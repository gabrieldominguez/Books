VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.1#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "ArcBall"
   ClientHeight    =   5070
   ClientLeft      =   3585
   ClientTop       =   2610
   ClientWidth     =   5070
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5070
   ScaleWidth      =   5070
   Begin MSComctlLib.StatusBar sts 
      Align           =   2  'Align Bottom
      Height          =   330
      Left            =   0
      TabIndex        =   1
      Top             =   4740
      Width           =   5070
      _ExtentX        =   8943
      _ExtentY        =   582
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   4
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
         EndProperty
         BeginProperty Panel4 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
         EndProperty
      EndProperty
   End
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4245
      Left            =   180
      TabIndex        =   0
      Top             =   90
      Width           =   4290
      _ExtentX        =   7567
      _ExtentY        =   7488
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "Options"
      Begin VB.Menu mnuAxis 
         Caption         =   "NoAxes"
         Index           =   1
         Shortcut        =   {F1}
      End
      Begin VB.Menu mnuAxis 
         Caption         =   "CameraAxis"
         Index           =   2
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuAxis 
         Caption         =   "BodyAxis"
         Index           =   3
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuAxis 
         Caption         =   "OtherAxis"
         Index           =   4
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuSep1 
         Caption         =   "-"
      End
      Begin VB.Menu m_ShowResult 
         Caption         =   "ShowResult"
         Shortcut        =   {F5}
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub

Private Sub Form_Resize()
    glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight - sts.height
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
    CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
    CX.InitGL
End Sub

Private Sub glxCtl1_Init()
    CX.Init
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Pick(items() As Long)
    CX.Pick items
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


Private Sub m_ShowResult_Click()
    'CX.KeyDown 116, 0
End Sub

Private Sub mnuAxis_Click(Index As Integer)
    CX.KeyDown Index + 111, 0
End Sub
