class AwesomeActor extends Actor
    placeable
    config(Game);

var config int MyConfigInt;

function PostBeginPlay()
{
    `log("MyConfigInt:" @ MyConfigInt);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
