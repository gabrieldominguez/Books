// This may look like C code, but it is really -*- C++ -*-
/* 
Copyright (C) 1988, 1992 Free Software Foundation
    written by Doug Lea (dl@rocky.oswego.edu)

This file is part of the GNU C++ Library.  This library is free
software; you can redistribute it and/or modify it under the terms of
the GNU Library General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.  This library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU Library General Public License for more details.
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free Software
Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _std_h
#define _std_h 1

#if defined(__GNUC__)
#include <_G_config.h>
#endif
#include <stdlib.h>
#include <string.h>
#if defined(unix)
#include <unistd.h>
#elif defined(WIN32)
#else
#endif
#include <stdio.h> 
#include <errno.h>
#include <fcntl.h>

#if defined(__GNUC__)
extern "C" {
int strcasecmp _G_ARGS((const char*, const char*));
}
#endif

#endif 
