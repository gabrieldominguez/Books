Attribute VB_Name = "modLang"
Option Explicit
'//-------- Localization ------------
Public intLOffset As Integer

Public rstrRepertoire As String
Public rstrFichier As String
Public rstrTitre As String
Public rstrArtiste As String
Public rstrAlbum As String
Public rstrAnnee As String
Public rstrGenre As String
Public rstrCommentaire As String
Public rstrPiste As String
Public rstrTaille As String
Public rstrDuree As String
Public rstrKbps As String
Public rstrMode As String
Public rstrRenommer As String
Public rstrKOct As String
Public rstrDate As String
Public rstrHeure As String

Public rstrSaisirPasse As String
Public rstrProtection As String
Public rstrMemePasse As String
Public rstrEcraser As String
Public rstrFichierExiste As String

Public Const resTitre = 112
Public Const resArtiste = 113
Public Const resAlbum = 114
Public Const resAnnee = 115
Public Const resCommentaire = 116
Public Const resPiste = 213
Public Const resEdit = 117
Public Const resDir = 118
Public Const resQuelsFichiers = 119
Public Const resRenommer = 120
Public Const resOpTerm = 121
Public Const resFiRen = 122
Public Const resRisque = 123
Public Const resContinuer = 124
Public Const resEtesEffacer = 125
Public Const resSuppression = 126

Public Const resMnuFichier = 127
Public Const resMnuRenommer = 130
Public Const resMnuEffacer = 128
Public Const resMnuRafraichir = 148
Public Const resMnuQuitter = 129

Public Const resMnuEdition = 197
Public Const resMnuMajuscule = 198

Public Const resDiffuser = 131
Public Const resColonne = 132
Public Const resEnsemble = 133
Public Const resApply = 134
Public Const resEnregistrer = 135
Public Const resPropager = 136
Public Const resFormat = 137
Public Const resAppliquer = 138
Public Const resAppliquerTous = 149
Public Const resAnnulerAppliquer = 199
Public Const resPlaylist = 139
Public Const resListing = 170

Public Const resOutils = 150
Public Const resToutDezipper = 151
Public Const resConfiguration = 152

Public Const resMnuAide = 194
Public Const resMnuForum = 212
Public Const resMnuMAJ = 209
Public Const resMnuApropos = 196

Public Const resMnuEchange = 200

Public Const resNomDuFichier = 140
Public Const resAucun = 141
Public Const resLanguage = 147
'//-------------------------------------------

Public Sub initLocalization()
'//-------- Localization ------------
rstrRepertoire = LoadResString(intLOffset + 184)
rstrFichier = LoadResString(intLOffset + 101)
rstrTitre = LoadResString(intLOffset + 102)
rstrArtiste = LoadResString(intLOffset + 103)
rstrAlbum = LoadResString(intLOffset + 104)
rstrAnnee = LoadResString(intLOffset + 105)
rstrGenre = LoadResString(intLOffset + 106)
rstrCommentaire = LoadResString(intLOffset + 107)
rstrPiste = LoadResString(intLOffset + 214)
rstrTaille = LoadResString(intLOffset + 108)
rstrDuree = LoadResString(intLOffset + 109)
rstrKbps = LoadResString(intLOffset + 110)
rstrMode = LoadResString(intLOffset + 111)
rstrRenommer = LoadResString(intLOffset + 120)
rstrKOct = LoadResString(intLOffset + 201)
rstrDate = LoadResString(intLOffset + 203)
rstrHeure = LoadResString(intLOffset + 204)

rstrSaisirPasse = LoadResString(intLOffset + 205)
rstrProtection = LoadResString(intLOffset + 206)
rstrMemePasse = LoadResString(intLOffset + 207)
rstrEcraser = LoadResString(intLOffset + 167)
rstrFichierExiste = LoadResString(intLOffset + 208)

With frmEditMp3
    .lblTmp(0) = LoadResString(intLOffset + resTitre)
    .lblTmp(1) = LoadResString(intLOffset + resArtiste)
    .lblTmp(2) = LoadResString(intLOffset + resAlbum)
    .lblTmp(3) = LoadResString(intLOffset + resAnnee)
    .lblTmp(5) = LoadResString(intLOffset + resCommentaire)
    .lblTmp(6) = LoadResString(intLOffset + resPiste)
    
    .fraEdit.Caption = LoadResString(intLOffset + resEdit)
    .fraDir.Caption = LoadResString(intLOffset + resDir)
    
    .mnuFichier.Caption = LoadResString(intLOffset + resMnuFichier)
    .mnuFichierRenommer.Caption = LoadResString(intLOffset + resMnuRenommer)
    .mnuFichierEffacer.Caption = LoadResString(intLOffset + resMnuEffacer)
    .mnuFichierRafraichir.Caption = LoadResString(intLOffset + resMnuRafraichir)
    .mnuFichierQuitter.Caption = LoadResString(intLOffset + resMnuQuitter)
    
    .mnuEdition.Caption = LoadResString(intLOffset + resMnuEdition)
    .mnuEditionMajuscule.Caption = LoadResString(intLOffset + resMnuMajuscule)
    .mnuEditionArtisteAlbum.Caption = rstrArtiste & " <=> " & rstrAlbum
    .mnuEditionTitreAlbum.Caption = rstrTitre & " <=> " & rstrAlbum
    .mnuEditionTitreArtiste.Caption = rstrTitre & " <=> " & rstrArtiste
    
    .mnuOptionsPropager.Caption = LoadResString(intLOffset + resPropager)
        .mnuOptionsArtiste.Caption = rstrArtiste
        .mnuOptionsAlbum.Caption = rstrAlbum
        .mnuOptionsAnnee.Caption = rstrAnnee
        .mnuOptionsGenre.Caption = rstrGenre
        .mnuOptionsCommentaire.Caption = rstrCommentaire
    .mnuOptionsFormat.Caption = LoadResString(intLOffset + resFormat)
    .mnuOptionsAppliqueFormat.Caption = LoadResString(intLOffset + resAppliquer)
    .mnuOptionsAppliqueFormatTous.Caption = LoadResString(intLOffset + resAppliquerTous)
    .mnuOptionsAnnulerFormat.Caption = LoadResString(intLOffset + resAnnulerAppliquer)
    .mnuOptionsPlaylist.Caption = LoadResString(intLOffset + resPlaylist)
    .mnuOptionsListing.Caption = LoadResString(intLOffset + resListing)
    
    .mnuOutils.Caption = LoadResString(intLOffset + resOutils)
    .mnuOutilsToutDezipper.Caption = LoadResString(intLOffset + resToutDezipper)
    .mnuOutilsConfiguration.Caption = LoadResString(intLOffset + resConfiguration)
    
    .mnuAide.Caption = LoadResString(intLOffset + resMnuAide)
    .mnuAideForum.Caption = LoadResString(intLOffset + resMnuForum)
    .mnuAideMiseAJour.Caption = LoadResString(intLOffset + resMnuMAJ)
    .mnuAideAPropos.Caption = LoadResString(intLOffset + resMnuApropos)
    
    .cmdEnregistrer.Caption = LoadResString(intLOffset + resEnregistrer)
    
    .mnuPopupEchange(2).Caption = LoadResString(intLOffset + resMnuEchange) & " " & rstrTitre
    .mnuPopupEchange(3).Caption = LoadResString(intLOffset + resMnuEchange) & " " & rstrArtiste
    .mnuPopupEchange(4).Caption = LoadResString(intLOffset + resMnuEchange) & " " & rstrAlbum
    .mnuPopupEchange(7).Caption = LoadResString(intLOffset + resMnuEchange) & " " & rstrCommentaire
End With
End Sub
