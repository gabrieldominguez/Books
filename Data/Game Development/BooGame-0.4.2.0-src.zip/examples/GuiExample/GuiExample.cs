/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;
using BooGame.Gui.Widgets;

namespace GuiExample
{
    /// <summary>
    /// BooGame demonstration of the embedded GUI.
    /// </summary>
    public class GuiExample : GameState
    {
        public static void Main()
        {
            // Setup the game state
            Core.Game = new GuiExample();

            // Setup the system
            Display.ClearColor = Color.White;
            Timer.FpsUpdate += new FpsUpdateEventHandler(Timer_FpsUpdate);

            // Begin running the system
            Core.Run();
        }

        // When there's a new FPS value
        static void Timer_FpsUpdate(object sender, FpsUpdateEventArgs args)
        {
            Display.WindowCaption = "BooGame - GuiExample - " + args.Fps.ToString("#.0") + " FPS";
        }

        public GuiExample()
        {
            // Create the font
            BooGame.Font arial = new BooGame.Font("Arial", 17f, FontStyle.Regular);

            // Create some GUI elements
            Label label = new Label(arial);
            label.Text = "Hello World!";
            label.Tint = Color.Red;
            this.Gui.Add(label); // Add it to the GameState's GUI

            // Make a button
            Button button = new Button(arial);
            button.Text = "Toggle Fullscreen";
            button.Pressed += new ButtonEventHandler(button_Pressed);
            button.X = 50;
            button.Y = 150;
            this.Gui.Add(button); // Add it to the GameState's GUI

            // How about a textbox
            TextBox textbox = new TextBox(arial);
            textbox.Text = "Edit Me!";
            textbox.Rectangle = new RectangleF(200, 100, 200, 40);
            this.Gui.Add(textbox);

            // Progress bars are fun
            ProgressBar progressbar = new ProgressBar();
            progressbar.Rectangle = new RectangleF(Display.Width - 200, 200, 150, 20);
            progressbar.Value = 70f;
            this.Gui.Add(progressbar);

            // CheckBoxes give you some options
            CheckBox checkbox1 = new CheckBox(arial);
            checkbox1.X = 450;
            checkbox1.Y = 20;
            CheckBox checkbox2 = new CheckBox(arial);
            checkbox2.X = 450;
            checkbox2.Y = 80;
            this.Gui.Add(checkbox1);
            this.Gui.Add(checkbox2);

            // Container with some radio buttons
            Container container = new Container();
            container.X = 20;
            container.Y = 400;
            container.Rectangle = new RectangleF(20, 400, 100, 80);
            RadioButton radio1 = new RadioButton(arial);
            RadioButton radio2 = new RadioButton(arial);
            radio2.X = 60f;
            radio2.Checked = true;
            container.Add(radio1);
            container.Add(radio2);
            this.Gui.Add(container);
        }

        void button_Pressed(object sender, ButtonEventArgs args)
        {
            Display.FullScreen = !Display.FullScreen;
        }

        public override void KeyUp(KeyboardEventArgs args)
        {
            if (args.Key == Keys.Escape)
                Core.QuitApplication();
        }
    }
}
