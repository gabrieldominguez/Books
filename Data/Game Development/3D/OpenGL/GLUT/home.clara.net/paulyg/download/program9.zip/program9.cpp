/* 15 June.  Simple single name picking example and use of GLUT text */
/*  By Paul Groves.                                                  */


#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "tgaload.h"

// For the textures
#define  MAX_NUM_TEXTURES    2
#define  EARTH_TEXTURE       0
#define  MOON_TEXTURE        1
GLuint   texture_names   [MAX_NUM_TEXTURES];

// Selection buffer and naming
#define  EARTH    1
#define  MOON     2


// We need to call gluPerspective out of the reshape function, so we need this
float aspect_ratio;

// Angles here
float angle, view_angle1, view_angle2;

int   startx, starty, depressed, ScreenWidth, ScreenHeight;

GLfloat  ambient_light[] = {0.3, 0.3, 0.45, 1.0};
GLfloat   source_light[] = {0.9, 0.8, 0.8, 1.0};
GLfloat      light_pos[] = {7.0, 0.0, 0.0, 1.0};

// For text in the 'overlay'
char str[256];


void OutputString ( float x, float y, char *string )
{
   int length;

   length = strlen ( string );
   glRasterPos2f( x, y );
   for (int  i = 0; i < length; i++ )
      glutBitmapCharacter ( GLUT_BITMAP_9_BY_15, string[i] );
}

void init(void)
{
   // Set up simple lighting model
   glEnable       ( GL_LIGHTING );
   glLightModelfv ( GL_LIGHT_MODEL_AMBIENT, ambient_light );
   glLightfv      ( GL_LIGHT0,GL_DIFFUSE,   source_light  );
   glLightfv      ( GL_LIGHT0,GL_POSITION,  light_pos     );
   glEnable       ( GL_LIGHT0 );

   // Enable material properties for lighting
   glEnable        ( GL_COLOR_MATERIAL );
   glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );

   // Do texture stuff :)
   glEnable      ( GL_TEXTURE_2D );
   glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
   glGenTextures ( 2, texture_names );
   
   texture_names[ EARTH_TEXTURE ] = tgaLoadAndBind  ( "earth.tga", TGA_DEFAULT );
   texture_names[ MOON_TEXTURE ]  = tgaLoadAndBind  ( "moon.tga", TGA_DEFAULT );

   glClearColor ( 0.0, 0.0, 0.0, 0.0 );
   glEnable     ( GL_DEPTH_TEST );
   glShadeModel ( GL_SMOOTH );
}


void draw_orbit_line ( float radius )
{
   float angle;

   glDisable ( GL_LIGHTING );
   glDisable ( GL_TEXTURE_2D );

   // Copy the current matrix and start a new one
   glPushMatrix ( );
   glRotatef ( 90.0, 1.0, 0.0, 0.0 );
   glBegin   ( GL_LINE_LOOP );
   glColor3f ( 0.0, 0.6, 0.0 );
   for ( int i = 0; i <= 24; i++ )
   {
      angle = 3.14159 / 12.0 * i;
      glVertex2f ( ( radius*cos ( angle )), ( radius*sin ( angle )) );
   }
   glEnd ( );
   glPopMatrix ( );

   glEnable ( GL_LIGHTING );
   glEnable ( GL_TEXTURE_2D );
}


void draw_sphere ( int tex_id, float size )
{
   glPushMatrix ( );
   glRotatef    ( -90.0, 1.0, 0.0, 0.0 );
   glColor4f    ( 1.0, 1.0, 1.0, 1.0 );
   GLUquadricObj*  q = gluNewQuadric ( );
   gluQuadricDrawStyle ( q, GLU_FILL );
   gluQuadricNormals   ( q, GLU_SMOOTH );
   gluQuadricTexture   ( q, GL_TRUE    );
   glBindTexture ( GL_TEXTURE_2D, texture_names[ tex_id ] );
   gluSphere ( q, size, 20, 20 );
   gluDeleteQuadric ( q );
   glPopMatrix ( );
}


void draw_2d_stuff ( void )
{
   glDisable ( GL_LIGHTING );
   glDisable ( GL_TEXTURE_2D );

   /* Set up viewing matrix  */
   glMatrixMode   ( GL_PROJECTION );
   glPushMatrix   ( );
   glLoadIdentity ( );

   glOrtho ( 0.0, ( (double)ScreenWidth ), 0.0,
                  ( (double)ScreenHeight ), -0.0, 0.0 );

   glMatrixMode   ( GL_MODELVIEW );

   glLoadIdentity ( );
      glColor3ub     ( 200, 200, 200    );
      OutputString   ( -0.95, 0.90, str );

   glMatrixMode ( GL_PROJECTION );
   glPopMatrix  ( );

   glMatrixMode ( GL_MODELVIEW );

   glEnable ( GL_LIGHTING );
   glEnable ( GL_TEXTURE_2D );
}


void draw_planets ( GLenum mode )
{
   glPushMatrix ( );
   glLightfv    ( GL_LIGHT0,GL_POSITION,light_pos );
   glTranslatef ( 0.0, 0.0, -4.0 );
   glRotatef ( view_angle1, 0.0, 1.0, 0.0 );
   glRotatef ( view_angle2, 1.0, 0.0, 0.0 );

   if (mode == GL_SELECT)
      glLoadName( EARTH );
   draw_sphere ( EARTH_TEXTURE, 1.0 );

   draw_orbit_line ( 2.0 );

   glRotatef   ( angle, 0.0, 1.0, 0.0 );
   glTranslatef ( 0.0, 0.0, 2.0 );

   if (mode == GL_SELECT)
      glLoadName( MOON );
   draw_sphere ( MOON_TEXTURE, 0.5 );
   glPopMatrix ( );
}


void process_hits ( GLint hits, GLuint buffer[] )
{
   // Use a struct to hold the current closest selection
   struct {
   GLuint z1;
   GLuint current_name;
   } log_me;

   // Looping vars and pointer vars
   unsigned int i, j;
   GLuint names, *ptr, *tptr;

   // Initialise the 'closest' Z value so out test works properly
   log_me.z1 = 9999999999999999999999999999999999999999999999999999;

   // Print the number of hits
   printf ( "hits = %d\n", hits );

   // Assign a pointer and a temporary pointer to the buffer indices
   ptr  = (GLuint *) buffer;
   tptr = (GLuint *) buffer;

   // For each hit grab values out of the buffer
   for ( i = 0; i < hits; i++ )
   {
      // Firstly get the number of names for this hit (should always be one in
      // this example.  Then increment the buffer pointer
      names = *ptr;
      printf ( "Number of names for this hit = %d\n", names );
      ptr++;

      // Print the closest Z value for this hit and inc the pointer
      printf ( "Closest Z:%u", *ptr );

      // If the current entries' closest Z is the lowest so far log it.
      // And skip ahead 2 positions in the buffer (using the temporary pointer)
      // to the name of the hit
      if (*ptr < log_me.z1 )
      {
         log_me.z1 = *ptr;
         tptr = ptr + 2;
         log_me.current_name = *tptr;
      }
      ptr++;

      // Print the furthest value for the current hit - increment the pointer
      printf("   Furthest Z: %u\n", *ptr );
      ptr++;

      // Print the name of the hit (there could be multiple hits, but only one
      // name
      printf(" the name is ");
      for (j = 0; j < names; j++)
      {
         printf("%d ", *ptr);
         ptr++;
      }
      printf("\n");
   }

   if ( hits >= 1 )
       sprintf ( str, "Object %u was selected.", log_me.current_name );

   if ( hits == 0 )
       sprintf ( str, "No object was selected." );
}


#define BUFSIZE 512
void pick_planets ( int x, int y )
{
   GLuint selectBuf[BUFSIZE];
   GLint hits;
   GLint viewport[4];

   // Get the size of the current viewport
   glGetIntegerv ( GL_VIEWPORT, viewport );

   // Allocate the selection buffer and enter selection mode
   glSelectBuffer ( BUFSIZE, selectBuf );
   glRenderMode   ( GL_SELECT );

   // Clear the names on the name stack and push on an 'empty' name
   glInitNames (   );
   glPushName  ( 0 );

   // Switch to projection mode and save our current projection
   glMatrixMode ( GL_PROJECTION );
   glPushMatrix   ( );

   // create 2x2 pixel picking region near cursor location
   glLoadIdentity ( );
   gluPickMatrix ( (GLdouble)x, (GLdouble)( viewport[3] - y ),
                 2.0, 2.0, viewport );

   // Apply the same view perspective
   gluPerspective ( 80.0, aspect_ratio, 1.0, 200.0 );

   // Go back to MODELVIEW and draw the planets again, this time loading names
   // on the stack
   glMatrixMode ( GL_MODELVIEW );
   draw_planets ( GL_SELECT );

   // Force OpenGL to finish up before continuing
   glFlush     ( );

   // Collect the number of hits from the render and parse the selection
   hits = glRenderMode ( GL_RENDER );
   process_hits  ( hits, selectBuf );

   // Restore the projection matrix
   glMatrixMode ( GL_PROJECTION );
   glPopMatrix  ( );

   // Go back to modelview for normal rendering
   glMatrixMode ( GL_MODELVIEW );
}


void display ( void )
{
   glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   draw_planets ( GL_RENDER );

   draw_2d_stuff   ( );
   glutSwapBuffers ( );
}

void mouse ( int button, int state, int x, int y )
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {
      depressed = 1;
      pick_planets ( x, y );
   }
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      depressed = 0;

   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
   {
      depressed = 2;
      startx = x;
      starty = y;
   }
   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_UP )
      depressed = 0;
}


void motion ( int x, int y )
{
   if ( depressed == 2 )
   {
      view_angle1 = view_angle1 + ( x - startx );
      view_angle2 = view_angle2 + ( y - starty );
      startx = x;
      starty = y;
   }
   glutPostRedisplay ( );
}


void reshape ( int w, int h )
{
   glViewport     ( 0, 0, w, h );
   glMatrixMode   ( GL_PROJECTION );
   glLoadIdentity ( );

   // Calculate correct aspect ratio (and prevent div by zero error)
   if ( h==0 )
      aspect_ratio = ( float )w;
   else
      aspect_ratio = ( float )w / ( float )h;

   gluPerspective ( 80.0, aspect_ratio, 1.0, 200.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );

   ScreenWidth  = w;
   ScreenHeight = h;
}


#pragma argsused
void keyboard ( unsigned char key, int x, int y )
{
   switch ( key )
   {
      case 27:
         exit ( 0 );
         break;
   }
}


void idle ( void )
{
   angle += 1;
   if ( angle >= 360 )
      angle = 0;

   glutPostRedisplay ( );
}


int main ( int argc, char **argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( argv[0] );

   init ( );

   glutIdleFunc     ( idle     );
   glutReshapeFunc  ( reshape  );
   glutDisplayFunc  ( display  );
   glutMouseFunc    ( mouse    );
   glutMotionFunc   ( motion   );
   glutKeyboardFunc ( keyboard );

   glutMainLoop ( );

   return 0; 
}
