VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3dBoundingBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'-----------------------------------------------------------------
'FUNCTION: this class is not used. the control uses
'the default resize of the ocx, the glxCamera.
'This file is included FYI, but has not been tested.
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'-----------------------------------------------------------------
'-----------------------------------------------------------------
Dim m_BoundX! 'As POINT3F ' bounding box, from spin angles
Dim m_BoundY! '
Dim m_BoundZ! '
Dim m_BoundingBoxProc As BoundingBoxProcConstants

Private Sub Class_Initialize()
'-----------------------------------------------------------------
End Sub

Private Sub Class_Terminate()
'-----------------------------------------------------------------
End Sub

Public Property Get BoundingBoxProc() As BoundingBoxProcConstants
BoundingBoxProc = m_BoundingBoxProc
End Property

Public Property Let BoundingBoxProc(ByVal NewValue As BoundingBoxProcConstants)
m_BoundingBoxProc = NewValue
End Property

Public Property Get X!()
X = m_BoundX
End Property

Public Property Get Y!()
If m_BoundY = 0 Then
    Y = 1
Else
    Y = m_BoundY
End If
End Property

Public Property Get Z!()
Z = m_BoundZ
End Property

Public Property Get AspectRatio!()
If m_BoundY = 0 Then m_BoundY = 1
AspectRatio = m_BoundX / m_BoundY
End Property

Public Sub CalcBoundingBox()
Select Case m_BoundingBoxProc
Case procCalcBoundingBox
    m_CalcBoundingBox
Case procCalcBoundingBoxGeneric
    m_CalcBoundingBoxGeneric
End Select
If m_BoundY = 0 Then
    ' avoid /0
    m_BoundY = 1
End If
End Sub

'*************************************************************************\
'* CalcBoundingBoxGeneric
'* Combines the bounding sphere with the bounding extents
'* Each of these alone will guarantee no clipping.  But we can
'* optimize by combining them.
'*************************************************************************/
Private Sub m_CalcBoundingBoxGeneric()
Dim extentBox As POINT3F
Dim X!, Y!, Z!, r!, d!, zt!, fovx!
Dim viewAngle!, viewDist!, viewDistO!
Dim xIn As Boolean, yIn As Boolean
With gCtl
    ' x,y,z represent half-extents
    X = g3D.TextExtentX / 2
    Y = g3D.TextExtentY / 2
    Z = g3D.StringDepth / 2
    ' get the max extent box
    '!!! wait, this alone doesn't guarantee no clipping?  It only
    ' * checks each axis-rotation separately, without combining them. This
     '* is no better than calling old CalcBoundingBox ... ??  Well, I
     '* can't prove why theoretically, but it works
    m_CalcBoundingBoxFromExtents extentBox
    ' determine whether x and y extents inside/outside bounding sphere
    r = Sqr(X * X + Y * Y + Z * Z)
    ' check y
    d = Sqr(extentBox.Y * extentBox.Y + extentBox.Z * extentBox.Z)
    yIn = IIf(d <= r, True, False)
    ' check x
    d = Sqr(extentBox.X * extentBox.X + extentBox.Z * extentBox.Z)
    xIn = IIf(d <= r, True, False)
    ' handle easy cases
    If (yIn And xIn) Then
        'm_Bound = extentBox
        m_BoundX = extentBox.X
        m_BoundY = extentBox.Y
        m_BoundZ = extentBox.Z
        Exit Sub
    End If
    If (yIn = 0 And xIn = 0) Then
        m_CalcBoundingBoxFromSpherePlus extentBox.Z
        Exit Sub
    End If
    ' harder cases
    viewAngle = .Ex.DegToRad(.Camera.FieldOfView) / 2
    If (yIn) Then
        ' figure out x
        viewDist = extentBox.Y / Tan(viewAngle)
        ' viewDist can be inside or outside of the sphere
'         * If inside - no optimization possible
'         * If outside, can draw line from viewpoint tangent to sphere,
'         * and use this point for x
        viewDistO = extentBox.Z + viewDist
        If (viewDistO <= r) Then
            ' vp inside sphere
            ' set x to the point where z intersects sphere
            ' this becomes a Pythagorous theorem problem:
            extentBox.X = Sqr(r * r - extentBox.Z * extentBox.Z)
        Else
            ' vp outside sphere
            ' - figure out zt, where line tangent to circle for viewAngle
            fovx = ArcSin(r / viewDistO)
            zt = r * ArcCos(PI_OVER_2 - viewAngle)
            If (extentBox.Z < zt) Then
                ' use x where extentBox.z intersects sphere
                extentBox.X = Sqr(r * r - extentBox.Z * extentBox.Z)
            Else
                ' use x at tangent point
                extentBox.X = Sqr(r * r - zt * zt)
            End If
        End If
    Else ' y out, x in
        ' have to figure out whether vp inside/outside of sphere.
        ' !We can cheat a bit here.  It IS possible, with view angles > 90,
         '* that the vp be inside sphere.  But since we always use 90 for
         '* this app, it is safe to assume vp > r  (Fix later for general case)
        ' XXX: wait, if y out, isn't vp always outside sphere ?
        ' So we solve it this way:
         '* - figure out line tangent to circle for viewAngle
         '* - y will be where this line intersects the z=extentBox.z line
        viewDistO = r / Sin(viewAngle)
        extentBox.Y = (viewDistO - extentBox.Z) * Tan(viewAngle)
    End If
    m_BoundX = extentBox.X
    m_BoundY = extentBox.Y
    m_BoundZ = extentBox.Z
End With
End Sub

'*************************************************************************\
'* CalcBoundingBox
'*************************************************************************/
Private Sub m_CalcBoundingBox()
Dim den!
Dim box(3) As POINT3F  ' for each axis rotation
Dim viewAngle!, critAngle!, critAngleC!, rectAngle!
Dim r!, rot!, X!, Y!, Z!, ymax!, zCrit!
Dim viewDist!, viewDistO!, xAngle!(3)
Dim boxvpo!(3)  ' viewpoint to origin distance along z for the boxes
Dim n&
Dim pt As POINT3F
With gCtl
    ' One thing to remember here is that box(n).z is constrained to be
'     * the near clipping plane.  The boxe's x and y represent the frustum
'     * cross-section at that point.
    viewAngle = .Ex.DegToRad(.Camera.FieldOfView) / 2
    ' x,y,z represent half-extents
    X = g3D.TextExtentX / 2
    Y = g3D.TextExtentY / 2
    Z = g3D.StringDepth / 2
    ' initialize box(0) with current extents
    box(0).X = X
    box(0).Y = Y
    box(0).Z = Z
    boxvpo(0) = 0
    ' handle rotation around x-axis
    If (gAC.RotMaxX <> 0) Then
        box(n).X = X
        ' need to determine y and z
        rot = gCtl.Ex.DegToRad(gAC.RotMaxX)
        r = Sqr(Y * Y + Z * Z)
        ' calc incursion along z
        rectAngle = IIf(Z = 0, PI_OVER_2, Atn(Y / Z))
        If (rot >= rectAngle) Then
            ' easy, use maximum possible extent
            box(n).Z = r
        Else
            ' rotate lower right corner of box by rot to get extent
            box(n).Z = Z * Cos(rot) + Y * Sin(rot)
        End If
        ' figure out critical angle, where rotated rectangle would
'         * be perpendicular to viewing frustum.  This indicates the max.
'         * y-incursion into the frustum.
        critAngle = PI_OVER_2 - viewAngle
        ymax = r * Sin(critAngle)
        If (Y > Z) Then
            rectAngle = PI_OVER_2 - rectAngle
            critAngleC = PI_OVER_2 - critAngle
        Else
            critAngleC = critAngle
        End If
        If ((rectAngle + rot) >= critAngleC) Then
            ' no view reduction possible in y, use max view
            ' need to calc y at box.z
            viewDistO = r / Cos(critAngle)
            boxvpo(n) = viewDistO
            box(n).Y = (viewDistO - box(n).Z) * Tan(PI_OVER_2 - critAngle)
        Else
            ' we can sonic reduce it
            If (Y > Z) Then
                rot = -rot
            End If
            ' rotate front-top point by rot to get ymax, z
            ymax = Z * Sin(rot) + Y * Cos(rot)
            zCrit = Z * Cos(rot) - Y * Sin(rot)
            ' not usin viewDistO properly here...
            viewDistO = ymax * Tan(viewAngle)
            boxvpo(n) = viewDistO + zCrit
            viewDist = boxvpo(n) - box(n).Z
            box(n).Y = viewDist * Tan(viewAngle)
        End If
        n = n + 1
    End If

    If (gAC.RotMaxY <> 0) Then
        box(n).Y = Y
        ' need to determine x and z
        rot = gCtl.Ex.DegToRad(gAC.RotMaxY)
        r = Sqr(X * X + Z * Z)
        rectAngle = IIf(Z = 0, PI_OVER_2, Atn(X / Z))
        ' calc incursion along z
        If (rot >= rectAngle) Then
            ' easy, use maximum possible extent
            box(n).Z = r
        Else
            ' rotate lower right corner of box by rot to get extent
            box(n).Z = Z * Cos(rot) + X * Sin(rot)
        End If
        ' view distance to largest z
        viewDist = Y / Tan(viewAngle)
        ' make viewDist represent distance to origin
        viewDistO = viewDist + box(n).Z
        boxvpo(n) = viewDistO
        ' now minimize angle between viewpoint and rotated rect
        If (viewDistO > r) Then
            ' calc crit angle where view is maximized (line from viewpoint
'             * tangent to rotation circle)
'             * critAngle is between z-axis and radial line
            critAngle = ArcCos(r / viewDistO)

            ' critAngleC is for Comparing
            If (X > Z) Then
                rectAngle = PI_OVER_2 - rectAngle
                critAngleC = PI_OVER_2 - critAngle
            Else
                critAngleC = critAngle
            End If
        End If

        If ((viewDistO > r) And ((rectAngle + rot) >= critAngleC)) Then
            ' no view reduction possible in x, use x along the max-view line
            box(n).X = viewDist * Tan(PI_OVER_2 - critAngle)
        Else
            ' we can sonic reduce it
            If (X > Z) Then
                rot = -rot
            End If
            ' rotate front-top point by rot to get x,z
            ' pt.z not needed
            'pt.z = z *  cos( rot ) - x *  sin( rot
            pt.X = Z * Sin(rot) + X * Cos(rot)
            box(n).X = pt.X
        End If
        n = n + 1
    End If

    If (gAC.RotMaxZ <> 0) Then
        m_CalcBoundingExtent gCtl.Ex.DegToRad(gAC.RotMaxZ), _
                            X, Y, _
                            box(n).X, box(n).Y '(POINTFLOAT *)
        box(n).Z = Z
        ' calc viewing distance from front of box
        viewDist = box(n).Y / Tan(viewAngle)
        ' calc view distance to origin;
        boxvpo(n) = box(n).Z + viewDist
        n = n + 1
    End If
    ' Now we've got 3 rectangles in x-y plane at various depths, and
'     * need to pick the shortest viewing distance that will encompass
'     * all of them.  Or, don't actually have to pick the view distance
'     * yet, since might want to wait for the viewport size in Reshape before
'     * we do this - but in that case need to pick the rectangle that 'sticks
'     * out the most', so it can be used as the bounding box.
'     */
    ' The box with the furthest viewpoint will work for y.
'     * But then have to check
'     * this against the x's of the others.  If any stick out of the frustum,
'     * then it will have to be made larger in x.  By making x larger, we
'     * do not affect fovy
'     */
    m_SortBoxes box, boxvpo, n  ' put largest viewpoint box in box(0)

    ' figure view dist to first box
    ' (could maintain these as they are calculated)
    viewDist = boxvpo(0) - box(0).Z
    ' compare x angles of boxes
    Select Case n
        Case 3:
            den = viewDist + (box(0).Z - box(2).Z)
            xAngle(2) = IIf(den = 0, PI_OVER_2, Atn(box(2).X / den))
        Case 2:
            den = viewDist + (box(0).Z - box(1).Z)
            xAngle(1) = IIf(den = 0, PI_OVER_2, Atn(box(1).X / den))
        Case 1:
            xAngle(0) = IIf(viewDist = 0, PI_OVER_2, Atn(box(0).X / viewDist))
    End Select
    ' here, just call Sort again, with list of xAngles
    m_SortBoxes box, xAngle, n  ' put largest xangle box in box(0)
    ' now box(0) should contain half extents of the Bounding box
    m_BoundX = box(0).X
    m_BoundY = box(0).Y
    m_BoundZ = box(0).Z
End With
End Sub

'*************************************************************************\
'* CalcBoundingBoxFromSphere
'* Calculates the bounding box from a sphere with r = diagonal of the box
'*************************************************************************/
Private Sub m_CalcBoundingBoxFromSphere()
Dim X!, Y!, Z!, r!
Dim viewAngle!, viewDist!, viewDistO!
Dim box As POINT3F
With gCtl
    ' x,y,z represent half-extents
    X = g3D.TextExtentX / 2
    Y = g3D.TextExtentY / 2
    Z = g3D.StringDepth / 2

    r = Sqr(X * X + Y * Y + Z * Z)
    box.Z = r
    viewAngle = .Ex.DegToRad(.Camera.FieldOfView / 2)
    viewDistO = r / Sin(viewAngle)
    viewDist = viewDistO - r
    box.Y = viewDist * Tan(viewAngle)
    box.X = box.Y
    m_BoundX = box.X
    m_BoundY = box.Y
    m_BoundZ = box.Z
End With
End Sub

'*************************************************************************\
'* CalcBoundingBoxFromSpherePlus
'* Same as above, but tries to optimize for case when z exent is small
'*************************************************************************/
Private Sub m_CalcBoundingBoxFromSpherePlus(zmax!)
Dim X!, Y!, Z!, r!
Dim viewAngle!, viewDist!, viewDistO!
Dim box As POINT3F
With gCtl
    ' x,y,z represent half-extents
    X = g3D.TextExtentX / 2
    Y = g3D.TextExtentY / 2
    Z = g3D.StringDepth / 2

    r = Sqr(X * X + Y * Y + Z * Z)
    viewAngle = .Ex.DegToRad(.Camera.FieldOfView / 2)
    If (zmax < r) Then
        ' we can get closer !
        box.Z = zmax
        viewDistO = r / Sin(viewAngle)
        viewDist = viewDistO - zmax

        ' we want to move the clipping plane closer by (r-zmax)
        If ((r - zmax) > viewDist) Then
        If SS_DEBUG Then
            glClearColor 1, 0, 0, 0
        End If
            ' we are moving the vp inside the sphere
            box.Y = Sqr(r * r - box.Z * box.Z)
            box.X = box.Y
        Else
            Dim zt! ' z-point where view frustum tangent to sphere
            ' vp outside sphere: can only optimize if zmax < ztangent
            zt = r * Cos(PI_OVER_2 - viewAngle)
            If (zmax < zt) Then
        If SS_DEBUG Then
                ' GREEN ZONE !!!
                glClearColor 0, 1, 0, 0
        End If
                box.Y = Sqr(r * r - zmax * zmax)
            Else
                ' this is the same as below, but with better clipping
                box.Y = (viewDist + (r - zmax)) * Tan(viewAngle)
            End If
            box.X = box.Y
        End If
    Else
        box.Z = r
        viewDistO = r / Sin(viewAngle)
        viewDist = viewDistO - r
        box.Y = viewDist * Tan(viewAngle)
        box.X = box.Y
    End If
    m_BoundX = box.X
    m_BoundY = box.Y
    m_BoundZ = box.Z
End With
End Sub

'*************************************************************************\
'* CalcBoundingBoxFromExtents
'* Calculate bounding box for text, assuming text centered at origin, and
'* using maximum possible spin angles.
'* Rotation around any one axis will affect bounding areas in the other
'* 2 directions (e.g. z-rotation affects x and y bounding values).
'* We need to find the maxima of the rotated 2d area, while staying within
'* the max spin angles.
'*************************************************************************/
Private Sub m_CalcBoundingBoxFromExtents(box As POINT3F)
Dim extent As POINTFLOAT
    box.X = g3D.TextExtentX / 2
    box.Y = g3D.TextExtentY / 2
    box.Z = g3D.StringDepth / 2

    ' split the 3d problem into 3 2d problems in 'x-y' plane

    If (gAC.RotMaxX <> 0) Then
        m_CalcBoundingExtent gCtl.Ex.DegToRad(gAC.RotMaxX), _
                            box.Z, box.Y, extent.X, extent.Y
        box.Z = gCtl.Ex.Max(box.Z, extent.X)
        box.Y = gCtl.Ex.Max(box.Y, extent.Y)
    End If

    If (gAC.RotMaxY <> 0) Then
        m_CalcBoundingExtent gCtl.Ex.DegToRad(gAC.RotMaxY), _
                            box.X, box.Z, extent.X, extent.Y
        box.X = gCtl.Ex.Max(box.X, extent.X)
        box.Z = gCtl.Ex.Max(box.Z, extent.Y)
    End If

    If (gAC.RotMaxZ <> 0) Then
        m_CalcBoundingExtent gCtl.Ex.DegToRad(gAC.RotMaxZ), _
                            box.X, box.Y, extent.X, extent.Y
        box.X = gCtl.Ex.Max(box.X, extent.X)
        box.Y = gCtl.Ex.Max(box.Y, extent.Y)
    End If
End Sub


'*************************************************************************\
'* Calculate the extents in x and y from rotating a rectangle in a 2d plane
'*************************************************************************/
Private Sub m_CalcBoundingExtent(rot!, X!, Y!, extentX!, extentY!) ' As POINTFLOAT)
Dim r!, angleCrit!
    r = Sqr(X * X + Y * Y)
    angleCrit = IIf(X = 0, PI_OVER_2, Atn(Y / X))
    ' calc incursion in x
    If (rot >= angleCrit) Then
        ' easy, use maximum possible extent
        extentX = r
    Else
        ' rotate lower right corner of box by rot to get extent
        extentX = X * Cos(rot) + Y * Sin(rot)
    End If
    ' calc incursion in y
    angleCrit = PI / 2 - angleCrit
    If (rot >= angleCrit) Then
        ' easy, use maximum possible extent
        extentY = r
    Else
        ' rotate upper right corner of box by rot to get extent
        extentY = X * Sin(rot) + Y * Cos(rot)
    End If
End Sub

'*************************************************************************\
'* Sorts in descending order, based on values in val array (bubble sort)
'*************************************************************************/
Private Sub m_SortBoxes(box() As POINT3F, v!(), numBox&)
Dim i&, j&, t&
Dim temp As POINT3F
    j = numBox
    Do While (j)
        t = 0
        For i = 0 To j - 2
            If v(i) < v(i + 1) Then
                ' swap'em
                temp = box(i)
                box(i) = box(i + 1)
                box(i + 1) = temp
                t = i
            End If
        Next
        j = t
    Loop
End Sub





