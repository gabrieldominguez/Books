VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CRainbow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
''
' *  Demonstration of palette animation in color index mode.
' *  Press 'h' for a help menu, middle button spins.
' *
' *  author: Nate Robins
' *  email: ndr@pobox.com
' *  www: http://www.pobox.com/~ndr
' */
''*****************************Module*Header******************************
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
''************************************************************************
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim tb As glxTrackBall
' globals */
Dim cube_list&       ' display list for cube */
Dim auto_rotate As Boolean   ' automatically rotate */
Const NUMCOLORS = 12
Dim colors(0 To NUMCOLORS * 2 * 3 - 1) As Byte
Dim light_position!(0 To 3)


Private Sub Class_Initialize()
auto_rotate = True
' duplicate the list */
FillArrayb colors, _
  255, 0, 0, 255, 128, 0, 255, 255, 0, _
  128, 255, 0, 0, 255, 0, 0, 255, 128, _
  0, 255, 255, 0, 128, 255, 0, 0, 255, _
  128, 0, 255, 255, 0, 255, 255, 0, 128, _
  255, 0, 0, 255, 128, 0, 255, 255, 0, _
  128, 255, 0, 0, 255, 0, 0, 255, 128, _
  0, 255, 255, 0, 128, 255, 0, 0, 255, _
  128, 0, 255, 255, 0, 255, 255, 0, 128
FillArrayf light_position, 1, 1, 1, 0
End Sub

Public Sub Init()
Dim i&
    gCtl.pfPixelType = PFD_TYPE_COLORINDEX
    gCtl.UseCamera = False
    Set tb = gCtl.Trackball
End Sub


Public Sub InitGL()
    ' create initial display lists */
    lists
    
    ' lighting */
    glDisable GL_LIGHTING
    
    glEnable GL_DEPTH_TEST
    glDepthFunc GL_LEQUAL
    
    glEnable GL_CULL_FACE
    
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetPosition 1, 1, 1
        .Enabled = True
    End With
    With gCtl.Lights
        '.SetAmbient 1, 1, 1
        .TwoSide = False
    End With

    gCtl.Palette.SetColor 9 + 2 * NUMCOLORS + 1, 0, 0, 0
    glClearIndex 9 + 2 * NUMCOLORS + 1
End Sub

Public Sub Draw()
Static rotate&
Static i&, spin!

    ' setup the colors */
    For i = rotate To NUMCOLORS + rotate - 1
        gCtl.Palette.SetColor 9 + i - rotate, _
             colors(3 * i + 0), colors(3 * i + 1), colors(3 * i + 2)
    Next
    
    rotate = rotate + 1
    rotate = rotate Mod NUMCOLORS
    
    
    glPushMatrix
    
    If (auto_rotate) Then
        spin = spin + 1
        glRotatef spin, 1, 1, 1
        spin = spin Mod 360
    Else
        tb.Update
    End If
    
    glCallList cube_list
    glPopMatrix

End Sub

Public Function Reshape(width&, height&) As Boolean
    glViewport 0, 0, width, height
    
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    gluPerspective 60, height / width, 1, 128
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glLightfv GL_LIGHT0, GL_POSITION, light_position(0)
    glTranslatef 0, 0, -12
    glRotatef 15, 0, 1, 0
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    ' start of view position functions */
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case vbKeyPageUp:
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii%)
Dim s$
    s = Chr$(KeyAscii)

    Select Case (s)
    Case "a":
    auto_rotate = Not auto_rotate
    gCtl.MouseRotate = Not auto_rotate
    
    Case "f":
    glPolygonMode GL_FRONT_AND_BACK, GL_FILL
    Case "w":
    glPolygonMode GL_FRONT_AND_BACK, GL_LINE
    Case "\b":
    'Init
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    '
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    '
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    '
End Sub


' functions */
Public Sub lists()
    ' cube */
    If (cube_list) Then
        glDeleteLists cube_list, 1
    End If
    ' generate a display list */
    cube_list = glGenLists(1)
    glNewList cube_list, GL_COMPILE
    glBegin GL_QUADS
    ' front */
    glIndexi 10
    glVertex3i -3, 3, 3
    glVertex3i -3, -3, 3
    glVertex3i -1, -3, 3
    glVertex3i -1, 3, 3
    
    glIndexi 11
    glVertex3i -1, 3, 3
    glVertex3i -1, -3, 3
    glVertex3i 1, -3, 3
    glVertex3i 1, 3, 3
    
    glIndexi 12
    glVertex3i 1, 3, 3
    glVertex3i 1, -3, 3
    glVertex3i 3, -3, 3
    glVertex3i 3, 3, 3
    
    ' back */
    glIndexi 19
    glVertex3i -1, 3, -3
    glVertex3i -1, -3, -3
    glVertex3i -3, -3, -3
    glVertex3i -3, 3, -3
    
    glIndexi 20
    glVertex3i 1, 3, -3
    glVertex3i 1, -3, -3
    glVertex3i -1, -3, -3
    glVertex3i -1, 3, -3
    
    glIndexi 21
    glVertex3i 3, 3, -3
    glVertex3i 3, -3, -3
    glVertex3i 1, -3, -3
    glVertex3i 1, 3, -3
    
    ' right */
    glIndexi 12
    glVertex3i 3, 3, 3
    glVertex3i 3, -3, 3
    glVertex3i 3, -3, 1
    glVertex3i 3, 3, 1
    
    glIndexi 11
    glVertex3i 3, 3, 1
    glVertex3i 3, -3, 1
    glVertex3i 3, -3, -1
    glVertex3i 3, 3, -1
    
    glIndexi 10
    glVertex3i 3, 3, -1
    glVertex3i 3, -3, -1
    glVertex3i 3, -3, -3
    glVertex3i 3, 3, -3
    
    ' left */
    glIndexi 21
    glVertex3i -3, 3, 1
    glVertex3i -3, -3, 1
    glVertex3i -3, -3, 3
    glVertex3i -3, 3, 3
    
    glIndexi 20
    glVertex3i -3, 3, -1
    glVertex3i -3, -3, -1
    glVertex3i -3, -3, 1
    glVertex3i -3, 3, 1
    
    glIndexi 19
    glVertex3i -3, 3, -3
    glVertex3i -3, -3, -3
    glVertex3i -3, -3, -1
    glVertex3i -3, 3, -1
    
    ' top */
    glIndexi 12
    glVertex3i 1, 3, 3
    glVertex3i 3, 3, 3
    glVertex3i 3, 3, 1
    glVertex3i 1, 3, 3          ' degenerate */
    
    glIndexi 11
    glVertex3i -1, 3, 3
    glVertex3i 1, 3, 3
    glVertex3i 3, 3, 1
    glVertex3i 3, 3, -1
    
    glIndexi 10
    glVertex3i -3, 3, 3
    glVertex3i -1, 3, 3
    glVertex3i 3, 3, -1
    glVertex3i 3, 3, -3
    
    glIndexi 21
    glVertex3i -3, 3, 1
    glVertex3i -3, 3, 3
    glVertex3i 3, 3, -3
    glVertex3i 1, 3, -3
    
    glIndexi 20
    glVertex3i -3, 3, -1
    glVertex3i -3, 3, 1
    glVertex3i 1, 3, -3
    glVertex3i -1, 3, -3
    
    glIndexi 19
    glVertex3i -3, 3, -3
    glVertex3i -3, 3, -1
    glVertex3i -1, 3, -3
    glVertex3i -3, 3, -3        ' degenerate */
    
    ' bottom */
    glIndexi 12
    glVertex3i 1, -3, 3         ' degenerate */
    glVertex3i 3, -3, 1
    glVertex3i 3, -3, 3
    glVertex3i 1, -3, 3
    
    glIndexi 11
    glVertex3i 3, -3, -1
    glVertex3i 3, -3, 1
    glVertex3i 1, -3, 3
    glVertex3i -1, -3, 3
    
    glIndexi 10
    glVertex3i 3, -3, -3
    glVertex3i 3, -3, -1
    glVertex3i -1, -3, 3
    glVertex3i -3, -3, 3
    
    glIndexi 21
    glVertex3i 1, -3, -3
    glVertex3i 3, -3, -3
    glVertex3i -3, -3, 3
    glVertex3i -3, -3, 1
    
    glIndexi 20
    glVertex3i -1, -3, -3
    glVertex3i 1, -3, -3
    glVertex3i -3, -3, 1
    glVertex3i -3, -3, -1
    
    glIndexi 19
    glVertex3i -3, -3, -3       ' degenerate */
    glVertex3i -1, -3, -3
    glVertex3i -3, -3, -1
    glVertex3i -3, -3, -3
    
    glEnd
    glEndList

End Sub


