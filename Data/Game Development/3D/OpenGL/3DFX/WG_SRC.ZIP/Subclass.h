
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _SUBCLASS_
#define _SUBCLASS_

#include <windows.h>

extern BOOL CWGSubclassWindow(HWND, WNDPROC *, WNDPROC, DWORD);
extern BOOL CWGUnsubclassWindowIfSubclassed(VOID);
extern BOOL CWGUnsubclassWindowBecauseDestroyed(VOID);

#endif //_SUBCLASS_

