VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'----------------------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: ported by edx - edx@hk.super.net, March 98
'HISTORY: -
'NOTES: The tess callbacks are the trickiest thing here.
'   - Press 'w' to cycle through the props in test2.
'----------------------------------------------------------------------------
Dim m_Mat As glxMaterial
Dim QuadObj&, QID&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
'/*
' *  tess.c
' *  This program demonstrates polygon tessellation.
' *  Two tesselated objects are drawn.  The first is a
' *  rectangle with a triangular hole.  The second is a
' *  smooth shaded, self-intersecting star.
' *
' *  Note the exterior rectangle is drawn with its vertices
' *  in counter-clockwise order, but its interior clockwise.
' *  Note the combineCallback is needed for the self-intersecting
' *  star.  Also note that removing the TessProperty for the
' *  star will make the interior unshaded (WINDING_ODD).
' */

Dim startList&
'/*
' *  tesswind.c
' *  This program demonstrates the winding rule polygon
' *  tessellation property.  Four tessellated objects are drawn,
' *  each with very different contours.  When the w key is pressed,
' *  the objects are drawn with a different winding rule.
' */
Dim currentWinding#  '= GLU_TESS_WINDING_ODD
Dim currentShape& ' = 0
Dim tobj 'tessobj
Dim list&
Dim rects#(0 To 35)
Dim spiral#(0 To 47)
Dim quad1#(0 To 11)
Dim quad2#(0 To 11)
Dim tri#(0 To 8)
Dim m_TestMode&

Private Sub Class_Initialize()
'
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Camera
        .FarPlane = 1000
        .NearPlane = 1
        .FieldOfView = 45
        .SetEyePos 50, 100, 400
        .SetTargetPos 50, 50, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetSpecular 0.6, 0.8, 0.8
        .SpecExp = 120
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .Axis = glxXYZ
        .Pick = True
        .SetWorldSize 500, 500, 500
        .GridStep = 50
    End With
    m_Grids = True
    '
    glDisable GL_LIGHTING
    TestMode = 1
    
End Sub

Public Sub Draw()
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    '
    Select Case m_TestMode
    Case 1
        Display1
    Case 2
        Display2
    End Select
    CheckError
End Sub

'----------------------------------------------------------------------------
'TEST 1 - tess.c
'----------------------------------------------------------------------------
Sub Display1()
   glColor3f 1, 1, 1
   glCallList startList
   glCallList startList + 1
   glFlush
End Sub

Sub Display2()
    glColor3f 0.8, 1, 1
    glPushMatrix
        'glTranslatef -50, 0, 0
        glScalef 0.2, 0.2, 0.2
        glCallList list
        glTranslatef 0, 500, 0
        glCallList list + 1
        glTranslatef 500, -500, 0
        glCallList list + 2
        glTranslatef 0, 500, 0
        glCallList list + 3
    glPopMatrix
    glFlush
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
      Case "w", "W":
        If m_TestMode = 2 Then
            If (currentWinding = GLU_TESS_WINDING_ODD) Then
               currentWinding = GLU_TESS_WINDING_NONZERO
            ElseIf (currentWinding = GLU_TESS_WINDING_NONZERO) Then
               currentWinding = GLU_TESS_WINDING_POSITIVE
            ElseIf (currentWinding = GLU_TESS_WINDING_POSITIVE) Then
               currentWinding = GLU_TESS_WINDING_NEGATIVE
            ElseIf (currentWinding = GLU_TESS_WINDING_NEGATIVE) Then
               currentWinding = GLU_TESS_WINDING_ABS_GEQ_TWO
            ElseIf (currentWinding = GLU_TESS_WINDING_ABS_GEQ_TWO) Then
               currentWinding = GLU_TESS_WINDING_ODD
            End If
            makeNewLists
            gCtl.Render
        End If
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If m_bMoving Then
        End If
        gCtl.Render
    ElseIf Button = 2 Then
        gCtl.Render
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, z#, z1#, z2#
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    z = FLOAT_MAX ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                z1 = ULong(items(ptr))
                Debug.Print " z1 = " & z1
                ptr = ptr + 1
            '3.z2
                z2 = ULong(items(ptr))
                Debug.Print " z2 = " & z2
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < z Then
                        z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub

Public Property Let TestMode(ByVal NewValue&)
    m_TestMode = NewValue&
    ClearCombineList
    If startList Then
        glDeleteLists startList, 2
    End If
    If list Then
        glDeleteLists list, 4
    End If
    Select Case m_TestMode
    Case 1 'tess.c
        Init1
    Case 2
        Init2
    End Select
    gCtl.Render
End Property

'----------------------------------------------------------------------------
Sub Init1()
Dim tobj&
Dim rct#(0 To 11) '(4)(3)
Dim tri#(0 To 8)
Dim star#(0 To 29)
    FillArrayd rct, 0, 0, 0, 100, 0, 0, 100, 100, 0, 0, 100, 0
    FillArrayd tri, 25, 25, 0, 50, 75, 0, 75, 25, 0
    startList = glGenLists(2)
    
    tobj = gluNewTess
    gluTessCallback tobj, GLU_TESS_VERTEX, AddressOf glVertex3dvCB
    gluTessCallback tobj, GLU_TESS_BEGIN, AddressOf glBeginCB
    gluTessCallback tobj, GLU_TESS_END, AddressOf glEndCB
    gluTessCallback tobj, GLU_TESS_ERROR, AddressOf glErrorCB
    
'GoTo dostar

    '  rectangle with triangular hole inside
    glNewList startList, GL_COMPILE
    glTranslatef -100, 0, 0
    glShadeModel GL_FLAT
    gluTessBeginPolygon tobj, 0&
       gluTessBeginContour tobj
          gluTessVertex tobj, rct(0), rct(0)
          gluTessVertex tobj, rct(3), rct(3)
          gluTessVertex tobj, rct(6), rct(6)
          gluTessVertex tobj, rct(9), rct(9)
       gluTessEndContour tobj
       gluTessBeginContour tobj
          gluTessVertex tobj, tri(0), tri(0)
          gluTessVertex tobj, tri(3), tri(3)
          gluTessVertex tobj, tri(6), tri(6)
       gluTessEndContour tobj
    gluTessEndPolygon tobj
    glEndList
    
    'Exit Sub
    
dostar:
    gluTessCallback tobj, GLU_TESS_VERTEX, AddressOf glColorVertex3dvCB
    gluTessCallback tobj, GLU_TESS_BEGIN, AddressOf glBeginCB
    gluTessCallback tobj, GLU_TESS_END, AddressOf glEndCB
    gluTessCallback tobj, GLU_TESS_ERROR, AddressOf glErrorCB
    gluTessCallback tobj, GLU_TESS_COMBINE, AddressOf combineCallback1
    
    FillArrayd star, 250, 50, 0, 1, 0, 1, _
                    325, 200, 0, 1, 1, 0, _
                    400, 50, 0, 0, 1, 1, _
                    250, 150, 0, 1, 0, 0, _
                    400, 150, 0, 0, 1, 0
    ' smooth shaded, self-intersecting star
    glNewList startList + 1, GL_COMPILE
    glShadeModel GL_SMOOTH
    glTranslatef -100, -50, 0
    gluTessProperty tobj, GLU_TESS_WINDING_RULE&, GLU_TESS_WINDING_POSITIVE
    gluTessBeginPolygon tobj, 0&
       gluTessBeginContour tobj
          gluTessVertex tobj, star(0), star(0)
          gluTessVertex tobj, star(6), star(6)
          gluTessVertex tobj, star(12), star(12)
          gluTessVertex tobj, star(18), star(18)
          gluTessVertex tobj, star(24), star(24)
       gluTessEndContour tobj
    gluTessEndPolygon tobj
    glEndList
    gluDeleteTess tobj
End Sub

'----------------------------------------------------------------------------
'TEST 2 - tesswind.c
'----------------------------------------------------------------------------
Sub Init2()
    currentWinding# = GLU_TESS_WINDING_ODD
    glShadeModel GL_FLAT

    tobj = gluNewTess
    gluTessCallback tobj, GLU_TESS_VERTEX, AddressOf glVertex3dvCB
    gluTessCallback tobj, GLU_TESS_BEGIN, AddressOf glBeginCB
    gluTessCallback tobj, GLU_TESS_END, AddressOf glEndCB
    gluTessCallback tobj, GLU_TESS_ERROR, AddressOf glErrorCB
    gluTessCallback tobj, GLU_TESS_COMBINE, AddressOf combineCallback2

    list = glGenLists(4)
    makeNewLists
End Sub

'/*  Make four display lists,
' *  each with a different tessellated object.
' */
Sub makeNewLists()
Dim i&
   FillArrayd rects, 50, 50, 0, 300, 50, 0, _
       300, 300, 0, 50, 300, 0, _
       100, 100, 0, 250, 100, 0, _
       250, 250, 0, 100, 250, 0, _
       150, 150, 0, 200, 150, 0, _
       200, 200, 0, 150, 200, 0
   FillArrayd spiral, 400, 250, 0, 400, 50, 0, _
       50, 50, 0, 50, 400, 0, _
       350, 400, 0, 350, 100, 0, _
       100, 100, 0, 100, 350, 0, _
       300, 350, 0, 300, 150, 0, _
       150, 150, 0, 150, 300, 0, _
       250, 300, 0, 250, 200, 0, _
       200, 200, 0, 200, 250, 0
   FillArrayd quad1, 50, 150, 0, 350, 150, 0, _
      350, 200, 0, 50, 200, 0
   FillArrayd quad2, 100, 100, 0, 300, 100, 0, _
       300, 350, 0, 100, 350, 0
   FillArrayd tri, 200, 50, 0, 250, 300, 0, _
       150, 300, 0
 
    gluTessProperty tobj, GLU_TESS_WINDING_RULE, currentWinding

    glNewList list, GL_COMPILE
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To 3
                gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 4 To 7
                gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 8 To 11
                gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glEndList

    glNewList list + 1, GL_COMPILE
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To 3
               gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 7 To 4 Step -1
               gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 11 To 8 Step -1
               gluTessVertex tobj, rects(i * 3), rects(i * 3)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glEndList

    glNewList list + 2, GL_COMPILE
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To 15
               gluTessVertex tobj, spiral(i * 3), spiral(i * 3)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glEndList

    glNewList list + 3, GL_COMPILE
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To 3
               gluTessVertex tobj, quad1(i * 3), quad1(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 0 To 3
               gluTessVertex tobj, quad2(i * 3), quad2(i * 3)
            Next
            gluTessEndContour tobj
            gluTessBeginContour tobj
            For i = 0 To 2
               gluTessVertex tobj, tri(i * 3), tri(i * 3)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glEndList
End Sub


