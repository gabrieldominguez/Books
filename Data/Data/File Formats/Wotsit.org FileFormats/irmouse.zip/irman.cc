#include "irman.h"
//#include <sys/time.h>
//#include <termios.h>
#include <unistd.h>
//#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int IRMouse::checkmouse() {
  int fbr;
  int s;
  unsigned char ch;

  if (fdev<0) return fdev;
  fbr=read(fdev,&ch,sizeof(ch));
  if (fbr<=0) return 0;
  if (ch<=0x3f) { // Normal button code
    switch (finstate) {
      case 0:   // normal waiting for something
              if ((fcodecount[ch]++)>MINNEED) {
                bzero(fcodecount,sizeof(fcodecount));
                frepeatcount=0;
                finstate=1;
                frepeatcode=ch;
                Event(ch);
              };
              break;
      case 1: // waiting for repeatcount repeats of char before repeating
              if (ch==frepeatcode) {
                if (frepeatcount++>=REPEATCOUNT) finstate=2;
              } else {
                finstate=0;
              };
              break;
      case 2: // repeat incoming chars
              if (ch==frepeatcode) {
                Event(ch);
              } else {
                finstate=0;
              };
              break;
      default: finstate=0;
               break;
    };
    return frepeatcode;
  }; // button codes
  if ((ch>=0x40)&&(ch<=0x6f)) { // This is a movement, ButtonUp or ButtonDown code
    /* handle codes and mousepad */
    s=(ch>>4)-3;
    switch (ch&0xf) {
      case 0x0: position.y-=4*s; position.x+=0*s; evMove(position.x,position.y); break;
      case 0x1: position.y-=3*s; position.x+=1*s; evMove(position.x,position.y); break;
      case 0x2: position.y-=2*s; position.x+=2*s; evMove(position.x,position.y); break;
      case 0x3: position.y-=1*s; position.x+=3*s; evMove(position.x,position.y); break;
      case 0x4: position.y+=0*s; position.x+=4*s; evMove(position.x,position.y); break;
      case 0x5: position.y+=1*s; position.x+=3*s; evMove(position.x,position.y); break;
      case 0x6: position.y+=2*s; position.x+=2*s; evMove(position.x,position.y); break;
      case 0x7: position.y+=3*s; position.x+=1*s; evMove(position.x,position.y); break;
      case 0x8: position.y+=4*s; position.x+=0*s; evMove(position.x,position.y); break;
      case 0x9: position.y+=3*s; position.x-=1*s; evMove(position.x,position.y); break;
      case 0xa: position.y+=2*s; position.x-=2*s; evMove(position.x,position.y); break;
      case 0xb: position.y+=1*s; position.x-=3*s; evMove(position.x,position.y); break;
      case 0xc: position.y+=0*s; position.x-=4*s; evMove(position.x,position.y); break;
      case 0xd: position.y-=1*s; position.x-=3*s; evMove(position.x,position.y); break;
      case 0xe: position.y-=2*s; position.x-=2*s; evMove(position.x,position.y); break;
      case 0xf: position.y-=3*s; position.x-=1*s; evMove(position.x,position.y); break;
    };
    return 0;
  }; // mouse movement code
  if (ch==IR_BUTTONDOWN) {  // Button Down
    bzero(fcodecount,sizeof(fcodecount));
    finstate=0;
    return 0;
  }; // button down code
  if (ch==IR_BUTTONUP) {  // Button up
    bzero(fcodecount,sizeof(fcodecount));
    finstate=0;
    return 0;
  };  // button up code
  return 0; 
};

void IRMouse::Event(int ev) {
  switch (ev) {
    case 0x01 : evHelp(); break;
    case 0x02 : evStart(); break;
    case 0x03 : evPhone(); break;
    case 0x04 : evTV(); break;
    case 0x05 : evGde(); break;
    case 0x06 : evCD(); break;
    case 0x07 : evMsg(); break;
    case 0x08 : evSelect(); break;
    case 0x0a : evChannelUp();  break;
    case 0x09 : evVolumeUp(); break;
    case 0x0b : fmuted=!fmuted; evMute(fmuted); break;
    case 0x0c : evVolumeDown(); break;
    case 0x0d : evChannelDown(); break;
    case 0x0e : evSkipPrev(); break;
    case 0x0f : evPlay(); break;
    case 0x10 : evSkipNext(); break;
    case 0x11 : evMenu(); break;
    case 0x12 : evStop(); break;
    case 0x13 : evPause(); break;
    case 0x14 : evKeypad('3'); break;
    case 0x15 : evKeypad('1'); break;
    case 0x16 : evKeypad('2'); break;
    case 0x17 : evKeypad('6'); break;
    case 0x18 : evKeypad('4'); break;
    case 0x19 : evKeypad('5'); break;
    case 0x1a : evKeypad('9'); break;
    case 0x1b : evKeypad('8'); break;
    case 0x1c : evKeypad('7'); break;
    case 0x1d : evKeypad('0'); break;
    case 0x1e : evKeypad('#'); break;
    case 0x1f : evKeypad('*'); break;
    case 0x23 : evTerminate(); break;
    case 0x38 : evClick(MB_NONE); break;
    case 0x39 : evClick(MB_LEFT); break;
    case 0x3a : evClick(MB_RIGHT); break;
    case 0x3b : evClick(MB_LEFT|MB_RIGHT); break;
    default: break;
  };
};

IRMouse::IRMouse(char *devname="/dev/irmouse") {
  struct termios info,info2;

// init ALL variables!
  fdev=-1;
  fvolume=0;
  fvolume_limit.min=0;
  fvolume_limit.max=99;
  fchannel=0;
  fchannel_limit.min=0;
  fchannel_limit.max=99;
  position.x=0;
  fx_limit.min=0;
  fx_limit.max=1024;
  position.y=0;
  fy_limit.min=0;
  fy_limit.max=1024;
  frepeatcode='\0';
  finstate=0;
  fmuted=0;
  bzero(fcodecount,sizeof(fcodecount));
  frepeatcount=0;
  

  if ((fdev=open(devname,O_RDWR))<0) return;
  /* set speed */
  tcgetattr(fdev,&info);
  cfsetispeed(&info,BAUD);
  cfsetospeed(&info,BAUD);
  cfmakeraw(&info);   /* make it raw */
  tcsetattr(fdev,TCSANOW,&info);
};

IRMouse::~IRMouse() {
  if (fdev>=0) close(fdev);
};

void IRMouse::evChannelUp() {
  int dir=1;
  if ((fchannel+dir>=fchannel_limit.min)&&(fchannel+dir<=fchannel_limit.max)) {
    fchannel+=dir;
  };
    evChannel(fchannel);
};

void IRMouse::evChannelDown() {
  int dir=-1;
  if ((fchannel+dir>=fchannel_limit.min)&&(fchannel+dir<=fchannel_limit.max)) {
    fchannel+=dir;
  };
    evChannel(fchannel);
};

void IRMouse::evVolumeUp(){
  int dir=1;
  if ((fvolume+dir>=fvolume_limit.min)&&(fvolume+dir<=fvolume_limit.max)) {
    fvolume+=dir;
  };
    evVolume(fvolume);
};

void IRMouse::evVolumeDown(){
  int dir=-1;
  if ((fvolume+dir>=fvolume_limit.min)&&(fvolume+dir<=fvolume_limit.max)) {
    fvolume+=dir;
  };
    evVolume(fvolume);
};

int IRMouse::setvolume(long newvolume) {
  if ((newvolume>=fvolume_limit.min)&&(newvolume<fvolume_limit.max)) {
    fvolume=newvolume;
    return 0;
  };
  return -1;
};

int IRMouse::setmaxvolume(long maxvolume) {
  if (maxvolume>=fvolume_limit.min) {
    fvolume_limit.max=maxvolume;
    if (maxvolume<fvolume) fvolume=maxvolume;
    return 0;
  };
  return -1;
};

int IRMouse::setminvolume(long minvolume) {
  if (minvolume<=fvolume_limit.max) {
    fvolume_limit.min=minvolume;
    if (fvolume<minvolume) fvolume=minvolume;
    return 0;
  };
  return -1;
};
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

char *codetostr(unsigned char ch) {
  char buffer[1024];

  switch (ch) {
    case 0x01 : return "Help";
    case 0x02 : return "Start";
    case 0x03 : return "Phone";
    case 0x04 : return "TV";
    case 0x05 : return "Gde";
    case 0x06 : return "CD";
    case 0x07 : return "Msg";
    case 0x08 : return "Select";
    case 0x0a : return "Channel +";
    case 0x09 : return "Volume +";
    case 0x0b : return "Mute";
    case 0x0c : return "Volume -";
    case 0x0d : return "Channel -";
    case 0x0e : return "Skip Prev";
    case 0x0f : return "Play";
    case 0x10 : return "Skip Next";
    case 0x11 : return "Menu";
    case 0x12 : return "Stop";
    case 0x13 : return "Pause";
    case 0x14 : return "Number 3";
    case 0x15 : return "Number 1";
    case 0x16 : return "Number 2";
    case 0x17 : return "Number 6";
    case 0x18 : return "Number 4";
    case 0x19 : return "Number 5";
    case 0x1a : return "Number 9";
    case 0x1b : return "Number 8";
    case 0x1c : return "Number 7";
    case 0x1d : return "Number 0";
    case 0x1e : return "Symbol #";
    case 0x1f : return "Symbol *";
    case 0x23 : return "Terminate";
    case 0x38 : return "Mouse up";
    case 0x39 : return "Left Mouse Down";
    case 0x3a : return "Right Mouse Down";
    case 0x3b : return "Both Mouse Down";
  };
  sprintf(buffer,"Unknown '0x%x'",ch);
  return buffer;
};
