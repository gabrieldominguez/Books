Attribute VB_Name = "mConstants"
Option Explicit

'public const INREAL float
Public gCtl As glxCtl
Public CN As CNurb
Public ExpectedError& ' As GLenum
Public Const S_NUMPOINTS = 13
Public Const S_ORDER = 3
Public Const S_NUMKNOTS = (S_NUMPOINTS + S_ORDER)
Public Const T_NUMPOINTS = 3
Public Const T_ORDER = 3
Public Const T_NUMKNOTS = (T_NUMPOINTS + T_ORDER)
Public Const SQRT_TWO = 1.4142135623731
Public rotX&, rotY&
Public Const GLU_ERROR = GLU_TESS_ERROR

Type Point4f
    pts(0 To 3) As Single
End Type

Public Sub ErrorCallback(which&) ' As GLenum)
    If which <> ExpectedError Then
        Debug.Print "Unexpected error occured " & which
        Debug.Print gluErrorString(which)
        Debug.Assert 0
    End If
End Sub

'Dim doubleBuffer&
'static void Args(int argc, char **argv)
'{
'    GLint i;
'
'    doubleBuffer = GL_FALSE;
'
'    for (i = 1; i < argc; i++) {
'    if (strcmp(argv[i], "-sb") == 0) {
'        doubleBuffer = GL_FALSE;
'    } else if (strcmp(argv[i], "-db") == 0) {
'        doubleBuffer = GL_TRUE;
'    }
'    }
'}

'int main(int argc, char **argv)
'{
'    GLenum type;
'
'    Args(argc, argv);
'
'    type = GLUT_RGB;
'    type |= (doubleBuffer) ? GLUT_DOUBLE : GLUT_SINGLE;
'    glutInitDisplayMode(type);
'    glutInitWindowSize(300, 300);
'    glutCreateWindow("NURBS Test");
'
'    Init();
'
'    glutReshapeFunc(Reshape);
'    glutKeyboardFunc(Key);
'    glutSpecialFunc(SpecialKey);
'    glutDisplayFunc(Draw);
'    glutMainLoop();
'}


Public Sub FillPoint4f(p As Point4f, a!, b!, c!, d!)
p.pts(0) = a
p.pts(1) = b
p.pts(2) = c
p.pts(3) = d
End Sub
