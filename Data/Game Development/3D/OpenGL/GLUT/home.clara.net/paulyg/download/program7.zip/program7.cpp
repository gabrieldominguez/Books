/*
                Program 7.

      A *VERY* simple example of multitexturing without the ARB extension - just
      like the good old days.

      Important!
      Be sure to 'glEnableClientState' your vertex arrays AFTER glut has created
      your OpenGL context (it does this with glutInitDisplayMode).  Just call
      your Init function after this and you'll be fine.

*/

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include "tgaload.h"

/*      Some macros for naming the textures */
#define         MAX_TEXTURES    2

#define         WOOD_IMAGE      0
#define         LIGHTMAP        1



PFNGLLOCKARRAYSEXTPROC      glLockArraysEXT   = NULL;
PFNGLUNLOCKARRAYSEXTPROC    glUnlockArraysEXT = NULL;

bool supportCVA_EXT = true;

float angle;

/* Vertex Array object description:
   These arrays contain the vertex data, indices for the vertices, and colours
   for each vertex.  */

GLfloat vertices[] =  { -1.0,  1.0,  0.0,
                         1.0,  1.0,  0.0,
                         1.0, -1.0,  0.0,
                        -1.0, -1.0,  0.0 };

GLfloat tex_coords[] = { 0.0, 1.0,
                         1.0, 1.0,
                         1.0, 0.0,
                         0.0, 0.0 };

GLuint  indices[] = { 0, 1, 2, 3 };

/*  Variables to hold our images and texture IDs   */
GLuint  tex_id[MAX_TEXTURES];


/* Get Compiled Vertex Array Extension functions.
 * We don't check to see if they are supported - so this WILL cause a crash if
 * if your OpenGL implementation doesn't support it.
 */
void get_CVA_ext ( void )
{
   glLockArraysEXT   =  ( PFNGLLOCKARRAYSEXTPROC )
    wglGetProcAddress ( "glLockArraysEXT" );
   glUnlockArraysEXT =  ( PFNGLUNLOCKARRAYSEXTPROC )
    wglGetProcAddress ( "glUnlockArraysEXT" );

   if (( glLockArraysEXT == NULL ) || ( glUnlockArraysEXT == NULL ))
   {
      printf ("Error: get_CVA_ext ( );   -   Could not get Compiled Vertex Array Extension\n");
      supportCVA_EXT = false;
   }
}

/*      Initialise:
 *      Enable the OpenGL arrays that contain our object data.
 */
void init( void )
{
   get_CVA_ext ( );

   glEnable      ( GL_TEXTURE_2D );
   glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
   glGenTextures ( 2, tex_id );

   tex_id[WOOD_IMAGE] = tgaLoadAndBind  ( "board.tga", TGA_FREE );
   tex_id[LIGHTMAP]   = tgaLoadAndBind  ( "lightmap.tga", TGA_FREE | TGA_LUMINANCE );

   glEnable ( GL_DEPTH_TEST );
   glEnableClientState ( GL_VERTEX_ARRAY );
   glEnableClientState ( GL_TEXTURE_COORD_ARRAY );
   glClearColor ( 0.0, 0.0, 0.0, 0.0 );
}


/* Set Object
 * Set the current vertex and colour arrays to the ones we have specified above,
 * (obviously, if you had more than one object could use different array names
 * here).
 * Then call glLockArrays to keep this data on the graphics card.
 */
void set_object ( void )
{
   if ( supportCVA_EXT )
      glUnlockArraysEXT ( );

   glVertexPointer   ( 3, GL_FLOAT, 0, &vertices );
   glTexCoordPointer ( 2, GL_FLOAT, 0, &tex_coords );

   /* Compile current geometry so shared or reused vertices don't need
      re-transforming.  Also means no re-transforms are needed if we draw
      the object more than once (IE multitexture it) */
   if ( supportCVA_EXT )
      glLockArraysEXT ( 0, ( GLsizei ) 4 );
}

void draw_object ( void )
{
   /* Draw the object     */
   glDrawElements ( GL_QUADS, 4, GL_UNSIGNED_INT, indices );
}


/*      Standard display callback
 */
void display ( void )
{
   glClear    ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   set_object ( );

   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, -3.0 );
   glRotatef    ( angle, 1.0, 1.0, 0.0 );

   glEnable      ( GL_DEPTH_TEST );
   glBindTexture ( GL_TEXTURE_2D, tex_id[WOOD_IMAGE] );
   draw_object   ( );

   glDisable ( GL_DEPTH_TEST );
   glEnable  ( GL_BLEND );

   /* Blend the two passes together                */
   glBlendFunc   ( GL_DST_COLOR, GL_SRC_COLOR );
   glBindTexture ( GL_TEXTURE_2D, tex_id[LIGHTMAP] );
   draw_object   ( );
   glDisable     ( GL_BLEND );

   glPopMatrix     ( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{
   glViewport   ( 0, 0, ( GLint ) w, ( GLint ) h );
   glMatrixMode ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, ( GLdouble ) w, 1.0, 20.0 );
   else
      gluPerspective ( 45, ( GLdouble ) w / ( GLdouble ) h ,1.0, 20.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );
}

void idle_func ( void )
{
   angle = angle + 0.1;
   if ( angle == 360 )
      angle = 0;
   glutPostRedisplay ( );
}

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
int main ( int argc, char** argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( argv[0] );

   init ( );

   glutReshapeFunc  ( reshape   );
   glutDisplayFunc  ( display   );
   glutIdleFunc     ( idle_func );
   glutMainLoop ( );

   return 0;
}
