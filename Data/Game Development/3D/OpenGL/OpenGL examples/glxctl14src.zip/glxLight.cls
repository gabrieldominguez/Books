VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxLight"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: the main purpose of this class is so you don't have have to fill
'   - numerous arrays to pass to GL
'   - do not try to create lights! These objects are cheap are store little
'   - data, they are mainly functional
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Private m_Index As glLightConstants
Public Enum glxLightModeConstants
    lmPoint = 1
    lmDirectional = 2
    lmSpot = 3
End Enum
'all values are read and written directly to uc
'except the following:
Private m_position!(0 To 3)
Private m_Mode As Long


'---------------------------------------------------------
'SETUP
'---------------------------------------------------------

Private Sub Class_Initialize()
'init to -1 to indicate that it's not yet assigned
m_Index = -1
End Sub

'---------------------------------------------------------
'Returns/sets the GL_LIGHTi this object represents
'this is called by the glxLights collection and should not be touched!
'---------------------------------------------------------
Friend Property Let Index(ByVal nLight As glLightConstants)
    If m_Index <> -1 Then
        'todo
        Debug.Assert 0
        'Err.Raise errRedefinedLight, "glxLight_Index", "Cannot reassign lights in the Lights collection"
        Exit Property
    End If
    m_Index = nLight
End Property

Friend Property Get Index() As glLightConstants
    Index = m_Index
End Property

'---------------------------------------------------------
'PUBLIC PROPERTIES
'---------------------------------------------------------
'
'---------------------------------------------------------
'toggles the light on and off
Public Property Let Enabled(ByVal bEnabled As Boolean)
If bEnabled Then
    glEnable m_Index
Else
    glDisable m_Index
End If
'UC.Render
End Property

Public Property Get Enabled() As Boolean
Dim r As Byte
glGetBooleanv m_Index, r
If r Then
    Enabled = True
End If
End Property

'---------------------------------------------------------
'Note: Mode and position are linked, so they are stored and
'not queried from gl
'---------------------------------------------------------
'Returns/sets the type of light (point, directional, spot)
Public Property Let mode(ByVal NewMode As glxLightModeConstants)
    m_Mode = NewMode
    'the 4th element in the position array controls whether a light
    'is a point or directional source
    Select Case m_Mode
    Case lmPoint
        m_position(3) = 1
    Case lmDirectional
        m_position(3) = 0
    Case lmSpot
        m_position(3) = 1
    End Select
    glLightfv m_Index, lpmPosition, m_position(0)
End Property

Public Property Get mode() As glxLightModeConstants
    mode = m_Mode
End Property

'---------------------------------------------------------
'Returns/sets the light's location. If the mode is set to 0,
'these values define a vector which sets the light's direction
Public Sub SetPosition(ByVal x!, ByVal y!, ByVal z!)
    m_position(0) = x
    m_position(1) = y
    m_position(2) = z
    glLightfv m_Index, lpmPosition, m_position(0)
End Sub

Public Sub GetPosition(x!, y!, z!)
    x = m_position(0)
    y = m_position(1)
    z = m_position(2)
End Sub

'---------------------------------------------------------
'If the light is positional, rather than directional, its intensity is attenuated by
' the reciprocal of the sum of: the constant factor, the linear factor multiplied by
' the distance between the light and the vertex being lighted, and the quadratic
' factor multiplied by the square of the same distance. The default attenuation factors
' are (1,0,0), resulting in no attenuation.
Public Sub SetCLQAttenuation(ByVal c!, ByVal l!, ByVal q!)
    ConstantAttenuation = c
    LinearAttenuation = l
    QuadraticAttenuation = q
End Sub

Public Sub GetCLQAttenuation(c!, l!, q!)
    c = ConstantAttenuation
    l = LinearAttenuation
    q = QuadraticAttenuation
End Sub

'---------------------------------------------------------
'Returns/sets a floating-point value representing the constant (not distance-related) attenuation of the light.
Public Property Let ConstantAttenuation(ByVal NewValue!)
    glLightf m_Index, lpmConstantAttenuation, NewValue
End Property

Public Property Get ConstantAttenuation() As Single
Dim f!
    glGetLightfv m_Index, lpmConstantAttenuation, f
    ConstantAttenuation = f
End Property

'---------------------------------------------------------
'Returns/sets a floating-point value representing the linear attenuation of the light.
Public Property Let LinearAttenuation(ByVal NewValue!)
    glLightf m_Index, lpmLinearAttenuation, NewValue
End Property

Public Property Get LinearAttenuation() As Single
Dim f!
    glGetLightfv m_Index, lpmLinearAttenuation, f
    LinearAttenuation = f
End Property

'---------------------------------------------------------
'Returns/sets a floating-point value representing the quadratic attenuation of the light
Public Property Let QuadraticAttenuation(ByVal NewValue!)
    glLightf m_Index, lpmQuadraticAttenuation, NewValue
End Property

Public Property Get QuadraticAttenuation() As Single
Dim f!
    glGetLightfv m_Index, lpmQuadraticAttenuation, f
    QuadraticAttenuation = f
End Property

'---------------------------------------------------------
'specifies the intensity distribution of the light. Effective light intensity is
' attenuated by the cosine of the angle between the direction of the light and
' the direction from the light to the vertex being lighted, raised to the power
' of the spot exponent. Only values in the range [0,128] are accepted
Public Property Let SpotExponent(ByVal NewValue As Single)
    glLightf m_Index, lpmSpotExponent, NewValue
End Property

Public Property Get SpotExponent() As Single
Dim f!
    glGetLightfv m_Index, lpmSpotExponent, f
    SpotExponent = f
End Property

'---------------------------------------------------------
' Specifies the maximum spread angle of a light source. Only values in the range [0,90],
' and the special value 180, are accepted.
Public Property Let SpotCutOff(ByVal NewValue As Single)
    glLightf m_Index, lpmSpotCutoff, NewValue
End Property

Public Property Get SpotCutOff() As Single
Dim f!
    glGetLightfv m_Index, lpmSpotCutoff, f
    SpotCutOff = f
End Property

'---------------------------------------------------------
' Three floating-point values that specify the
' direction of the light in homogeneous object coordinates.
' The default direction is (0,0,-1).
Public Sub SetSpotDirection(ByVal x!, ByVal y!, ByVal z!)
Dim spot!(0 To 2)
    spot(0) = x
    spot(1) = y
    spot(2) = z
    glLightfv m_Index, lpmSpotDirection, spot(0)
End Sub

Public Sub GetSpotDirection(x!, y!, z!)
Dim f!(0 To 2)
    glGetLightfv m_Index, lpmSpotDirection, f(0)
    x = f(0)
    y = f(1)
    z = f(2)
End Sub

'---------------------------------------------------------
'COLOR PROPERTIES
'---------------------------------------------------------
'
'Specifies the specular RGBA intensity of the light. The default specular intensity
' is (0.0, 0.0, 0.0, 1.0) for all lights other than light zero. The default specular
' intensity of light zero is (1.0, 1.0, 1.0, 1.0).
Public Sub SetSpecular255(ByVal Red&, ByVal Green&, ByVal Blue&, Optional ByVal alpha& = 255)
    SetColor255 Red, Green, Blue, alpha, lpmSpecular
End Sub

Public Sub SetSpecular(ByVal Red!, ByVal Green!, ByVal Blue!, Optional ByVal alpha! = 1)
    SetColor Red, Green, Blue, alpha, lpmSpecular
End Sub

Public Sub GetSpecular(r!, g!, b!, a!)
    GetColor lpmSpecular, r, g, b, a
End Sub

'---------------------------------------------------------
'Specifies the diffuse RGBA intensity of the light. The default diffuse intensity is
' (0.0, 0.0, 0.0, 1.0) for all lights other than light zero. The default diffuse
' intensity of light zero is (1.0, 1.0, 1.0, 1.0).
Public Sub SetDiffuse255(ByVal Red&, ByVal Green&, ByVal Blue&, Optional ByVal alpha& = 255)
    SetColor255 Red, Green, Blue, alpha, lpmDiffuse
End Sub

Public Sub SetDiffuse(ByVal Red!, ByVal Green!, ByVal Blue!, Optional ByVal alpha! = 1)
    SetColor Red, Green, Blue, alpha, lpmDiffuse
End Sub

Public Sub GetDiffuse(r!, g!, b!, a!)
    GetColor lpmDiffuse, r, g, b, a
End Sub

'---------------------------------------------------------
'Specifies the ambient RGBA intensity of the light. The default ambient light intensity is (0.0, 0.0, 0.0, 1.0).
Public Sub SetAmbient255(ByVal Red&, ByVal Green&, ByVal Blue&, Optional ByVal alpha& = 1)
    SetColor255 Red, Green, Blue, alpha, lpmAmbient
End Sub

Public Sub SetAmbient(ByVal Red!, ByVal Green!, ByVal Blue!, Optional ByVal alpha! = 1)
    SetColor Red, Green, Blue, alpha, lpmAmbient
End Sub

Public Sub GetAmbient(r!, g!, b!, a!)
    GetColor lpmAmbient, r, g, b, a
End Sub

'---------------------------------------------------------
'utility routines
Private Sub SetColor(r!, g!, b!, a!, code As glLightParameterConstants)
Dim clr!(0 To 3)
    clr(0) = r
    clr(1) = g
    clr(2) = b
    clr(3) = a
    glLightfv m_Index, code, clr(0)
End Sub

Private Sub SetColor255(r&, g&, b&, a&, code As glLightParameterConstants)
Dim clr!(0 To 3)
    clr(0) = r / 255
    clr(1) = g / 255
    clr(2) = b / 255
    clr(3) = a / 255
    glLightfv m_Index, code, clr(0)
End Sub

Private Function GetColor(code As glLightParameterConstants, r!, g!, b!, a!) As Boolean
Dim f!(0 To 3)
    glGetLightfv m_Index, code, f(0)
    r = f(0)
    g = f(1)
    b = f(2)
    a = f(3)
End Function


