#include <stdio.h>
#include <ctype.h>

#include "globals.h"
#include "wpfonts.h"
#include "device.h"

/************************************************************
 * return the width of a char drawn with wp_draw_char
 */
int
wp_char_width(font_struct* fs, int character)
{
  int index;
  int width;
  if (fs->desc.type!=WP_OUTLINE) return 0;
  index=fs->table[character].offset;
  do {
  } while(fs->data[index++]==255);
  width=(int)*((short*)&fs->data[index]);
  return width;
}

/************************************************************
 * draw a character
 * return the width
 */
int
wp_draw_char(font_struct* fs, device* dev, int x0, int y0, int character)
{
  int index; /* index in description */
  int last; /* end of description */
  int num; /* number of strokes */
  int width; /* width of character */
  int x,y; /* cursor */
  int dx,dy; /* for strokes */
  int dx1,dx2,dx3; /* for splines */
  int dy1,dy2,dy3;
  char* charp;
  short* shortp;

  if (fs->desc.type!=WP_OUTLINE) return 0;
  /* start of character data */
  index=fs->table[character].offset;

  /* determine length */
  last=index;
  do {
    last+=fs->data[index];
  } while(fs->data[index++]==255);

  /* determine width */
  width=(int)*((short*)&(fs->data[index]));
  index+=2;

  x=x0;
  y=y0;

  /* process character data */
  do {
    switch(fs->data[index])
    {
    case 0x77: /* move short */
    case 0x78:
      shortp=(short*)&(fs->data[index+1]);
      index+=5;
      x=x0+(int)(shortp[0]);
      y=y0+(int)(shortp[1]);
      break;
    case 0x6: /* byte strokes */
      num=(int)fs->data[index+1];
      charp=(char*)&(fs->data[index+2]);
      index+=2+2*num;
      while(num-->0)
      {
	dx=(int)charp[0];
	dy=(int)charp[1];
	charp+=2;
	dev->line(dev,x,y,x+dx,y+dy);
	x+=dx;
	y+=dy;
      }
      break;
    case 0x7: /* short strokes */
      num=(int)fs->data[index+1];
      shortp=(short*)&(fs->data[index+2]);
      index+=2+4*num;
      while(num-->0)
      {
	dx=(int)(shortp[0]);
	dy=(int)(shortp[1]);
	shortp+=2;
	dev->line(dev,x,y,x+dx,y+dy);
	x+=dx;
	y+=dy;
      }
      break;
    case 0xa: /* byte spline */
      charp=(char*)&fs->data[index+1];
      index+=7;
      dx1=(int)charp[0];
      dy1=(int)charp[1];
      dx2=(int)charp[2];
      dy2=(int)charp[3];
      dx3=(int)charp[4];
      dy3=(int)charp[5];
      dev->spline(dev,
		  x,y,
		  x+dx1,y+dy1,
		  x+dx1+dx2,y+dy1+dy2,
		  x+dx1+dx2+dx3,y+dy1+dy2+dy3);
      x+=dx1+dx2+dx3;
      y+=dy1+dy2+dy3;
      break;
    case 0xb: /* short spline */
      shortp=(short*)&fs->data[index+1];
      index+=13;
      dx1=(int)shortp[0];
      dy1=(int)shortp[1];
      dx2=(int)shortp[2];
      dy2=(int)shortp[3];
      dx3=(int)shortp[4];
      dy3=(int)shortp[5];
      dev->spline(dev,
		  x,y,
		  x+dx1,y+dy1,
		  x+dx1+dx2,y+dy1+dy2,
		  x+dx1+dx2+dx3,y+dy1+dy2+dy3);
      x+=dx1+dx2+dx3;
      y+=dy1+dy2+dy3;
      break;
    case 0x3a: 
    case 0x54:
    case 0x58:
      break; /* no idea about these */
    default: 
      printf("draw_outline: unknown token %02x\n",
	     (int)fs->data[index]);
      index++;
      break;
    }
  } while (index<last);
  return width;
}

/************************************************************
 * draw a string
 * call wp_draw_char for each char 
 */
int
wp_draw_string(font_struct* fs, device* dev, int x, int y, char* str)
{
  int xx=0;
  while(*str!='\0')
  {
    if (*str!=' ' && isprint(*str))
    {
      xx+=wp_draw_char(fs,dev,xx,y,*str);
    } else
    {
      xx+=fs->nspace;
    }
    str++;
  }
  return xx-x;
}
