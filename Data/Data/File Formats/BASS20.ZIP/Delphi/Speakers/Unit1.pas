unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Bass;

type
  TForm1 = class(TForm)
    GroupBox1: TGroupBox;
    Button1: TButton;
    GroupBox2: TGroupBox;
    Button2: TButton;
    GroupBox3: TGroupBox;
    Button3: TButton;
    GroupBox4: TGroupBox;
    Button4: TButton;
    OpenDialog1: TOpenDialog;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

  flags: array[0..3] of DWORD = (BASS_SPEAKER_FRONT, BASS_SPEAKER_REAR, BASS_SPEAKER_CENLFE, BASS_SPEAKER_REAR2);
  chan: array[0..3] of HSTREAM;

implementation

{$R *.dfm}

procedure TForm1.FormCreate(Sender: TObject);
var
  i: BASS_INFO;
begin
  // Check that BASS 2.0 was loaded
  if (BASS_GetVersion <> DWORD(MAKELONG(2,0))) then
  begin
    MessageBox(0, 'BASS version 2.0 was not loaded', 'Incorrect BASS.DLL', 0);
    Halt;
  end;

  // initialize BASS - default device
  if (not BASS_Init(1, 44100, 0, Handle, nil)) then
  begin
    MessageBox(0, 'Can''t initialize device', 'Error', 0);
    Halt;
  end;

  // check how many speakers the device supports
  i.size := SizeOf(i);
  BASS_GetInfo(i);
  if (i.speakers < 4) then // no extra speakers detected, enable them anyway?
  begin
    if (MessageBox(0, 'Do you wish to enable "speaker assignment" anyway?', 'No extra speakers detected', MB_ICONQUESTION or MB_YESNO) = IDYES) then
    begin
      // reinitialize BASS - forcing speaker assignment
      BASS_Free;
      if (not BASS_Init(1, 44100, BASS_DEVICE_SPEAKERS, Handle, nil)) then
      begin
        MessageBox(0, 'Can''t initialize device', 'Error', 0);
        Halt;
      end;
      BASS_GetInfo(i); // get info again
    end;
  end;

  if (i.speakers < 8) then
    Button4.Enabled := False;

  if (i.speakers < 6) then
    Button3.Enabled := False;

  if (i.speakers < 4) then
  begin
    Button2.Enabled := False;
    // no multi-speaker support, so remove speaker flag for normal stereo output
    flags[0] := 0;
  end;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  BASS_Free;
end;

procedure TForm1.Button1Click(Sender: TObject);
var
  speaker: Integer;
begin
  speaker := TButton(Sender).Tag;
  if (not OpenDialog1.Execute) then
    Exit;

  BASS_StreamFree(chan[speaker]); // free old stream before opening new
  chan[speaker] := BASS_StreamCreateFile(False, PChar(OpenDialog1.FileName), 0, 0, flags[speaker]);
  if (chan[speaker] = 0) then
  begin
    TButton(Sender).Caption := 'click here to open a file...';
    MessageBox(0, 'Can''t play the file', 'Error', 0);
    Exit;
  end;

  TButton(Sender).Caption := OpenDialog1.FileName;
  BASS_StreamPlay(chan[speaker], False, BASS_SAMPLE_LOOP);
end;

end.
