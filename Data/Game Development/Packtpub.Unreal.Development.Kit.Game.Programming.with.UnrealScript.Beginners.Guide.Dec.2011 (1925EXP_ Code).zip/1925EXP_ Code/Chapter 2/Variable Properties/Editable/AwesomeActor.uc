class AwesomeActor extends Actor
    placeable;

var() int MyEditableInt;
var(Physics) int MyEditableInt2;

function PostBeginPlay()
{
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
