
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _PCOPY_
#define _PCOPY_

#include <windows.h>

extern VOID FPUPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG);
extern VOID MMXPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG);

#endif //_PCOPY_
