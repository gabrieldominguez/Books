Attribute VB_Name = "mSpirals"
Option Explicit

Public Sub InitSpirals()

End Sub

Public Sub DrawSpirals()

End Sub



