class AwesomeActor extends Actor
    placeable;

var int Int1;

function PostBeginPlay()
{
    While(Int1 < 5)
    {
        Int1++;

        if(Int1 == 3)
            continue;

        `log("This will not log if Int1 is 3");
    }
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
