VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3DListEntries"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'local variable to hold collection
Private mCol As Collection


Public Function Add(le As C3DListEntry) As C3DListEntry
Dim sKey$
    'presumes that only errors are attempts to add
    'an existing entry
    On Error Resume Next
    sKey = Asc(le.glyph)
    'set the properties passed into the method
    mCol.Add le, sKey
    'return the object created
    If Err = 0 Then
    Set Add = le
    End If
End Function

Public Property Get Item(Key$) As C3DListEntry
Attribute Item.VB_UserMemId = 0
Attribute Item.VB_MemberFlags = "200"
Dim le As C3DListEntry, i&
    If mCol.count Then
        For i = 1 To mCol.count
            Set le = mCol(i)
            If Not le Is Nothing Then
                If le.glyph = Key Then
                    Set Item = le
                    Exit Property
                End If
            End If
        Next
    End If
End Property

Public Property Get count() As Long
    count = mCol.count
End Property

Public Sub Remove(vntIndexKey As Variant)
    mCol.Remove vntIndexKey
End Sub

Public Property Get NewEnum() As IUnknown
    Set NewEnum = mCol.[_NewEnum]
End Property

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub


Public Sub Clear()
Dim i&
    For i = 1 To mCol.count
        Remove 1
    Next
End Sub

