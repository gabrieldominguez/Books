/*//////////////////////////////////////////////////////////////////////////////
//
//  A awfully simple minded and horrible object loader.
//
//  Notice how I've thrown good software engineering practices out the window
//  for the sake of 'clarity'?  There is minimal pointer passing in this program
//  usually we'd divide everything up into functions and pass pointers to the
//  arrays.  Not here. ;)  By plopping (and I mean plopping in every sense of
//  the word) everything into one big function, it should make it clearer for
//  people who are inexperienced with pointers in C/C++.  Ugh, I've been at this
//  a while now and I still have trouble sometimes :(
//
//////////////////////////////////////////////////////////////////////////////*/


#include <windows.h>
#include <stdio.h>
#include <GL/glut.h>

#include "meshload.h"

// Declare some global statistics
int     num_verts, num_coordinates, num_faces, num_materials;

// Define some types to hold our data
typedef float t_coord[3];
typedef int   t_index[5];
typedef float t_mat[3];


// Our object data
t_coord *coordinates;
t_index *indices;
t_mat   *materials;

// Give the coordinate, colour and index indices 'proper' names.
// ( These are read by the compiler as X=0, Y=1, Z=2 -- V1=0 ... and so on )
enum {X, Y, Z};
enum {R, G, B};
enum {V1, V2, V3, V4, MATERIAL};


void load_simple_mesh (GLuint &list, char *file_name)
{
   FILE    *file;
   char    line[80];
   char    mode[15];
   char    trash[2];

   int  vertex = 0;

   if ((file = fopen(file_name, "r"))==NULL)
   {
      printf("File Not Found : %s\n",file_name);
      exit (1);
   }

   // Get first line and parse it
   fgets  ( line, 80, file );
   sscanf ( line,"%s %d", &mode, &num_verts );
   printf ( "%s %d\n", mode, num_verts );

   printf ( "%d Seperate Coordinates\n", num_verts * 3 );

   // Allocate space for verts
   coordinates = (t_coord *) malloc (num_verts * (sizeof(t_coord)));
   if (coordinates == NULL)
   {
      printf ( "Cannot allocate memory for Coordinate List\n" );
      fclose ( file );
      exit   ( 1    );
   }

   // Get the vertex data
   while (vertex < num_verts )
   {
      fgets  ( line, 80, file );

      /* "coordinates[vertex][X]",
      // Notice how useful our type and name declarations were ?  */
         sscanf ( line, "%f %f %f", &coordinates[vertex][X], &coordinates[vertex][Y],
                                    &coordinates[vertex][Z] );

         printf ("%f %f %f\n",  coordinates[vertex][X],
                                coordinates[vertex][Y],
                                coordinates[vertex][Z] );
         vertex++;
   }

   // Eat blank line
   fgets ( line, 80, file );

   // Get Material line and parse it
   fgets  ( line, 80, file );
   sscanf ( line,"%s %d", &mode, &num_materials );

   printf ( "%s %d\n", mode, num_materials );

   // Allocate space for materials
   materials = (t_mat *) malloc ( num_materials * (sizeof(t_mat)));
   if ( materials == NULL )
   {
      printf ( "Cannot allocate memory for materials List\n" );
      fclose ( file);
      free   ( coordinates );
      exit   ( 1 );
   }

   // Get the materials
   for (int loop = 0; loop < num_materials; loop++)
   {
      fgets  ( line, 80, file );
      sscanf ( line, "%s %f %s %f %s %f", &trash, &materials[loop][R],
                                          &trash, &materials[loop][G],
                                          &trash, &materials[loop][B] );

      printf ("%f %f %f\n",  materials[loop][R],
                             materials[loop][G],
                             materials[loop][B] );
   }

   // Eat blank line
   fgets(line, 80, file);

   // Get face line and parse it
   fgets  ( line, 80, file );
   sscanf ( line,"%s %d", &mode, &num_faces );

   printf ( "%s %d\n", mode, num_faces );

   // Allocate space for faces
   indices = (t_index *) malloc(num_faces * (sizeof(t_index)));
   if ( indices == NULL )
   {
      printf ( "Cannot allocate memory for face List\n" );
      fclose ( file );
      free ( coordinates );
      free ( materials   );
      exit ( 1 );
   }

   // Get the lines of facess
   for ( int loop = 0; loop < num_faces; loop++ )
   {
   fgets  ( line, 80, file );
   sscanf ( line,"%i %i %i %i %i", &indices[loop][V1], &indices[loop][V2],
                                   &indices[loop][V3], &indices[loop][V4],
                                   &indices[loop][MATERIAL] );

   printf ("%i %i %i %i %i\n", indices[loop][V1], indices[loop][V2],
                               indices[loop][V3], indices[loop][V4],
                               indices[loop][MATERIAL] );
   }

   // Do OpenGL Display list gubbins
   // ...
   list = glGenLists(1);

   glNewList(list, GL_COMPILE);

   for ( int loop = 0; loop < num_faces; loop++ )
   {
      glBegin(GL_POLYGON);

      // if the last material <> the current material then change colour,
      // else its the same, so leave it - this *should* make things a little faster
      if ( indices[loop][MATERIAL] != indices[loop-1][MATERIAL] )
      {
         glColor3f  ( materials[ indices[loop][MATERIAL] ][R],
                      materials[ indices[loop][MATERIAL] ][G],
                      materials[ indices[loop][MATERIAL] ][B]);

         printf ( "Face: %i Previous material: %i Current Material: %i\n", loop,
                   indices[loop-1][MATERIAL], indices[loop][MATERIAL] );
      }
      glVertex3fv ( coordinates[ indices[loop][V1] ] ) ;
      glVertex3fv ( coordinates[ indices[loop][V2] ] ) ;
      glVertex3fv ( coordinates[ indices[loop][V3] ] ) ;
      glVertex3fv ( coordinates[ indices[loop][V4] ] ) ;
      glEnd();
   }
   glEndList();

   // Free the arrays
   free ( indices     );
   free ( coordinates );
   free ( materials   );
}

