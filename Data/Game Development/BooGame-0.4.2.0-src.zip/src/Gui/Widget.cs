/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;
using System.Drawing;

namespace BooGame.Gui
{
    /// <summary>
    /// When implemented by a class, encapsulates a Widget control for the graphical user interface.
    /// </summary>
    public abstract class Widget : Entity
    {
        public Widget()
        {
            base.IsWorldObject = false;
        }

        private Widget m_Parent;
        /// <summary>
        /// Gets and sets the parent widget, if there is one.
        /// </summary>
        public Widget Parent
        {
            get { return m_Parent; }
            set
            {
                if (m_Parent != null)
                    if (m_Parent.Children.Contains(this))
                        m_Parent.Children.Remove(this);
                m_Parent = value;
                if(m_Parent != null)
                    if (!m_Parent.Children.Contains(this))
                        m_Parent.Children.Add(this);
            }
        }

        private WidgetCollection m_Children = new WidgetCollection();
        /// <summary>
        /// Gets all children associated with this control.
        /// </summary>
        public WidgetCollection Children
        {
            get { return m_Children; }
        }

        public void Add(Widget widget)
        {
            m_Children.Add(widget);
            widget.Parent = this;
        }

        private bool m_Focusable = true;
        /// <summary>
        /// True if the widget can recieve focus.
        /// </summary>
        public bool Focusable
        {
            get { return m_Focusable; }
            set { m_Focusable = value; }
        }

        /// <summary>
        /// Gets and sets whether the widget has GUI focus.
        /// </summary>
        public bool HasFocus
        {
            get
            {
                if(Core.Game.Gui.FocusedWidget != null)
                    return Core.Game.Gui.FocusedWidget.Equals(this);
                return false;
            }
            set
            {
                Core.Game.Gui.FocusedWidget = value ? this : null;
            }
        }

        /// <summary>
        /// When overriden, draws the widget on the screen.
        /// </summary>
        public override void Draw()
        {
            if(Visible)
                m_Children.Draw();
        }

        /// <summary>
        /// When overriden, updates the state of the widgets.
        /// </summary>
        public override void Update()
        {
            base.Update();
            m_Children.Update();
        }

        /// <summary>
        /// Gets and sets a rectangle representing the absolute location of the widget.
        /// </summary>
        public RectangleF AbsoluteRectangle
        {
            get
            {
                return new RectangleF(this.AbsoluteX, this.AbsoluteY, this.Width, this.Height);
            }
            set
            {
                this.AbsoluteX = value.X;
                this.AbsoluteY = value.Y;
                this.Width = value.Width;
                this.Height = value.Height;
            }
        }

        public PointF AbsoluteLocation
        {
            get
            {
                return new PointF(this.AbsoluteX, this.AbsoluteY);
            }
            set
            {
                this.AbsoluteX = value.X;
                this.AbsoluteY = value.Y;
            }
        }

        /// <summary>
        /// Gets and sets the absolute X coordinate of the widget.
        /// </summary>
        public float AbsoluteX
        {
            get
            {
                if (m_Parent != null)
                    return m_Parent.AbsoluteX + this.X;
                else
                    return this.X;
            }
            set
            {
                if (m_Parent != null)
                    this.X = value - m_Parent.AbsoluteX;
                else
                    this.X = value;
            }
        }

        /// <summary>
        /// Gets and sets the absolute Y coordinate of the widget.
        /// </summary>
        public float AbsoluteY
        {
            get
            {
                if (m_Parent != null)
                    return m_Parent.AbsoluteY + this.Y;
                else
                    return this.Y;
            }
            set
            {
                if (m_Parent != null)
                    this.Y = value - m_Parent.AbsoluteY;
                else
                    this.Y = value;
            }
        }

        #region Events

        #region Mouse Events
        /// <summary>
        /// Called when the mouse is moved over the widget.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnMouseMotion(MouseEventArgs e)
        {
            if (MouseMotion != null)
                MouseMotion(this, e);
            foreach (Widget widget in m_Children)
                if (widget.AbsoluteRectangle.IntersectsWith(e.Rectangle))
                    widget.OnMouseMotion(e);
        }
        /// <summary>
        /// Called when a mouse button is pressed on the widget.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnMouseButtonDown(MouseEventArgs e)
        {
            if (MouseButtonDown != null)
                MouseButtonDown(this, e);
            foreach (Widget widget in m_Children)
                if (widget.AbsoluteRectangle.IntersectsWith(e.Rectangle))
                    widget.OnMouseButtonDown(e);
        }
        /// <summary>
        /// Called when the mouse wheel is scrolled on the widget.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnMouseWheel(MouseEventArgs e)
        {
            if (MouseWheel != null)
                MouseWheel(this, e);
            foreach (Widget widget in m_Children)
                if (widget.AbsoluteRectangle.IntersectsWith(e.Rectangle))
                    widget.OnMouseWheel(e);
        }
        /// <summary>
        /// Called when the mouse button is unpressed on the widget.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnMouseButtonUp(MouseEventArgs e)
        {
            if (MouseButtonUp != null)
                MouseButtonUp(this, e);
            foreach (Widget widget in m_Children)
                if (widget.AbsoluteRectangle.IntersectsWith(e.Rectangle))
                    widget.OnMouseButtonUp(e);
        }
        public event MouseEventHandler MouseMotion;
        public event MouseEventHandler MouseButtonDown;
        public event MouseEventHandler MouseButtonUp;
        public event MouseEventHandler MouseWheel;

        #endregion Mouse Events

        #region Keyboard Events

        /// <summary>
        /// Called when a keyboard key is unpressed when this widget has focus.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnKeyUp(KeyboardEventArgs e)
        {
            if (KeyUp != null)
                KeyUp(this, e);
        }
        /// <summary>
        /// Called when a keyboard key is pressed when this widget has focus.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnKeyDown(KeyboardEventArgs e)
        {
            if (KeyDown != null)
                KeyDown(this, e);
        }
        public event KeyboardEventHandler KeyUp;
        public event KeyboardEventHandler KeyDown;

        #endregion Keyboard Events

        #region Joystick Events
        public event JoystickEventHandler JoystickButtonDown;
        public event JoystickEventHandler JoystickButtonUp;
        public event JoystickEventHandler JoystickAxisMovement;
        public virtual void OnJoystickButtonDown(JoystickEventArgs e)
        {
            if (JoystickButtonDown != null)
                JoystickButtonDown(this, e);
        }
        public virtual void OnJoystickButtonUp(JoystickEventArgs e)
        {
            if (JoystickButtonUp != null)
                JoystickButtonUp(this, e);
        }
        public virtual void OnJoystickAxisMovement(JoystickEventArgs e)
        {
            if (JoystickAxisMovement != null)
                JoystickAxisMovement(this, e);
        }
        #endregion Joystick Events

        #endregion Events
    }


    #region WidgetCollection
    /// <summary>
    /// A collection of Widgets.
    /// </summary>
    [Serializable]
    public class WidgetCollection : CollectionBase, ICollection
    {
        public WidgetCollection()
            : base()
        {
        }

        public WidgetCollection(WidgetCollection widgets)
        {
            this.Add(widgets);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public WidgetCollection(Widget widget)
        {
            Add(widget);
        }

        public Widget this[int index]
        {
            get
            {
                return ((Widget)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }

        public int Add(Widget widget)
        {
            return (List.Add(widget));
        }

        public int Add(WidgetCollection widgetCollection)
        {
            for (int i = 0; i < widgetCollection.Count; i++)
                this.Add(widgetCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Widget widget)
        {
            List.Insert(index, widget);
        }

        public void Remove(Widget widget)
        {
            List.Remove(widget);
        }

        public int IndexOf(Widget widget)
        {
            return (List.IndexOf(widget));
        }

        public bool Contains(Widget widget)
        {
            return (List.Contains(widget));
        }

        public virtual void CopyTo(Widget[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public void Draw()
        {
            foreach (Widget widget in List)
                widget.Draw();
        }
        public void Update()
        {
            foreach (Widget widget in List)
                widget.Update();
        }
    }
    #endregion WidgetCollection
}
