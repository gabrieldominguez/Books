Attribute VB_Name = "gleExtrusionsEx"
Option Explicit


'-------------------------------------------------------------------------== */
' * The following routine is, in principle, very simple:
' * all that it does is normalize the up vector, and makes
' * sure that it is perpendicular to the initial polyline segment.
' *
' * In fact, this routine gets awfully complicated because:
' * a) the first few segements of the polyline might be degenerate,
' * b) up vecotr may be parallel to first few segments of polyline,
' * c) etc.
'public sub up_sanity_check (gleDouble up(3),  ' up vector for contour */
'                      int npoints,      ' numpoints in poly-line */
'                      gleDouble point_array()(3))   ' polyline */
'-------------------------------------------------------------------------== */
'-------------------------------------------------------------------------
'FUNCTION:
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Public Sub UpSanityCheck(up#(), npoints&, point_array() As gleVector)
Dim i&
Dim lng#
Dim diff#(0 To 2)
    ' now, right off the bat, we should make sure that the up vector
    ' * is in fact perpendicular to the polyline direction */
    V3Subd diff, point_array(1).v, point_array(0).v
    V3Lengthd lng, diff
    If lng = 0 Then
        ' This error message should go through "official" error interface */
        'fdebug.? (stderr, "Extrusion: Warning: initial segment zero length \n");
        Debug.Assert 0
    
        ' loop till we find something that ain't of zero length */
        For i = 1 To npoints - 3 '2; i++) {
            V3Subd diff, point_array(i + 1).v, point_array(i).v
            V3Lengthd lng, diff
            If lng <> 0 Then
                Exit For
            End If
        Next
    End If

    ' normalize diff to be of unit length */
    lng = 1 / lng
    V3Scaled diff, lng, diff
    
    ' we want to take only perpendicular component of up w.r.t. the
     '* initial segment */
    V3Perpd up, up, diff
    
    V3Lengthd lng, up
    If (lng = 0) Then
        ' This error message should go through "official" error interface */
        'fdebug.? (stderr, "Extrusion: Warning: ");
        'fdebug.? (stderr, "contour up vector parallel to tubing direction \n");
        Debug.Assert 0
        ' do like the error message says ... */
        V3Copyd up, diff
    End If
End Sub


'
' * MODULE: segment.h
' *
' * FUNCTION:
' * Contains function prototypes for segment drawing subroutines.
' * These are used only internally, and are not to be exported to
' * the user.
' *
' * HISTORY:
' * Create by Linas Vepstas
' */

'-------------------------------------------------------------------------== */
'
' * MODULE NAME: segment.c
' *
' * FUNCTION:
' * This module contains code that draws cylinder sections.  There are a
' * number of different segment routines presented: with and without colors,
' * with and without normals, with and without front and back normals.
' *
' * HISTORY:
' * written by Linas Vepstas August/September 1991
' * split into multiple compile units, Linas, October 1991
' * added normal vectors Linas, October 1991
' * consoldated from other modules,  Linas Vepstas, March 1993
' */

'-------------------------------------------------------------------------== */
'public sub draw_segment_plain (ncp&,   ' number of contour points */
'                         gleDouble front_contour()(3),
'                         gleDouble back_contour()(3),
'                         inext&, double lng)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_plain(gc As gleGC, ncp&, _
        front_contour() As gleVector, fIndex&, _
        back_contour() As gleVector, bIndex&, inext&, lng#)
Dim j&
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        V3F gc, back_contour(bIndex + j).v, j, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        V3F gc, front_contour(fIndex).v, j, tFRONT
        V3F gc, back_contour(bIndex).v, j, tBACK
    End If
    glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_segment_color (ncp&,   ' number of contour points */
'                         gleDouble front_contour()(3),
'                         gleDouble back_contour()(3),
'                         float color_last(3),
'                         float color_next(3),
'                         inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_color(gc As gleGC, ncp&, _
        front_contour() As gleVector, fIndex&, _
        back_contour() As gleVector, bIndex&, _
        color_last!(), color_next!(), inext&, lng#)
Dim j&
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        glColor3fv color_last(0)
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        
        glColor3fv color_next(0)
        V3F gc, back_contour(bIndex + j).v, j, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        glColor3fv color_last(0)
        V3F gc, front_contour(fIndex).v, 0, tFRONT

        glColor3fv color_next(0)
        V3F gc, back_contour(bIndex).v, 0, tBACK
    End If

    glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_segment_edge_n (ncp&,  ' number of contour points */
'                           gleDouble front_contour()(3),
'                           gleDouble back_contour()(3),
'                           double norm_cont()(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_edge_n(gc As gleGC, ncp&, _
        front_contour() As gleVector, fIndex&, _
        back_contour() As gleVector, bIndex&, _
        norm_cont() As gleVector, nIndex&, inext&, lng#)
Dim j&
    
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        V3F gc, back_contour(bIndex + j).v, j, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        N3F gc, norm_cont(nIndex).v
        V3F gc, front_contour(fIndex).v, 0, tFRONT
        V3F gc, back_contour(bIndex).v, 0, tBACK
    End If
    glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_segment_c_and_edge_n (ncp&,    ' number of contour points */
'                           gleDouble front_contour()(3),
'                           gleDouble back_contour()(3),
'                           double norm_cont()(3),
'                           float color_last(3),
'                           float color_next(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_c_and_edge_n(gc As gleGC, ncp&, _
                front_contour() As gleVector, fIndex&, _
                back_contour() As gleVector, bIndex&, _
                norm_cont() As gleVector, nIndex&, _
                color_last!(), _
                color_next!(), _
                inext&, lng#)
Dim j&
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, back_contour(bIndex + j).v, j, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex).v
        V3F gc, front_contour(fIndex).v, 0, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex).v
        V3F gc, back_contour(bIndex).v, 0, tBACK
    End If
   glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_segment_facet_n (ncp&, ' number of contour points */
'                           gleDouble front_contour()(3),
'                           gleDouble back_contour()(3),
'                           double norm_cont()(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_facet_n(gc As gleGC, ncp&, _
            front_contour() As gleVector, fIndex&, _
            back_contour() As gleVector, bIndex&, _
            norm_cont() As gleVector, nIndex&, inext&, lng#)
Dim j&

    ' draw the tube segment */
    'BGNTMESH inext, lng
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        V3F gc, back_contour(bIndex + j).v, j, tBACK
        V3F gc, front_contour(fIndex + j + 1).v, j + 1, tFRONT
        V3F gc, back_contour(bIndex + j + 1).v, j + 1, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        N3F gc, norm_cont(nIndex + ncp - 1).v
        V3F gc, front_contour(fIndex + ncp - 1).v, ncp - 1, tFRONT
        V3F gc, back_contour(bIndex + ncp - 1).v, ncp - 1, tBACK
        V3F gc, front_contour(fIndex).v, 0, tFRONT
        V3F gc, back_contour(bIndex).v, 0, tBACK
    End If

   glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_segment_c_and_facet_n (ncp&,
'                           gleDouble front_contour()(3),
'                           gleDouble back_contour()(3),
'                           double norm_cont()(3),
'                           float color_last(3),
'                           float color_next(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_segment_c_and_facet_n(gc As gleGC, ncp&, _
                front_contour() As gleVector, fIndex&, _
                back_contour() As gleVector, bIndex&, _
                norm_cont() As gleVector, nIndex&, _
                color_last!(), color_next!(), inext&, lng#)
Dim j&
   ' Note about this code:
   ' * At first, when looking at this code, it appears to be really dumb:
   ' * the N3F() call appears to be repeated multiple times, for no
   ' * apparent purpose.  It would seem that a performance improvement
   ' * would be gained by stripping it out. !DONT DO IT!
   ' * When there are no local lights or viewers, the V3F() subroutine
   ' * does not trigger a recalculation of the lighting equations.
   ' * However, we MUST trigger lighting, since otherwise colors come out
   ' * wrong.  Trigger lighting by doing an N3F call.
   ' */

    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, front_contour(fIndex + j).v, j, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, back_contour(bIndex + j).v, j, tBACK
        
        
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, front_contour(fIndex + j + 1).v, j + 1, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex + j).v
        V3F gc, back_contour(bIndex + j + 1).v, j + 1, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex + ncp - 1).v
        V3F gc, front_contour(fIndex + ncp - 1).v, ncp - 1, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex + ncp - 1).v
        V3F gc, back_contour(bIndex + ncp - 1).v, ncp - 1, tBACK
        
        glColor3fv color_last(0)
        N3F gc, norm_cont(nIndex + ncp - 1).v
        V3F gc, front_contour(fIndex).v, 0, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, norm_cont(nIndex + ncp - 1).v
        V3F gc, back_contour(bIndex).v, 0, tBACK
    End If
    glEnd
End Sub

'-------------------------------------------------------------------------== */
' * This routine draws a segment with normals specified at each end.
'public sub draw_binorm_segment_edge_n (ncp&,
'                           double front_contour()(3),
'                           double back_contour()(3),
'                           double front_norm()(3),
'                           double back_norm()(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_binorm_segment_edge_n(gc As gleGC, ncp&, _
            front_contour() As gleVector, fcIndex&, _
            back_contour() As gleVector, bcIndex&, _
            front_norm() As gleVector, fnIndex&, _
            back_norm() As gleVector, bnIndex&, _
            inext&, lng#)
Dim j&
With gc
    ' draw the tube segment */
    'index check
    'If fcIndex <> 0 Then Debug.Assert 0
    'If bcIndex <> 0 Then Debug.Assert 0
    'If fnIndex <> 0 Then Debug.Assert 0
    'If bnIndex <> 0 Then Debug.Assert 0
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j).v, j, tFRONT
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j).v, j, tBACK
    Next
    
    If (.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        N3F gc, front_norm(fnIndex).v
        V3F gc, front_contour(fcIndex).v, 0, tFRONT
        N3F gc, back_norm(bnIndex).v
        V3F gc, back_contour(bcIndex).v, 0, tBACK
    End If
    glEnd
End With
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_binorm_segment_c_and_edge_n (ncp&,
'                           double front_contour()(3),
'                           double back_contour()(3),
'                           double front_norm()(3),
'                           double back_norm()(3),
'                           float color_last(3),
'                           float color_next(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_binorm_segment_c_and_edge_n(gc As gleGC, ncp&, _
                    front_contour() As gleVector, fcIndex&, _
                    back_contour() As gleVector, bcIndex&, _
                    front_norm() As gleVector, fnIndex&, _
                    back_norm() As gleVector, bnIndex&, _
                    color_last!(), _
                    color_next!(), _
                    inext&, lng#)
Dim j&
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j).v, j, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j).v, j, tBACK
    Next
    
    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex).v
        V3F gc, front_contour(fcIndex).v, 0, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex).v
        V3F gc, back_contour(bcIndex).v, 0, tBACK
    End If
    glEnd
End Sub

'-------------------------------------------------------------------------== */
' * This routine draws a piece of the round segment with psuedo-facet
' * normals.  I say "psuedo-facet" because the resulting object looks
' * much, much better than real facet normals, and is what the  round
' * join style was meant to accomplish for face normals.
' */
'public sub draw_binorm_segment_facet_n (ncp&,
'                           double front_contour()(3),
'                           double back_contour()(3),
'                           double front_norm()(3),
'                           double back_norm()(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_binorm_segment_facet_n(gc As gleGC, ncp&, _
                front_contour() As gleVector, fcIndex&, _
                back_contour() As gleVector, bcIndex&, _
                front_norm() As gleVector, fnIndex&, _
                back_norm() As gleVector, bnIndex&, _
                inext&, lng#)
                         
Dim j&
    ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j).v, j, tFRONT
        
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j).v, j, tBACK
        
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j + 1).v, j + 1, tFRONT
        
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j + 1).v, j + 1, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        N3F gc, front_norm(fnIndex + ncp - 1).v
        V3F gc, front_contour(fcIndex + ncp - 1).v, ncp - 1, tFRONT
        
        N3F gc, back_norm(bnIndex + ncp - 1).v
        V3F gc, back_contour(bcIndex + ncp - 1).v, ncp - 1, tBACK
        
        N3F gc, front_norm(fnIndex + ncp - 1).v
        V3F gc, front_contour(fcIndex).v, 0, tFRONT
        
        N3F gc, back_norm(bnIndex + ncp - 1).v
        V3F gc, back_contour(bcIndex).v, 0, tBACK
    End If
    glEnd
End Sub

'-------------------------------------------------------------------------== */
'public sub draw_binorm_segment_c_and_facet_n (ncp&,
'                           double front_contour()(3),
'                           double back_contour()(3),
'                           double front_norm()(3),
'                           double back_norm()(3),
'                           float color_last(3),
'                           float color_next(3),
'                           inext&, lng#)
'-------------------------------------------------------------------------== */
Public Sub draw_binorm_segment_c_and_facet_n(gc As gleGC, ncp&, _
                front_contour() As gleVector, fcIndex&, _
                back_contour() As gleVector, bcIndex&, _
                front_norm() As gleVector, fnIndex&, _
                back_norm() As gleVector, bnIndex&, _
                color_last!(), _
                color_next!(), _
                inext&, lng#)
Dim j&
   ' draw the tube segment */
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j).v, j, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j).v, j, tBACK
        
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex + j).v
        V3F gc, front_contour(fcIndex + j + 1).v, j + 1, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex + j).v
        V3F gc, back_contour(bcIndex + j + 1).v, j + 1, tBACK
    Next

    If (gc.ContourStyle = gleCLOSED) Then
        ' connect back up to first point of contour */
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex + ncp - 1).v
        V3F gc, front_contour(fcIndex + ncp - 1).v, ncp - 1, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex + ncp - 1).v
        V3F gc, back_contour(bcIndex + ncp - 1).v, ncp - 1, tBACK
        
        glColor3fv color_last(0)
        N3F gc, front_norm(fnIndex + ncp - 1).v
        V3F gc, front_contour(fcIndex).v, 0, tFRONT
        
        glColor3fv color_next(0)
        N3F gc, back_norm(bnIndex + ncp - 1).v
        V3F gc, back_contour(bcIndex).v, 0, tBACK
    End If
    
    glEnd
End Sub

' ==================== END OF FILE =========================== */

