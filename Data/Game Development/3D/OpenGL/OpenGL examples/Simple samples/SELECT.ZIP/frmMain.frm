VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "GLSelecCube"
   ClientHeight    =   5625
   ClientLeft      =   300
   ClientTop       =   2010
   ClientWidth     =   6000
   Icon            =   "frmMain.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   375
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   400
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Example of picking specific part of 3D object
'Compilation from GLCube and picking example by Rm. Ferrai
'done by Michal Husak husakm@vscht.cz
' Picking the cube faces is possible by mouse + left button
' rotating by cursor key, zooming by Z,X

Option Explicit

Const STEPTRACK = 0.1

Dim hPalette As Long
Dim hGLRC As Long

' +-------------------------------------------------------------------
' | Set some constants.
' +-------------------------------------------------------------------

Dim scalefactor As Single
Const STEP = 10
Dim xAngle As GLfloat
Dim yAngle As GLfloat
Dim zAngle As GLfloat
Dim doubleBuffer As GLboolean
Dim displayListInited As GLboolean

Sub Selection(X As Single, Y As Single)
Dim hits As Long
Dim viewport(0 To 3) As Long ' array for viewport
Dim selectbuf(0 To 512) As GLuint ' array for the reultes of picking
Dim BUFSIZE As Integer
BUFSIZE = 512


    glGetIntegerv GL_VIEWPORT, viewport(0)
    glSelectBuffer BUFSIZE, selectbuf(0)
    glRenderMode GL_SELECT
    glInitNames
    glPushName 0 'intializing the name stack
        
    'setting the same geomety as for normal view
    glMatrixMode GL_PROJECTION
    glPushMatrix 'saving the original matrix
    glLoadIdentity
    '2*2 region near cursor
    gluPickMatrix X, viewport(3) - Y, 2, 2, viewport(0)

    Kamera

    Objekt

    glPopMatrix 'restoring the original matrix
    glFlush

    hits = glRenderMode(GL_RENDER)   'hits = objects in hit

    processHits hits, selectbuf, X, Y
End Sub

Private Sub processHits(hits As Long, selectbuf, X As Single, Y As Single)
Dim i As Integer
Dim near As Long
Dim dist As Single, helpvar As GLuint
       
        If hits = 0 Then Exit Sub
        If hits > 0 Then
            Beep
        
            near = 0
            dist = 1E+30 ' very big number :)
            For i = 1 To hits
                helpvar = selectbuf((i - 1) * 4 + 1)
                If (GLuint_to_Single(helpvar) < dist) Then 'The distance to picked objekt
                    dist = GLuint_to_Single(helpvar)
                    near = selectbuf((i - 1) * 4 + 3) ' near = number of picked objekt
                End If
         
            Next i
            PSet (X, Y), RGB(255, 0, 0)
            Print near
        End If

End Sub

Private Function GLuint_to_Single(GLuint As GLuint) As Single
' Transformation of GLuint varibale (UnsignedLongInteger in C , no equivalent in VB) to Single
Dim result As Single

    result = GLuint
    If result < 0 Then result = 2147483648# + (2147483648# + result)
    GLuint_to_Single = result

End Function



Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 1 Then Selection X, Y
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
        Case vbKeyUp
            xAngle = xAngle + STEP
            otoc
        Case vbKeyDown
            xAngle = xAngle - STEP
            otoc
        Case vbKeyRight
            yAngle = yAngle + STEP
            otoc
        Case vbKeyLeft
            yAngle = yAngle - STEP
            otoc
        Case vbKeyZ
           scalefactor = scalefactor * 1.05
            otoc
       Case vbKeyX
            scalefactor = scalefactor * 0.95
            otoc
    End Select
End Sub

Private Sub otoc()
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glRotatef xAngle, 1, 0, 0
    glRotatef yAngle, 0, 1, 0
    glRotatef zAngle, 0, 0, 1
    glScalef scalefactor, scalefactor, scalefactor
    Form_Paint
End Sub

Sub Pohled()
    glViewport 0, 0, frmMain.ScaleWidth, frmMain.ScaleHeight
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    Kamera
End Sub

Sub Kamera()
     ' Camer view, the same for picking as for viewing
    gluPerspective 90, frmMain.ScaleWidth / frmMain.ScaleHeight, 1, 60
    gluLookAt 0, 0, 3, 0, 0, 0, 0, 1, 0
End Sub


Private Sub Form_Load()
scalefactor = 1

' +-------------------------------------------------------------------
' | Set angles and initialize.
' +-------------------------------------------------------------------

    Dim hGLRC As Long
    
    xAngle = 0
    yAngle = 0
    zAngle = 0
    doubleBuffer = GL_TRUE '
    displayListInited = GL_FALSE '
    SetupPixelFormat hDC
        
    hGLRC = wglCreateContext(hDC)
  
  
    wglMakeCurrent hDC, hGLRC
    
    ' ---------------------------------------------
    ' configure the OpenGL context for randering
    '----------------------------------------------
    
    glEnable GL_DEPTH_TEST
   
    glEnable GL_DITHER '
    glDepthFunc GL_LESS
    glClearDepth 1
    ' frame buffer clears should be to black
    glClearColor 1, 1, 1, 0
    ' set up projection transform

    Pohled
   
    Show
     
    Form_Paint
     
End Sub

Sub Objekt()
'Faces of cube numbered 1 to 4

        glLoadName (1) 'first label
        glBegin GL_QUADS
        
        glColor3f 0, 0.7, 0.1               ' Front Face (Green)
        glVertex3f -1, 1, 1
        glVertex3f 1, 1, 1
        glVertex3f 1, -1, 1
        glVertex3f -1, -1, 1
        glEnd
         
        glLoadName (2)
        glBegin GL_QUADS
        glColor3f 0.9, 1, 0                 ' Back Face (Yellow)
        glVertex3f -1, 1, -1
        glVertex3f 1, 1, -1
        glVertex3f 1, -1, -1
        glVertex3f -1, -1, -1
        glEnd
        
        glLoadName (3)
        glBegin GL_QUADS
        glColor3f 0.2, 0.2, 1               ' Top Side Face (Blue)
        glVertex3f -1, 1, 1
        glVertex3f 1, 1, 1
        glVertex3f 1, 1, -1
        glVertex3f -1, 1, -1
        glEnd
         
        glLoadName (4)
        glBegin GL_QUADS
        glColor3f 0.7, 0, 0.1                ' Bottom Side Face (Red)
        glVertex3f -1, -1, 1
        glVertex3f 1, -1, 1
        glVertex3f 1, -1, -1
        glVertex3f -1, -1, -1
        glEnd
        
        
End Sub

Private Sub Form_Paint()
' +-------------------------------------------------------------------
' | If a display list has been created, use it.  Otherwise, create it.
' +-------------------------------------------------------------------
    
    If displayListInited = GL_TRUE Then
        glCallList 1
    Else
        glNewList 1, GL_COMPILE_AND_EXECUTE
        glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
        
            Objekt
        
        glEndList
        
        displayListInited = GL_TRUE
    End If
        
    SwapBuffers hDC
        
End Sub

Private Sub Form_Resize()
    Pohled
    Form_Paint
End Sub

Private Sub Form_Unload(Cancel As Integer)
' +-------------------------------------------------------------------
' | Release OpenGL if we decide to quit.
' +-------------------------------------------------------------------
    
    If hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext hGLRC
    End If
    
    If hPalette <> 0 Then
        DeleteObject hPalette
    End If

End Sub
