
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _SYSMENU_
#define _SYSMENU_

#include <windows.h>

extern BOOL AddWinGlideSystemMenuOptions(HWND, DWORD);
extern VOID RemoveWinGlideSystemMenuOptions(HWND);
extern BOOL HandleWinGlideSystemMenuOptions(HWND, WPARAM, LPARAM);
extern BOOL ResetWinGlideWindowSize(HWND);

#endif //_SYSMENU_

