class AwesomeSeqAct_SpawnBoss extends SequenceAction;

event Activated()
{
    if(AwesomeGame(GetWorldInfo().Game) != none)
        AwesomeGame(GetWorldInfo().Game).SpawnBoss();
}

defaultproperties
{
    ObjName="Spawn Boss"
    ObjCategory="Awesome Game"
    VariableLinks.Empty
}
