/******************************************************************************
File: 		 dwdhdr.h
Version:	 2.00
Tab stops: every 2 columns
Project:   DiamondWare's Sound ToolKit
Copyright: 1996-1999 DiamondWare, Ltd.	All rights reserved.
Written:	 by Keith Weiner
Purpose:	 Declares the DWD file header and related constants and types
History:	 98/09/10 KW Started, based on dwd.h by JL
					 99/01/30 KW Finalized for v2.0 Std.
******************************************************************************/



#ifndef dwdhdr_INCLUDE

	#define dwdhdr_INCLUDE



	#define dwdhdr_MAGICSTR "DiamondWare Digitized\n"
	#define dwdhdr_EOF			0x1a

	#define dwdhdr_EOFINDEX 23

	#define dwdhdr_MAJVER 	 1
	#define dwdhdr_MINVER 	 1
	#define dwdhdr_MINVERDOS 0


	/*
	 . This enum is not used in dwdhdr_HEADER.comp because we need to guarantee
	 . size and alignment with disk files.
	*/
	typedef enum
	{
		dwdhdr_COMPR_NONE,
		dwdhdr_COMPR_DW,
		dwdhdr_COMPR_MSACM,
		dwdhdr_COMPR_REALAUDIO,
		dwdhdr_COMPR_VOXWARE,
		dwdhdr_COMPR_ECHOSPEECH,
		dwdhdr_COMPR_NUMCOMPRESSIONS

	} dwdhdr_COMPTYP;



	#ifdef _MSC_VER // Microsoft  C
		#ifdef	WIN32
			#pragma pack(push, dwdefs_h, 2) // Use 2 byte alignment for these structs
		#else
			#pragma pack(2)
		#endif
	#endif 

	typedef struct
	{
		char	title[24];	/* "DiamondWare Digitized\n\0\x1a" */
		BYTE	major;			/* Major version number */
		BYTE	minor;			/* Minor version number */
		DWORD sndid;			/* Unique sound ID (checksum XOR timestamp) */
		BYTE	reserved1;
		BYTE	comp; 			/* Compression type (0=none, see below) */
		WORD	rate;				/* Sampling rate (in Hz) */
		BYTE	chans;			/* Number of channels (1=mono, 2=stereo) */
		BYTE	bits;				/* Number of bits per sample per channel (8, 16) */
		WORD	vabs;				/* Absolute value of largest sample in file */
		DWORD	len;				/* Length of data section (in bytes) */
		DWORD	samp;				/* Number of samples (16-bit stereo would be 4 bytes/sample) */
		DWORD	offs;				/* Offset of data section from start of file (in bytes) */
		DWORD	reserved2;	/* Reserved for future expansion (markers) */
		WORD	pad;				/* 2 bytes of padding (in version 1.0) */

	} dwdhdr_DWD;

	#ifdef _MSC_VER // Microsoft  C
		#ifdef	WIN32
			#pragma pack(pop, dwdefs_h) // back to default packing
		#else
			#pragma pack()
		#endif
	#endif 



#endif
