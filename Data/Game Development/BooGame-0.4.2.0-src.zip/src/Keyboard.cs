/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;

using Tao.OpenGl;
using Tao.FreeGlut;

namespace BooGame
{
    /// <summary>
    /// Describes a event with the keyboard.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="e">The arguments associated with the event.</param>
    public delegate void KeyboardEventHandler(object sender, KeyboardEventArgs e);

    /// <summary>
    /// Module to work with the keyboard.
    /// </summary>
    public sealed class Keyboard
    {
        /// <summary>
        /// Invoked when a keyboard key is released.
        /// </summary>
        public static event KeyboardEventHandler KeyUp;
        /// <summary>
        /// Invoked when a keyboard key is pressed.
        /// </summary>
        public static event KeyboardEventHandler KeyDown;

        static Keyboard()
		{
			Core.Initialize();
            Glut.glutKeyboardFunc(new Glut.KeyboardCallback(KeyDownCallback));
            Glut.glutKeyboardUpFunc(new Glut.KeyboardUpCallback(KeyUpCallback));

            Glut.glutSpecialFunc(new Glut.SpecialCallback(SpecialKeyDownCallback));
            Glut.glutSpecialUpFunc(new Glut.SpecialUpCallback(SpecialKeyUpCallback));

			ClearKeys();
        }
        
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Keyboard()
        {
        }

        /// <summary>
        /// Makes sure the keyboard module is initialized.
        /// </summary>
        internal static void Initialize()
        {
        }

        /// <summary>
        /// Clears all polled key states.
        /// </summary>
        public static void ClearKeys()
        {
            keysDown = new bool[256];
        }

        /// <summary>
        /// Returns true if the given key is pressed.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool IsKeyDown(Keys key)
        {
            return keysDown[(int)key];
        }

		private static bool[] keysDown;

		private static void OnKeyDown(Keys key, bool special)
		{
            KeyboardEventArgs args = new KeyboardEventArgs(key, true, special);

            if (Terminal.Enabled)
            {
                if (Terminal.ActivationKey == args.Key)
                {
                    Terminal.Visible = !Terminal.Visible;
                    return;
                }
                else if (Terminal.Visible)
                {
                    Terminal.OnKeyDown(args);
                    return;
                }
            }
            Core.Game.KeyDown(args);
            Core.Game.Gui.OnKeyDown(args);

            if (KeyDown != null)
                KeyDown(null, args);
		}
        private static void OnKeyUp(Keys key, bool special)
		{
            KeyboardEventArgs args = new KeyboardEventArgs(key, false, special);

            if (!Terminal.Visible && args.Key != Terminal.ActivationKey)
            {
                Core.Game.KeyUp(args);
                Core.Game.Gui.OnKeyUp(args);

                if (KeyUp != null)
                    KeyUp(null, args);
            }
		}

        private static void SpecialKeyDownCallback(int key, int x, int y)
        {
            keysDown[key+126] = true;
            OnKeyDown((Keys)(key + 126), true);
        }
        private static void SpecialKeyUpCallback(int key, int x, int y)
        {
            keysDown[key+126] = false;
            OnKeyUp((Keys)(key + 126), true);
        }

        private static void KeyDownCallback(byte key, int x, int y)
        {
            keysDown[key] = true;
            OnKeyDown((Keys)key, false);
        }
        private static void KeyUpCallback(byte key, int x, int y)
        {
            keysDown[key] = false;
            OnKeyUp((Keys)key, false);
        }

        private static bool m_KeyRepeat = false;
        /// <summary>
        /// Gets and sets whether the KeyDown event is called when the user holds down a key.
        /// </summary>
        public static bool KeyRepeat
        {
            get 
            {
                return m_KeyRepeat;
            }
            set
            {
                Glut.glutIgnoreKeyRepeat(value ? 0 : 1);
                m_KeyRepeat = value;
            }
        }

        /// <summary>
        /// Converts a Key to a character type.
        /// </summary>
        /// <param name="key">The Key value to convert.</param>
        /// <returns>A character representing the Key value.</returns>
        public static char KeyToChar(Keys key)
        {
            return (char)(int)key;
        }
        /// <summary>
        /// Converts a character value to a key value.
        /// </summary>
        /// <param name="chr">The character.</param>
        /// <returns>A key value representing the character type.</returns>
        public static Keys CharToKey(char chr)
        {
            return (Keys)(int)chr;
        }

        /// <summary>
        /// Gets whether or not a keyboard device exists.
        /// </summary>
        public static bool Exists
        {
            get
            {
                return Glut.glutDeviceGet(Glut.GLUT_HAS_KEYBOARD) != 0;
            }
        }
	}

	/// <summary>
	/// Arguments passed to keyboard events.
	/// </summary>
	public class KeyboardEventArgs : EventArgs
	{
		public KeyboardEventArgs()
		{
		}
		public KeyboardEventArgs(Keys key)
		{
			m_Key = key;
		}
		public KeyboardEventArgs(Keys key, bool pressed)
		{
			m_Key = key;
			m_Pressed = pressed;
        }
        public KeyboardEventArgs(Keys key, bool pressed, bool specialKey)
        {
            m_Key = key;
            m_Pressed = pressed;
            m_SpecialKey = specialKey;
        }
		private bool m_Pressed = false;
        private Keys m_Key = Keys.Null;
        private bool m_SpecialKey = false;

        /// <summary>
        /// Gets the character represented by the key.
        /// </summary>
		public char Char
		{
			get { return (char)(int)m_Key; }
		}

        /// <summary>
        /// Whether the key is currently pressed.
        /// </summary>
		public bool Pressed
		{
			get { return m_Pressed; }
		}

        /// <summary>
        /// Gets the key associated with this event.
        /// </summary>
		public Keys Key
		{
			get { return m_Key; }
		}

        /// <summary>
        /// Gets whether the key is a special key or not.
        /// </summary>
        public bool IsSpecialKey
        {
            get { return m_SpecialKey; }
        }
	}

    /// <summary>
    /// Represents keys on the keyboard.
    /// </summary>
    public enum Keys
    {
        Null = 0,
        HeaderStart = 1,
        TextStart = 2,
        TextEnd = 3,
        TransmissionEnd = 4,
        Enquiry = 5,
        Acknowledgment = 6,
        Bell = 7,
        Backspace = 8,
        Tab = 9,
        LineFeed = 10,
        VerticalTab = 11,
        FormFeed = 12,
        Return = 13,
        ShiftOut = 14,
        ShiftIn = 15,
        DataLinkEscape = 16,
        DeviceControl1 = 17,
        DeviceControl2 = 18,
        DeviceControl3 = 19,
        DeviceControl4 = 20,
        NegativeAcknowledgement = 21,
        SynchronousIdle = 22,
        EndOfTransBlock = 23,
        Cancel = 24,
        EndOfMedium = 25,
        Substitute = 26,
        Escape = 27,
        FileSeparator = 28,
        GroupSeparator = 29,
        RecordSeparator = 30,
        UnitSeparator = 31,
        Space = 32,
        Exclamation = 33,
        DoubleQuote = 34,
        NumberSign = 35,
        DollarSign = 36,
        PercentSign = 37,
        Ampersand = 38,
        SingleQuote = 39,
        OpenBracket = 40,
        CloseBracket = 41,
        Asterisk = 42,
        PlusSign = 43,
        Comma = 44,
        Hyphen = 45,
        Period = 46,
        Slash = 47,
        Zero = 48,
        One = 49,
        Two = 50,
        Three = 51,
        Four = 52,
        Five = 53,
        Six = 54,
        Seven = 55,
        Eight = 56,
        Nine = 57,
        Colon = 58,
        SemiColon = 59,
        LessThan = 60,
        Equals = 61,
        GreaterThan = 62,
        QuestionMark = 63,
        AtSign = 64,
        CapitalA = 65,
        CapitalB = 66,
        CapitalC = 67,
        CapitalD = 68,
        CapitalE = 69,
        CapitalF = 70,
        CapitalG = 71,
        CapitalH = 72,
        CapitalI = 73,
        CapitalJ = 74,
        CapitalK = 75,
        CapitalL = 76,
        CapitalM = 77,
        CapitalN = 78,
        CapitalO = 79,
        CapitalP = 70,
        CapitalQ = 81,
        CapitalR = 82,
        CapitalS = 83,
        CapitalT = 84,
        CapitalU = 85,
        CapitalV = 86,
        CapitalW = 87,
        CapitalX = 88,
        CapitalY = 89,
        CapitalZ = 90,
        SquareBracketOpen = 91,
        Backslash = 92,
        SquareBracketClose = 93,
        Caret = 94,
        Underscore = 95,
        GraveAccent = 96,
        A = 97,
        B = 98,
        C = 99,
        D = 100,
        E = 101,
        F = 102,
        G = 103,
        H = 104,
        I = 105,
        J = 106,
        K = 107,
        L = 108,
        M = 109,
        N = 110,
        O = 111,
        P = 112,
        Q = 113,
        R = 114,
        S = 115,
        T = 116,
        U = 117,
        V = 118,
        W = 119,
        X = 120,
        Y = 121,
        Z = 122,
        CurlyBracketOpen = 123,
        VerticalBar = 124,
        CurlyBracketClose = 124,
        Tilde = 125,
        F1 = Glut.GLUT_KEY_F1+126,
        F2 = Glut.GLUT_KEY_F2+126,
        F3 = Glut.GLUT_KEY_F3 + 126,
        F4 = Glut.GLUT_KEY_F4 + 126,
        F5 = Glut.GLUT_KEY_F5 + 126,
        F6 = Glut.GLUT_KEY_F6 + 126,
        F7 = Glut.GLUT_KEY_F7 + 126,
        F8 = Glut.GLUT_KEY_F8 + 126,
        F9 = Glut.GLUT_KEY_F9 + 126,
        F10 = Glut.GLUT_KEY_F10 + 126,
        F11 = Glut.GLUT_KEY_F11 + 126,
        F12 = Glut.GLUT_KEY_F12 + 126,
        PageUp = Glut.GLUT_KEY_PAGE_UP + 126,
        PageDown = Glut.GLUT_KEY_PAGE_DOWN + 126,
        Home = Glut.GLUT_KEY_HOME + 126,
        End = Glut.GLUT_KEY_END + 126,
        LeftArrow = Glut.GLUT_KEY_LEFT + 126,
        RightArrow = Glut.GLUT_KEY_RIGHT + 126,
        DownArrow = Glut.GLUT_KEY_DOWN + 126,
        UpArrow = Glut.GLUT_KEY_UP + 126,
        Insert = Glut.GLUT_KEY_INSERT + 126
    }
}
