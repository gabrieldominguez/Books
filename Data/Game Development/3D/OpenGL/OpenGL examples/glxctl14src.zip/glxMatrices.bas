Attribute VB_Name = "glxMatrices"
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: matrix routines.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY: Hah! These routines come from all over. Use at your
'       own risk!!!
'NOTES: I don't know how many of the row-column issues
'       have been resolved in this code. Also, using these routines
'       on cameras and objects produce quite different results.
'
'-------------------------------------------------------------------------


Public Enum glxPrincipalAxes
    AXIS_X = 1
    AXIS_Y = 2
    AXIS_Z = 3
End Enum
Public Enum glxReferenceFrame
    glxSelf = 1
    glxWorld = 2
End Enum

'-------------------------------------------------------------------------
'Identity
'-------------------------------------------------------------------------
Public Sub MatIdentityf(m!())
   m(0) = 1: m(1) = 0: m(2) = 0: m(3) = 0:
   m(4) = 0: m(5) = 1: m(6) = 0: m(7) = 0
   m(8) = 0: m(9) = 0: m(10) = 1: m(11) = 0
   m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

Public Sub MatIdentityd(m#())
   m(0) = 1: m(1) = 0: m(2) = 0: m(3) = 0:
   m(4) = 0: m(5) = 1: m(6) = 0: m(7) = 0
   m(8) = 0: m(9) = 0: m(10) = 1: m(11) = 0
   m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------
' Copy
'-------------------------------------------------------------------------
Public Sub MatCopyf(mdest!(), m!())
Dim i&
    For i = 0 To 15
        mdest(i) = m(i)
    Next
End Sub

Public Sub MatCopyd(mdest#(), m#())
Dim i&
    For i = 0 To 15
        mdest(i) = m(i)
    Next
End Sub

'-------------------------------------------------------------------------------------
'Transpose
'-------------------------------------------------------------------------------------
Public Sub MatTransposef(m!())
Dim i&, j&
Dim m2!(0 To 15)
    For i = 0 To 3: For j = 0 To 3
        m2(i * 4 + j) = m(j * 4 + i)
    Next: Next
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
'Invert
'-------------------------------------------------------------------------------------
Public Function MatInvertf(dest!(), Src!()) As Boolean
Dim i&, j&, k&, swap&, t!
Dim temp!(0 To 3, 0 To 3)
On Error GoTo EH
    For i = 0 To 3:  For j = 0 To 3
        temp(i, j) = Src(i * 4 + j)
    Next: Next
    MatIdentityf dest
    For i = 0 To 3
        ' Look for largest element in column
        swap = i
        For j = i + 1 To 3
            If (Abs(temp(j, i)) > Abs(temp(i, i))) Then
                swap = j
            End If
        Next
        If (swap <> i) Then
            ' Swap rows.
            For k = 0 To 3
                t = temp(i, k)
                temp(i, k) = temp(swap, k)
                temp(swap, k) = t
                t = dest(i * 4 + k)
                dest(i * 4 + k) = dest(swap * 4 + k)
                dest(swap * 4 + k) = t
            Next
        End If
        If (temp(i, i) = 0) Then
             ' No non-zero pivot.  The matrix is singular, which
             'shouldn 't ** happen.  This means the user gave us a
             'bad matrix.
            Debug.Assert 0
            Exit Function
        End If
        t = temp(i, i)
        For k = 0 To 3
            temp(i, k) = temp(i, k) / t
            dest(i * 4 + k) = dest(i * 4 + k) / t
        Next
        For j = 0 To 3
            If (j <> i) Then
                t = temp(j, i)
                For k = 0 To 3
                    temp(j, k) = temp(j, k) - temp(i, k) * t
                    dest(j * 4 + k) = dest(j * 4 + k) - dest(i * 4 + k) * t
                Next
            End If
        Next
    Next
    MatInvertf = True
    Exit Function
EH:
    Debug.Assert 0
End Function

'-------------------------------------------------------------------------------------
'Translate
'-------------------------------------------------------------------------------------
Public Sub MatSetTranslationf(m!(), ByVal X!, ByVal Y!, ByVal z!)
    MatIdentityf m
    m(12) = X
    m(13) = Y
    m(14) = z
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatSetTransOnlyf(m!(), ByVal X!, ByVal Y!, ByVal z!)
    m(12) = X
    m(13) = Y
    m(14) = z
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatTranslatef(m!(), ByVal X!, ByVal Y!, ByVal z!)
Dim m1!(0 To 15)
Dim m2!(0 To 15)
    MatSetTranslationf m1, X, Y, z
    MatMultiplyf m2, m, m1
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatTranslateOnOwnAxisf(m!(), ByVal distance!, ByVal Axis As glxPrincipalAxes)
Dim m1!(0 To 15)
Dim m2!(0 To 15)
Dim v!(0 To 2)
    'axis constants run 1 - 3
    v(Axis - 1) = distance
    MatSetTranslationf m1, v(0), v(1), v(2)
    MatMultiplyf m2, m1, m
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatTranslateOnAxisf(m!(), Axis!(), ByVal distance!)
Dim m1!(0 To 15)
Dim m2!(0 To 15)
    MatSetTranslationf m1, Axis(0) * distance, _
            Axis(1) * distance, Axis(2) * distance
    MatMultiplyf m2, m1, m
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
'SCALE
'-------------------------------------------------------------------------------------
Public Sub MatSetScalef(m!(), ByVal X!, ByVal Y!, ByVal z!)
    MatIdentityf m
    m(0) = X
    m(5) = Y
    m(10) = z
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatSetScaleOnlyf(m!(), ByVal X!, ByVal Y!, ByVal z!)
    m(0) = X
    m(5) = Y
    m(10) = z
End Sub

'-------------------------------------------------------------------------------------
'scales along world axes
Public Sub MatScalef(m!(), ByVal X!, ByVal Y!, ByVal z!)
Dim m1!(0 To 15)
Dim m2!(0 To 15)
    MatSetScalef m1, X, Y, z
    MatMultiplyf m2, m, m1
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatScaleOnOwnAxisf(m!(), ByVal X!, ByVal Y!, ByVal z!)
Dim m1!(0 To 15)
Dim m2!(0 To 15)
    MatSetScalef m1, X, Y, z
    MatMultiplyf m2, m1, m
    MatCopyf m, m2
End Sub

'-------------------------------------------------------------------------------------
' the scale factors of the matrix
'-------------------------------------------------------------------------------------
Public Sub MatGetScale(m!(), v3!())
Dim i&
    For i = 0 To 2
        v3(i) = Sqr(m(i) * m(i) + _
                     m(4 + i) * m(4 + i) + _
                     m(8 + i) * m(8 + 1))
    Next
End Sub

'-------------------------------------------------------------------------------------
' Rotate
'-------------------------------------------------------------------------------------

'-------------------------------------------------------------------------------------
' rotation about the x-axis, in radians
'-------------------------------------------------------------------------------------
Public Sub MatSetRotationXRadf(m!(), ByVal theta!)
Dim c!, s!
    c = Cos(theta)
    s = Sin(theta)
    m(0) = 1: m(4) = 0: m(8) = 0:  m(12) = 0
    m(1) = 0: m(5) = c: m(9) = -s: m(13) = 0
    m(2) = 0: m(6) = s: m(10) = c: m(14) = 0
    m(3) = 0: m(7) = 0: m(11) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
' rotation about the y-axis
'-------------------------------------------------------------------------------------
Public Sub MatSetRotationYRadf(m!(), ByVal theta!)
Dim c!, s!
    c = Cos(theta)
    s = Sin(theta)
    m(0) = c:  m(4) = 0: m(8) = s:  m(12) = 0
    m(1) = 0:  m(5) = 1: m(9) = 0:  m(13) = 0
    m(2) = -s: m(6) = 0: m(10) = c: m(14) = 0
    m(3) = 0:  m(7) = 0: m(11) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
'rotation about the z-axis
'-------------------------------------------------------------------------------------
Public Sub MatSetRotationZRadf(m!(), ByVal theta!)
Dim c!, s!
    c = Cos(theta)
    s = Sin(theta)
    m(0) = c: m(4) = -s: m(8) = 0:  m(12) = 0
    m(1) = s: m(5) = c:  m(9) = 0:  m(13) = 0
    m(2) = 0: m(6) = 0:  m(10) = 1: m(14) = 0
    m(3) = 0: m(7) = 0:  m(11) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatSetRotationRadf(m!(), ByVal theta!, ByVal X!, ByVal Y!, ByVal z!)
Dim d!, ct!, st!
    MatIdentityf m
    ' normalize axis
    V3Normalize3f X, Y, z
    ct = Cos(theta)
    st = Sin(theta)
    ' R = uu' + cos(theta)*(I-uu') + sin(theta)*S
    '
    ' S =  0  -z   y    u' = (x, y, z)
    '      z   0  -x
    '     -y   x   0
     m(0) = X * X + ct * (1 - X * X) + st * 0
     m(4) = X * Y + ct * (0 - X * Y) + st * -z
     m(8) = X * z + ct * (0 - X * z) + st * Y
     m(1) = Y * X + ct * (0 - Y * X) + st * z
     m(5) = Y * Y + ct * (1 - Y * Y) + st * 0
     m(9) = Y * z + ct * (0 - Y * z) + st * -X
     m(2) = z * X + ct * (0 - z * X) + st * -Y
     m(6) = z * Y + ct * (0 - z * Y) + st * X
     m(10) = z * z + ct * (1 - z * z) + st * 0
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatRotateRadf(m!(), ByVal theta!, ByVal Axis As glxPrincipalAxes, ByVal frame As glxReferenceFrame)
Dim Mat!(0 To 15)
    Select Case Axis
    Case AXIS_X: MatRotX_CS Mat, Cos(theta), Sin(theta)
    Case AXIS_Y: MatRotY_CS Mat, Cos(theta), Sin(theta)
    Case AXIS_Z: MatRotZ_CS Mat, Cos(theta), Sin(theta)
    End Select
    If frame = glxWorld Then
        MatMultiplyf m, m, Mat
    Else
        MatMultiplyf m, Mat, m
    End If
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatRotateOnAxisRadf(m!(), ByVal theta!, Axis!(), ByVal frame As glxReferenceFrame)
Dim CosA2!, SinA2!, A!, B!, c!
Dim Mat!(0 To 15)
Dim X!, Y!, z!
    CosA2 = Cos(theta / 2)
    SinA2 = Sin(theta / 2)
    A = SinA2 * Axis(0)
    B = SinA2 * Axis(1)
    c = SinA2 * Axis(2)
    X = -m(12)
    Y = -m(13)
    z = -m(14)
    '
    Mat(0) = 1 - 2 * B * B - 2 * c * c
    Mat(1) = 2 * A * B - 2 * CosA2 * c
    Mat(2) = 2 * A * c + 2 * CosA2 * B
    Mat(4) = 2 * A * B + 2 * CosA2 * c
    Mat(5) = 1 - 2 * A * A - 2 * c * c
    Mat(6) = 2 * B * c - 2 * CosA2 * A
    Mat(8) = 2 * A * c - 2 * CosA2 * B
    Mat(9) = 2 * B * c + 2 * CosA2 * A
    Mat(10) = 1 - 2 * A * A - 2 * B * B
    Mat(15) = 1
    If frame = glxWorld Then
        MatMultiplyf m, m, Mat
    Else
        MatMultiplyf m, Mat, m
    End If
End Sub

'-------------------------------------------------------------------------------------
' rotation about the x-axis
Public Sub MatRotX_CS(m!(), ByVal c!, ByVal s!)
    m(0) = 1: m(1) = 0: m(2) = 0: m(3) = 0
    m(4) = 0: m(5) = c: m(6) = s: m(7) = 0
    m(8) = 0: m(9) = -s: m(10) = c: m(11) = 0
    m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatRotY_CS(m!(), ByVal c!, ByVal s!)
   ' rotation about the y-axis
    m(0) = c:  m(1) = 0:  m(2) = -s: m(3) = 0
    m(4) = 0:  m(5) = 1:  m(6) = 0:  m(7) = 0
    m(8) = s:  m(9) = 0:  m(10) = c: m(11) = 0
    m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatRotZ_CS(m!(), ByVal c!, ByVal s!)
    ' rotation about the z-axis   \
    m(0) = c:  m(1) = s:  m(2) = 0:  m(3) = 0
    m(4) = -s: m(5) = c:  m(6) = 0:  m(7) = 0
    m(8) = 0:  m(9) = 0:  m(10) = 1: m(11) = 0
    m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------
'Multiply
'-------------------------------------------------------------------------
Public Sub MatMultiplyf(mdest!(), m1!(), m2!())
Dim m!(0 To 15)
    m(0) = m1(0) * m2(0) + m1(1) * m2(4) + m1(2) * m2(8) + m1(3) * m2(12)
    m(1) = m1(0) * m2(1) + m1(1) * m2(5) + m1(2) * m2(9) + m1(3) * m2(13)
    m(2) = m1(0) * m2(2) + m1(1) * m2(6) + m1(2) * m2(10) + m1(3) * m2(14)
    m(3) = m1(0) * m2(3) + m1(1) * m2(7) + m1(2) * m2(11) + m1(3) * m2(15)
    
    m(4) = m1(4) * m2(0) + m1(5) * m2(4) + m1(6) * m2(8) + m1(7) * m2(12)
    m(5) = m1(4) * m2(1) + m1(5) * m2(5) + m1(6) * m2(9) + m1(7) * m2(13)
    m(6) = m1(4) * m2(2) + m1(5) * m2(6) + m1(6) * m2(10) + m1(7) * m2(14)
    m(7) = m1(4) * m2(3) + m1(5) * m2(7) + m1(6) * m2(11) + m1(7) * m2(15)
    
    m(8) = m1(8) * m2(0) + m1(9) * m2(4) + m1(10) * m2(8) + m1(11) * m2(12)
    m(9) = m1(8) * m2(1) + m1(9) * m2(5) + m1(10) * m2(9) + m1(11) * m2(13)
    m(10) = m1(8) * m2(2) + m1(9) * m2(6) + m1(10) * m2(10) + m1(11) * m2(14)
    m(11) = m1(8) * m2(3) + m1(9) * m2(7) + m1(10) * m2(11) + m1(11) * m2(15)
    
    m(12) = m1(12) * m2(0) + m1(13) * m2(4) + m1(14) * m2(8) + m1(15) * m2(12)
    m(13) = m1(12) * m2(1) + m1(13) * m2(5) + m1(14) * m2(9) + m1(15) * m2(13)
    m(14) = m1(12) * m2(2) + m1(13) * m2(6) + m1(14) * m2(10) + m1(15) * m2(14)
    m(15) = m1(12) * m2(3) + m1(13) * m2(7) + m1(14) * m2(11) + m1(15) * m2(15)
    MatCopyf mdest, m
End Sub

'called by gleView routines
'each m(0 to 15)
Public Sub MatMultiplyd(mdest#(), m1#(), m2#())
   mdest(0) = m1(0) * m2(0) + m1(1) * m2(4) + m1(2) * m2(8) + m1(3) * m2(12)
   mdest(1) = m1(0) * m2(1) + m1(1) * m2(5) + m1(2) * m2(9) + m1(3) * m2(13)
   mdest(2) = m1(0) * m2(2) + m1(1) * m2(6) + m1(2) * m2(10) + m1(3) * m2(14)
   mdest(3) = m1(0) * m2(3) + m1(1) * m2(7) + m1(2) * m2(11) + m1(3) * m2(15)
   mdest(4) = m1(4) * m2(0) + m1(5) * m2(4) + m1(6) * m2(8) + m1(7) * m2(12)
   mdest(5) = m1(4) * m2(1) + m1(5) * m2(5) + m1(6) * m2(9) + m1(7) * m2(13)
   mdest(6) = m1(4) * m2(2) + m1(5) * m2(6) + m1(6) * m2(10) + m1(7) * m2(14)
   mdest(7) = m1(4) * m2(3) + m1(5) * m2(7) + m1(6) * m2(11) + m1(7) * m2(15)
   mdest(8) = m1(8) * m2(0) + m1(9) * m2(4) + m1(10) * m2(8) + m1(11) * m2(12)
   mdest(9) = m1(8) * m2(1) + m1(9) * m2(5) + m1(10) * m2(9) + m1(11) * m2(13)
   mdest(10) = m1(8) * m2(2) + m1(9) * m2(6) + m1(10) * m2(10) + m1(11) * m2(14)
   mdest(11) = m1(8) * m2(3) + m1(9) * m2(7) + m1(10) * m2(11) + m1(11) * m2(15)
   mdest(12) = m1(12) * m2(0) + m1(13) * m2(4) + m1(14) * m2(8) + m1(15) * m2(12)
   mdest(13) = m1(12) * m2(1) + m1(13) * m2(5) + m1(14) * m2(9) + m1(15) * m2(13)
   mdest(14) = m1(12) * m2(2) + m1(13) * m2(6) + m1(14) * m2(10) + m1(15) * m2(14)
   mdest(15) = m1(12) * m2(3) + m1(13) * m2(7) + m1(14) * m2(11) + m1(15) * m2(15)
End Sub

'-------------------------------------------------------------------------
'' matrix times vector
'-------------------------------------------------------------------------
Public Sub MatDotVectorf(vdest!(), m!(), v!())
Dim v2!(0 To 2)
   v2(0) = m(0) * v(0) + m(1) * v(1) + m(2) * v(2)
   v2(1) = m(4) * v(0) + m(5) * v(1) + m(6) * v(2)
   v2(2) = m(8) * v(0) + m(9) * v(1) + m(10) * v(2)
   V3Copyf vdest, v2
End Sub

Public Sub MatDotVectord(vdest#(), m#(), v#())
   vdest(0) = m(0) * v(0) + m(1) * v(1) + m(2) * v(2)
   vdest(1) = m(4) * v(0) + m(5) * v(1) + m(6) * v(2)
   vdest(2) = m(8) * v(0) + m(9) * v(1) + m(10) * v(2)
End Sub


'-------------------------------------------------------------------------
'UNTESTED
'-------------------------------------------------------------------------
Public Sub MatFromAxisAngle(m!(), Axis!(), ByVal Angle!)
Dim q!(0 To 3)
    QuatFromAxis q, Axis, Angle
    QuatToMatrix q, m
End Sub

'-------------------------------------------------------------------------
' Calculate an axis and rotation angle from a matrix
'-------------------------------------------------------------------------
Public Sub MatToAxisAngle(m!(), Axis!(), ByVal Angle!)
Dim q!(0 To 3)
    QuatFromMatrix q, m
    QuatToAxis q, Axis, Angle
End Sub

''-------------------------------------------------------------------------------------
'' * FUNCTION:
'' * This module provides two different routines that compute and return
'' * viewing matrices.  Both routines take a direction and an up vector,
'' * and return a matrix that transforms the direction to the z-axis, and
'' * the up-vector to the y-axis.
'' * HISTORY:
'' * written by Linas Vepstas August 1991
'' * Added double precision interface, March 1993, Linas
'' * ported by edx - edx@hk.super.net, April 98
''-------------------------------------------------------------------------------------
'' The ViewPoint subroutine computes a 4x4 matrix that
'' translates the origin to the point Eye, puts the negative z axis
'' along the direction v21=Target-Eye, and puts the y axis along the up
'' vector.
''-------------------------------------------------------------------------------------
Public Sub MatViewPoint(m!(), eye!(), Target!(), up!())
Dim v21!(0 To 2)
Dim trans_mat!(0 To 15)
Dim rot_mat!(0 To 15)
    ' find the vector that points in the v21 direction
    V3Subf v21, Target, eye
    ' compute rotation matrix that takes -z axis to the v21 axis,
    ' and y to the up direction
    m_ViewDirection rot_mat, v21, up
    ' build matrix that translates the origin to Eye
    MatIdentityf trans_mat
    trans_mat(12) = eye(0)
    trans_mat(13) = eye(1)
    trans_mat(14) = eye(2)
    ' concatenate the matrices together
    MatMultiplyf m, rot_mat, trans_mat
End Sub

''-------------------------------------------------------------------------------------
'' The ViewDirection subroutine computes and returns a 4x4 rotation
''  matrix that puts the negative z axis along the direction v21 and
''  puts the y axis along the up vector.
''
''  Note that this code is fairly tolerant of "weird" paramters.
''  It normalizes when necessary, it does nothing when vectors are of
''  zero length, or are co-linear.  This code shouldn't croak, no matter
''  what the user sends in as arguments.
''
''-------------------------------------------------------------------------------------
Private Sub m_ViewDirection(m!(), v21!(), up!())
Dim amat!(0 To 15)
Dim bmat!(0 To 15)
Dim cmat!(0 To 15)
Dim v_hat_21!(0 To 2)
Dim v_xy!(0 To 2)
Dim sine!, cosine!
Dim lng!
Dim up_proj!(0 To 2)
Dim tmp!(0 To 2)
On Error GoTo EH
    ' find the unit vector that points in the v21 direction
    V3Copyf v_hat_21, v21
    V3Lengthf lng, v_hat_21
    If (lng <> 0) Then
        lng = 1 / lng
        V3Scalef v_hat_21, lng, v_hat_21
        ' rotate z in the xz-plane until same latitude
        sine = Sqr(1 - v_hat_21(2) * v_hat_21(2))
        MatRotY_CS amat, -v_hat_21(2), -sine
    Else
        ' error condition: zero length vecotr passed in -- do nothing
        Debug.Assert 0
        'MatrixIdentity amat
        Exit Sub
    End If


    ' project v21 onto the xy plane
    v_xy(0) = v21(0)
    v_xy(1) = v21(1)
    v_xy(2) = 0
    V3Lengthf lng, v_xy

    ' rotate in the x-y plane until v21 lies on z axis ---
    ' but of course, if its already there, do nothing
    If (lng <> 0) Then
        ' want xy projection to be unit vector, so that sines/cosines pop out
        lng = 1 / lng
        V3Scalef v_xy, lng, v_xy
        ' rotate the projection of v21 in the xy-plane over to the x axis
        MatRotZ_CS bmat, v_xy(0), v_xy(1)
        ' concatenate these together
        MatMultiplyf cmat, amat, bmat
    Else
        ' no-op -- vector is already in correct position
        MatCopyf cmat, amat
    End If

    ' up vector really should be perpendicular to the x-form direction --
    ' Use up a couple of cycles, and make sure it is,
    ' just in case the user blew it.
    V3Perpf up_proj, up, v_hat_21
    V3Lengthf lng, up_proj
    If (lng <> 0) Then
        ' normalize the vector
        lng = 1 / lng
        V3Scalef up_proj, lng, up_proj

        ' compare the up-vector to the  y-axis to get the cosine of the angle
        tmp(0) = cmat(4) '(1, 0)
        tmp(1) = cmat(5) '(1, 1)
        tmp(2) = cmat(6) '(1, 2)
        V3Dotf cosine, tmp, up_proj

        ' compare the up-vector to the x-axis to get the sine of the angle
        tmp(0) = cmat(0) '(0, 0)
        tmp(1) = cmat(1) '(0, 1)
        tmp(2) = cmat(2) '(0, 2)
        V3Dotf sine, tmp, up_proj

        ' rotate to align the up vector with the y-axis
        MatRotZ_CS amat, cosine, -sine

        ' This xform, although computed last, acts first
        MatMultiplyf m, amat, cmat

    Else
        ' error condition: up vector is indeterminate (zero length)
        ' -- do nothing
        Debug.Assert 0
        MatCopyf m, cmat
    End If
    Exit Sub
EH:
    Debug.Assert 0
End Sub





'-------------------------------------------------------------------------------------
'EVERYTHING BELOW HERE SHOULD BE CONSIDERED UNTESTED!!!
'There may be row-column issues or other problems.
'These are ports I made and collected here for now.
'-------------------------------------------------------------------------------------




'-------------------------------------------------------------------------
' Find the rotation angle and axis that rotates between two matrices
' -------------------------------------------------------------------------
Private Sub MatInterpAxisAngle(ma!(), mB!(), Axis!(), ByVal Angle!)
Dim mt!(0 To 15), mr!(0 To 15), ms!(0 To 15)
    Stop
    MatCopyf mt, ma
    MatTransposef ma
    MatMultiplyf ms, mt, mB
    MatToAxisAngle ms, Axis, Angle
End Sub

'-------------------------------------------------------------------------
' Convert the spherical rotation coordinates to a matrix
'-------------------------------------------------------------------------
Public Sub MatFromSpherical(m!(), v!())
Dim Axis!(0 To 2), q!(0 To 3)
    V3FromSpherical Axis, v   ' Latitude/Longitude-> Axis
    QuatFromAxis q, Axis, v(2)   'vs->vz );   /* Rotation angle */
    QuatToMatrix q, m
End Sub

'-------------------------------------------------------------------------
' Convert a matrix to spherical rotation coordinates
'-------------------------------------------------------------------------
Public Sub MatToSpherical(m!(), v!())
Dim Axis!(0 To 2), q!(0 To 3)
    QuatFromMatrix q, m
    QuatToAxis q, Axis, v(2)  ' &vs->vz );    /* Rotation angle */
    V3ToSpherical v, Axis ' Axis -> Latitude/Longitude */
End Sub

'-------------------------------------------------------------------------
' Calculate the Euler rotation angles from a 4x4 matrix
'-------------------------------------------------------------------------
Public Sub MatToEuler(m!(), v!())
Dim cos_ry!, trx!, try!
On Error GoTo EH
    v(1) = ArcSin(-m(8))   ' Rotation in Y
    cos_ry = Cos(v(1))
    v(1) = RadToDegf(v(1))
    
    If (Abs(cos_ry) > 0.0005) Then      ' Y rotation is non-zero?
        trx = m(10) / cos_ry            ' Yes, so get X rotation
        try = -m(9) / cos_ry
        v(0) = Atan2(try, trx)
        v(0) = RadToDegf(v(0))
        trx = m(0) / cos_ry       ' Then get Z rotation
        try = -m(4) / cos_ry
        v(2) = Atan2(try, trx)
        v(2) = RadToDegf(v(2))
    Else                            ' Y rotation is zero
        v(0) = 0                    ' X rotation must be zero
        trx = m(5)                 ' So get Z rotation
        try = m(1)
        v(2) = Atan2(try, trx)
        v(2) = RadToDegf(v(2))
    End If

    If (v(0) < 0) Then     ' Less than zero?
        v(0) = v(0) + 360  ' Yes, so wrap-around
    End If
    If (v(1) < 0) Then     ' Less than zero?
        v(1) = v(1) + 360       ' Yes, so wrap-around
    End If
    If v(2) < 0 Then  ' Less than zero?
        v(2) = v(2) + 360 ' Yes, so wrap-around
    End If
    Exit Sub
EH:
    Debug.Assert 0
End Sub

Public Sub MatFromEuler(m!(), X!, Y!, z!)
Dim sx!, sy!, sz!, cx!, cy!, cz!
Dim sxsy!, cxsy!
    sx = Sin(X): cx = Cos(X)
    sy = Sin(Y): cy = Cos(Y)
    sz = Sin(z): cz = Cos(z)
    sxsy = sx * sy
    cxsy = cx * sy
    
    m(0) = cy * cz
    m(4) = -cy * sz
    m(8) = -sy
    
    m(1) = cx * sz - sxsy * cz
    m(5) = cx * cz + sxsy * sz
    m(9) = -sx * cy
    
    m(2) = sx * sz + cxsy * cz
    m(6) = sx * cz - cxsy * sz
    m(10) = cx * cy
End Sub

'-------------------------------------------------------------------------------------
'untested
Sub MatToEuler1(m!(), v3Out!())
Dim siny!, cosy!
On Error GoTo EH
    siny = m(8)
    cosy = Sqr(1 - siny * siny)
    If (m(0) < 0 And m(10) < 0) Then cosy = -cosy
    If (cosy <> 0) Then
        v3Out(0) = Atan2(m(9) / cosy, m(10) / cosy)
        v3Out(1) = Atan2(siny, cosy)
        v3Out(2) = Atan2(m(4) / cosy, m(0) / cosy)
    Else
        v3Out(0) = Atan2(-m(6), m(5))
        v3Out(1) = ArcSin(siny)
        v3Out(2) = 0
    End If
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
Sub MatToEuler2(m!(), v3Out!())
Const VTK_AXIS_EPSILON = 0.001
Dim X!, Y!, z!, d!, d1!, d2!, dot!
Dim alpha!, phi!, theta!
Dim cosPhi!, sinPhi!, cosTheta!, sinTheta!
Dim cosAlpha!, sinAlpha!, x2!, y2!, z2!
Dim x3!, y3!, z3!, x3p!, y3p!
Dim fScale!(0 To 2)
On Error GoTo EH
    '
    MatGetScale m, fScale
    ' first rotate about y axis
    x2 = m(8) / fScale(0)
    y2 = m(9) / fScale(1)
    z2 = m(10) / fScale(2)
    
    x3 = m(4) / fScale(0)
    y3 = m(5) / fScale(1)
    z3 = m(6) / fScale(2)
    
    dot = x2 * x2 + z2 * z2
    d1 = Sqr(dot)

    If (d1 < VTK_AXIS_EPSILON) Then
        cosTheta = 1
        sinTheta = 0
    Else
        cosTheta = z2 / d1
        sinTheta = x2 / d1
    End If

    theta = Atan2(sinTheta, cosTheta)

    Y = -theta / 0.017453292

    ' now rotate about x axis
    dot = x2 * x2 + y2 * y2 + z2 * z2
    d = Sqr(dot)
    
    If (d < VTK_AXIS_EPSILON) Then
      sinPhi = 0
      cosPhi = 1
    ElseIf (d1 < VTK_AXIS_EPSILON) Then
      sinPhi = y2 / d
      cosPhi = z2 / d
    Else
      sinPhi = y2 / d
      cosPhi = (x2 * x2 + z2 * z2) / (d1 * d)
    End If
    
    phi = Atan2(sinPhi, cosPhi)

    X = phi / 0.017453292

    ' finally, rotate about z
    x3p = x3 * cosTheta - z3 * sinTheta
    y3p = -sinPhi * sinTheta * x3 + cosPhi * y3 - sinPhi * cosTheta * z3
    dot = x3p * x3p + y3p * y3p
    
    d2 = Sqr(dot)
    If (d2 < VTK_AXIS_EPSILON) Then
      cosAlpha = 1
      sinAlpha = 0
    Else
      cosAlpha = y3p / d2
      sinAlpha = x3p / d2
    End If

    alpha = Atan2(sinAlpha, cosAlpha)

    z = alpha / 0.017453292

    v3Out(0) = X
    v3Out(1) = Y
    v3Out(2) = z
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
Public Sub MatMultiplyPointf(ptOut!(), ptIn!(), m!())
Dim X!, Y!, z!
Dim i&
    For i = 0 To 2
        ptOut(i) = ptIn(0) * m(i) + _
                    ptIn(1) * m(i + 4) + _
                    ptIn(2) * m(i + 8) + _
                    m(i + 12)
    Next
End Sub

'-------------------------------------------------------------------------------------
'following routines came from the screensavers
'-------------------------------------------------------------------------------------
Public Sub MatXFormPointf(ptOut!(), ptIn!(), Mat!()) ' As MatrixF)
Dim X!, Y!, z!
    X = (ptIn(0) * Mat(0)) + (ptIn(1) * Mat(1)) + _
        (ptIn(2) * Mat(2)) + Mat(3)
    Y = (ptIn(0) * Mat(4)) + (ptIn(1) * Mat(5)) + _
        (ptIn(2) * Mat(6)) + Mat(7)
    z = (ptIn(0) * Mat(8)) + (ptIn(1) * Mat(9)) + _
        (ptIn(2) * Mat(10)) + Mat(11)
    ptOut(0) = X
    ptOut(1) = Y
    ptOut(2) = z
End Sub

Public Sub MatXFormNormf(ptOut!(), ptIn!(), Mat!())
Dim X!, Y!, z!, lng!
    X = (ptIn(0) * Mat(0)) + (ptIn(1) * Mat(1)) + _
        (ptIn(2) * Mat(2)) + Mat(3)
    Y = (ptIn(0) * Mat(4)) + (ptIn(1) * Mat(5)) + _
        (ptIn(2) * Mat(6)) + Mat(7)
    z = (ptIn(0) * Mat(8)) + (ptIn(1) * Mat(9)) + _
        (ptIn(2) * Mat(10)) + Mat(11)
    lng = (X * X) + (Y * Y) + (z * z)
    If (lng >= ZERO_EPS) Then
        lng = 1 / Sqr(lng)
    Else
        lng = 1
    End If
    ptOut(0) = X * lng
    ptOut(1) = Y * lng
    ptOut(2) = z * lng
End Sub

'-------------------------------------------------------------------------------------
'MatrixRotAxisDegd
' * Computes a rotation matrix.
' * The rotation is around the the direction specified by the argument
' * argument axis(3).  User may specify vector which is not of unit
' * length.  The angle of rotation is specified in degrees, and is in the
' * right-handed direction.
'-------------------------------------------------------------------------------------
Public Sub MatRotAxisDegf(m!(), ByVal Angle!, Axis!())
Dim lng!, ax!(0 To 2)
    Angle = Angle * M_PI / 180 ' convert to radians
    ' renormalize axis vector, if needed
    lng = Axis(0) * Axis(0) + Axis(1) * Axis(1) + Axis(2) * Axis(2)
    '
    If lng <> 1 Then
        lng = 1 / Sqr(lng)
        ax(0) = Axis(0) * lng
        ax(1) = Axis(1) * lng
        ax(2) = Axis(2) * lng
        MatrixRotAxisf m, Angle, ax
    Else
        MatrixRotAxisf m, Angle, Axis
    End If
End Sub

'-------------------------------------------------------------------------------------
'MatrixRotAxisf
' * void urot_axis (float m(4)(4),      --- returned
' *                 float omega,        --- input
' *                 float axis(3))      --- input
' * Same as urot_about_axis(), but angle specified in radians.
' * It is assumed that the argument axis(3) is a vector of unit length.
' * If it is not of unit length, the returned matrix will not be correct.
'-------------------------------------------------------------------------------------
Public Sub MatrixRotAxisf(m!(), ByVal theta!, Axis!(), Optional Apply As Boolean = False)
Dim s!, c!, ssq!, csq!, cts!, tmp!
'    * The formula coded up below can be derived by using the
'    * homomorphism between SU(2) and O(3), namely, that the
'    * 3x3 rotation matrix R is given by
'    *      t.R.v = S(-1) t.v S
'    * where
'    * t are the Pauli matrices (similar to Quaternions, easier to use)
'    * v is an arbitrary 3-vector
'    * and S is a 2x2 hermitian matrix:
'    *     S = exp ( i omega t.axis / 2 )
'    * (Also, remember that computer graphics uses the transpose of R).
'    *
'    * The Pauli matrices are:
'    *
'    *  tx = (0 1)          ty = (0 -i)            tz = (1  0)
'    *       (1 0)               (i  0)                 (0 -1)
'    * Note that no error checking is done -- if the axis vector is not
'    * of unit length, you'll get strange results.
    tmp = theta / 2
    s = Sin(tmp)
    c = Cos(tmp)
    
    ssq = s * s
    csq = c * c
    
    m(0) = csq - ssq
    m(5) = csq - ssq
    m(10) = csq - ssq
    
    ssq = ssq * 2
    
    ' on-diagonal entries
    m(0) = m(0) + ssq * Axis(0) * Axis(0)
    m(5) = m(5) + ssq * Axis(1) * Axis(1)
    m(10) = m(10) + ssq * Axis(2) * Axis(2)
    
    ' off-diagonal entries
    m(1) = Axis(0) * Axis(1) * ssq
    m(4) = m(1)
    m(6) = Axis(1) * Axis(2) * ssq
    m(9) = m(6)
    m(8) = Axis(2) * Axis(0) * ssq
    m(2) = m(8)
    
    cts = 2 * c * s
    
    tmp = cts * Axis(2)
    m(1) = m(1) + tmp
    m(4) = m(4) - tmp
    
    tmp = cts * Axis(0)
    m(6) = m(6) + tmp
    m(9) = m(9) - tmp

    tmp = cts * Axis(1)
    m(8) = m(8) + tmp
    m(2) = m(2) - tmp
    
    ' homogeneous entries
    m(3) = 0
    m(7) = 0
    m(11) = 0
    'm(14) = 0
    'm(13) = 0
    'm(12) = 0
    m(15) = 1
    If Apply Then
        glMultMatrixf m(0)
    End If
End Sub


'-------------------------------------------------------------------------------------
'MatLookAt - from Mesa : gluLookAt
'-------------------------------------------------------------------------------------
Public Sub MatLookAt(Matrix!(), eye!(), tgt!(), up!())
Dim m!(0 To 15)
Dim X!(0 To 2), Y!(0 To 2), z!(0 To 2)
Dim mag!
    ' Z vector
    V3Subf z, eye, tgt
    'save distance, to regenerate target
    mag = Sqr(z(0) * z(0) + z(1) * z(1) + z(2) * z(2))
    If mag Then ' mpichler, 19950515
        z(0) = z(0) / mag
        z(1) = z(1) / mag
        z(2) = z(2) / mag
    End If
    ' Y vector
    Y(0) = up(0)
    Y(1) = up(1)
    Y(2) = up(2)
    ' X vector = Y cross Z
    X(0) = Y(1) * z(2) - Y(2) * z(1)
    X(1) = -Y(0) * z(2) + Y(2) * z(0)
    X(2) = Y(0) * z(1) - Y(1) * z(0)
    ' Recompute Y = Z cross X
    Y(0) = z(1) * X(2) - z(2) * X(1)
    Y(1) = -z(0) * X(2) + z(2) * X(0)
    Y(2) = z(0) * X(1) - z(1) * X(0)
    '
    V3Normalizef X
    V3Normalizef Y
    Matrix(0) = X(0): Matrix(4) = Y(0): Matrix(8) = z(0): Matrix(12) = 0 '-eye(0)
    Matrix(1) = X(1): Matrix(5) = Y(1): Matrix(9) = z(1): Matrix(13) = 0 '-eye(1)
    Matrix(2) = X(2): Matrix(6) = Y(2): Matrix(10) = z(2): Matrix(14) = 0 '-eye(2)
    Matrix(3) = 0:    Matrix(7) = 0:    Matrix(11) = 0: Matrix(15) = 1

    '/* Translate Eye to Origin */
    'glTranslated( -eyex, -eyey, -eyez );
    'glMultMatrixd( m );
    MatTranslatef Matrix, -eye(0), -eye(1), -eye(2)
End Sub




