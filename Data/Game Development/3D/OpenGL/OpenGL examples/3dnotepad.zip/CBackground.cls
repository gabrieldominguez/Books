VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CBackground"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: Implements panoramic (cubic) or spherical backgrounds.
'The panaorama is a VRML panorama.
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES:
'--------------------------------------------------------------------

'the type of background
Public Enum n3dBkgModes
    n3dBkgNone = 0
    n3dBkgSphere = 1
    n3dBkgbox = 2
End Enum
'for drawing tesselated planes
Private Enum DirectionConstants
    dirFront = 0
    dirLeft = 1 'for the object
    dirRight = 2
    dirBack = 3
    dirTop = 4
    dirBottom = 5
End Enum
Dim m_ListID&
Dim BkgTex&() 'array of texture ID's
'struct used for saving to disk
Private Type BKGREC
    BkgMode As Long
    NumUrls As Long
    Urls() As String
End Type
Dim Pics As BKGREC

'-----------------------------------------------------------------
Private Sub Class_Initialize()
    m_ListID = glGenLists(1)
End Sub

Private Sub Class_Terminate()
    Clear
    glDeleteLists m_ListID, 1
End Sub

'-----------------------------------------------------------------
Public Sub Clear()
Dim i&
    On Error GoTo OK
    If UBound(BkgTex) <> Pics.NumUrls - 1 Then
        Debug.Assert 0
    End If
    GoTo cont
OK: 'error when bkgtex is erased
    If Pics.NumUrls > 0 Then Debug.Assert 0
cont:
    On Error GoTo EH
    'the texture IDs we created when loading the textures
    'must be deleted when we finish with them.
    If Pics.NumUrls > 0 Then
        For i = 0 To Pics.NumUrls - 1
            If BkgTex(i) > 0 Then
                glDeleteTextures 1, BkgTex(i)
            Else
                Debug.Assert 0
            End If
        Next
    End If
    Erase BkgTex
    CheckError
    Pics.NumUrls = 0
    Pics.BkgMode = n3dBkgNone
    Erase Pics.Urls
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-----------------------------------------------------------------
'the panorama effect is produced by drawing the bkg at the same
'distance from the viewpoint each time.
'We try to avoid drawing the bkg if no texture files were
'loaded, because it makes a confusing pure white bkg field.
'-----------------------------------------------------------------
Public Sub Draw()
Dim ex!, ey!, ez!
    If (Pics.BkgMode > 0) And (Pics.NumUrls > 0) Then
        With gCtl.Camera
            .GetEyePos ex, ey, ez
            glPushMatrix
                glTranslatef ex, ey, ez
                glCallList m_ListID
            glPopMatrix
        End With
    End If
End Sub

'-----------------------------------------------------------------
'PROPERTIES
'-----------------------------------------------------------------

'-----------------------------------------------------------------
'controls type of env - none, sphere, or box
'-----------------------------------------------------------------
Public Property Get BkgMode() As n3dBkgModes
    BkgMode = Pics.BkgMode
End Property

Public Property Let BkgMode(ByVal NewValue As n3dBkgModes)
    Clear
    Pics.BkgMode = NewValue
End Property

'-----------------------------------------------------------------
'set the bkg images with an array of strings
'-----------------------------------------------------------------
Public Property Let Urls(filenames$())
Dim i&, cnt&
On Error GoTo EH
    ReDim Pics.Urls(0 To 5)
    For i = LBound(filenames) To UBound(filenames)
        If Len(filenames(i)) Then
            Pics.Urls(cnt) = filenames(i)
            cnt = cnt + 1
        Else: Exit For
        End If
    Next
    If cnt Then
        ReDim Preserve Pics.Urls(0 To cnt - 1)
        Pics.NumUrls = cnt
        m_LoadUrls
    Else
    End If
    Exit Property
EH:
    Debug.Assert 0
End Property

'-----------------------------------------------------------------
'this routine allows a bkg mode and a variable number of file names to
'be passed in. If no filenames are passed then it resets bkgmode to none.
'-----------------------------------------------------------------
Public Function SetBkgMode(ByVal NewValue As n3dBkgModes, ParamArray Urls()) As Boolean
Dim v, cnt&
On Error GoTo EH
    Clear
    Pics.BkgMode = NewValue
    'create new bkg if needed
    If Pics.BkgMode Then
        'load the filenames into a string array
        ReDim Pics.Urls(0 To 5)
        For Each v In Urls
            cnt = cnt + 1
            Pics.Urls(cnt - 1) = v
            If cnt >= 6 Then Exit For
        Next
        Pics.NumUrls = cnt
        If cnt Then
            ReDim Preserve Pics.Urls(0 To cnt - 1)
        Else 'don't want to draw a ugly white bkg
            Clear
            Exit Function
        End If
        SetBkgMode = m_LoadUrls()
    Else
        SetBkgMode = True
    End If
    Exit Function
EH:
    Debug.Assert 0
End Function

'-----------------------------------------------------------------
'this routine sets bkgmode to box (panorama).
'It allows the files to be set from a single filename.
'The filenames must be in SkyPaint format (x_FR.xxx, x_LF.xxx,x_RT.xxx, etc)
'It searches the dir for filenames in SkyPaint format in the order:
'fr,lf,rt,bk,up,dn
'It stops looking if it finds one file missing. This is because I
'assume that the user is trying to set a single file for all 6 sides
'or else is using a set of 6, one for each side.
'-----------------------------------------------------------------
Public Function SetBkg(file$) As Boolean
Dim s$, i&
Dim r&, cnt&
Dim Title$, Name$, Path$, Suffix$, Root$, Ext$
Dim fname$
On Error GoTo EH
    Clear
    ReDim Pics.Urls(0 To 5)
    'get the path and root name for the files
    Path = ExtractPath(file)
    Title = ExtractFileName(file) 'name w/ ext
    Ext = ExtractExt(Title)
    Name = ExtractName(Title) 'base name of the selected file (name w/out ext)
    Root = Left$(Name, Len(Name) - 3) 'root name of all the files
    'search order: fr,lf,rt,bk,up,dn
    For i = 0 To 5
        Select Case i
        Case 0: Suffix = "_FR"
        Case 1: Suffix = "_LF"
        Case 2: Suffix = "_RT"
        Case 3: Suffix = "_BK"
        Case 4: Suffix = "_UP"
        Case 5: Suffix = "_DN"
        End Select
        fname = Path & "\" & Root & Suffix & "." & Ext
        s = Dir(fname)
        If Len(s) = 0 Then
            'if its just a single file, not part of a set,
            'use it for all 6 sides
            If i = 0 Then
                Pics.Urls(i) = file
                cnt = 1
            End If
            'quit looking.
            Exit For
        End If
        Pics.Urls(i) = fname
        cnt = cnt + 1
    Next
    Pics.NumUrls = cnt
    If cnt Then
        If cnt < 6 Then ReDim Preserve Pics.Urls(0 To cnt - 1)
        Pics.BkgMode = n3dBkgbox
        SetBkg = m_LoadUrls()
    Else: Clear
    End If
    Exit Function
EH:
    Debug.Assert 0
    Debug.Print Err.Description
    MsgBox "Error opening file." & vbCrLf & Err.Description
    Exit Function
    Resume Next

End Function

'-----------------------------------------------------------------
'loads the bkg files and compiles them into a display list.
'Releases the textures when finished.
'-----------------------------------------------------------------
Private Function m_LoadUrls() As Boolean
Dim i&, cnt&, Pic As StdPicture, Tex As glxTexture
On Error GoTo EH
    If Pics.NumUrls < 1 Then
        Debug.Assert 0
        Exit Function
    End If
    Set Pic = New StdPicture 'used to load the files
    ReDim BkgTex(0 To Pics.NumUrls - 1) 'array of texture names
    For i = 0 To Pics.NumUrls - 1
        'if any file fails to load, abort.
        If Len(Pics.Urls(i)) = 0 Then
            Debug.Assert 0
            Exit For
        End If
        Set Tex = gCtl.NewTexture
        'a new addition to the ocx, for when I forget it only supports bmps and sgi files,
        'loads the file to a StdPicture and converts it to a texture:
        'If Tex.LoadTextureFile(Files(i)) Then
        '(the above line can replace the next 6 lines)
        Set Pic = LoadPicture(Pics.Urls(i))
        If Pic = 0 Then
            Debug.Assert 0
            Exit For
        End If
        If Tex.LoadPicture(Pic) Then
            BkgTex(i) = Tex.TexID 'save the ID for the texture object
            Tex.mode = Decal
            Tex.MAG = Linear
            Tex.Min = Linear
            cnt = cnt + 1
        Else: Exit For
        End If
        'this allows the texture data to be released when the class
        'terminates without deleting the texture object gl holds:
        Tex.DeleteID = False
        Set Tex = Nothing
    Next
    CheckError
    If cnt = 0 Then
        Clear
    Else
        Pics.NumUrls = cnt
        ReDim Preserve BkgTex(0 To cnt - 1)
        ReDim Preserve Pics.Urls(0 To cnt - 1)
        'now compile the bkg into a display list
        m_DrawBkg
        CheckError
        m_LoadUrls = True
    End If
    Exit Function
EH:
    Debug.Assert 0
    Debug.Print Err.Description
    MsgBox "Error opening file." & vbCrLf & Err.Description
    Exit Function
    Resume Next
End Function


'----------------------------------------------------------------------------
'uses quad strips to create the box planes. Must be >8 or the bkg looks crappy
'----------------------------------------------------------------------------
Private Sub m_DrawBkg()
Dim X!, z!, q&
    glNewList m_ListID, GL_COMPILE
        glPushAttrib GL_LIGHTING
            glDisable GL_LIGHTING
            glEnable GL_TEXTURE_2D
            glBindTexture glTexture2D, BkgTex(0)
            gCtl.Materials.SetMaterialIndex BRIGHT_WHITE
            glColor3f 1, 1, 1
            Select Case Pics.BkgMode
            Case n3dBkgSphere
                q = gluNewQuadric
                glPushMatrix
                    glRotatef 90, 1, 0, 0
                    gluQuadricNormals q, qnSmooth
                    gluQuadricOrientation q, qoInside
                    gluQuadricTexture q, 1
                    gluSphere q, 1000, 64, 64
                glPopMatrix
                gluDeleteQuadric q
            Case n3dBkgbox
                X = 1000
                z = 500
                BkgPlane dirFront, X, X, -z ', 4, 4
                If Pics.NumUrls >= 2 Then glBindTexture glTexture2D, BkgTex(1)
                BkgPlane dirLeft, X, X, -z
                If Pics.NumUrls >= 3 Then glBindTexture glTexture2D, BkgTex(2)
                BkgPlane dirRight, X, X, z
                If Pics.NumUrls >= 4 Then glBindTexture glTexture2D, BkgTex(3)
                BkgPlane dirBack, X, X, z
                If Pics.NumUrls >= 5 Then glBindTexture glTexture2D, BkgTex(4)
                BkgPlane dirTop, X, X, z
                If Pics.NumUrls >= 6 Then glBindTexture glTexture2D, BkgTex(5)
                BkgPlane dirBottom, X, X, -z
            End Select
            glDisable GL_TEXTURE_2D
        glPopAttrib
    glEndList
End Sub

'----------------------------------------------------------------------------
'provides a box side broken up into quads
'----------------------------------------------------------------------------
Private Sub BkgPlane(direction As DirectionConstants, Width!, Height!, translation!, Optional slices& = 8, Optional stacks& = 8)
Dim nx!, ny!, nz!
Dim nStepW!, nStepH!
Dim X!, Y!, z!, s!, t!, ds!, dt!
    Select Case direction
    Case dirFront: nz = 1
    Case dirBack: nz = -1
    Case dirLeft: nx = 1
    Case dirRight: nx = -1
    Case dirTop: ny = -1
    Case dirBottom: ny = 1
    End Select
    glNormal3f nx, ny, nz
    'texture
    ds = 1 / slices
    dt = 1 / stacks
    nStepW = Width / slices
    nStepH = Height / stacks
    For X = -Width / 2 To Width / 2 - nStepW Step nStepW
        glBegin GL_QUAD_STRIP
            For Y = -Height / 2 To Height / 2 Step nStepH
                glTexCoord2f s, t
                Select Case direction
                Case dirFront:
                    glVertex3f X, Y, translation
                    glTexCoord2f s + ds, t
                    glVertex3f X + nStepW, Y, translation
                Case dirLeft:
                    glVertex3f translation, Y, -X
                    glTexCoord2f s + ds, t
                    glVertex3f translation, Y, -X - nStepW
                Case dirBack:
                    glVertex3f -X, Y, translation
                    glTexCoord2f s + ds, t
                    glVertex3f -X - nStepW, Y, translation
                Case dirRight:
                    glVertex3f translation, Y, X
                    glTexCoord2f s + ds, t
                    glVertex3f translation, Y, X + nStepW
                Case dirTop: 'facing down
                    glVertex3f X, translation, Y
                    glTexCoord2f s + ds, t
                    glVertex3f X + nStepW, translation, Y
                Case dirBottom: 'facing up
                    glVertex3f X, translation, -Y
                    glTexCoord2f s + ds, t
                    glVertex3f X + nStepW, translation, -Y
                End Select
                t = t + dt
            Next
        glEnd
        s = s + ds
        t = 0
    Next
End Sub

'----------------------------------------------------------------------------
'write the Pics struct to disk
'----------------------------------------------------------------------------
Public Function Save(fn&, Path$) As Boolean
Dim i&, dest$, s$, file$, cnt&
Dim p2 As BKGREC
On Error GoTo EH
    If optCopyImages And Pics.NumUrls Then
        'make a new struct, because we want to save
        'the filename only, not the path.
        p2.BkgMode = Pics.BkgMode
        For i = 0 To Pics.NumUrls - 1
            If Len(Pics.Urls(i)) Then
                cnt = cnt + 1
            Else
                Exit For
            End If
        Next
        p2.NumUrls = cnt
        If p2.NumUrls > 0 Then
            ReDim p2.Urls(0 To p2.NumUrls - 1)
            'write the file name w/out a path.
            'Change full path in Pics.Urls to
            'point to the save directory
            For i = 0 To Pics.NumUrls - 1
                file = ExtractFileName(Pics.Urls(i))
                dest = Path & "\" & file
                s = Dir(dest)
                If Len(s) = 0 Then
                    FileCopy Pics.Urls(i), dest
                End If
                p2.Urls(i) = file
                Pics.Urls(i) = dest
            Next
        End If
        Put #fn, , p2
    Else
        Put #fn, , Pics
    End If
    Save = True
    Exit Function
EH:
    Debug.Print Err.Description
    Debug.Assert 0
    MsgBox "Error saving background." & vbCrLf & Err.Description
    Exit Function
    Resume Next
End Function

'----------------------------------------------------------------------------
'load the files
'----------------------------------------------------------------------------
Public Function Load(fn&, Path$) As Boolean
Dim s$, i&
    Get fn, , Pics
    'verify the files
    If Pics.NumUrls Then
        For i = 0 To Pics.NumUrls - 1
            If Len(Pics.Urls(i)) = 0 Then
                Debug.Assert 0
                'do something. In this case I'm just going to abort
                Clear
                Exit Function
            ElseIf InStr(Pics.Urls(i), "\") = 0 Then
                'we have a file name of a file in the doc dir
                Pics.Urls(i) = Path & "\" & Pics.Urls(i)
            End If
        Next
        Load = m_LoadUrls
    Else: Load = True
    End If
End Function


