RasterSaver 1.00 - Screen Saver
===============================

James Ward (espresso@crema.co.uk)
3rd April 2002

This is the source code for the "RasterSaver" OpenGL screen saver.
Strangely, I wrote this in July 2001 and for some reason only just
got around to releasing it..

Introduction
------------

Have you ever noticed that in the background of any self respecting
SciFi anime movie, there will be a monitor covered in strange
scrolling symbols (usually green), mysterious spinning objects and
the odd burst of static or snow?

Well, this is my homage to all those movies.. now you can give your
own office that "Manga Techno Lab" ambience by installing this
screen saver. For an even better effect, dangle some wires from the
roof, install some panels of flashing lights and (optionally) a few
giant robots.

Working with the sources
------------------------

FIRST: Install the screen saver - this will copy the required
textures and 3D models, and create registry settings that allow
the screen saver executable to locate them. Otherwise you will not
be able to view the screen saver properly from within the compiler.

There is a project workspace provided for MS Visual C++ version 6,
and it shouldn't be too difficult to create equivalents for other
compilers if required.

The screen saver uses some simple classes to wrap the screen saver
library:

  Saver   - This is a generic OpenGL screen saver. You shouldn't
            normally need to alter this class, unless you find a bug
            or need to add some more obscure features.

  MySaver - This contains the implementation of the screen saver
            itself, and contains all the custom drawing code. You
            can replace this class to create other screen savers
            based on this template.

There is also a fairly basic model loader that can load ASE format
files (which can be created using 3D Studio MAX for example).

The source code serves as a good example of how not to write this
sort of thing. I'm providing it because I like the idea of sharing,
and people are often curious how these things are implemented :)
