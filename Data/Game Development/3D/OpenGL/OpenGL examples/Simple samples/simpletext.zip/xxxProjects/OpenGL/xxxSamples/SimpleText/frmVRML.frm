VERSION 5.00
Begin VB.Form frmVRML 
   Caption         =   "Form1"
   ClientHeight    =   4830
   ClientLeft      =   405
   ClientTop       =   2415
   ClientWidth     =   5085
   LinkTopic       =   "Form1"
   ScaleHeight     =   322
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   339
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   50
      Left            =   180
      Top             =   135
   End
   Begin VB.Menu mnuScene 
      Caption         =   "Scene"
      Begin VB.Menu mnuScene1 
         Caption         =   "Scene1"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuScene2 
         Caption         =   "Scene2"
      End
   End
End
Attribute VB_Name = "frmVRML"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim WithEvents GL As COpenGL
Dim SCENE1&, SCENE2&, JACK&
Dim m_Scene1&, m_Scene2&
Dim m_Angle!

Private Sub Form_Initialize()
Dim obj&
Set GL = New COpenGL
GL.Initialize hwnd, hDC
'create 2 scenes
SCENE1 = glGenLists(1)
glPushMatrix
    glNewList SCENE1, GL_COMPILE
    DrawText ARIAL36, "OpenGL in Visual Basic", -5, 1, 0, vbWhite
    glEndList
glPopMatrix
SCENE2 = glGenLists(1)
glPushMatrix
    glNewList SCENE2, GL_COMPILE
    DrawText ARIAL36, "VRML2", -1.5, -1, 0, vbWhite
    glEndList
glPopMatrix
JACK = glGenLists(1)
glPushMatrix
    glNewList JACK, GL_COMPILE
        glColor3f 0.5, 0.8, 0.8
        obj = gluNewQuadric
        glTranslatef 0, 0, -1.5
        gluCylinder obj, 0.2, 0.2, 3, 16, 16
        glTranslatef -1.5, 0, 1.5
        glRotatef 90, 0, 1, 0
        gluCylinder obj, 0.2, 0.2, 3, 16, 16
        glTranslatef 0, 1.5, 1.5
        glRotatef 90, 1, 0, 0
        gluCylinder obj, 0.2, 0.2, 3, 16, 16
    glEndList
glPopMatrix
m_Scene1 = True
End Sub

Private Sub Form_Paint()
GL.Display
End Sub

Private Sub Form_Resize()
Static W&, H&
Dim w1&, h1&
    w1 = ScaleWidth
    h1 = ScaleHeight
    GL.OnSize w1, h1
    If w1 <= W And h1 <= H Then GL.Display 'force a repaint
    W = w1: H = h1
End Sub

Private Sub GL_OnDisplay()
Dim obj&
'insert any extra drawing here
If m_Scene1 Then glCallList SCENE1
If m_Scene2 Then
    glCallList SCENE2
    glPushMatrix
        glTranslatef 0, -4, 0
        glRotatef m_Angle, 1, 1, 1
        glCallList JACK
    glPopMatrix
    glPushMatrix
        glColor3f 0.5, 0.8, 0.1
        glRotatef m_Angle, 0, 1, 0
        glTranslatef -4, -4, 0
        obj = gluNewQuadric
        gluSphere obj, 0.5, 16, 16
    glPopMatrix
End If
End Sub

Private Sub mnuScene1_Click()
mnuScene1.Checked = Not mnuScene1.Checked
m_Scene1 = mnuScene1.Checked
Form_Paint
End Sub

Private Sub mnuScene2_Click()
mnuScene2.Checked = Not mnuScene2.Checked
m_Scene2 = mnuScene2.Checked
Timer1.Enabled = m_Scene2
Form_Paint
End Sub

Private Sub Timer1_Timer()
m_Angle = m_Angle + 15
If m_Angle = 360 Then m_Angle = 0
Form_Paint
End Sub
