/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public class CheckBox : Button
    {
        public CheckBox(Font font) : base(font)
        {
            base.Focusable = true;
            base.BackgroundColor = Color.Green;
            this.HoverColor = Color.DarkGreen;
            base.BorderColor = Color.Black;
            base.Tint = Color.White;
            this.Width = 50f;
            this.Height = 50f;
        }
        public CheckBox(Font font, bool check)
            : this(font)
        {
            m_Checked = check;
        }
        public override void OnKeyDown(KeyboardEventArgs e)
        {
            if (e.Key == Keys.Space)
                Press();
        }
        public override void Press()
        {
            m_Checked = !m_Checked;
            base.Press();
        }
        private bool m_Checked = false;
        public bool Checked
        {
            get { return m_Checked; }
            set { m_Checked = value; }
        }
        public override string Text
        {
            get{ return m_Checked ? "X" : ""; }
            set
            {
                if (value == bool.TrueString)
                    m_Checked = true;
				else if(value == bool.FalseString)
					m_Checked = false;
                else if (value == "X")
                    m_Checked = true;
                else if (value == "")
                    m_Checked = false;
            }
        }
    }
}
