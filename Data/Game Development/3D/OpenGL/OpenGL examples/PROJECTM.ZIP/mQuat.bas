Attribute VB_Name = "mQuat"
Option Explicit

'-------------------------------------------------------------------------------------
Public Sub QuatOne(q!())
    q(0) = 0
    q(1) = 0
    q(2) = 0
    q(3) = 1
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatCopy(qTo!(), qFrom!())
    qTo(0) = qFrom(0)
    qTo(1) = qFrom(1)
    qTo(2) = qFrom(2)
    qTo(3) = qFrom(3)
End Sub

'-------------------------------------------------------------------------------------
' Given an axis and angle, compute quaternion.
'-------------------------------------------------------------------------------------
Public Sub QuatFromAxis(q!(), x!, y!, z!, Angle!)
    q(0) = x
    q(1) = y
    q(2) = z
    QuatNormal q
    QuatScale q, Sin(Angle / 2)
    q(3) = Cos(DegToRadf(Angle) / 2)
End Sub

Public Sub QuatFromAxisv(q!(), Axis!(), Angle!)
    q(0) = Axis(0)
    q(1) = Axis(1)
    q(2) = Axis(2)
    QuatNormal q
    QuatScale q, Sin(Angle / 2)
    q(3) = Cos(DegToRadf(Angle) / 2)
End Sub

Public Sub QuatFromAxisRadv(q!(), Axis!(), Angle!)
    q(0) = Axis(0)
    q(1) = Axis(1)
    q(2) = Axis(2)
    QuatNormal q
    QuatScale q, Sin(Angle / 2)
    q(3) = Cos(Angle / 2)
End Sub

'-------------------------------------------------------------------------------------
' Return quaternion product qL * qR.  Note: order is important!
' To combine rotations, use the product Mul(qSecond, qFirst),
' which gives the effect of rotating by qFirst then qSecond.
'-------------------------------------------------------------------------------------
Public Sub QuatMultiply(qL!(), qR!(), q!())
Dim i&, qq!(0 To 3)
    qq(3) = qL(3) * qR(3) - qL(0) * qR(0) - qL(1) * qR(1) - qL(2) * qR(2)
    qq(0) = qL(3) * qR(0) + qL(0) * qR(3) + qL(1) * qR(2) - qL(2) * qR(1)
    qq(1) = qL(3) * qR(1) + qL(1) * qR(3) + qL(2) * qR(0) - qL(0) * qR(2)
    qq(2) = qL(3) * qR(2) + qL(2) * qR(3) + qL(0) * qR(1) - qL(1) * qR(0)
    For i = 0 To 3
        q(i) = qq(i)
    Next
End Sub

'-------------------------------------------------------------------------------------
' Return conjugate of quaternion.
Public Sub QuatConj(q!(), qconj!())
    qconj(0) = -q(0)
    qconj(1) = -q(1)
    qconj(2) = -q(2)
    qconj(3) = q(3)
End Sub

Public Sub QuatToAxis(q!(), x!, y!, z!, Angle!)
Dim lng!, q1!(0 To 3), s!
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    If lng > 0.00001 Then
        QuatScale2 q1, q, 1 / lng
        x = q1(0)
        y = q1(1)
        z = q1(2)
        Angle = RadToDegf(2 * ArcCos(q(3)))
    Else
        x = 0
        y = 0
        z = 1
        Angle = 0
    End If
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatNormal(q!())
Dim lng!
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    QuatScale q, 1 / lng
End Sub

'-------------------------------------------------------------------------------------
' Return version of v scaled by s
Public Sub QuatScale(q!(), s!)
    q(0) = s * q(0)
    q(1) = s * q(1)
    q(2) = s * q(2)
End Sub

'-------------------------------------------------------------------------------------
' Return version of v scaled by s
Public Sub QuatScale2(qDest!(), q!(), s!)
    qDest(0) = s * q(0)
    qDest(1) = s * q(1)
    qDest(2) = s * q(2)
End Sub

'-------------------------------------------------------------------------------------
' Construct rotation matrix from (possibly non-unit) quaternion.
' * Assumes matrix is used to multiply column vector on the left:
' * vnew = mat vold.  Works correctly for right-handed coordinate system
' * and right-handed rotations.
'-------------------------------------------------------------------------------------
Public Sub QuatToMatrix(q!(), mOut!())
Dim Nq!, s!, xs!, ys!, zs!, wx!, wy!, wz!
Dim xx!, xy!, xz!, yy!, yz!, zz!
On Error GoTo EH
    Nq = q(0) * q(0) + q(1) * q(1) + q(2) * q(2) + q(3) * q(3)
    If Nq > 0 Then
        s = 2 / Nq
    Else: s = 0
    End If
    xs = q(0) * s
    ys = q(1) * s
    zs = q(2) * s
    wx = q(3) * xs
    wy = q(3) * ys
    wz = q(3) * zs
    xx = q(0) * xs
    xy = q(0) * ys
    xz = q(0) * zs
    yy = q(1) * ys
    yz = q(1) * zs
    zz = q(2) * zs
    mOut(0) = 1 - (yy + zz)
    mOut(4) = xy + wz
    mOut(8) = xz - wy
    '
    mOut(1) = xy - wz
    mOut(5) = 1 - (xx + zz)
    mOut(9) = yz + wx
    '
    mOut(2) = xz + wy
    mOut(6) = yz - wx
    mOut(10) = 1 - (xx + yy)
    '
    mOut(3) = 0
    mOut(7) = 0
    mOut(11) = 0
    mOut(12) = 0
    mOut(13) = 0
    mOut(14) = 0
    mOut(15) = 1
    Exit Sub
EH:
    Debug.Assert 0
End Sub

