Attribute VB_Name = "glxQuats"
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: quaternion routines.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'NOTES: Use at your own risk!
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------------------
'  Project an x,y pair onto a sphere of radius r OR a hyperbolic sheet
'  if we are away from the center of the sphere.
'-------------------------------------------------------------------------------------
Public Function ProjectToSphere!(ByVal r!, ByVal X!, ByVal Y!)
Dim d!, t!, z!
On Error GoTo EH
    d = Sqr(X * X + Y * Y)
    If (d < r * 0.707106781186548) Then    '     Inside sphere
        z = Sqr(r * r - d * d)
    Else '         On hyperbola
        t = r / 1.4142135623731
        z = t * t / d
    End If
    ProjectToSphere = z
    Exit Function
EH:
    Debug.Assert 0
    Exit Function
End Function

'-------------------------------------------------------------------------------------
'these routines come mostly from Ken Shoemakes
'**** BallAux.c ****
'-------------------------------------------------------------------------------------
' Return quaternion product qL * qR.  Note: order is important!
' To combine rotations, use the product Mul(qSecond, qFirst),
' which gives the effect of rotating by qFirst then qSecond.
'-------------------------------------------------------------------------------------
Public Sub QuatMultiply(qL!(), qR!(), q!())
Dim i&, qq!(0 To 3)
    qq(3) = qL(3) * qR(3) - qL(0) * qR(0) - qL(1) * qR(1) - qL(2) * qR(2)
    qq(0) = qL(3) * qR(0) + qL(0) * qR(3) + qL(1) * qR(2) - qL(2) * qR(1)
    qq(1) = qL(3) * qR(1) + qL(1) * qR(3) + qL(2) * qR(0) - qL(0) * qR(2)
    qq(2) = qL(3) * qR(2) + qL(2) * qR(3) + qL(0) * qR(1) - qL(1) * qR(0)
    For i = 0 To 3
        q(i) = qq(i)
    Next
End Sub

'-------------------------------------------------------------------------------------
' Given an axis and angle, compute quaternion.
'-------------------------------------------------------------------------------------
Public Sub QuatFromAxis(q!(), Axis!(), Angle!)
On Error GoTo EH
    q(0) = Axis(0)
    q(1) = Axis(1)
    q(2) = Axis(2)
    QuatNormal q
    QuatScale q, Sin(Angle / 2)
    q(3) = Cos(DegToRadf(Angle) / 2)
    Exit Sub
EH:
    Debug.Assert 0
End Sub

Public Sub QuatFromAxisRad(q!(), Axis!(), Angle!)
On Error GoTo EH
    q(0) = Axis(0)
    q(1) = Axis(1)
    q(2) = Axis(2)
    QuatNormal q
    QuatScale q, Sin(Angle / 2)
    q(3) = Cos(Angle / 2)
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
' * Quaternions always obey:  a^2 + b^2 + c^2 + d^2 = 1.0
' * If they don't add up to 1.0, dividing by their magnitued will
' * renormalize them.
' *
' * Note: See the following for more information on quaternions:
' *
' * - Shoemake, K., Animating rotation with quaternion curves, Computer
' *   Graphics 19, No 3 (Proc. SIGGRAPH'85), 245-254, 1985.
' * - Pletinckx, D., Quaternion calculus as a basic tool in computer
' *   graphics, The Visual Computer 5, 2-13, 1989.
Public Sub QuatNormalize(q!())
Dim i&, mag!
On Error GoTo EH
    mag = q(0) * q(0) + q(1) * q(1) + q(2) * q(2) + q(3) * q(3)
    For i = 0 To 3
        q(i) = q(i) / mag
    Next
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatNormal(q!())
Dim lng!
On Error GoTo EH
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    QuatScale q, 1 / lng
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
' Return version of v scaled by s
Public Sub QuatScale(q!(), s!)
    q(0) = s * q(0)
    q(1) = s * q(1)
    q(2) = s * q(2)
End Sub

'-------------------------------------------------------------------------------------
' Return version of v scaled by s
Public Sub QuatScale2(qDest!(), q!(), s!)
    qDest(0) = s * q(0)
    qDest(1) = s * q(1)
    qDest(2) = s * q(2)
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatFromMatrix(q!(), m!())
Dim tr!, s!, i&, j&, k&, qt!(0 To 3)
Dim nxt&(0 To 2)
On Error GoTo EH
    'const int nxt[3] = { 1, 2, 0 }
    nxt(0) = 1: nxt(1) = 2: nxt(2) = 0
    tr = m(0) + m(5) + m(10)
    If (tr > 0) Then
         s = Sqr(tr + 1)
         qt(3) = s * 0.5
         s = 0.5 / s
    
         qt(0) = (m(6) - m(9)) * s
         qt(1) = (m(8) - m(2)) * s
         qt(2) = (m(1) - m(4)) * s
    Else
         i = 0
         If (m(5) > m(0)) Then
            i = 1
         End If
         If (m(10) > m(i * 4) + i) Then
            i = 2
         End If
         
         j = nxt(i)
         k = nxt(j)
         
         s = Sqr((m(i * 4 + i) - (m(j * 4 + j) + m(k * 4 + k))) + 1) '??
         
         qt(i) = s * 0.5
         s = 0.5 / s
         
         qt(3) = (m(j * 4 + k) - m(k * 4 + j)) * s
         qt(j) = (m(i * 4 + j) + m(j * 4 + i)) * s
         qt(k) = (m(i * 4 + k) + m(k * 4 + i)) * s
    End If
    
        q(0) = qt(0)
        q(1) = qt(1)
        q(2) = qt(2)
        q(3) = qt(3)
    Exit Sub
EH:
    Debug.Assert 0
End Sub

Public Sub QuatToAxis(q!(), Axis!(), Angle!)
Dim lng!, q1!(0 To 3), s!
On Error GoTo EH
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    If lng > 0.00001 Then
        QuatScale2 q1, q, 1 / lng
        Axis(0) = q1(0)
        Axis(1) = q1(1)
        Axis(2) = q1(2)
        Angle = RadToDegf(2 * ArcCos(q(3)))
    Else
        Axis(0) = 0
        Axis(1) = 0
        Axis(2) = 1
        Angle = 0
    End If
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------------------
' Construct rotation matrix from (possibly non-unit) quaternion.
' * Assumes matrix is used to multiply column vector on the left:
' * vnew = mat vold.  Works correctly for right-handed coordinate system
' * and right-handed rotations.
'-------------------------------------------------------------------------------------
Public Sub QuatToMatrix(q!(), mOut!())
Dim Nq!, s!, xs!, ys!, zs!, wx!, wy!, wz!
Dim xx!, xy!, xz!, yy!, yz!, zz!
On Error GoTo EH
    Nq = q(0) * q(0) + q(1) * q(1) + q(2) * q(2) + q(3) * q(3)
    If Nq > 0 Then
        s = 2 / Nq
    Else: s = 0
    End If
    xs = q(0) * s
    ys = q(1) * s
    zs = q(2) * s
    wx = q(3) * xs
    wy = q(3) * ys
    wz = q(3) * zs
    xx = q(0) * xs
    xy = q(0) * ys
    xz = q(0) * zs
    yy = q(1) * ys
    yz = q(1) * zs
    zz = q(2) * zs
    mOut(0) = 1 - (yy + zz)
    mOut(4) = xy + wz
    mOut(8) = xz - wy
    '
    mOut(1) = xy - wz
    mOut(5) = 1 - (xx + zz)
    mOut(9) = yz + wx
    '
    mOut(2) = xz + wy
    mOut(6) = yz - wx
    mOut(10) = 1 - (xx + yy)
    '
    mOut(3) = 0
    mOut(7) = 0
    mOut(11) = 0
    mOut(12) = 0
    mOut(13) = 0
    mOut(14) = 0
    mOut(15) = 1
    Exit Sub
EH:
    Debug.Assert 0
End Sub

Public Sub QuatToMatrixBell(q!(), m!())
    m(0) = 1 - 2 * (q(1) * q(1) + q(2) * q(2))
    m(1) = 2 * (q(0) * q(1) - q(2) * q(3))
    m(2) = 2 * (q(2) * q(0) + q(1) * q(3))
    m(3) = 0

    m(4) = 2 * (q(0) * q(1) + q(2) * q(3))
    m(5) = 1 - 2 * (q(2) * q(2) + q(0) * q(0))
    m(6) = 2 * (q(1) * q(2) - q(0) * q(3))
    m(7) = 0

    m(8) = 2 * (q(2) * q(0) - q(1) * q(3))
    m(9) = 2 * (q(1) * q(2) + q(0) * q(3))
    m(10) = 1 - 2 * (q(1) * q(1) + q(0) * q(0))
    m(11) = 0

    m(12) = 0
    m(13) = 0
    m(14) = 0
    m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
' Return conjugate of quaternion.
Public Sub QuatConj(q!(), qconj!())
    qconj(0) = -q(0)
    qconj(1) = -q(1)
    qconj(2) = -q(2)
    qconj(3) = q(3)
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatOne(q!())
    q(0) = 0
    q(1) = 0
    q(2) = 0
    q(3) = 1
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatCopy(qTo!(), qFrom!())
    qTo(0) = qFrom(0)
    qTo(1) = qFrom(1)
    qTo(2) = qFrom(2)
    qTo(3) = qFrom(3)
End Sub

'-------------------------------------------------------------------------------------
Public Sub QuatAdd(qDest!(), q1!(), q2!())
Dim t1!(0 To 3), t2!(0 To 3), t3!(0 To 3)
Dim tf!(0 To 3)
Dim dot!

    V3Copyf t1, q1
    V3Scalef t1, q2(3), t1
    V3Copyf t2, q2
    V3Scalef t2, q1(3), t2
    
    V3Crossf t3, q2, q1
    V3Sumf tf, t1, t2
    V3Sumf tf, t3, tf
    V3Dotf dot, q1, q2
    tf(3) = q1(3) * q2(3) - dot

    qDest(0) = tf(0)
    qDest(1) = tf(1)
    qDest(2) = tf(2)
    qDest(3) = tf(3)
End Sub

'-------------------------------------------------------------------------
' * Ok, simulate a track-ball.  Project the points onto the virtual
' * trackball, then figure out the axis of rotation, which is the cross
' * product of P1 P2 and O P1 (O is the center of the ball, 0,0,0)
' * Note:  This is a deformed trackball-- is a trackball in the center,
' * but is deformed into a hyperbolic sheet of rotation away from the
' * center.  This particular function was chosen after trying out
' * several variations.
' * It is assumed that the arguments to this routine are in the range
' * (-1.0 ... 1.0)
Public Sub QuatTrackball(q!(), p1x!, p1y!, p2x!, p2y!, Optional TRACKBALLSIZE! = 0.8)
Dim A!(0 To 2) '  Axis of rotation
Dim phi! '   how much to rotate about axis
Dim p1!(0 To 2), p2!(0 To 2), d!(0 To 2)
Dim t!
    If (p1x = p2x And p1y = p2y) Then
        ' Zero rotation
        V3Zerof q
        q(3) = 1
        Exit Sub
    End If
    '
    ' * First, figure out z-coordinates for projection of P1 and P2 to
    ' * deformed sphere
    V3Makef p1, p1x, p1y, ProjectToSphere(TRACKBALLSIZE, p1x, p1y)
    V3Makef p2, p2x, p2y, ProjectToSphere(TRACKBALLSIZE, p2x, p2y)
    '
    ' *  Now, we want the cross product of P1 and P2
    V3Crossf A, p2, p1
    '
    ' *  Figure out how much to rotate around that axis.
    V3Subf d, p1, p2
    V3Lengthf t, d
    t = t / (2 * TRACKBALLSIZE)

    ' * Avoid problems with out-of-control values...
    If (t > 1) Then t = 1
    If (t < -1) Then t = -1
    phi = 2 * ArcSin(t)

    QuatFromAxisRad q, A, phi
    'Debug.Print phi
End Sub

