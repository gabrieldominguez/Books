#include <iostream>
#include <GL/glut.h>
#include <glui.h>

//void myGlutInit(){;}
//void myGlutKeyboard(unsigned char Key, int x, int y){;}
void myGlutMenu( int value ){;}
//void myGlutIdle( void ){;}
//void myGlutMouse(int button, int button_state, int x, int y ){;}
//void myGlutMotion(int x, int y ){;}
// void myGlutReshape( int x, int y ){;}
//void myGlutDisplay( void ){;}
//void control_cb( int ID ){;}

int WindW, WindH;

void control_cb(int eleccion)
{ //muestra quien llam�
  switch (eleccion)
  {
    case 1:
      cout << "Llamo Checkbox." << endl;
      break;
    case 2:
      cout << "Llamo Boton de Radio" << endl;
      break;
  }
}

static void TeclaPulsada(unsigned char key, int x, int y)
{ // key es el valor ASCII de la tecla pulsada
  // x e y indica la posici�n del mouse.
  // Pasando NULL desabilita la generaci�n de llamado a esta funci�n por
  // eventos del teclado.
  switch (key)
  {
    case 27: exit(0);
             break;
  }
}

void Dibujar(void)
{
  glClear(GL_COLOR_BUFFER_BIT);

  glColor3f(1.0f, 1.0f, 1.0f);
  // glRasterPos2f(-0.95f, 0);

  // hacer una esfera.
  // hacer un toroide o esfera seg�n lo que elija....


  // Llamado a "dibujar" el texto
  //dibujar_string_bitmap(GLUT_BITMAP_TIMES_ROMAN_24,
  //                      "Pulsar boton derecho del mouse");

  glutSwapBuffers();   // realiza un impl�cito glFlush()
}

void RefrescarPantalla(int width, int height)
{
  glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(-1, 1, -1, 1);
  glMatrixMode(GL_MODELVIEW);

  WindW = width;
  WindH = height;
}


int main(int argc, char* argv[])
{
  WindW = 400;
  WindH = 300;

  // Inicializaci�n de GLUT en forma normal ====================================

  glutInit(&argc, argv);
  glutInitWindowSize(WindW, WindH);

  glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
  glutInitWindowPosition( 50, 50 );
  glutInitWindowSize( 300, 300 );

  int main_window;
  main_window = glutCreateWindow( "GLUI test app" );

  glutKeyboardFunc( TeclaPulsada );
  glutDisplayFunc(Dibujar);
  glutReshapeFunc( RefrescarPantalla );

  //glutMotionFunc( myGlutMotion );
  //glutMouseFunc( myGlutMouse );
  //myGlutInit();

  // Creaci�n de la interfaz GLUI ==============================================

  GLUI *glui = GLUI_Master.create_glui ( "GLUI", 0 );

  // Texto estatico
  glui->add_statictext( "Simple Ejemplo de GLUI" );

  // Separador
  glui->add_separator();

  // Chechbox
  int wireframe = 1;
  glui->add_checkbox( "Wireframe", &wireframe, 1, control_cb );

  // spinner. GLUI_SPINNER_INT significa tipo de datos enteros
  int segments = 5;
  GLUI_Spinner *segment_spinner =
  glui->add_spinner( "Segments:",GLUI_SPINNER_INT, &segments );
  segment_spinner->set_int_limits( 3, 60, GLUI_LIMIT_WRAP );

  // Edit Text
  char text[30];
  GLUI_EditText *edittext = glui->add_edittext("Text:",GLUI_EDITTEXT_TEXT,&text);

  // Agrega un separador. True indica que es en forma vertical
  glui->add_column(true);

  // Se realiza un panel
  GLUI_Panel *obj_panel = glui->add_panel ( "Object Type" );

  // Boton de Radio (agregado dentro del panel)
  int obj = 1;
  GLUI_RadioGroup *group1 =
  glui->add_radiogroup_to_panel(obj_panel,&obj,2,control_cb);

  glui->add_radiobutton_to_group( group1, "Sphere" );
  glui->add_radiobutton_to_group( group1, "Torus" );
  glui->add_button( "Quit", 0,(GLUI_Update_CB)exit );

  // Conexta a glui con la ventana principal
  glui->set_main_gfx_window( main_window );

  /** Register the Idle callback with GLUI (instead of with GLUT) **/
  //GLUI_Master.set_glutIdleFunc( myGlutIdle );
  GLUI_Master.set_glutIdleFunc( NULL );

  // Llamado al GLUT main loop
  glutMainLoop();

  return (0);
}
