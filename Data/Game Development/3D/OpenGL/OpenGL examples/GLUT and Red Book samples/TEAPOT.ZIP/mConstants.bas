Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CTeapot
'
Public Const PI = 3.141592654
Public xRotation!, yRotation!, zTranslation!
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayl(a&(), ParamArray n())
Dim i&, j&, k&
    For i = 0 To 9
    For j = 0 To 15
        a(i, j) = n(k)
        k = k + 1
    Next
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArray3f(a!(), ndx&, ParamArray n())
Dim i&, k&
    For i = ndx To ndx + 4
        a(i, 0) = n(k)
        a(i, 1) = n(k + 1)
        a(i, 2) = n(k + 2)
        k = k + 3
    Next
End Sub

