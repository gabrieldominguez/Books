class AwesomeGame extends UTDeathmatch;

defaultproperties
{
    PlayerControllerClass=class'AwesomeGame.AwesomePlayerController'
}
