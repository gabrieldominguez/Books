VERSION 5.00
Begin VB.Form Form1 
   Appearance      =   0  'Flat
   Caption         =   "3 Lights"
   ClientHeight    =   5655
   ClientLeft      =   375
   ClientTop       =   2055
   ClientWidth     =   8010
   LinkTopic       =   "Form1"
   ScaleHeight     =   377
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   534
   Begin VB.PictureBox Dummy 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      ForeColor       =   &H80000008&
      Height          =   285
      Left            =   90
      ScaleHeight     =   19
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   16
      TabIndex        =   6
      TabStop         =   0   'False
      Top             =   1035
      Width           =   240
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   7500
      Top             =   4260
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   225
      LargeChange     =   15
      Left            =   5580
      Max             =   360
      TabIndex        =   2
      Top             =   960
      Width           =   975
   End
   Begin VB.VScrollBar VScroll1 
      Height          =   1095
      LargeChange     =   10
      Left            =   2880
      Max             =   -90
      Min             =   90
      TabIndex        =   1
      Top             =   840
      Value           =   -90
      Width           =   225
   End
   Begin VB.Frame Frame1 
      Height          =   975
      Left            =   0
      TabIndex        =   0
      Top             =   -45
      Width           =   7935
      Begin VB.OptionButton Option3 
         Caption         =   "Lamp 3"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   240
         Left            =   180
         TabIndex        =   5
         Top             =   660
         Width           =   1575
      End
      Begin VB.OptionButton Option2 
         Caption         =   "Lamp 2"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000C000&
         Height          =   240
         Left            =   180
         TabIndex        =   4
         Top             =   420
         Width           =   1575
      End
      Begin VB.OptionButton Option1 
         Caption         =   "Lamp 1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   180
         TabIndex        =   3
         Top             =   180
         Width           =   1575
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: simple demo of light position
'AUTHOR:Ferrari, Jose Antonio 8/98
'HISTORY: -
'/*************************************************************************
Dim m_hGLRC As Long '
Const jl = 320
Dim lamp1(0 To 2, 0 To 2) As Single
Dim lamp2(0 To 2, 0 To 2) As Single
Dim lamp3(0 To 2, 0 To 2) As Single

Dim lamp1_posi(0 To 1) As Integer
Dim lamp2_posi(0 To 1) As Integer
Dim lamp3_posi(0 To 1) As Integer
Dim rot As Integer
Const pi = 3.14159265359
'
'sizing
Const SCROLLBARSIZE = 15
Const FRAMEHEIGHT = 70

Sub SetDefaults()
lamp1(0, 0) = 0.7
lamp1(1, 0) = 0.7
lamp1(2, 0) = 0.7

lamp1(0, 1) = 1
lamp1(1, 1) = 0.2
lamp1(2, 1) = 0.2

lamp1(0, 2) = 0.3
lamp1(1, 2) = 0.3
lamp1(2, 2) = 0.3
'========
lamp2(0, 0) = 0.7
lamp2(1, 0) = 0.7
lamp2(2, 0) = 0.7

lamp2(0, 1) = 0.2
lamp2(1, 1) = 1
lamp2(2, 1) = 0.2

lamp2(0, 2) = 0.3
lamp2(1, 2) = 0.3
lamp2(2, 2) = 0.3
'==============
lamp3(0, 0) = 0.7
lamp3(1, 0) = 0.7
lamp3(2, 0) = 0.7

lamp3(0, 1) = 0.2
lamp3(1, 1) = 0.2
lamp3(2, 1) = 1

lamp3(0, 2) = 0.3
lamp3(1, 2) = 0.3
lamp3(2, 2) = 0.3
'*******************************************
lamp1_posi(0) = 0
lamp1_posi(1) = 80

lamp2_posi(0) = 120
lamp2_posi(1) = 25

lamp3_posi(0) = 240
lamp3_posi(1) = 25

End Sub

Function Initialize() As Boolean
Dim pfd As PIXELFORMATDESCRIPTOR
Dim r&, pos!(0 To 3)
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    r = ChoosePixelFormat(hDC, pfd)
    If r = 0 Then
        MsgBox "Fail"
        Initialize = False
        Exit Function
    End If
    r = SetPixelFormat(hDC, r, pfd)
 
    m_hGLRC = wglCreateContext(hDC)
    wglMakeCurrent hDC, m_hGLRC

    glClearColor 0, 0, 0, 1
    glClearDepth 1
    glShadeModel (GL_SMOOTH)
    
    glEnable GL_DEPTH_TEST
  
    '========
        glEnable (GL_LIGHTING)
        glEnable (GL_LIGHT0)
        glEnable (GL_LIGHT1)
        glEnable (GL_LIGHT2)
        SetDefaults
        glLightfv GL_LIGHT0, GL_AMBIENT, lamp1(0, 0)
        glLightfv GL_LIGHT0, GL_DIFFUSE, lamp1(0, 1)
        glLightfv GL_LIGHT0, GL_SPECULAR, lamp1(0, 2)
        
        glLightfv GL_LIGHT1, GL_AMBIENT, lamp2(0, 0)
        glLightfv GL_LIGHT1, GL_DIFFUSE, lamp2(0, 1)
        glLightfv GL_LIGHT1, GL_SPECULAR, lamp2(0, 2)
                
        glLightfv GL_LIGHT2, GL_AMBIENT, lamp3(0, 0)
        glLightfv GL_LIGHT2, GL_DIFFUSE, lamp3(0, 1)
        glLightfv GL_LIGHT2, GL_SPECULAR, lamp3(0, 2)
    Initialize = True
    
End Function

Sub EndProc()
    If m_hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hGLRC
    End If
End Sub

Sub Draw()
Dim obj As Long

obj = gluNewQuadric

glPushMatrix
  
    glColor4f 0.2, 0.2, 0.2, 1
    gluSphere obj, 50, 16, 16
   
    glTranslatef 0, 100, -25
    gluCylinder obj, 40, 0, 65, 16, 16
  
glPopMatrix

End Sub

Sub Render()
Static Busy As Boolean
Static rotacao As Integer, rz As Integer

    If Busy Then Exit Sub
    Busy = True
    '
    wglMakeCurrent hDC, m_hGLRC
    '=================================================
        
    glClear clrColorBufferBit Or clrDepthBufferBit
    'SetViewport
    lamps
    draw_lamps
    
    glPushMatrix
        glRotated rot, 0, 0, 1
        Draw
    glPopMatrix
     
    '=================================================
    SwapBuffers hDC
    '
    wglMakeCurrent 0, 0
    Busy = False
End Sub

Sub lamps()
Dim posix As Double, posiy As Double, posiz As Double
Dim posit1(0 To 3) As Single
Dim posit2(0 To 3) As Single
Dim posit3(0 To 3) As Single
   
    polar_cartz lamp1_posi(0), lamp1_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
    
    posit1(0) = posix: posit1(1) = posiy: posit1(2) = posiz: posit1(3) = 1
    glLightfv GL_LIGHT0, GL_POSITION, posit1(0)
    
    polar_cartz lamp2_posi(0), lamp2_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
    posit2(0) = posix: posit2(1) = posiy: posit2(2) = posiz: posit2(3) = 1
    glLightfv GL_LIGHT1, GL_POSITION, posit2(0)
    
    polar_cartz lamp3_posi(0), lamp3_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
    posit3(0) = posix: posit3(1) = posiy: posit3(2) = posiz: posit3(3) = 1
    glLightfv GL_LIGHT2, GL_POSITION, posit3(0)

End Sub

Sub draw_lamps()
Dim posix As Double, posiy As Double, posiz As Double
Dim obj As Long

    obj = gluNewQuadric
    
    glDisable (GL_LIGHTING)
        glPushMatrix
            glColor4f 1, 0, 0, 1
            polar_cartz lamp1_posi(0), lamp1_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
            glTranslatef posix, posiy, posiz
            gluSphere obj, 10, 16, 16
        glPopMatrix
        
        glPushMatrix
            glColor4f 0, 1, 0, 1
            polar_cartz lamp2_posi(0), lamp2_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
            glTranslatef posix, posiy, posiz
            gluSphere obj, 10, 16, 16
         glPopMatrix
        
        glPushMatrix
            glColor4f 0, 0, 1, 1
            polar_cartz lamp3_posi(0), lamp3_posi(1), jl / 2, 0, 0, 0, posix, posiy, posiz
            glTranslatef posix, posiy, posiz
            gluSphere obj, 10, 16, 16
        glPopMatrix
    glEnable (GL_LIGHTING)
End Sub

Public Sub polar_cartz(ByVal az As Double, ByVal clino As Double, ByVal dist As Double, ByVal org_x As Double, ByVal org_y As Double, ByVal org_z As Double, xlamp As Double, ylamp As Double, zlamp As Double)
  Dim lp As Double
  lp = dist * Cos(clino / 180 * pi)
  
  xlamp = org_x + lp * Sin(az / 180 * pi)
  ylamp = org_y + lp * Cos(az / 180 * pi)
  zlamp = org_z + dist * Sin(clino / 180 * pi)
  
End Sub

Private Sub Form_DblClick()
    If Timer1.Enabled = True Then Timer1.Enabled = False Else Timer1.Enabled = True
End Sub

Private Sub Form_Load()
Initialize
Option1.Value = True
Frame1.Left = 0
Frame1.Top = 0
Frame1.Height = FRAMEHEIGHT
VScroll1.Width = SCROLLBARSIZE
HScroll1.Left = 0
HScroll1.Height = SCROLLBARSIZE
VScroll1.Top = FRAMEHEIGHT
End Sub

Private Sub Form_Paint()
Render
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
EndProc
End Sub

Private Sub Form_Resize()
Dim w1 As Long, h1 As Long 'the dimensions of the gl viewport
Dim vsLeft&, hsTop& 'pos of scrollbars

    'calculate size of viewport, min size = 1x1
    w1 = ScaleWidth - (SCROLLBARSIZE + 1)
    h1 = ScaleHeight - (SCROLLBARSIZE + FRAMEHEIGHT + 1)
    If w1 < 1 Then w1 = 1
    If h1 < 1 Then h1 = 1
    
    'move interface elements
    Frame1.Width = ScaleWidth
    VScroll1.Height = h1 ' - Frame1.Height - HScroll1.Height
    VScroll1.Left = w1 ' - VScroll1.Width
    
    HScroll1.Width = w1 ' - VScroll1.Width
    HScroll1.Top = h1 + FRAMEHEIGHT ' - HScroll1.Height
    Dummy.Move w1, h1 + FRAMEHEIGHT, SCROLLBARSIZE, SCROLLBARSIZE
    'set viewport and frustrum
    wglMakeCurrent hDC, m_hGLRC
        'note: x,y = lower-left corner
        glViewport 0, SCROLLBARSIZE, w1, h1
        '===========================================
        glMatrixMode GL_PROJECTION
        glLoadIdentity

        If w1 <= h1 Then
            glOrtho -jl, jl, (-jl * h1 / w1), (jl * h1 / w1), -jl * 5, jl * 5
        Else
            glOrtho (-jl * w1 / h1), (jl * w1 / h1), -jl, jl, -jl * 5, jl * 5
        End If

        gluLookAt 50, 50, 20, -50, -50, -20, 0, 0, 1
        '===========================================
        glMatrixMode GL_MODELVIEW
        glLoadIdentity
    wglMakeCurrent 0, 0
    Render
End Sub

'Sub SetViewport()
'        '===========================================
'        glMatrixMode GL_PROJECTION
'        glLoadIdentity
'
'        If w <= h Then
'            glOrtho -jl, jl, (-jl * h / w), (jl * h / w), -jl * 5, jl * 5
'        Else
'            glOrtho (-jl * w / h), (jl * w / h), -jl, jl, -jl * 5, jl * 5
'        End If
'
'        gluLookAt 50, 50, 20, -50, -50, -20, 0, 0, 1
'        '===========================================
'        glMatrixMode GL_MODELVIEW
'        glLoadIdentity
'    wglMakeCurrent 0, 0
'End Sub

Private Sub HScroll1_Change()
    HScroll1_Scroll
End Sub

Private Sub HScroll1_Scroll()
    If Option1.Value = True Then
        lamp1_posi(0) = HScroll1.Value
    End If
    
    If Option2.Value = True Then
        lamp2_posi(0) = HScroll1.Value
    End If
    
    If Option3.Value = True Then
        lamp3_posi(0) = HScroll1.Value
    End If
    Render
End Sub

Private Sub Option1_Click()
    HScroll1.Value = lamp1_posi(0)
    VScroll1.Value = lamp1_posi(1)
End Sub

Private Sub Option2_Click()
    HScroll1.Value = lamp2_posi(0)
    VScroll1.Value = lamp2_posi(1)
End Sub

Private Sub Option3_Click()
    HScroll1.Value = lamp3_posi(0)
    VScroll1.Value = lamp3_posi(1)
End Sub

Private Sub Timer1_Timer()
    rot = rot + 15
    If rot > 360 Then rot = 0
    Render
End Sub

Private Sub VScroll1_Change()
    VScroll1_Scroll
End Sub

Private Sub VScroll1_Scroll()
    If Option1.Value = True Then
        lamp1_posi(1) = VScroll1.Value
    End If
    
    If Option2.Value = True Then
        lamp2_posi(1) = VScroll1.Value
    End If
    
    If Option3.Value = True Then
        lamp3_posi(1) = VScroll1.Value
    End If
    Render
End Sub
