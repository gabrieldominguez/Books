#ifndef __wpfonts_h
#define __wpfonts_h
#include "globals.h"
#include "device.h"

#define WP_FONTFILE "wp.drs"
#define WP_NUMFONTS 67

/* font data index */
typedef struct {
  long offset;              /* offset of font in file */
  u_short length;           /* length of font description */
  u_short xxx;              /* unknown */ 
} index_entry;

/* font name index */
typedef struct {
  u_short offset;           /* offset of font table in file */
} nindex_entry;

typedef struct {
  char* filename;           /* name of fontfile */
  index_entry* index;       /* index of fonts */
  nindex_entry* file_index; /* index of file names */
  char* file_names;         /* table of file names */
  nindex_entry* font_index; /* index of font names */
  char* font_names;         /* table of font names */
} font_file;

#define WP_BITMAP 4
#define WP_OUTLINE 8

typedef struct {
  u_short type;             /* font type: BITMAP/OUTLINE */ 
  u_short numchars;         /* number of chars in font */
  u_short table_offset;     /* offset to char table */
  u_short data_offset;      /* offset to char data */
  u_short data_size;        /* size of char data */
} font_descriptor;

typedef struct {
  u_short offset;           /* offset in char data */
} char_entry;

typedef u_char char_data;    /* raw data */

typedef struct {
  font_file* file;          /* font file */
  int number;               /* number of the font in this file */
  font_descriptor desc;     /* descriptor */
  int nspace;              /* width of an n-space */
  char_entry* table;        /* char table */
  char_data* data;          /* char data */ 
} font_struct;


font_file* wp_init_fonts(char* filename);
void wp_exit_fonts(font_file* ff);
font_struct* wp_load_font(font_file* ff, int number);
void wp_dispose_font(font_struct* fs);
int wp_char_width(font_struct* fs, int character);
int wp_draw_char(font_struct* fs, device* dev, int x, int y, int character);
int wp_draw_string(font_struct* fs, device* dev, int x, int y, char* str);

#endif
