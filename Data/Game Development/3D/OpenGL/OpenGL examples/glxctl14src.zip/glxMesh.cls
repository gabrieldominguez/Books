VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxMesh"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'-------------------------------------------------------------------------
'* Module Name: mesh.c
'* Routines to create a mesh representation of a 3D object and to turn it
'* into an OpenGL description.
'* Copyright (c) 1994 Microsoft Corporation
'-------------------------------------------------------------------------
'-------------------------------------------------------------------------
'FUNCTION: allows you to define a contour and rotate it to produce a mesh
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Private Type MFACE
    p(0 To 3) As Long 'index in the pts array of the face vertexes
    Material As Long
    norm(0 To 2) As GLfloat
End Type

'this value gets passed to OpenGL and must be
'an array because of differences in array storage
'in VB
Private Type pt3f
    x(0 To 2) As Single
End Type

Const MAXPREC = 40
Dim m_NumFaces&
Dim m_NumPoints&
Dim m_Pts() As pt3f    'm_Pts(0 To numPts - 1, 0 To 2)
Dim m_Norms() As pt3f 'm_Norms(0 To numPts - 1, 0 To 2)
Dim m_Faces() As MFACE 'm_Faces(0 To NumFaces - 1)
Dim m_bInit As Boolean

Private Sub Class_Initialize()
'
End Sub

Private Sub Class_Terminate()
    Erase m_Pts
    Erase m_Norms
    Erase m_Faces
End Sub

'/******************************Public*Routine******************************\
'* newMesh
'* Allocate memory for the mesh structure to accomodate the specified number
'* of points and faces.
'-------------------------------------------------------------------------
Public Sub Init(ByVal NumFaces&, ByVal numPts&)
    m_NumFaces = 0
    m_NumPoints = 0
    If numPts Then
        ReDim m_Pts(0 To numPts - 1)
        ReDim m_Norms(0 To numPts - 1)
        ReDim m_Faces(0 To NumFaces - 1)
    End If
    m_bInit = True
End Sub

Public Property Get NumFaces&()
    NumFaces = m_NumFaces
End Property

Public Property Let NumFaces(ByVal NewValue&)
    m_NumFaces = NewValue&
End Property

Public Property Get NumPoints&()
    NumPoints = m_NumPoints
End Property

Public Property Let NumPoints(ByVal NewValue&)
    m_NumPoints = NewValue&
End Property

Public Property Get pA&(ByVal Index&)
pA = m_Faces(Index).p(0)
End Property

Public Property Let pA(ByVal Index&, ByVal value&)
m_Faces(Index).p(0) = value
End Property

Public Property Get pB&(ByVal Index&)
pB = m_Faces(Index).p(1)
End Property

Public Property Let pB(ByVal Index&, ByVal value&)
m_Faces(Index).p(1) = value
End Property

Public Property Get pC&(ByVal Index&)
pC = m_Faces(Index).p(2)
End Property

Public Property Let pC(ByVal Index&, ByVal value&)
m_Faces(Index).p(2) = value
End Property

Public Property Get pD&(ByVal Index&)
pD = m_Faces(Index).p(3)
End Property

Public Property Let pD(ByVal Index&, ByVal value&)
m_Faces(Index).p(3) = value
End Property

Public Sub SetFacePoints(ByVal Index&, ByVal a&, ByVal b&, ByVal c&, ByVal d&)
m_Faces(Index).p(0) = a
m_Faces(Index).p(1) = b
m_Faces(Index).p(2) = c
m_Faces(Index).p(3) = d
End Sub

Public Sub GetNormal(ByVal Index&, x!, y!, z!)
    x = m_Norms(Index).x(0)
    y = m_Norms(Index).x(1)
    z = m_Norms(Index).x(2)
End Sub

Public Sub SetNormal(ByVal Index&, ByVal x!, ByVal y!, ByVal z!)
    m_Norms(Index).x(0) = x
    m_Norms(Index).x(1) = y
    m_Norms(Index).x(2) = z
End Sub

Public Sub GetNormalv(ByVal Index&, norm!())
    norm(0) = m_Norms(Index).x(0)
    norm(1) = m_Norms(Index).x(1)
    norm(2) = m_Norms(Index).x(2)
End Sub

Public Sub SetNormalv(ByVal Index&, norm!())
    m_Norms(Index).x(0) = norm(0)
    m_Norms(Index).x(1) = norm(1)
    m_Norms(Index).x(2) = norm(2)
End Sub

Public Sub IncrementNormal(ByVal Index&, norm!())
m_Norms(Index).x(0) = m_Norms(Index).x(0) + norm(0)
m_Norms(Index).x(1) = m_Norms(Index).x(1) + norm(1)
m_Norms(Index).x(2) = m_Norms(Index).x(2) + norm(2)
End Sub

Public Sub glNormalv(ByVal Index&)
    glNormal3fv m_Norms(Index).x(0)
End Sub

Public Function GetVertex(ByVal Index&, x!, y!, z!) As Boolean
    x = m_Pts(Index).x(0)
    y = m_Pts(Index).x(1)
    z = m_Pts(Index).x(2)
End Function

Public Function SetVertex(ByVal Index&, ByVal x!, ByVal y!, ByVal z!) As Boolean
    m_Pts(Index).x(0) = x
    m_Pts(Index).x(1) = y
    m_Pts(Index).x(2) = z
End Function

Public Function GetVertexv(ByVal Index&, v!()) As Boolean
    v(0) = m_Pts(Index).x(0)
    v(1) = m_Pts(Index).x(1)
    v(2) = m_Pts(Index).x(2)
End Function

Public Function SetVertexv(ByVal Index&, v!()) As Boolean
    m_Pts(Index).x(0) = v(0)
    m_Pts(Index).x(1) = v(1)
    m_Pts(Index).x(2) = v(2)
End Function

Public Sub glVertexv(ByVal Index&)
    glVertex3fv m_Pts(Index).x(0)
End Sub

Public Property Get VertexX!(ByVal Index&)
    VertexX = m_Pts(Index).x(0)
End Property

Public Property Let VertexX(ByVal Index&, ByVal x!)
    m_Pts(Index).x(0) = x
End Property

Public Property Get VertexY!(ByVal Index&)
    VertexY = m_Pts(Index).x(1)
End Property

Public Property Let VertexY(ByVal Index&, ByVal y!)
    m_Pts(Index).x(1) = y
End Property

Public Property Get VertexZ!(ByVal Index&)
    VertexZ = m_Pts(Index).x(2)
End Property

Public Property Let VertexZ(ByVal Index&, ByVal z!)
    m_Pts(Index).x(2) = z
End Property

Public Sub CopyVertex(ByVal Index&, Dest!())
Dest(0) = m_Pts(Index).x(0)
Dest(1) = m_Pts(Index).x(1)
Dest(2) = m_Pts(Index).x(2)
End Sub

Public Sub CopyNormal(ByVal Index&, Dest!())
Dest(0) = m_Norms(Index).x(0)
Dest(1) = m_Norms(Index).x(1)
Dest(2) = m_Norms(Index).x(2)
End Sub

Public Sub CopyFaceNormal(ByVal Index&, Dest!())
Dest(0) = m_Faces(Index).norm(0)
Dest(1) = m_Faces(Index).norm(1)
Dest(2) = m_Faces(Index).norm(2)
End Sub

Public Sub SetFaceNormal(ByVal Index&, norm!())
    m_Faces(Index).norm(0) = norm(0)
    m_Faces(Index).norm(1) = norm(1)
    m_Faces(Index).norm(2) = norm(2)
End Sub

Public Property Let FaceMaterial(ByVal Index&, ByVal ID&)
    m_Faces(Index).Material = ID
End Property

Public Property Get FaceMaterial&(ByVal Index&)
    FaceMaterial = m_Faces(Index).Material
End Property

Public Sub ClearNorms()
Dim l&, u&
On Error GoTo errorhandler
u = UBound(m_Norms)
ReDim m_Norms(0 To u)
Exit Sub
errorhandler:
Debug.Assert 0
End Sub

Public Sub NormalizeNorms()
m_NormalizeNorms
End Sub

Public Sub CalcNormal(norm!(), ByVal p1Index&, ByVal p2Index&, ByVal p3Index&)
    CalcNorm norm, m_Pts(p1Index).x(0), m_Pts(p1Index).x(1), m_Pts(p1Index).x(2), _
        m_Pts(p2Index).x(0), m_Pts(p2Index).x(1), m_Pts(p2Index).x(2), _
        m_Pts(p3Index).x(0), m_Pts(p3Index).x(1), m_Pts(p3Index).x(2)
End Sub

'/******************************Public*Routine******************************\
'* revolveSurface
'* Takes the set of points in curve and fills the mesh structure with a
'* surface of revolution.  The surface consists of quads made up of the
'* points in curve rotated about the y-axis.  The number of increments
'* in the revolution is determined by the steps parameter.
'-------------------------------------------------------------------------
Public Sub RevolveSurface(Curve!(), ByVal Steps&)
Dim i&, j&, facecount&
Dim rotation#, rotInc#, cosVal#, sinVal#
Dim stepsSqr&
Dim norm!(0 To 2) '    POINT3D norm;
Dim a!(0 To MAXPREC, 0 To 2) ' POINT3D a(MAXPREC + 1);
Dim b!(0 To MAXPREC, 0 To 2) '    POINT3D b(MAXPREC + 1);
    If Steps > MAXPREC Then Steps = MAXPREC
    rotInc = (2 * PI) / (Steps - 1)
    stepsSqr = Steps * Steps
    'newMesh(mesh, stepsSqr, 4 * stepsSqr)
    If m_bInit Then Debug.Assert 0
    Init stepsSqr, 4 * stepsSqr

    For j = 0 To Steps - 1 '; j++, rotation += rotInc) {
        cosVal = Cos(rotation)
        sinVal = Sin(rotation)
        For i = 0 To Steps - 1 '; i < steps; i++) {
            a(i, 0) = Curve(i, 0) * cosVal + Curve(i, 2) * sinVal 'x=x+z
            a(i, 1) = Curve(i, 1) 'y=y
            a(i, 2) = Curve(i, 2) * cosVal - Curve(i, 0) * sinVal 'z=z-x
        Next

        cosVal = Cos(rotation + rotInc)
        sinVal = Sin(rotation + rotInc)
        For i = 0 To Steps - 1
            b(i, 0) = Curve(i, 0) * cosVal + Curve(i, 2) * sinVal 'x=x+z
            b(i, 1) = Curve(i, 1) 'y=y
            b(i, 2) = Curve(i, 2) * cosVal - Curve(i, 0) * sinVal 'z=z-x
        Next

        For i = 0 To Steps - 2 '; i < (steps - 1); i++) {
            m_CalcNorm2d3f norm, b, i + 1, b, i, a, i
            If norm(0) * norm(0) + norm(1) * norm(1) + norm(2) * norm(2) < 0.9 Then
                m_CalcNorm2d3f norm, a, i, a, i + 1, b, i + 1
            End If
            m_Faces(facecount).Material = j And 7
            SetFaceNormal facecount, norm
            m_Faces(facecount).p(0) = m_iPtInList(b(i, 0), b(i, 1), b(i, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(1) = m_iPtInList(a(i, 0), a(i, 1), a(i, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(2) = m_iPtInList(b(i + 1, 0), b(i + 1, 1), b(i + 1, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(3) = m_iPtInList(a(i + 1, 0), a(i + 1, 1), a(i + 1, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_NumFaces = m_NumFaces + 1
            facecount = facecount + 1
        Next
        rotation = rotation + rotInc
    Next
    m_NormalizeNorms
End Sub

Public Sub RevolveSurface2(Curve As glxCurve, ByVal Steps&)
Dim i&, j&, facecount&
Dim rotation#, rotInc#, cosVal#, sinVal#
Dim norm!(0 To 2) '    POINT3D norm;
Dim a!(0 To MAXPREC, 0 To 2) ' POINT3D a(MAXPREC + 1);
Dim b!(0 To MAXPREC, 0 To 2) '    POINT3D b(MAXPREC + 1);
    'If Steps > MAXPREC Then Steps = MAXPREC
    rotInc = (2 * PI) / (Steps - 1)
    For j = 0 To Steps - 1 '; j++, rotation += rotInc) {
        cosVal = Cos(rotation)
        sinVal = Sin(rotation)
        For i = 0 To Steps - 1 '; i < steps; i++) {
            a(i, 0) = Curve.x(i) * cosVal + Curve.z(i) * sinVal
            a(i, 1) = Curve.y(i)
            a(i, 2) = Curve.z(i) * cosVal - Curve.x(i) * sinVal
        Next

        cosVal = Cos(rotation + rotInc)
        sinVal = Sin(rotation + rotInc)
        For i = 0 To Steps - 1
            b(i, 0) = Curve.x(i) * cosVal + Curve.z(i) * sinVal
            b(i, 1) = Curve.y(i)
            b(i, 2) = Curve.z(i) * cosVal - Curve.x(i) * sinVal
        Next

        For i = 0 To Steps - 2 '; i < (steps - 1); i++) {
            m_CalcNorm2d3f norm, b, i + 1, b, i, a, i
            If norm(0) * norm(0) + norm(1) * norm(1) + norm(2) * norm(2) < 0.9 Then
                m_CalcNorm2d3f norm, a, i, a, i + 1, b, i + 1
            End If
            m_Faces(facecount).Material = j And 7
            m_Faces(facecount).norm(0) = norm(0)
            m_Faces(facecount).norm(1) = norm(1)
            m_Faces(facecount).norm(2) = norm(2)
            m_Faces(facecount).p(0) = m_iPtInList(b(i, 0), b(i, 1), b(i, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(1) = m_iPtInList(a(i, 0), a(i, 1), a(i, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(2) = m_iPtInList(b(i + 1, 0), b(i + 1, 1), b(i + 1, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_Faces(facecount).p(3) = m_iPtInList(a(i + 1, 0), a(i + 1, 1), a(i + 1, 2), _
                                norm(0), norm(1), norm(2), 0)
            m_NumFaces = m_NumFaces + 1
            facecount = facecount + 1
        Next
        rotation = rotation + rotInc
    Next
    m_NormalizeNorms 'm_Norms, m_NumPoints
End Sub


'/******************************Public*Routine******************************\
'* updateObject
'* Takes the mesh structure and converts the data into OpenGL immediate
'* mode commands.
'-------------------------------------------------------------------------
Public Sub UpdateObject(ByVal bSmooth As Boolean)
Dim i&, a&, b&
Dim lastC&, lastD&
    glBegin GL_QUAD_STRIP
    lastC = m_Faces(0).p(0)
    lastD = m_Faces(0).p(1)
    For i = 0 To m_NumFaces - 1
        a = m_Faces(i).p(0)
        b = m_Faces(i).p(1)
        '
        If bSmooth = False Then
            If (a <> lastC Or b <> lastD) Then
                'terminate and start a new strip
                glNormal3fv m_Faces(i - 1).norm(0)
                glVertex3fv m_Pts(lastC).x(0)
                glVertex3fv m_Pts(lastD).x(0)
                glEnd
                glBegin GL_QUAD_STRIP
            End If
            glNormal3fv m_Faces(i).norm(0)
            glVertex3fv m_Pts(a).x(0)
            glVertex3fv m_Pts(b).x(0)
        Else
            If a <> lastC Or b <> lastD Then
                glNormal3fv m_Norms(lastC).x(0)
                glVertex3fv m_Pts(lastC).x(0)
                glNormal3fv m_Norms(lastD).x(0)
                glVertex3fv m_Pts(lastD).x(0)
                glEnd
                glBegin GL_QUAD_STRIP
            End If
            glNormal3fv m_Norms(a).x(0)
            glVertex3fv m_Pts(a).x(0)
            glNormal3fv m_Norms(b).x(0)
            glVertex3fv m_Pts(b).x(0)
        End If
        lastC = m_Faces(i).p(2)
        lastD = m_Faces(i).p(3)
    Next
    If bSmooth = False Then
        glNormal3fv m_Faces(i - 1).norm(0)
        glVertex3fv m_Pts(lastC).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    Else
        glNormal3fv m_Norms(lastC).x(0)
        glVertex3fv m_Pts(lastC).x(0)
        glNormal3fv m_Norms(lastD).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    End If
    glEnd
End Sub


'/******************************Public*Routine******************************\
'* updateObject
'* This is a special case that handles a mesh structure that represents
'* a strip that is a 1 high loop.
'* Takes the mesh structure and converts the data into OpenGL immediate
'* mode commands.
'-------------------------------------------------------------------------
Public Sub UpdateObject2(ByVal bSmooth As Boolean)
Dim i&, a&, b& ', aOffs&, bOffs&, cOffs&, dOffs&
Dim lastC&, lastD&
    glBegin GL_QUAD_STRIP
    lastC = m_Faces(0).p(0)
    lastD = m_Faces(0).p(1)
    For i = 0 To m_NumFaces - 1
        a = m_Faces(i).p(0)
        b = m_Faces(i).p(1)
        If bSmooth = False Then
            glNormal3fv m_Faces(i).norm(0)
            glVertex3fv m_Pts(a).x(0) 'LShiftl(a, 3) + LShiftl(a, 2))
            glVertex3fv m_Pts(b).x(0) 'LShiftl(b, 3) + LShiftl(b, 2))
        Else
'            aOffs = LShiftl(a, 3) + LShiftl(a, 2)
'            bOffs = LShiftl(b, 3) + LShiftl(b, 2)

            glNormal3fv m_Norms(a).x(0)
            glVertex3fv m_Pts(a).x(0)
            glNormal3fv m_Norms(b).x(0)
            glVertex3fv m_Pts(b).x(0)
        End If
        lastC = m_Faces(i).p(2)
        lastD = m_Faces(i).p(3)
    Next
'    cOffs = (LShiftl(lastC, 3) + LShiftl(lastC, 2)) / 3
'    dOffs = (LShiftl(lastD, 3) + LShiftl(lastD, 2)) / 3
    If bSmooth = False Then
        glNormal3fv m_Faces(i - 1).norm(0)
        glVertex3fv m_Pts(lastC).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    Else
        glNormal3fv m_Norms(lastC).x(0)
        glVertex3fv m_Pts(lastC).x(0)
        glNormal3fv m_Norms(lastD).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    End If
    glEnd
End Sub

'/******************************Public*Routine******************************\
'* MakeList
'* Takes the mesh structure and converts the data into OpenGL display
'* list.
'-------------------------------------------------------------------------
Public Sub MakeList(ByVal listID&)
Dim i&, a&, b&
'Dim aOffs&, bOffs&, cOffs&, dOffs&
Dim bSmooth As Boolean
Dim shadeModel&
Dim lastC&, lastD&
'    MFACE *faces;
'    POINT3D *pp;
'    POINT3D *pn;
'    pp = mesh->pts;
'    pn = mesh->norms;
    glGetIntegerv GL_SHADE_MODEL, shadeModel
    bSmooth = (shadeModel = GL_SMOOTH)
    glNewList listID, GL_COMPILE
    glBegin GL_QUAD_STRIP
    lastC = m_Faces(0).p(0)
    lastD = m_Faces(0).p(1)
    For i = 0 To m_NumFaces - 1 '; i++, faces++) {
        a = m_Faces(i).p(0)
        b = m_Faces(i).p(1)
        If bSmooth = False Then
            If a <> lastC Or b <> lastD Then
                glNormal3fv m_Faces(i - 1).norm(0)
                glVertex3fv m_Pts(lastC).x(0)
                glVertex3fv m_Pts(lastD).x(0)
                glEnd
                glBegin GL_QUAD_STRIP
            End If
            glNormal3fv m_Faces(i).norm(0)
            glVertex3fv m_Pts(a).x(0)
            glVertex3fv m_Pts(b).x(0)
        Else
            If ((a <> lastC) Or (b <> lastD)) Then
                glNormal3fv m_Norms(lastC).x(0)
                glVertex3fv m_Pts(lastC).x(0)
                glNormal3fv m_Norms(lastD).x(0)
                glVertex3fv m_Pts(lastD).x(0)
                glEnd
                glBegin GL_QUAD_STRIP
            End If
            glNormal3fv m_Norms(a).x(0)
            glVertex3fv m_Pts(a).x(0)
            glNormal3fv m_Norms(b).x(0)
            glVertex3fv m_Pts(b).x(0)
        End If
        lastC = m_Faces(i).p(2)
        lastD = m_Faces(i).p(3)
    Next

    If bSmooth = False Then
        glNormal3fv m_Faces(i - 1).norm(0)
        glVertex3fv m_Pts(lastC).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    Else
        glNormal3fv m_Norms(lastC).x(0)
        glVertex3fv m_Pts(lastC).x(0)
        glNormal3fv m_Norms(lastD).x(0)
        glVertex3fv m_Pts(lastD).x(0)
    End If
    glEnd
    glEndList
End Sub

'/******************************Public*Routine******************************\
'* iPtInList
'* Add a vertex and its normal to the mesh.  If the vertex already exists,
'* add in the normal to the existing normal (we to accumulate the average
'* normal at each vertex).  Normalization of the normals is the
'* responsibility of the caller.
'-------------------------------------------------------------------------
Private Function m_iPtInList&(ByVal pX!, ByVal pY!, ByVal pZ!, _
                ByVal nX!, ByVal nY!, ByVal nZ!, ByVal Start&)
Dim i&
    'POINT3D *pts = mesh->pts + start;
    'for (i = start; i < mesh->numPoints; i++, pts++)
    For i = Start To m_NumPoints - 1
    ' If the vertices are within ZERO_EPS of each other, then its the same
    ' vertex.
        If Abs(m_Pts(i).x(0) - pX) < ZERO_EPS And _
             Abs(m_Pts(i).x(1) - pY) < ZERO_EPS And _
             Abs(m_Pts(i).x(2) - pZ) < ZERO_EPS Then
            m_Norms(i).x(0) = m_Norms(i).x(0) + nX
            m_Norms(i).x(1) = m_Norms(i).x(1) + nY
            m_Norms(i).x(2) = m_Norms(i).x(2) + nZ
            m_iPtInList = i
            Exit Function
        End If
    Next
    'vertex not found
    m_Pts(i).x(0) = pX
    m_Pts(i).x(1) = pY
    m_Pts(i).x(2) = pZ
    m_Norms(i).x(0) = nX
    m_Norms(i).x(1) = nY
    m_Norms(i).x(2) = nZ
    m_NumPoints = m_NumPoints + 1
    m_iPtInList = i
End Function

'used by RevolveSurface
Private Sub m_CalcNorm2d3f(norm!(), p1!(), ByVal p1Index&, p2!(), ByVal p2Index&, p3!(), ByVal p3Index&)
    CalcNorm norm, p1(p1Index, 0), p1(p1Index, 1), p1(p1Index, 2), _
        p2(p2Index, 0), p2(p2Index, 1), p2(p2Index, 2), _
        p3(p3Index, 0), p3(p3Index, 1), p3(p3Index, 2)
End Sub

Private Sub m_NormalizeNorms() 'P() As pt3f, cPts&)
Dim lng!, i&
    For i = 0 To m_NumPoints - 1
        lng = (m_Norms(i).x(0) * m_Norms(i).x(0)) + (m_Norms(i).x(1) * m_Norms(i).x(1)) + (m_Norms(i).x(2) * m_Norms(i).x(2))
        If lng > ZERO_EPS Then
            lng = 1 / Sqr(lng)
        Else
            lng = 1
        End If

        m_Norms(i).x(0) = m_Norms(i).x(0) * lng
        m_Norms(i).x(1) = m_Norms(i).x(1) * lng
        m_Norms(i).x(2) = m_Norms(i).x(2) * lng
    Next
End Sub
'


