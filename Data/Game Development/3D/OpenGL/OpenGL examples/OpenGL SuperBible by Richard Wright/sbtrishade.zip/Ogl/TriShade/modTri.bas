Attribute VB_Name = "mTriangle"
Public Sub RenderScene()

' Routine to draw triangle with flat/smooth shading
    
    Dim dBallRadius As Double
    Dim red As GLubyte
    Dim green As GLubyte
    Dim blue As GLubyte

    glClear clrColorBufferBit + clrDepthBufferBit
    glMatrixMode mmModelView
    glLoadIdentity
    
    'Enable flat/smooth shading
    If iFlatSmooth = 1 Then
      glShadeModel smFlat
    Else
      glShadeModel smSmooth
    End If

    'Draw the triangle
    glBegin bmTriangles
        'Red Apex
        red = 255
        green = 0
        blue = 0
        glColor3ub red, green, blue
        glVertex3f 0#, 100#, 0#

        'Green on the right bottom corner
        red = 0
        green = 255
        blue = 0
        glColor3ub red, green, blue
        glVertex3f 100#, -70#, 0#

        'Blue on the left bottom corner
        red = 0
        green = 0
        blue = 255
        glColor3ub red, green, blue
        glVertex3f -100#, -70#, 0#
    glEnd

    SwapBuffers frmDisplay.hDC
    
    ' Flush drawing commands
    glFlush
    
End Sub
