VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Caustics"
   ClientHeight    =   5250
   ClientLeft      =   2655
   ClientTop       =   2385
   ClientWidth     =   5880
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   350
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   392
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4830
      Left            =   180
      TabIndex        =   0
      Top             =   135
      Width           =   4785
      _ExtentX        =   8440
      _ExtentY        =   8520
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFilePosLight 
         Caption         =   "Positional light"
      End
      Begin VB.Menu mnuFileDirLight 
         Caption         =   "Directional light"
      End
      Begin VB.Menu mnuFileGreenLight 
         Caption         =   "Greenish light"
      End
      Begin VB.Menu mnufileWhitelight 
         Caption         =   "White light"
      End
      Begin VB.Menu mnuFileCaustics 
         Caption         =   "Caustics"
      End
      Begin VB.Menu mnufileIncrease 
         Caption         =   "Increase ripple size"
      End
      Begin VB.Menu mnuFileDecrease 
         Caption         =   "Decrease ripple size"
      End
      Begin VB.Menu mnuFileMotion 
         Caption         =   "Motion"
      End
      Begin VB.Menu mnuFileMipmaps 
         Caption         =   "Mipmaps"
         Enabled         =   0   'False
      End
   End
   Begin VB.Menu mnuModel 
      Caption         =   "Model"
      Begin VB.Menu mnuModels 
         Caption         =   "Sphere"
         Index           =   0
      End
      Begin VB.Menu mnuModels 
         Caption         =   "Cube"
         Index           =   1
      End
      Begin VB.Menu mnuModels 
         Caption         =   "Dino"
         Index           =   2
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, shift As Integer)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else: Exit Sub
    End Select
    KeyCode = 0
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.Key KeyAscii
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CX = New CCaustic
glxCtl1.Init
glxCtl1.Animate = True
End Sub


Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, shift As Integer, X As Single, y As Single)
CX.MouseDown Button, shift, X, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, shift As Integer, X As Single, y As Single)
CX.MouseMove Button, shift, X, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, shift As Integer, X As Single, y As Single)
CX.MouseUp Button, shift, X, y
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


Private Sub mnuFile_Click()
mnuFilePosLight.Checked = (optDirectionalLight = 0)
mnuFileDirLight.Checked = optDirectionalLight
mnuFileCaustics.Checked = optShowCaustics
mnuFileMotion.Checked = optCausticMotion
mnuFileMipmaps.Checked = optUseMipmaps
End Sub

Private Sub mnuFileCaustics_Click()
CX.MenuSelect M_WITH_CAUSTICS
End Sub

Private Sub mnuFileDecrease_Click()
CX.MenuSelect M_DECREASE_RIPPLE_SIZE
End Sub

Private Sub mnuFileDirLight_Click()
CX.MenuSelect M_DIRECTIONAL
End Sub

Private Sub mnuFileGreenLight_Click()
CX.MenuSelect M_GREENISH_LIGHT
End Sub

Private Sub mnufileIncrease_Click()
CX.MenuSelect M_INCREASE_RIPPLE_SIZE
End Sub

Private Sub mnuFileMipmaps_Click()
'optUseMipmaps = Not optUseMipmaps
End Sub

Private Sub mnuFileMotion_Click()
optCausticMotion = Not optCausticMotion
End Sub

Private Sub mnuFilePosLight_Click()
CX.MenuSelect M_POSITIONAL
End Sub

Private Sub mnufileWhitelight_Click()
CX.MenuSelect M_WHITE_LIGHT
End Sub

Private Sub mnuModel_Click()
Dim i&
For i = 0 To 2
    mnuModels(i).Checked = (optCurModel = i + 1)
Next
End Sub

Private Sub mnuModels_Click(Index As Integer)
optCurModel = Index + 1
End Sub
