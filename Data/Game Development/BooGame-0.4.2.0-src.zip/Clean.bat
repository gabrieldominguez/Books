@REM Cleans Project Files and Binaries

@ECHO OFF

@REM Create NAnt Project Files
tools\Prebuild\Prebuild.exe /target nant /file Prebuild.xml

@REM Clean using NAnt
tools\NAnt\NAnt.exe -t:net-1.1 -buildfile:BooGame.build clean

@REM Clean using Prebuild
.\tools\Prebuild\Prebuild.exe /clean /removedir obj /yes