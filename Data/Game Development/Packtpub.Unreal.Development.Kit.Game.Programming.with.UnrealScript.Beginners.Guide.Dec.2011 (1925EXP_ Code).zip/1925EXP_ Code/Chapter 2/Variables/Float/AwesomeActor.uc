class AwesomeActor extends Actor
    placeable;

var float DistanceToGo;

function PostBeginPlay()
{
    `log("Distance to go:" @ DistanceToGo);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
