VERSION 5.00
Begin VB.Form frmAPropos 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "A propos..."
   ClientHeight    =   1800
   ClientLeft      =   750
   ClientTop       =   1770
   ClientWidth     =   3825
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmAPropos.frx":0000
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1800
   ScaleWidth      =   3825
   Begin VB.CommandButton cmdFermer 
      Cancel          =   -1  'True
      Caption         =   "&Fermer"
      Height          =   330
      Left            =   2310
      TabIndex        =   2
      Top             =   1365
      Width           =   1275
   End
   Begin VB.Line Line1 
      X1              =   105
      X2              =   3675
      Y1              =   1260
      Y2              =   1260
   End
   Begin VB.Image Image1 
      Height          =   480
      Left            =   315
      Picture         =   "frmAPropos.frx":000C
      Top             =   315
      Width           =   480
   End
   Begin VB.Label lblVers 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "lblVers"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Left            =   1260
      TabIndex        =   3
      Top             =   735
      Width           =   525
   End
   Begin VB.Label lblHttp 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "http://docvb.free.fr/"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   210
      MouseIcon       =   "frmAPropos.frx":08D6
      MousePointer    =   99  'Custom
      TabIndex        =   1
      Top             =   1440
      Width           =   1515
   End
   Begin VB.Label lblApp 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Mp3 Tag Editor"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1050
      TabIndex        =   0
      Top             =   315
      Width           =   2145
   End
End
Attribute VB_Name = "frmAPropos"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdFermer_Click()
' Fermeture de la fen�tre
Unload Me
End Sub

Private Sub Form_Load()
' Affichage du num�ro de version
lblVers.Caption = "Version " & App.Major & "." & App.Minor & "." & App.Revision
' Centrage de la fen�tre
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2
Me.Caption = Replace(LoadResString(intLOffset + 196), "&", "")
cmdFermer.Caption = LoadResString(intLOffset + 183)
End Sub

Private Sub lblHttp_Click()
' Ouverture de la page d'accueil du site
On Error Resume Next
Shell "explorer.exe http://docvb.free.fr/", vbNormalFocus
End Sub
