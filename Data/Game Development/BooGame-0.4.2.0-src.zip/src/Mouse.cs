/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

using Tao.FreeGlut;

namespace BooGame
{
    /// <summary>
    /// Describes a mouse event.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void MouseEventHandler(object sender, MouseEventArgs e);

    /// <summary>
    /// Module to access the mouse.
    /// </summary>
    public sealed class Mouse
    {
        /// <summary>
        /// Called when the mouse moves.
        /// </summary>
        public static event MouseEventHandler Motion;
        /// <summary>
        /// Called when a mouse button is pushed.
        /// </summary>
        public static event MouseEventHandler ButtonDown;
        /// <summary>
        /// Called when a mouse button is let go.
        /// </summary>
        public static event MouseEventHandler ButtonUp;
        /// <summary>
        /// Called when the mouse wheel is moved up or down.
        /// </summary>
        public static event MouseEventHandler Wheel;

		
        static Mouse()
        {
			Core.Initialize();
            Glut.glutMouseFunc(new Glut.MouseCallback(MouseButtonCallback));
            Glut.glutMotionFunc(new Glut.MotionCallback(MouseDragCallback));
            Glut.glutPassiveMotionFunc(new Glut.PassiveMotionCallback(MouseMotionCallback));
            Glut.glutMouseWheelFunc(new Glut.MouseWheelCallback(MouseWheelCallback));

            Cursor = MouseCursors.LeftArrow;
        }
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Mouse()
        {
        }

        internal static void Initialize()
        {
        }

        private static bool[] m_ButtonsDown = new bool[3];

        private static void MouseButtonCallback(int button, int state, int x, int y)
        {
			int mousebutton = (button >= m_ButtonsDown.Length) ? 1 : button;
            m_ButtonsDown[mousebutton] = state == Glut.GLUT_DOWN;
            if (state == Glut.GLUT_DOWN)
			{
				m_LastButton = (MouseButtons)mousebutton;
				MouseEventArgs args = new MouseEventArgs(m_MouseX, m_MouseY, m_LastButton, true);
				
				Core.Game.MouseButtonDown(args);
                Core.Game.Gui.OnMouseButtonDown(args);

                if(ButtonDown != null)
                    ButtonDown(null, args);
            }
            else
			{
				MouseEventArgs args = new MouseEventArgs(m_MouseX, m_MouseY, (MouseButtons)mousebutton, false);

                Core.Game.MouseButtonUp(args);
                Core.Game.Gui.OnMouseButtonUp(args);

				if(ButtonUp != null)
                    ButtonUp(null, args);
            }
        }

        private static void MouseWheelCallback(int wheel, int direction, int x, int y)
        {
            MouseEventArgs args = new MouseEventArgs(m_MouseX, m_MouseY, MouseButtons.Wheel, false, direction);
            Core.Game.MouseWheel(args);
            Core.Game.Gui.OnMouseWheel(args);
            if (Wheel != null)
                Wheel(null, args);
        }

		private static MouseButtons m_LastButton = MouseButtons.Unknown;

        /// <summary>
        /// Returns true if the given button is pushed down.
        /// </summary>
        /// <param name="button">The button to see is pushed down.</param>
        /// <returns>True if the button is pushed down.</returns>
        public static bool IsButtonDown(MouseButtons button)
        {
            return m_ButtonsDown[(int)button];
        }

        /// <summary>
        /// Gets and sets a point representating the X and Y location of the mouse.
        /// </summary>
        public static PointF Location
        {
            get
            {
                return new PointF(m_MouseX, m_MouseY);
            }
            set
            {
                Glut.glutWarpPointer((int)(value.X - Camera.X * Camera.ScaleX), (int)(value.Y - Camera.Y * Camera.ScaleY));
                m_MouseX = value.X;
                m_MouseY = value.Y;
            }
        }

        private static float m_MouseX = 0f;
        private static float m_MouseY = 0f;
        private static float m_RelativeMouseX = 0f;
        private static float m_RelativeMouseY = 0f;

        /// <summary>
        /// Gets and sets the X coordinate of the mouse.
        /// </summary>
        public static float X
        {
            get
            {
                return m_MouseX;
            }
            set
            {
                Glut.glutWarpPointer((int)(value - Camera.X * Camera.ScaleX), (int)(m_MouseY - Camera.Y * Camera.ScaleY));
                m_MouseX = value;
            }
        }

        /// <summary>
        /// Gets and sets the Y coordinate of the mouse.
        /// </summary>
        public static float Y
        {
            get
            {
                return m_MouseY;
            }
            set
            {
                Glut.glutWarpPointer((int)(m_MouseX - Camera.X * Camera.ScaleX), (int)(value - Camera.Y * Camera.ScaleY));
                m_MouseY = value;
            }
        }

		private static void MouseMotionUpdate(int x, int y)
		{
			Size window = Display.WindowSize;
            Size screen = Display.ScreenSize;

			// Screen coordinates
			float mousex = (float)x / (float)window.Width * (float)screen.Width + Camera.X * Camera.ScaleX;
            float mousey = (float)y / (float)window.Height * (float)screen.Height + Camera.Y * Camera.ScaleY;

            // Report coordinates
            m_RelativeMouseX = mousex - m_MouseX;
            m_RelativeMouseY = mousey - m_MouseY;
            m_MouseX = mousex;
            m_MouseY = mousey;
		}

        private static void MouseMotionCallback(int x, int y)
        {
			MouseMotionUpdate(x,y);
			MouseEventArgs args = new MouseEventArgs(m_MouseX, m_MouseY, MouseButtons.None, false, 0, m_RelativeMouseX, m_RelativeMouseY);
			
			Core.Game.MouseMotion(args);
            Core.Game.Gui.OnMouseMotion(args);

            if(Motion != null)
                Motion(null, args);
        }

        /// <summary>
        /// Gets whether the mouse intersects with the given point with a tolerance.
        /// </summary>
        /// <param name="point">The point to check against.</param>
        /// <param name="tolerance">How tolerant the collision check is. Defaults to 0.1f.</param>
        /// <returns>True if the points collide, false otherwise.</returns>
        public static bool IntersectsWith(PointF point, float tolerance)
        {
            if (m_MouseX - point.X < tolerance)
                if (m_MouseY - point.Y < tolerance)
                    return true;
            return false;
        }

        /// <summary>
        /// Gets whether the mouse intersects with the given point.
        /// </summary>
        /// <param name="point">The point to check against.</param>
        /// <returns>True if the points collide, false otherwise.</returns>
        public static bool IntersectsWith(PointF point)
        {
            return IntersectsWith(point, 0.1f);
        }

        /// <summary>
        /// Gets whether the mouse is intersecting with the given rectangle.
        /// </summary>
        /// <param name="rect">The ractangle to check against.</param>
        /// <returns>True if the mouse is within the box, false otherwise.</returns>
        public static bool IntersectsWith(RectangleF rect)
        {
            if (m_MouseX < rect.Right)
                if (m_MouseY < rect.Bottom)
                    if (m_MouseX > rect.Left)
                        if (m_MouseY > rect.Top)
                            return true;
            return false;
        }

        private static void MouseDragCallback(int x, int y)
		{
			MouseMotionUpdate(x,y);
			MouseEventArgs args = new MouseEventArgs(m_MouseX, m_MouseY, m_LastButton, true, 0, m_RelativeMouseX, m_RelativeMouseY);

            Core.Game.MouseMotion(args);
            Core.Game.Gui.OnMouseMotion(args);

            if(Motion != null)
                Motion(null, args);
        }

		private static bool m_ShowCursor = true;
        /// <summary>
        /// Gets and sets whether the mouse cursor is visible.
        /// </summary>
		public static bool ShowCursor
		{
			get
			{
				return m_ShowCursor;
			}
			set
			{
				m_ShowCursor = value;
                Cursor = m_Cursor;
			}
		}

        private static MouseCursors m_Cursor = MouseCursors.LeftArrow;
        /// <summary>
        /// Gets and sets the cursor type to associate with the mouse.
        /// </summary>
        public static MouseCursors Cursor
        {
            get
            {
                return m_Cursor;
            }
            set
            {
                m_Cursor = value;
                if (m_ShowCursor)
                    Glut.glutSetCursor((int)value);
                else
                    Glut.glutSetCursor((int)MouseCursors.None);
            }
        }

        /// <summary>
        /// Gets whether or not a mouse device exists.
        /// </summary>
        public static bool Exists
        {
            get
            {
                return Glut.glutDeviceGet(Glut.GLUT_HAS_MOUSE) != 0;
            }
        }
    }

	/// <summary>
	/// Event arguments that are passed when a mouse event occurs.
	/// </summary>
	public class MouseEventArgs : EventArgs
	{
		public MouseEventArgs(float x, float y)
		{
			m_MouseX = x;
			m_MouseY = y;
		}

		public MouseEventArgs(float x, float y, MouseButtons button) : this(x, y)
		{
			m_Button = button;
		}

		public MouseEventArgs(float x, float y, MouseButtons button, bool pressed) : this(x, y, button)
		{
			m_Pressed = pressed;
        }

        public MouseEventArgs(float x, float y, MouseButtons button, bool pressed, int wheelDirection)
            : this(x, y, button, pressed)
        {
            m_WheelDirection = wheelDirection;
        }

        public MouseEventArgs(float x, float y, MouseButtons button, bool pressed, int wheelDirection, float relativeX, float relativeY)
            : this(x, y, button, pressed, wheelDirection)
        {
            m_RelativeMouseX = relativeX;
            m_RelativeMouseY = relativeY;
        }

		private float m_MouseX = 0f;
		private float m_MouseY = 0f;
        private int m_WheelDirection = 0;
        private float m_RelativeMouseX = 0f;
        private float m_RelativeMouseY = 0f;

        /// <summary>
        /// The mouse X coordinate at the time the event was thrown.
        /// </summary>
		public float MouseX
		{
			get
			{
				return m_MouseX;
			}
        }

        /// <summary>
        /// The mouse Y coordinate at the time the event was thrown.
        /// </summary>
        public float MouseY
        {
            get
            {
                return m_MouseY;
            }
        }

        /// <summary>
        /// The mouse X relative to the last mouse event.
        /// </summary>
        public float RelativeMouseX
        {
            get
            {
                return m_RelativeMouseX;
            }
        }

        /// <summary>
        /// The mouse Y relative to the last mouse event.
        /// </summary>
        public float RelativeMouseY
        {
            get
            {
                return m_RelativeMouseY;
            }
        }

        /// <summary>
        /// Gets a point representing the relative position of the mouse since last mouse event.
        /// </summary>
        public PointF RelativeLocation
        {
            get
            {
                return new PointF(m_RelativeMouseX, m_RelativeMouseY);
            }
        }
		
        /// <summary>
        /// The direction of the mouse wheel (-1 to 1).
        /// </summary>
		public MouseWheelDirection WheelDirection
		{
			get
			{
                return (MouseWheelDirection)m_WheelDirection;
			}
		}

        /// <summary>
        /// The mouse location at the time the event was thrown.
        /// </summary>
		public PointF Location
		{
			get
			{
				return new PointF(m_MouseX, m_MouseY);
			}
		}

        /// <summary>
        /// Gets a rectangle representing the current location of the mouse.
        /// </summary>
        public RectangleF Rectangle
        {
            get
            {
                return new RectangleF(Location, new SizeF(1f, 1f));
            }
        }
		
		private bool m_Pressed = false;
        /// <summary>
        /// Whether or not the button was pushed.
        /// </summary>
		public bool Pressed
		{
			get
			{
				return m_Pressed;
			}
		}
		private MouseButtons m_Button = MouseButtons.None;
        /// <summary>
        /// The button associated with this event.
        /// </summary>
		public MouseButtons Button
		{
			get
			{
				return m_Button;
			}
		}
	}

    /// <summary>
    /// The buttons on the mouse.
    /// </summary>
    public enum MouseButtons
    {
        /// <summary>
        /// No mouse button.
        /// </summary>
        None = 0,
        /// <summary>
        /// The left mouse button.
        /// </summary>
        Left = Glut.GLUT_LEFT_BUTTON,
        /// <summary>
        /// The middle mouse button.
        /// </summary>
        Middle = Glut.GLUT_MIDDLE_BUTTON,
        /// <summary>
        /// The right mouse button
        /// </summary>
        Right = Glut.GLUT_RIGHT_BUTTON,
        /// <summary>
        /// An unknown mouse button.
        /// </summary>
        Unknown = Glut.GLUT_RIGHT_BUTTON + 1,
        /// <summary>
        /// A mouse wheel turn.
        /// </summary>
        Wheel = Glut.GLUT_RIGHT_BUTTON + 2
    }

    /// <summary>
    /// A mouse wheel direction.
    /// </summary>
    public enum MouseWheelDirection
    {
        /// <summary>
        /// The mouse wheel is moved down.
        /// </summary>
        Down = -1,
        /// <summary>
        /// The mouse wheel is not being moved.
        /// </summary>
        None = 0,
        /// <summary>
        /// The mouse wheel is moved up.
        /// </summary>
        Up = 1
    }

    /// <summary>
    /// Mouse cursors that are available.
    /// </summary>
    public enum MouseCursors
    {
        /// <summary>
        /// An arrow pointing up and to the left.
        /// </summary>
        LeftArrow = Glut.GLUT_CURSOR_LEFT_ARROW,
        /// <summary>
        /// An arrow pointing up and to the right.
        /// </summary>
        RightArrow = Glut.GLUT_CURSOR_RIGHT_ARROW,
        /// <summary>
        /// A pointing hand.
        /// </summary>
        Hand = Glut.GLUT_CURSOR_INFO,
        /// <summary>
        /// Skull and cross-bones.
        /// </summary>
        Skull = Glut.GLUT_CURSOR_DESTROY,
        /// <summary>
        /// Question mark.
        /// </summary>
        Help = Glut.GLUT_CURSOR_HELP,
        /// <summary>
        /// Arrows rotating in a cycle.
        /// </summary>
        Rotate = Glut.GLUT_CURSOR_CYCLE,
        /// <summary>
        /// Spray can.
        /// </summary>
        Spray = Glut.GLUT_CURSOR_SPRAY,
        /// <summary>
        /// Wrist watch.
        /// </summary>
        Wait = Glut.GLUT_CURSOR_WAIT,
        /// <summary>
        /// Text insertion point.
        /// </summary>
        Text = Glut.GLUT_CURSOR_TEXT,
        /// <summary>
        /// Simple cross-hair.
        /// </summary>
        CrossHair = Glut.GLUT_CURSOR_CROSSHAIR,
        /// <summary>
        /// Cursor pointing up and down.
        /// </summary>
        UpDown = Glut.GLUT_CURSOR_UP_DOWN,
        /// <summary>
        /// Cursor pointing left and right.
        /// </summary>
        LeftRight = Glut.GLUT_CURSOR_LEFT_RIGHT,
        /// <summary>
        /// Arrow pointing to top side.
        /// </summary>
        TopSide = Glut.GLUT_CURSOR_TOP_SIDE,
        /// <summary>
        /// Arrow pointing to bottom side.
        /// </summary>
        BottomSide = Glut.GLUT_CURSOR_BOTTOM_SIDE,
        
        /// <summary>
        /// Arrow pointing to left side.
        /// </summary>
        LeftSide = Glut.GLUT_CURSOR_LEFT_SIDE,
        /// <summary>
        /// Arrow pointing to right side.
        /// </summary>
        RightSide = Glut.GLUT_CURSOR_RIGHT_SIDE,
        /// <summary>
        /// Arrow pointing to top-left corner.
        /// </summary>
        TopLeftCorner = Glut.GLUT_CURSOR_TOP_LEFT_CORNER,
        /// <summary>
        /// Arrow pointing to top-right corner.
        /// </summary>
        TopRightCorner = Glut.GLUT_CURSOR_TOP_RIGHT_CORNER,
        /// <summary>
        /// Arrow pointing to bottom-right corner.
        /// </summary>
        BottomRightCorner = Glut.GLUT_CURSOR_BOTTOM_RIGHT_CORNER,
        /// <summary>
        /// Arrow pointing to bottom-left corner.
        /// </summary>
        BottomLeftCorner = Glut.GLUT_CURSOR_BOTTOM_LEFT_CORNER,
        /// <summary>
        /// Parent window's cursor.
        /// </summary>
        ParentWindow = Glut.GLUT_CURSOR_INHERIT,
        /// <summary>
        /// No cursor.
        /// </summary>
        None = Glut.GLUT_CURSOR_NONE,
        /// <summary>
        /// Full cross hair cursor.
        /// </summary>
        FullCrossHair = Glut.GLUT_CURSOR_FULL_CROSSHAIR
    }
}