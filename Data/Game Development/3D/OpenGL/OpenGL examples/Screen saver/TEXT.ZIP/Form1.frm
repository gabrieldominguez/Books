VERSION 5.00
Object = "*\A..\..\glxCtl\glxCtl.vbp"
Begin VB.Form frm3dText 
   Caption         =   "Form1"
   ClientHeight    =   5580
   ClientLeft      =   945
   ClientTop       =   2370
   ClientWidth     =   5805
   LinkTopic       =   "Form1"
   ScaleHeight     =   372
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   387
   Begin glCtl.glxCtl glxCtl1 
      Height          =   5145
      Left            =   135
      TabIndex        =   0
      Top             =   90
      Width           =   5325
      _ExtentX        =   9393
      _ExtentY        =   9075
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileOptions 
         Caption         =   "Options"
      End
   End
End
Attribute VB_Name = "frm3dText"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Click()
'
End Sub

Private Sub glxCtl1_DblClick()
'
End Sub

Private Sub glxCtl1_Draw()
g3D.Draw
End Sub

Private Sub glxCtl1_Init()
g3D.Init
End Sub

Private Sub glxCtl1_InitGL()
g3D.InitGL
End Sub

Private Sub glxCtl1_Resize(Width As Long, Height As Long, Default As Boolean)
Default = g3D.Reshape(Width, Height)
End Sub

Private Sub mnuFileOptions_Click()
bSuspended = True
DoConfigure
bSuspended = False
End Sub
