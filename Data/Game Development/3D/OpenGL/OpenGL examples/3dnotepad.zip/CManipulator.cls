VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CManipulator"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: Allows manipulation of objects
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES: This class is coming along. It has some glitches though.
'--------------------------------------------------------------------
Public Enum ManipulatorEditModes
    mmNone = 0
    mmRotate = 1
    mmScale = 2
    mmTranslate = 3
End Enum
Public Enum CAxisConstants
    XAxis = 0
    YAxis = 1
    ZAxis = 2
    NoAxis = 3
End Enum
'----------------------------------------------------------------
'on sphere
Dim m_MouseNowX!, m_MouseNowY!
Dim m_MouseLastX!, m_MouseLastY!
Dim m_MouseDownX!, m_MouseDownY!
'actual mouse x,y values
Dim m_MNowX!, m_MNowY!
Dim m_MLastX!, m_MLastY!
Dim m_MDownX!, m_MDownY!
'
Dim m_QuatNow!(0 To 3)
Dim m_QuatLast!(0 To 3)
Dim m_QuatStart!(0 To 3)
Dim m_Axis As CAxisConstants
Dim m_EditMode As ManipulatorEditModes
Dim m_Zoom!
'----------------------------------------------------------------
Dim m_Area As CArea 'the selected Area we are manipulating
Dim mId!(0 To 15) '
Dim m_Width&, m_Height&
Dim winx#, winy#, winz# 'model center

Private Sub Class_Initialize()
    EditMode = mmNone
    Axis = NoAxis
    m_Zoom = 1
    Reset
End Sub

'----------------------------------------------------------------
'reset defaults before loading the data for a Area
'----------------------------------------------------------------
Public Sub Reset()
Dim i&
    'Debug.Print "reset"
    Qt_One m_QuatStart
    Qt_One m_QuatNow
    m_MouseNowX = 0: m_MouseNowY = 0
    m_MouseDownX = 0: m_MouseDownY = 0
    FillArrayf mId, 1, 0, 0, 0, _
                      0, 1, 0, 0, _
                      0, 0, 1, 0, _
                      0, 0, 0, 1
End Sub

'----------------------------------------------------------------
'Set an active axis, or none.  The axis is the axis scales
'and translations will affect, or around which the model rotates.
'----------------------------------------------------------------
Public Property Let Axis(NewAxis As CAxisConstants)
    If NewAxis < 0 Or NewAxis > 3 Then Debug.Assert 0
    m_Axis = NewAxis
End Property

Public Property Get Axis() As CAxisConstants
    Axis = m_Axis
End Property

'----------------------------------------------------------------
'Set the transform mode - Translate, Scale, Rotate
'----------------------------------------------------------------
Public Property Let EditMode(NewValue As ManipulatorEditModes)
    m_EditMode = NewValue
End Property

Public Property Get EditMode() As ManipulatorEditModes
    EditMode = m_EditMode
End Property

'----------------------------------------------------------------
Public Sub SetView(Zoom!, Width&, Height&)
    m_Width = Width
    m_Height = Height
    m_Zoom = Zoom
End Sub

'----------------------------------------------------------------
Public Property Get Area() As CArea
    Set Area = m_Area
End Property

'----------------------------------------------------------------
'reset the ball data when a Area is picked
Public Property Set Area(ByVal NewValue As CArea)
Dim i&
Dim dx!, dy!, dz!, a!
    If NewValue Is Nothing Then
        Set m_Area = Nothing
        Axis = NoAxis
    ElseIf Not m_Area Is NewValue Then
        Reset
        Set m_Area = NewValue
    End If
End Property

Public Sub Resize(Width As Long, Height As Long)
    m_Width = Width
    m_Height = Height
End Sub

'----------------------------------------------------------------
' Begin pick or drag sequence.
Public Sub MouseDown(ByVal X!, ByVal Y!)
Dim dx!, dy!, dz!, a!
    If Area Is Nothing Then Exit Sub
    '----------------------------------------------------------------
    'save actual mouse values
    m_MDownX = X: m_MDownY = Y
    m_MNowX = X: m_MNowY = Y
    m_MLastX = X: m_MLastY = Y
    'save mouse values in a range of -1 to 1
    m_MouseNowX = 2 * X / m_Width - 1
    m_MouseNowY = 2 * (m_Height - Y) / m_Height - 1
    m_MouseDownX = m_MouseNowX
    m_MouseDownY = m_MouseNowY
    m_MouseLastX = m_MouseNowX
    m_MouseLastY = m_MouseNowY
    'convert the object's gl rotation to a quat
    Area.GetRotation a, dx, dy, dz
    Qt_FromAxis m_QuatStart, a, dx, dy, dz
    Qt_Copy m_QuatNow, m_QuatStart
    Qt_Copy m_QuatLast, m_QuatStart
End Sub

'----------------------------------------------------------------
' Incorporate new mouse position.
Public Sub MouseMove(X!, Y!)
    If Area Is Nothing Then Exit Sub
    'for translation
    m_MNowX = X
    m_MNowY = Y
    'for rotation
    m_MouseNowX = 2 * X / m_Width - 1
    m_MouseNowY = 2 * (m_Height - Y) / m_Height - 1
    '
    Update
    '
    m_MLastX = m_MNowX
    m_MLastY = m_MNowY
    '
    m_MouseLastX = m_MouseNowX
    m_MouseLastY = m_MouseNowY
End Sub


'----------------------------------------------------------------
' Using m_MouseDownX, vNow, dragging, and axisSet, compute rotation etc.
Public Sub Update()
Dim i&, v4!(0 To 3)
Dim vFrom!(0 To 3)
Dim vTo!(0 To 3)
Dim QuatDrag!(0 To 3), F!
Dim dx!, dy!, dz!, a!
Dim m!(0 To 15)
    '
    Select Case CX.EditMode
    Case n3dRotate
        m_MouseOnSphere m_MouseDownX, m_MouseDownY, vFrom 'could do just once per
        m_MouseOnSphere m_MouseNowX, m_MouseNowY, vTo
        Qt_FromBallPoints vFrom, vTo, QuatDrag 'get quat describing the drag
        Qt_Mul QuatDrag, m_QuatStart, m_QuatNow 'mul to Now
        Qt_Conj m_QuatNow, v4 ' Gives transpose for GL.
        Qt_ToAxis v4, a, dx, dy, dz 'return to axis/angle
        Debug.Print a
        If Not Area Is Nothing Then
            Area.SetRotation a, dx, dy, dz
        End If
    Case n3dScale
        F = m_MouseNowY - m_MouseLastY
        If F > 0 Then
            F = 1 + F
        ElseIf F < 0 Then
            F = 1 - Abs(F) 'f * 0.9
        Else: Exit Sub
        End If
        Area.Width = Area.Width * F
        Area.Height = Area.Height * F
    Case n3dTranslate
        dx = m_MNowX - m_MLastX
        dy = m_MNowY - m_MLastY
        dx = dx * m_Zoom / 50
        dy = dy * m_Zoom / 50
        Area.GetTranslation vFrom(0), vFrom(1), vFrom(2)
        With gCtl.Trackball
            .GetCurrentRotMatrix m
        End With
        vTo(0) = dx
        vTo(1) = dy
        vTo(2) = 0
        MAT_DOT_VEC_3X3_4 v4, m, vTo
        'Debug.Print "move"
        Area.SetTranslation vFrom(0) + v4(0), vFrom(1) - v4(1), vFrom(2) + v4(2)
    End Select
End Sub

'----------------------------------------------------------------
' Convert window coordinates to sphere coordinates.
Private Function m_MouseOnSphere(X!, Y!, v!())
Dim MAG#, scale_#
    v(0) = X '- Center(0)) ' / Radius
    v(1) = Y ' - Center(1)) ' / Radius
    MAG = v(0) * v(0) + v(1) * v(1)
    If (MAG > 1) Then
        scale_ = 1 / Sqr(MAG)
        v(0) = v(0) * scale_
        v(1) = v(1) * scale_
        v(2) = 0
    Else
        v(2) = Sqr(1 - MAG)
    End If
    v(3) = 0
End Function

'----------------------------------------------------------------
' Constrgctlt a unit quaternion vFrom two points on unit sphere
Private Sub Qt_FromBallPoints(vFrom!(), vTo!(), q!())
    q(0) = vFrom(1) * vTo(2) - vFrom(2) * vTo(1)
    q(1) = vFrom(2) * vTo(0) - vFrom(0) * vTo(2)
    q(2) = vFrom(0) * vTo(1) - vFrom(1) * vTo(0)
    q(3) = vFrom(0) * vTo(0) + vFrom(1) * vTo(1) + vFrom(2) * vTo(2)
End Sub

'----------------------------------------------------------------
' Convert window coordinates to disk coordinates.
Private Function m_MouseOnDisk(X!, Y!, v!())
    Debug.Print "x,y"
    Debug.Print X, Y
'    Select Case m_View
'    Case CTop: v(0) = X: v(1) = 0: v(2) = Y
'    Case CBottom:  v(0) = X: v(1) = 0: v(2) = -Y
'    Case CFront: v(0) = X: v(1) = Y: v(2) = 0
'    Case CBack: v(0) = -X: v(1) = Y: v(2) = 0
'    Case CRight: v(0) = 0: v(1) = Y: v(2) = X
'    Case CLeft: v(0) = 0: v(1) = Y: v(2) = -X
'    End Select
    v(0) = X: v(1) = Y: v(2) = 0
    V3_Unit v, v
End Function

'----------------------------------------------------------------
' Constrgctlt a unit quaternion vFrom two points on unit sphere
'Private Sub Qt_FromDiskPoints(q!())
'Dim dot!, v!(0 To 3), vFrom!(0 To 3), vTo!(0 To 3)
'    Debug.Print "Object center:" & winx & "," & winy
'    m_MouseOnDisk m_MDownX - winx, m_MDownY - winy, vFrom
'    m_MouseOnDisk m_MNowX - winx, m_MNowY - winy, vTo
'    'VEC_DOT_PRODgctlT dot, vFrom, vTo
'    'dot = atan2(vTo(0) - vFrom(0), vTo(1) - vFrom(1))
'    dot = RadToDegf(dot)
'    Debug.Print "Angle:" & dot
'    Select Case m_View
'    Case CTop: v(0) = 0: v(1) = 1: v(2) = 0
'    Case CBottom:  v(0) = 0: v(1) = -1: v(2) = 0
'    Case CFront: v(0) = 0: v(1) = 0: v(2) = 1
'    Case CBack: v(0) = 0: v(1) = 0: v(2) = -1
'    Case CRight: v(0) = -1: v(1) = 0: v(2) = 0
'    Case CLeft: v(0) = 1: v(1) = 0: v(2) = 0
'    End Select
'    Qt_FromAxis q, dot, v(0), v(1), v(2)
'End Sub

'Public Sub Draw()
'Dim viewport&(0 To 3)
'Dim mvm#(0 To 15), pm#(0 To 15)
'Dim res&
'    glGetIntegerv GL_VIEWPORT, viewport(0)
'    glGetDoublev glgModelViewMatrix, mvm(0)
'    glGetDoublev glgProjectionMatrix, pm(0)
'    res = gluProject(0, 0, 0, mvm(0), pm(0), viewport(0), winx, winy, winz)
'End Sub

'----------------------------------------------------------------
' Return conjugate of quaternion.
Public Sub Qt_One(q!())
    q(0) = 0
    q(1) = 0
    q(2) = 0
    q(3) = 1
End Sub

'------------------------------------------------------------
' *  Given an axis and angle, compute quaternion.
' a(3), q(4)
Public Sub Qt_FromAxis(q!(), a!, X!, Y!, z!)
'Dim v!(0 To 2)
    q(0) = X: q(1) = Y: q(2) = z
    Qt_Normal q
    Qt_Scale q, Sin(a / 2)
    q(3) = Cos(DegToRadf(a) / 2)
End Sub

'----------------------------------------------------------------
' Return version of v scaled by s
Public Sub Qt_Normal(q!())
Dim lng!
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    Qt_Scale q, 1 / lng
End Sub


'----------------------------------------------------------------
' Return version of v scaled by s
Public Sub Qt_Scale(q!(), s!)
    q(0) = s * q(0)
    q(1) = s * q(1)
    q(2) = s * q(2)
End Sub

'----------------------------------------------------------------
' Return conjugate of quaternion.
Public Sub Qt_Copy(qTo!(), qFrom!())
    qTo(0) = qFrom(0)
    qTo(1) = qFrom(1)
    qTo(2) = qFrom(2)
    qTo(3) = qFrom(3)
End Sub

'----------------------------------------------------------------
' Return quaternion prodgctlt qL * qR.  Note: order is important!
'  To combine rotations, use the prodgctlt Mul(qSecond, qFirst),
'  which gives the effect of rotating by qFirst then qSecond.
Public Sub Qt_Mul(qL!(), qR!(), q!())
Dim i&, qq!(0 To 3)
    qq(3) = qL(3) * qR(3) - qL(0) * qR(0) - qL(1) * qR(1) - qL(2) * qR(2)
    qq(0) = qL(3) * qR(0) + qL(0) * qR(3) + qL(1) * qR(2) - qL(2) * qR(1)
    qq(1) = qL(3) * qR(1) + qL(1) * qR(3) + qL(2) * qR(0) - qL(0) * qR(2)
    qq(2) = qL(3) * qR(2) + qL(2) * qR(3) + qL(0) * qR(1) - qL(1) * qR(0)
    For i = 0 To 3
        q(i) = qq(i)
    Next
End Sub

'----------------------------------------------------------------
' Return conjugate of quaternion.
Public Sub Qt_Conj(q!(), qconj!())
    qconj(0) = -q(0)
    qconj(1) = -q(1)
    qconj(2) = -q(2)
    qconj(3) = q(3)
End Sub


Public Sub Qt_ToAxis(q!(), Angle!, X!, Y!, z!)
Dim lng!, q1!(0 To 3), s!
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    If lng > 0.00001 Then
        'vnormal q
        '    vscale v, 1 / vlength(v)
        Qt_Scale2 q1, q, 1 / lng
        X = q1(0)
        Y = q1(1)
        z = q1(2)
        Angle = RadToDegf(2 * ArcCos(q(3)))
    Else
        X = 0
        Y = 0
        z = 1
        Angle = 0
    End If
End Sub

'----------------------------------------------------------------
' Return unit magnitude vector in direction of v
Public Sub V3_Unit(v!(), vunit!())
Dim vlen!
    vlen = Sqr(V3_Norm(v))
    If (vlen <> 0) Then
        vunit(0) = v(0) / vlen
        vunit(1) = v(1) / vlen
        vunit(2) = v(2) / vlen
    End If
    vunit(3) = 0
End Sub

' ==========================================================
' matrix times vector
'ONLY FOR 4X4 M!
Public Sub MAT_DOT_VEC_3X3_4(p!(), m!(), v!())
'   p(0) = m(0, 0) * v(0) + m(0, 1) * v(1) + m(0, 2) * v(2)
'   p(1) = m(1, 0) * v(0) + m(1, 1) * v(1) + m(1, 2) * v(2)
'   p(2) = m(2, 0) * v(0) + m(2, 1) * v(1) + m(2, 2) * v(2)
   p(0) = m(0) * v(0) + m(1) * v(1) + m(2) * v(2)
   p(1) = m(4) * v(0) + m(5) * v(1) + m(6) * v(2)
   p(2) = m(8) * v(0) + m(9) * v(1) + m(10) * v(2)
End Sub


'------------------------------------------------------------
Public Function DegToRadf!(a!)
DegToRadf = a * PI * ONE_OVER_180
End Function

Public Function RadToDegf!(a!)
RadToDegf = (a * 180) * ONE_OVER_PI
End Function


'----------------------------------------------------------------
' Return version of v scaled by s
Public Sub Qt_Scale2(qDest!(), q!(), s!)
    qDest(0) = s * q(0)
    qDest(1) = s * q(1)
    qDest(2) = s * q(2)
End Sub


'----------------------------------------------------------------
' Return norm of v, defined as sum of squares of components
Public Function V3_Norm!(v!())
    V3_Norm = v(0) * v(0) + v(1) * v(1) + v(2) * v(2)
End Function


