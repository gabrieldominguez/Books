VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "gleExtrusion"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim gc As gleGC

Private Sub Class_Initialize()
    ReDim gc.up(0 To 2)
    gc.up(1) = 1
    gc.JoinStyle = gleANGLE
    gc.CapStyle = gleCAPS
    gc.NormStyle = gleFACET
    gc.ContourStyle = gleOPEN
End Sub

Private Sub Class_Terminate()
'
End Sub

'-------------------------------------------------------------------------== */
'public sub gleExtrusion (ncp&,               ' number of contour points */
'                gleDouble contour()(2),    ' 2D contour */
'                gleDouble cont_normal()(2), ' 2D contour normals */
'                gleDouble up(3),           ' up vector for contour */
'                int npoints,           ' numpoints in poly-line */
'                gleDouble point_array()(3),        ' polyline */
'                float color_array()(3))        ' color of polyline */
'-------------------------------------------------------------------------== */
Public Sub Draw()
    SuperExtrusion gc
End Sub

'-------------------------------------------------------------------------
'PUBLIC PROPERTIES
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'ncp
'-------------------------------------------------------------------------
Public Property Get NumContourPoints() As Long
NumContourPoints = gc.ncp
End Property

Public Property Let NumContourPoints(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncp = 0
    Erase gc.contour
Else
    gc.ncp = NewValue
    ReDim Preserve gc.contour(0 To gc.ncp - 1)
End If
End Property

'-------------------------------------------------------------------------
'contour
'-------------------------------------------------------------------------
Public Sub GetContourPt(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.contour(Index).v(0)
    y = gc.contour(Index).v(1)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetContourPt(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.contour(Index).v(0) = x
    gc.contour(Index).v(1) = y
Exit Sub

eh: gEH 1
End Sub

Public Property Get CPtX(ByVal Index&) As Double
On Error GoTo eh
    CPtX = gc.contour(Index).v(0)
Exit Property
eh: gEH 1
End Property

Public Property Let CPtX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.contour(Index).v(0) = NewX
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CPtY(ByVal Index&) As Double
On Error GoTo eh
    CPtY = gc.contour(Index).v(1)
Exit Property
eh: gEH 1
End Property

Public Property Let CPtY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.contour(Index).v(1) = NewY
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
'ncnormals
'-------------------------------------------------------------------------
Public Property Get NumContourNormals() As Long
NumContourNormals = gc.ncnormals
End Property

Public Property Let NumContourNormals(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncnormals = 0
    Erase gc.cont_normal
Else
    gc.ncnormals = NewValue
    ReDim Preserve gc.cont_normal(0 To gc.ncnormals - 1)
End If
End Property

'-------------------------------------------------------------------------
'cont_normal
'-------------------------------------------------------------------------
Public Sub GetContourNormal(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.cont_normal(Index).v(0)
    y = gc.cont_normal(Index).v(1)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetContourNormal(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = x
    gc.cont_normal(Index).v(1) = y
Exit Sub

eh: gEH 1
End Sub

Public Property Get CNX(ByVal Index&) As Double
On Error GoTo eh
    CNX = gc.cont_normal(Index).v(0)
Exit Property
eh: gEH 1
End Property

Public Property Let CNX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = NewX
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CNY(ByVal Index&) As Double
On Error GoTo eh
    CNY = gc.cont_normal(Index).v(1)
Exit Property
eh: gEH 1
End Property

Public Property Let CNY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(1) = NewY
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
'up
'-------------------------------------------------------------------------
Public Sub GetUp(x#, y#, z#)
On Error GoTo eh
    x = gc.up(0)
    y = gc.up(1)
    z = gc.up(2)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetUp(ByVal x#, ByVal y#, ByVal z#)
On Error GoTo eh
    gc.up(0) = x
    gc.up(1) = y
    gc.up(2) = z
Exit Sub
eh: gEH 1
End Sub


'-------------------------------------------------------------------------
'npoints
'-------------------------------------------------------------------------
Public Property Get NumPoints() As Long
NumPoints = gc.npoints
End Property

Public Property Let NumPoints(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.npoints = 0
    Erase gc.point_array ' m_Pts
Else
    gc.npoints = NewValue
    ReDim Preserve gc.point_array(0 To gc.npoints - 1)
End If
End Property

'-------------------------------------------------------------------------
'point_array
'-------------------------------------------------------------------------
Public Sub GetPt(ByVal Index&, x#, y#, z#)
On Error GoTo eh
    x = gc.point_array(Index).v(0)
    y = gc.point_array(Index).v(1)
    z = gc.point_array(Index).v(2)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetPt(ByVal Index&, ByVal x#, ByVal y#, ByVal z#)
On Error GoTo eh
    gc.point_array(Index).v(0) = x
    gc.point_array(Index).v(1) = y
    gc.point_array(Index).v(2) = z
Exit Sub
eh: gEH 1
End Sub

Public Property Get PtX(ByVal Index&) As Double
On Error GoTo eh
    PtX = gc.point_array(Index).v(0)
Exit Property
eh: gEH 1
End Property

Public Property Let PtX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.point_array(Index).v(0) = NewX
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get PtY(ByVal Index&) As Double
On Error GoTo eh
    PtY = gc.point_array(Index).v(1)
Exit Property

eh: gEH 1
End Property

Public Property Let PtY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.point_array(Index).v(1) = NewY
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get PtZ(ByVal Index&) As Double
On Error GoTo eh
    PtZ = gc.point_array(Index).v(2)
Exit Property

eh: gEH 1
End Property

Public Property Let PtZ(ByVal Index&, ByVal NewZ As Double)
On Error GoTo eh
    gc.point_array(Index).v(2) = NewZ
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
'color_array
'-------------------------------------------------------------------------
'-------------------------------------------------------------------------
'number of colors
'-------------------------------------------------------------------------
Public Property Get NumColors() As Long
NumColors = gc.ncolors
End Property

Public Property Let NumColors(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncolors = 0
    Erase gc.color_array
Else
    gc.ncolors = NewValue
    ReDim Preserve gc.color_array(0 To gc.ncolors - 1)
End If
End Property

'-------------------------------------------------------------------------
'color_array
'-------------------------------------------------------------------------
Public Sub GetColor(ByVal Index&, r#, g#, b#)
On Error GoTo eh
    r = gc.color_array(Index).v(0)
    g = gc.color_array(Index).v(1)
    b = gc.color_array(Index).v(2)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetColor(ByVal Index&, ByVal r#, ByVal g#, ByVal b#)
On Error GoTo eh
    gc.color_array(Index).v(0) = r
    gc.color_array(Index).v(1) = g
    gc.color_array(Index).v(2) = b
Exit Sub
eh: gEH 1
End Sub

Public Property Get Red(ByVal Index&) As Double
On Error GoTo eh
    Red = gc.color_array(Index).v(0)
Exit Property

eh: gEH 1
End Property

Public Property Let Red(ByVal Index&, ByVal NewValue As Double)
On Error GoTo eh
    gc.color_array(Index).v(0) = NewValue
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get Green(ByVal Index&) As Double
On Error GoTo eh
    Green = gc.color_array(Index).v(1)
Exit Property

eh: gEH 1
End Property

Public Property Let Green(ByVal Index&, ByVal NewValue As Double)
On Error GoTo eh
    gc.color_array(Index).v(1) = NewValue
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get Blue(ByVal Index&) As Double
On Error GoTo eh
    Blue = gc.color_array(Index).v(2)
Exit Property

eh: gEH 1
End Property

Public Property Let Blue(ByVal Index&, ByVal NewValue As Double)
On Error GoTo eh
    gc.color_array(Index).v(2) = NewValue
Exit Property

eh: gEH 1
End Property

' ======================================================= */
Public Property Get TextureEnabled() As Boolean
TextureEnabled = gc.TextureEnabled
End Property

Public Property Let TextureEnabled(ByVal NewValue As Boolean)
If NewValue Then
    gc.TextureEnabled = True
Else
    gc.TextureEnabled = False
End If
End Property

' ======================================================= */
Public Property Get TextureMode() As gleTextureModes
TextureMode = gc.TextureMode
End Property

Public Property Let TextureMode(ByVal mode As gleTextureModes)
gc.TextureMode = mode
SetTextureMode gc
End Property

' ======================================================= */
Public Property Get JoinStyle() As gleJoinStyles
JoinStyle = gc.JoinStyle
End Property

Public Property Let JoinStyle(ByVal NewValue As gleJoinStyles)
gc.JoinStyle = NewValue
End Property

' ======================================================= */
Public Property Get NormStyle() As gleNormStyles
NormStyle = gc.NormStyle
End Property

Public Property Let NormStyle(ByVal NewValue As gleNormStyles)
gc.NormStyle = NewValue
End Property

' ======================================================= */
Public Property Get ContourStyle() As gleContourStyles
ContourStyle = gc.ContourStyle
End Property

Public Property Let ContourStyle(ByVal NewValue As gleContourStyles)
gc.ContourStyle = NewValue
End Property

' ======================================================= */
Public Property Get CapStyle() As gleCapStyles
CapStyle = gc.CapStyle
End Property

Public Property Let CapStyle(ByVal NewValue As gleCapStyles)
gc.CapStyle = NewValue
End Property




