Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CXXX
Public ActiveContour As CContour
Public optLights As Boolean
'
Public Const PI = 3.141592654
Public Const FLOAT_MAX = 3.402823466E+38
Type VERTEX
    Pt(0 To 8) As Double
End Type

Type POINT4F
    P(0 To 3) As Single
End Type

Type POINT3D
    P(0 To 2) As Double
End Type

Type POINT2F
    P(0 To 1) As Single
End Type
Type POINT2I
    P(0 To 1) As Long
End Type
Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (Dest As Byte, Src As Byte, ByVal length&)
Declare Sub CopyToDoubleFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
        (Dest#, ByVal PtrSrc&, ByVal length&)
Declare Sub CopyToSingleFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
        (Dest!, ByVal PtrSrc&, ByVal length&)

'----------------------------------------------------------------------------
Public Sub Main()
Set gCtl = frmMain.glxCtl1
Set CX = New CXXX
gCtl.Init
frmMain.Show
'this enables a VB timer to fire Paint events:
'gCtl.Animate = True
End Sub

'----------------------------------------------------------------------------
Public Sub CheckError()
Dim s$
    Do
        s = gCtl.GetErr
        If Len(s) Then
            Debug.Print s
            Debug.Assert 0
        Else: Exit Sub
        End If
    Loop
End Sub

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(A() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(A!(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(A&(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub


'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(A() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        A(i, j).P(0) = n(cnt)
        A(i, j).P(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

Public Function Max(A, b)
Max = IIf(A > b, A, b)
End Function

Public Function Min(A, b)
Min = IIf(A < b, A, b)
End Function

'------------------------------------------------------------
Public Function ULong(lng&) As Double
On Error GoTo EH
    If lng < 0 Then
        ULong = 2147483648# + 2147483648# + lng
    Else
        ULong = lng
    End If
    Exit Function
EH:
    Debug.Assert 0
    Resume Next
End Function

'-------------------------------------------------------------------------
Sub glBeginCB(ByVal which&)
Dim s$
    glBegin which
End Sub

'-------------------------------------------------------------------------
Sub glVertex3dvCB(ByRef arg#)
    glVertex3dv arg
End Sub

'-------------------------------------------------------------------------
Sub glEndCB()
    glEnd
End Sub

Sub glErrorCB(ByVal errorCode&) '???
Dim estring$, s$
    estring = gluErrorString(errorCode)
    Debug.Print "Tessellation Error: " & estring
    Select Case errorCode
    Case GLU_TESS_MISSING_BEGIN_POLYGON
        Debug.Assert 0
    Case GLU_TESS_MISSING_END_POLYGON
        Debug.Assert 0
    Case GLU_TESS_MISSING_BEGIN_CONTOUR
        Debug.Assert 0
    Case GLU_TESS_MISSING_END_CONTOUR
        Debug.Assert 0
    Case GLU_TESS_COORD_TOO_LARGE
        Debug.Assert 0
    Case GLU_TESS_NEED_COMBINE_CALLBACK
        Debug.Assert 0
    Case errorCode >= GLU_TESS_ERROR1 And errorCode <= GLU_TESS_ERROR8
        '10151-10158
        Debug.Assert 0
    Case Else
    Debug.Assert 0
    End Select
    Stop
End Sub

Sub CombineCB(ByVal c&, ByVal vdata&, ByVal weight&, ByRef dataOut&)
Dim coords#(0 To 2)
    'coords
    'Debug.Assert 0
    CopyToDoubleFromPtr coords(0), c, 3 * Len(coords(0))
    dataOut = ActiveContour.AddCombinePt(coords(0), coords(1), coords(2))
End Sub


