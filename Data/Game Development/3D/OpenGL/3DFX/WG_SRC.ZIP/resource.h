//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Wg.rc
//
#define IDD_GAMMA_CORRECTION            101
#define IDC_RESET                       1000
#define IDC_RED_SLIDER                  1001
#define IDC_GREEN_SLIDER                1002
#define IDC_BLUE_SLIDER                 1003
#define IDC_LOCK_SLIDERS                1004
#define IDC_RED_GAMMA                   1005
#define IDC_GREEN_GAMMA                 1006
#define IDC_BLUE_GAMMA                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
