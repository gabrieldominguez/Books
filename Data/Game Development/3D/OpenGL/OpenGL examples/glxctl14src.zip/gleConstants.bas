Attribute VB_Name = "gleConstants"
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: utility routines
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Public gleTextureEnabled As Boolean
'
Public Const POLYCYL_TESS = 20
Public Const ROUND_TESS_PIECES = 5
'
Public Const M_PI = 3.14159265358979

Public Enum HelixCallbackConstants
    hc_gleSpiral = 1
    hc_gleLathe = 2
End Enum


Public Enum BgnGenTextureConstants
    ZTexgen = 1
    SphereTexGen = 2
End Enum
Public Enum V3DGenTextureConstants
    VertexFlatTexgen_v = 1
    NormalFlatTexgen_v = 2
    VertexFlatModel_v = 3
    NormalFlatModel_v = 4
    VertexCylinderTexgen_v = 5
    NormalCylinderTexgen_v = 6
    VertexCylinderModel_v = 7
    NormalCylinderModel_v = 8
    VertexSphereTexgen_v = 9
    NormalTphereTexgen_v = 10
    VertexSphereModel_v = 11
    NormalSphereModel_v = 12
End Enum
Public Enum N3DGenTextureConstants
    SaveNormal = 1
End Enum

Type gleVector
    v(0 To 2) As Double
End Type

Type gleVector3i
    v(0 To 2) As Long
End Type

Type gleVector3f
    v(0 To 2) As Single
End Type

Type gleVector4i
    v(0 To 3) As Long
End Type

Type gleColor
    v(0 To 2) As Single
End Type
'
Type gleTwoVec
    v(0 To 1) As Double
End Type

Type gleAffine
    v0(0 To 2) As Double
    v1(0 To 2) As Double
End Type

'' ====================================================== */
Type gleGC
'  ' public methods */
    TextureMode As gleTextureModes
    TextureEnabled As Boolean
    ' protected members -- "general knowledge" stuff */
    JoinStyle As gleJoinStyles
    NormStyle As gleNormStyles
    ContourStyle As gleContourStyles
    CapStyle As gleCapStyles
    ' arguments passed into extrusion code */
    ncp As Long    ' number of contour points */
    contour() As gleTwoVec   ' 2D contour */
    ncnormals As Long 'edx: number of contour normals
    cont_normal() As gleTwoVec ' 2D contour normals */
    up() As Double              ' up vector */
    npoints As Long ' number of points in polyline */
    point_array() As gleVector    ' path */
    ncolors As Long 'edx
    color_array() As gleColor         ' path colors */
    nxforms As Long 'edx
    xform_array() As gleAffine ' contour xforms */

    ' private members, used by texturing code */
    BgnGenTextureFunc As BgnGenTextureConstants
    N3dGenTextureFunc As N3DGenTextureConstants
    V3dGenTextureFunc As V3DGenTextureConstants
    EndGenTextureFunc As Long
    ' private members, used by texturing code */
    NumVertices    As Long
    segment_number As Long
    segment_length As Double
    accum_seg_lng    As Double
    Prev_X As Double
    Prev_Y As Double
End Type

'-------------------------------------------------------------------------
'tess callbacks
Public Sub gleBegin(ByVal arg&)
    glBegin arg
End Sub

Sub gleVertex3dv(ByRef arg As Double)  '
    glVertex3dv arg
End Sub

Sub gleEnd()
    glEnd
End Sub

'-------------------------------------------------------------------------
'global error handler
Public Sub gEH(num&)
    If RaiseErrors Then
        Err.Raise num
    Else
        Debug.Assert 0
    End If
End Sub

'-------------------------------------------------------------------------
'hack to deal with null pointers without redesigning the
'function interfaces
'a few routines pass <undimensioned> arrays, when the function
'does need an array index.
'Note that many functions have had an explicit index parameter added, and
'the same technique could be used here, passing a -1 to indicate
'an invalid or Null array
'-------------------------------------------------------------------------
Public Function ArraySize&(v)
Dim lb&, ub&
On Error GoTo errorhandler
    ub = UBound(v, 1)
    lb = LBound(v, 1)
    If lb <> 0 Then Exit Function
    '
    ArraySize = ub + 1
Exit Function
errorhandler:
Debug.Assert 0
End Function

Public Function ArraySizeV&(v() As gleVector)
Dim lb&, ub&
On Error GoTo errorhandler
    ub = UBound(v, 1)
    lb = LBound(v, 1)
    If lb <> 0 Then Exit Function
    '
    ArraySizeV = ub + 1
Exit Function
errorhandler:
Debug.Assert 0
End Function

Public Function ArraySizeA&(v() As gleAffine)
Dim lb&, ub&
On Error GoTo errorhandler
    ub = UBound(v, 1)
    lb = LBound(v, 1)
    If lb <> 0 Then Exit Function
    '
    ArraySizeA = ub + 1
Exit Function
errorhandler:
'Debug.Assert 0
End Function


