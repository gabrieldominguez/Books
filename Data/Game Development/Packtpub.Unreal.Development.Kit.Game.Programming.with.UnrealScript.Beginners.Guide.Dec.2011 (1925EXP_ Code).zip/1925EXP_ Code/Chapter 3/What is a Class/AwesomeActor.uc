class AwesomeActor extends Actor
    placeable;

var() int MyInt;

function PostBeginPlay()
{
    `log(self @ MyInt);
}

defaultproperties
{
    MyInt=4

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
