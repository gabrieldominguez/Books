class AwesomeActor extends Actor
    placeable;

var int Int1;

function PostBeginPlay()
{
    do
    {
        `log("Int1" @ Int1);
        Int1++;
    } until (Int1 > 5);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
