/************************************************************
 * reading outline fonts from WP.DRS font file
 * (c) Lode Leroy
 * Thu Aug 18 22:42:27 WET DST 1994
 *
 *
 * there are still a few 'magic' numbers in here
 * due to incomplete understanding of the font file format
 * tested with WP.DRS from DrawPerfect 1.0
 */

#include <stdio.h>
#include <stdlib.h>
#include "globals.h"
#include "wpfonts.h"

/************************************************************
 * opens the font file 
 * reads in index, nindex, names; 
 *
 * export: ff, ff->filename, ff->index,
 *             ff->file_index, ff->file_names
 *             ff->font_index, ff->font_names
 */

font_file* 
wp_init_fonts(char* filename)
{
  font_file* ff;
  FILE* fp;
  int i;
  char* p;
  char* q;

  /* open file */
  fp=fopen(filename,"rb");
  if (fp==NULL)
  {
    fprintf(stderr,"file %s not found\n",filename);
    return NULL;
  }
  
  ff=(font_file*)malloc(sizeof(font_file));
  ff->filename=(char*)malloc(strlen(filename));
  strcpy(ff->filename,filename);
  
  /* read font data index */
  fseek(fp,0x12d0,SEEK_SET);
  ff->index=(index_entry*)calloc(sizeof(index_entry),WP_NUMFONTS);
  fread(ff->index,sizeof(index_entry),WP_NUMFONTS,fp);

  /* read file name index */
  fseek(fp,0x14e8,SEEK_SET);
  ff->file_index=(nindex_entry*)calloc(sizeof(nindex_entry),WP_NUMFONTS);
  fread(ff->file_index,sizeof(nindex_entry),WP_NUMFONTS,fp);

  /* read file name table */
  fseek(fp,0x156e,SEEK_SET);
  ff->file_names=(u_char*)malloc(1540);
  fread(ff->file_names,1,1540,fp);

  /* read font name table */
  fseek(fp,0xfd2,SEEK_SET);
  ff->font_names=(u_char*)malloc(617);
  fread(ff->font_names,1,617,fp);

  /* construct font name index */
  ff->font_index=(nindex_entry*)calloc(sizeof(nindex_entry),WP_NUMFONTS);
  for(i=0,p=ff->font_names;i<WP_NUMFONTS;i++)
  {
    ff->font_index[i].offset=(p-ff->font_names);
    q=p;
    p+=(int)(*p)+1;
    *q=0; /* zero terminate string */
  }

  /* close file */
  fclose(fp);
  return ff;
}

/************************************************************
 * frees memory malloc'ed in wp_init_fonts
 */

void
wp_exit_fonts(font_file* ff)
{
  free(ff->filename);
  free(ff->index);
  free(ff->file_index);
  free(ff->file_names);
  free(ff->font_index);
  free(ff->font_names);
  free(ff);
}

/************************************************************
 * reads the font outline data 
 *
 * export: fs, fs->filename, fs->number, fs->desc, fs->table, fs->data
 */

font_struct*
wp_load_font(font_file* ff, int number)
{
  font_struct* fs;
  FILE *fp;
  long offset;

  /* open file */
  fp=fopen(ff->filename,"rb");
  if (fp==NULL)
  {
    fprintf(stderr,"file %s not found\n",ff->filename);
    return NULL;
  }    
  
  fs=(font_struct*)malloc(sizeof(font_struct));
  fs->file=ff;
  fs->number=number;
  
  /* read descriptor */
  offset=0x123a+fs->file->index[fs->number].offset;
  fseek(fp,offset,SEEK_SET);
  fread(&fs->desc,sizeof(font_descriptor),1,fp);
  
  /* read table */
  fseek(fp,offset+fs->desc.table_offset,SEEK_SET);
  fs->table=(char_entry*)malloc((fs->desc.numchars)*sizeof(u_short));
  fread(fs->table,sizeof(u_short),(fs->desc.numchars),fp);

  /* read data */
  fseek(fp,offset+fs->desc.data_offset,SEEK_SET);
  fs->data=(char_data*)malloc(fs->desc.data_size);
  fread(fs->data,1,fs->desc.data_size,fp);
  
  /* fill in the nspace field of font */
  fs->nspace=wp_char_width(fs,'n');

  /* close file */
  fclose(fp);
  return fs;
}

/************************************************************
 * frees memory malloc'ed in wp_load_font
 */

void
wp_dispose_font(font_struct* fs)
{
  free(fs->table);
  free(fs->data);
  free(fs);
}
