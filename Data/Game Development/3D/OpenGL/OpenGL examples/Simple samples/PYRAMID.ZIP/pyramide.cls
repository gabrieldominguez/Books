VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "pyramide"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'co-ordinates of the pyramide
Private xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd, xe, ye, ze As GLfloat

'dimension of the pyramide
Private de As Single

'center of the pyramide
Private xcentre, ycentre, zcentre As Single

'name given to the pyramide (not use here)
Public nom As String

'eye position (camera)
Private x50, y50, z50 As Single

'angles of each polygon with the camera
Private angle1 As GLfloat
Private angle2 As GLfloat
Private angle3 As GLfloat
Private angle4 As GLfloat

'vector normal of each face polygon
Private xn1, yn1, zn1 As Single
Private xn2, yn2, zn2 As Single
Private xn3, yn3, zn3 As Single
Private xn4, yn4, zn4 As Single

Public Sub rotation_gauche()

'rotate without glrotated

Dim a, b As Single

'center of rotation
a = xcentre
b = zcentre

Dim t, e, f As Double

Dim degr� As Double

degr� = 12

'convert in radians
t = degr� * 0.017453293

e = Cos(t)
f = Sin(t)

Dim un, deux As Single

'first point
un = xa - a
deux = za - b
xa = a + un * e - deux * f
za = b + un * f + deux * e

'second point
un = xb - a
deux = zb - b
xb = a + un * e - deux * f
zb = b + un * f + deux * e

'third point
un = xc - a
deux = zc - b
xc = a + un * e - deux * f
zc = b + un * f + deux * e

'fourth point
un = xd - a
deux = zd - b
xd = a + un * e - deux * f
zd = b + un * f + deux * e

'top of the pyramide
un = xe - a
deux = ze - b
xe = a + un * e - deux * f
ze = b + un * f + deux * e

End Sub
Public Sub rotation_droite()

'rotate without glrotated

Dim a, b As Single

'center of rotation
a = xcentre
b = zcentre

Dim t, e, f As Double

Dim degr� As Double

degr� = -12

'convertion in radians
t = degr� * 0.017453293

e = Cos(t)
f = Sin(t)

Dim un, deux As Single

'first point
un = xa - a
deux = za - b
xa = a + un * e - deux * f
za = b + un * f + deux * e

'second point
un = xb - a
deux = zb - b
xb = a + un * e - deux * f
zb = b + un * f + deux * e

'third point
un = xc - a
deux = zc - b
xc = a + un * e - deux * f
zc = b + un * f + deux * e

'fourth point
un = xd - a
deux = zd - b
xd = a + un * e - deux * f
zd = b + un * f + deux * e

'top of the pyramide
un = xe - a
deux = ze - b
xe = a + un * e - deux * f
ze = b + un * f + deux * e

End Sub
Public Sub poly_aed()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double


'vector ea
xbc = xa - xe
ybc = ya - ye
zbc = za - ze

'vector ed
xbd = xd - xe
ybd = yd - ye
zbd = zd - ze


'normal vector of the face
xn1 = (ybd * zbc) - (zbd * ybc)
yn1 = (zbd * xbc) - (xbd * zbc)
zn1 = (xbd * ybc) - (ybd * xbc)


'barycentre of the face
baryx1 = (xa + xe + xd) / 3
baryy1 = (ya + ye + yd) / 3
baryz1 = (za + ze + zd) / 3


'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn1) ^ 2 + (yn1) ^ 2 + (zn1) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn1 * xvo1
int2 = yn1 * yvo1
int3 = zn1 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle1 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_eab()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double


'vector ea
xbc = xe - xa
ybc = ye - ya
zbc = ze - za

'vector eb
xbd = xb - xe
ybd = yb - ye
zbd = zb - ze

'normal vector of the face
xn2 = (ybd * zbc) - (zbd * ybc)
yn2 = (zbd * xbc) - (xbd * zbc)
zn2 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xa + xe + xb) / 3
baryy1 = (ya + ye + yb) / 3
baryz1 = (za + ze + zb) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn2) ^ 2 + (yn2) ^ 2 + (zn2) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn2 * xvo1
int2 = yn2 * yvo1
int3 = zn2 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle2 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_ebc()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double

'vector be
xbc = xe - xb
ybc = ye - yb
zbc = ze - zb

'vector bc
xbd = xc - xb
ybd = yc - yb
zbd = zc - zb

'normal vector of the face
xn3 = (ybd * zbc) - (zbd * ybc)
yn3 = (zbd * xbc) - (xbd * zbc)
zn3 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xc + xe + xb) / 3
baryy1 = (yc + ye + yb) / 3
baryz1 = (zc + ze + zb) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn3) ^ 2 + (yn3) ^ 2 + (zn3) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn3 * xvo1
int2 = yn3 * yvo1
int3 = zn3 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle3 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_ecd()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double

'vector ce
xbc = xe - xc
ybc = ye - yc
zbc = ze - zc

'vector cd
xbd = xd - xc
ybd = yd - yc
zbd = zd - zc


'normal vector of the face
xn4 = (ybd * zbc) - (zbd * ybc)
yn4 = (zbd * xbc) - (xbd * zbc)
zn4 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xc + xe + xd) / 3
baryy1 = (yc + ye + yd) / 3
baryz1 = (zc + ze + zd) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn4) ^ 2 + (yn4) ^ 2 + (zn4) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn4 * xvo1
int2 = yn4 * yvo1
int3 = zn4 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle4 = a10b10 / (a10 * b10)

End Sub

Public Sub affichage(ByVal xoeil As Single, ByVal yoeil As Single, ByVal zoeil As Single)

'use co-ordinate of the camera
x50 = xoeil
y50 = yoeil
z50 = zoeil

'calculate angle between polygons and camera
poly_aed
poly_eab
poly_ebc
poly_ecd

'if the polygon is visible (angle>0)
'then draw on the frame buffer
If angle1 > 0 Then
aed
End If

If angle2 > 0 Then
eab
End If

If angle3 > 0 Then
ebc
End If

If angle4 > 0 Then
ecd
End If


End Sub
Public Sub eab()

Dim a As Double
a = Sqr((xn2) ^ 2 + (yn2) ^ 2 + (zn2) ^ 2) 'norme

Dim xv, yv, zv As GLfloat
'normalize
xv = Abs(xn2 / a)
yv = Abs(yn2 / a)
zv = Abs(zn2 / a)

'draw polygon "eab"

glBegin bmPolygon

glNormal3f xv, yv, zv

glColor3f 0.31, 0.31, 0.82 'blue medium

glVertex3f xe, ye, ze

glVertex3f xa, ya, za

glVertex3f xb, yb, zb

glEnd

End Sub
Public Sub ebc()

Dim a As Double
a = Sqr((xn3) ^ 2 + (yn3) ^ 2 + (zn3) ^ 2) 'norme

Dim xv, yv, zv As GLfloat
'normalize
xv = Abs(xn3 / a)
yv = Abs(yn3 / a)
zv = Abs(zn3 / a)

'draw polygon "ebc"

glBegin bmPolygon

glNormal3f xv, yv, zv

glColor3f 0.31, 0.31, 0.82 'blue medium

glVertex3f xe, ye, ze

glVertex3f xb, yb, zb

glVertex3f xc, yc, zc

glEnd


End Sub
Public Sub ecd()

Dim a As Double
a = Sqr((xn4) ^ 2 + (yn4) ^ 2 + (zn4) ^ 2) 'norme

Dim xv, yv, zv As GLfloat
'normalize
xv = Abs(xn4 / a)
yv = Abs(yn4 / a)
zv = Abs(zn4 / a)

'draw polygon "ecd"

glBegin bmPolygon

glNormal3f xv, yv, zv

glColor3f 0.31, 0.31, 0.82 'blue medium

glVertex3f xe, ye, ze

glVertex3f xc, yc, zc

glVertex3f xd, yd, zd

glEnd


End Sub
Public Sub aed()

'draw polygon "aed"

'the light is in the same axe as the pyramide

Dim a As Double
a = Sqr((xn1) ^ 2 + (yn1) ^ 2 + (zn1) ^ 2) 'norme

Dim xv, yv, zv As GLfloat
'normalize
xv = Abs(xn1 / a)
yv = Abs(yn1 / a)
zv = Abs(zn1 / a)

glBegin bmPolygon

glNormal3f xv, yv, zv

glColor3f 0.31, 0.31, 0.82 'blue medium

glVertex3f xa, ya, za

glVertex3f xe, ye, ze

glVertex3f xd, yd, zd

glEnd

End Sub


Private Sub Class_Initialize()

de = 0.6 'dimension de la pyramide

xcentre = 0
ycentre = 0
zcentre = 0

xa = xcentre - 3 * de
ya = ycentre
za = zcentre - 3 * de

xb = xcentre + 3 * de
yb = ycentre
zb = zcentre - 3 * de

xc = xcentre + 3 * de
yc = ycentre
zc = zcentre + 3 * de

xd = xcentre - 3 * de
yd = ycentre
zd = zcentre + 3 * de

'sommet
xe = xcentre
ye = ycentre + 5 * de
ze = zcentre


End Sub


