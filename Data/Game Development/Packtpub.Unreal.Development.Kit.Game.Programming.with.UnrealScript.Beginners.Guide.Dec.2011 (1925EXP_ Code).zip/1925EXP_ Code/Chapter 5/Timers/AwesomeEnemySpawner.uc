class AwesomeEnemySpawner extends AwesomeActor
    placeable;

var TestEnemy MySpawnedEnemy;

function TimedEnemySpawn()
{
    SetTimer(5.0 + FRand() * 5.0, false, 'SpawnEnemy');
}

function SpawnEnemy()
{
    if(MySpawnedEnemy == none)
        MySpawnedEnemy = spawn(class'TestEnemy', self,, Location);
}

function EnemyDied()
{
    TimedEnemySpawn();
}

function FreezeEnemy()
{
    if(MySpawnedEnemy != none)
        MySpawnedEnemy.Freeze();

    ClearTimer('SpawnEnemy');
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}