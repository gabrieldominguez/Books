
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _SBWG_
#define _SBWG_

#include <windows.h>

extern BOOL StretchBltWGInitialize(HWND, DWORD, DWORD);
extern VOID StretchBltWGShutdown(VOID);
extern VOID StretchBltWGCopy3DfxFrameBuffer(VOID);

#endif //_SBWG_
