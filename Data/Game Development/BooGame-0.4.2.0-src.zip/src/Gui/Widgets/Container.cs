/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public class Container : Widget
    {
        public Container()
        {
        }

        public Container(ColorF borderColor, ColorF backgroundColor)
        {
            m_BorderColor = borderColor;
            m_BackgroundColor = backgroundColor;
        }
        public Container(ColorF borderColor)
        {
            m_BorderColor = borderColor;
        }
        private ColorF m_BackgroundColor = Color.Transparent;
        public ColorF BackgroundColor
        {
            get { return m_BackgroundColor; }
            set { m_BackgroundColor = value; }
        }

        private ColorF m_BorderColor = Color.Transparent;
        public ColorF BorderColor
        {
            get { return m_BorderColor; }
            set { m_BorderColor = value; }
        }

        /// <summary>
        /// When overriden, draws the background of the widget.
        /// </summary>
        protected virtual void DrawBackground()
        {
            Paint.FilledRectangle(this.AbsoluteRectangle, m_BackgroundColor);
            Paint.Rectangle(this.AbsoluteRectangle, m_BorderColor);
        }

        private float m_Height = 100f;
        public override float Height
        {
            get { return m_Height; }
            set { m_Height = value; }
        }
        private float m_Width = 100f;
        public override float Width
        {
            get { return m_Width; }
            set { m_Width = value; }
        }

        public override void Draw()
        {
            if (Visible)
            {
                DrawBackground();
                base.Draw();
            }
        }
    }
}
