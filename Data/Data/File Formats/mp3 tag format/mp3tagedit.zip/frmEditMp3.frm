VERSION 5.00
Object = "{22D6F304-B0F6-11D0-94AB-0080C74C7E95}#1.0#0"; "msdxm.ocx"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmEditMp3 
   Caption         =   "Mp3 Tag Edit"
   ClientHeight    =   5040
   ClientLeft      =   1305
   ClientTop       =   2820
   ClientWidth     =   8505
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmEditMp3.frx":0000
   NegotiateMenus  =   0   'False
   ScaleHeight     =   5040
   ScaleWidth      =   8505
   Begin VB.Frame fraEdit 
      Caption         =   " &Edition : "
      ClipControls    =   0   'False
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2820
      Left            =   3740
      TabIndex        =   1
      Top             =   -30
      Width           =   4575
      Begin VB.TextBox txtPiste 
         Height          =   285
         Left            =   3990
         MaxLength       =   3
         TabIndex        =   22
         TabStop         =   0   'False
         Text            =   "txtPiste"
         Top             =   210
         Width           =   465
      End
      Begin VB.CommandButton cmdEnregistrer 
         Caption         =   "E&nregistrer"
         Default         =   -1  'True
         Height          =   465
         Left            =   3240
         TabIndex        =   19
         Top             =   2205
         Width           =   1155
      End
      Begin VB.Timer tmrPlay 
         Interval        =   1000
         Left            =   4095
         Top             =   2310
      End
      Begin VB.TextBox txtCommentaire 
         Height          =   285
         Left            =   1260
         MaxLength       =   30
         TabIndex        =   13
         Text            =   "txtCommentaire"
         Top             =   1785
         Width           =   3195
      End
      Begin VB.ComboBox cboGenre 
         Height          =   315
         IntegralHeight  =   0   'False
         Left            =   2730
         Sorted          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   11
         Top             =   1460
         Width           =   1730
      End
      Begin VB.TextBox txtAnnee 
         Height          =   285
         Left            =   1260
         MaxLength       =   4
         TabIndex        =   9
         Text            =   "txtAnnee"
         Top             =   1470
         Width           =   750
      End
      Begin VB.TextBox txtAlbum 
         Height          =   285
         Left            =   1260
         MaxLength       =   30
         TabIndex        =   7
         Text            =   "txtAlbum"
         Top             =   1155
         Width           =   3195
      End
      Begin VB.TextBox txtArtiste 
         Height          =   285
         Left            =   1260
         MaxLength       =   30
         TabIndex        =   5
         Text            =   "txtArtiste"
         Top             =   840
         Width           =   3195
      End
      Begin VB.TextBox txtTitre 
         Height          =   285
         Left            =   1260
         MaxLength       =   30
         TabIndex        =   3
         Text            =   "txtTitre"
         Top             =   525
         Width           =   3195
      End
      Begin VB.Label lblInfos 
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         Caption         =   "lblInfos"
         Height          =   285
         Left            =   1260
         TabIndex        =   24
         Top             =   210
         Width           =   2115
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Informations"
         Height          =   195
         Index           =   7
         Left            =   105
         TabIndex        =   23
         Top             =   210
         Width           =   915
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "&Piste :"
         Height          =   195
         Index           =   6
         Left            =   3465
         TabIndex        =   21
         Top             =   210
         Width           =   450
      End
      Begin VB.Label lblTrackInfo 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "lblTrackInfo"
         Height          =   255
         Left            =   1245
         TabIndex        =   18
         Top             =   2455
         Width           =   615
      End
      Begin MediaPlayerCtl.MediaPlayer mp3Player 
         Height          =   625
         Left            =   120
         TabIndex        =   17
         Top             =   2160
         Width           =   3015
         AudioStream     =   -1
         AutoSize        =   0   'False
         AutoStart       =   0   'False
         AnimationAtStart=   0   'False
         AllowScan       =   -1  'True
         AllowChangeDisplaySize=   0   'False
         AutoRewind      =   0   'False
         Balance         =   0
         BaseURL         =   ""
         BufferingTime   =   5
         CaptioningID    =   ""
         ClickToPlay     =   -1  'True
         CursorType      =   0
         CurrentPosition =   -1
         CurrentMarker   =   0
         DefaultFrame    =   ""
         DisplayBackColor=   0
         DisplayForeColor=   16777215
         DisplayMode     =   0
         DisplaySize     =   7
         Enabled         =   -1  'True
         EnableContextMenu=   -1  'True
         EnablePositionControls=   -1  'True
         EnableFullScreenControls=   0   'False
         EnableTracker   =   -1  'True
         Filename        =   ""
         InvokeURLs      =   0   'False
         Language        =   -1
         Mute            =   0   'False
         PlayCount       =   1
         PreviewMode     =   0   'False
         Rate            =   1
         SAMILang        =   ""
         SAMIStyle       =   ""
         SAMIFileName    =   ""
         SelectionStart  =   -1
         SelectionEnd    =   -1
         SendOpenStateChangeEvents=   0   'False
         SendWarningEvents=   0   'False
         SendErrorEvents =   -1  'True
         SendKeyboardEvents=   0   'False
         SendMouseClickEvents=   0   'False
         SendMouseMoveEvents=   0   'False
         SendPlayStateChangeEvents=   0   'False
         ShowCaptioning  =   0   'False
         ShowControls    =   -1  'True
         ShowAudioControls=   -1  'True
         ShowDisplay     =   0   'False
         ShowGotoBar     =   0   'False
         ShowPositionControls=   0   'False
         ShowStatusBar   =   0   'False
         ShowTracker     =   -1  'True
         TransparentAtStart=   0   'False
         VideoBorderWidth=   0
         VideoBorderColor=   0
         VideoBorder3D   =   0   'False
         Volume          =   -180
         WindowlessVideo =   0   'False
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "&Commentaire :"
         Height          =   195
         Index           =   5
         Left            =   105
         TabIndex        =   12
         Top             =   1785
         Width           =   1050
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "&Genre :"
         Height          =   195
         Index           =   4
         Left            =   2100
         TabIndex        =   10
         Top             =   1470
         Width           =   540
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "A&nn�e :"
         Height          =   195
         Index           =   3
         Left            =   105
         TabIndex        =   8
         Top             =   1470
         Width           =   570
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Al&bum :"
         Height          =   195
         Index           =   2
         Left            =   105
         TabIndex        =   6
         Top             =   1155
         Width           =   540
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "&Artiste :"
         Height          =   195
         Index           =   1
         Left            =   105
         TabIndex        =   4
         Top             =   840
         Width           =   585
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "&Titre :"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   2
         Top             =   525
         Width           =   435
      End
   End
   Begin VB.Frame fraDir 
      Caption         =   " R�pertoire : "
      ClipControls    =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2820
      Left            =   40
      TabIndex        =   14
      Top             =   -30
      Width           =   3615
      Begin VB.DirListBox dirTmp 
         Height          =   2115
         Left            =   120
         TabIndex        =   16
         Top             =   600
         Width           =   3375
      End
      Begin VB.DriveListBox drvTmp 
         Height          =   315
         Left            =   120
         TabIndex        =   15
         Top             =   240
         Width           =   3405
      End
      Begin VB.Label lblTotal 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "(Total: 0 Ko)"
         Height          =   195
         Left            =   2625
         TabIndex        =   20
         Top             =   0
         Width           =   900
      End
   End
   Begin MSComctlLib.ListView lvwListe 
      Height          =   2010
      Left            =   40
      TabIndex        =   0
      Top             =   2840
      Width           =   8235
      _ExtentX        =   14526
      _ExtentY        =   3545
      View            =   3
      LabelEdit       =   1
      Sorted          =   -1  'True
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      FullRowSelect   =   -1  'True
      GridLines       =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   0
   End
   Begin VB.Menu mnuFichier 
      Caption         =   "&Fichier"
      Begin VB.Menu mnuFichierExtension 
         Caption         =   "E&xtension"
      End
      Begin VB.Menu mnuFichierRenommer 
         Caption         =   "&Renommer"
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuFichierEffacer 
         Caption         =   "&Effacer"
      End
      Begin VB.Menu mnuFichierRafraichir 
         Caption         =   "R&afra�chir"
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuSep05 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFichierQuitter 
         Caption         =   "&Quitter"
         Shortcut        =   ^Q
      End
   End
   Begin VB.Menu mnuEdition 
      Caption         =   "&Edition"
      Begin VB.Menu mnuEditionMajuscule 
         Caption         =   "&Majuscule en d�but de mot"
         Shortcut        =   {F6}
      End
      Begin VB.Menu mnuSep07 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditionTitreArtiste 
         Caption         =   "&Titre <=> Artiste"
      End
      Begin VB.Menu mnuEditionTitreAlbum 
         Caption         =   "Titre <=> Al&bum"
      End
      Begin VB.Menu mnuEditionArtisteAlbum 
         Caption         =   "&Artiste <=> Album"
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuOptionsPropager 
         Caption         =   "&Propager valeur courante"
         Begin VB.Menu mnuOptionsArtiste 
            Caption         =   "&Artiste"
            Shortcut        =   +{F2}
         End
         Begin VB.Menu mnuOptionsAlbum 
            Caption         =   "Al&bum"
            Shortcut        =   +{F3}
         End
         Begin VB.Menu mnuOptionsAnnee 
            Caption         =   "A&nn�e"
            Shortcut        =   +{F4}
         End
         Begin VB.Menu mnuOptionsGenre 
            Caption         =   "&Genre"
            Shortcut        =   +{F5}
         End
         Begin VB.Menu mnuOptionsCommentaire 
            Caption         =   "&Commentaire"
            Shortcut        =   +{F6}
         End
      End
      Begin VB.Menu mnuSep10 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsFormat 
         Caption         =   "&Format de fichier"
      End
      Begin VB.Menu mnuOptionsAppliqueFormat 
         Caption         =   "&Appliquer le format"
         Shortcut        =   {F7}
      End
      Begin VB.Menu mnuOptionsAppliqueFormatTous 
         Caption         =   "Appliquer le format pour &tous"
         Shortcut        =   ^{F7}
      End
      Begin VB.Menu mnuOptionsAnnulerFormat 
         Caption         =   "A&nnuler le dernier format appliqu�"
      End
      Begin VB.Menu mnuSep20 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsPlaylist 
         Caption         =   "&G�n�rer une ""Playlist"" (.m3u)"
      End
      Begin VB.Menu mnuOptionsListing 
         Caption         =   "&Exporter l'arborescence"
      End
   End
   Begin VB.Menu mnuOutils 
      Caption         =   "O&utils"
      Begin VB.Menu mnuOutilsToutDezipper 
         Caption         =   "Tout &D�zipper"
         Shortcut        =   ^U
      End
      Begin VB.Menu mnuOutilsConfiguration 
         Caption         =   "&Configuration..."
         Shortcut        =   ^{F12}
      End
   End
   Begin VB.Menu mnuAide 
      Caption         =   "&Aide"
      Begin VB.Menu mnuAideForum 
         Caption         =   "&Forum en ligne"
      End
      Begin VB.Menu mnuSep23 
         Caption         =   "-"
      End
      Begin VB.Menu mnuAideMiseAJour 
         Caption         =   "&Chercher une mise � jour"
      End
      Begin VB.Menu mnuSep25 
         Caption         =   "-"
      End
      Begin VB.Menu mnuAideAPropos 
         Caption         =   "&A propos..."
         Shortcut        =   {F1}
      End
   End
   Begin VB.Menu mnuPopup 
      Caption         =   "&Popup"
      Visible         =   0   'False
      Begin VB.Menu mnuPopupEffacer 
         Caption         =   "&Effacer"
      End
      Begin VB.Menu mnuPopupPropager 
         Caption         =   "&Propager"
      End
      Begin VB.Menu mnuSep30 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPopupEchange 
         Caption         =   "Echanger avec &Titre"
         Index           =   2
      End
      Begin VB.Menu mnuPopupEchange 
         Caption         =   "Echanger avec &Artiste"
         Index           =   3
      End
      Begin VB.Menu mnuPopupEchange 
         Caption         =   "Echanger avec Al&bum"
         Index           =   4
      End
      Begin VB.Menu mnuPopupEchange 
         Caption         =   "Echanger avec &Commentaire"
         Index           =   7
      End
   End
End
Attribute VB_Name = "frmEditMp3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
' Format de fichier
Private stFormat As String

' ==================== Gestion des boutons de commande =====================

Private Sub cmdEnregistrer_Click()
' Enregistre les modifications courantes
Dim btTmp As Byte
If (lvwListe.ListItems.Count > 0) Then
    Me.Enabled = False
    ' Mise en place de l'index du genre
    If (cboGenre.ListIndex < 0) Then
        btTmp = 255
    Else
        btTmp = cboGenre.ItemData(cboGenre.ListIndex)
    End If
    ' Sauvegarde du fichier courant et mise � z�ro pour permettre la mise � jour
    mp3Player.Tag = mp3Player.FileName
    mp3Player.FileName = vbNullString
    ' Enregistrement des modifications
    EcrireTagID3v1 lvwListe.SelectedItem.Key, txtTitre.Text, txtArtiste.Text, _
                   txtAlbum.Text, txtAnnee.Text, btTmp, txtCommentaire.Text, _
                   txtPiste.Text
    ' Remise en position du fichier courant
    mp3Player.FileName = mp3Player.Tag
    lvwListe.SelectedItem.SubItems(1) = txtTitre.Text
    lvwListe.SelectedItem.SubItems(2) = txtArtiste.Text
    lvwListe.SelectedItem.SubItems(3) = txtAlbum.Text
    lvwListe.SelectedItem.SubItems(4) = txtAnnee.Text
    lvwListe.SelectedItem.SubItems(5) = cboGenre.Text
    lvwListe.SelectedItem.SubItems(6) = txtCommentaire.Text
    ' Ajustement de la taille des colonnes
    AdjustColListView lvwListe, Me
    Me.Enabled = True
    ' Replace le focus sur la liste
    lvwListe.SetFocus
End If
End Sub

' =================== Gestion des contr�les Dir et Drive ===================

Private Sub dirTmp_Click()
' Changement de r�pertoire courant
Dim stTmp As String
stTmp = dirTmp.List(dirTmp.ListIndex)
If (Right$(stTmp, 1) <> "\") Then stTmp = stTmp & "\"
If (stCurDir <> stTmp) Then
    stCurDir = stTmp
    ' Charge la liste des fichiers du r�pertoire choisi
    Call ChargeListe(stCurDir)
    lvwListe.SetFocus
    ' S�lection du premier �l�ment
    Call lvwListe_ItemClick(lvwListe.SelectedItem)
End If
End Sub

Private Sub drvTmp_Change()
' Changement de lecteur courant
On Error Resume Next
Err.Clear
dirTmp.Path = drvTmp.Drive
If (Err.Number <> 0) Then MsgBox Err.Description, vbExclamation, "Error"
End Sub

' ==================== Ev�nements associ�s � la feuille ====================
Private Sub Form_Load()
Dim lgFor As Long

' V�rifie l'existence d'une version plus r�cente
If blUpdate Then Call ChercheUpdate
' Initialisation du "moteur" mp3
Call InitMp3

' R�cup�ration de la configuration
blUpdate = GetSetting("MP3TagEdit", "Configuration", "Update", False)
intLOffset = GetSetting("MP3TagEdit", "Localization", "Language", -1)
If (intLOffset < 0) Then
    frmConfiguration.Show vbModal
Else
    ' Assure la compatibilit� avec la version pr�c�dente
    If (intLOffset = 50) Then intLOffset = 150
    Call initLocalization
End If
' Titre de la fen�tre
Me.Caption = "Mp3 Tag Edit (" & App.Major & "." & App.Minor & "." & App.Revision & ")"
' Centrage de la fen�tre
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2
' Initialisation des zones
txtTitre.Text = vbNullString
txtArtiste.Text = vbNullString
txtAlbum.Text = vbNullString
txtAnnee.Text = vbNullString
txtCommentaire.Text = vbNullString
txtPiste.Text = vbNullString
lblInfos.Caption = vbNullString
lblTrackInfo.Caption = vbNullString
stCurDir = vbNullString
' R�cup�ration du format courant dans la base de registre
stFormat = GetSetting("MP3TagEdit", "Fichier", "Format", "%2 - %t")
' Pr�paration de la liste des genres
For lgFor = 0 To UBound(Split(GENRE, "|"))
    cboGenre.AddItem Split(GENRE, "|")(lgFor)
    cboGenre.ItemData(cboGenre.NewIndex) = lgFor
Next lgFor
cboGenre.ListIndex = -1
' Charge le r�pertoire courant par d�faut
Call ChargeListe(App.Path)
End Sub

Private Sub Form_Resize()
' Redimensionnement des contr�les
On Error Resume Next
'If (Me.Height < 3930) Then Me.Width = 3930
If (Me.Width < 7360) Then Me.Width = 7360
If (Me.Width - fraEdit.Width - 220) > 2550 Then
    fraDir.Move fraDir.Left, fraDir.Top, Me.Width - fraEdit.Width - 300
Else
    fraDir.Move fraDir.Left, fraDir.Top, 2475
End If
drvTmp.Move drvTmp.Left, drvTmp.Top, fraDir.Width - 240
dirTmp.Move dirTmp.Left, dirTmp.Top, fraDir.Width - 240
lblTotal.Move fraDir.Width - lblTotal.Width - 100
fraEdit.Move fraDir.Width + 140
lvwListe.Move lvwListe.Left, lvwListe.Top, Me.Width - 200, _
              Me.Height - 740 - fraEdit.Height
End Sub

Private Sub Form_Unload(Cancel As Integer)
' Sauvegarde du format de fichier dans la base de registre
SaveSetting "MP3TagEdit", "Fichier", "Format", stFormat
End Sub

' ==================== Ev�nements du contr�le ListView =====================

Private Sub lvwListe_AfterLabelEdit(Cancel As Integer, NewString As String)
' Applique le nouveau nom au fichier
Dim stPath As String
Dim stExt As String
NewString = Trim$(NomFichierValide(NewString))
stExt = UCase$(Mid$(NewString, InStrRev(NewString, ".")))
If (stExt <> ".MP3") Then
    If (MsgBox(LoadResString(intLOffset + resRisque) & vbCrLf & _
               LoadResString(intLOffset + resContinuer), _
               vbQuestion + vbYesNo, rstrRenommer) <> vbYes) Then
        Cancel = True
        Exit Sub
    End If
End If
If (NewString <> vbNullString) Then
    ' Extraction du r�pertoire
    stPath = Left$(lvwListe.SelectedItem.Key, _
             InStrRev(lvwListe.SelectedItem.Key, "\"))
    ' Gestion d'erreur
    On Error Resume Next
    Err.Clear
    ' Renomme le fichier
    Name lvwListe.SelectedItem.Key As stPath & NewString
    If (Err.Number <> 0) Then
        MsgBox Err.Description, vbExclamation, "Erreur"
    Else
        ' Enregisrement du nouveau nom
        lvwListe.SelectedItem.Key = stPath & NewString
    End If
End If
' Recharge la liste dans le cas d'un changement d'extension
If (stExt <> ".MP3") Then Call ChargeListe(stCurDir)
End Sub

Private Sub lvwListe_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)
' Tri sur ent�te de colonne
Call ListViewColumnClick(lvwListe, ColumnHeader.Index)
End Sub

Private Sub lvwListe_GotFocus()
cmdEnregistrer.Default = False
End Sub

Private Sub lvwListe_KeyDown(KeyCode As Integer, Shift As Integer)
' Effet sp�cial associ� � la touche [F8], d�coupe le nom du fichier
' et en d�duit le titre et l'artiste.
Dim stText As String, stTmp As String
Select Case KeyCode
    Case vbKeyF8
        stText = Replace(lvwListe.SelectedItem.Text, "_", "-")
        If (InStr(1, stText, "-") > 0) Then
            txtArtiste.Text = Trim$(Mid$(stText, 1, InStr(1, stText, "-") - 1))
            stTmp = Trim$(Mid$(stText, InStr(1, stText, "-") + 1))
            stTmp = Left$(stTmp, Len(stTmp) - 4)
            txtTitre.Text = stTmp
            txtTitre.SetFocus
        End If
    Case vbKeyDelete
        Call mnuFichierEffacer_Click
End Select
End Sub

Private Sub lvwListe_KeyPress(KeyAscii As Integer)
If (KeyAscii = vbKeyReturn) Then txtTitre.SetFocus
End Sub

Private Sub lvwListe_LostFocus()
cmdEnregistrer.Default = True
End Sub

Private Sub lvwListe_ItemClick(ByVal Item As MSComctlLib.ListItem)
' S�lection d'un �l�ment
Dim stTmp(10) As String
If (lvwListe.ListItems.Count > 0) Then
    If Not lvwListe.SelectedItem Is Nothing Then
        LireTagID3v1 lvwListe.SelectedItem.Key, stTmp(0), stTmp(1), _
                     stTmp(2), stTmp(3), stTmp(4), stTmp(5), , _
                     stTmp(6), stTmp(7), stTmp(8), stTmp(9), stTmp(10)
        txtTitre.Text = stTmp(0)
        txtArtiste.Text = stTmp(1)
        txtAlbum.Text = stTmp(2)
        txtAnnee.Text = stTmp(3)
        If (stTmp(4) <> vbNullString) Then
            cboGenre.Text = stTmp(4)
        Else
            cboGenre.ListIndex = -1
        End If
        txtCommentaire.Text = stTmp(5)
        txtPiste.Text = stTmp(6)
        lblInfos.Caption = stTmp(9) & " " & rstrKbps & " - " & stTmp(10)
        ' Evite les erreurs sur les fichiers incorrects
        On Error Resume Next
        ' Mise en place du fichier dans le player
        mp3Player.FileName = lvwListe.SelectedItem.Key
        On Error GoTo 0
    End If
Else
    txtTitre.Text = vbNullString
    txtArtiste.Text = vbNullString
    txtAlbum.Text = vbNullString
    txtAnnee.Text = vbNullString
    cboGenre.ListIndex = -1
    txtCommentaire.Text = vbNullString
End If
End Sub

Private Sub lvwListe_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
' Gestion du menu Popup
Dim litTmp As ListItem
Dim lchTmp As ColumnHeader
Dim lgPos As Long, lgCol As Long
Dim stCol As String, stTmp As String
' Action du bouton droit de la souris
If (Button = vbRightButton) Then
    ' Positionnement sur l'�l�ment courant sous la souris
    Set litTmp = lvwListe.HitTest(x, y)
    If Not litTmp Is Nothing Then
        litTmp.Selected = True
        ' Recherche de la colonne s�lectionn�e
        lgPos = litTmp.Left - 20
        For Each lchTmp In lvwListe.ColumnHeaders
            If (lgPos < x) And (x < lgPos + lchTmp.Width) Then
                stCol = lchTmp.Text
                lgCol = lchTmp.Index
                Exit For
            End If
            lgPos = lgPos + lchTmp.Width
        Next
        ' Affichage du menu uniquement pour les colonnes "TAG"
        If (lgCol > 1) And (lgCol < 8) Then
            stTmp = litTmp.ListSubItems(lgCol - 1).Text
            ' Affiche l'option de suppression si la valeur n'est pas vide
            If (stTmp <> vbNullString) Then
                mnuPopupEffacer.Caption = LoadResString(intLOffset + resMnuEffacer) & " '" & stTmp & "'"
                mnuPopupEffacer.Visible = True
            Else
                mnuPopupEffacer.Visible = False
            End If
            ' Affiche l'option de propagation (sauf pour la colonne "titre")
            If (lgCol > 2) Then
                mnuPopupPropager.Caption = LoadResString(intLOffset + 136) & " '" & stCol & "'"
                mnuPopupPropager.Visible = True
            Else
                mnuPopupPropager.Visible = False
            End If
            ' Affichage du s�parateur
            mnuSep30.Visible = mnuPopupEffacer.Visible Or mnuPopupPropager.Visible
            If (lgCol <> 5) And (lgCol <> 6) Then
                mnuPopupEchange(2).Visible = True
                mnuPopupEchange(3).Visible = True
                mnuPopupEchange(4).Visible = True
                mnuPopupEchange(7).Visible = True
                mnuPopupEchange(lgCol).Visible = False
            Else
                ' Pas d'�change avec l'ann�e et le genre
                mnuPopupEchange(2).Visible = False
                mnuPopupEchange(3).Visible = False
                mnuPopupEchange(4).Visible = False
                mnuPopupEchange(7).Visible = False
                mnuSep30.Visible = False
            End If
            ' Stocke la colonne s�lectionn�e dans le tag du menu popup
            mnuPopup.Tag = lgCol - 1
            ' Affichage du menu contextuel
            PopupMenu mnuPopup
        End If
    End If
End If
End Sub

' ========================== Actions du menu Aide ==========================

Private Sub mnuAideAPropos_Click()
' Affiche la fen�tre "A propos..."
frmAPropos.Show vbModal
End Sub

Private Sub mnuAideForum_Click()
' Acc�s au forum en ligne
If IsConnected Then
    On Error Resume Next
    Shell "explorer.exe ""http://docvb.free.fr/forum/forums.php?id=2""", vbNormalFocus
End If
End Sub

Private Sub mnuAideMiseAJour_Click()
' V�rifie s'il existe une version plus r�cente de l'application
Call ChercheUpdate(True)
End Sub

' ======================== Actions du menu Edition =========================

Private Sub mnuEditionMajuscule_Click()
' Met les premi�res lettres de chaque mot de la s�lection courante en majuscule
' (uniquement actif sur les "TextBox" de saisie)
Dim lgFor As Long
Dim stTmp As String, stCar As String
' Test le type du contr�le courant
If TypeOf ActiveControl Is TextBox Then
    stTmp = Trim$(ActiveControl.Text)
    If (stTmp <> vbNullString) Then
        ' Premi�re lettre en majuscule
        Mid$(stTmp, 1, 1) = UCase$(Mid$(stTmp, 1, 1))
        For lgFor = 2 To Len(stTmp)
            If (Mid$(stTmp, lgFor - 1, 1) = " ") Then
                ' Apr�s chaque espace, on met une majuscule
                Mid$(stTmp, lgFor, 1) = UCase$(Mid$(stTmp, lgFor, 1))
            End If
        Next lgFor
        ' Met � jour le contr�le avec la nouvelle valeur
        ActiveControl.Text = stTmp
    End If
End If
End Sub

Private Sub mnuEditionArtisteAlbum_Click()
' Echange les valeurs des zones "artiste" et "album"
Dim stTmp As String
stTmp = txtArtiste.Text
txtArtiste.Text = txtAlbum.Text
txtAlbum.Text = stTmp
' Enregistre les modifications
Call cmdEnregistrer_Click
End Sub

Private Sub mnuEditionTitreAlbum_Click()
' Echange les valeurs des zones "titre" et "album"
Dim stTmp As String
stTmp = txtTitre.Text
txtTitre.Text = txtAlbum.Text
txtAlbum.Text = stTmp
' Enregistre les modifications
Call cmdEnregistrer_Click
End Sub

Private Sub mnuEditionTitreArtiste_Click()
' Echange les valeurs des zones "titre" et "artiste"
Dim stTmp As String
stTmp = txtTitre.Text
txtTitre.Text = txtArtiste.Text
txtArtiste.Text = stTmp
' Enregistre les modifications
Call cmdEnregistrer_Click
End Sub

' ======================== Actions du menu Fichier =========================

Private Sub mnuFichierEffacer_Click()
' Efface le fichier courant s�lectionn�
If Not (lvwListe.SelectedItem Is Nothing) Then
    ' Confirmation de la demande
    If (MsgBox(LoadResString(intLOffset + resEtesEffacer) & _
               lvwListe.SelectedItem.Text & "'?", _
               vbQuestion + vbOKCancel, _
               LoadResString(intLOffset + resSuppression)) = vbOK) Then
        On Error Resume Next
        Err.Clear
        ' On enl�ve syst�matiquement l'attribut lecture seule
        SetAttr lvwListe.SelectedItem.Key, _
                GetAttr(lvwListe.SelectedItem.Key) And Not vbReadOnly
        ' Suppression du fichier
        Call EffaceVersCorbeille(lvwListe.SelectedItem.Key)
        On Error GoTo 0
        If (Err.Number <> 0) Then
            MsgBox LoadResString(intLOffset + 202) & vbCrLf & _
                   Err.Description, vbExclamation, _
                   LoadResString(intLOffset + resSuppression)
        Else
            ' Rafrachissement de la liste courante
            Call ChargeListe(stCurDir)
        End If
    End If
End If
End Sub

Private Sub mnuFichierExtension_Click()
' Modifier en une seule passe les extensions
' de fichier du r�pertoire courant
Dim stInput As String, stFile As String, stNewFile As String
Dim stRenameTo As String, lgCount As Long
If (stCurDir <> vbNullString) Then
    stInput = UCase$(Trim$(InputBox(LoadResString( _
              intLOffset + resQuelsFichiers), rstrRenommer, "BIN")))
    If (stInput <> vbNullString) Then
        Do
            stRenameTo = UCase$(Trim$(InputBox(LoadResString( _
                      intLOffset + 169), rstrRenommer, "MP3")))
        Loop While (InStr(1, stRenameTo, ".") > 0)
        
        If (stRenameTo <> vbNullString) Then
            ' Gestion d'erreur
            On Error Resume Next
            lgCount = 0
            stFile = Dir$(stCurDir & "*." & stInput)
            Do While (stFile <> vbNullString)
                stNewFile = stCurDir & Left$(stFile, _
                            Len(stFile) - Len(stInput)) & stRenameTo
                Err.Clear
                Name stCurDir & stFile As stNewFile
                If (Err.Number = 0) Then lgCount = lgCount + 1
                stFile = Dir$
            Loop
            MsgBox LoadResString(intLOffset + resOpTerm) & vbCrLf & _
                   lgCount & LoadResString(intLOffset + resFiRen), _
                   vbExclamation, rstrRenommer
            ' Recharge la liste courante
            Call ChargeListe(stCurDir)
        End If
    End If
Else
    MsgBox LoadResString(intLOffset + resAucun), _
           vbExclamation, rstrRenommer
End If
End Sub

Private Sub mnuFichierQuitter_Click()
' Fermeture de l'application
Unload Me
End Sub

Private Sub mnuFichierRafraichir_Click()
' Rafrachit la liste courante
If (stCurDir <> vbNullString) Then Call ChargeListe(stCurDir)
End Sub

Private Sub mnuFichierRenommer_Click()
' Renommer le fichier courant s�lectionn�
If Not (lvwListe.SelectedItem Is Nothing) Then
    ' Passe l'�l�ment courant en mode �dition
    lvwListe.StartLabelEdit
End If
End Sub

' ============== Menus et fonction pour le format de fichier ===============

Private Sub mnuOptionsAnnulerFormat_Click()
' Annule l'application du dernier format en redonnant aux fichiers leur
' nom d'origine (uniquement valable dans le cas ou la liste n'a pas chang�)
Dim lgFor As Long
Dim stOld As String, stCur As String
For lgFor = 1 To lvwListe.ListItems.Count
    ' S�lection des �l�ments
    Set lvwListe.SelectedItem = lvwListe.ListItems(lgFor)
    ' R�cup�re l'ancien nom de fichier
    stOld = lvwListe.SelectedItem.ListSubItems(1).Tag
    If (stOld <> vbNullString) Then
        stCur = lvwListe.SelectedItem.Key
        lvwListe.SelectedItem.Key = stOld
        ' R�initialise la zone de stockage temporaire
        lvwListe.SelectedItem.ListSubItems(1).Tag = vbNullString
        ' Changement de nom
        Name stCur As stOld
        ' Mise � jour du nom de fichier dans la liste
        lvwListe.SelectedItem.Text = Mid$(stOld, InStrRev(stOld, "\") + 1)
    End If
Next lgFor
' Ajustement de la taille des colonnes
AdjustColListView lvwListe, Me
End Sub

Private Sub mnuOptionsAppliqueFormat_Click()
' Renommer le fichier d'apr�s les informations courantes (format)
If Not lvwListe.SelectedItem Is Nothing Then Call AppliqueFormat(True)
End Sub

Private Sub mnuOptionsAppliqueFormatTous_Click()
' Applique le format pour tous les fichiers du r�pertoire courant
Dim lgFor As Long
For lgFor = 1 To lvwListe.ListItems.Count
    ' S�lection de l'�l�ment
    Set lvwListe.SelectedItem = lvwListe.ListItems(lgFor)
    ' Mode non interactif
    Call AppliqueFormat(False)
Next lgFor
' Ajustement de la taille des colonnes
AdjustColListView lvwListe, Me
End Sub

Private Sub mnuOptionsFormat_Click()
' D�finition du format de fichier
Dim stNewFormat As String
Dim stText As String
stText = LoadResString(intLOffset + 146) & vbCrLf & _
         LoadResString(intLOffset + 142) & vbCrLf & _
         LoadResString(intLOffset + 143) & vbCrLf & _
         LoadResString(intLOffset + 144) & vbCrLf & _
         LoadResString(intLOffset + 145)
stNewFormat = InputBox(stText, "Format", stFormat)
If (stNewFormat <> vbNullString) Then
    ' Suppression des caract�res interdits
    stNewFormat = NomFichierValide(stNewFormat)
    ' V�rification du nouveau format
    stFormat = stNewFormat
End If
End Sub

Private Sub AppliqueFormat(blInteractif As Boolean)
' Applique le format courant � un fichier
Dim stFile As String, stNumero As String
Dim stTmp As String
Dim tabTmp
Dim lgFor As Long
Dim stPrompt As String, stTitre As String
' Recherche d'un num�ro de chanson
stNumero = "0"
stTmp = Replace(lvwListe.SelectedItem.Text, "_", " _ ")
stTmp = Replace(stTmp, "-", " - ")
stTmp = Replace(stTmp, ".", " . ")
tabTmp = Split(stTmp, " ")
For lgFor = 0 To UBound(tabTmp)
    If IsNumeric(tabTmp(lgFor)) Then
        stNumero = tabTmp(lgFor)
        Exit For
    End If
Next lgFor

stFile = Replace(stFormat, "%1", Format$(stNumero, "0"))
stFile = Replace(stFile, "%2", Format$(stNumero, "00"))
stFile = Replace(stFile, "%3", Format$(stNumero, "000"))
stFile = Replace(stFile, "%g", lvwListe.SelectedItem.SubItems(5)) ' Genre
stFile = Replace(stFile, "%n", lvwListe.SelectedItem.SubItems(4)) ' Ann�e
stFile = Replace(stFile, "%t", lvwListe.SelectedItem.SubItems(1))
stFile = Replace(stFile, "%a", lvwListe.SelectedItem.SubItems(2))
stFile = Replace(stFile, "%b", lvwListe.SelectedItem.SubItems(3))
stFile = Replace(stFile, "%c", lvwListe.SelectedItem.SubItems(6)) & ".mp3"
' Suppression des caract�res invalides
stFile = Trim$(NomFichierValide(stFile))
If blInteractif Then
    stFile = Trim$(InputBox(Replace(LoadResString(intLOffset + 164), "%1", stFormat), _
             rstrRenommer, stFile))
End If
If (stFile <> vbNullString) Then
    If (Dir$(stCurDir & stFile) <> vbNullString) Then
        stPrompt = Replace(LoadResString(intLOffset + 165), "%1", stCurDir & stFile) & _
                   vbCrLf & LoadResString(intLOffset + 166)
        stTitre = LoadResString(intLOffset + 167)
        If Not blInteractif Then
            Exit Sub
        ElseIf (MsgBox(stPrompt, vbQuestion + vbYesNo, stTitre) = vbNo) Then
            Exit Sub
        End If
    End If
    ' Sauvegarde l'ancien nom (pour op�ration inverse en cas de probl�me)
    lvwListe.SelectedItem.ListSubItems(1).Tag = lvwListe.SelectedItem.Key
    ' Changement de nom
    Name lvwListe.SelectedItem.Key As stCurDir & stFile
    ' Mise � jour de la liste
    lvwListe.SelectedItem.Text = stFile
    lvwListe.SelectedItem.Key = stCurDir & stFile
    If blInteractif Then
        ' Ajustement de la taille des colonnes
        AdjustColListView lvwListe, Me
    End If
End If
End Sub

' ==================== Menus et fonction de propagation ====================

Private Sub mnuOptionsGenre_Click()
' Propagation du genre de la s�lection courante
On Error Resume Next
Call Propager(4, CStr(cboGenre.ItemData(cboGenre.ListIndex)), "Genre")
End Sub

Private Sub mnuOptionsAlbum_Click()
' Propagation de l'album de la s�lection courante
Call Propager(2, txtAlbum.Text, rstrAlbum)
End Sub

Private Sub mnuOptionsAnnee_Click()
' Propagation de l'ann�e de la s�lection courante
Call Propager(3, txtAnnee.Text, rstrAnnee)
End Sub

Private Sub mnuOptionsArtiste_Click()
' Propagation de l'artiste de la s�lection courante
Call Propager(1, txtArtiste.Text, rstrArtiste)
End Sub

Private Sub mnuOptionsCommentaire_Click()
' Propagation du commentaire de la s�lection courante
Call Propager(5, txtCommentaire.Text, rstrCommentaire)
End Sub

Private Sub Propager(lgElement As Long, stValeur As String, stInfo As String)
' Propage un contenu dans tous les fichiers du r�pertoire courant
Dim stTmp(6) As String
Dim lgFor As Long, lgTmp As Long
If (lgElement = 4) Then stTmp(0) = cboGenre.Text Else stTmp(0) = stValeur
lgTmp = MsgBox(LoadResString(intLOffset + resDiffuser) & _
        stTmp(0) & LoadResString(intLOffset + resColonne) _
        & stInfo & LoadResString(intLOffset + resEnsemble), _
        vbQuestion + vbOKCancel, LoadResString(intLOffset + resApply))
If (lgTmp = vbOK) Then
    ' Sauvegarde du fichier courant et mise � z�ro pour permettre la mise � jour
    mp3Player.Tag = mp3Player.FileName
    mp3Player.FileName = vbNullString
    ' Parcours de la liste
    For lgFor = 1 To lvwListe.ListItems.Count
        LireTagID3v1 lvwListe.ListItems(lgFor).Key, stTmp(0), stTmp(1), _
                     stTmp(2), stTmp(3), stTmp(4), stTmp(5), lgTmp, stTmp(6)
        stTmp(4) = CStr(lgTmp)
        stTmp(lgElement) = stValeur
        ' Enregistrement des modifications
        EcrireTagID3v1 lvwListe.ListItems(lgFor).Key, stTmp(0), stTmp(1), _
                       stTmp(2), stTmp(3), CByte(stTmp(4)), stTmp(5), stTmp(6)
        lvwListe.ListItems(lgFor).SubItems(1) = stTmp(0)
        lvwListe.ListItems(lgFor).SubItems(2) = stTmp(1)
        lvwListe.ListItems(lgFor).SubItems(3) = stTmp(2)
        lvwListe.ListItems(lgFor).SubItems(4) = stTmp(3)
        If (CLng(stTmp(4)) > 147) Then
            lvwListe.ListItems(lgFor).SubItems(5) = vbNullString
        Else
            lvwListe.ListItems(lgFor).SubItems(5) = Split(GENRE, "|")(CLng(stTmp(4)))
        End If
        lvwListe.ListItems(lgFor).SubItems(6) = stTmp(5)
    Next lgFor
    ' Remise en position du fichier courant
    mp3Player.FileName = mp3Player.Tag
End If
End Sub

Private Sub mnuOptionsListing_Click()
' Parcours l'arborescence actuelle pour g�n�rer un listing des fichiers MP3
If (stCurDir <> vbNullString) Then frmExport.Show vbModal
End Sub

Private Sub mnuOptionsPlaylist_Click()
' G�n�re une "Playlist" (fichier .m3u) d'apr�s le contenu du r�pertoire
Dim stFile As String
Dim inFree As Integer
Dim lgFor As Long
stFile = Trim$(NomFichierValide(InputBox(LoadResString( _
               intLOffset + resNomDuFichier), "Playlist", stFile)))
If (stFile <> vbNullString) Then
    inFree = FreeFile
    ' Ajout de l'extension au cas ou elle ne serait pas pr�sente
    If (UCase$(Right$(stFile, 4)) <> ".M3U") Then stFile = stFile & ".m3u"
    ' Ouverture du fichier
    Open stCurDir & stFile For Output As #inFree
    ' Ecriture du fichier
    Print #inFree, "#EXTM3U"
    For lgFor = 1 To lvwListe.ListItems.Count
        Print #inFree, "#EXTINF:" & lvwListe.ListItems(lgFor).Tag & "," & _
                       lvwListe.ListItems(lgFor).SubItems(2) & " - " & _
                       lvwListe.ListItems(lgFor).SubItems(1)
        Print #inFree, Mid$(lvwListe.ListItems(lgFor).Key, 3)
    Next lgFor
    ' Fermeture du fichier
    Close #inFree
    MsgBox Replace(LoadResString(intLOffset + 168), "%1", stCurDir & stFile), _
           vbInformation, "Playlist"
End If
End Sub

Private Sub mnuOutilsConfiguration_Click()
' Affiche la fen�tre de configuration de l'application
frmConfiguration.Show vbModal
SetListViewColumnName lvwListe, rstrFichier, rstrTitre, _
                rstrArtiste, rstrAlbum, rstrAnnee, _
                rstrGenre, rstrCommentaire, rstrTaille, _
                rstrDuree, rstrKbps, rstrMode
AdjustColListView lvwListe, Me
End Sub

Private Sub mnuOutilsToutDezipper_Click()
' V�rifie la pr�sence de la DLL et lance le traitement de
' d�compression de tous les fichiers ZIP du r�pertoire courant
Dim lgRep As Long
Dim stPath As String
If Not VBUnzipOk Then
    ' Affiche un message d'information pour la r�cup�ration de la DLL
    lgRep = MsgBox(Replace(LoadResString(intLOffset + 215), "\n", vbCrLf), _
                   vbQuestion + vbYesNo)
    If (lgRep = vbNo) Then
        MsgBox Replace(LoadResString(intLOffset + 216), "\n", vbCrLf), _
               vbInformation
    Else
        ' V�rifie l'�tat de la connexion Internet
        If IsConnected Then
            ' Sablier
            Screen.MousePointer = vbHourglass
            stPath = App.Path
            If (Right$(stPath, 1) <> "\") Then stPath = stPath & "\"
            ' Lance la r�cup�ration du fichier dans le r�pertoire courant de l'application
            StringToFile GetUrlFile("http://docvb.free.fr/download/unzip32.dll"), stPath & "unzip32.dll"
            ' Fin du t�l�chargement
            Screen.MousePointer = vbNormal
            MsgBox Replace(LoadResString(intLOffset + 217), "\n", vbCrLf), _
                   vbInformation
        Else
            MsgBox Replace(LoadResString(intLOffset + 218), "\n", vbCrLf), _
                   vbExclamation
        End If
    End If
Else
    ' Affiche la fen�tre de d�compression
    If (stCurDir <> vbNullString) Then frmUnzip.Show vbModal
End If
End Sub

Private Sub mnuPopupEchange_Click(Index As Integer)
' Echange les valeurs de colonne de l'�l�ment courant
Dim stTmp As String, stNew As String
stNew = lvwListe.SelectedItem.ListSubItems(CLng(mnuPopup.Tag)).Text
Select Case Index
    Case 2
        stTmp = txtTitre.Text
        txtTitre.Text = stNew
    Case 3
        stTmp = txtArtiste.Text
        txtArtiste.Text = stNew
    Case 4
        stTmp = txtAlbum.Text
        txtAlbum.Text = stNew
    Case 7
        stTmp = txtCommentaire.Text
        txtCommentaire.Text = stNew
End Select
Select Case mnuPopup.Tag
    Case 1
        txtTitre.Text = stTmp
    Case 2
        txtArtiste.Text = stTmp
    Case 3
        txtAlbum.Text = stTmp
    Case 6
        txtCommentaire.Text = stTmp
End Select
' Enregistre la modification
Call cmdEnregistrer_Click
End Sub

Private Sub mnuPopupEffacer_Click()
' Efface le contenu de la colonne courante de l'�l�ment s�lectionn�
Select Case mnuPopup.Tag
    Case 1
        txtTitre.Text = vbNullString
    Case 2
        txtArtiste.Text = vbNullString
    Case 3
        txtAlbum.Text = vbNullString
    Case 4
        txtAnnee.Text = vbNullString
    Case 5
        cboGenre.ListIndex = -1
    Case 6
        txtCommentaire.Text = vbNullString
End Select
Call cmdEnregistrer_Click
End Sub

Private Sub mnuPopupPropager_Click()
' Propage le contenu de la colonne courante de l'�l�ment s�lectionn�
' sur l'ensemble de la liste
Select Case mnuPopup.Tag
    Case 2
        Call mnuOptionsArtiste_Click
    Case 3
        Call mnuOptionsAlbum_Click
    Case 4
        Call mnuOptionsAnnee_Click
    Case 5
        Call mnuOptionsGenre_Click
    Case 6
        Call mnuOptionsCommentaire_Click
End Select
End Sub

Private Sub tmrPlay_Timer()
' Affiche le compteur de temps pour le morceau courant
Dim lgTime As Long
If (mp3Player.PlayState = mpPlaying) Then
    lgTime = Int(mp3Player.CurrentPosition)
    lblTrackInfo.Caption = Format$(lgTime \ 60, "00") & ":" & _
                           Format$(lgTime - ((lgTime \ 60) * 60), "00")
Else
    lblTrackInfo.Caption = vbNullString
End If
End Sub

Public Sub ChargeListe(stChemin As String)
' Charge la liste des fichiers contenu dans le r�pertoire pass� en argument
Dim stFile As String
Dim litTmp As ListItem
Dim stTmp(9) As String
Dim lgLen As Long
Dim dbTotal As Double
' Sablier
Screen.MousePointer = vbHourglass
dbTotal = 0
' R�glage du chemin
If (Right$(stChemin, 1) <> "\") Then stChemin = stChemin & "\"
' Rend la liste invisible le temps de la pr�paration
lvwListe.Visible = False
lvwListe.Refresh
' Pr�paration de la liste
lvwListe.ListItems.Clear
lvwListe.ColumnHeaders.Clear
' Mise en place des ent�tes de colonne
SetListViewColumnName lvwListe, rstrFichier, rstrTitre, _
                        rstrArtiste, rstrAlbum, rstrAnnee, _
                        rstrGenre, rstrCommentaire, rstrTaille, _
                        rstrDuree, rstrKbps, rstrMode
stFile = Dir$(stChemin & "*.mp3")
Do While (stFile <> vbNullString)
    Set litTmp = lvwListe.ListItems.Add(, stChemin & stFile, stFile)
    LireTagID3v1 stChemin & stFile, stTmp(0), stTmp(1), stTmp(2), _
                                    stTmp(3), stTmp(4), stTmp(5), , , _
                                    stTmp(6), stTmp(7), stTmp(8), _
                                    stTmp(9)
    litTmp.SubItems(1) = stTmp(0)
    litTmp.SubItems(2) = stTmp(1)
    litTmp.SubItems(3) = stTmp(2)
    litTmp.SubItems(4) = stTmp(3)
    litTmp.SubItems(5) = stTmp(4)
    litTmp.SubItems(6) = stTmp(5)
    lgLen = FileLen(stChemin & stFile)
    litTmp.SubItems(7) = Format$(lgLen \ 1024, "# ##0") & " " & rstrKOct
    dbTotal = dbTotal + lgLen
    litTmp.SubItems(8) = stTmp(6)
    litTmp.Tag = stTmp(7)
    litTmp.SubItems(9) = Format$(stTmp(8), "@@@")
    litTmp.SubItems(10) = stTmp(9)
    stFile = Dir$
Loop
' Affiche le total des mp3 du r�pertoire courant
lblTotal.Caption = "(Total: " & Trim$(Format(dbTotal \ 1024, "# ### ##0")) & _
                   " " & rstrKOct & ")"
' Ajustement de la taille des colonnes
AdjustColListView lvwListe, Me
' Remet la liste visible
lvwListe.Visible = True
lvwListe.Refresh
Screen.MousePointer = vbNormal
End Sub

Private Sub ChercheUpdate(Optional blMessage As Boolean = False)
' Recherche si une version plus r�cente de l'application est disponible
Dim stGet As String, stTmp As String
Dim lgRep As Long
If IsConnected Then
    stGet = LCase$(Left$(LoadResString((intLOffset / 150) + 10), 2))
    stGet = GetUrlFile("http://docvb.free.fr/download/mp3tagedit" & stGet & ".txt")
    stTmp = App.Major & "." & App.Minor & "." & App.Revision
    If (Left$(stGet, 5) > stTmp) And (stGet <> vbNullString) Then
        ' Il existe une version plus r�cente
        stTmp = Replace(LoadResString(intLOffset + 191), "\n", vbCrLf)
        stTmp = Replace(stTmp, "%1", Mid$(stGet, 7))
        lgRep = MsgBox(stTmp, vbYesNo + vbDefaultButton2, _
                       LoadResString(intLOffset + 192))
        ' Utilisation de explorer pour la r�cup�ration du programme
        If (lgRep = vbYes) Then
            On Error Resume Next
            Err.Clear
            Shell "explorer.exe http://docvb.free.fr/download/mp3tagedit.exe", vbNormalFocus
            If (Err.Number <> 0) Then
                MsgBox LoadResString(intLOffset + 193), vbInformation, _
                       LoadResString(intLOffset + 191)
            End If
        End If
    Else
        If blMessage Then MsgBox LoadResString(intLOffset + 210), vbInformation
    End If
Else
    If blMessage Then MsgBox LoadResString(intLOffset + 211), vbExclamation
End If
End Sub

Private Sub txtAlbum_GotFocus()
SelAllText txtAlbum
End Sub

Private Sub txtAnnee_GotFocus()
SelAllText txtAnnee
End Sub

Private Sub txtArtiste_GotFocus()
SelAllText txtArtiste
End Sub

Private Sub txtCommentaire_GotFocus()
SelAllText txtCommentaire
End Sub

Private Sub txtPiste_GotFocus()
SelAllText txtPiste
End Sub
Private Sub txtPiste_KeyPress(KeyAscii As Integer)
' Filtre la saisie de la zone de texte pour n'accepter que les caract�res de 0 � 9.
' On fait attention � bien laisser passer les KeyAscii inf�rieurs � 32
' puisqu'ils repr�sentent des cas sp�ciaux (comme [BackSpace] par exemple).
If (KeyAscii > 31) And (InStr(1, "0123456789", Chr$(KeyAscii)) <= 0) Then
    KeyAscii = 0
End If
End Sub

Private Sub txtTitre_GotFocus()
SelAllText txtTitre
End Sub
