VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CNode"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'----------------------------------------------------------------
'FUNCTION: simple node class for building a scene database.
' This class is used to build a vastly simplified Inventor/vrml style
' tree of nodes.  Its main purpose is organizational,
' to act as a container of fields and parent of other nodes.
'AUTHOR: edx - edx@hk.super.net, Oct 98 - all rights reserved
'HISTORY: -
'NOTES:
'----------------------------------------------------------------
'----------------------------------------------------------------
Public Enum GeometryConstants
    geoBox = 1
    geoSphere = 2
    geoCylinder = 3
    geoCone = 4
End Enum

Public ListID& 'display list
Public NameID& 'name for picking
Public Parent As CNode
Public Children As Collection
Public Texture As glxTexture
Public Material As glxMaterial
Public Geometry As GeometryConstants
'----------------------------------------------------------------
Dim m_tx!, m_ty!, m_tz! 'translation
Dim m_sx!, m_sy!, m_sz! 'scale
Dim m_x!, m_y!, m_z! 'size
Dim m_rotx!, m_roty!, m_rotz!, m_rota! 'vector and angle
Dim m_Selected As Boolean
Dim m_Name$
Dim m_r!, m_g!, m_b! 'color
'----------------------------------------------------------------
'

Private Sub Class_Initialize()
    m_x = 1: m_y = 1: m_z = 1 'size
    m_sx = 1: m_sy = 1: m_sz = 1 'scale
    m_rotz = 1 '0,0,1
    Set Children = New Collection
    NameID = NextID
    m_r = 1
    m_g = 1
    m_b = 1
    Geometry = geoSphere
    Set Material = gCtl.Materials.GetMaterialIndex(BRIGHT_WHITE)
End Sub

'----------------------------------------------------------------
'note: these routines are just dummies. This whole class is a quick
'hack. There are various VRML libraries available on the web which
'show how to build a proper node system.
'----------------------------------------------------------------
Public Sub GetBoundingBox(x!, y!, z!)
    x = m_x * m_sx
    y = m_y * m_sy
    z = m_z * m_sz
End Sub

Public Sub GetTranslation(x!, y!, z!)
    x = m_tx: y = m_ty: z = m_tz
End Sub

'------------------------------------------------------------
Public Sub SetTranslation(x!, y!, z!)
    m_tx = x: m_ty = y: m_tz = z
End Sub

Public Sub GetScale(x!, y!, z!)
    x = m_sx: y = m_sy: z = m_sz
End Sub

Public Sub SetScale(x!, y!, z!)
    m_sx = x: m_sy = y: m_sz = z
End Sub

Public Sub UniformScale(f!)
    m_sx = m_sx * f: m_sy = m_sy * f: m_sz = m_sz * f
End Sub

Public Sub GetRotation(A!, x!, y!, z!)
    A = m_rota
    x = m_rotx
    y = m_roty
    z = m_rotz
End Sub

Public Sub SetRotation(A!, x!, y!, z!)
    m_rota = A
    m_rotx = x
    m_roty = y
    m_rotz = z
End Sub

Public Property Get Selected() As Boolean
    Selected = m_Selected
End Property

Public Property Let Selected(ByVal NewValue As Boolean)
    m_Selected = NewValue
End Property

Public Sub AddChild(Node As CNode)
    Children.Add Node, CStr(Node.NameID)
    Set Node.Parent = Me
End Sub

Public Property Get Name() As String
Name = m_Name
End Property

Public Property Let Name(ByVal NewValue As String)
m_Name = NewValue
End Property

'-------------------------------------------------------------------------------------
'Returns true if a Node was picked
Public Function OnPick(ID&) As Boolean
Dim i&
    If ID = NameID Then
        OnPick = True
        Exit Function
    End If
    For i = 1 To Children.Count
        If Children(i).OnPick Then
            OnPick = True
            Exit Function
        End If
    Next
End Function


Public Sub Draw()
Dim center!(0 To 2), i&
Dim sizx!, sizy!, sizz! 'size
    'CheckError
    If m_Selected Then
        'Manipulator.Draw
    End If
    glPushMatrix
    glLoadName NameID
    glTranslatef m_tx, m_ty, m_tz
    glRotatef m_rota, m_rotx, m_roty, m_rotz
    'we don't really want to scale
    'glScalef m_sx, m_sy, m_sz
    sizx = m_x * m_sx
    sizy = m_y * m_sy
    sizz = m_z * m_sz
    '
    If m_Selected Then
        glColor3f 1, 0.3, 0.3
    Else
        glColor3f m_r, m_g, m_b
    End If
    If Not Material Is Nothing Then
        Material.SetMaterial
    End If
    '
    If Not Texture Is Nothing Then
        glEnable GL_TEXTURE_2D
        Texture.SetTexture
    End If
    '
'    If ListID = 0 Then
'        Compile
'    End If
'    glCallList ListID
    With gCtl.Shapes
        Select Case Geometry
        Case geoBox: .Box sizx, sizy, sizz
        Case geoSphere: .Sphere sizx
        Case geoCylinder: .Cylinder sizx, sizy, sizz
        Case geoCone: .Cone sizx, sizy, sizz
        Case Else: Debug.Assert 0
        End Select
    End With
    '
    If Not Texture Is Nothing Then
        glDisable GL_TEXTURE_2D
    End If
    '
    For i = 1 To Children.Count
        Children(i).Draw
    Next
    glPopMatrix
    CheckError
End Sub

'Public Sub Compile(View As CView)
'if wglShareLists works, we should be able to use global lists.
'couldn't get it to work.
''all we do use a precompiled list
'    Select Case Geometry
'    Case geoBox: ListID = BoxID
'    Case geoSphere: ListID = SphereID&
'    Case geoCylinder: ListID = CylinderID&
'    Case geoCone: ListID = ConeID&
'    Case Else: Debug.Assert 0
'    End Select
'all we do use a precompiled list

'End Sub

Public Sub GetColor(r!, g!, B!)
    r = m_r: g = m_g: B = m_b
End Sub

Public Property Let Color(r!, g!, B!)
    m_r = r: m_g = g: m_b = B
End Property

