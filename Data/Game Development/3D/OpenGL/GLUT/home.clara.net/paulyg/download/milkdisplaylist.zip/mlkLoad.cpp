/*//////////////////////////////////////////////////////////////////////////////
//
//  An ASCII milkshape object loader - couldn't get the binary files to read
//  properly (datatype _issues_)
//
//////////////////////////////////////////////////////////////////////////////*/


#include <windows.h>
#include <math.h>
#include <stdio.h>

#include <GL\gl.h>

#include "mlkLoad.h"
#include "tgaLoad.h"

enum { X, Y, Z };
enum { U, V };

void Normalize ( float* n )
{
   float l;

   l = (float) sqrt ( n[X] * n[X] + n[Y] * n[Y] + n[Z] * n[Z] );

   if ( l != 0.0 )
   {
      n[0] /= l;
      n[1] /= l;
      n[2] /= l;
   }
}

void CrossProd ( float* u, float* v, float* n )
{
  /* compute the cross product (u x v for right-handed (IE anti-clockwise))  */
  n[X] = u[Y] * v[Z] - u[Z] * v[Y];
  n[Y] = u[Z] * v[X] - u[X] * v[Z];
  n[Z] = u[X] * v[Y] - u[Y] * v[X];
}


void mlkGenerateFacetNormals ( mlkObject_t *object, int current_mesh )
{
   float u[3];
   float v[3];
   float n[3];

   for ( unsigned int i=0; i < object->Mesh[current_mesh].NumIndices; i++ )
   {
      /* Calculate 2 vectors for the triangle */
      u[X] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][0] ][X] -
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][X];

      u[Y] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][0] ][Y] -
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][Y];

      u[Z] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][0] ][Z]-
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][Z];


      v[X] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][X] -
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][2] ][X];

      v[Y] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][Y] -
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][2] ][Y];

      v[Z] = object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][1] ][Z]-
             object->Mesh[current_mesh].Vertices[ object->Mesh[current_mesh].Indices[i][2] ][Z];

      CrossProd ( u, v, n );
      Normalize ( n );

      object->Mesh[current_mesh].FaceNormals[i][X] = n[X];
      object->Mesh[current_mesh].FaceNormals[i][Y] = n[Y];
      object->Mesh[current_mesh].FaceNormals[i][Z] = n[Z];
   }
}


void mlkGenerateVertexNormals ( mlkObject_t *object, int current_mesh )
{
   vec3_t sum;
   int shared = 0;

   /*
   This bit of code calculates our vertex normals.  What happens is we walk
   our vertex list and for each vertex we walk the face list and find all the
   faces that use the current vertex.  If a face uses the current vertex we add
   it to our sum and increment our shared variable.  After all faces have been
   walked we divide the sum by the number of faces that share the current
   vertex and normalize it.  This gives us a vertex normal for the current
   vertex.  We then move onto the next vertex and repeat the process again
   until all vertices have been visited.    
   */ 
   for ( unsigned int i = 0; i < object->Mesh[current_mesh].NumVertices; i++ )
   {
      for ( unsigned int j = 0; j < object->Mesh[current_mesh].NumIndices; j++ )
      {
         if ( object->Mesh[current_mesh].Indices[j][X] == i ||
              object->Mesh[current_mesh].Indices[j][Y] == i ||
              object->Mesh[current_mesh].Indices[j][Z] == i )
         {
            sum[X] += object->Mesh[current_mesh].FaceNormals[j][X];
            sum[Y] += object->Mesh[current_mesh].FaceNormals[j][Y];
            sum[Z] += object->Mesh[current_mesh].FaceNormals[j][Z];
            shared++;
         }
      }      
      object->Mesh[current_mesh].VertexNormals[i][X] = ( sum[X] / (float) shared );
      object->Mesh[current_mesh].VertexNormals[i][Y] = ( sum[Y] / (float) shared );
      object->Mesh[current_mesh].VertexNormals[i][Z] = ( sum[Z] / (float) shared );

      Normalize ( object->Mesh[current_mesh].VertexNormals[i] );

      sum[X] = sum[Y] = sum[Z] = 0.0;
      shared = 0;
   }
}


void mlkGetVertsAndUV ( FILE *file, mlkObject_t *p, int current_mesh )
{
   char  line[80];
   int   ignore_flag;

   for ( unsigned int i = 0; i < p->Mesh[ current_mesh ].NumVertices; i ++ )
   {

      fgets  ( line, 80, file );
      sscanf ( line, "%i %f %f %f %f %f %i", &ignore_flag,
                                             &p->Mesh[ current_mesh ].Vertices[i][X],
                                             &p->Mesh[ current_mesh ].Vertices[i][Y],
                                             &p->Mesh[ current_mesh ].Vertices[i][Z],
                                             &p->Mesh[ current_mesh ].UV[i][U],
                                             &p->Mesh[ current_mesh ].UV[i][V],
                                             &ignore_flag );
   }
}


void mlkEatNormals ( FILE *file )
{
   char  line[80];
   int   NumTempNormals;

   // Read the size of the normal table
   fgets  ( line, 80, file );
   sscanf ( line, "%i", &NumTempNormals );

   // Eat the normals table and ignore
   for ( int i = 0; i < NumTempNormals; i ++ )
      fgets  ( line, 80, file );
}


void mlkGetIndices ( FILE *file, mlkObject_t *p, int current_mesh )
{
   char  line[80];
   int   ignore;

   unsigned int  TempNormalIndex[3];

   // Get number of index triples (IE num of triangles)
   fgets  ( line, 80, file );
   sscanf ( line, "%i",     &p->Mesh[ current_mesh ].NumIndices );

   // Allocate the memory for the indices
   p->Mesh[ current_mesh ].Indices =
     (ind3_t *) malloc ( p->Mesh[ current_mesh ].NumIndices * (sizeof(ind3_t)) );

   // Get the indices
   for ( unsigned int i = 0; i < p->Mesh[ current_mesh ].NumIndices ; i++ )
   {
      fgets  ( line, 80, file );
      sscanf ( line, "%i %i %i %i %i %i %i %i", &ignore,
                                    &p->Mesh[ current_mesh ].Indices[i][X],
                                    &p->Mesh[ current_mesh ].Indices[i][Y],
                                    &p->Mesh[ current_mesh ].Indices[i][Z],
                                    &TempNormalIndex[0],
                                    &TempNormalIndex[1],
                                    &TempNormalIndex[2], &ignore );
   }
   printf ("Got Indices for mesh %i\n\n", current_mesh );

   /* Although Milkshape stores 'tabular' normals, we make our own facet normals
      IE one normal vector per triangle...
    */
   p->Mesh[ current_mesh ].FaceNormals =
     (vec3_t *) malloc ( p->Mesh[ current_mesh ].NumIndices * (sizeof(vec3_t)) );

   p->Mesh[ current_mesh ].VertexNormals =
     (vec3_t *) malloc ( p->Mesh[ current_mesh ].NumVertices * (sizeof(vec3_t)) );


}


void mlkReadMesh ( FILE *file, mlkObject_t *p, int current_mesh )
{
   char    line[80];
   char    name[32];
   int     flags;

   // Ignore name and flags for now - just get material index.
   fgets  ( line, 80, file );
   sscanf ( line, "%s %i %i", &name, &flags,
            &p->Mesh[ current_mesh ].MaterialIndex );

   // Scan for Verts in this mesh
   fgets  ( line, 80, file );
   sscanf ( line, "%i", &p->Mesh[ current_mesh ].NumVertices );

   // Allocate space for Verts, Normals and UV coords in this mesh
   p->Mesh[ current_mesh ].Vertices =
     (vec3_t *) malloc ( p->Mesh[ current_mesh ].NumVertices * (sizeof(vec3_t)) );

   p->Mesh[ current_mesh ].UV =
     (vec2_t *) malloc ( p->Mesh[ current_mesh ].NumVertices * (sizeof(vec2_t)) );

   mlkGetVertsAndUV  ( file, p, current_mesh );
   mlkEatNormals     ( file );
   mlkGetIndices     ( file, p, current_mesh );

   mlkGenerateFacetNormals  ( p, current_mesh );
   mlkGenerateVertexNormals ( p, current_mesh );
}


void mlkScanTextureName ( char *line, char *target )
{
   int i = 1;

   while ( line[i] != '"' )
   {
      target[i-1] = line[i];
      i++;
   }
   printf ("\n");
}

void mlkReadMaterial ( FILE *file, mlkObject_t *p, int current_material )
{
   image_t image;

   char    line[80];
   char    name[32];

   fgets  ( line, 80, file );  // Eat Name
   fgets  ( line, 80, file );  // Eat Ambient

   // Scan diffuse parameter for base colour
   fgets  ( line, 80, file );
   sscanf ( line, "%f %f %f", &p->Material[current_material].Diffuse[X],
                              &p->Material[current_material].Diffuse[Y],
                              &p->Material[current_material].Diffuse[Z] );

   fgets  ( line, 80, file );  // Eat

   // Scan for emissive property
   fgets  ( line, 80, file );
   sscanf ( line, "%f %f %f", &p->Material[current_material].Emission[X],
                              &p->Material[current_material].Emission[Y],
                              &p->Material[current_material].Emission[Z] );

   fgets  ( line, 80, file );  //
   fgets  ( line, 80, file );  //
   fgets  ( line, 80, file );  // Get Tex Name

   mlkScanTextureName ( line, p->Material[current_material].TextureMap );

   p->Material[current_material].TextureId[0] = tgaLoadAndBind ( p->Material[current_material].TextureMap, TGA_FREE );
   tgaSetTexParams ( GL_LINEAR, GL_LINEAR, GL_MODULATE );

   fgets  ( line, 80, file ); // Eat alpha map name
}


void mlkFreeObject (mlkObject_t *object)
{
   unsigned int i;

   /* Free each allocated block for the meshes  */
   for ( i = 0; i < object->NumMeshes; i++ )
   {
      if ( object->Mesh[i].Vertices != NULL )
        free ( object->Mesh[i].Vertices );
         
      if ( object->Mesh[i].Indices != NULL )
        free ( object->Mesh[i].Indices );

      if ( object->Mesh[i].UV != NULL )
         free ( object->Mesh[i].UV );

      if ( object->Mesh[i].FaceNormals != NULL )
         free ( object->Mesh[i].FaceNormals );

      if ( object->Mesh[i].VertexNormals != NULL )
         free ( object->Mesh[i].VertexNormals );
      printf ( "freed mesh %i\n", i );
   }

   if ( object->Mesh != NULL )
        free ( object->Mesh );

   if ( object->Material != NULL )
        free ( object->Material );
}



void mlkLoad (GLuint &list, char *file_name )
{
   FILE    *file;
   char    line[80];
   char    mode[15];
   char    trash[2];

   mlkObject_t    *object;

   if ((file = fopen(file_name, "r"))==NULL)
   {
      printf("File Not Found : %s\n",file_name);
      exit (1);
   }

   object = ( mlkObject_t * ) malloc ( sizeof ( mlkObject_t ));

   // Eat lines until we get to the meat of the file :)
   for (int i = 0; i < 6; i ++ )
      fgets  ( line, 80, file );

   // Scan line for no. of meshes
   sscanf ( line,"%s %i", &mode, &object->NumMeshes );

   // Allocate for meshes
   object->Mesh = ( mlkMesh_t *) malloc (object->NumMeshes * (sizeof(mlkMesh_t)));

   // Get Meshes
   for ( unsigned int i = 0; i < object->NumMeshes; i++ )
      mlkReadMesh ( file, object, i );

   // Eat blank line
   fgets  ( line, 80, file );

   // Scan line for no. of materials
   fgets  ( line, 80, file );
   sscanf ( line,"%s %i", &mode, &object->NumMaterials );

   // Allocate for materials
   object->Material = ( mlkMat_t *) malloc (object->NumMaterials * (sizeof(mlkMat_t)));

   // Get materials
   for ( unsigned int i = 0; i < object->NumMaterials; i++ )
      mlkReadMaterial ( file, object, i );

   fclose ( file );

   // Do OpenGL Display list gubbins
   list = glGenLists ( 1 );
   glNewList ( list, GL_COMPILE );

   for ( unsigned int i = 0; i < object->NumMeshes; i++ )
   {
      glPushAttrib  ( GL_CURRENT_BIT );
      glBindTexture ( GL_TEXTURE_2D, object->Material[ object->Mesh[i].MaterialIndex ].TextureId[0] );
      glColor3fv    ( object->Material[ object->Mesh[i].MaterialIndex ].Diffuse );
      glMaterialfv ( GL_FRONT, GL_EMISSION,
                     object->Material[ object->Mesh[i].MaterialIndex ].Emission );

      for ( unsigned int j = 0; j < object->Mesh[i].NumIndices; j++ )
      {
         glBegin ( GL_TRIANGLES );

         glTexCoord2d  ( object->Mesh[i].UV[ object->Mesh[i].Indices[j][X] ][U],
                         object->Mesh[i].UV[ object->Mesh[i].Indices[j][X] ][V] );
         glNormal3fv   ( object->Mesh[i].VertexNormals[ object->Mesh[i].Indices[j][X] ] ) ;
         glVertex3fv   ( object->Mesh[i].Vertices[ object->Mesh[i].Indices[j][X] ] ) ;


         glTexCoord2d  ( object->Mesh[i].UV[ object->Mesh[i].Indices[j][Y] ][U],
                         object->Mesh[i].UV[ object->Mesh[i].Indices[j][Y] ][V] );
         glNormal3fv   ( object->Mesh[i].VertexNormals[ object->Mesh[i].Indices[j][Y] ] ) ;
         glVertex3fv   ( object->Mesh[i].Vertices[ object->Mesh[i].Indices[j][Y] ] ) ;

         glTexCoord2d  ( object->Mesh[i].UV[ object->Mesh[i].Indices[j][Z] ][U],
                         object->Mesh[i].UV[ object->Mesh[i].Indices[j][Z] ][V] );
         glNormal3fv   ( object->Mesh[i].VertexNormals[ object->Mesh[i].Indices[j][Z] ] ) ;
         glVertex3fv   ( object->Mesh[i].Vertices[ object->Mesh[i].Indices[j][Z] ] ) ;

         glEnd ( );
      }
      glPopAttrib ( );
   }
   glEndList ( );
   mlkFreeObject ( object );
}
