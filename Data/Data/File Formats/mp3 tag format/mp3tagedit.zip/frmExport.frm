VERSION 5.00
Begin VB.Form frmExport 
   Caption         =   "Exportation"
   ClientHeight    =   4380
   ClientLeft      =   1755
   ClientTop       =   3840
   ClientWidth     =   6870
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmExport.frx":0000
   ScaleHeight     =   4380
   ScaleWidth      =   6870
   Begin VB.CommandButton cmdExporter 
      Caption         =   "&Exporter"
      Height          =   375
      Left            =   5380
      TabIndex        =   21
      Top             =   2310
      Width           =   1215
   End
   Begin VB.PictureBox picInfo 
      Align           =   2  'Align Bottom
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      Height          =   225
      Left            =   0
      ScaleHeight     =   225
      ScaleWidth      =   6870
      TabIndex        =   20
      Top             =   4155
      Width           =   6870
   End
   Begin VB.Frame fraTmp 
      ClipControls    =   0   'False
      Height          =   4095
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   6615
      Begin VB.CommandButton cmdDel 
         Caption         =   "<"
         Height          =   255
         Left            =   2400
         TabIndex        =   14
         Top             =   3240
         Width           =   495
      End
      Begin VB.CommandButton cmdDelAll 
         Caption         =   "<<"
         Height          =   255
         Left            =   2400
         TabIndex        =   15
         Top             =   3600
         Width           =   495
      End
      Begin VB.CommandButton cmdAdd 
         Caption         =   ">"
         Height          =   255
         Left            =   2400
         TabIndex        =   13
         Top             =   2640
         Width           =   495
      End
      Begin VB.CommandButton cmdAddAll 
         Caption         =   ">>"
         Height          =   255
         Left            =   2400
         TabIndex        =   12
         Top             =   2280
         Width           =   495
      End
      Begin VB.CommandButton cmdFermer 
         Cancel          =   -1  'True
         Caption         =   "&Fermer"
         Height          =   375
         Left            =   5280
         TabIndex        =   18
         Top             =   3480
         Width           =   1215
      End
      Begin VB.ListBox lstExport 
         Height          =   1620
         Left            =   3000
         MultiSelect     =   2  'Extended
         TabIndex        =   17
         Top             =   2280
         Width           =   2175
      End
      Begin VB.ListBox lstDispo 
         Height          =   1620
         Left            =   120
         MultiSelect     =   2  'Extended
         TabIndex        =   11
         Top             =   2280
         Width           =   2175
      End
      Begin VB.CommandButton cmdParcourir 
         Caption         =   "&Parcourir..."
         Height          =   285
         Left            =   5280
         TabIndex        =   9
         Top             =   1680
         Width           =   1215
      End
      Begin VB.TextBox txtDestination 
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   8
         Text            =   "txtDestination"
         Top             =   1680
         Width           =   5055
      End
      Begin VB.TextBox txtCol 
         Height          =   285
         Left            =   1800
         TabIndex        =   6
         Text            =   "txtCol"
         Top             =   1080
         Width           =   735
      End
      Begin VB.TextBox txtLig 
         Height          =   285
         Left            =   1800
         TabIndex        =   2
         Text            =   "txtLig"
         Top             =   600
         Width           =   735
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Exportation depuis :"
         Height          =   195
         Index           =   9
         Left            =   120
         TabIndex        =   19
         Top             =   210
         Width           =   1455
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Champs � exporter :"
         Height          =   195
         Index           =   8
         Left            =   3000
         TabIndex        =   16
         Top             =   2040
         Width           =   1485
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Champs disponible :"
         Height          =   195
         Index           =   7
         Left            =   120
         TabIndex        =   10
         Top             =   2040
         Width           =   1425
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Fichier de &destination :"
         Height          =   195
         Index           =   6
         Left            =   120
         TabIndex        =   7
         Top             =   1440
         Width           =   1635
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Caract�res sp�ciaux :"
         Height          =   195
         Index           =   5
         Left            =   2760
         TabIndex        =   3
         Top             =   600
         Width           =   1575
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "/r = retour chariot"
         Height          =   720
         Index           =   2
         Left            =   4440
         TabIndex        =   4
         Top             =   600
         Width           =   1320
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "D�limiteur de &colonne :"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   5
         Top             =   1080
         Width           =   1635
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "D�limiteur de &ligne :"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   1
         Top             =   600
         Width           =   1410
      End
   End
End
Attribute VB_Name = "frmExport"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' Variable pour l'arr�t de l'exportation
Private blStopExport As Boolean

' ======================= Boutons d'�change de liste =======================

Private Sub cmdAdd_Click()
Call Echange(lstDispo, lstExport)
End Sub

Private Sub cmdAddAll_Click()
Call EchangeTout(lstDispo, lstExport)
End Sub

Private Sub cmdDel_Click()
Call Echange(lstExport, lstDispo)
End Sub

Private Sub cmdDelAll_Click()
Call EchangeTout(lstExport, lstDispo)
End Sub

Private Sub lstDispo_DblClick()
Call cmdAdd_Click
End Sub

Private Sub lstExport_DblClick()
Call cmdDel_Click
End Sub

' ==================== Ev�nements associ�s aux boutons =====================

Private Sub cmdExporter_Click()
Dim stListing As String, stFile As String
Dim stLig As String, stCol As String, stTmp As String
Dim lgFor As Long
Dim inFree As Integer
If Not blStopExport Then
    blStopExport = True
    Exit Sub
End If
' Fichier destination de l'exportation
stFile = txtDestination.Text
If (stFile <> vbNullString) Then
    ' Contr�le des champs � exporter
    If (lstExport.ListCount > 0) Then
        Screen.MousePointer = vbHourglass
        cmdExporter.Caption = "&Arreter"
        fraTmp.Enabled = False
        blStopExport = False
        ' Pr�paration des ent�tes de colonnes
        stLig = Replace(txtLig.Text, "/r", vbCr)
        stLig = Replace(stLig, "/n", vbLf)
        stLig = Replace(stLig, "/t", vbTab)
        stCol = Replace(txtCol.Text, "/r", vbCr)
        stCol = Replace(stCol, "/n", vbLf)
        stCol = Replace(stCol, "/t", vbTab)
        stTmp = vbNullString
        For lgFor = 0 To lstExport.ListCount - 2
            stTmp = stTmp & """" & lstExport.List(lgFor) & """" & stCol
        Next lgFor
        stTmp = stTmp & """" & lstExport.List(lgFor) & """" & stLig
        inFree = FreeFile
        ' Ouverture du fichier
        Open stFile For Output As #inFree
        ' Ecriture du fichier
        Print #inFree, stTmp;
        ' Ecriture du listing
        Call Mp3GetListing(stCurDir, inFree)
        ' Fermeture du fichier
        Close #inFree
        Screen.MousePointer = vbNormal
        fraTmp.Enabled = True
        cmdExporter.Caption = "&Exporter"
        If Not blStopExport Then
            MsgBox Replace(LoadResString(intLOffset + 168), "%1", stFile), _
                   vbInformation, "Export"
        End If
        blStopExport = True
    Else
        MsgBox LoadResString(intLOffset + 186), vbExclamation, "Export"
        lstExport.SetFocus
    End If
Else
    MsgBox LoadResString(intLOffset + 187), vbExclamation, "Export"
    txtDestination.SetFocus
End If
End Sub

Private Sub cmdFermer_Click()
Unload Me
End Sub

Private Sub cmdParcourir_Click()
' Affiche la fen�tre de s�lection du fichier
txtDestination = OpenFile(Me.hwnd, LoadResString(intLOffset + 185), 1, , , , stCurDir, "txt")
End Sub

' ======================= Chargement de la feuille =========================

Private Sub Form_Load()
' Initialisation des zones
txtLig.Text = "/r/n"
txtCol.Text = ","
blStopExport = True
txtDestination.Text = vbNullString
lblTmp(9).Caption = lblTmp(9).Caption & " " & stCurDir
lstDispo.Clear
lstExport.Clear
lstDispo.AddItem rstrRepertoire:      lstDispo.ItemData(lstDispo.NewIndex) = 1
lstDispo.AddItem rstrFichier:       lstDispo.ItemData(lstDispo.NewIndex) = 2
lstDispo.AddItem rstrTitre:         lstDispo.ItemData(lstDispo.NewIndex) = 3
lstDispo.AddItem rstrArtiste:       lstDispo.ItemData(lstDispo.NewIndex) = 4
lstDispo.AddItem rstrAlbum:         lstDispo.ItemData(lstDispo.NewIndex) = 5
lstDispo.AddItem rstrAnnee:         lstDispo.ItemData(lstDispo.NewIndex) = 6
lstDispo.AddItem rstrGenre:         lstDispo.ItemData(lstDispo.NewIndex) = 7
lstDispo.AddItem rstrCommentaire:   lstDispo.ItemData(lstDispo.NewIndex) = 8
lstDispo.AddItem rstrPiste:         lstDispo.ItemData(lstDispo.NewIndex) = 9
lstDispo.AddItem rstrTaille:        lstDispo.ItemData(lstDispo.NewIndex) = 10
lstDispo.AddItem rstrDuree:         lstDispo.ItemData(lstDispo.NewIndex) = 11
lstDispo.AddItem rstrKbps:          lstDispo.ItemData(lstDispo.NewIndex) = 12
lstDispo.AddItem rstrMode:          lstDispo.ItemData(lstDispo.NewIndex) = 13
' Centrage de la fen�tre
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2
Me.Caption = LoadResString(intLOffset + 179)
' Langue d'affichage
lblTmp(0).Caption = LoadResString(intLOffset + 172)
lblTmp(1).Caption = LoadResString(intLOffset + 173)
lblTmp(2).Caption = Replace(LoadResString(intLOffset + 178), "|", vbCrLf)
lblTmp(5).Caption = LoadResString(intLOffset + 177)
lblTmp(6).Caption = LoadResString(intLOffset + 174)
lblTmp(7).Caption = LoadResString(intLOffset + 175)
lblTmp(8).Caption = LoadResString(intLOffset + 176)
lblTmp(9).Caption = LoadResString(intLOffset + 171)
cmdParcourir.Caption = LoadResString(intLOffset + 181)
cmdExporter.Caption = LoadResString(intLOffset + 182)
cmdFermer.Caption = LoadResString(intLOffset + 183)
End Sub

' ================ Fonctions utilis�es par l'exportation ===================

Private Sub Mp3GetListing(stPath As String, inHandle As Integer)
' Ecriture du listing dans le fichier d'export
Dim stFile As String
Dim stDir As String, tabDir
Dim lgFor As Long, lgRep As Long
Dim stTmp(10) As String
Dim stInfos As String, stLig As String, stCol As String
stDir = vbNullString
stLig = Replace(txtLig.Text, "/r", vbCr)
stLig = Replace(stLig, "/n", vbLf)
stLig = Replace(stLig, "/t", vbTab)
stCol = Replace(txtCol.Text, "/r", vbCr)
stCol = Replace(stCol, "/n", vbLf)
stCol = Replace(stCol, "/t", vbTab)
If (Right$(stPath, 1) <> "\") Then stPath = stPath & "\"
' Recensement des sous-r�pertoires
stFile = Dir$(stPath & "*.*", vbDirectory)
Do While (stFile <> vbNullString)
    If (stFile <> ".") And (stFile <> "..") Then
        ' V�rification de l'attribut courant (r�pertoire)
        If GetAttr(stPath & stFile) And vbDirectory Then
            stDir = stDir & stPath & stFile & vbCrLf
        End If
    End If
    stFile = Dir$()
Loop
tabDir = Split(stDir, vbCrLf)
' Examen des sous-r�pertoires
For lgFor = 0 To UBound(tabDir) - 1
    Call Mp3GetListing(CStr(tabDir(lgFor)), inHandle)
Next lgFor
' R�cup�ration des fichiers
stFile = Dir$(stPath & "*.mp3", vbDirectory)
Do While (stFile <> vbNullString) And Not blStopExport
    stInfos = vbNullString
    If InList(lstExport, 1, True) Then
        stInfos = stInfos & """" & stPath & """" & stCol
    End If
    If InList(lstExport, 2, True) Then
        stInfos = stInfos & """" & stFile & """" & stCol
    End If
    ' Recherche des infos sur le fichier
    LireTagID3v1 stPath & stFile, stTmp(0), stTmp(1), stTmp(2), _
                                  stTmp(3), stTmp(4), stTmp(5), , _
                                  stTmp(6), stTmp(7), stTmp(8), _
                                  stTmp(9), stTmp(10)
    If InList(lstExport, 3, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(0)) & """" & stCol
    End If
    If InList(lstExport, 4, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(1)) & """" & stCol
    End If
    If InList(lstExport, 5, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(2)) & """" & stCol
    End If
    If InList(lstExport, 6, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(3)) & """" & stCol
    End If
    If InList(lstExport, 7, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(4)) & """" & stCol
    End If
    If InList(lstExport, 8, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(5)) & """" & stCol
    End If
    If InList(lstExport, 9, True) Then
        stInfos = stInfos & """" & Trim$(stTmp(6)) & """" & stCol
    End If
    If InList(lstExport, 10, True) Then
        stInfos = stInfos & """" & FileLen(stPath & stFile) & """" & stCol
    End If
    If InList(lstExport, 11, True) Then
        stInfos = stInfos & """" & stTmp(7) & """" & stCol
    End If
    If InList(lstExport, 12, True) Then
        stInfos = stInfos & """" & stTmp(9) & """" & stCol
    End If
    If InList(lstExport, 13, True) Then
        stInfos = stInfos & """" & stTmp(10) & """" & stCol
    End If
    stInfos = Mid$(stInfos, 1, Len(stInfos) - Len(stCol))
    ' Ecriture dans le fichier destination
    Print #inHandle, stInfos & stLig;
    ' Affichage de la progression dans la PictureBox
    picInfo.Cls
    picInfo.Print "   => " & stPath & stFile
    DoEvents
    ' Passe au fichier suivant
    stFile = Dir$()
    If blStopExport Then
        lgRep = MsgBox(LoadResString(intLOffset + 180), _
                       vbQuestion + vbYesNo, _
                       LoadResString(intLOffset + 179))
        If (lgRep <> vbYes) Then blStopExport = False
    End If
Loop
End Sub
