VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CFontTextures"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Collection" ,"CFontTexture"
Attribute VB_Ext_KEY = "Member0" ,"CFontTexture"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit

Private mCol As Collection
Dim NextID&

'---------------------------------------------------------
'draws text with a given font
'---------------------------------------------------------
'Public Sub Draw(ID&, Text$, Width!, Height!)
'Dim i&
'    For i = 1 To mCol.Count
'        If mCol(i).ID = ID Then
'            mCol(i).DrawText Text, Width, Height
'            Exit Sub
'        End If
'    Next
'    Debug.Assert 0
'End Sub

'---------------------------------------------------------
'returns the fontname from an ID
'---------------------------------------------------------
'Public Function Fontname(ID&)
'Dim i&
'    For i = 1 To mCol.Count
'        If mCol(i).ID = ID Then
'            Fontname = mCol(i).Fontname
'            Exit Function
'        End If
'    Next
'    Debug.Assert 0
'End Function

'---------------------------------------------------------
'loads a font if it is not already loaded
'used for stock fonts
'---------------------------------------------------------
Public Function LoadFont(Name$) As CFontTexture
Dim i&
    For i = 1 To mCol.Count
        If mCol(i).Fontname = Name Then
            Set LoadFont = mCol(i)
            Exit Function
        End If
    Next
    Set LoadFont = Add(App.Path & "\fonts\" & Name & ".ftx")
End Function

'---------------------------------------------------------
'load a default font
'---------------------------------------------------------
Public Sub Init()
    Add App.Path & "\fonts\Arial Black.ftx"
End Sub

'---------------------------------------------------------
'loads a font
'---------------------------------------------------------
Private Function Add(Filename$) As CFontTexture
Dim nf As CFontTexture
    CheckError
    Set nf = New CFontTexture
    CheckError
    If nf.LoadFTX(Filename) Then
        NextID = NextID + 1
        nf.ID = NextID
        mCol.Add nf, Format$(NextID)
        Set Add = nf
    End If
    Set nf = Nothing
End Function

Public Property Get Item(vntIndexKey As Variant) As CFontTexture
Attribute Item.VB_UserMemId = 0
  Set Item = mCol(vntIndexKey)
End Property

Public Property Get Count() As Long
    Count = mCol.Count
End Property

Public Sub Remove(vntIndexKey As Variant)
    mCol.Remove vntIndexKey
End Sub

Public Property Get NewEnum() As IUnknown
Attribute NewEnum.VB_UserMemId = -4
Attribute NewEnum.VB_MemberFlags = "40"
    Set NewEnum = mCol.[_NewEnum]
End Property

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub


