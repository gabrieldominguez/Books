//Thanks to Andy Murdoch for the MMX detection code

#ifndef _DETMMX_
#define _DETMMX_

#include <windows.h>

DWORD DetectMMX(VOID);

#endif //_DETMMX_
