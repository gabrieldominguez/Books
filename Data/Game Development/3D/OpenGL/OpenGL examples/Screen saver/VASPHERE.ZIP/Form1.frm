VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "VASphere"
   ClientHeight    =   6030
   ClientLeft      =   3570
   ClientTop       =   2790
   ClientWidth     =   6645
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   6030
   ScaleWidth      =   6645
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3795
      Left            =   360
      TabIndex        =   0
      Top             =   450
      Width           =   3030
      _ExtentX        =   5345
      _ExtentY        =   6694
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyPress(KeyAscii As Integer)
If KeyAscii = Asc("d") Then
    gSphere.Keyd
ElseIf KeyAscii = 32 Then
    gSphere.KeySPACE
End If
End Sub

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_Draw()
gSphere.Draw
End Sub

Private Sub glxCtl1_Init()
gSphere.Init
End Sub

Private Sub glxCtl1_InitGL()
gSphere.InitGL
End Sub

Private Sub glxCtl1_Resize(WIDTH As Long, HEIGHT As Long, Default As Boolean)
Default = gSphere.Resize
End Sub


