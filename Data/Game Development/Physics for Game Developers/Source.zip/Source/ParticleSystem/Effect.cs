using System;
using System.Collections;
using Microsoft.DirectX;

namespace ParticleSystems
{
    namespace Verlet
    {
        namespace Effects
        {

            /// <summary>		 
            /// Wind implements IEffect. Wind is an effect which intends to
            /// emulate a wind travelling along a vector. It applies a 
            /// random velocity increase along the wind vector for all particles
            /// that's supposed to be affected by the wind
            /// </summary>
            public class Wind : IEffect
            {
                /// <summary>
                /// Constructor
                /// </summary>
                /// <param name="particles">Particles to be affected by the wind effect</param>
                /// <param name="ratio">The ratio by which wind force fluctuates</param>
                /// <param name="direction">The wind direction(and strength)</param>
                public Wind(
                    Particle[] particles,
                    float ratio,
                    Vector3 direction)
                {
                    mParticles = particles;
                    mRatio = ratio;
                    mDirection = direction;
                }

                /// <summary>
                /// Applies the effect
                /// </summary>
                /// <param name="timeDelta">The timedelta used by the particle system this iteration</param>
                public void Apply(float timeDelta)
                {
                    float lScale = Tools.Tools.GetRandomNumber(mRatio * timeDelta, timeDelta);
                    int lIter = 0;
                    int lLength = mParticles.Length;
                    for(; lIter < lLength; ++lIter)
                    {
                        float lSubScale = Tools.Tools.GetRandomNumber(0.0f, lScale);
                        mParticles[lIter].IncreaseVelocity(timeDelta, lSubScale * mDirection);
                    }
                }

                /// <summary>
                /// The direction of the wind
                /// </summary>
                public Vector3 Direction
                {
                    get
                    {
                        return mDirection;
                    }
                    set
                    {
                        mDirection = value;
                    }
                }

                /// <summary>
                /// Ratio by which the wind fluctuates
                /// </summary>
                public float Ratio
                {
                    get
                    {
                        return mRatio;
                    }
                    set
                    {
                        mRatio = value;
                    }
                }

                private Particle[] mParticles;
                private float mRatio;
                private Vector3 mDirection;
            }

        }
    }
}