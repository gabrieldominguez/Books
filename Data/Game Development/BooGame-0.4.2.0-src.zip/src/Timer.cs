/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 * Modified by Morgan LaMoore (morganl@gmail.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

using Tao.FreeGlut;

namespace BooGame
{
	/// <summary>
	/// A Cross-Platform Hi-Resolution Timer.
	/// </summary>
	/// <remarks>
	/// By Morgan LaMoore (morganl@gmail.com).
	/// Modified by Rob Loach (http:/www.robloach.net).
	/// </remarks>
	/// <example>The following is an example of the timer's use:
	/// <code>
	/// using Timer = BooGame.Timer;
	/// 
	/// // Limit to 100 FPS
	/// Timer.MaxFPS = 100;
	/// // If you didn't have this, it wouldn't limit framerate at all,
	/// 
	/// // Every frame
	/// int dt = Timer.DeltaTime; //get the length of the last frame (in ms)
	/// int absTime = Timer.Ticks; // get the absolute time relative to the system startup (in ms)
	/// Console.WriteLine(Timer.FPS.ToString());
	/// </code>
    /// 
    /// This is an example of using the Timer object where it will put a "." on the window caption every 2 seconds.
    /// <code>
    /// Timer delay = new Timer(2000); // 2 seconds
    /// 
    /// // In update code
    /// if(delay.CheckTime())
    /// {
    ///     Display.WindowCaption += ".";
    /// }
    /// </code>
    /// </example>
    [Serializable]
	public class Timer
	{
		#region Static Constructor
		/// <summary>
		/// This initializes the timer; it gets called automatically at the first use of Timer.
		/// </summary>
		static Timer()
		{
            Core.Initialize();
			try
			{
				// use QPF/QPC if we can
				if (QueryPerformanceFrequency(out mFrequency) == false ||
					QueryPerformanceCounter(out mTicks) == false)
				{
					throw new Win32Exception();
				}
			}
			catch
			{
				// Function failed; we're not in windows or something's borked
				UseEnvClock();
			}
			
			// Get everything else set up
			mOldTicks = mTicks;
            Timer.MaxFPS = 500;

			Glut.glutIdleFunc(new Glut.IdleCallback(UpdateTimer));
		}
		#endregion Static Constructor

		#region Public Properties

		#region DeltaTime
		/// <summary>
		/// The number of milliseconds between the previous two updates.
		/// </summary>
		public static int DeltaTicks
		{
			get
			{
				return mDeltaTime;
			}
		}
		#endregion DeltaTime

        #region DeltaSeconds
        /// <summary>
        /// The number of seconds between the previous two updates.
        /// </summary>
        public static float DeltaSeconds
		{
			get
			{
				return (float)DeltaTicks / 1000f;
			}
        }
        #endregion DeltaSeconds

		#region Ticks
		/// <summary>
		/// The absolute number of ticks in milliseconds.
		/// </summary>
		public static int Ticks
		{
			get
			{
				return (int) (1000 * mTicks / mFrequency);
			}
		}
		#endregion Ticks

        #region Seconds
        /// <summary>
        /// The absolute time (usually measured since system startup), in seconds.
        /// </summary>
        public static float Seconds
        {
            get
            {
                return (float)Ticks / 1000f;
            }
        }
        #endregion Seconds

        #region Fps
        /// <summary>
		/// The number of frames per second over a very recent .1 second period.
		/// </summary>
		public static float Fps
		{
			get
			{
                return mFPS;
			}
		}
		#endregion Fps
		
		#region MaxFPS
		/// <summary>
		/// The maximum number of frames per second.
		/// </summary>
		/// <remarks>
		/// If you set this to a value less than 1000, it will limit the speed
		/// of your program so you don't go above the max fps (in reality you
		/// will get slightly lower than maxFPS). By default it is set to not
		/// limit speed at all.
		/// </remarks>
		public static int MaxFPS
		{
			get
			{
				return 1000 / mMinWait;
			}
			set
			{
				mMinWait = 1000 / value;
			}
		}
		#endregion MaxFPS

		#endregion Public Properties
		
		#region Public Methods

        internal static void Initialize()
        {
        }

        /// <summary>
        /// Invoked when a new FPS value is reported.
        /// </summary>
        public static event FpsUpdateEventHandler FpsUpdate;

        /// <summary>
        /// Resets the timer's progress in the current tick.
        /// </summary>
        /// <remarks>Doesn't invoke an Update event.</remarks>
        public static void Reset()
        {
            Update();
        }

		#region Update()
        /// <summary>
        /// Called when the application is idle.
        /// </summary>
        private static void UpdateTimer()
        {
            Update();
            Core.InvokeUpdate();
        }

		/// <summary>
		/// This function will be called once per frame. It updates the timer.
		/// </summary>
		private static void Update()
		{
			// last frame's ticks
			mOldTicks = mTicks;
			
			// Should we do it the easy way...
			if(mUseEnvTicks)
			{
				mTicks = Environment.TickCount;
				
				while(mMinWait > mTicks - mOldTicks)
				{
					System.Threading.Thread.Sleep(0);
					mTicks = Environment.TickCount;
				}
				
				mDeltaTime = (int) (mTicks - mOldTicks);
			}
				// or the QPF way?
			else
			{
				QueryPerformanceCounter(out mTicks);

                while (mMinWait * mFrequency > 1000 * (mTicks - mOldTicks))
				{
					System.Threading.Thread.Sleep(0);
					QueryPerformanceCounter(out mTicks);
				}
				
				mDeltaTime = ((int) (1000 * (mTicks - mOldTicks) / mFrequency));
			}

            mFPSFrames++;

            if ((mTicks - mFPSTime) * 1000 >= mFPSUpdate * mFrequency)
            {
                mFPS = ((float)(mFPSFrames * mFrequency)) / ((float)(mTicks - mFPSTime));

                mFPSFrames = 0;
                mFPSTime = mTicks;

                // Report new FPS
                if (FpsUpdate != null)
                    FpsUpdate(null, new FpsUpdateEventArgs(mFPS));
            }
		}
		#endregion Update()

		#endregion Public Methods

		#region Private Methods
		
		#region UseEnvClock
		/// <summary>
		/// A private method that makes the timer use the environment clock.
		/// </summary>
		private static void UseEnvClock()
		{
			mUseEnvTicks = true;
			mFrequency = 1000;
			mTicks = Environment.TickCount;
			// Doesn't the framework make everything simpler?
			// It's too bad Microsoft didn't implement their
			// own framework with a high resolution timer.
		}
		#endregion UseEnvClock

		#region P/Invoke Functions

		#region QueryPerformanceFrequency
		[DllImport("kernel32.dll", CallingConvention=CallingConvention.StdCall), System.Security.SuppressUnmanagedCodeSecurity]
		private static extern bool QueryPerformanceFrequency(out long Frequency);
		#endregion QueryPerformanceFrequency
		
		#region QueryPerformanceCounter
		[DllImport("kernel32.dll", CallingConvention=CallingConvention.StdCall), System.Security.SuppressUnmanagedCodeSecurity]
		private static extern bool QueryPerformanceCounter(out long TimeCount);
		#endregion QueryPerformanceCounter

		#endregion P/Invoke Functions

		#endregion Private Methods
		
		#region Private Variables
		private static long mFrequency = 0;
		private static long mTicks = 0;
		private static long mOldTicks = 0;
		private static int mDeltaTime = 0;
		private static int mMinWait = 0;
		private static bool mUseEnvTicks = false;
        private static long mFPSTime = 0;
        private static int mFPSFrames = 1;
        private static float mFPS = 1f;

        //The FPS counter will update about this often (in ms)
        private static int mFPSUpdate = 100;
		#endregion Private Variables

        #region Object Implementation

        private int m_Interval = 1000;

        /// <summary>
        /// Gets and sets the number of milliseconds between ticks.
        /// </summary>
        public int Interval
        {
            get { return m_Interval; }
            set { m_Interval = value; }
        }

        /// <summary>
        /// Gets and sets the number of seconds between ticks.
        /// </summary>
        public float IntervalSeconds
        {
            get { return (float)m_Interval / 1000f; }
            set { m_Interval = (int)(value * 1000f); }
        }

        private int m_StartTime = Timer.Ticks;

        /// <summary>
        /// Gets the millisecond tick at which this timer was started.
        /// </summary>
        public int StartTick
        {
            get { return m_StartTime; }
        }

        /// <summary>
        /// Restarts the timer.
        /// </summary>
        public void Restart()
        {
            m_StartTime = Timer.Ticks;
        }

        /// <summary>
        /// Checks if a tick is due for the timer and restarts it if it is.
        /// </summary>
        /// <returns>True if a tick was called, false otherwise.</returns>
        /// <remarks>Restarts the timer if there was a tick.</remarks>
        public bool CheckTime()
        {
            int ticks = Timer.Ticks;
            if (ticks >= m_StartTime + m_Interval)
            {
                Restart();
                if (Tick != null)
                    Tick(this, new TickEventArgs(ticks));
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets whether a tick is due.
        /// </summary>
        public bool IsTickTime
        {
            get
            {
                return Timer.Ticks >= m_StartTime + m_Interval;
            }
        }

        /// <summary>
        /// Create a Timer object.
        /// </summary>
        public Timer()
        {
        }

        /// <summary>
        /// Create a Timer object with a set interval.
        /// </summary>
        /// <param name="interval">The number of milliseconds between ticks.</param>
        public Timer(int interval)
        {
            m_Interval = interval;
        }
        public event TickEventHandler Tick;
        #endregion Object Implementation
    }

    /// <summary>
    /// Describes an event associated with a tick.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The tick arguments.</param>
    public delegate void TickEventHandler(object sender, TickEventArgs args);

    /// <summary>
    /// Event arguments passed when a tick occurs.
    /// </summary>
    public class TickEventArgs : EventArgs
    {
        private int m_Tick;

        /// <summary>
        /// Absolute number of milliseconds that have passed.
        /// </summary>
        public int Tick
        {
            get { return m_Tick; }
        }

        /// <summary>
        /// Absolute number of seconds that have passed.
        /// </summary>
        public float TickSeconds
        {
            get { return (float)m_Tick / 1000f; }
        }

        /// <summary>
        /// Create a set of tick arguments.
        /// </summary>
        /// <param name="tick">Number of milliseconds that have passed.</param>
        public TickEventArgs(int tick)
        {
            m_Tick = tick;
        }

        /// <summary>
        /// Create a set of tick arguments.
        /// </summary>
        public TickEventArgs()
        {
        }
    }

    /// <summary>
    /// Describes when a new FPS value is updated.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments associated with the event.</param>
    public delegate void FpsUpdateEventHandler(object sender, FpsUpdateEventArgs args);

    /// <summary>
    /// An event argument passed when there is an updated FPS value.
    /// </summary>
    public class FpsUpdateEventArgs : EventArgs
    {
        /// <summary>
        /// Creates an FPS update event argument.
        /// </summary>
        /// <param name="fps">The current FPS.</param>
        public FpsUpdateEventArgs(float fps)
        {
            m_Fps = fps;
        }
        private float m_Fps = 0;
        /// <summary>
        /// The frames per second at which the event was called.
        /// </summary>
        public float Fps
        {
            get
            {
                return m_Fps;
            }
        }
    }
}