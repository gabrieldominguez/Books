VERSION 5.00
Begin VB.UserControl glxCtl 
   ClientHeight    =   7800
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7845
   ClipControls    =   0   'False
   PaletteMode     =   4  'None
   ScaleHeight     =   520
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   523
   ToolboxBitmap   =   "glxCtl.ctx":0000
   Begin VB.Timer Timer1 
      Left            =   675
      Top             =   495
   End
   Begin VB.Image CursorDolly 
      Height          =   480
      Left            =   4320
      Picture         =   "glxCtl.ctx":0532
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorOrbit 
      Height          =   480
      Left            =   6930
      Picture         =   "glxCtl.ctx":083C
      Top             =   270
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorMove 
      Height          =   480
      Left            =   4230
      Picture         =   "glxCtl.ctx":0B46
      Top             =   765
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorYaw 
      Height          =   480
      Left            =   5940
      Picture         =   "glxCtl.ctx":0E50
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorRoll 
      Height          =   480
      Left            =   6435
      Picture         =   "glxCtl.ctx":115A
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorPitch 
      Height          =   480
      Left            =   5445
      Picture         =   "glxCtl.ctx":1464
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorArcRotate 
      Height          =   480
      Left            =   4860
      Picture         =   "glxCtl.ctx":176E
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorScale 
      Height          =   480
      Left            =   5265
      Picture         =   "glxCtl.ctx":1A78
      Top             =   765
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorRotate 
      Height          =   480
      Left            =   4770
      Picture         =   "glxCtl.ctx":1D82
      Top             =   765
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorZoom 
      Height          =   480
      Left            =   3285
      Picture         =   "glxCtl.ctx":208C
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorPan 
      Height          =   480
      Left            =   3825
      Picture         =   "glxCtl.ctx":2396
      Top             =   225
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image Image2 
      Height          =   1920
      Left            =   135
      Picture         =   "glxCtl.ctx":26A0
      Top             =   1125
      Visible         =   0   'False
      Width           =   1920
   End
   Begin VB.Image Image1 
      Height          =   7680
      Left            =   45
      Picture         =   "glxCtl.ctx":4212
      Top             =   1215
      Visible         =   0   'False
      Width           =   7680
   End
End
Attribute VB_Name = "glxCtl"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: sets up an OpenGL window ready for an app to use
'   - can be used for porting GLUT and SDK samples
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'   March 98 - changed initialization so it won't crash so much in design mode
'           - reworked the Camera to use a matrix
'           - killed a separate ortho eyepoint
'           - changed the acos, asin, atan2 math functions
'           - changed Initialization to wait on creating
'               display lists for grids(so maybe sharelists will work)
'           - some apps will require a Form.Show before the Init will
'               will succeed, don't know why yet.
'   Feb 98 - added offscreen rendering option
'
'NOTES: This ocx is intended to function more as a code library than as a
'component. Most of the ocx's functionality can be disabled or ignored if
'it is not needed. Because this ocx is intended to be used for learning and
'experimenting, it supports many different opengl scenarios. You can a little
'speed improvement by not using an ocx and placing just the code you need
'directly in your VB app.
'The Basics:
'The default behavior of the ocx is to set up a RGBA double-buffer with 16bit
'depth and draw to the UserControl window. It also creates a glxCamera and
'sets up a perspective view and handles resize events. On Paint or Timer events,
'it clears the buffer, sets up the projection, loads an identity matrix, fires
'a Draw event, then swaps the buffer. It also enables one light, depth testing,
'and creates 28 stock materials. This allows the user to just start drawing.
'Modifying the default behavior:
'Use the Init event to modify the setup. You can set the depth, pixel format flags,
'whether to use the camera, whether to clear, single/double buffer.
'As of v1.4, you can use an offscreen memDC to render, then draw to with GDI;
'the ocx then blits the image to its window.
'Other basic options include scene rotation with the right mouse button, picking,
'and grids. This comprises this basic functionality of the ocx and is contained
'in this module, glxCamera, and glxLight/s.
'Other classes:
'Font (glxFont, glxGlyph/s), material (glxMatrial/s), and texture (glxTexture,
'glxImage, glxRGBImage) - these utility routines can be used creating an object
'using Newxxx routines.
'Shapes provides some primitives. Mesh, Curve, and DigitalDissolve are for the SDK screen
'saver samples only. Timer isn't much use either.
'All modules beginning with 'gle' are from the OpenGL Extrusion Library distributed
'with GLUT.
'
'That's about it. It's a little tricky sometimes to coordinate an apps code with
'the ocx's behavior when the app is trying to implement an advanced or unusual
'technique. Please keep in mind that this ocx is directed toward basic services
'and beginning issues and that it sets up a basic gl rendering context to that end.
'You may need to override or disable its behavior in some situations. The Resize
'and Paint events contain various flags which let you control the basic behavior.
'
'Also keep in mind that, although the ocx is structured like most ocx's, where the
'VB app looks like a 'client', the reality is that both and ocx are more or less
'coequal partners. The ocx presents a visible window on which the
'gl renderings are displayed, but this needn't be so. The ocx can be modified to
'be invisible and render to some other surface such as a form or dialog box, or
'to not render at all. Any of the code in the ocx can be executed from the VB app
'and vice versa.
'
'The ocx contains 2 images - these are for texturing tests and demonstrating image
'loading. Likewise for the image in the resource file.
'
'Multiple instances:
'You can use multiple ocxs in a vb app, but I haven't yet prepared a demo of
'sharing display lists, and each ocx will duplicate any data it maintains (textures,
'display lists).
'---------------------------------------------------------------------------------
Dim m_ID& 'to debug 2 instances
Dim m_RenderMode& 'drawing or selecting
Dim WORLD_LIST& 'list for the grid and axes
'---------------------------------------------------------------------------------
Public Enum glxCursors 'sets of state values for dumping
    CURSOR_ZOOM = 200
    CURSOR_PAN = 201
    CURSOR_DOLLY = 202
    CURSOR_ARCROTATE = 203
    CURSOR_PITCH = 204
    CURSOR_YAW = 205
    CURSOR_ROLL = 206
    CURSOR_ORBIT = 207
    CURSOR_MOVE = 210
    CURSOR_ROTATE = 211
    CURSOR_SCALE = 212
End Enum

'---------------------------------------------------------------------------------
'debugging
Public Enum glxGLStates 'sets of state values for dumping
    glsCurrentValues = 1
    glsEnabled = 4
    glsLighting = 6
    glsLights = 7
    glsRaster = 10
    glsTexture = 12
    glsGLMatrix = 20
End Enum
'---------------------------------------------------------------------------------
'control properties
Public Enum glxBorderStyles
    glxctlNone = 0
    glxctlFixedSingle = 1
End Enum
Public Enum GridStyleConstants
    glxGridNone = 0
    glxGridX = 1
    glxGridY = 2
    glxGridZ = 4
    glxGridXY = 3
    glxGridYZ = 6
    glxGridXZ = 5
    glxGridXYZ = 7
End Enum
Public Enum AxisStyleConstants
    glxNone = &H0
    glxXYZ = &H1
End Enum
'---------------------------------------------------------------------------------
'gl setup
Public Enum ClearModes 'glClear
    clrNone = 0
    clrColor = 1
    clrDepth = 2
    clrBoth = 3
End Enum
' Depth types
Public Enum PFDepthTypes
    SS_DEPTH_NONE = 0
    SS_DEPTH16 = 16
    SS_DEPTH32 = 32
End Enum
'---------------------------------------------------------------------------------
'gle
'---------------------------------------------------------------------------------
' defines for tubing join styles
Public Enum gleJoinStyles
    gleRAW = &H1
    gleANGLE = &H2
    gleCUT = &H3
    gleROUND = &H4
    'gleCAP = &H10
    'TUBE_JN_MASK = &HF           ' mask bits
End Enum
' determine how normal vectors are to be handled
Public Enum gleNormStyles
    gleFACET = &H100
    gleEDGE = &H200
    glePATH_EDGE = &H400 ' for spiral, lathe, helix primitives
    gleMASK = &HF00         ' mask bits
End Enum
' closed or open countours
'Public Const TUBE_CONTOUR_CLOSED = &H1000
Public Enum gleContourStyles
    gleOPEN = &H0
    gleCLOSED = &H1
End Enum
Public Enum gleCapStyles
    gleCAPS = &H0
    gleNOCAPS = &H1
End Enum
Public Enum gleTextureModes
    GLE_TEXTURE_VERTEX_FLAT = 1
    GLE_TEXTURE_NORMAL_FLAT = 2
    GLE_TEXTURE_VERTEX_CYL = 3
    GLE_TEXTURE_NORMAL_CYL = 4
    GLE_TEXTURE_VERTEX_SPH = 5
    GLE_TEXTURE_NORMAL_SPH = 6
    GLE_TEXTURE_VERTEX_MODEL_FLAT = 7
    GLE_TEXTURE_NORMAL_MODEL_FLAT = 8
    GLE_TEXTURE_VERTEX_MODEL_CYL = 9
    GLE_TEXTURE_NORMAL_MODEL_CYL = 10
    GLE_TEXTURE_VERTEX_MODEL_SPH = 11
    GLE_TEXTURE_NORMAL_MODEL_SPH = 12
End Enum
'---------------------------------------------------------------------------------
'offscreen rendering
Public Enum glxPenStyles
    psSolid = PS_SOLID
    psDash = PS_DASH
    psDot = PS_DOT
    psDashDot = PS_DASHDOT
    psDashDotDot = PS_DASHDOTDOT
    psNull = PS_NULL
    psInsideFrame = PS_INSIDEFRAME
End Enum
Public Enum glxROP2Modes
    r2Black = R2_BLACK 'Pixel is always 0.
    r2CopyPen = R2_COPYPEN 'Pixel is the pen color.
    r2MaskNotPen = R2_MASKNOTPEN 'Pixel is a combination of the colors common to both the screen and the inverse of the pen.
    r2MaskPen = R2_MASKPEN ' Pixel is a combination of the colors common to both the pen and the screen.
    r2MaskPenNot = R2_MASKPENNOT ' Pixel is a combination of the colors common to both the pen and the inverse of the screen.
    r2MergNotPen = R2_MERGENOTPEN 'Pixel is a combination of the screen color and the inverse of the pen color.
    r2MergePen = R2_MERGEPEN ' Pixel is a combination of the pen color and the screen color.
    r2MergePenNot = R2_MERGEPENNOT ' Pixel is a combination of the pen color and the inverse of the screen color.
    r2NOP = R2_NOP ' Pixel remains unchanged.
    r2Not = R2_NOT 'Pixel is the inverse of the screen color.
    r2NotCopyPen = R2_NOTCOPYPEN ' Pixel is the inverse of the pen color.
    r2NotMaskPen = R2_NOTMASKPEN ' Pixel is the inverse of the R2_MASKPEN color.
    r2NotMergePen = R2_NOTMERGEPEN 'Pixel is the inverse of the R2_MERGEPEN color.
    r2NotXORPen = R2_NOTXORPEN ' Pixel is the inverse of the R2_XORPEN color.
    r2White = R2_WHITE ' Pixel is always 1.
    r2XORPen = R2_XORPEN ' Pixel is a combination of the colors in the pen and in the screen, but not in both.
End Enum
Public Enum glxHatchStyles
    hsBDiagonal = HS_BDIAGONAL ' A 45-degree upward, left-to-right hatch
    hsCross = HS_CROSS ' Horizontal and vertical cross-hatch
    hsDiagCross = HS_DIAGCROSS ' 45-degree crosshatch
    hsFDiagonal = HS_FDIAGONAL ' A 45-degree downward, left-to-right hatch
    hsHorizontal = HS_HORIZONTAL ' Horizontal hatch
    hsVertical = HS_VERTICAL
End Enum

'---------------------------------------------------------------------------------
'Default Property Values:
Const m_def_BackColor = 0 '&H8000000F
'Property Variables:
Dim m_BackColor As OLE_COLOR
'---------------------------------------------------------------------------------
'Event Declarations:
Event Click() 'MappingInfo=UserControl,UserControl,-1,Click
Event DblClick() 'MappingInfo=UserControl,UserControl,-1,DblClick
Event KeyDown(KeyCode As Integer, shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyDown
Event KeyPress(KeyAscii As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyPress
Event KeyUp(KeyCode As Integer, shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyUp
Event MouseDown(Button As Integer, shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseDown
Event MouseMove(Button As Integer, shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseMove
Event MouseUp(Button As Integer, shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseUp
Event Paint() 'MappingInfo=UserControl,UserControl,-1,Paint
Event Resize(Width&, Height&, Default As Boolean) 'MappingInfo=UserControl,UserControl,-1,Resize
Event Init()
Event InitGL()
Event Draw()
Event DrawGDI()
Event Pick(items&())
Event EnterFocus()
Event ExitFocus()
'Event MakePalette(hPal&)
'---------------------------------------------------------------------------------
'PUBLIC MEMBERS
'---------------------------------------------------------------------------------
'public objects
Public Font As glxFont
Public Materials As glxMaterials
Public Lights As glxLights
Public Camera As glxCamera
Attribute Camera.VB_VarMemberFlags = "400"
Public Palette As glxPalette
Public Ex As glxUtility
Public Shapes As glxShapes
Public Trackball As glxTrackball
'OBSOLETE:
Public hbrBg&   ' global bg brush
'---------------------------------------------------------------------------------
'PRIVATE VARIABLES
'---------------------------------------------------------------------------------
Dim m_Flags&  ' various flags
Dim m_Ready As Boolean 'initialized
'---------------------------------------------------------------------------------
'Property Variables:
Dim m_Width&, m_Height&
Dim m_hRC&, m_hDC&
Dim m_hMemDC&, m_hBmpOld&, m_hBmp& 'offscreen rendering
Dim m_UseMemDC As Boolean
Dim m_pfFlags As Long    ' pixel format flags
Dim m_depthType As PFDepthTypes
Dim m_ClearMode As ClearModes
Dim m_DoubleBuffer As Boolean
Dim m_pfPixelType As Byte
Dim m_MouseX&, m_MouseY&
Dim m_Picked&
Dim m_Animate As Boolean
Dim m_bUseCamera As Boolean
Dim m_MousePointer%
'debug grid:
Dim m_GridStyle As GridStyleConstants '
Dim m_GridStep&
Dim m_Axis As AxisStyleConstants
Dim m_SizeX#, m_SizeY#, m_SizeZ# 'size of the 3d worldspace
'
Dim m_KeyRotate As Boolean
Dim m_MouseRotate As Boolean
Dim m_bAllowPick As Boolean
Dim m_Hits&
'---------------------------------------------------------------------------------
'GDI stuff when memdc is used
Dim m_DrawMode As glxROP2Modes
'pen
Dim m_DrawWidth As Long
Dim m_ForeColor As OLE_COLOR
Dim m_DrawStyle As glxPenStyles
'brush
Dim m_FillColor As OLE_COLOR
Dim m_FillStyle As Long
Dim m_CurPen As Long          'Handle of current pen
Dim m_OldPen As Long          'Handle of old pen
Dim m_CurBrush As Long        'Handle of current brush
Dim m_OldBrush As Long        'Handle of old brush

Private Sub Image3_Click()

End Sub

Private Sub UserControl_Initialize()
    Set UC = Me
    m_SizeX = 10 'grid size
    m_SizeY = 10
    m_SizeZ = 10
    'set defaults
    m_bUseCamera = True
    m_depthType = SS_DEPTH16
    m_DoubleBuffer = True
    m_ClearMode = clrBoth
    m_pfPixelType = PFD_TYPE_RGBA
    m_pfFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_TYPE_RGBA Or PFD_DOUBLEBUFFER
    'these do nothing in Class_Init, so OK
    'to create here
    Set PicStars = Image1.Picture
    Set PicBricks = Image2.Picture
    Set Palette = New glxPalette
    Debug.Print "UC_Intitialize"
End Sub

Private Sub UserControl_Terminate()
    glDeleteLists WORLD_LIST, 1
    If m_hRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hRC
    End If
    Set Materials = Nothing
    Set Lights = Nothing
    Set Camera = Nothing
    Set Font = Nothing
    Set Palette = Nothing
    Set Ex = Nothing
    Set Shapes = Nothing
    Set Trackball = Nothing
    ' release the Memory Device Context.
    m_ReleaseMemDC
    Set PicStars = Nothing
    Set PicBricks = Nothing
End Sub

'---------------------------------------------------------------------------------
Private Sub m_ReleaseMemDC()
Dim r&
    If m_hBmpOld Then
        If m_hMemDC = 0 Then Debug.Assert 0
        m_hBmp = SelectObject(m_hMemDC, m_hBmpOld)
        DeleteObject m_hBmp
        m_hBmp = 0
    End If
    'GDI objects
    If m_OldPen Then
        SelectObject m_hMemDC, m_OldPen: m_OldPen = 0
    End If
    If m_CurPen <> 0 Then
        DeleteObject m_CurPen: m_CurPen = 0
    End If
    If m_OldBrush <> 0 Then
        SelectObject m_hMemDC, m_OldBrush: m_OldBrush = 0
    End If
    If m_CurBrush <> 0 Then
        DeleteObject m_CurBrush: m_CurBrush = 0
    End If
    If m_hMemDC Then
        r = DeleteDC(m_hMemDC)
    End If
End Sub

'---------------------------------------------------------------------------------
'PROPERTIES
'---------------------------------------------------------------------------------

'---------------------------------------------------------------------------------
'the glClearColor
'---------------------------------------------------------------------------------
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns or sets the design-time backcolor of the control. Has no effect after gl is initialized."
    BackColor = m_BackColor
End Property

Public Property Let BackColor(ByVal NewColor As OLE_COLOR)
Dim r!, g!, B!
    If m_Ready Then
        r = Ex.GetRValue(NewColor) / 255
        g = Ex.GetGValue(NewColor) / 255
        B = Ex.GetBValue(NewColor) / 255
        If r > 1 Or g > 1 Or B > 1 Then Debug.Assert 0
        MakeCurrent
        glClearColor r, g, B, 1
    End If
End Property

'---------------------------------------------------------------------------------
'Specifies what kind of clearing is done before firing Draw.
'---------------------------------------------------------------------------------
Public Property Get ClearMode() As ClearModes
Attribute ClearMode.VB_Description = "Returns or sets a value indicating whether the control should clear the buffers before firing the 'Draw' event."
Attribute ClearMode.VB_MemberFlags = "400"
    ClearMode = m_ClearMode
End Property

Public Property Let ClearMode(ByVal NewValue As ClearModes)
    m_ClearMode = NewValue
End Property

'---------------------------------------------------------------------------------
'Specifies single or double buffering.
'---------------------------------------------------------------------------------
Public Property Get DoubleBuffer() As Boolean
Attribute DoubleBuffer.VB_MemberFlags = "400"
DoubleBuffer = m_DoubleBuffer
End Property

'---------------------------------------------------------------------------------
'default flags:
'PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_TYPE_RGBA Or PFD_DOUBLEBUFFER
'---------------------------------------------------------------------------------
Public Property Let DoubleBuffer(ByVal NewValue As Boolean)
m_DoubleBuffer = NewValue
If m_DoubleBuffer Then
    m_pfFlags = m_pfFlags Or PFD_DOUBLEBUFFER
Else
    If m_pfFlags And PFD_DOUBLEBUFFER Then
        m_pfFlags = m_pfFlags Xor PFD_DOUBLEBUFFER
    End If
End If
End Property

'---------------------------------------------------------------------------------
'flags for the PFD. Normally should be set during Init.
'---------------------------------------------------------------------------------
Public Property Get pfFlags() As Long
Attribute pfFlags.VB_MemberFlags = "400"
pfFlags = m_pfFlags
End Property

Public Property Let pfFlags(ByVal NewValue As Long)
m_pfFlags = NewValue
End Property

'---------------------------------------------------------------------------------
'RGBA or paletted. Normally should be set during Init.
'---------------------------------------------------------------------------------
Public Property Get pfPixelType() As Byte
Attribute pfPixelType.VB_MemberFlags = "400"
pfPixelType = m_pfPixelType
End Property

Public Property Let pfPixelType(ByVal NewValue As Byte)
m_pfPixelType = NewValue
End Property

'---------------------------------------------------------------------------------
'Depth for PFD. Normally should be set during Init.
'---------------------------------------------------------------------------------
Public Property Get DepthType() As PFDepthTypes
Attribute DepthType.VB_MemberFlags = "400"
DepthType = m_depthType
End Property

Public Property Let DepthType(ByVal NewValue As PFDepthTypes)
m_depthType = NewValue
End Property

'---------------------------------------------------------------------------------
Public Property Get BorderStyle() As glxBorderStyles
Attribute BorderStyle.VB_Description = "Returns or sets the border style"
    BorderStyle = UserControl.BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As glxBorderStyles)
    UserControl.BorderStyle() = IIf(New_BorderStyle, 1, 0)
    PropertyChanged "BorderStyle"
End Property

'---------------------------------------------------------------------------------
Public Property Get MouseIcon() As Picture
    Set MouseIcon = UserControl.MouseIcon
End Property

Public Property Set MouseIcon(ByVal New_MouseIcon As Picture)
    Set UserControl.MouseIcon = New_MouseIcon
    PropertyChanged "MouseIcon"
End Property

'---------------------------------------------------------------------------------
Public Property Get MousePointer() As Integer
    MousePointer = m_MousePointer
End Property

Public Property Let MousePointer(ByVal New_MousePointer As Integer)
    m_MousePointer = New_MousePointer
    With UserControl
    If m_MousePointer <= 99 Then
        .MousePointer() = m_MousePointer
    Else
        .MousePointer() = 99
        Select Case m_MousePointer
        Case 200: Set .MouseIcon = CursorZoom
        Case 201: Set .MouseIcon = CursorPan
        Case 202: Set .MouseIcon = CursorDolly
        Case 203: Set .MouseIcon = CursorArcRotate
        Case 204: Set .MouseIcon = CursorPitch
        Case 205: Set .MouseIcon = CursorYaw
        Case 206: Set .MouseIcon = CursorRoll
        Case 207: Set .MouseIcon = CursorOrbit
        Case 210: Set .MouseIcon = CursorMove
        Case 211: Set .MouseIcon = CursorRotate
        Case 212: Set .MouseIcon = CursorScale
        Case Else
            .MousePointer = 0
        End Select
    End If
    End With
    PropertyChanged "MousePointer"
End Property

'---------------------------------------------------------------------------------
'not implemented
Public Property Get KeyRotate() As Boolean
KeyRotate = m_KeyRotate
End Property

Public Property Let KeyRotate(ByVal NewValue As Boolean)
m_KeyRotate = NewValue
End Property

'---------------------------------------------------------------------------------
'Enables use of Trackball to rotate the scene
Public Property Get MouseRotate() As Boolean
MouseRotate = m_MouseRotate
End Property

Public Property Let MouseRotate(ByVal NewValue As Boolean)
m_MouseRotate = NewValue
End Property

'---------------------------------------------------------------------------------
'Returns the hDC used for rendering, either the UC window or the memDC.
Public Property Get hDC() As Long
    'hDC = UserControl.hDC
    hDC = m_hDC
End Property

Public Property Get hRC() As Long
    hRC = m_hRC
End Property

Public Property Get hWnd() As Long
    hWnd = UserControl.hWnd
End Property

'---------------------------------------------------------
'Returns or sets a value indicating whether the XYZ axes will be drawn
Public Property Get Axis() As AxisStyleConstants
Axis = m_Axis
End Property

Public Property Let Axis(ByVal NewValue As AxisStyleConstants)
m_Axis = NewValue
DrawWorld WORLD_LIST, m_GridStyle
Render
End Property

'---------------------------------------------------------------------------------
'Returns or sets the type of grids which will be draw by DrawGrids()
Public Property Get Grid() As GridStyleConstants
Grid = m_GridStyle
End Property

Public Property Let Grid(ByVal NewValue As GridStyleConstants)
m_GridStyle = NewValue
DrawWorld WORLD_LIST, m_GridStyle
Render
End Property

'---------------------------------------------------------------------------------
Public Property Get GridStep&()
GridStep = m_GridStep
End Property

Public Property Let GridStep(ByVal NewValue&)
m_GridStep = NewValue
DrawWorld WORLD_LIST, m_GridStyle
Render
End Property

'---------------------------------------------------------------------------------
'Sets/returns the size of the grid
Public Sub SetWorldSize(ByVal X As Double, ByVal Y As Double, ByVal z As Double)
m_SizeX = X
m_SizeY = Y
m_SizeZ = z
DrawWorld WORLD_LIST, m_GridStyle
Render
End Sub

Public Property Get SizeX() As Double
SizeX = m_SizeX
End Property

Public Property Get SizeY() As Double
SizeY = m_SizeY
End Property

Public Property Get SizeZ() As Double
SizeZ = m_SizeZ
End Property

'---------------------------------------------------------------------------------
Public Property Get ScaleHeight() As Single
    ScaleHeight = UserControl.ScaleHeight
End Property

Public Property Get ScaleWidth() As Single
    ScaleWidth = UserControl.ScaleWidth
End Property

'---------------------------------------------------------------------------------
'an ID to distinguish between ocx instances
Public Property Get DebugID() As Long
DebugID = m_ID
End Property

'---------------------------------------------------------------------------------
'for debugging multiple instances
Public Property Let DebugID(ByVal NewValue As Long)
If m_ID Then Debug.Assert 0
m_ID = NewValue
Debug.Print "ID:" & m_ID
Debug.Print "m_hDC:" & m_hDC
Debug.Print "hRC:" & m_hRC
Debug.Print "hWnd" & hWnd
End Property

'---------------------------------------------------------------------------------
'drawing or picking
Friend Property Get RenderMode&()
RenderMode = m_RenderMode
End Property

Friend Property Let RenderMode(ByVal NewValue&)
m_RenderMode = NewValue
End Property

'---------------------------------------------------------------------------------
'Starts and stops the animation timer
Public Property Get Animate() As Boolean
Animate = m_Animate
End Property

Public Property Let Animate(ByVal NewValue As Boolean)
m_Animate = NewValue
If m_Animate Then
    Timer1.Interval = 50
    Timer1.Enabled = -1
Else
    Timer1.Enabled = 0
End If
End Property

'---------------------------------------------------------------------------------
'Enables picking
Public Property Get Pick() As Boolean
Pick = m_bAllowPick
End Property

Public Property Let Pick(ByVal NewValue As Boolean)
m_bAllowPick = NewValue
End Property

'---------------------------------------------------------------------------------
'Timer interval
Public Property Get Interval&()
Interval = Timer1.Interval
End Property

Public Property Let Interval(ByVal NewValue&)
Timer1.Interval = NewValue
End Property

'---------------------------------------------------------------------------------
'returns number of hits from last mousedown
Public Property Get Hits() As Long
Hits = m_Hits
End Property

'---------------------------------------------------------------------------------
'default is true
Public Property Get UseCamera() As Boolean
UseCamera = m_bUseCamera
End Property

Public Property Let UseCamera(ByVal NewValue As Boolean)
m_bUseCamera = NewValue
End Property

'------------------------------------------------------------------------------------
'default is false
Public Property Get UseMemDC() As Boolean
    UseMemDC = m_UseMemDC
End Property

Public Property Let UseMemDC(ByVal NewValue As Boolean)
    m_UseMemDC = NewValue
End Property

'------------------------------------------------------------------------------------
Public Property Get MemDC&()
    MemDC = m_hMemDC
End Property

'Public Property Let MemDC(ByVal NewValue As Boolean)
'    m_MemDC = NewValue
'End Property

'---------------------------------------------------------------------------------
' PROPERTIES FOR GDI
'---------------------------------------------------------------------------------
    
Public Property Get Drawmode() As glxROP2Modes
    Drawmode = m_DrawMode
End Property

Public Property Let Drawmode(ByVal vNewValue As glxROP2Modes)
    If vNewValue <= 0 Then vNewValue = 1
    If vNewValue > 16 Then vNewValue = 16
    m_DrawMode = vNewValue
    SetROP2 m_hMemDC, m_DrawMode
End Property

'---------------------------------------------------------------------------------
Public Property Get ForeColor() As OLE_COLOR
    ForeColor = m_ForeColor
End Property

Public Property Let ForeColor(ByVal NewValue As OLE_COLOR)
    m_ForeColor = NewValue
    m_CreatePen
End Property

'---------------------------------------------------------------------------------
Public Property Get DrawWidth() As Long
    DrawWidth = m_DrawWidth
End Property

Public Property Let DrawWidth(ByVal vNewValue As Long)
    If vNewValue < 0 Then vNewValue = 0
    m_DrawWidth = vNewValue
    m_CreatePen
End Property

'---------------------------------------------------------------------------------
Public Property Get DrawStyle() As glxPenStyles
    DrawStyle = m_DrawStyle
End Property

Public Property Let DrawStyle(ByVal vNewValue As glxPenStyles)
    If vNewValue < 0 Then vNewValue = 0
    If vNewValue > 6 Then vNewValue = 6
    m_DrawStyle = vNewValue
    m_CreatePen
End Property

'---------------------------------------------------------------------------------
Public Sub SetPen(ByVal DrawStyle As glxPenStyles, ByVal DrawWidth As Long, ByVal ForeColor As OLE_COLOR)
    m_DrawStyle = DrawStyle
    m_DrawWidth = DrawWidth
    m_ForeColor = ForeColor
    m_CreatePen
End Sub

'---------------------------------------------------------------------------------
Public Property Get FillColor() As OLE_COLOR
    FillColor = m_FillColor
End Property

Public Property Let FillColor(ByVal vNewValue As OLE_COLOR)
    m_FillColor = vNewValue
    m_CreateBrush
End Property

'---------------------------------------------------------------------------------
Public Property Get FillStyle() As Long
    FillStyle = m_FillStyle
End Property

Public Property Let FillStyle(ByVal vNewValue As Long)
    If vNewValue < 0 Then vNewValue = 0
    If vNewValue > 7 Then vNewValue = 7
    m_FillStyle = vNewValue
    m_CreateBrush
End Property

'---------------------------------------------------------------------------------
'EVENT HANDLERS
'---------------------------------------------------------------------------------
Private Sub Timer1_Timer()
Render
End Sub

Private Sub UserControl_Click()
     RaiseEvent Click
End Sub

Private Sub UserControl_DblClick()
    RaiseEvent DblClick
End Sub

Private Sub UserControl_EnterFocus()
RaiseEvent EnterFocus
End Sub

Private Sub UserControl_ExitFocus()
RaiseEvent ExitFocus
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, shift As Integer)
    RaiseEvent KeyDown(KeyCode, shift)
End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, shift As Integer)
    RaiseEvent KeyUp(KeyCode, shift)
End Sub

'---------------------------------------------------------------------------------
'If enabled, this checks for a selection
'---------------------------------------------------------------------------------
Private Sub UserControl_MouseDown(Button As Integer, shift As Integer, X As Single, Y As Single)
Const BUFSIZE = 1024
Dim selectBuf&(0 To BUFSIZE - 1)
Dim viewport&(0 To 3)
Dim items&()
    wglMakeCurrent m_hDC, m_hRC
    RaiseEvent MouseDown(Button, shift, X, Y)
    '
    If m_bAllowPick And Button = 1 Then
        glGetIntegerv GL_VIEWPORT, viewport(0)
        glSelectBuffer BUFSIZE, selectBuf(0)
        glRenderMode GL_SELECT
        glInitNames
        glPushName -1
        
        glMatrixMode GL_PROJECTION
        glPushMatrix
            glLoadIdentity
            gluPickMatrix X, viewport(3) - Y, 4, 4, viewport(0)
            'note:user may define view but must define the
            'camera to use picking
            'If m_bUseCamera Then
                'problem here. We assume the user is
                'returning true. No way to know what we need to know.
                Camera.SetProjection
            'End If
            m_RenderMode = 1
            glMatrixMode GL_MODELVIEW
            Render
            glFlush
            m_RenderMode = 0
        glMatrixMode GL_PROJECTION
        glPopMatrix
        '
        m_Hits = glRenderMode(GL_RENDER)
        Debug.Print "ocx pick:" & selectBuf(7)
        glMatrixMode GL_MODELVIEW
        RaiseEvent Pick(selectBuf)
    End If
    '
    m_MouseX = X
    m_MouseY = Y
    If m_MouseRotate Then
        Trackball.MouseDown Button, shift, X, Y
    End If
    If m_bAllowPick Then
        Render
    End If
End Sub

'---------------------------------------------------------------------------------
'Allows testing an arbitrary point for an object
'---------------------------------------------------------------------------------
Public Sub HitTest(X&, Y&)
Const BUFSIZE = 1024
Dim selectBuf&(0 To BUFSIZE - 1)
Dim viewport&(0 To 3)
Dim items&()
    wglMakeCurrent m_hDC, m_hRC
    'don't raise mouse event
    glGetIntegerv GL_VIEWPORT, viewport(0)
    glSelectBuffer BUFSIZE, selectBuf(0)
    glRenderMode GL_SELECT
    glInitNames
    glPushName -1
        
    glMatrixMode GL_PROJECTION
    glPushMatrix
        glLoadIdentity
        gluPickMatrix X, viewport(3) - Y, 4, 4, viewport(0)
        'note:assumes user is using the Camera!
            Camera.SetProjection
        m_RenderMode = 1
        glMatrixMode GL_MODELVIEW
        Render
        glFlush
        m_RenderMode = 0
    glMatrixMode GL_PROJECTION
    glPopMatrix
    '
    m_Hits = glRenderMode(GL_RENDER)
    glMatrixMode GL_MODELVIEW
    RaiseEvent Pick(selectBuf)
    '
    Render
End Sub

Private Sub UserControl_MouseMove(Button As Integer, shift As Integer, X As Single, Y As Single)
    m_MouseX = X
    m_MouseY = Y
    RaiseEvent MouseMove(Button, shift, X, Y)
    If m_MouseRotate Then
        wglMakeCurrent m_hDC, m_hRC
        Trackball.MouseMove Button, shift, X, Y
    End If
End Sub

Private Sub UserControl_MouseUp(Button As Integer, shift As Integer, X As Single, Y As Single)
    m_MouseX = X
    m_MouseY = Y
    RaiseEvent MouseUp(Button, shift, X, Y)
    If m_MouseRotate Then
        wglMakeCurrent m_hDC, m_hRC
        Trackball.MouseUp Button, shift, X, Y
    End If
End Sub

Private Sub UserControl_Paint()
    If m_Ready Then
        RaiseEvent Paint
    End If
End Sub

'---------------------------------------------------------------------------------
'If Camera is enabled, sets the viewport
'---------------------------------------------------------------------------------
Private Sub UserControl_Resize()
Dim W&, H&, Def As Boolean
    If m_Ready = False Then Exit Sub
    Debug.Print "UC_Resize"
    W = ScaleWidth
    H = ScaleHeight
    If H = 0 Then H = 1
    If W = 0 Then W = 1
On Error Resume Next
    wglMakeCurrent m_hDC, m_hRC
    'give w,h to trackball
    Trackball.Resize W, H
    'GetErr
    RaiseEvent Resize(W, H, Def)
    If m_bUseCamera Then Camera.OnSize W, H, Def
    If W <= m_Width And H <= m_Height Then
        UserControl_Paint
    End If
    m_Width = W: m_Height = H
    If m_UseMemDC Then
        'TODO - try to delay rendering till resize is done?
        'resize the DIB to match the window
        m_CreateDIB m_hDC, m_Width, m_Height
    End If
End Sub

'---------------------------------------------------------------------------------
'Initialize Properties for User Control
'---------------------------------------------------------------------------------
Private Sub UserControl_InitProperties()
    Debug.Print "UC_InitProperties"
    m_BackColor = m_def_BackColor
End Sub

'---------------------------------------------------------------------------------
'Load property values from storage
'---------------------------------------------------------------------------------
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Debug.Print "UC_ReadProperties"
    m_BackColor = PropBag.ReadProperty("BackColor", m_def_BackColor)
    'UserControl.BackColor = m_BackColor
    UserControl.BorderStyle = PropBag.ReadProperty("BorderStyle", 1)
    UserControl.MousePointer = PropBag.ReadProperty("MousePointer", 0)
    Set MouseIcon = PropBag.ReadProperty("MouseIcon", Nothing)
End Sub

'---------------------------------------------------------------------------------
'Write property values to storage
'---------------------------------------------------------------------------------
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("BackColor", m_BackColor, m_def_BackColor)
    Call PropBag.WriteProperty("BorderStyle", UserControl.BorderStyle, 1)
    Call PropBag.WriteProperty("MousePointer", UserControl.MousePointer, 0)
    Call PropBag.WriteProperty("MouseIcon", MouseIcon, Nothing)
End Sub

'---------------------------------------------------------------------------------
'Normally it clears the buffer, sets up the projection,fires Draw, then flushes
'and swaps buffers.
'At the very least, this routine calls wglMakeCurrent, fires Draw, calls glFlush.
'---------------------------------------------------------------------------------
Public Sub Render()
Static Busy As Boolean
Dim n&
On Error Resume Next
    If Not m_Ready Then Exit Sub 'resize events can cause Render to be called too soon
    If Busy Then Exit Sub
    Busy = True
    'GetErr
    wglMakeCurrent m_hDC, m_hRC
    'single buffer animations don't clear the screen
    'double-buffer can set the clear mode
    If m_DoubleBuffer Then
        Select Case m_ClearMode
        Case clrColor
            glClear clrColorBufferBit
        Case clrDepth
            glClear clrDepthBufferBit
        Case clrBoth
            glClear clrColorBufferBit Or clrDepthBufferBit
        End Select
    End If
    '
    'when picking, the view is set to a small area
    'If m_RenderMode = 0 Then
        'let glut apps set the frustrum
        If m_bUseCamera Then
            glLoadIdentity
            Camera.Update
        End If
    'End If
    '
    '
    RaiseEvent Draw
    glFlush
    If m_UseMemDC Then
        RaiseEvent DrawGDI
        BitBlt UserControl.hDC, 0, 0, m_Width, m_Height, m_hMemDC, 0, 0, SRCCOPY
    Else
        If m_DoubleBuffer Then SwapBuffers m_hDC
    End If
    Busy = False
    'GetErr
    'wglMakeCurrent 0, 0
End Sub

'---------------------------------------------------------------------------------
'set up the gl RC.
'This enables depth test, lighting, light0, sets clear color to dark grey, and
'initializes the Camera.
'---------------------------------------------------------------------------------
Public Sub Init()
Static bDoneOnce As Boolean
Dim r&
On Error Resume Next
    Debug.Print "UC_Init"
    '
    Randomize Timer ' Initialize randomizer
    RaiseEvent Init
    If Not m_SetupGL Then
        Debug.Assert 0
        Exit Sub
    End If
    '
    If bDoneOnce = 0 Then
        If Ambient.UserMode <> True Then
            Debug.Assert 0
        End If
        Set Ex = New glxUtility
        Set Font = New glxFont
        Set Shapes = New glxShapes
        Set Materials = New glxMaterials
        Set Camera = New glxCamera
        Set Trackball = New glxTrackball
        glClearColor 0.3, 0.3, 0.3, 1
        bDoneOnce = True
    End If
    'r = wglMakeCurrent(m_hDC, m_hRC)
    'If Not r Then
        'Debug.Assert 0
        'Debug.Print "Init: MakeCurrent failed."
        'r = GetLastError
    'End If
    'GetErr
    Set Lights = New glxLights
    'depth
    glClearDepth 1
    glEnable GL_DEPTH_TEST
    '
    'Trackball.Init 1
    'turn on the first light
    glEnable GL_LIGHTING
    With Lights(liLight0)
        .mode = lmDirectional
        .SetPosition 0, 100, 100
        .Enabled = True
    End With
    '
    RaiseEvent InitGL
    'force resize to set up view
    m_Ready = True
    UserControl_Resize
End Sub

'---------------------------------------------------------------------------------
' m_SetupGL
' Setup OpenGL. m_hDC is the DC which will be rendered to. At present, this can be
' the UC window or an offscreen memDC.
'---------------------------------------------------------------------------------
Private Function m_SetupGL() As Boolean
    Debug.Print "UC_m_SetupGL"
    'I'm assuning the hdc won't change.
    m_hDC = UserControl.hDC
    If m_UseMemDC Then
        If Not m_CreateMemDC(m_hDC, m_hMemDC, ScaleWidth, ScaleHeight) Then
            Debug.Assert 0
            Exit Function
        End If
        m_hDC = m_hMemDC
    End If
    If Not m_SetupPixelFormat(m_hDC) Then
        Debug.Print "SetupGL failed"
        Debug.Assert 0
        Exit Function
    End If
    ' Create a new rc
    If m_hRC Then
        wglDeleteContext m_hRC
    End If
    m_hRC = wglCreateContext(m_hDC)
    '
    If m_hRC Then
        wglMakeCurrent m_hDC, m_hRC
        Debug.Print "m_SetupGL: hrc=" & m_hRC
        Debug.Print " hwnd=" & hWnd
        m_SetupGL = True
        QueryGLVersion szVersion
    Else
        Debug.Assert 0
    End If
End Function

'---------------------------------------------------------------------------------
' Set up a Memory Device Context.
' Call this once at startup.
'---------------------------------------------------------------------------------
Private Function m_CreateMemDC(hDC&, hMemDC&, Width&, Height&) As Boolean
On Error GoTo EH
Dim flags&
    ' Create Compatible Memory Device Context
    hMemDC = CreateCompatibleDC(hDC)
    If hMemDC = 0 Then
        Debug.Print "Unable to create CompatibleDC."
        GoTo EH
    End If
    If Not m_CreateDIB(hMemDC, Width, Height) Then
        Debug.Print "CreateDIB failed"
        GoTo EH
    End If
    ' Set up a Pixel format for the DIB surface
    ' set needed flags. For now use whatever user sets.
    m_pfFlags = flags Or PFD_DRAW_TO_BITMAP Or PFD_SUPPORT_OPENGL Or PFD_SUPPORT_GDI
    SetBkMode hMemDC, 1   'Transparent
    'set up GDI stuff
    m_ForeColor = QBColor(15) 'white
    m_DrawWidth = 1
    m_FillStyle = 1  'default  transparent
    m_FillColor = QBColor(15)
    DrawStyle = psSolid 'cause pen to be created
    m_CreateMemDC = True
    Exit Function
EH:
    Debug.Assert 0
    m_ReleaseMemDC
    Exit Function
    Resume Next
End Function

'---------------------------------------------------------------------------------
' Create a DIB section
'---------------------------------------------------------------------------------
Private Function m_CreateDIB(hMemDC&, W&, H&) As Boolean
Dim bits() As Byte
Dim bpp&
Dim bfh As BITMAPFILEHEADER, bi As BITMAPINFO
Dim ptr&
Dim dwSizeImage&, s$
Dim hCurBmp&
    bpp = 24
    dwSizeImage = W * H * bpp / 8 ' i.e. 3
    ' set the pixel data in the pic
    bi.bmiHeader.biSize = Len(bi.bmiHeader)
    bi.bmiHeader.biWidth = W
    bi.bmiHeader.biHeight = H
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 24
    bi.bmiHeader.biCompression = BI_RGB
    bi.bmiHeader.biSizeImage = dwSizeImage
    bi.bmiHeader.biXPelsPerMeter = 2952
    bi.bmiHeader.biYPelsPerMeter = 2952
    'delete current BMP
    If m_hBmpOld Then
        hCurBmp = SelectObject(hMemDC, m_hBmpOld)
        DeleteObject hCurBmp
    End If
    ' Create a DIB surface
    m_hBmp = CreateDIBSection(UC.hDC, bi, DIB_RGB_COLORS, ptr, 0, 0)
    If m_hBmp Then
        ' Select the DIB Surface into the dc
        m_hBmpOld = SelectObject(hMemDC, m_hBmp)
        If m_hBmpOld = 0 Then
            Debug.Assert 0
        End If
        m_CreateDIB = True
    Else
        Debug.Print "CreateDIBSection Error"
        Debug.Assert 0
    End If
End Function

'-------------------------------------------------------------------------
' Choose pixel format according to supplied flags.  If gpfd is non-0,
' call DescribePixelFormat with it.
'-------------------------------------------------------------------------
Private Function m_SetupPixelFormat(hDC&) As Boolean
Dim PixelFormat&
    PixelFormat = m_ChoosePixelFormat(hDC)
    If PixelFormat Then
        If SetPixelFormat(hDC, PixelFormat, gPFD) Then
            DescribePixelFormat hDC, PixelFormat, _
                            Len(gPFD), gPFD
            m_SetupPixelFormat = True
            Palette.Init hDC
        End If
    Else
        Debug.Assert 0
        Debug.Print "ChoosePixelFormat failed"
        Exit Function
    End If
End Function


'-------------------------------------------------------------------------
' Choose pixel format based on flags.
'-------------------------------------------------------------------------
Private Function m_ChoosePixelFormat&(hDC&)
Dim MaxPFDs&, iBest&, r&
Dim cColorBits&, bDoubleBuf As Boolean
Dim cDepthBits&, i&
Dim s$
Dim flags&
Dim cb As Byte
    If m_pfPixelType = PFD_TYPE_COLORINDEX Then
        cb = 8
    Else
        cb = 24
    End If
    gPFD.nSize = Len(gPFD)
    gPFD.nVersion = 1
    gPFD.dwFlags = m_pfFlags
    gPFD.iPixelType = m_pfPixelType
    gPFD.cColorBits = cb
    gPFD.cDepthBits = m_depthType
    gPFD.iLayerType = PFD_MAIN_PLANE
    r = ChoosePixelFormat(hDC, gPFD)
    If r = 0 Then
        Debug.Print "ChoosePixelFormat failed"
        Exit Function
    End If
    m_ChoosePixelFormat = r
    Exit Function
End Function

'---------------------------------------------------------------------------------
'ROUTINES TO CREATE OBJECTS
'---------------------------------------------------------------------------------
Public Function NewMaterial() As glxMaterial
Set NewMaterial = New glxMaterial
End Function

Public Function NewImage() As glxImage
Set NewImage = New glxImage
End Function

Public Function NewTexture() As glxTexture
Set NewTexture = New glxTexture
End Function

Public Function NewPolyCylinder() As glePolyCylinder
Set NewPolyCylinder = New glePolyCylinder
End Function

Public Function NewPolyCone() As glePolyCone
Set NewPolyCone = New glePolyCone
End Function

Public Function NewExtrusion() As gleExtrusion
Set NewExtrusion = New gleExtrusion
End Function

Public Function NewTwist() As gleTwistExtrusion
Set NewTwist = New gleTwistExtrusion
End Function

Public Function NewLathe() As gleLathe
Set NewLathe = New gleLathe
End Function

Public Function NewHelicoid() As gleHelicoid
Set NewHelicoid = New gleHelicoid
End Function

Public Function NewScrew() As gleScrew
Set NewScrew = New gleScrew
End Function

Public Function NewSpiral() As gleSpiral
Set NewSpiral = New gleSpiral
End Function

Public Function NewSuperExtrusion() As gleSuperExtrusion
Set NewSuperExtrusion = New gleSuperExtrusion
End Function

Public Function NewToroid() As gleToroid
Set NewToroid = New gleToroid
End Function

Public Function NewDissolve() As glxDigitalDissolve
Set NewDissolve = New glxDigitalDissolve
End Function

Public Function NewMesh() As glxMesh
Set NewMesh = New glxMesh
End Function

Public Function NewCurve() As glxCurve
Set NewCurve = New glxCurve
End Function

'---------------------------------------------------------------------------------
'METHODS
'---------------------------------------------------------------------------------

'---------------------------------------------------------------------------------
Public Sub DrawGrids()
    glPushMatrix
        glCallList WORLD_LIST
    glPopMatrix
End Sub

'---------------------------------------------------------------------------------
Public Sub MakeCurrent()
wglMakeCurrent m_hDC, m_hRC
End Sub

'---------------------------------------------------------------------------------
' Find out what GL version is being loaded.  If it's 1.1, set various
' global capabilities.
'---------------------------------------------------------------------------------
Public Function QueryGLVersion$(str As glStringNameConstants)
Dim p&, s$
Select Case str
    Case szVendor
        p = glGetString(szVendor)
    Case szRenderer
        p = glGetString(szRenderer)
    Case szExtensions
        p = glGetString(szExtensions)
    Case GL_VERSION
        p = glGetString(GL_VERSION)
    Case Else: Exit Function
    End Select
    s = GetGLString(p)
    '
    QueryGLVersion = s
    If str = szVersion Then
        If (InStr(s, "1.1")) Then
            gbGLv1_1 = True
        Else
            gbGLv1_1 = False
        End If
    End If
End Function

Public Property Get GLv1_1() As Boolean
GLv1_1 = gbGLv1_1
End Property

'---------------------------------------------------------------------------------
Public Function GetErr$(Optional ByRef n&)
Dim s$, t$, glErr&
    glErr = glGetError()
    If glErr = GL_NO_ERROR Then Exit Function
    s = "glError:" & glErr & vbCrLf
    If glErr Then
    Select Case glErr
    Case GL_NO_ERROR
    'An unacceptable value is specified for an enumerated argument.
    'The offending function is ignored, having no side effect other than to set the error flag.
    Case GL_INVALID_ENUM: t = "GL_INVALID_ENUM"
    'A numeric argument is out of range. The offending function is
    'ignored, having no side effect other than to set the error flag.
    Case GL_INVALID_VALUE: t = "GL_INVALID_VALUE"
    'The specified operation is not allowed in the current state. The offending
    'function is ignored, having no side effect other than to set the error flag.
    Case GL_INVALID_OPERATION: t = "GL_INVALID_OPERATION"
    'This function would cause a stack overflow. The offending function
    'is ignored, having no side effect other than to set the error flag.
    Case GL_STACK_OVERFLOW: t = "GL_STACK_OVERFLOW"
    'This function would cause a stack underflow. The offending function
    'is ignored, having no side effect other than to set the error flag.
    Case GL_STACK_UNDERFLOW: t = "GL_STACK_UNDERFLOW"
    'There is not enough memory left to execute the function. The state of OpenGL
    'is undefined, except for the state of the error flags, after this error is recorded.
    Case GL_OUT_OF_MEMORY: t = "GL_OUT_OF_MEMORY"
    Case Else: Debug.Assert 0
    End Select
    s = s & t
    Debug.Print s
    Debug.Assert 0
    GetErr$ = s
    n = glErr
    End If
End Function

'------------------------------------------------------------------------------------
Public Function Dump$(state As glxGLStates)
Select Case state
Case glsCurrentValues: Dump = DumpCurrent
Case glsEnabled: Dump = DumpEnabled
Case glsLighting: Dump = DumpLighting
Case glsLights: Dump = DumpLights
Case glsRaster: Dump = DumpRaster
Case glsTexture: Dump = DumpTexture
Case glsGLMatrix: Dump = DumpGLMatrix
End Select
End Function

'---------------------------------------------------------------------------------
' GDI DRAWING ROUTINES
'---------------------------------------------------------------------------------
Public Sub GDILine(ByVal x1 As Long, ByVal y1 As Long, ByVal x2 As Long, ByVal y2 As Long)
    MoveToEx m_hMemDC, x1, y1, ByVal 0&
    LineTo m_hMemDC, x2, y2
End Sub

Public Sub GDICircle(ByVal X As Long, ByVal Y As Long, ByVal r As Long)
    Chord m_hMemDC, X - r, Y - r, X + r, Y + r, X + r, Y, X + r, Y
End Sub

Public Sub GDIText(ByVal X As Long, ByVal Y As Long, Text As String)
    TextOut m_hMemDC, X, Y, Text, Len(Text)
End Sub


'---------------------------------------------------------------------------------
' PRIVATE UTILITY ROUTINES FOR GDI
'---------------------------------------------------------------------------------
    
'---------------------------------------------------------------------------------
'create a pen using current properties
'---------------------------------------------------------------------------------
Private Function m_CreatePen&()
Dim locPen As Long
    SetTextColor m_hMemDC, m_ForeColor
    locPen = CreatePen(m_DrawStyle, m_DrawWidth, m_ForeColor)
    Debug.Assert (locPen <> 0)
    If m_OldPen = 0 Then
        'store oldpen only the first time (default-Pen of DC)
        m_OldPen = SelectObject(m_hMemDC, locPen)
    Else
        SelectObject m_hMemDC, locPen
        DeleteObject m_CurPen
    End If
    m_CurPen = locPen
End Function

'---------------------------------------------------------------------------------
'create a pen using current properties
'---------------------------------------------------------------------------------
Private Sub m_CreateBrush()
Dim locBrush As Long
Dim logbr As LOGBRUSH
    logbr.lbColor = m_FillColor
    Select Case m_FillStyle
    Case 0: logbr.lbStyle = BS_SOLID
    Case 1: logbr.lbStyle = BS_NULL
    Case Else: logbr.lbStyle = BS_HATCHED
    End Select
    
    If m_FillStyle > 2 Then
        logbr.lbHatch = m_FillStyle - 2
    Else
        logbr.lbHatch = 0
    End If
    locBrush = CreateBrushIndirect(logbr)
    Debug.Assert (locBrush <> 0)
    If m_OldBrush = 0 Then
        'store oldBrush only the first time (default-Brush of DC)
        m_OldBrush = SelectObject(m_hMemDC, locBrush)
    Else
        SelectObject m_hMemDC, locBrush
        DeleteObject m_CurBrush
    End If
       
    m_CurBrush = locBrush
End Sub

