VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3dLists"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'*************************************************************************\
'FUNCTION:
'this class maintains a collection of strings
'each string object has:
'   - a 'key' - the category to which the string belongs
'   - a string - the string which be displayed
'given a category string, the ss will cycle the strings of that
'category when in 'vstring' mode
'
'note: reading strings from file or input is not supported
'   - the code actually cycles through the random texts, but
'   - you can rig up an input system if you want
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'*************************************************************************\
Private mCol As Collection

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub

Public Function Add(pszStr$, Optional sKey As String) As C3dList
Dim plist As C3dList
    Set plist = New C3dList
    '
    plist.pszStr = pszStr
    plist.sKey = sKey
    mCol.Add plist
    'return the object created
    Set Add = plist
    Set plist = Nothing
End Function

Public Property Get Item(vntIndexKey As Variant) As C3dList
Attribute Item.VB_UserMemId = 0
  Set Item = mCol(vntIndexKey)
End Property

Public Property Get count() As Long
    count = mCol.count
End Property

Public Sub Remove(vntIndexKey As Variant)
    mCol.Remove vntIndexKey
End Sub

Public Property Get NewEnum() As IUnknown
    Set NewEnum = mCol.[_NewEnum]
End Property

Public Sub Clear()
Dim i&
    For i = 1 To mCol.count
        mCol.Remove 1
    Next
End Sub

Public Sub CreateRandomList()
    Add "OpenGL"
    Add "#2@-E+\"
    Add "AaBbCc"
    Add Chr$(34) & Chr$(10) & Chr$(32) & "-" & Chr$(32) & Chr$(200) & Chr$(34)
    Add "When the night", "songs"
    Add "Umm dabba dabba dabba", "songs"
    Add "telephart", "science"
    Add "diffraction", "science"
End Sub

'*************************************************************************\
'* VerifyString
'* Validate the string
'* A string can be checked against a list of 'key strings' in an ascii file.
'* If there is a match between the user inputted string and one of these key
'* strings, then the display mode is enhanced to show a random list of 'item
'* strings' that follow the key string in the file.  To point the screen saver
'* at such a file, put the filename in the registry key entry "magic" / "file", under
'* the registry setting group for the text3d screen saver.  The file format is
'* as follows:
'*
'* -key0
'* item0
'* item1
'*  ...
'* itemn
'* -key1
'*  ...
'*
'* For example:
'* -color
'* red
'* green
'* -animal
'* dog
'* cat
'*
'edx: modified to check the current 'optText' for a '-', indicating that the text
'is the key for a set of strings to display. Then checks to see if any strings
'have this key.
'*************************************************************************/
Public Function IsaKeyString() As Boolean
Dim szKey$, nMatch&
Dim i&, l As C3dList
    If Left$(optText, 1) = "-" Then
        szKey = Trim$(Mid$(optText, 2))
        For i = 1 To mCol.count
            Set l = mCol(i)
            If l.sKey = szKey Then
                nMatch = 1
                Exit For
            End If
        Next
    End If
    If nMatch Then
        ' put first string in gac.optText
        optDemoType = DEMO_VSTRING
        ' for now, initialize strings here
        g3D.UpdateString False
        ' adjust cycle time based on optRotationStyle
        Select Case optRotationStyle
            Case ROTSTYLE_NONE:
                g3D.CycleTime = 4
            Case ROTSTYLE_SEESAW:
                g3D.CycleTime = 8
            Case ROTSTYLE_RANDOM:
                g3D.CycleTime = 10
            'default:
            Case Else
                g3D.CycleTime = 9
        End Select
        IsaKeyString = True
    End If
End Function



