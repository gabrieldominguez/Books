VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CExplode"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'/******************************Module*Header******************************
'* Module Name: genexpld.c
'FUNCTION:
'* The Explode style of the 3D Flying Objects screen saver.
'* Simulation of a sphere that occasionally explodes.
'* Copyright (c) 1994 Microsoft Corporation
'
'this module does not use Material or Camera objects of the ocx.
'these are managed by direct calls to OpenGL
'
'note that the 'UseCamera' property is set to false in init
'
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************
'
Const RADIUS = 0.3
Const NUMSTEPS = 30
Const MAXPREC = 20
' Data type accepted by glInterleavedArrays
Dim faceMat() As MATRIX
Dim xstep!()
Dim ystep!()
Dim zstep!()
Dim xrot!()
Dim yrot!()
Dim zrot!()
Dim explodeMesh As glxMesh
Dim iPrec&
Dim bOpenGL11 As Boolean
'
Dim pN3V3() As POINT_N3F_V3F
'
Dim matl1Diffuse!(0 To 3) '
Dim matl2Diffuse!(0 To 3) '
Dim matlSpecular!(0 To 3) '
Dim light0Pos!(0 To 3) '
'
Dim myrotInc# '
Dim direction& '
Dim spinDelta! '

Private Sub Class_Initialize()
iPrec = 10
myrotInc = 0.1
direction& = 1
spinDelta! = 5
gCtl.Ex.FillArrayf matl1Diffuse, 1, 0.8, 0, 1
gCtl.Ex.FillArrayf matl2Diffuse, 0.8, 0.8, 0.8, 1
gCtl.Ex.FillArrayf matlSpecular, 1, 1, 1, 1
gCtl.Ex.FillArrayf light0Pos, 100, 100, 100, 0
Set explodeMesh = gCtl.NewMesh
End Sub

Private Sub Class_Terminate()
    Set explodeMesh = Nothing
End Sub

Public Sub InitExplodeScene()
    iPrec = optTesselFact * 10.5
    If (iPrec < 5) Then iPrec = 5
    If (iPrec > MAXPREC) Then iPrec = MAXPREC
    ReDim faceMat(iPrec * iPrec)
    ReDim xstep(iPrec * iPrec)
    ReDim ystep(iPrec * iPrec)
    ReDim zstep(iPrec * iPrec)
    ReDim xrot(iPrec * iPrec)
    ReDim yrot(iPrec * iPrec)
    ReDim zrot(iPrec * iPrec)
    m_genExplode
    ' Find out the OpenGL version that we are running on.
    bOpenGL11 = gCtl.GLv1_1
    ' Setup the data arrays.
    ReDim pN3V3(0 To (explodeMesh.NumFaces * 4) - 1)
    ' If we are running on OpenGL 1.1, use the new vertex array functions.
    If bOpenGL11 Then
        glInterleavedArrays GL_N3F_V3F, 0, pN3V3(0)
    End If
    glMaterialfv GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matl1Diffuse(0)
    glMaterialfv GL_FRONT, GL_SPECULAR, matlSpecular(0)
    glMaterialf GL_FRONT, GL_SHININESS, 100
    glMaterialfv GL_BACK, GL_AMBIENT_AND_DIFFUSE, matl2Diffuse(0)
    glMaterialfv GL_BACK, GL_SPECULAR, matlSpecular(0)
    glMaterialf GL_BACK, GL_SHININESS, 60
    'glMatrixMode GL_PROJECTION
    'glLoadIdentity
    'gluPerspective 30, 1, 0.1, 10
    'glTranslatef 0, 0, 30
    With gCtl.Camera
        .SetEyePos 0, 0, 3
    End With
End Sub

Private Sub m_genExplode()
Dim i&
Dim circ!(0 To MAXPREC, 0 To 2)
Dim angle#
Dim step# ' = -PI / (iPrec - 1);
Dim start# ' = PI / 2.0;
    step = -PI / (iPrec - 1)
    start = PI / 2
    angle = start
    For i = 0 To iPrec - 1 '; i++, angle += step) {
        circ(i, 0) = RADIUS * Cos(angle)
        circ(i, 1) = RADIUS * Sin(angle)
        circ(i, 2) = 0
        angle = angle + step
    Next
    explodeMesh.RevolveSurface circ, iPrec

    For i = 0 To explodeMesh.NumFaces - 1 '; i++) {
        ss_matrixIdent faceMat(i)
        xstep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
        ystep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
        zstep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
        xrot(i) = 0
        yrot(i) = 0
        zrot(i) = 0
    Next
End Sub


Public Sub UpdateExplodeScene(flags&)
Static mxrot#
Static myrot#
Static mzrot#
Static mxrotInc#
Static mzrotInc#
Static maxR!
Static r!
Static rotZ!
Static count&
Static restCount&
Static lightSpin!
Static h&
Static Color!(0 To 3)
Dim i&, a&, b&, c&, d&, j&, k&, m&
Dim vector!(0 To 2)
    mxrot = mxrot + mxrotInc
    myrot = myrot + myrotInc
    mzrot = mzrot + mzrotInc
    If optColorCycle Or h = 0 Then
        gCtl.Ex.HSVtoRGB CSng(h), 1, 1, Color
        glMaterialfv GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Color(0)
        h = h + 1
        h = h Mod 360
    End If
    glMatrixMode GL_MODELVIEW
    glPushMatrix
    glRotatef -lightSpin, 0, 1, 0
    glLightfv GL_LIGHT0, GL_POSITION, light0Pos(0)
    lightSpin = lightSpin + spinDelta
    If lightSpin > 90 Or lightSpin < 0 Then
        spinDelta = -spinDelta
    End If
    glPopMatrix
    If bOpenGL11 = False Then
        glBegin GL_QUADS
    End If
    With explodeMesh
    'pn3v3 = pN3V3
    For i = 0 To explodeMesh.NumFaces - 1
    'i++, faces++, pn3v3 += 4
        ss_matrixIdent faceMat(i)
        ss_matrixRotate faceMat(i), CDbl(xrot(i)), CDbl(yrot(i)), CDbl(zrot(i))
        If restCount Then
        Else
            xrot(i) = xrot(i) + (xstep(i))
            yrot(i) = yrot(i) + ystep(i)
            zrot(i) = zrot(i) + (zstep(i))
        End If
        a = .pA(i)
        b = .pB(i)
        c = .pD(i)
        d = .pC(i)
        
        .CopyVertex a, pN3V3(k).vertex ', (explodeMesh.pts + a), sizeof(POINT3D));
        .CopyVertex b, pN3V3(k + 1).vertex ', (explodeMesh.pts + b), sizeof(POINT3D));
        .CopyVertex c, pN3V3(k + 2).vertex ', (explodeMesh.pts + c), sizeof(POINT3D));
        .CopyVertex d, pN3V3(k + 3).vertex ', (explodeMesh.pts + d), sizeof(POINT3D));

        vector(0) = pN3V3(k).vertex(0)
        vector(1) = pN3V3(k).vertex(1)
        vector(2) = pN3V3(k).vertex(2)

        For j = 0 To 3
            pN3V3(k + j).vertex(0) = pN3V3(k + j).vertex(0) - vector(0)
            pN3V3(k + j).vertex(1) = pN3V3(k + j).vertex(1) - vector(1)
            pN3V3(k + j).vertex(2) = pN3V3(k + j).vertex(2) - vector(2)
            ss_xformPoint pN3V3(k + j).vertex, pN3V3(k + j).vertex, faceMat(i)
            pN3V3(k + j).vertex(0) = pN3V3(k + j).vertex(0) + vector(0) + (vector(0) * r)
            pN3V3(k + j).vertex(1) = pN3V3(k + j).vertex(1) + vector(1) + (vector(1) * r)
            pN3V3(k + j).vertex(2) = pN3V3(k + j).vertex(2) + vector(2) + (vector(2) * r)
        Next
        If optSmoothShading Then
            .CopyNormal a, pN3V3(k).Normal ', (explodeMesh.norms + a), sizeof(POINT3D));
            .CopyNormal b, pN3V3(k + 1).Normal ', (explodeMesh.norms + b), sizeof(POINT3D));
            .CopyNormal c, pN3V3(k + 2).Normal ', (explodeMesh.norms + c), sizeof(POINT3D));
            .CopyNormal d, pN3V3(k + 3).Normal ', (explodeMesh.norms + d), sizeof(POINT3D));
            For j = 0 To 3 '; j < 4; j++
                ss_xformNorm pN3V3(j).Normal, pN3V3(j).Normal, faceMat(i)
            Next
        Else
            .CopyFaceNormal i, pN3V3(0).Normal
            ss_xformNorm pN3V3(0).Normal, pN3V3(0).Normal, faceMat(i)
            For m = 1 To 3
                pN3V3(k + m).Normal(0) = pN3V3(k).Normal(0)
                pN3V3(k + m).Normal(1) = pN3V3(k).Normal(1)
                pN3V3(k + m).Normal(2) = pN3V3(k).Normal(2)
            Next
        End If

        If bOpenGL11 = False Then
            If optSmoothShading Then
                glNormal3fv pN3V3(k).Normal(0)
                glVertex3fv pN3V3(k).vertex(0)
                glNormal3fv pN3V3(k + 1).Normal(0)
                glVertex3fv pN3V3(k + 1).vertex(0)
                glNormal3fv pN3V3(k + 2).Normal(0)
                glVertex3fv pN3V3(k + 2).vertex(0)
                glNormal3fv pN3V3(k + 3).Normal(0)
                glVertex3fv pN3V3(k + 3).vertex(0)
            Else
                glNormal3fv pN3V3(k).Normal(0)
                glVertex3fv pN3V3(k).vertex(0)
                glVertex3fv pN3V3(k + 1).vertex(0)
                glVertex3fv pN3V3(k + 2).vertex(0)
                glVertex3fv pN3V3(k + 3).vertex(0)
            End If
        End If
        k = k + 4
    Next
    If bOpenGL11 Then
        glDrawArrays GL_QUADS, 0, explodeMesh.NumFaces * 4
    Else
        glEnd
    End If
    If restCount Then
        restCount = restCount - 1
        GoTo resting
    End If
    If direction Then
        maxR = r
        r = r + (0.3 * ((NUMSTEPS - count) / NUMSTEPS) ^ 4)
    Else
        r = r - (maxR / (NUMSTEPS))
    End If

    count = count + 1
    If count > NUMSTEPS Then
        direction = direction Xor 1
        count = 0

        If direction = 1 Then
            restCount = 10
            r = 0
            For i = 0 To explodeMesh.NumFaces - 1 '; i++) {
                ss_matrixIdent faceMat(i)
                xstep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
                ystep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
                zstep(i) = (((Rnd() And &H3) * PI) / (NUMSTEPS + 1))
                xrot(i) = 0
                yrot(i) = 0
                zrot(i) = 0
            Next
        End If
    End If
resting:
End With
End Sub


