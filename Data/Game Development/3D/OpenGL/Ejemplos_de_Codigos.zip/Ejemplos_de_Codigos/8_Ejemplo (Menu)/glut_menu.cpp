//--------------------------------------------------------------
// Demostraci�n de uno de Men� con GLUT
// Basado en el ejemplo "glut_menu" de Roman Podobedov
//
// Objetivo: Construcci�n de men�es
//           Mostrar texto en ventana gr�fica
//           Captura de teclado
//
// Computaci�n II
// Daniel, 18/Setiembre/2001
//--------------------------------------------------------------

#include <iostream>
#include <stdlib.h>
#include <GL/glut.h>

int WindW, WindH;
int submenu1, submenu2;

void dibujar_string_bitmap(void *font, const char* string)
{ // se transforma caracter a caracter
  while (*string){
    glutBitmapCharacter(font, *string);
    *string++;
  }
}

void RefrescarPantalla(int width, int height)
{
  glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(-1, 1, -1, 1);
  glMatrixMode(GL_MODELVIEW);

  WindW = width;
  WindH = height;
}

void Dibujar(void)
{
  glClear(GL_COLOR_BUFFER_BIT);

  glColor3f(1.0f, 1.0f, 1.0f);
  glRasterPos2f(-0.95f, 0);

  // Llamado a "dibujar" el texto
  dibujar_string_bitmap(GLUT_BITMAP_TIMES_ROMAN_24,
                        "Pulsar boton derecho del mouse");

  glutSwapBuffers();   // realiza un impl�cito glFlush()
}

static void TeclaPulsada(unsigned char key, int x, int y)
{ // key es el valor ASCII de la tecla pulsada
  // x e y indica la posici�n del mouse.
  // Pasando NULL desabilita la generaci�n de llamado a esta funci�n por
  // eventos del teclado.
  switch (key)
  {
    case 27: exit(0);
             break;
  }
}

void select1(int eleccion)
{ //Selecci�n por submenu 1
  switch (eleccion)
  {
    case 1:
      cout << "Submenu1: #1" << endl;
      break;
    case 2:
      cout << "Submenu1: #2" << endl;
      break;
  }
}

void select2(int eleccion)
{ // Selecci�n por submenu 2
  switch (eleccion)
  {
    case 1:
      cout << "Submenu2: #1" << endl;
      break;
    case 2:
      cout << "Submenu2: #2" << endl;
      break;
  }
}

void main_menu(int value)
{ // Seleccion menu principal
  switch (value) {
  case 1:
    exit(0);
    break;
  }
}

int main(int argc, char *argv[])
{
  WindW = 400;
  WindH = 300;

  cout << "Demostraci�n de Men�es con GLUT" << endl;
  cout << "Computaci�n II" << endl;

  glutInit(&argc, argv);
  glutInitWindowSize(WindW, WindH);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  (void)glutCreateWindow("Demostracion de Menu");

  glutReshapeFunc(RefrescarPantalla);
  glutDisplayFunc(Dibujar);

  glClearColor(0, 0, 0, 0);

  // Comunica que funci�n va a atender eventos del teclado
  glutKeyboardFunc(TeclaPulsada);

  /* Creaci�n de Menues */
  /* Creacion submenu 1 */
  submenu1 = glutCreateMenu(select1);
  glutAddMenuEntry("#1", 1);
  glutAddMenuEntry("#2", 2);

  /* Creacion submenu 2 */
  submenu2 = glutCreateMenu(select2);
  glutAddMenuEntry("#1", 1);
  glutAddMenuEntry("#2", 2);

  /* Creacion menu principal*/
  glutCreateMenu(main_menu);
  glutAddSubMenu("Submenu 1", submenu1);
  glutAddSubMenu("Submenu 2", submenu2);
  glutAddMenuEntry("Quit", 1);

  // enlaza boton del mouse con el llamado al menu
  glutAttachMenu(GLUT_RIGHT_BUTTON);

  glutMainLoop();

  return 0;
}


// TIPOS DE LETRAS =============================================================
// GLUT BITMAP_8_BY_13
// GLUT BITMAP_9_BY_15
// GLUT BITMAP_TIMES_ROMAN_10
// GLUT BITMAP_TIMES_ROMAN_24
// GLUT BITMAP_HELVETICA_10
// GLUT BITMAP_HELVETICA_12
// GLUT BITMAP_HELVETICA_18

// BOTONES PARA LLAMAR A MENUES ================================================
// GLUT_LEFT_BUTTON - GLUT_MIDDLE_BUTTON - GLUT_RIGHT_BUTTON



