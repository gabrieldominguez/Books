Attribute VB_Name = "mMain"
Option Explicit

'/******************************Module*Header******************************
'FUNCTION: manages startup events
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************
'last minute note: the 'Explode' sample used to have color
'on the ourside of the ball - don't know what happened.
'
Public gCtl As glxCtl
Public g3DFO As C3dFO
Public Texture As glxTexture
' Global screen saver settings.
Public optColorCycle As Boolean    ' color cycling flag
Public optSmoothShading As Boolean ' smooth shading flag
Public optTesselFact!          ' object tessalation
Public optSize&                  ' object size
Public optType                 ' screen saver index (into function arrays)
Public optTextureFile$
Public Material(0 To 15) As glxMaterial
Public gbTextureLoaded As Boolean

'the order of creation is important. The ocx must be created
'before any of its functions or the gl functions can be called
Public Sub Main()
If App.PrevInstance Then End
If DoConfigure Then
    Set g3DFO = New C3dFO
    Load frm3dFO
    g3DFO.Init
    Set gCtl = frm3dFO.glxCtl1
    gCtl.Init
    'g3DFO.InitGL
    frm3dFO.Show
    gCtl.Animate = True
Else
    End
End If
End Sub

'/******************************Public*Routine*****************************
'* initMaterial
'* Initialize the material properties.
'\*************************************************************************
Public Sub InitMaterial(id&, r!, g!, b!)
    Material(id).SetAmbient r, g, b
    Material(id).SetDiffuse r, g, b
    Material(id).SetSpecular 1, 1, 1
    Material(id).SpecExp = 128
End Sub


