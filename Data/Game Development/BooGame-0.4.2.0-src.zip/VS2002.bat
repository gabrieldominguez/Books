@rem Generates a solution (.sln) and a set of project files (.csproj) 
@rem for Microsoft Visual Studio .NET 2002
.\tools\Prebuild\Prebuild.exe /target vs2002 /file Prebuild.xml
