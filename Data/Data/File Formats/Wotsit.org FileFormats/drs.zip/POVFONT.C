#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> /* for {s,g}et{u,g}id */
#include <string.h>

#include <vga.h>

#include "wpfonts.h"
#include "device.h"

int 
help(char* name)                                                          
{                                                                       
  printf("Usage: %s [-n<fontnr>] [-s<string>] [-o<file>]\n",name);
  printf("       makes a PoVRay string\n");  
  return 1;
}

extern device dev_text,dev_graphic,dev_pov;

int
main(int argc, char* argv[])
{
  device* output;
  font_file* ff;
  font_struct* fs;
  int number;
  char* string;
  int x,y;
  int i;

  /* defaults */
  number=0;
  string="PoVRay";
  output=&dev_pov;

  /* command line processing */
  if (argc==1) 
    return help(argv[0]);

  /* determine output device */
  for(i=1;i<argc;i++)
  {
    if (strncmp(argv[i],"-pov",4)==0) { output=&dev_pov; continue; }
    if (strncmp(argv[i],"-txt",4)==0) { output=&dev_text; continue; }
    if (strncmp(argv[i],"-vga",2)==0) { output=&dev_graphic; continue; }
  }
  dev_init(output);


  while (--argc>0)
  {
    if (sscanf(argv[argc],"-n%d",&number)>0) continue;
    if (strncmp(argv[argc],"-s",2)==0) { string=argv[argc]+2; continue; }

    if (sscanf(argv[argc],"-xsc%f",&output->xscale)>0) continue;
    if (sscanf(argv[argc],"-ysc%f",&output->yscale)>0) continue;
    if (sscanf(argv[argc],"-zsc%f",&output->zscale)>0) continue;
    if (sscanf(argv[argc],"-rsc%f",&output->rscale)>0) continue;

    if (strncmp(argv[argc],"-o",2)==0) 
    { output->fp=fopen(argv[argc]+2,"wt"); 
      if (output->fp==NULL)
      {
	fprintf(stdout,"Cannot create output file %s\n",argv[argc]+2);
	return help(argv[0]);
      }
      continue; 
    }
  }

  if (output!=&dev_graphic)
  {
    setuid(getuid());       /* Don't need supervisor rights anymore. */
    setgid(getgid());
  }

  /* open fontfile */
  ff=wp_init_fonts(WP_FONTFILE);
  if (ff==NULL)
  {
    fprintf(stdout,"error opening fontfile\n");
    goto no_file;
  }
  printf("// Selected font=%s\n",
	 &ff->file_names[ff->file_index[number].offset+1]);

  /* load font */
  fs=wp_load_font(ff,number);
  if (ff==NULL) 
  { 
    printf("error acessing font\n");
    goto no_font;
  }

  if (fs->desc.type!=WP_OUTLINE)
  {
    printf("font is bitmapped\n");
    goto no_font;
  }

  /* do it */
  x=0;
  y=0;
 
  output->init(output);

  wp_draw_string(fs,output,x,y,string);

  output->getch(output);
  output->exit(output);
  fclose(output->fp);

  /* clean up */
 no_font:
  wp_dispose_font(fs);
 no_file:
  wp_exit_fonts(ff);
  return 0;
}
