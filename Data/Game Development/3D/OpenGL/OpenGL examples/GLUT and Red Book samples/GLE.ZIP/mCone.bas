Attribute VB_Name = "mCone"
Option Explicit
''
' * cone drawing demo
' *
' * FUNCTION:
' * Baisc demo illustrating how to write code to draw
' * the most basic cone shape.
' *
' * HISTORY:
' * Linas Vepstas March 1995
' */
'

Public IDCone&
Public gleCone As glePolyCone
Const NPTS = 6
'
' * Initialize a bent shape with three segments.
' * The data format is a polyline.
' *
' * NOTE that neither the first, nor the last segment are drawn.
' * The first & last segment serve only to determine that angle
' * at which the endcaps are drawn.
' */
Public Sub InitCones()
    Set gleCone = gCtl.NewPolyCone
    ' initialize the join style here */
    With gleCone
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureMode = CX.TextureStyle
        .TextureEnabled = CX.TextureEnabled
        .NumPoints = NPTS
        .NUMCOLORS = NPTS
        .NumRadiusPts = NPTS
        
        .radius(0) = 1
        .SetColor 0, 0, 0, 0
        .SetPt 0, -6, 6, 0
        
        .radius(1) = 1
        .SetColor 1, 0, 0.8, 0.3
        .SetPt 1, 6, 6, 0
        
        .radius(2) = 3
        .SetColor 2, 0.8, 0.3, 0
        .SetPt 2, 6, -6, 0
        
        .radius(3) = 0.5
        .SetColor 3, 0.2, 0.3, 0.9
        .SetPt 3, -6, -6, 0
        
        .radius(4) = 2
        .SetColor 4, 0.2, 0.8, 0.5
        .SetPt 4, -6, 6, 0
        
        .radius(5) = 1
        .SetColor 5, 0, 0, 0
        .SetPt 5, 6, 6, 0
    
        IDCone = glGenLists(1)
        glNewList IDCone, lstCompile
        DrawCone
        glEndList
    End With
End Sub


' draw the polycone shape */
Public Sub DrawCone()
   ' Phew. FINALLY, Draw the polycone  -- */
   'glePolyCone gc 'idx, POINTS, colors, radii
    glPushMatrix
    gleCone.Draw
    glPopMatrix
End Sub

' --------------------------- end of file ------------------- */

