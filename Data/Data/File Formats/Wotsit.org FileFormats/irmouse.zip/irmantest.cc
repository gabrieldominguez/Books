#include "irman.h"
#include <sys/time.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

main () {
  IRMouse vm;
  int vmfileno;
  fd_set readfds;
  int lastfd;
  struct termios termstat;
  struct termios newtermstat;

  fprintf(stderr,"AST IRMouse test application\n");
  fprintf(stderr,"Press buttons on IR Mouse to test or hit any key to exit\n");

  tcgetattr(0,&termstat);	// save terminal attributes
  tcgetattr(0,&newtermstat);	// get a copy of attributes to play with
  tcflush(0,TCIFLUSH);		// flush all extra input

  vmfileno=vm.fileno();		// get fileno to select on

  while (1) {
    lastfd=0;			// setup readfds and lastfd for select
    FD_ZERO(&readfds);
    FD_SET(vmfileno,&readfds);
    FD_SET(0,&readfds);
    if (lastfd<vmfileno) lastfd=vmfileno;

    cfmakeraw(&newtermstat);	// put terminal in raw mode
    tcsetattr(0,0,&newtermstat);
    select(lastfd+1,&readfds,NULL,NULL,NULL);	// wait for keypressed or mouse
    tcsetattr(0,0,&termstat);	// put terminal back in cooked mode

    // Check what we should do
    if (FD_ISSET(0,&readfds)) break;  // user hit a key
    if (FD_ISSET(vmfileno,&readfds)) vm.checkmouse();
  };
  tcsetattr(0,0,&termstat);	// put terminal in cooked mode
  tcflush(0,TCIFLUSH);	// flush all extra input
  printf("bye-bye\n");	// say bye-bye
};
