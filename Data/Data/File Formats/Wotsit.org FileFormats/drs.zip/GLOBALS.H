#ifndef __globals_h
#define __globals_h

#include <linux/types.h>

/*
typedef unsigned char  u_char;
typedef unsigned short u_short;
typedef unsigned int   u_int;
typedef unsigned long  u_long;
*/

#endif
