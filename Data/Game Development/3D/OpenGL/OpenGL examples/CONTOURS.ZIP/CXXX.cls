VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'----------------------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: -
'NOTES:
'  printf("Use left mouse button to place vertices.\n");
'  printf("Press middle mouse button when done.\n");
'  printf("Select tesselate from the pop-up menu.\n");
'----------------------------------------------------------------------------
' tess_demo.c
' A demo of the GLU polygon tesselation functions written
' by Bogdan Sikorski.
' Bug fixes by Mark Kilgard 11/8/96
' this was ported from a file in the GLUT distribution.
'----------------------------------------------------------------------------
Dim m_Mat As glxMaterial
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Public m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
'----------------------------------------------------------------------------
Dim width&, height&
Const MAX_POINTS = 200
Const MAX_CONTOURS = 50
Dim Contours As Collection
Dim m_NearPlane!
'this info isn't used:
'Enum mode_type
'  DEFINE = 1
'  TESSELATED = 2
'End Enum
'Dim mode As mode_type

Private Sub Class_Initialize()
'
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    'something seems wrong with the lights
    'lighting looks bad
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 0, 30, 100
        .Enabled = True
    End With
    With gCtl.Lights.Item(liLight1)
        .SetPosition 10, 100, 50
        .Enabled = True
        .SetAmbient 0.5, 0.5, 0.5
    End With
    With gCtl.Lights
        .TwoSide = True
        .LocalViewer = True
    End With
    m_NearPlane = -1000
    With gCtl.Camera
        .FarPlane = 1000
        .NearPlane = m_NearPlane
        .FieldOfView = 45
        .SetEyePos 0, 0, 0
        .SetTargetPos 0, 0, -1
        .View = glxOrtho
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFrontAndBack
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.7, 1, 1
        .SetSpecular 1, 1, 1
        .SpecExp = 120
        .Shininess = 50
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridY
        .GridStep = 1
        .Axis = glxXYZ
        .Pick = True
        .SetWorldSize 200, 200, 200
    End With
    m_Grids = True
    glShadeModel GL_FLAT
    glPolygonMode GL_FRONT, GL_FILL
    '
    'mode = DEFINE
    glPointSize 3
    Set Contours = New Collection
    m_Mat.SetMaterial
    glDisable GL_LIGHTING
End Sub

Public Sub Draw()
Dim i&, j&
Dim c As CContour
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    For Each c In Contours
        c.Draw 0 'mode
    Next
    CheckError
End Sub

Public Function Reshape(w&, h&) As Boolean
    Reshape = True
    width = w
    height = h
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case vbKeyReturn: Done
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "c", "C"
        Clear
    Case " "
        Done
    Case Else: Exit Sub
    End Select
    gCtl.Render
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
        AddPoint x, y
    ElseIf Button = 4 Then
        Done
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If m_bMoving Then
        End If
        gCtl.Render
    ElseIf Button = 2 Then
        gCtl.Render
    End If
End Sub

Sub AddPoint(x1!, y1!)
Dim viewport&(0 To 3)
Dim modelMatrix#(0 To 15), projMatrix#(0 To 15)
Dim objx#, objy#, objz#
Dim P#(0 To 2), point_cnt&
Dim Pt&(0 To 2)
    If ActiveContour Is Nothing Then Exit Sub
    ' translate  into GL coordinates
    P(0) = x1
    P(1) = height - y1
        glGetDoublev GL_MODELVIEW_MATRIX, modelMatrix(0)
        glGetDoublev GL_PROJECTION_MATRIX, projMatrix(0)
        glGetIntegerv GL_VIEWPORT, viewport(0)
        'ortho view near=-far, eye is at 0
        gluUnProject P(0), P(1), 0.5, _
                        modelMatrix(0), projMatrix(0), viewport(0), _
                        objx, objy, objz
    ActiveContour.Add objx, objy, objz
End Sub

Sub Done()
    If Not ActiveContour Is Nothing Then
        ActiveContour.Done
        ActiveContour.Tess 0
    End If
    Set ActiveContour = Nothing
    gCtl.Render
    gCtl.MouseRotate = True
End Sub

Sub NewContour()
    If Not ActiveContour Is Nothing Then
        ActiveContour.Done
    End If
    Set ActiveContour = New CContour
    Contours.Add ActiveContour
    'don't allow rotation or everything goes haywire
    gCtl.MouseRotate = False
End Sub

Sub Clear()
Dim i&
    For i = 1 To Contours.Count
        Contours.Remove 1
    Next
    gCtl.Render
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, z#, z1#, z2#
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    z = FLOAT_MAX ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                z1 = ULong(items(ptr))
                Debug.Print " z1 = " & z1
                ptr = ptr + 1
            '3.z2
                z2 = ULong(items(ptr))
                Debug.Print " z2 = " & z2
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < z Then
                        z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub


