VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "GLUT and GLE Demo"
   ClientHeight    =   4635
   ClientLeft      =   180
   ClientTop       =   2265
   ClientWidth     =   5385
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   309
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   359
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3300
      Left            =   540
      TabIndex        =   0
      Top             =   540
      Width           =   3165
      _ExtentX        =   5583
      _ExtentY        =   5821
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileMouse 
         Caption         =   "Mouse tracking"
      End
   End
   Begin VB.Menu mnuGLUTz 
      Caption         =   "GLUT"
      Begin VB.Menu mnuGLUT 
         Caption         =   "Cone"
         Index           =   1
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Cube"
         Index           =   2
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Dodecahedron"
         Index           =   3
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Icosahedron"
         Index           =   4
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Octahedron"
         Index           =   5
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Sphere"
         Index           =   6
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Tetrahedron"
         Index           =   7
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Torus"
         Index           =   8
      End
      Begin VB.Menu mnuGLUT 
         Caption         =   "Cylinder"
         Index           =   9
      End
   End
   Begin VB.Menu mnuVRMLz 
      Caption         =   "VRML"
      Begin VB.Menu mnuVRML 
         Caption         =   "Box"
         Index           =   0
      End
      Begin VB.Menu mnuVRML 
         Caption         =   "Cone"
         Index           =   1
      End
      Begin VB.Menu mnuVRML 
         Caption         =   "Cylinder"
         Index           =   2
      End
      Begin VB.Menu mnuVRML 
         Caption         =   "Sphere"
         Index           =   3
      End
   End
   Begin VB.Menu mnuGLEz 
      Caption         =   "GLE"
      Begin VB.Menu mnuGLE 
         Caption         =   "Cylinder"
         Index           =   1
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Cone"
         Index           =   2
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Extrusion"
         Index           =   3
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "TwistExtrusion"
         Index           =   4
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "SuperExtrusion"
         Index           =   5
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Spiral"
         Index           =   6
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Lathe"
         Index           =   7
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Helicoid"
         Index           =   8
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Toroid"
         Index           =   9
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Screw"
         Index           =   10
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Cylinders and Cones"
         Index           =   12
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Extrusions"
         Index           =   13
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Spirals"
         Index           =   14
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Lathes"
         Index           =   15
      End
      Begin VB.Menu mnuGLE 
         Caption         =   "Other"
         Index           =   16
      End
   End
   Begin VB.Menu mnuJoinStyle 
      Caption         =   "Join style"
      Begin VB.Menu mnuJoinRaw 
         Caption         =   "Raw"
      End
      Begin VB.Menu mnuJoinAngle 
         Caption         =   "Angle"
      End
      Begin VB.Menu mnuJoinCut 
         Caption         =   "Cut"
      End
      Begin VB.Menu mnuJoinRound 
         Caption         =   "Round"
      End
      Begin VB.Menu mnuJoinSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuJoinFacets 
         Caption         =   "Facet normals"
      End
      Begin VB.Menu mnuJoinEdges 
         Caption         =   "Edge normals"
      End
   End
   Begin VB.Menu mnuTextures 
      Caption         =   "Texture"
      Begin VB.Menu mnTexOn 
         Caption         =   "Off"
         Checked         =   -1  'True
         Index           =   1
      End
      Begin VB.Menu mnTexOn 
         Caption         =   "On"
         Index           =   2
      End
      Begin VB.Menu mnTexSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnTex 
         Caption         =   "Vertex Flat"
         Index           =   1
      End
      Begin VB.Menu mnTex 
         Caption         =   "Normal Flat"
         Index           =   2
      End
      Begin VB.Menu mnTex 
         Caption         =   "Vertex Cylinder"
         Index           =   3
      End
      Begin VB.Menu mnTex 
         Caption         =   "Normal Cylinder"
         Index           =   4
      End
      Begin VB.Menu mnTex 
         Caption         =   "Vertex Sphere"
         Index           =   5
      End
      Begin VB.Menu mnTex 
         Caption         =   "Normal Sphere"
         Index           =   6
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Vertex Flat"
         Index           =   7
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Normal Flat"
         Index           =   8
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Vertex Cylinder"
         Index           =   9
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Normal Cylinder"
         Index           =   10
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Vertex Sphere"
         Index           =   11
      End
      Begin VB.Menu mnTex 
         Caption         =   "Model Normal Sphere"
         Index           =   12
      End
      Begin VB.Menu mnTexSep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTexs 
         Caption         =   "Check"
         Checked         =   -1  'True
         Index           =   1
      End
      Begin VB.Menu mnuTexs 
         Caption         =   "Barberpole"
         Index           =   2
      End
      Begin VB.Menu mnuTexs 
         Caption         =   "Wildtooth"
         Index           =   3
      End
      Begin VB.Menu mnuTexs 
         Caption         =   "Molten lava"
         Index           =   4
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case (KeyCode)
    Case 27:   Unload frmMain
    Case Else:
        CX.KeyDown KeyCode, Shift
    End Select
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CX = New CGLETest
'
glxCtl1.Init
glxCtl1.Animate = True
End Sub

Private Sub Form_Resize()
    glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub


Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, default As Boolean)
default = CX.Reshape(width, height)
End Sub

Private Sub mnuFile_Click()
mnuFileMouse.Checked = optMouseTrack
End Sub

Private Sub mnuFileMouse_Click()
optMouseTrack = Not optMouseTrack
gCtl.MouseRotate = optMouseTrack
End Sub

Private Sub mnuGLE_Click(Index As Integer)
CX.CurObject = Index + 10
End Sub


Private Sub mnuGLEz_Click()
Dim i%
    For i = 1 To 16
        If i + 10 = CX.CurObject Then
            mnuGLE(i).Checked = True
        Else
            mnuGLE(i).Checked = 0
        End If
    Next

End Sub

Private Sub mnuGLUT_Click(Index As Integer)
CX.CurObject = Index
End Sub

Private Sub mnuGLUTz_Click()
Dim i%
    For i = 1 To 9
        If i = CX.CurObject Then
            mnuGLUT(i).Checked = True
        Else
            mnuGLUT(i).Checked = 0
        End If
    Next
End Sub

Private Sub mnuJoinAngle_Click()
CX.JoinStyle = gleANGLE
End Sub

Private Sub mnuJoinCut_Click()
CX.JoinStyle = gleCUT
End Sub

Private Sub mnuJoinEdges_Click()
CX.NormStyle = gleEDGE
End Sub

Private Sub mnuJoinFacets_Click()
CX.NormStyle = gleFACET
End Sub

Private Sub mnuJoinRaw_Click()
CX.JoinStyle = gleRAW
End Sub

Private Sub mnuJoinRound_Click()
CX.JoinStyle = gleROUND
End Sub

Private Sub mnuJoinStyle_Click()
mnuJoinRaw.Checked = (CX.JoinStyle = gleRAW)
mnuJoinRound.Checked = (CX.JoinStyle = gleROUND)
mnuJoinFacets.Checked = (CX.NormStyle = gleFACET)
mnuJoinEdges.Checked = (CX.NormStyle = gleEDGE)
mnuJoinAngle.Checked = (CX.JoinStyle = gleANGLE)
mnuJoinCut.Checked = (CX.JoinStyle = gleCUT)
End Sub


Private Sub mnuTexs_Click(Index As Integer)
Dim i&
    CX.Texture = Index
    For i = 1 To 4
        If i = Index Then
            mnuTexs(i).Checked = True
        Else
            mnuTexs(i).Checked = 0
        End If
    Next
End Sub

Private Sub mnTex_Click(Index As Integer)
CX.TextureStyle = Index
End Sub

Private Sub mnTexOn_Click(Index As Integer)
If Index = 1 Then
    mnTexOn(1).Checked = True
    mnTexOn(2).Checked = False
    CX.TextureEnabled = False
Else
    mnTexOn(2).Checked = True
    mnTexOn(1).Checked = False
    CX.TextureEnabled = True
End If
End Sub


Private Sub mnuTextures_Click()
Dim i&, n&
    'on/off
    n = CX.TextureEnabled
    mnTexOn(1).Checked = Not n
    mnTexOn(2).Checked = n
    'texture style
    n = CX.TextureStyle
    For i = 1 To 12
        If i = n Then
            mnTex(i).Checked = True
        Else
            mnTex(i).Checked = False
        End If
    Next

End Sub

Private Sub mnuVRML_Click(Index As Integer)
CX.CurObject = Index + 30
End Sub

Private Sub mnuVRMLz_Click()
Dim i%
    For i = 0 To 3
        If i + 30 = CX.CurObject Then
            mnuVRML(i).Checked = True
        Else
            mnuVRML(i).Checked = 0
        End If
    Next

End Sub
