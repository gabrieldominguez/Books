
#include <windows.h>
#include <GL/glut.h>

typedef struct {
	double posx;
   double posy;
   double posz;
} object_t;

struct world_object_type {

	object_t	coords;

   float upx;
	float upy;
   float upz;

	float azimuth;
	float elevation;

	float speed;

};

// Variables to store time
struct time_delta_type {
	float elapsedTime;
	float currentTime;
	float lastTime;
};


/*
	Define a few constants to make for a more accurate simulation...

   These figures below were calculated using,
   (360 degrees / orbital period in days).
*/

#define MERC_DEGS          4.109
#define VENUS_DEGS         1.599
#define EARTH_DEGS 			0.986
#define MARS_DEGS 			0.524
#define MOON_DEGS 			12

#define MAX_STARS 			1000
#define STAR_RADIUS 			1500


#define MAX_NO_TEXTURES 4

#define MOUSE_SENSITIVITY 0.1



