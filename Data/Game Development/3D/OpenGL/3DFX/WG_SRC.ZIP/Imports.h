
#ifndef _IMPORTS_
#define _IMPORTS_

#include <windows.h>

HINSTANCE LoadSymbols(HINSTANCE);

#endif //_IMPORTS_
