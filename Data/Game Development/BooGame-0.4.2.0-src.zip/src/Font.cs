/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;
using System.Drawing.Text;
using System.Drawing.Drawing2D;

using Tao.OpenGl;
using Tao.PhysFs;
using Tao.DevIl;

namespace BooGame
{
    /// <summary>
    /// Encapsulates the use of a font for printing text on screen.
    /// </summary>
	[Serializable]
    public class Font : Texture, ISerializable
    {
        static Font()
        {
            Core.Initialize();
            Texture.Initialize();
            Font.Initialize();
        }

        internal static new void Initialize()
		{
			if(m_Default == null)
				m_Default = new Font(FontFamily.GenericMonospace, 14f, FontStyle.Bold);
        }

        /// <summary>
        /// Creates a monospaced font with a size of 14.
        /// </summary>
        public Font() : this(FontFamily.GenericMonospace, 14f)
        {
        }

        /// <summary>
        /// Creates a font.
        /// </summary>
        /// <param name="family">The font family (Example: "Arial").</param>
        /// <param name="size">The size of the font in pixels. Defaults to 20.</param>
        /// <param name="style">The style to be associated with the font.</param>
        public Font(string family, float size, FontStyle style)
            : this(new System.Drawing.Font(family, size, style, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Creates a font.
        /// </summary>
        /// <param name="family">The font family (Example: "Arial").</param>
        /// <param name="size">The size of the font in pixels. Defaults to 20.</param>
        /// <param name="style">The style to be associated with the font.</param>
        public Font(FontFamily family, float size, FontStyle style)
            : this(new System.Drawing.Font(family, size, style, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Creates a font.
        /// </summary>
        /// <param name="family">The font family (Example: "Arial").</param>
        /// <param name="size">The size of the font in pixels. Defaults to 20.</param>
        public Font(string family, float size)
            : this(new System.Drawing.Font(family, size, FontStyle.Regular, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Creates a font.
        /// </summary>
        /// <param name="family">The font family.</param>
        /// <param name="size">The size of the font in pixels. Defaults to 20.</param>
        public Font(FontFamily family, float size)
            : this(new System.Drawing.Font(family, size, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Creates a font with a default size 20.
        /// </summary>
        /// <param name="family">The font family (Example: "Arial").</param>
        public Font(string family)
            : this(new System.Drawing.Font(family, 20f, FontStyle.Regular, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Creates a font from the given font family with a size of 20.
        /// </summary>
        /// <param name="family"></param>
        public Font(FontFamily family)
            : this(new System.Drawing.Font(family, 20f, GraphicsUnit.Pixel))
        {
        }

        /// <summary>
        /// Loads a BooGame Font from a Font object.
        /// </summary>
        /// <param name="font">The font to load.</param>
        /// <remarks>The Font.Unit must be in Pixels.</remarks>
        protected Font(System.Drawing.Font font)
        {
            Load(font);
        }

        /// <summary>
        /// Constructor for run-time generated font-texture.
        /// </summary>
        /// <param name="fontFamily">FontFamily to be generated.</param>
        /// <param name="fontSize">Size of the font.</param>
        /// <param name="fontStyle">Style of the font.</param>
        /// <remarks>Font.Unit has to be in pixels.</remarks>
        protected virtual void Load(System.Drawing.Font font)
        {
            m_Name = font.Name;
            FontStyle fontStyle = font.Style;
            m_Font = font;
            float lineSpace = (float)font.FontFamily.GetLineSpacing(fontStyle)
                / (float)font.FontFamily.GetEmHeight(fontStyle);
            int cellSize = (int)(font.Size * lineSpace * 1.2f); // Increase size by 20% to allow anti alias

            System.Drawing.Bitmap image = new Bitmap(16 * cellSize, 16 * cellSize,
                System.Drawing.Imaging.PixelFormat.Format32bppArgb);

			Graphics g = Graphics.FromImage(image);
			g.FillRectangle(Brushes.Transparent,
				new Rectangle(0, 0, image.Width, image.Height));
    
            string layout =
                "????????????????" +
                "????????????????" +
                " !\"#$%&'()*+,-./" +
                "0123456789:;<=>?" +
                "@ABCDEFGHIJKLMNO" +
                "PQRSTUVWXYZ[\\]^_" +
                "`abcdefghijklmno" +
                "pqrstuvwxyz{|}~" +
                "����������������" +
                "����������������" +
                " ���������������" +
                "����������������" +
                "����������������" +
                "����������������" +
                "����������������" +
                "��������������� ";

            // Without anti-alias
            //g.TextRenderingHint = TextRenderingHint.SystemDefault;
            //g.SmoothingMode = SmoothingMode.HighQuality;

            // With anti-alias
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            for (int i = 0; i < 256; i++)
            {
                int row = i % 16;
                int col = (int)((float)i / (float)16);
                g.DrawString(layout[i].ToString(), font, Brushes.White,
                    row * cellSize, col * cellSize);
            }

            // Load the image into a byte array
            base.Load(image);
            m_TileSet = new TileSet(this, base.Width / 16, base.Height / 16);

            // Calculate font height and character widths
            RectangleF[] charMetrics = new RectangleF[256];
			Region[] tmp;
            RectangleF layoutRect = new RectangleF(0, 0, image.Width, image.Height); 
            CharacterRange[] ranges = new CharacterRange[] { new CharacterRange(0, 1) };
            StringFormat strFormat = new StringFormat(StringFormatFlags.MeasureTrailingSpaces);
            strFormat.SetMeasurableCharacterRanges(ranges);

            m_TextWidths = new float[256];
            m_TextHeight = 0;

			for (int i = 0; i < layout.Length; i++)
            {
				tmp = g.MeasureCharacterRanges(layout[i].ToString(), font, layoutRect, strFormat);
				if (tmp.Length == 0)
					charMetrics[i] = new RectangleF();
				else
                {
					RectangleF aux = tmp[0].GetBounds(g);
					charMetrics[i] = aux;
                    m_TextHeight = Math.Max(aux.Height + aux.Y, m_TextHeight);
				}
			}
            for (int i = 0; i < 256; i++)
                m_TextWidths[i] = charMetrics[i].Width;

        }

        private float[] m_TextWidths;
        private float m_TextHeight;
        private System.Drawing.Font m_Font;

		private TileSet m_TileSet;
        /// <summary>
        /// Gets the tileset associated with the font.
        /// </summary>
        public TileSet TileSet
        {
            get
            {
                return m_TileSet;
            }
        }
        
        /// <summary>
        /// Gets the width of the given text string using the current font.
        /// </summary>
        /// <param name="text">The text to check.</param>
        /// <param name="scaleX">The scale to use with the font. Defaults to 1f.</param>
        /// <returns>A float representing the width of the text at the given scale.</returns>
        public float TextWidth(string text, float scaleX)
        {
            float finalWidth = 0f;
            float width = 0f;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '\n')
                {
                    if (width > finalWidth)
                        finalWidth = width;
                    else
                        width = 0f;
                }
                else
                    width += m_TextWidths[(int)text[i]];
            }
            float final = (finalWidth > width) ? finalWidth : width;
            return final * scaleX;
        }

        /// <summary>
        /// Retrieves how high the given string is when used with the current font.
        /// </summary>
        /// <param name="text">The string to check.</param>
        /// <param name="scaleY">The Y scale of the font drawing. Defaults to 1f.</param>
        /// <returns>The height of the string in pixels.</returns>
        public float TextHeight(string text, float scaleY)
        {
            float finalHeight = m_TextHeight;
            for (int i = 0; i < text.Length; i++)
                if (text[i] == '\n')
                    finalHeight += m_TextHeight;
            return finalHeight * scaleY;
        }

        /// <summary>
        /// Gets the height of the given string.
        /// </summary>
        /// <param name="text">The text to read in.</param>
        /// <returns>The height of the string in pixels.</returns>
        public float TextHeight(string text)
        {
            return TextHeight(text, 1f);
        }

        /// <summary>
        /// Gets the height of the given number of lines.
        /// </summary>
        /// <param name="numLines">The number of lines of the string.</param>
        /// <returns>The height in pixels.</returns>
        public float TextHeight(int numLines)
        {
            return m_TextHeight * (float)numLines;
        }

        /// <summary>
        /// Gets the height of the given number of lines.
        /// </summary>
        /// <param name="numLines">The number of lines of the string.</param>
        /// <param name="scaleY">The number of lines of the string.</param>
        /// <returns>The height in pixels.</returns>
        public float TextHeight(int numLines, float scaleY)
        {
            return m_TextHeight * (float)numLines * scaleY;
        }

        /// <summary>
        /// Gets the width of the given string.
        /// </summary>
        /// <param name="text">The text to read in.</param>
        /// <returns>The width of the string in pixels.</returns>
        public float TextWidth(string text)
        {
            return TextWidth(text, 1f);
        }

        /// <summary>
        /// Returns the height of a character in pixels.
        /// </summary>
        public override int Height
        {
            get
            {
                return (int)m_TextHeight;
            }
        }

        #region Print
        public void Print(string text)
        {
            Print(text, Color.White, Camera.Top, Camera.Left, ContentAlignment.TopLeft, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color)
        {
            Print(text, color, Camera.Top, Camera.Left, ContentAlignment.TopLeft, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y)
        {
            Print(text, color, x, y, ContentAlignment.TopLeft, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location)
        {
            Print(text, color, location.X, location.Y, ContentAlignment.TopLeft, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment)
        {
            Print(text, color, x, y, alignment, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment)
        {
            Print(text, color, location.X, location.Y, alignment, -1f, -1f, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, float width, float height)
        {
            Print(text, color, x, y, alignment, width, height, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, SizeF size)
        {
            Print(text, color, x, y, alignment, size.Width, size.Height, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, SizeF size)
        {
            Print(text, color, location.X, location.Y, alignment, size.Width, size.Height, 0f, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, float width, float height)
        {
            Print(text, color, location.X, location.Y, alignment, width, height, 0f, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect, ContentAlignment alignment)
        {
            Print(text, color, rect.X, rect.Y, alignment, rect.Width, rect.Height, 0f, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect)
        {
            Print(text, color, rect.X, rect.Y, ContentAlignment.TopLeft, rect.Width, rect.Height, 0f, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, float width, float height, float rotation)
        {
            Print(text, color, x, y, alignment, width, height, rotation, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, SizeF size, float rotation)
        {
            Print(text, color, x, y, alignment, size.Width, size.Height, rotation, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, SizeF size, float rotation)
        {
            Print(text, color, location.X, location.Y, alignment, size.Width, size.Height, rotation, 1f, 1f, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, float width, float height, float rotation)
        {
            Print(text, color, location.X, location.Y, alignment, width, height, rotation, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect, ContentAlignment alignment, float rotation)
        {
            Print(text, color, rect.X, rect.Y, alignment, rect.Width, rect.Height, rotation, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect, float rotation)
        {
            Print(text, color, rect.X, rect.Y, ContentAlignment.TopLeft, rect.Width, rect.Height, rotation, 1f, 1f, 0f, 0f);
        }

        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, x, y, alignment, width, height, rotation, scaleX, scaleY, 0f, 0f);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, x, y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, location.X, location.Y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, 0f, 0f);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, location.X, location.Y, alignment, width, height, rotation, scaleX, scaleY, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect, ContentAlignment alignment, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, rect.X, rect.Y, alignment, rect.Width, rect.Height, rotation, scaleX, scaleY, 0f, 0f);
        }

        public void Print(string text, ColorF color, RectangleF rect, float rotation, float scaleX, float scaleY)
        {
            Print(text, color, rect.X, rect.Y, ContentAlignment.TopLeft, rect.Width, rect.Height, rotation, scaleX, scaleY, 0f, 0f);
        }

        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, x, y, alignment, width, height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }
        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, x, y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, location.X, location.Y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, location.X, location.Y, alignment, width, height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }

        public void Print(string text, ColorF color, RectangleF rect, ContentAlignment alignment, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, rect.X, rect.Y, alignment, rect.Width, rect.Height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }

        public void Print(string text, ColorF color, RectangleF rect, float rotation, float scaleX, float scaleY, PointF hotspot)
        {
            Print(text, color, rect.X, rect.Y, ContentAlignment.TopLeft, rect.Width, rect.Height, rotation, scaleX, scaleY, hotspot.X, hotspot.Y);
        }

        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            Print(text, color, x, y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, hotspotX, hotspotY);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, SizeF size, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            Print(text, color, location.X, location.Y, alignment, size.Width, size.Height, rotation, scaleX, scaleY, hotspotX, hotspotY);
        }
        public void Print(string text, ColorF color, PointF location, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            Print(text, color, location.X, location.Y, alignment, width, height, rotation, scaleX, scaleY, hotspotX, hotspotY);
        }

        public void Print(string text, ColorF color, RectangleF rect, ContentAlignment alignment, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            Print(text, color, rect.X, rect.Y, alignment, rect.Width, rect.Height, rotation, scaleX, scaleY, hotspotX, hotspotY);
        }

        public void Print(string text, ColorF color, RectangleF rect, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            Print(text, color, rect.X, rect.Y, ContentAlignment.TopLeft, rect.Width, rect.Height, rotation, scaleX, scaleY, hotspotX, hotspotY);
        }

        public void Print(string text, ColorF color, float x, float y, ContentAlignment alignment, float width, float height, float rotation, float scaleX, float scaleY, float hotspotX, float hotspotY)
        {
            if (text.Length == 0)
                return;
            if (color.A == 0)
                return;

            // Setup the GL matrix
            Gl.glPushMatrix();
            Camera.ApplyMatrix();
            Gl.glTranslatef(x, y, 0f);
            Gl.glRotatef(rotation, 0f, 0f, 1f);
            Gl.glScalef(scaleX, scaleY, 0f);
            Gl.glTranslatef(-hotspotX, -hotspotY, 0f);
            Gl.glColor4f(color.R, color.G, color.B, color.A);

            // Parse the text
            text = text.Replace("\r\n", "\n");
            text = text.Replace("\r", "\n");

            // Take off unshown lines
            if (height > 0f)
            {
                while (height < TextHeight(text, scaleY))
                    if (text.IndexOf("\n") >= 0)
                        text = text.Substring(0, text.LastIndexOf('\n'));
                    else
                        break;
            }

            // Split the lines up into an array
            string[] lines = text.Split('\n');

            // Take off unshown characters
            if (width > 0f)
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    string finalLine = lines[i];
                    while (TextWidth(finalLine, scaleX) > width)
                        finalLine = finalLine.Remove(finalLine.Length - 1, 1);
                    lines[i] = finalLine;
                }
            }

            // Check the alignment and print
            switch (alignment)
            {
                case ContentAlignment.TopCenter:
                    y = 0f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, TextWidth(line, scaleX) / -2f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.TopLeft:
                    y = 0f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, 0f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.TopRight:
                    y = 0f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, -TextWidth(line, scaleX), y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.MiddleCenter:
                    y = TextHeight(lines.Length, scaleY) / -2f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, TextWidth(line, scaleX) / -2f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.MiddleLeft:
                    y = TextHeight(lines.Length, scaleY) / -2f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, 0f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.MiddleRight:
                    y = TextHeight(lines.Length, scaleY) / -2f;
                    foreach (string line in lines)
                    {
                        PrintHelper(line, -TextWidth(line, scaleX), y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.BottomCenter:
                    y = -TextHeight(lines.Length, scaleY);
                    foreach (string line in lines)
                    {
                        PrintHelper(line, TextWidth(line, scaleX) / -2f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.BottomLeft:
                    y = -TextHeight(lines.Length, scaleY);
                    foreach (string line in lines)
                    {
                        PrintHelper(line, 0f, y);
                        y += TextHeight(line);
                    }
                    break;
                case ContentAlignment.BottomRight:
                    y = -TextHeight(lines.Length, scaleY);
                    foreach (string line in lines)
                    {
                        PrintHelper(line, -TextWidth(line, scaleX), y);
                        y += TextHeight(line);
                    }
                    break;
            }
            
            // End GL drawing
            Gl.glEnd();
            Gl.glPopMatrix();
        }

        /// <summary>
        /// Writes the text to the screen without parsing.
        /// </summary>
        /// <param name="text"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        private void PrintHelper(string text, float x, float y)
        {
            for (int i = 0; i < text.Length; i++)
            {
                int ascii = (int)text[i];
                int tx = ascii % m_TileSet.TilesWide;
                int ty = (ascii - tx) / m_TileSet.TilesWide;
                m_TileSet.QuickDraw(tx, ty, x, y, m_TileSet.TileWidth, m_TileSet.TileHeight);
                x += m_TextWidths[ascii];
            }
        }
        #endregion Print

        #region Serialization
        /// <summary>
        /// Save the serialized font state to a file.
        /// </summary>
        /// <param name="filename">The destination filename.</param>
        public override void Save(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(stream, this);
            }
        }

        /// <summary>
        /// Loads a serialized font state from a file.
        /// </summary>
        /// <param name="filename">The destination filename.</param>
        /// <returns>The loaded texture object.</returns>
        public new static Font FromSerialized(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            Font font;
            using (Stream stream = FileSystem.GetStream(filename))
            {
                font = (Font)formatter.Deserialize(stream);
            }
            return font;
        }

        protected Font(SerializationInfo info, StreamingContext context)
        {
            Load((System.Drawing.Font)info.GetValue("font", typeof(System.Drawing.Font))); //m_Font.GetType()));
        }

        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("font", m_Font, m_Font.GetType());
        }
        #endregion Serialization

        #region Default Fonts
        private static Font m_Default;
        /// <summary>
        /// Gets the default system font.
        /// </summary>
        public static Font Default
        {
            get
            {
                return m_Default;
            }
        }
        #endregion Default Fonts
    }
}
