Attribute VB_Name = "mGLUTess"
Option Explicit

Type V3DOUBLEV
    v(0 To 2) As Double
End Type

Type V6DOUBLEV
    v(0 To 5) As Double
End Type


Declare Sub CopyToDoubleFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
        (Dest#, ByVal PtrSrc&, ByVal length&)
Declare Sub CopyToSingleFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
        (Dest!, ByVal PtrSrc&, ByVal length&)
Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (Dest As Byte, Src As Byte, ByVal length&)
Declare Sub CopyToStrFromInt Lib "kernel32" Alias "RtlMoveMemory" (ByVal Dest$, Src%, ByVal length&)
Declare Sub CopyToPtrFromPtr Lib "kernel32" Alias "RtlMoveMemory" (ByVal DestAddr&, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToByteFromPtr Lib "kernel32" Alias "RtlMoveMemory" (Dest As Byte, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToLongFromPtr Lib "kernel32" Alias "RtlMoveMemory" (Dest&, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToIntegerFromPtr Lib "kernel32" Alias "RtlMoveMemory" (Dest%, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToStrFromPtr Lib "kernel32" Alias "RtlMoveMemory" (ByVal Dest$, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToStrFromLong Lib "kernel32" Alias "RtlMoveMemory" (ByVal Dest$, Src&, ByVal length&)
Declare Sub CopyToTypeFromPtr Lib "kernel32" Alias "RtlMoveMemory" (ByRef Dest As Any, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToTypeFromType Lib "kernel32" Alias "RtlMoveMemory" (ByRef Dest As Any, ByRef Src As Any, ByVal length&)

Const CombineListSize = 1000
Dim CombineList(1 To CombineListSize) As V6DOUBLEV
Dim CombineNext&
'

Public Sub ClearCombineList()
    CombineNext = 0
End Sub

'-------------------------------------------------------------------------
Sub glBeginCB(ByVal which&)
Dim s$
    glBegin which
    Select Case which
    Case GL_TRIANGLE_FAN: s = "GL_TRIANGLE_FAN"
    Case GL_TRIANGLE_STRIP: s = "GL_TRIANGLE_STRIP"
    Case GL_TRIANGLES: s = "GL_TRIANGLES"
    Case GL_LINE_LOOP: s = "GL_LINE_LOOP"
    Case Else
        Debug.Assert 0
    End Select
    Debug.Print "glBegin " & s
End Sub

'-------------------------------------------------------------------------
Sub glBeginCB_User(ByVal which&, ByRef data&)
    glBegin which
    '?
End Sub

'-------------------------------------------------------------------------
Sub glEdgeFlagCB(ByVal flag As GLboolean)
    '
End Sub

'-------------------------------------------------------------------------
Sub glEdgeFlagCB_User(ByVal flag As GLboolean, ByRef data&)
    '?
End Sub

'-------------------------------------------------------------------------
Sub glVertex3fvCB(ByRef arg!)
    glVertex3fv arg
End Sub

'-------------------------------------------------------------------------
Sub glVertex3dvCB(ByRef arg#)
    glVertex3dv arg
End Sub

Sub glColorVertex3dvCB(ByRef vertex#)
Dim n&, d#, c#(0 To 2)
    'glColor3dv(pointer+3)
    'Exit Sub
    n = VarPtr(vertex) + 3 * (Len(c(0)))
    CopyToDoubleFromPtr c(0), n, Len(c(0)) * 3
    glColor3dv c(0)
    'glVertex3dv(vertex)
    glVertex3dv vertex
End Sub

'-------------------------------------------------------------------------
Sub glCombineCB()

End Sub

'-------------------------------------------------------------------------
Sub glEndCB()
    glEnd
    Debug.Print "glEnd"
End Sub

'-------------------------------------------------------------------------
Sub glErrorCB(ByVal errorCode&) '???
Dim estring$, s$
    estring = gluErrorString(errorCode)
    Debug.Print "Tessellation Error: " & estring
    Select Case errorCode
    Case GLU_TESS_MISSING_BEGIN_POLYGON
        Debug.Assert 0
    Case GLU_TESS_MISSING_END_POLYGON
        Debug.Assert 0
    Case GLU_TESS_MISSING_BEGIN_CONTOUR
        Debug.Assert 0
    Case GLU_TESS_MISSING_END_CONTOUR
        Debug.Assert 0
    Case GLU_TESS_COORD_TOO_LARGE
        Debug.Assert 0
    Case GLU_TESS_NEED_COMBINE_CALLBACK
        Debug.Assert 0
    Case errorCode >= GLU_TESS_ERROR1 And errorCode <= GLU_TESS_ERROR8
        '10151-10158
        Debug.Assert 0
    Case Else
    Debug.Assert 0
    End Select
    Stop
End Sub

Sub combineCallback1(ByVal c&, _
        ByVal vdata&, _
        ByVal weight&, _
        ByRef dataOut&)
Dim i&, n&
Dim coords#(0 To 2)
Dim vd&(0 To 3) 'pointers
Dim vd4(0 To 3) As V6DOUBLEV 'data
Dim w!(0 To 3)
    '
    'Stop
    CombineNext = CombineNext + 1
    If CombineNext > CombineListSize Then
        'we gonna crash!
        Debug.Assert 0
    End If
    'coords
    CopyToDoubleFromPtr coords(0), c, 3 * Len(coords(0))
    Debug.Print Round(coords(0), 3)
    Debug.Print Round(coords(1), 3)
    Debug.Print Round(coords(2), 3)
    CombineList(CombineNext).v(0) = coords(0)
    CombineList(CombineNext).v(1) = coords(1)
    CombineList(CombineNext).v(2) = coords(2)
    'vertex data
    CopyToLongFromPtr vd(0), vdata, 4 * Len(vd(0))
    Debug.Print vd(0)
    Debug.Print vd(1)
    Debug.Print vd(2)
    Debug.Print vd(3)
    CopyToTypeFromPtr vd4(0), vd(0), Len(vd4(0))
    CopyToTypeFromPtr vd4(1), vd(1), Len(vd4(0))
    CopyToTypeFromPtr vd4(2), vd(2), Len(vd4(0))
    CopyToTypeFromPtr vd4(3), vd(3), Len(vd4(0))
    '
    CopyToSingleFromPtr w(0), weight, 4 * Len(w(0))
    Debug.Print Round(w(0), 3)
    Debug.Print Round(w(1), 3)
    Debug.Print Round(w(2), 3)
    Debug.Print Round(w(3), 3)
    For i = 3 To 5
        CombineList(CombineNext).v(i) = w(0) * vd4(0).v(i) _
                  + w(1) * vd4(1).v(i) _
                  + w(2) * vd4(2).v(i) _
                  + w(3) * vd4(3).v(i)
    Next
    dataOut = VarPtr(CombineList(CombineNext).v(0))
End Sub

'-------------------------------------------------------------------------
'tesswinding.c

'/*  combineCallback is used to create a new vertex when edges
' *  intersect.  coordinate location is trivial to calculate,
' *  but weight(4) may be used to average color, normal, or texture
' *  coordinate data.
' */
'sub combineCallback2(coords#(3), GLdouble *data(4),
'                     GLfloat weight(4), GLdouble **dataOut )
Sub combineCallback2(ByVal c&, _
        ByVal vdata&, _
        ByVal weight&, _
        ByRef dataOut&)
Dim coords#(0 To 2)
    'GLdouble *vertex;
   'vertex = (GLdouble *) malloc(3 * sizeof(GLdouble)
    CombineNext = CombineNext + 1
    If CombineNext > CombineListSize Then
        'we gonna crash!
        Debug.Assert 0
    End If
    'coords
    CopyToDoubleFromPtr coords(0), c, 3 * Len(coords(0))
    Debug.Print Round(coords(0), 3)
    Debug.Print Round(coords(1), 3)
    Debug.Print Round(coords(2), 3)
    CombineList(CombineNext).v(0) = coords(0)
    CombineList(CombineNext).v(1) = coords(1)
    CombineList(CombineNext).v(2) = coords(2)
    dataOut = VarPtr(CombineList(CombineNext).v(0)) 'vertex;
End Sub




