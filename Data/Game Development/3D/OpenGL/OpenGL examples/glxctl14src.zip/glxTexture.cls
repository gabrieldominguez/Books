VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxTexture"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: wrapper for textures
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'From the OpenGL screensavers:
'* Module Name: texture.c
'* Texture handling functions
'* Copyright (c) 1994 Microsoft Corporation
'HISTORY:
'Oct 98
'   - added error handlers and support for Pictures
'   - added texture properties
'   - modified the interface to set data by passing a byte array rather
'       than by a pointer to the data
'NOTES - once the texture is bound, you can save the ID in your app and set this
'class to nothing to release all the pixel data if you don't need it anymore.
'   - note: glTexEnvf fails - always use glTexEnvi
'-------------------------------------------------------------------------
Public Enum glxTexEnvModes
    Decal = GL_DECAL
    Modulate = GL_MODULATE
    Blend = GL_BLEND
End Enum
Public Enum glxTexFilters
    Nearest = GL_NEAREST
    Linear = GL_LINEAR
End Enum
Public Enum glxTexWrap
    Repeat = GL_REPEAT
    Clamp = GL_CLAMP
End Enum
Public Enum glxTexGenModes
    ObjectLinear = GL_OBJECT_LINEAR
    EyeLinear = GL_EYE_LINEAR
    SphereMap = GL_SPHERE_MAP
End Enum
' texture data
Public TexID As GLuint ' texture object
Dim m_Image As glxImage
Dim m_Mode As glxTexEnvModes
Dim m_MAG As glxTexFilters
Dim m_MIN As glxTexFilters
Dim m_WrapS As glxTexWrap, m_WrapT As glxTexWrap
Dim m_TexGenMode As glxTexGenModes
Dim m_DeleteID As Boolean

'-------------------------------------------------------------------------
Private Sub Class_Initialize()
    Set m_Image = New glxImage
    m_Mode = Modulate
    m_MAG = Nearest
    m_MIN = Nearest
    m_WrapS = Repeat
    m_WrapT = Repeat
    m_TexGenMode = ObjectLinear
    m_DeleteID = True
End Sub

'-------------------------------------------------------------------------
'you can set DeleteID to false to allow you to delete the class but
'still use the gl texture
'-------------------------------------------------------------------------
Private Sub Class_Terminate()
    If m_DeleteID Then DeleteTexture
    Set m_Image = Nothing
End Sub

'-------------------------------------------------------------------------
' DeleteTexture - this deletes the gl texture object
'-------------------------------------------------------------------------
Private Sub DeleteTexture()
    If TexID Then
        glDeleteTextures 1, TexID
        TexID = 0
    End If
End Sub

'-------------------------------------------------------------------------
'PUBLIC PROPERTIES
'-------------------------------------------------------------------------


'-------------------------------------------------------------------------
' Flag indicating whether to delete the TexID on unload
'-------------------------------------------------------------------------
Public Property Get DeleteID() As Boolean
    DeleteID = m_DeleteID
End Property

Public Property Let DeleteID(ByVal NewValue As Boolean)
    m_DeleteID = NewValue
End Property

'-------------------------------------------------------------------------
'Set or return the image object, which contains all the pixel data
'-------------------------------------------------------------------------
Public Property Get Image() As glxImage
    Set Image = m_Image
End Property

Public Property Let Image(NewImage As glxImage)
    Set m_Image = Nothing
    Set m_Image = NewImage
End Property

'-------------------------------------------------------------------------
'gl texture properties
'-------------------------------------------------------------------------
Public Property Get mode() As glxTexEnvModes
    mode = m_Mode
End Property

Public Property Let mode(ByVal NewValue As glxTexEnvModes)
    m_Mode = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get mag() As glxTexFilters
    mag = m_MAG
End Property

Public Property Let mag(ByVal NewValue As glxTexFilters)
    m_MAG = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get Min() As glxTexFilters
    Min = m_MIN
End Property

Public Property Let Min(ByVal NewValue As glxTexFilters)
    m_MIN = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get WrapS() As glxTexWrap
    WrapS = m_WrapS
End Property

Public Property Let WrapS(ByVal NewValue As glxTexWrap)
    m_WrapS = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get WrapT() As glxTexWrap
    WrapT = m_WrapT
End Property

Public Property Let WrapT(ByVal NewValue As glxTexWrap)
    m_WrapT = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get TexGenMode() As glxTexGenModes
    TexGenMode = m_TexGenMode
End Property

Public Property Let TexGenMode(ByVal NewValue As glxTexGenModes)
    m_TexGenMode = NewValue
End Property

'-------------------------------------------------------------------------
' SetParams - calls gl with the settings for this texture
'-------------------------------------------------------------------------
Public Sub SetParams()
    'note:glTexEnvf fails - always use glTexEnvi
    glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, m_Mode
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, m_WrapS
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, m_WrapT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, m_MAG
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, m_MIN
End Sub

'-------------------------------------------------------------------------
' SetTexture - call this function to make this the current texture
'-------------------------------------------------------------------------
Public Sub SetTexture()
    If TexID Then
        glBindTexture GL_TEXTURE_2D, TexID
    Else
        m_Image.SetTexImage
    End If
End Sub

'-------------------------------------------------------------------------
'LoadTextureFile - Loads a BMP file and prepares it for GL usage
'-------------------------------------------------------------------------
Public Function LoadTextureFile(ByVal FileName$) As Boolean
On Error GoTo Cleanup
    If FileName = "" Then Exit Function
    If m_Image.LoadFile(FileName) Then
        LoadTextureFile = m_ProcessTexture()
    End If
Cleanup:
End Function

'-------------------------------------------------------------------------
'LoadTextureResource
'Loads a BMP or RGB texture resource and prepares it for GL usage
'edx: - there's only one texture in the res file to keep the size of the ocx down.
'this is provided to demonstrate using resources.
''-------------------------------------------------------------------------
Public Function LoadTextureResource(ByVal ID&) As Boolean
Dim ghmodule&, hr&
Dim fLoaded As Boolean
    On Error GoTo NotFound
    fLoaded = m_Image.LoadResource(ID)
NotFound:
    If fLoaded Then
        LoadTextureResource = m_ProcessTexture()
    End If
End Function

'---------------------------------------------------------
'LoadPicture - loads any image VB can read (gif, jpeg, ...)
'---------------------------------------------------------
Public Function LoadPicture(Pic As StdPicture, Optional Opacity! = 1) As Boolean
Dim fLoaded As Boolean
    fLoaded = m_Image.LoadPicture(Pic, Opacity)
    If fLoaded Then
        LoadPicture = m_ProcessTexture()
    End If
End Function

'-------------------------------------------------------------------------
'ProcessTexture
' - Verifies texture size
' - Creates a texture object if extension exists
'-------------------------------------------------------------------------
Private Function m_ProcessTexture() As Boolean
    ' Enforce proper texture size (power of 2, etc.)
    If m_Image.ScaleP2() = False Then Exit Function
    ' if texturing objects available, init the object
    glGenTextures 1, TexID
'    UC.GetErr
    glBindTexture GL_TEXTURE_2D, TexID
'    UC.GetErr
    ' Default attributes for TexID
    'UC.GetErr
    SetParams
'    UC.GetErr
    m_Image.SetTexImage
    m_ProcessTexture = True
End Function


'-------------------------------------------------------------------------
'PUBLIC UTILITY ROUTINES
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'CopyTexture - Make a copy of a texture.
'-------------------------------------------------------------------------
Public Function CopyTexture(Src As glxTexture) As Boolean
Dim nSize&, ptr&
    If Src Is Nothing Then Exit Function
    m_Image.Copy Src.Image
    If Src.TexID Then
        glGenTextures 1, TexID
    End If
    glBindTexture GL_TEXTURE_2D, TexID
    SetParams
    m_Image.SetTexImage
    CopyTexture = True
End Function



'-------------------------------------------------------------------------
'SetTextureTransparency
' Set transparency for a texture by adding or modifying the alpha data.
' Transparency value must be between 0.0 (opaque) and 1.0 (fully transparent)
' If the texture data previously had no alpha, add it in.
' If bSet is TRUE, make this the current texture.
' Note: Currently fully transparent pixels (alpha=0) will not be altered, since
' it is assumed these should be permanently transparent (could make this an
' option? - bPreserveTransparentPixels )
'-------------------------------------------------------------------------
Public Function SetTextureTransparency(ByVal fTransp!, ByVal bSet As Boolean) As Boolean
    If m_Image.SetTransparency(fTransp) Then
        ' Send down new data if texture objects
        glBindTexture GL_TEXTURE_2D, TexID
        m_Image.SetTexImage
        SetTextureTransparency = True
    End If
End Function

'-------------------------------------------------------------------------
Public Sub CreateCheckTexture()
Const TEXTURE_SIZE& = 256
Dim i&, j&
Dim pixmap(0 To TEXTURE_SIZE * TEXTURE_SIZE * 3 - 1) As Byte
Dim mi&, mj&
On Error GoTo EH
    For i = 0 To TEXTURE_SIZE - 1
        For j = 0 To TEXTURE_SIZE - 1
            pixmap(3 * TEXTURE_SIZE * i + 3 * j) = _
            255 * IIf(i / 32 Mod 2 = j / 32 Mod 2, 1, 0)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 1) = _
            255 * IIf(i / 32 Mod 2 = j / 32 Mod 2, 1, 0)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 2) = _
            255 * IIf(i / 32 Mod 2 = j / 32 Mod 2, 1, 0)
        Next
    Next
    glPixelStorei GL_UNPACK_ALIGNMENT, 1
    With m_Image
        .SizeX = TEXTURE_SIZE
        .SizeY = TEXTURE_SIZE
        .SetDataPtr VarPtr(pixmap(0)), TEXTURE_SIZE * TEXTURE_SIZE * 3
        .Components = 3
        .Format = GL_RGB
    End With
    m_ProcessTexture
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'sets the image data from a byte array
'-------------------------------------------------------------------------
Public Sub SetData(ByVal Width&, ByVal Height&, ByVal Components&, _
        ByVal Format As glTIFormatConstants, ByVal DataSize&, Data() As Byte)
On Error GoTo EH
    If UBound(Data) <> Width * Height * Components - 1 Then
        Debug.Assert 0
        Exit Sub
    End If
    glPixelStorei GL_UNPACK_ALIGNMENT, 1
    With m_Image
        .SizeX = Width
        .SizeY = Height
        .Components = Components
        .Format = Format
        .SetPixels Data, DataSize
    End With
    m_ProcessTexture
'-------------------------------------------------------------------------
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'InitAutoTexture
' Generate texture coordinates automatically.
' If pTexRep (s,t) is not 0, use it to set the repetition of the generated
' texture.
'-------------------------------------------------------------------------
Public Sub InitAutoTexture(ByVal s!, ByVal t!)
Dim sgenparams!(0 To 3), tgenparams!(0 To 3)
    UC.Ex.FillArrayf sgenparams, 1, 0, 0, 0
    UC.Ex.FillArrayf tgenparams, 0, 1, 0, 0
    glTexGeni GL_S, GL_TEXTURE_GEN_MODE, m_TexGenMode
    If s Then sgenparams(0) = s
    glTexGenfv GL_S, GL_OBJECT_PLANE, sgenparams(0)
    glTexGeni GL_T, GL_TEXTURE_GEN_MODE, m_TexGenMode
    If t Then tgenparams(0) = t
    glTexGenfv GL_T, GL_OBJECT_PLANE, tgenparams(0)
    glEnable GL_TEXTURE_GEN_S
    glEnable GL_TEXTURE_GEN_T
    glEnable GL_TEXTURE_2D
End Sub

Public Sub EndAutoTexture()
    glDisable GL_TEXTURE_GEN_S
    glDisable GL_TEXTURE_GEN_T
End Sub

'-------------------------------------------------------------------------
' Restore defaults
'-------------------------------------------------------------------------
Public Sub SetDefaultTextureParams()
    m_WrapS = GL_REPEAT
    m_WrapT = GL_REPEAT
    m_MAG = GL_NEAREST
    m_MIN = GL_NEAREST
    SetParams
End Sub

