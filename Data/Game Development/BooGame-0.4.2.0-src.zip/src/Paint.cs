/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

using Tao.OpenGl;

namespace BooGame
{
    #region Dot
    /// <summary>
    /// Encapsulates the effect of a pixel on the screen.
    /// </summary>
    public class Dot : Entity
    {
        public Dot(PointF location)
        {
            Location = location;
        }
        public Dot(PointF location, ColorF color)
        {
            Location = location;
            Tint = color;
        }
        public Dot(ColorF color)
        {
            Tint = color;
        }
        public override float Width
        {
            get
            {
                return 1;
            }
            set
            {
            }
        }
        public override float Height
        {
            get
            {
                return 1;
            }
            set
            {
            }
        }
        public override void Draw()
        {
            Paint.Dot(this.X, this.Y, this.Tint);
        }
    }
    #endregion Dot

    #region Line
    /// <summary>
    /// Manages a line from one point to another.
    /// </summary>
	public class Line : Entity
	{
        public Line(PointF p1, PointF p2)
        {
            X = p1.X; m_X2 = p2.X; Y = p1.Y; m_Y2 = p2.Y;
        }
        public Line(float x1, float y1, float x2, float y2)
        {
            X = x1; m_X2 = x2; Y = y1; m_Y2 = y2;
        }
		private float m_X2, m_Y2;

        public float X1 { get { return X; } set { X = value; } }
        public float Y1 { get { return Y; } set { Y = value; } }
		public float X2 { get{ return m_X2; } set{ m_X2 = value; } }
		public float Y2 { get{ return m_Y2; } set{ m_Y2 = value; } }
		public PointF Point1
		{
			get
			{
				return new PointF(X, Y);
			}
			set
			{
				X = value.X;
				Y = value.Y;
			}
		}
		public PointF Point2
		{
			get
			{
				return new PointF(m_X2, m_Y2);
			}
			set
			{
				m_X2 = value.X;
				m_Y2 = value.Y;
			}
		}
        public override float Width
        {
            get
            {
                return Math.Abs(m_X2 - X);
            }
            set
            {
            }
        }
        public override float Height
        {
            get
            {
                return Math.Abs(m_Y2 - Y);
            }
            set
            {
                base.Height = value;
            }
        }

        public override void Draw()
        {
            Paint.Line(X, Y, m_X2, m_Y2, this.Tint);
            base.Draw();
        }
    }
    #endregion Line

    #region Triangle
    /// <summary>
    /// A structure defining a Triangle.
    /// </summary>
	public class Triangle : Entity
	{
        public Triangle(PointF p1, PointF p2, PointF p3)
        {
            X = p1.X; m_X2 = p2.X; m_X3 = p3.X;
            Y = p1.Y; m_Y2 = p2.Y; m_Y3 = p3.Y;
        }
        public Triangle(float x1, float y1, float x2, float y2, float x3, float y3)
        {
            X = x1; m_X2 = x2; m_X3 = x3;
            Y = y1; m_Y2 = y2; m_Y3 = x3;
        }
		private float m_X2, m_Y2, m_X3, m_Y3;

		public float X1 { get{ return X; } set{ X = value; } }
		public float Y1 { get{ return Y; } set{ Y = value; } }
		public float X2 { get{ return m_X2; } set{ m_X2 = value; } }
		public float Y2 { get{ return m_Y2; } set{ m_Y2 = value; } }
		public float X3 { get{ return m_X3; } set{ m_X3 = value; } }
		public float Y3 { get{ return m_Y3; } set{ m_Y3 = value; } }
		public PointF Point1
		{
			get
			{
				return new PointF(X, Y);
			}
			set
			{
				X = value.X;
				Y = value.Y;
			}
		}
		public PointF Point2
		{
			get
			{
				return new PointF(m_X2, m_Y2);
			}
			set
			{
				m_X2 = value.X;
				m_Y2 = value.Y;
			}
		}
		public PointF Point3
		{
			get
			{
				return new PointF(m_X3, m_Y3);
			}
			set
			{
				m_X3 = value.X;
				m_Y3 = value.Y;
			}
		}
        public override void Draw()
        {
            if (m_Filled)
                Paint.FilledTriangle(X, Y, m_X2, m_Y2, m_X3, m_Y3, this.Tint);
            else
                Paint.Triangle(X, Y, m_X2, m_Y2, m_X3, m_Y3, this.Tint);
            base.Draw();
        }

        private bool m_Filled = true;
        public bool Filled { get { return m_Filled; } set { m_Filled = value; } }
    }
    #endregion Triangle

    #region Circle
    /// <summary>
    /// A structure defining a Circle.
    /// </summary>
    public class Circle : Entity
    {
        public Circle(float x, float y, float radius)
        {
            X = x; Y = y; m_Radius = radius;
        }
        public Circle(float x, float y)
        {
            X = x; Y = y; m_Radius = 0f;
        }
        public Circle(PointF p, float radius)
        {
            X = p.X; Y = p.Y; m_Radius = radius;
        }
        public Circle(PointF p)
        {
            X = p.X; Y = p.Y; m_Radius = 0f;
        }
        public Circle(float radius)
        {
            m_Radius = radius; X = 0f; Y = 0f; 
        }
        private float m_Radius;
        public float Radius { get { return m_Radius; } set { m_Radius = value; } }

        public override void Draw()
        {
            if (m_Filled)
                Paint.FilledCircle(X, Y, m_Radius * this.Scale, this.Tint, this.Resolution);
            else
                Paint.Circle(X, Y, m_Radius * this.Scale, this.Tint, this.Resolution);
            base.Draw();
        }

        public override float Width
        {
            get
            {
                return m_Radius * 2 * this.Scale;
            }
            set
            {
                m_Radius = value / 2 * this.Scale;
            }
        }
        public override float Height
        {
            get
            {
                return m_Radius * 2 * this.Scale;
            }
            set
            {
                m_Radius = value / 2 * this.Scale;
            }
        }

        private bool m_Filled = true;
        public bool Filled { get { return m_Filled; } set { m_Filled = value; } }

        private int m_Resolution = 32;
        public int Resolution { get { return m_Resolution; } set { m_Resolution = value; } }

        public override float Left
        {
            get
            {
                return X + (HotSpot.X - m_Radius) * Math.Abs(this.ScaleX);
            }
            set
            {
                this.X = value - (m_Radius + HotSpot.X) * Math.Abs(ScaleX);
            }
        }
        public override float Top
        {
            get
            {
                return Y + (HotSpot.Y - m_Radius) * Math.Abs(this.ScaleY);
            }
            set
            {
                this.Y = value - (m_Radius + HotSpot.Y) * Math.Abs(ScaleY);
            }
        }
    }
    #endregion Circle

    #region Ellipse
    /// <summary>
    /// A structure defining an ellipse.
    /// </summary>
    public class Ellipse : Entity
    {
        public Ellipse(Circle circle)
        {
            X = circle.X; Y = circle.Y; m_RadiusX = circle.Radius; m_RadiusY = circle.Radius;
        }
        public Ellipse(float x, float y, float radiusX, float radiusY)
        {
            X = x; Y = y; m_RadiusX = radiusX; m_RadiusY = radiusY;
        }
        public Ellipse(float x, float y, float radius)
        {
            X = x; Y = y; m_RadiusX = radius; m_RadiusY = radius;
        }
        public Ellipse(float x, float y)
        {
            X = x; Y = y; m_RadiusX = 0f; m_RadiusY = 0f;
        }
        public Ellipse(float x, float y, SizeF radius)
        {
            X = x; Y = y; m_RadiusX = radius.Width; m_RadiusY = radius.Height;
        }
        public Ellipse(PointF p, float radiusX, float radiusY)
        {
            X = p.X; Y = p.Y; m_RadiusX = radiusX; m_RadiusY = radiusY;
        }
        public Ellipse(PointF p)
        {
            X = p.X; Y = p.Y; m_RadiusX = 0f; m_RadiusY = 0f;
        }
         
        public Ellipse(PointF p, SizeF radius)
        {
            X = p.X; Y = p.Y; m_RadiusX = radius.Width; m_RadiusY = radius.Height;
        }
        public Ellipse(SizeF radius)
        {
            X = 0f; Y = 0f; m_RadiusX = radius.Width; m_RadiusY = radius.Height;
        }
        public Ellipse(float radius)
        {
            m_RadiusX = radius; m_RadiusY = radius; X = 0f; Y = 0f;
        }

        public override float Width
        {
            get
            {
                return m_RadiusX * 2 * this.ScaleY;
            }
            set
            {
                m_RadiusX = value / 2 * this.ScaleY;
            }
        }
        public override float Height
        {
            get
            {
                return m_RadiusY * 2 * this.ScaleY;
            }
            set
            {
                m_RadiusY = value / 2 * this.ScaleY;
            }
        }
        private float m_RadiusX, m_RadiusY;
        public float RadiusX { get { return m_RadiusX; } set { m_RadiusX = value; } }
        public float RadiusY { get { return m_RadiusY; } set { m_RadiusY = value; } }

        public override void Draw()
        {
            if(m_Filled)
                Paint.FilledEllipse(X, Y, m_RadiusX * this.ScaleX, m_RadiusY * this.ScaleY, this.Tint);
            else
                Paint.Ellipse(X, Y, m_RadiusX, m_RadiusY, this.Tint);
        }


        private bool m_Filled = true;
        public bool Filled { get { return m_Filled; } set { m_Filled = value; } }

        private int m_Resolution = 32;
        public int Resolution { get { return m_Resolution; } set { m_Resolution = value; } }

        public override float Left
        {
            get
            {
                return X + (HotSpot.X - RadiusX) * Math.Abs(this.ScaleX);
            }
            set
            {
                this.X = value - (RadiusX + HotSpot.X) * Math.Abs(ScaleX);
            }
        }
        public override float Top
        {
            get
            {
                return Y + (HotSpot.Y - RadiusY) * Math.Abs(this.ScaleY);
            }
            set
            {
                this.Y = value - (RadiusY + HotSpot.Y) * Math.Abs(ScaleY);
            }
        }
    }
    #endregion Ellipse

    #region Rect
    /// <summary>
    /// A structure defining a BooGame rectangle.
    /// </summary>
    public class Rect : Entity
    {
        public Rect(RectangleF rect)
        {
            X = rect.X; Y = rect.Y;
            Width = rect.Width; Height = rect.Height;
        }
        public Rect(float x, float y, float width, float height)
        {
            X = x; Y = y; Width = width; Height = height;
        }
        public Rect(PointF p, SizeF size)
        {
            X = p.X; Y = p.Y;
            Width = size.Width; Height = size.Height;
        }

        private bool m_Filled = true;
        public bool Filled { get { return m_Filled; } set { m_Filled = value; } }

        public override void Draw()
        {
            if (m_Filled)
                Paint.FilledRectangle(X, Y, Width, Height, this.Tint);
            else
                Paint.Rectangle(X, Y, Width, Height, this.Tint);
        }
    }
    #endregion Rect

    #region Polygon
    /// <summary>
    /// Describes the structure of a polygon with multiple points.
    /// </summary>
    public class Polygon : Entity
    {
        public Polygon(Vector point)
        {
            m_Points.Add(point);
        }

        public Polygon(params Vector[] points)
        {
            m_Points.Add(points);
        }

        public Polygon(float x, float y, params Vector[] points) : this(points)
        {
            this.X = x; this.Y = y;
        }

        public Polygon(float x, float y, ColorF color, params Vector[] points) : this(x,y,points)
        {
            this.Tint = color;
        }

        private VectorCollection m_Points = new VectorCollection();

        public override void Draw()
        {
            Paint.FilledPolygon(X, Y, Tint, m_Points);
        }
    }

    #endregion Polygon

    /// <summary>
    /// Module for painting primitive shapes onto the screen.
    /// </summary>
    public sealed class Paint
    {
        #region Constructors
        static Paint()
		{
			Core.Initialize();
        }
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Paint()
        {
        }
        #endregion Constructors

        #region FilledRectangle
        public static void FilledRectangle(RectangleF rect, ColorF color)
        {
            if (color.A <= 0)
                return;
			FilledRectangle(rect.X, rect.Y, rect.Width, rect.Height, color);
        }
        public static void FilledRectangle(Rect rect)
        {
            rect.Filled = true;
            rect.Draw();
        }
		public static void FilledRectangle(float x, float y, float width, float height, ColorF color)
        {
            if (color.A <= 0)
                return;
            Gl.glPushMatrix();
			Gl.glDisable(Gl.GL_TEXTURE_2D);
			Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
			Gl.glBegin(Gl.GL_QUADS);
			{
				Gl.glVertex2f(x, y);
				Gl.glVertex2f(x+width, y);
				Gl.glVertex2f(x+width, y+height);
				Gl.glVertex2f(x, y+height);
			}
			Gl.glEnd();
			Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
		}
        public static void FilledRectangle(PointF location, SizeF size, ColorF color)
        {
            if(color.A > 0)
                FilledRectangle(location.X, location.Y, size.Width, size.Height, color);
        }
        #endregion FilledRectangle
        
        #region Rectangle
        public static void Rectangle(float x, float y, float width, float height, ColorF color)
        {
            if (color.A <= 0)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_LINES);
            {
                Gl.glVertex2f(x, y);
                Gl.glVertex2f(x + width, y);
                Gl.glVertex2f(x + width, y);
                Gl.glVertex2f(x + width, y + height);
                Gl.glVertex2f(x + width, y + height);
                Gl.glVertex2f(x, y + height);
                Gl.glVertex2f(x, y + height);
                Gl.glVertex2f(x, y);
            }
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }

        public static void Rectangle(Rect rect)
        {
            rect.Draw();
        }

        public static void Rectangle(RectangleF rect, ColorF color)
        {
            if (color.A > 0)
                Rectangle(rect.X, rect.Y, rect.Width, rect.Height, color);
        }
        public static void Rectangle(PointF location, SizeF size, ColorF color)
        {
            if(color.A > 0)
                Rectangle(location.X, location.Y, size.Width, size.Height, color);
        }
        #endregion Rectangle

        #region FilledTriangle
        public static void FilledTriangle(PointF p1, PointF p2, PointF p3, ColorF color)
        {
            if (color.A > 0)
			    FilledTriangle(p1.X, p1.Y, p2.X, p2.Y, p3.X, p3.Y, color);
		}
		public static void FilledTriangle(float x1,float y1, float x2, float y2, float x3, float y3, ColorF color)
        {
            if (color.A <= 0)
                return;
            Gl.glPushMatrix();
			Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
			Gl.glBegin(Gl.GL_TRIANGLES);
			{
				Gl.glVertex2f(x1, y1);
				Gl.glVertex2f(x2, y2);
				Gl.glVertex2f(x3, y3);
			}
			Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
		}
        public static void FilledTriangle(Triangle triangle, ColorF color)
        {
            FilledTriangle(triangle.X1, triangle.Y1, triangle.X2, triangle.Y2, triangle.X3, triangle.Y3, color);
        }
        public static void FilledTriangle(Triangle triangle)
        {
            FilledTriangle(triangle.X1, triangle.Y1, triangle.X2, triangle.Y2, triangle.X3, triangle.Y3, triangle.Tint);
        }
        #endregion FilledTriangle
        
        #region Triangle
        public static void Triangle(float x1, float y1, float x2, float y2, float x3, float y3, ColorF color)
        {
            if (color.A <= 0)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_LINES);
            {
                Gl.glVertex2f(x1, y1);
                Gl.glVertex2f(x2, y2);
                Gl.glVertex2f(x2, y2);
                Gl.glVertex2f(x3, y3);
                Gl.glVertex2f(x3, y3);
                Gl.glVertex2f(x1, y1);
            }
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }

        public static void Triangle(PointF p1, PointF p2, PointF p3, ColorF color)
        {
            if (color.A > 0)
                Triangle(p1.X, p1.Y, p2.X, p2.Y, p3.X, p3.Y, color);
        }

        public static void Triangle(Triangle triangle)
        {
            triangle.Draw();
        }
        #endregion Triangle
        
        #region Dot
        public static void Dot(PointF p, ColorF color)
        {
            Dot(p.X, p.Y, color);
		}
        public static void Dot(float x, float y, ColorF color)
        {
            if (color.A <= 0)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_POINTS);
            {
                Gl.glVertex2f(x, y);
            }
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }
        #endregion Dot

        #region Line
        public static void Line(Line line, ColorF color)
        {
            if (color.A > 0)
			    Line(line.X1, line.Y1, line.X2, line.Y2, color);
		}

		public static void Line(PointF p1, PointF p2, ColorF color)
        {
            if (color.A > 0)
			    Line(p1.X, p1.Y, p2.X, p2.Y, color);
		}

		public static void Line(float x1, float y1, float x2, float y2, ColorF color)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
			Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Camera.ApplyMatrix();
			Gl.glBegin(Gl.GL_LINES);
			Gl.glVertex3f(x1, y1, 0f);    // First endpoint of line
			Gl.glVertex3f(x2, y2, 0f);    // Second endpoint of line
			Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }
        #endregion Line

        #region Circle
        public static void Circle(PointF p, float radius, ColorF color, int resolution)
        {
            Ellipse(p.X, p.Y, radius, radius, color, resolution);
        }
        public static void Circle(PointF p, float radius, ColorF color)
        {
            Ellipse(p.X, p.Y, radius, radius, color, 360);
        }
        public static void Circle(float x, float y, float radius, ColorF color, int resolution)
        {
            Ellipse(x, y, radius, radius, color, resolution);
        }
        public static void Circle(float x, float y, float radius, ColorF color)
        {
            Ellipse(x, y, radius, radius, color, 360);
        }
        public static void Circle(Circle circle)
        {
            circle.Draw();
        }
        public static void Circle(Circle circle, ColorF color)
        {
            Circle(circle.X, circle.Y, circle.Radius, circle.Tint, circle.Resolution);
        }
        #endregion Circle
        
        #region FilledCircle
        public static void FilledCircle(float x, float y, float radius, ColorF color, int resolution)
        {
            FilledEllipse(x, y, radius, radius, color, resolution);
        }
        public static void FilledCircle(PointF p, float radius, ColorF color, int resolution)
        {
            FilledEllipse(p.X, p.Y, radius, radius, color, resolution);
        }
        public static void FilledCircle(PointF p, float radius, ColorF color)
        {
            FilledEllipse(p.X, p.Y, radius, radius, color, 360);
        }
        public static void FilledCircle(float x, float y, float radius, ColorF color)
        {
            FilledEllipse(x, y, radius, radius, color, 360);
        }
        public static void FilledCircle(Circle circle, ColorF color)
        {
            FilledCircle(circle.X, circle.Y, circle.Radius, circle.Tint, circle.Resolution);
        }
        #endregion FilledCircle

        #region Ellipse
        public static void Ellipse(PointF p, float xradius, float yradius, ColorF color, int resolution)
        {
            Ellipse(p.X, p.Y, xradius, yradius, color, resolution);
        }
        public static void Ellipse(PointF p, float xradius, float yradius, ColorF color)
        {
            Ellipse(p.X, p.Y, xradius, yradius, color, 360);
        }
        public static void Ellipse(float x, float y, float xradius, float yradius, ColorF color, int resolution)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Gl.glTranslatef(x, y, 0f);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_LINE_STRIP);
            for (int i = 0; i <= resolution; i++)
            {
                float angle = (float)(i * 2) * ((float)Math.PI / (float)resolution);
                Gl.glVertex2d(Math.Cos(angle) * xradius, Math.Sin(angle) * yradius);
            }
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }
        public static void Ellipse(float x, float y, float xradius, float yradius, ColorF color)
        {
            Ellipse(x, y, xradius, yradius, color, 360);
        }
        public static void Ellipse(Ellipse ellipse)
        {
            Ellipse(ellipse.X, ellipse.Y, ellipse.RadiusX, ellipse.RadiusY, ellipse.Tint, ellipse.Resolution);
        }
        #endregion Ellipse

        #region FilledEllipse
        public static void FilledEllipse(float x, float y, float xradius, float yradius, ColorF color, int resolution)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Gl.glTranslatef(x, y, 0f);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_TRIANGLES);
            float vectorY1 = 0f;
            float vectorX1 = 0f;
            for (int i = 0; i <= resolution; i++)
            {
                float angle = (float)(i * 2) * ((float)Math.PI / (float)resolution);
                float vectorX = xradius * (float)Math.Sin((double)angle);
                float vectorY = yradius * (float)Math.Cos((double)angle);
                Gl.glVertex2f(0f, 0f);
                Gl.glVertex2d(vectorX1, vectorY1);
                Gl.glVertex2d(vectorX, vectorY);
                vectorY1 = vectorY;
                vectorX1 = vectorX;
            }
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }
        public static void FilledEllipse(PointF p, float xradius, float yradius, ColorF color, int resolution)
        {
            FilledEllipse(p.X, p.Y, xradius, yradius, color, resolution);
        }
        public static void FilledEllipse(PointF p, float xradius, float yradius, ColorF color)
        {
            FilledEllipse(p.X, p.Y, xradius, yradius, color, 360);
        }
        public static void FilledEllipse(float x, float y, float xradius, float yradius, ColorF color)
        {
            FilledEllipse(x, y, xradius, yradius, color, 360);
        }
        public static void FilledEllipse(Ellipse ellipse)
        {
            FilledEllipse(ellipse.X, ellipse.Y, ellipse.RadiusX, ellipse.RadiusY, ellipse.Tint, ellipse.Resolution);
        }
        #endregion FilledEllipse

        #region FilledPolygon

        public static void FilledPolygon(ColorF color, params Vector[] points)
        {
            FilledPolygon(0,0,color,points);
        }

        public static void FilledPolygon(float x, float y, ColorF color, params Vector[] points)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Gl.glTranslatef(x, y, 0f);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_POLYGON);
            for (int i = 0; i < points.Length; i++)
                Gl.glVertex2f(points[i].X, points[i].Y);
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }

        public static void FilledPolygon(float x, float y, ColorF color, VectorCollection points)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Gl.glTranslatef(x, y, 0f);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_POLYGON);
            foreach(Vector v in points)
                Gl.glVertex2f(v.X, v.Y);
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }

        public static void FilledPolygon(ColorF color, VectorCollection points)
        {
            FilledPolygon(0f, 0f, color, points);
        }

        public static void FilledPolygon(PointF location, ColorF color, VectorCollection points)
        {
            FilledPolygon(location.X, location.Y, color, points);
        }

        public static void FilledPolygon(PointF location, ColorF color, params Vector[] points)
        {
            FilledPolygon(location.X, location.Y, color, points);
        }

        public static void FilledPolygon(float x, float y, ColorF color, params PointF[] points)
        {
            if (color.A <= 0f)
                return;
            Gl.glPushMatrix();
            Gl.glDisable(Gl.GL_TEXTURE_2D);
            Gl.glColor4f(color.R, color.G, color.B, color.A);
            Gl.glTranslatef(x, y, 0f);
            Camera.ApplyMatrix();
            Gl.glBegin(Gl.GL_POLYGON);
            for (int i = 0; i < points.Length; i++)
                Gl.glVertex2f(points[i].X, points[i].Y);
            Gl.glEnd();
            Gl.glEnable(Gl.GL_TEXTURE_2D);
            Gl.glPopMatrix();
        }
        public static void FilledPolygon(ColorF color, params PointF[] points)
        {
            FilledPolygon(0f, 0f, color, points);
        }
        public static void FilledPolygon(PointF location, ColorF color, params PointF[] points)
        {
            FilledPolygon(location.X, location.Y, color, points);
        }

        #endregion FilledPolygon
    }
}
