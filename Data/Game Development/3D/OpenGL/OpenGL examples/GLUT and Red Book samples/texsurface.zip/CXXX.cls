VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: -
'NOTES: Red Book sample
'*************************************************************************
Dim m_Grids As Boolean
Dim ctrlpoints(0 To (4 * 4 - 1)) As POINT3F
Dim texpts(0 To (2 * 2 - 1)) As POINT2F
Dim mblnDisplayed As Boolean
Dim Image() As Byte
Dim imgw&, imgh&

Private Sub Class_Initialize()
'/////  just a flat square canvas
  FillArray3f ctrlpoints(0), -1.5, -1.5, 4
  FillArray3f ctrlpoints(1), -0.5, -1.5, 2
  FillArray3f ctrlpoints(2), 0.5, -1.5, -1
  FillArray3f ctrlpoints(3), 1.5, -1.5, 2
  FillArray3f ctrlpoints(4), -1.5, -0.5, 1
  FillArray3f ctrlpoints(5), -0.5, -0.5, 3
  FillArray3f ctrlpoints(6), 0.5, -0.5, 0
  FillArray3f ctrlpoints(7), 1.5, -0.5, -1
  FillArray3f ctrlpoints(8), -1.5, 0.5, 4
  FillArray3f ctrlpoints(9), -0.5, 0.5, 0
  FillArray3f ctrlpoints(10), 0.5, 0.5, 3
  FillArray3f ctrlpoints(11), 1.5, 0.5, 4
  FillArray3f ctrlpoints(12), -1.5, 1.5, -2
  FillArray3f ctrlpoints(13), -0.5, 1.5, -2
  FillArray3f ctrlpoints(14), 0.5, 1.5, 0
  FillArray3f ctrlpoints(15), 1.5, 1.5, -1
'//// texture coordinates
  FillArray2f texpts(0), 0, 0
  FillArray2f texpts(1), 0, 1
  FillArray2f texpts(2), 1, 0
  FillArray2f texpts(3), 1, 1

    MakeImage2
  mblnDisplayed = False
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    glDisable GL_LIGHTING
'    With gCtl.Lights
'        .SetAmbient 1, 1, 1
'        .TwoSide = True
'    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 0, 0, 10
        .SetTargetPos 0, 0, 0
    End With
    '
'    Set m_Mat = gCtl.NewMaterial
'    With m_Mat
'        .face = faceFront
'        .SetAmbient 0.1, 0.1, 0.1
'        .SetDiffuse 0.5, 1, 1
'        .SetSpecular 0.6, 0.8, 0.8
'        .SpecExp = 120
'    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
'    QuadObj = gluNewQuadric
'    QID = 1 'name for the ball
'    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    
End Sub

Public Sub MakeImage()
    imgw = 2
    imgh = 2
    ReDim Image(0 To 11)
    'green
    Image(0) = 0
    Image(1) = 255
    Image(2) = 0
    'yellow
    Image(3) = 255
    Image(4) = 255
    Image(5) = 0
    'blue
    Image(6) = 0 '255
    Image(7) = 0
    Image(8) = 255
    'black
    Image(9) = 0
    Image(10) = 0
    Image(11) = 0

End Sub

Public Sub MakeImage2()
Dim i&, j&, ti!, tj!
    imgw = 64
    imgh = 64
    ReDim Image(0 To imgw * imgh * 3 - 1)
    For i = 0 To 63
        ti = 2 * PI * (i / 64)
        For j = 0 To 63
            tj = 2 * PI * (j / imgh)
            Image(3 * (imgh * i + j)) = 127 * (1 + Sin(ti))
            Image(3 * (imgh * i + j) + 1) = 127 * (1 + Cos(2 * tj))
            Image(3 * (imgh * i + j) + 2) = 127 * (1 + Cos(ti + tj))
        Next
    Next
End Sub

Public Sub Draw()
    With gCtl
        .Trackball.Update
        'If m_Grids Then .DrawGrids
    End With
    
    glColor3f 1, 1, 1

    If Not mblnDisplayed Then
      glEnable GL_DEPTH_TEST
      glEnable GL_NORMALIZE
      glEnable GL_MAP2_TEXTURE_COORD_2
      glEnable GL_MAP2_VERTEX_3
      glMap2f GL_MAP2_VERTEX_3, 0, 1, 3, 4, _
        0, 1, 12, 4, _
        ctrlpoints(0).p(0)
      glMap2f GL_MAP2_TEXTURE_COORD_2, 0, 1, 2, 2, _
          0, 1, 4, 2, texpts(0).p(0)
      glMapGrid2f 20, 0, 1, 20, 0, 1

'      glTexEnvf GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL
'////////  if i do a GLGetError  I get a GL_INVALID_ENUM = 1280 error??
      '(use the 'i' version, not the 'f'.)
      glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL
      glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP
      glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP
      glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
      glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
      glTexImage2D GL_TEXTURE_2D, 0, 3, imgw, imgh, 0, _
           GL_RGB, GL_UNSIGNED_BYTE, Image(0)
      glEnable GL_TEXTURE_2D

      glShadeModel GL_FLAT

      If glIsList(4) Then glDeleteLists 4, 1
      glNewList 4, GL_COMPILE
        'glEvalMesh2 GL_LINE, 0, 20, 0, 20
        glEvalMesh2 GL_FILL, 0, 20, 0, 20
      glEndList
      mblnDisplayed = True
    Else
      glCallList 4
    End If
    CheckError
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)

End Sub

Public Sub KeyPress(KeyAscii As Integer)
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
End Sub

Public Sub Pick(items() As Long)
End Sub







