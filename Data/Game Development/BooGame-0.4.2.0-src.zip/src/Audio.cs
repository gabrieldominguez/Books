/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

namespace BooGame
{
    /// <summary>
    /// An audio clip that can be played.
    /// </summary>
	[Serializable]
    public class Audio : IDisposable, ISerializable
    {
        #region System Related
        private static FMOD.System m_System = null;

        static Audio()
        {
            ErrorCheck(FMOD.Factory.System_Create(ref m_System), "FMOD failed to create system");
            ErrorCheck(m_System.init(32, FMOD.INITFLAG.NORMAL, (IntPtr)null), "FMOD system failed to initialize");
        }

        #region Lifetime
        /// <summary>
        /// A private object to control the lifetime of the Monostate (calls deconstructor).
        /// </summary>
        private static Lifetime m_Lifetime = new Audio.Lifetime();

        /// <summary>
        /// Private class so that it calls the deconstuctor when the program ends and lifetime is destroyed.
        /// </summary>
        private class Lifetime : IDisposable
        {
            private bool disposed = false;
            public void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    if (disposing)
                    {
                    }
                    ErrorCheck(m_System.close(), "FMOD failed to close");
                    ErrorCheck(m_System.release(),"FMOD failed to release");
                }
                disposed = true;
            }

            public void Dispose()
            {
                Dispose(true);
                System.GC.SuppressFinalize(this);
            }

            ~Lifetime()
            {
                Dispose(false);
            }
        }
        #endregion Lifetime

        #endregion System Related

        #region Audio File Related

        private FMOD.Sound m_Sound = null;
        private FMOD.Channel m_Channel = null;


        /// <summary>
        /// Creates an audio object using a buffer stream from the given file.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static Audio FromStream(string filename)
        {
            return new Audio(filename, true);
        }

        /// <summary>
        /// Creates an audio object from the given file.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static Audio FromFile(string filename)
        {
            return new Audio(filename, false);
        }

        /// <summary>
        /// Disables default constructor.
        /// </summary>
        private Audio()
        {
        }

        /// <summary>
        /// Loads an audio clip from a file.
        /// </summary>
        /// <param name="filename">The file to load.</param>
        public Audio(string filename)
        {
			Load(filename, false);
        }

        /// <summary>
        /// Loads an audio clip from a file.
        /// </summary>
        /// <param name="filename">The file to load.</param>
        /// <param name="stream">To load the audio as a stream (good for saving memory on long audio files). Defaults to false.</param>
        public Audio(string filename, bool stream)
        {
            Load(filename, stream);
		}
		private void Load(string filename, bool stream)
		{
			FMOD.CREATESOUNDEXINFO exinfo = new FMOD.CREATESOUNDEXINFO();

			byte[] audiodata = FileSystem.GetBytes(filename);
			m_Filename = filename;
			m_Streamed = stream;

			exinfo.cbsize = System.Runtime.InteropServices.Marshal.SizeOf(exinfo);
			exinfo.length = (uint)audiodata.Length;

			FMOD.RESULT result;
			if(stream)
				result = m_System.createStream(audiodata, (FMOD.MODE.HARDWARE | FMOD.MODE.OPENMEMORY | FMOD.MODE.CREATESTREAM | FMOD.MODE.MODE_2D), ref exinfo, ref m_Sound);
			else
				result = m_System.createSound(audiodata, (FMOD.MODE.HARDWARE | FMOD.MODE.OPENMEMORY | FMOD.MODE.MODE_2D), ref exinfo, ref m_Sound);
			ErrorCheck(result, "FMOD failed to load audio");
		}

		private bool m_Streamed;
        /// <summary>
        /// Gets whether the current audio object is being streamed.
        /// </summary>
		public bool Streamed
		{
			get
			{
				return m_Streamed;
			}
		}

        /// <summary>
        /// Gets and sets the number of times the sound should loop.
        /// </summary>
        /// <remarks>
        /// 0 = oneshot. 1 = loop once then stop. 2 = loop twice. -1 = loop forever.
        /// </remarks>
        private int m_LoopCount = 0;
        public int LoopCount
        {
            get
            {
                return m_LoopCount;
            }
            set
            {
                m_LoopCount = value;
                m_Sound.setLoopCount(m_LoopCount);
                if (m_Channel != null)
                    m_Channel.setLoopCount(value);
            }
        }
		private string m_Filename;
        /// <summary>
        /// Gets the filename from where the audio was loaded.
        /// </summary>
		public string Filename
		{
			get
			{
				return m_Filename;
			}
		}

        /// <summary>
        /// Plays the current audio object.
        /// </summary>
        public void Play()
        {
            ErrorCheck(m_System.playSound(FMOD.CHANNELINDEX.REUSE, m_Sound, false, ref m_Channel), "FMOD failed to play audio");

            if(m_Volume != 1f)
                ErrorCheck(m_Channel.setVolume(m_Volume), "FMOD failed to set the volume of the sound");
            if(m_Pan != 0f)
                ErrorCheck(m_Channel.setPan(m_Pan), "FMOD failed to set the panning of the sound");
            if (m_Mute != false)
                ErrorCheck(m_Channel.setMute(m_Mute), "FMOD failed to set the mute status of the sound");
            ErrorCheck(m_Channel.setLoopCount(m_LoopCount), "FMOD failed to set loop count");
        }
        /// <summary>
        /// Plays the current audio object with the given number of loops.
        /// </summary>
        /// <param name="loopCount">The number of times to loop.</param>
        public void Play(int loopCount)
        {
            LoopCount = loopCount;
            Play();
        }

        private bool m_Mute = false;
        /// <summary>
        /// Gets and sets whether the audio object is muted.
        /// </summary>
        public bool Mute
        {
            get
            {
                if (m_Channel == null)
                    return m_Mute;
                bool mute = false;
                ErrorCheck(m_Channel.getMute(ref mute), "FMOD failed to get the mute status of the channel");
                return mute;
            }
            set
            {
                m_Mute = value;
                if (m_Channel != null)
                    m_Channel.setMute(m_Mute);
            }
        }

        private float m_Volume = 1f; // 0 to 1
        /// <summary>
        /// Gets and sets the current volume of the audio object from 0 to 1.
        /// </summary>
        public float Volume
        {
            get
            {
                if (m_Channel == null)
                    return m_Volume;
                float vol = 1f;
                ErrorCheck(m_Channel.getVolume(ref vol), "FMOD failed to get the volume of the channel");
                return vol;
            }
            set
            {
                m_Volume = value;
                if (m_Channel != null)
                    m_Channel.setVolume(m_Volume);
            }
        }

        /// <summary>
        /// Stops the audio object from playing.
        /// </summary>
        public void Stop()
        {
            if (m_Channel != null)
                m_Channel.stop();
        }

        /// <summary>
        /// Gets and sets whether the audio is currently playing.
        /// </summary>
		public bool IsPlaying
		{
			get
			{
				bool isplaying = false;
				if(m_Channel != null)
					m_Channel.isPlaying(ref isplaying);
				return isplaying;
			}
			set
			{
				if(value)
				{
					if(!IsPlaying)
						Play();
				}
				else
				{
					if(IsPlaying)
						Stop();
				}
			}
		}

        /// <summary>
        /// Gets the length of the audio clip.
        /// </summary>
        public int Length
        {
            get
            {
                uint length = 0;
                ErrorCheck(m_Sound.getLength(ref length, FMOD.TIMEUNIT.MS),"FMOD failed to get the length of the sound");
                return (int)length;
            }
        }

        /// <summary>
        /// Gets the position of the audio in milliseconds.
        /// </summary>
        public int Position // milliseconds
        {
            get
            {
                if (m_Channel == null)
                    return 0;
                uint position = 0;
                ErrorCheck(m_Channel.getPosition(ref position, FMOD.TIMEUNIT.MS), "FMOD failed to get position of the channel");
                return (int)position;
            }
            set
            {
                if (m_Channel != null)
                    ErrorCheck(m_Channel.setPosition((uint)value, FMOD.TIMEUNIT.MS), "FMOD failed to set the position of the track");
            }
        }

        private float m_Pan = 0f; // -1 to 1
        /// <summary>
        /// Get and sets the panning of the audio from -1 to 1.
        /// </summary>
        public float Pan
        {
            get
            {
                if (m_Channel == null)
                    return m_Pan;
                float pan = 0f;
                ErrorCheck(m_Channel.getPan(ref pan), "FMOD failed to get the panning of the channel");
                return pan;
            }
            set
            {
                m_Pan = value;
                if (m_Channel != null)
                    m_Channel.setPan(m_Pan);
            }
        }

        /// <summary>
        /// Gets and sets whether the audio is currently paused.
        /// </summary>
        public bool Pause
        {
            get
            {
                if (m_Channel == null)
                    return false;
                bool paused = false;
                ErrorCheck(m_Channel.getPaused(ref paused), "FMOD failed to get pause state");
                return paused;
            }
            set
            {
                if(m_Channel != null)
                    ErrorCheck(m_Channel.setPaused(value), "FMOD failed to change pause state");
            }
        }

        private static void ErrorCheck(FMOD.RESULT result, string messageOnFailure)
        {
            if (result != FMOD.RESULT.OK)
                throw new Exception(messageOnFailure + ": " + FMOD.Error.String(result));
        }


        #region Dispose
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if(!this.disposed)
            {
                if(disposing)
                {
                    // Disposed managed resources
                }

                try
                {
					Stop();
                    ErrorCheck(m_Sound.release(), "FMOD failed to dispose audio");
                }
                catch// (AccessViolationException)
                {
                    m_Sound = null;
                }

            }
            disposed = true;         
        }
        private bool disposed = false;

        ~Audio()      
        {
            Dispose(false);
        }
        #endregion Dispose

        #endregion

		#region Serialization
		protected Audio(SerializationInfo info, StreamingContext context)
		{
			Load(info.GetString("filename"), info.GetBoolean("Streamed"));
			this.IsPlaying = info.GetBoolean("IsPlaying");
			this.Position = info.GetInt32("Position");
			this.Mute = info.GetBoolean("Mute");
			this.Pan = info.GetSingle("Pan");
			this.Pause = info.GetBoolean("Pause");
			this.Volume = info.GetSingle("Volume");
		}

		[SecurityPermissionAttribute(SecurityAction.Demand,SerializationFormatter=true)]
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("filename", m_Filename);
			info.AddValue("Streamed", m_Streamed);
			info.AddValue("IsPlaying", IsPlaying);
			info.AddValue("Position", Position);
			info.AddValue("Mute", Mute);
			info.AddValue("Pan", Pan);
			info.AddValue("Pause", Pause);
			info.AddValue("Volume", Volume);

		}
		#endregion Serialization
    }
}
