class AwesomeInfo extends Info
    placeable;

var StaticMeshComponent MyMeshComponent;
var Material GreenMat, RedMat;

simulated function OnToggle(SeqAct_Toggle Action)
{
    if(Action.InputLinks[2].bHasImpulse)
    {
        if(MyMeshComponent.GetMaterial(0) == GreenMat)
            MyMeshComponent.SetMaterial(0, RedMat);
        else
            MyMeshComponent.SetMaterial(0, GreenMat);
    }
}

defaultproperties
{
    GreenMat=Material'EditorMaterials.WidgetMaterial_Y'
    RedMat=Material'EditorMaterials.WidgetMaterial_X'

    Begin Object Class=StaticMeshComponent Name=MyMesh
        StaticMesh=StaticMesh'UN_SimpleMeshes.TexPropCube_Dup'
        Materials(0)=Material'EditorMaterials.WidgetMaterial_Y'
        Scale3D=(X=0.25,Y=0.25,Z=0.25)
    End Object
    Components.Add(MyMesh)
    MyMeshComponent=MyMesh

    bHidden=false
}
