Attribute VB_Name = "gleVectors"
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'   - only the macros used by the code are shown here
'HISTORY:
'   Feb 99 - deleted unused stuff and moved most of
'           the rest to glxVectors to consolidate.
'           The stuff here is used only by GLE
'   Feb 98 - added new routines and renamed them
' * Written by Linas Vepstas, August 1991
' * Added 2D code, March 1993
' * Added Outer products, C++ proofed, Linas Vepstas October 1993
'   - added float versions
' * vvector.h
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'called by GenSpiral
'each m(0 to 1, 0 to 1)
Public Sub MatCopy2X2d(mdest#(), m#())
   mdest(0, 0) = m(0, 0)
   mdest(0, 1) = m(0, 1)
   mdest(1, 0) = m(1, 0)
   mdest(1, 1) = m(1, 1)
End Sub

'-------------------------------------------------------------------------
'called by GenSpiral
'mdest(0 to 1, 0 to 1)
Public Sub MatCopy2X2Ad(mdest#(), m As gleAffine)
   mdest(0, 0) = m.v0(0)
   mdest(0, 1) = m.v0(1)
   mdest(1, 0) = m.v1(0)
   mdest(1, 1) = m.v1(1)
End Sub

Public Sub MatCopy3X3d(mdest As gleAffine, m As gleAffine)
   mdest.v0(0) = m.v0(0)
   mdest.v0(1) = m.v0(1)
   mdest.v0(2) = m.v0(2)
   mdest.v1(0) = m.v1(0)
   mdest.v1(1) = m.v1(1)
   mdest.v1(2) = m.v1(2)
End Sub

'called by Genspiral
'each m(0 to 1, 0 to 1)
Public Sub MatMultiply2X2d(mdest#(), m1#(), m2#())
   mdest(0, 0) = m1(0, 0) * m2(0, 0) + m1(0, 1) * m2(1, 0)
   mdest(0, 1) = m1(0, 0) * m2(0, 1) + m1(0, 1) * m2(1, 1)
   mdest(1, 0) = m1(1, 0) * m2(0, 0) + m1(1, 1) * m2(1, 0)
   mdest(1, 1) = m1(1, 0) * m2(0, 1) + m1(1, 1) * m2(1, 1)
End Sub

'-------------------------------------------------------------------------
' affine matrix times vector
' The matrix is assumed to be an affine matrix, with last two
' * entries representing a translation
Public Sub MatDotVectorAd(p#(), m As gleAffine, v#())
    p(0) = m.v0(0) * v(0) + m.v0(1) * v(1) + m.v0(2)
    p(1) = m.v1(0) * v(0) + m.v1(1) * v(1) + m.v1(2)
End Sub

'-------------------------------------------------------------------------
'' transform normal vector by inverse transpose of matrix
'' * and then renormalize the vector
'' *
'' * This macro computes inverse transpose of matrix m,
'' * and multiplies vector v into it, to yeild vector p
'' * Vector p is then normalized.
Public Sub NORM_XFORM_2X2(p#(), m As gleAffine, v#())
Dim lng#
'm=xform_array()(2)(3))
    ' do nothing if off-diagonals are zero and diagonals are
    ' * equal
    If ((m.v0(1) <> 0) Or _
        (m.v1(0) <> 0) Or _
        (m.v0(0) <> m.v1(1))) Then
            p(0) = m.v1(1) * v(0) - m.v1(0) * v(1)
            p(1) = -m.v0(1) * v(0) + m.v0(0) * v(1)

        lng = p(0) * p(0) + p(1) * p(1)
        'division by zero
        If lng = 0 Then
            Debug.Assert 0
            lng = 0.0000000001
        End If
        lng = 1 / Sqr(lng)
        p(0) = p(0) * lng
        p(1) = p(1) * lng
    Else
        V2Copyd p, v
    End If
End Sub


