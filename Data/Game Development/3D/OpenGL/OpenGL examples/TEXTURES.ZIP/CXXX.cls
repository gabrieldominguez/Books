VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net
'HISTORY:
'NOTES: The code in the mTexture module shows how to load bmps,
'jpgs, & gifs using VB. Press F12 to toggle through materials.
'Opacity is the alpha supplied when reading RGB images and
'preparing them as RGBA.
'You can set transparency and other effects through the form.
'This doesn't show a 'billboard' or transparent effect like a transparent
'gif, but it does have code in mTexture to set the texture's alpha
'from a pixel or a mask color. I'll return to billboarded trees
'in another sample. You can see transparency by checking 'Mask color'
' and 'Blend'. Also missing is a way to vary texture offsets, angles, and repeat.
'This could use a few more controls, but it was
'getting busy so I stopped it here.
'*************************************************************************
Dim m_SphereMat As glxMaterial
Dim m_SphereMat2 As glxMaterial
Dim m_BoxMat As glxMaterial
Dim QuadObj&
Dim QuadObj2&
Public Texture As Boolean
Public Model&
Dim m_UseMask As Boolean
Dim m_Headlight As Boolean
Dim m_Tex As glxTexture
Dim m_Wireframe As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
'blend function
Dim m_Sfactor&, m_Dfactor&
'filter
Dim m_MAG&, m_MIN&
Dim m_Opacity!
Dim m_Blend As Boolean
Dim m_MaskColor&


Private Sub Class_Initialize()
    Model = 2
    Texture = True
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
Dim r As Boolean
Dim c!(0 To 3)
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 0, 10, 10
        .Enabled = True
    End With
'    With gCtl.Lights
'        .TwoSide = True
'    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos -1, 3, 4
        .SetTargetPos 0, 0, 0
    End With
    '
    'weird problem here:
    Set m_SphereMat = gCtl.NewMaterial
    'the above doesn't fail when using the source code of the ocx
    'is this just my machine?
    With m_SphereMat
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetSpecular 0.8, 0.8, 0.8
        .SpecExp = 120
    End With
    Set m_BoxMat = gCtl.NewMaterial
    With m_BoxMat
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.2, 0.2, 0.5
        .SetSpecular 0.2, 0.2, 0.5
        .SpecExp = 30
        .Shininess = 0.2
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .Axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
    glEnable GL_CULL_FACE
    QuadObj = gluNewQuadric
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    '
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    '
    'we'll set these values, but by setting the values in the form,'
    'which will call properties to set them:
    'glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
    'glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
    'glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    'glTexGeni GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
    'glTexGeni GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
    With frmMain
        .optMag(0).value = True
        .optMin(0).value = True
        .optTexEnv(1).value = True
        .optTexGen(0).value = True
    End With
    '
    'set a blend color
    'c(0) = 0.2: c(1) = 0.2: c(2) = 0.8: c(3) = 0.1
    'glTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, c(0)
    '
    'the box in the ocx has no texture coord's
    'set this if you want texture on glu geometry
    gluQuadricTexture QuadObj, 1
    '
    '
    'for transparency
    'm_Sfactor = GL_SRC_ALPHA
    'm_Dfactor = GL_ONE_MINUS_SRC_ALPHA
    'glBlendFunc m_Sfactor, m_Dfactor
    With frmMain
        .List1.ListIndex = 1 'default '4
        .List2.ListIndex = 0 'default '5
        .txtOpacity = "1"
    End With
    'load a texture
    UsePicture frmMain.Image1
    CheckError
End Sub

Public Sub InitGL2()
Const o = 1.2
Dim c!(0 To 3)
    glClearColor 0, 0, 0, 0
    With gCtl2.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 2, 2, 10
        .Enabled = True
    End With
    With gCtl2.Camera
        .FarPlane = 100
        .NearPlane = -100
        .SetOrthoEyePos 0, 0, 0
        .SetOrtho -o, o, -o, o
        .View = glxOrtho
    End With
    '
    
    glEnable GL_CULL_FACE
    QuadObj2 = gluNewQuadric
    '
    Set m_SphereMat2 = gCtl2.NewMaterial
    With m_SphereMat2
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetSpecular 0.8, 0.8, 0.8
        .SpecExp = 120
    End With
    m_SphereMat2.SetMaterial
    NextMaterial True
End Sub

'----------------------------------------------------------------------------
'----------------------------------------------------------------------------
Public Sub Draw()
    gCtl.Trackball.Update
    If m_Grids Then gCtl.DrawGrids
    If m_Headlight = 0 Then
        gCtl.Lights.Item(liLight0).SetPosition 0, 10, 10
    End If
    '
    With gCtl.Shapes
    'the model is transparent to this box
    glPushMatrix
        glTranslatef 0, -1, 0
        m_BoxMat.SetMaterial
        .Box 1, 0.1, 1
    glPopMatrix
    '
    glPushAttrib amAllAttribBits
    If Texture Then glEnable GL_TEXTURE_2D
    If m_Blend Then glEnable GL_BLEND
    If m_UseMask Then
        'glDepthMask 0
        glEnable GL_BLEND
        glEnable GL_ALPHA_TEST
    End If
    '
    m_SphereMat.SetMaterial
    Select Case Model
    Case 1 'glxbox - must let gl generate tex coords.
        glEnable GL_TEXTURE_GEN_S
        glEnable GL_TEXTURE_GEN_T
        .Box 2, 2, 2
        glDisable GL_TEXTURE_GEN_S
        glDisable GL_TEXTURE_GEN_T
    Case 2 'glusphere - glu will generate tex coords.
        gluSphere QuadObj, 1, 16, 16
    Case 3 'explicit tex coords.
        DrawBox 1
    End Select
    glPopAttrib
    '
    'the model is opaque to this one
    glPushMatrix
        glTranslatef 0, -2, 0
        m_BoxMat.SetMaterial
        .Box 3, 0.1, 3
    glPopMatrix
    '
    CheckError
    End With
End Sub

'----------------------------------------------------------------------------
'----------------------------------------------------------------------------
Public Sub Draw2()
    gluSphere QuadObj2, 1, 32, 32
    CheckError
End Sub

Public Function Reshape(Width&, Height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    '
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 2 Then gCtl.Render
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      '
End Sub

Public Sub Pick(items() As Long)
'
End Sub

'----------------------------------------------------------------------------
'draw a box with explicit tex coords
'----------------------------------------------------------------------------
Public Sub DrawBox(x!)
    'front
    glBegin GL_POLYGON
        glNormal3d 0, 0, 1
        glTexCoord2f 0, 0
        glVertex3d -x, -x, x
        glTexCoord2f 1, 0
        glVertex3d x, -x, x
        glTexCoord2f 1, 1
        glVertex3d x, x, x
        glTexCoord2f 0, 1
        glVertex3d -x, x, x
    glEnd
    'back
    glBegin GL_POLYGON
        glNormal3d 0, 0, -1
        glTexCoord2f 0, 0
        glVertex3d x, -x, -x
        glTexCoord2f 1, 0
        glVertex3d -x, -x, -x
        glTexCoord2f 1, 1
        glVertex3d -x, x, -x
        glTexCoord2f 0, 1
        glVertex3d x, x, -x
    glEnd
    'right
    glBegin GL_POLYGON
        glNormal3d 1, 0, 0
        glTexCoord2f 0, 0
        glVertex3d x, -x, x
        glTexCoord2f 1, 0
        glVertex3d x, -x, -x
        glTexCoord2f 1, 1
        glVertex3d x, x, -x
        glTexCoord2f 0, 1
        glVertex3d x, x, x
    glEnd
    'left
    glBegin GL_POLYGON
        glNormal3d -1, 0, 0
        glTexCoord2f 0, 0
        glVertex3d -x, -x, -x
        glTexCoord2f 1, 0
        glVertex3d -x, -x, x
        glTexCoord2f 1, 1
        glVertex3d -x, x, x
        glTexCoord2f 0, 1
        glVertex3d -x, x, -x
    glEnd
    'bottom
    glBegin GL_POLYGON
        glNormal3d 0, -1, 0
        glTexCoord2f 0, 0
        glVertex3d -x, -x, -x
        glTexCoord2f 1, 0
        glVertex3d x, -x, -x
        glTexCoord2f 1, 1
        glVertex3d x, -x, x
        glTexCoord2f 0, 1
        glVertex3d -x, -x, x
    glEnd
    'top
    glBegin GL_POLYGON
        glNormal3d 0, 1, 0
        glTexCoord2f 0, 0
        glVertex3d -x, x, x
        glTexCoord2f 1, 0
        glVertex3d x, x, x
        glTexCoord2f 1, 1
        glVertex3d x, x, -x
        glTexCoord2f 0, 1
        glVertex3d -x, x, -x
    glEnd
End Sub

'----------------------------------------------------------------------------
'Polygon mode
'----------------------------------------------------------------------------
Public Property Get Wireframe() As Boolean
Wireframe = m_Wireframe
End Property

Public Property Let Wireframe(ByVal NewValue As Boolean)
m_Wireframe = NewValue
If m_Wireframe Then
     glPolygonMode GL_FRONT_AND_BACK, GL_LINE
Else
    glPolygonMode GL_FRONT_AND_BACK, GL_FILL
End If
gCtl.Render
End Property

'----------------------------------------------------------------------------
'toggles through the predefined materials in the ocx
'DontChange is a hack to let me populate the textboxes
'----------------------------------------------------------------------------
Public Sub NextMaterial(Optional DontChange)
Static IDX&
Dim v!(0 To 3)
    If IsMissing(DontChange) Then
        IDX = IDX + 1
        If IDX > 27 Then IDX = 0
        Set m_SphereMat = Nothing
        Set m_SphereMat = gCtl.Materials.GetMaterialIndex(IDX)
    End If
    m_SphereMat.SetMaterial
    'the class has no 'get' functions, so get it from gl
    With frmMain
    glGetMaterialfv GL_FRONT, GL_AMBIENT, v(0)
    .txtMat(0) = v(0): .txtMat(1) = v(1)
    .txtMat(2) = v(2): .txtMat(3) = v(3)
    glGetMaterialfv GL_FRONT, GL_DIFFUSE, v(0)
    .txtMat(4) = v(0): .txtMat(5) = v(1)
    .txtMat(6) = v(2): .txtMat(7) = v(3)
    glGetMaterialfv GL_FRONT, GL_SPECULAR, v(0)
    .txtMat(8) = v(0): .txtMat(9) = v(1)
    .txtMat(10) = v(2): .txtMat(11) = v(3)
    End With
gCtl.Render
gCtl2.MakeCurrent
m_SphereMat.SetMaterial
gCtl2.Render
End Sub

'----------------------------------------------------------------------------
'note that many of the materials have .5 alpha. This lets you change
'the materials
'----------------------------------------------------------------------------
Public Sub SetMaterial(index&, v!())
With m_SphereMat
    Select Case index
    Case 0
        .SetAmbient v(0), v(1), v(2), v(3)
    Case 1
        .SetDiffuse v(0), v(1), v(2), v(3)
    Case 2
        .SetSpecular v(0), v(1), v(2), v(3)
    End Select
End With
With m_SphereMat2
    Select Case index
    Case 0
        .SetAmbient v(0), v(1), v(2), v(3)
    Case 1
        .SetDiffuse v(0), v(1), v(2), v(3)
    Case 2
        .SetSpecular v(0), v(1), v(2), v(3)
    End Select
End With
gCtl.Render
gCtl2.Render
End Sub

'----------------------------------------------------------------------------
'Texture file
'----------------------------------------------------------------------------

'----------------------------------------------------------------------------
'load a file from disk using the ocx code
'this is only for bmps, and sgi image files(bw,la,rgb,rgba)
'this isn't called - you can change the file open code
'to call it for sgi files.
'----------------------------------------------------------------------------
Public Property Let TextureFile(ByVal File$)
Dim r As Boolean
    Set m_Tex = Nothing
    Set m_Tex = gCtl.NewTexture
    r = m_Tex.LoadTextureFile(File)
    If r <> True Then Debug.Assert 0
    m_Tex.SetTexture
    frmMain.Loader = LoadPicture("")
gCtl.Render
End Property

'----------------------------------------------------------------------------
'use a texture generated by code (in the ocx)
'----------------------------------------------------------------------------
Public Sub UseCheck()
    Set m_Tex = Nothing
    Set m_Tex = gCtl.NewTexture
    m_Tex.CreateCheckTexture
    m_Tex.SetTexture
    frmMain.Loader = LoadPicture("")
gCtl.Render
End Sub

'----------------------------------------------------------------------------
'load a image resource and use as texture (from the ocx)
'----------------------------------------------------------------------------
Public Sub UseResource()
    Set m_Tex = Nothing
    Set m_Tex = gCtl.NewTexture
    m_Tex.LoadTextureResource (101)
    frmMain.Loader = LoadPicture("")
gCtl.Render
End Sub

'----------------------------------------------------------------------------
'use an image loaded by VB, from a picturebox, image, or file
'this can be any type of file recognized by VB
'----------------------------------------------------------------------------
Public Sub UsePicture(Pic As Picture)
Dim Width&, Height&, Components&, fm&
Dim imgdata() As Byte
    Set m_Tex = Nothing
    FixPictureRGBA Pic, Width, Height, Components, fm, imgdata
    glTexImage2D GL_TEXTURE_2D, 0, Components, Width, Height, 0, _
         fm, GL_UNSIGNED_BYTE, imgdata(0)

    frmMain.Loader = Pic
gCtl.Render
End Sub

'----------------------------------------------------------------------------
'TexGenMode - how tex coords are generated
'----------------------------------------------------------------------------
Public Property Let TexGenMode(n&)
Dim x&
    Select Case n
    Case 0: x = GL_OBJECT_LINEAR
    Case 1: x = GL_EYE_LINEAR
    Case 2: x = GL_SPHERE_MAP
    End Select
    glTexGeni GL_S, GL_TEXTURE_GEN_MODE, x
    glTexGeni GL_T, GL_TEXTURE_GEN_MODE, x
gCtl.Render
End Property

'----------------------------------------------------------------------------
'TexEnv - how the texture is combined with existing color
'----------------------------------------------------------------------------
Public Property Let TexEnvMode(n&)
Dim x&
    Select Case n
    Case 0: x = GL_DECAL
        m_Blend = False
    Case 1: x = GL_MODULATE
        m_Blend = False
    Case 2:
        x = GL_BLEND
        m_Blend = True
    End Select
    glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, x
gCtl.Render
End Property

'----------------------------------------------------------------------------
'Blend factors
'----------------------------------------------------------------------------
Public Sub Blend(factor&, value&)
Dim x&
    Select Case value
    Case 1: x = GL_ZERO
    Case 2: x = GL_ONE
    Case 3: x = GL_DST_COLOR
    Case 4: x = GL_ONE_MINUS_DST_COLOR
    Case 5: x = GL_SRC_ALPHA
    Case 6: x = GL_ONE_MINUS_SRC_ALPHA
    Case 7: x = GL_DST_ALPHA
    Case 8: x = GL_ONE_MINUS_DST_ALPHA
    Case 9: x = GL_SRC_ALPHA_SATURATE
    End Select
    If factor = 1 Then
        m_Sfactor = x
    Else
        m_Dfactor = x
    End If
    glBlendFunc m_Sfactor, m_Dfactor
gCtl.Render
End Sub

'----------------------------------------------------------------------------
'MAG and MIN filters
'these are per texture settings, but we only have 1 texture
'----------------------------------------------------------------------------
Public Property Get MAG&()
MAG = m_MAG
End Property

Public Property Let MAG(ByVal NewValue&)
m_MAG = NewValue
If m_MAG = 1 Then
    MAGLinear
Else: MAGNearest
End If
gCtl.Render
End Property

Public Property Get Min&()
Min = m_MIN
End Property

Public Property Let Min(ByVal NewValue&)
m_MIN = NewValue
If m_MIN = 1 Then
    MINLinear
Else: MINNearest
End If
gCtl.Render
End Property

Public Sub MAGLinear()
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
End Sub

Public Sub MAGNearest()
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
End Sub

Public Sub MINLinear()
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
End Sub

Public Sub MINNearest()
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
End Sub

'----------------------------------------------------------------------------
'controls whether the light pos is fixed in relation
'to the scene or the viewer
'----------------------------------------------------------------------------
Public Property Get Headlight() As Boolean
Headlight = m_Headlight
End Property

Public Property Let Headlight(ByVal NewValue As Boolean)
m_Headlight = NewValue
If m_Headlight Then
    glMatrixMode GL_MODELVIEW
    glPushMatrix
    glLoadIdentity
    With gCtl.Lights.Item(liLight0)
        .SetPosition 0, 3, 10
    End With
    glPopMatrix
End If
gCtl.Render
End Property

'----------------------------------------------------------------------------
'sets the alpha which will be supplied when a Picture is loaded
'----------------------------------------------------------------------------
Public Property Get Opacity!()
Opacity = m_Opacity
End Property

Public Property Let Opacity(ByVal NewValue!)
m_Opacity = NewValue
End Property

'----------------------------------------------------------------------------
'mask color and/or UseMask must be set before an image is loaded if you want the alpha channel
'to get set from a color or pixel.
'----------------------------------------------------------------------------
Public Property Get MaskColor&()
    MaskColor = m_MaskColor
End Property

Public Property Let MaskColor(ByVal Color&)
    m_MaskColor = Color
End Property

Public Property Get UseMask() As Boolean
    UseMask = m_UseMask
End Property

Public Property Let UseMask(ByVal NewValue As Boolean)
    m_UseMask = NewValue
    If m_UseMask Then
        glAlphaFunc GL_GREATER, 0.5
    Else
        glDisable GL_ALPHA_TEST
    End If
    gCtl.Render
End Property
