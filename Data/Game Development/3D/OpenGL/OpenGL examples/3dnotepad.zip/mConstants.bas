Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CXXX
Public Areas As CAreas
Public Images As CImages
Public Fonts As CFontTextures
Public Manipulator As CManipulator
Public Panorama As CBackground
'
Public dlgTextX!, dlgTextY!
Public dlgPropX!, dlgPropY!
Public optCopyImages As Boolean
'
Dim m_NextID&
'
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type
Type V3F
    v(0 To 2) As Single
End Type
Type V4I
    v(0 To 3) As Long
End Type
Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (dest As Byte, Src As Byte, ByVal length&)

'----------------------------------------------------------------------------
Public Sub CheckError()
Dim s$
    s = gCtl.GetErr
    If Len(s) Then
    Debug.Print s
    Debug.Assert 0
    End If
End Sub

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

'set current color from RGB255 values
Public Sub glColor32(Color&)
Dim r%, g%, b%
    r = GetRValue(Color)
    g = GetGValue(Color)
    b = GetBValue(Color)
    glColor3f r / 255, g / 255, b / 255
End Sub

'return the 255 values for the color components
Public Function GetRValue(X As Long) As Byte
    GetRValue = (X \ &H10000) And &HFF
End Function

Public Function GetGValue(X As Long) As Byte
    GetGValue = (X \ &H100) And &HFF
End Function

Public Function GetBValue(X As Long) As Byte
    GetBValue = X And &HFF
End Function

Public Function DegToRad(a)
DegToRad = a * PI * ONE_OVER_180
End Function

Public Function RadToDeg(a)
RadToDeg = (a * 180) * ONE_OVER_PI
End Function

'----------------------------------------------------------------------------
Public Sub FillArray3f(a() As V3F, ParamArray n())
Dim v, i&, j&
    For Each v In n
        a(i).v(j) = v
        j = j + 1
        If j > 2 Then
            i = i + 1
            j = 0
        End If
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArray4i(a() As V4I, ParamArray n())
Dim v, i&, j&
    For Each v In n
        a(i).v(j) = v
        j = j + 1
        If j > 3 Then
            i = i + 1
            j = 0
        End If
    Next
End Sub

'------------------------------------
'return pos of last occurence of char$
'------------------------------------
Public Function GetLast&(s$, char$)
Dim i&
On Error Resume Next
For i = Len(s) To 1 Step -1
    If mId$(s, i, 1) = char Then
        GetLast = i: Exit Function
    End If
Next
End Function




Public Sub Main()
optCopyImages = True
Set gCtl = frmMain.glxCtl1
Set CX = New CXXX
gCtl.Init
frmMain.Show
End Sub

'----------------------------------------------------------------------------
Public Function NextID&()
    m_NextID = m_NextID + 1
    NextID = m_NextID
End Function

'returns all text to right of last '\', else all text
Public Function ExtractFileName$(ByVal fil$)
Dim r&, s$
'------------------------------------
On Error Resume Next
    r = GetLast(fil, "\")
    If r = 0 Then
        ExtractFileName = fil
    Else
        ExtractFileName = mId$(fil, r + 1)
    End If
End Function

'returns all text to right of last '\', else all text
Public Function ExtractPath$(ByVal fil$)
Dim r&, s$
'------------------------------------
On Error Resume Next
    r = GetLast(fil, "\")
    If r = 0 Then
        ExtractPath = fil
    Else
        ExtractPath = Left$(fil, r - 1)
    End If
End Function

'returns the file extension or nothing
Public Function ExtractExt$(ByVal fil$)
Dim r&, s$
'------------------------------------
On Error Resume Next
    r = GetLast(fil, ".")
    If r Then
        ExtractExt = mId$(fil, r + 1)
    End If
End Function

'returns the name w/out extension or fil
Public Function ExtractName$(ByVal fil$)
Dim r&, s$
'------------------------------------
On Error Resume Next
    r = GetLast(fil, ".")
    If r Then
        ExtractName = Left$(fil, r - 1)
    End If
End Function



