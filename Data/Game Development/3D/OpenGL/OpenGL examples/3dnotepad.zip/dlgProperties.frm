VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form dlgProperties 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Properties"
   ClientHeight    =   3210
   ClientLeft      =   3195
   ClientTop       =   2595
   ClientWidth     =   4830
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   214
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   322
   ShowInTaskbar   =   0   'False
   Begin VB.PictureBox Pic 
      BorderStyle     =   0  'None
      Height          =   2655
      Index           =   0
      Left            =   5340
      ScaleHeight     =   177
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   275
      TabIndex        =   20
      Top             =   2160
      Width           =   4125
      Begin VB.TextBox txtPos 
         Height          =   315
         Index           =   2
         Left            =   2610
         TabIndex        =   29
         Top             =   210
         Width           =   555
      End
      Begin VB.TextBox txtPos 
         Height          =   315
         Index           =   1
         Left            =   2010
         TabIndex        =   28
         Top             =   210
         Width           =   555
      End
      Begin VB.TextBox txtPos 
         Height          =   315
         Index           =   0
         Left            =   1410
         TabIndex        =   27
         Top             =   210
         Width           =   555
      End
      Begin VB.TextBox txtRot 
         Height          =   315
         Index           =   0
         Left            =   1410
         TabIndex        =   26
         Top             =   600
         Width           =   555
      End
      Begin VB.TextBox txtRot 
         Height          =   315
         Index           =   1
         Left            =   2010
         TabIndex        =   25
         Top             =   600
         Width           =   555
      End
      Begin VB.TextBox txtRot 
         Height          =   315
         Index           =   2
         Left            =   2610
         TabIndex        =   24
         Top             =   600
         Width           =   555
      End
      Begin VB.TextBox txtRot 
         Height          =   315
         Index           =   3
         Left            =   3210
         TabIndex        =   23
         Top             =   600
         Width           =   555
      End
      Begin VB.TextBox txtHeight 
         Height          =   315
         Left            =   2940
         TabIndex        =   22
         Top             =   990
         Width           =   855
      End
      Begin VB.TextBox txtWidth 
         Height          =   315
         Left            =   1410
         TabIndex        =   21
         Top             =   990
         Width           =   855
      End
      Begin VB.Label lblTrans 
         Caption         =   "Translation:"
         Height          =   285
         Left            =   480
         TabIndex        =   33
         Top             =   270
         Width           =   915
      End
      Begin VB.Label lblRot 
         Caption         =   "Rotation:"
         Height          =   285
         Left            =   630
         TabIndex        =   32
         Top             =   690
         Width           =   705
      End
      Begin VB.Label lblHeight 
         Caption         =   "Height:"
         Height          =   285
         Left            =   2430
         TabIndex        =   31
         Top             =   1020
         Width           =   555
      End
      Begin VB.Label lblWidth 
         Caption         =   "Width:"
         Height          =   285
         Left            =   840
         TabIndex        =   30
         Top             =   1050
         Width           =   555
      End
   End
   Begin VB.PictureBox Pic 
      BorderStyle     =   0  'None
      Height          =   2535
      Index           =   1
      Left            =   5340
      ScaleHeight     =   169
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   280
      TabIndex        =   11
      Top             =   360
      Visible         =   0   'False
      Width           =   4200
      Begin VB.CommandButton btnColor 
         Height          =   315
         Left            =   2820
         TabIndex        =   15
         Top             =   600
         Width           =   300
      End
      Begin VB.ComboBox cmbFont 
         Height          =   315
         Left            =   1410
         Style           =   2  'Dropdown List
         TabIndex        =   14
         Top             =   210
         Width           =   1755
      End
      Begin VB.TextBox txtScale 
         Height          =   315
         Index           =   1
         Left            =   2010
         TabIndex        =   13
         Top             =   990
         Width           =   555
      End
      Begin VB.TextBox txtScale 
         Height          =   315
         Index           =   0
         Left            =   1410
         TabIndex        =   12
         Top             =   990
         Width           =   555
      End
      Begin VB.Label lblFontColor 
         BorderStyle     =   1  'Fixed Single
         Height          =   315
         Left            =   1410
         TabIndex        =   19
         Top             =   600
         Width           =   1305
      End
      Begin VB.Label lblFColor 
         Caption         =   "Color:"
         Height          =   255
         Left            =   870
         TabIndex        =   18
         Top             =   660
         Width           =   405
      End
      Begin VB.Label lblFont 
         Caption         =   "Font:"
         Height          =   255
         Left            =   900
         TabIndex        =   17
         Top             =   270
         Width           =   585
      End
      Begin VB.Label lblScale 
         Caption         =   "Scale:"
         Height          =   195
         Left            =   840
         TabIndex        =   16
         Top             =   1050
         Width           =   465
      End
   End
   Begin VB.PictureBox Pic 
      BorderStyle     =   0  'None
      Height          =   2400
      Index           =   2
      Left            =   180
      ScaleHeight     =   160
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   280
      TabIndex        =   1
      Top             =   510
      Visible         =   0   'False
      Width           =   4200
      Begin VB.ComboBox cmbBorder 
         Height          =   315
         ItemData        =   "dlgProperties.frx":0000
         Left            =   1410
         List            =   "dlgProperties.frx":0010
         Style           =   2  'Dropdown List
         TabIndex        =   7
         Top             =   600
         Width           =   1395
      End
      Begin VB.CommandButton btnBorder 
         Height          =   315
         Left            =   2880
         TabIndex        =   6
         Top             =   600
         Width           =   300
      End
      Begin VB.CommandButton btnBkg 
         Height          =   315
         Left            =   2880
         TabIndex        =   5
         Top             =   210
         Width           =   300
      End
      Begin VB.ComboBox cmbBkg 
         Height          =   315
         ItemData        =   "dlgProperties.frx":002C
         Left            =   1410
         List            =   "dlgProperties.frx":0039
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   210
         Width           =   1395
      End
      Begin VB.TextBox txtScale 
         Height          =   315
         Index           =   3
         Left            =   1410
         TabIndex        =   3
         Top             =   990
         Width           =   555
      End
      Begin VB.TextBox txtScale 
         Height          =   315
         Index           =   2
         Left            =   2010
         TabIndex        =   2
         Top             =   990
         Width           =   555
      End
      Begin VB.Label lblBorder 
         Caption         =   "Border:"
         Height          =   255
         Left            =   780
         TabIndex        =   10
         Top             =   660
         Width           =   585
      End
      Begin VB.Label lblBkg 
         Caption         =   "Bkg:"
         Height          =   255
         Left            =   960
         TabIndex        =   9
         Top             =   270
         Width           =   405
      End
      Begin VB.Label lblTile 
         Alignment       =   1  'Right Justify
         Caption         =   "Tile:"
         Height          =   195
         Left            =   690
         TabIndex        =   8
         Top             =   1050
         Width           =   585
      End
   End
   Begin MSComctlLib.TabStrip TS 
      Height          =   3165
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4815
      _ExtentX        =   8493
      _ExtentY        =   5583
      MultiRow        =   -1  'True
      _Version        =   393216
      BeginProperty Tabs {1EFB6598-857C-11D1-B16A-00C0F0283628} 
         NumTabs         =   3
         BeginProperty Tab1 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Position"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Font"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Image"
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "dlgProperties"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim CD As CommonDialog
Dim Loading As Boolean
Dim a As CArea
Dim F As Form

Private Sub btnBorder_Click()
On Error Resume Next
    CD.Color = Areas.SelectedArea.BorderColor
    CD.ShowColor
    If Error Then Exit Sub
    a.BorderColor = CD.Color
    gCtl.Render
    F.Dirty = True
End Sub

Private Sub btnBkg_Click()
If Loading Then Exit Sub
On Error Resume Next
    Select Case cmbBkg.ListIndex
    Case 0
        'Debug.Assert 0
        Exit Sub
    Case 1
        CD.Color = a.BkgColor
        CD.ShowColor
        If Error Then Exit Sub
        a.BkgColor = CD.Color
    Case 2
        CD.Filter = "Images|*.jpg;*.bmp;*.gif;*.jpeg|All files(*.*)|*.*"
        CD.FilterIndex = 1
        CD.ShowOpen
        If Error Then Exit Sub
        a.BkgImage = CD.Filename
    End Select
    gCtl.Render
    F.Dirty = True
End Sub

Private Sub cmbBkg_Click()
    btnBkg.Enabled = (cmbBkg.ListIndex > 0)
    If Not Loading Then
        a.BkgStyle = cmbBkg.ListIndex
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub cmbBorder_Click()
    If Not Loading Then
        a.BorderStyle = cmbBorder.ListIndex
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub btnColor_Click()
On Error Resume Next
    CD.flags = cdlCCRGBInit
    CD.Color = lblFontColor.BackColor
    CD.ShowColor
    If Error Then Exit Sub
    Debug.Print CD.Color
    a.FontColor = CD.Color
    lblFontColor.BackColor = CD.Color
    gCtl.Render
    F.Dirty = True
End Sub

Private Sub cmbFont_Click()
    If Not Loading Then
        a.Font = cmbFont.Text
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    dlgPropX = Left
    dlgPropY = Top
End Sub

Private Sub TS_Click()
Dim s$, n&, i&
    s = TS.SelectedItem
    Select Case s
    Case "Position": n = 0
    Case "Font": n = 1
    Case "Image": n = 2
    End Select
    For i = 0 To 2
        Pic(i).Visible = (i = n)
    Next
End Sub

Private Sub txtScale_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.sx = Val(txtScale(0).Text)
        Case 1: a.sy = Val(txtScale(1).Text)
        End Select
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub txtHeight_Change()
    If Not Loading Then
        a.Height = Val(txtHeight.Text)
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub txtRot_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.rX = Val(txtRot(0).Text)
        Case 1:  a.rY = Val(txtRot(1).Text)
        Case 2:  a.rZ = Val(txtRot(2).Text)
        Case 3:  a.ra = Val(txtRot(3).Text)
        End Select
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub txtPos_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.X = Val(txtPos(0).Text)
        Case 1: a.Y = Val(txtPos(1).Text)
        Case 2: a.z = Val(txtPos(2).Text)
        End Select
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub txtWidth_Change()
    If Not Loading Then
        a.Width = Val(txtWidth.Text)
        gCtl.Render
        F.Dirty = True
    End If
End Sub

Private Sub Form_Load()
Dim s$, n&, i&
    For i = 0 To 2
        Pic(i).Move 12, 34, 280, 160
    Next
    Set CD = frmMain.CD
    s = Dir(App.Path & "\fonts\" & "*.ftx")
    Do While Len(s)
        n = InStr(s, ".")
        s = Left$(s, n - 1)
        cmbFont.AddItem s
        s = Dir
    Loop
    Area = Areas.SelectedArea
    Move dlgPropX, dlgPropY
    Set F = frmMain
End Sub

Public Property Let Area(ByVal Selection As CArea)
Dim X!, Y!, z!, ra!
Dim s$, i&
    Loading = True
    Set a = Selection
    If a Is Nothing Then
        txtPos(0) = ""
        txtPos(1) = ""
        txtPos(2) = ""
        txtRot(0) = ""
        txtRot(1) = ""
        txtRot(2) = ""
        txtRot(3) = ""
        txtScale(0) = ""
        txtScale(1) = ""
        txtScale(2) = ""
        txtWidth = ""
        txtHeight = ""
        cmbFont.ListIndex = -1
        lblFontColor.BackColor = &H8000000F
        cmbBkg.ListIndex = -1
        cmbBorder.ListIndex = -1
        For i = 0 To 2
            Pic(i).Enabled = False
        Next
    Else
        For i = 0 To 2
            Pic(i).Enabled = True
        Next
        With cmbFont
            s = a.Font
            For i = 1 To .ListCount
                If .List(i - 1) = s Then
                    .ListIndex = i - 1
                    Exit For
                End If
            Next
            If i > .ListCount Then .ListIndex = -1
        End With
        lblFontColor.BackColor = a.FontColor
        txtScale(0) = a.sx
        txtScale(1) = a.sy
        '
        cmbBkg.ListIndex = a.BkgStyle
        cmbBorder.ListIndex = a.BorderStyle
        '
        a.GetTranslation X, Y, z
        txtPos(0) = X
        txtPos(1) = Y
        txtPos(2) = z
        a.GetRotation ra, X, Y, z
        txtRot(0) = X
        txtRot(1) = Y
        txtRot(2) = z
        txtRot(3) = ra
        txtWidth = a.Width
        txtHeight = a.Height
        '
    End If
    Loading = False
End Property


