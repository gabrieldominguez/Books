class AwesomeGame extends UTDeathmatch;

var int EnemiesLeft;

simulated function PostBeginPlay()
{
    local TestEnemy TE;

    super.PostBeginPlay();

    GoalScore = 0;

    foreach DynamicActors(class'TestEnemy', TE)
        GoalScore++;

    EnemiesLeft = GoalScore;
}

function ScoreObjective(PlayerReplicationInfo Scorer, Int Score)
{
    EnemiesLeft--;
    super.ScoreObjective(Scorer, Score);
}

defaultproperties
{
    bScoreDeaths=false
    PlayerControllerClass=class'AwesomeGame.AwesomePlayerController'
    DefaultPawnClass=class'AwesomeGame.AwesomePawn'
    DefaultInventory(0)=None
}
