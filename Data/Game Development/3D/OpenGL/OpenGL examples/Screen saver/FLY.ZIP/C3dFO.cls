VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3dFO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: Main class of the app.
'   Dispatches messages to the individual screen savers.
'   Each screen saver implements an 'init' procedure and an
'   'update' procedure
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************
Public Enum SaverTypes
    ssExplode = 1
    ssDrop = 2
    ssStrip = 3
    ssTex = 4
    ssLem = 5
    ssWin = 6
End Enum
Dim m_SaverType As SaverTypes
Dim Ex As CExplode
Dim Drop As CDrop
Dim Strip As CStrip
Dim Flag As CTexFlag

Private Sub Class_Initialize()
Set g3DFO = Me
End Sub

Private Sub Class_Terminate()
Set Ex = Nothing
Set Drop = Nothing
Set Strip = Nothing
Set Flag = Nothing
End Sub

Public Property Get Saver() As SaverTypes
Saver = m_SaverType
End Property

Public Property Let Saver(ByVal NewValue As SaverTypes)
Select Case m_SaverType
Case ssExplode: Set Ex = Nothing
Case ssDrop: Set Drop = Nothing
Case ssLem
Case ssStrip: Set Strip = Nothing
Case ssTex: Set Flag = Nothing
Case ssWin
Case Else: ' Debug.Assert 0
End Select
m_SaverType = NewValue
Select Case m_SaverType
Case ssExplode
    Set Ex = New CExplode
    Ex.InitExplodeScene
Case ssDrop
    Set Drop = New CDrop
    Drop.InitDropScene
Case ssLem
Case ssStrip
    Set Strip = New CStrip
    Strip.InitStripScene
Case ssTex
    Set Flag = New CTexFlag
    Flag.InitTexScene
Case ssWin
Case Else: Debug.Assert 0
End Select
End Property

'/******************************Public*Routine*****************************
'* ss_Init
'* Screen saver entry point.  Pre-GL initialization
'\*************************************************************************
Public Sub Init()
End Sub

'/******************************Public*Routine*****************************
'* _3dfo_Init
'\*************************************************************************
Public Sub InitGL()
Dim i&
    GetIniSettings
    ' Make sure the selected texture file is OK.
    If Len(optTextureFile) Then
        Set Texture = gCtl.NewTexture
        i = Texture.LoadTextureFile(optTextureFile)
        If i = 0 Then
            Texture.LoadTextureResource (0)
        End If
        gbTextureLoaded = i
    End If
    ' set configuration info to return
    'glClearColor 0, 0, 0, 0
    ' Select the shading model.
    If optSmoothShading Then
        glShadeModel GL_SMOOTH
    Else
        glShadeModel GL_FLAT
    End If
    ' Setup the lighting.
    gCtl.GetErr
    With gCtl.Lights
        .SetAmbient 0.21, 0.21, 0.21
        .TwoSide = True
    End With
    gCtl.GetErr
    With gCtl.Lights(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 0.8, 0.8, 0.8
        .SetSpecular 0.4, 0.3, 0.3
        .SetPosition 10, 10, 10
        .Enabled = True
        '.Mode = lmDirectional 'this is the default
            'for the control, shown here for clarity
    End With
    '
    gCtl.GetErr
    ' Setup the material properties.
    For i = 0 To 15
        Set Material(i) = gCtl.NewMaterial
        Select Case i
        Case 0
        InitMaterial i, 1, 0, 0
        Case 1
        InitMaterial i, 0, 1, 0
        Case 2
        InitMaterial i, 0, 0, 1
        Case 3
        InitMaterial i, 1, 1, 0
        Case 4
        InitMaterial i, 1, 1, 1
        Case 5
        InitMaterial i, 1, 0, 1
        Case 6
        InitMaterial i, 0.235, 0, 0.78
        End Select
    Next
    Material(0).SetMaterial
    Saver = optType
End Sub

'/******************************Public*Routine*****************************
'* _3dfo_Draw
'\*************************************************************************
Public Sub Draw()
    Select Case m_SaverType
    Case ssExplode
        Ex.UpdateExplodeScene 0
    Case ssDrop
        Drop.UpdateDropScene 0
    Case ssLem
    Case ssStrip
        Strip.UpdateStripScene 0
    Case ssTex
        Flag.UpdateTexScene 0
    Case ssWin
    Case Else: 'Debug.Assert 0
    End Select
End Sub

'/*************************************************************************
'Each of the savers defines it's own view except 'Drop',
'which I have modifed to use the Camera in the ocx.
'To have the ocx handle resizing, set the Camera parameters and
'then return 'True' from this function
'Note that the SDK ss's do not correct for the aspect ratio - this is
'because they run in fixed size floating windows
'\*************************************************************************
Public Function Reshape(Width&, Height&)
    Select Case m_SaverType
    Case ssExplode: Reshape = True
    Case ssDrop: Reshape = True
    Case ssLem
    Case ssStrip
    Case ssTex
    Case ssWin
    Case Else: Debug.Assert 0
    End Select
End Function


