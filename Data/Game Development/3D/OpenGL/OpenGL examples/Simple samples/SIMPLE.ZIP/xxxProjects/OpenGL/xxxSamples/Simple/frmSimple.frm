VERSION 5.00
Begin VB.Form frmSimple 
   Caption         =   "Simple"
   ClientHeight    =   7845
   ClientLeft      =   240
   ClientTop       =   1935
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   ScaleHeight     =   523
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   439
End
Attribute VB_Name = "frmSimple"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: simple demo of the basics of opengl
'    - gl setup, resize, and drawing
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY: -
'/*************************************************************************
Const WORLD_LIST = 1000000
Private m_fieldOfView As Double
Private m_NearPlane As Double
Private m_FarPlane As Double
Private m_AspectRatio As Double
Dim m_hGLRC&

Public Function Initialize() As Boolean
Dim pfd As PIXELFORMATDESCRIPTOR
Dim R&, pos!(0 To 3)
'set standard parameters
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    R = ChoosePixelFormat(hDC, pfd)
    If R = 0 Then
        MsgBox "ChoosePixelFormat failed"
        Exit Function
    End If
    R = SetPixelFormat(hDC, R, pfd)
    'palette?
    '
    m_hGLRC = wglCreateContext(hDC)
    wglMakeCurrent hDC, m_hGLRC
    glClearColor 0.2, 0.2, 0.2, 1
    'depth
    glClearDepth 1
    glEnable GL_DEPTH_TEST
    'color
    glEnable glcColorMaterial
    glColorMaterial faceFront, GL_AMBIENT_AND_DIFFUSE
    'lighting
    glEnable GL_LIGHTING
    glEnable glcLight0
    'move light
    pos(0) = 10: pos(1) = 10: pos(2) = 10: pos(3) = 1
    glLightfv ltLight0, lpmPosition, pos(0)
    pos(0) = -1: pos(1) = -1: pos(2) = -1
    glLightfv ltLight0, lpmSpotDirection, pos(0)
    glLightfv ltLight0, lpmSpotCutoff, 40
    glLightfv ltLight0, lpmSpotExponent, 4
    'viewport
    m_AspectRatio = 1
    m_FarPlane = 200
    m_NearPlane = 0.5
    m_fieldOfView = 45
    '
    DrawWorld
    Initialize = True
End Function

Public Sub DrawWorld()
Dim obj&
glPushMatrix
    glNewList WORLD_LIST, GL_COMPILE
        glColor3f 0.2, 0.8, 0
        obj = gluNewQuadric
        glRotatef -90, 1, 0, 0
        gluCylinder obj, 1, 0, 2, 16, 16
        glTranslatef 1.3, 0.5, 0
        glColor3f 1, 0, 0
        gluSphere obj, 1, 16, 16
        glTranslatef 0, -2, -2
        glRotatef -90, 0, 1, 1
        glColor3f 0.1, 0.1, 0.7
        gluCylinder obj, 0.3, 0.3, 6, 16, 16
    glEndList
glPopMatrix
End Sub

Private Sub Form_Initialize()
Initialize
End Sub

Private Sub Form_Paint()
Display
End Sub

Private Sub Form_Resize()
Static W&, H&
Dim w1&, h1&
    w1 = ScaleWidth
    h1 = ScaleHeight
    OnSize w1, h1
    If w1 <= W And h1 <= H Then Display 'force a repaint
    W = w1: H = h1
End Sub

Private Sub Form_Unload(Cancel As Integer)
    If m_hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hGLRC
    End If
End Sub

Public Sub Display()
Static Busy As Boolean
    If Busy Then Exit Sub
    Busy = True
    glClear clrColorBufferBit Or clrDepthBufferBit
    glPushMatrix
        gluLookAt 0, 0, 10, 0, 0, 0, 0, 1, 0
        glCallList WORLD_LIST
    glPopMatrix
    glFinish
    SwapBuffers hDC
    Busy = False
End Sub

'Adjusts the viewport to match the window size.
Public Sub OnSize(ByVal W&, ByVal H&)
If H = 0 Then H = 1
m_AspectRatio = W / H
glViewport 0, 0, W, H
SetViewPort
End Sub

Private Sub SetViewPort()
Dim W&, H&
Dim X#, Y#, Z#

glMatrixMode mmProjection
glLoadIdentity
gluPerspective m_fieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
glMatrixMode mmModelView
glLoadIdentity
End Sub


