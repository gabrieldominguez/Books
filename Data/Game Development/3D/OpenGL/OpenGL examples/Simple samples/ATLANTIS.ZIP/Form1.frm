VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Atlantis"
   ClientHeight    =   4335
   ClientLeft      =   2595
   ClientTop       =   3660
   ClientWidth     =   6540
   LinkTopic       =   "Form1"
   ScaleHeight     =   289
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   436
   Begin VB.Timer Timer1 
      Interval        =   20
      Left            =   5580
      Top             =   360
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileAnimate 
         Caption         =   "&Animate"
      End
      Begin VB.Menu mnuFileSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Initialize()
Initialize Me
End Sub

Private Sub Form_Paint()
Display
End Sub

Private Sub Form_Resize()
Static W&, H&
Dim w1&, h1&
    w1 = ScaleWidth
    h1 = ScaleHeight
    OnSize w1, h1
    If w1 <= W And h1 <= H Then Display
    W = w1: H = h1
End Sub

Private Sub Form_Unload(Cancel As Integer)
Terminate
End Sub

Private Sub mnuFileExit_Click()
End
End Sub

Private Sub Timer1_Timer()
Animate
Display
End Sub
