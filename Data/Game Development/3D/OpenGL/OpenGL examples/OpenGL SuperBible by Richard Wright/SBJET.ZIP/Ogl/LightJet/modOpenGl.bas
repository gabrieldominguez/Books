Attribute VB_Name = "mOpengl"
' modOpenGL: OpenGL start/stop functions and related routines.

Option Explicit

Public bLight, bSpecular, bShine As GLboolean
Public xRot, yRot As GLfloat
Public bAppRunning As GLboolean

Public Type PIXELFORMATDESCRIPTOR
    nSize As Integer
    nVersion As Integer
    dwFlags As Long
    iPixelType As Byte
    cColorBits As Byte
    cRedBits As Byte
    cRedShift As Byte
    cGreenBits As Byte
    cGreenShift As Byte
    cBlueBits As Byte
    cBlueShift As Byte
    cAlphaBits As Byte
    cAlphaShift As Byte
    cAccumBits As Byte
    cAccumRedBits As Byte
    cAccumGreenBits As Byte
    cAccumBlueBits As Byte
    cAccumAlpgaBits As Byte
    cDepthBits As Byte
    cStencilBits As Byte
    cAuxBuffers As Byte
    iLayerType As Byte
    bReserved As Byte
    dwLayerMask As Long
    dwVisibleMask As Long
    dwDamageMask As Long
End Type
Public Const PFD_TYPE_RGBA = 0
Public Const PFD_TYPE_COLORINDEX = 1
Public Const PFD_MAIN_PLANE = 0
Public Const PFD_DOUBLEBUFFER = 1
Public Const PFD_DRAW_TO_WINDOW = &H4
Public Const PFD_SUPPORT_OPENGL = &H20
Public Const PFD_NEED_PALETTE = &H80
Public Declare Function ChoosePixelFormat Lib "gdi32" (ByVal hDC As Long, pfd As PIXELFORMATDESCRIPTOR) As Long
Public Declare Function CreatePalette Lib "gdi32" (pPal As LOGPALETTE) As Long
Public Declare Sub DeleteObject Lib "gdi32" (hObject As Long)
Public Declare Sub DescribePixelFormat Lib "gdi32" (ByVal hDC As Long, ByVal PixelFormat As Long, ByVal nBytes As Long, pfd As PIXELFORMATDESCRIPTOR)
Public Declare Function GetDC Lib "gdi32" (ByVal hWnd As Long) As Long
Public Declare Function GetPixelFormat Lib "gdi32" (ByVal hDC As Long) As Long
Public Declare Sub GetSystemPaletteEntries Lib "gdi32" (ByVal hDC As Long, ByVal start As Long, ByVal entries As Long, ByVal ptrEntries As Long)
Public Declare Sub RealizePalette Lib "gdi32" (ByVal hPalette As Long)
Public Declare Sub SelectPalette Lib "gdi32" (ByVal hDC As Long, ByVal hPalette As Long, ByVal bln As Long)
Public Declare Function SetPixelFormat Lib "gdi32" (ByVal hDC As Long, ByVal i As Long, pfd As PIXELFORMATDESCRIPTOR) As Boolean
Public Declare Sub SwapBuffers Lib "gdi32" (ByVal hDC As Long)
Public Declare Function wglCreateContext Lib "OpenGL32" (ByVal hDC As Long) As Long
Public Declare Sub wglDeleteContext Lib "OpenGL32" (ByVal hContext As Long)
Public Declare Sub wglMakeCurrent Lib "OpenGL32" (ByVal l1 As Long, ByVal l2 As Long)
Public hGLRC As Long

Public sRenderer As String, sVendor As String, sExtensions As String, sVersion As String

Dim V(2, 2) As Single
Dim Out(2) As GLfloat
Dim Vector(2) As GLfloat

Public Sub FatalError(ByVal sMessage As String)

'Subroutine to stop the program on fatal error

    MsgBox "Fatal Error: " & sMessage, vbCritical + vbApplicationModal + vbOKOnly + vbDefaultButton1, "Fatal Error In " & App.Title
    Unload frmDisplay
    Set frmDisplay = Nothing
    End
    
End Sub

Private Sub SetupPixelFormat(ByVal lhDC As Long)

' Subroutine to set pixel format

    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim PixelFormat As Integer
    
    ' Initialize pixel format
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 16
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    
    ' Choose a pixel format that best matches that described in pfd
    PixelFormat = ChoosePixelFormat(lhDC, pfd)
    If PixelFormat = 0 Then FatalError "Could not retrieve pixel format!"
    
    ' Set the pixel format for the device context
    SetPixelFormat lhDC, PixelFormat, pfd
    
End Sub

Public Sub StartOpenGL(ByVal lTargetHDC As Long)

' Subroutine to intialize opengl window
   
    ' Select the pixel format
    SetupPixelFormat lTargetHDC
    
    ' Create the rendering context and make it current
    hGLRC = wglCreateContext(lTargetHDC)
    wglMakeCurrent lTargetHDC, hGLRC

End Sub

Public Sub StopOpenGL()

' Subroutine called when opengl window is closed
    
    ' Deselect the current rendering context and delete it
    If hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext hGLRC
    End If
    
End Sub

Public Sub SetupRC()

' Subroutine to initialize opengl graphics
    
    Dim AmbientLight(3) As GLfloat
    Dim DiffuseLight(3) As GLfloat
    Dim LightPos(3) As GLfloat
    Dim Specular(3) As GLfloat
    Dim SpecRef(3) As GLfloat
    Dim Shine As GLfloat
    
    AmbientLight(0) = 0.3
    AmbientLight(1) = 0.3
    AmbientLight(2) = 0.3
    AmbientLight(3) = 1#
    
    DiffuseLight(0) = 0.7
    DiffuseLight(1) = 0.7
    DiffuseLight(2) = 0.7
    DiffuseLight(3) = 1#
    
    Specular(0) = 1#
    Specular(1) = 1#
    Specular(2) = 1#
    Specular(3) = 1#
    
    LightPos(0) = -50#
    LightPos(1) = -50#
    LightPos(2) = 100#
    LightPos(3) = 1#
    
    glEnable glcDepthTest
    glFrontFace ffCCW
    glEnable glcCullFace
    
    ' Enable lighting
    If bLight = True Then
        glEnable glcLighting
    Else
        glDisable glcLighting
    End If
    
    ' Setup and enable light 0
    glLightfv ltLight0, lpmAmbient, AmbientLight(0)
    glLightfv ltLight0, lpmDiffuse, DiffuseLight(0)
    glLightfv ltLight0, lpmPosition, LightPos(0)
    If bSpecular = True Then
        glLightfv ltLight0, lpmSpecular, Specular(0)
    End If
    If bLight = True Then
        glEnable glcLight0
    Else
        glDisable glcLight0
    End If
    
    ' Enable color tracking
    If bLight = True Then
        glEnable glcColorMaterial
    Else
        glDisable glcColorMaterial
    End If
    
    ' Set material properties to follow glcolor values
    If bLight = True Then
        glColorMaterial faceFront, cmmAmbientAndDiffuse
        If bSpecular = True Then
            SpecRef(0) = 1#
            SpecRef(1) = 1#
            SpecRef(2) = 1#
            SpecRef(3) = 1#
        Else
            SpecRef(0) = 0#
            SpecRef(1) = 0#
            SpecRef(2) = 0#
            SpecRef(3) = 0#
        End If
        glMaterialfv faceFront, mprSpecular, SpecRef(0)
        If bShine = True Then
            Shine = 128
        Else
            Shine = 0
        End If
        glMaterialfv faceFront, mprShininess, Shine
    End If
    
    ' Light blue background
    glClearColor 0#, 0#, 0#, 1#
    
    Call RenderScene

End Sub


Public Sub glRGB(x As GLubyte, y As GLubyte, z As GLubyte)
  glColor3ub x, y, z
End Sub

Public Sub CalcNormal(V, Out)
    
    Dim V1(2), V2(2) As Single
    Static x As Integer
    Static y As Integer
    Static z As Integer

    x = 0
    y = 1
    z = 2
    
    ' Calculate two vectors from the three points
    V1(x) = V(0, x) - V(1, x)
    V1(y) = V(0, y) - V(1, y)
    V1(z) = V(0, z) - V(1, z)
    
    V2(x) = V(1, x) - V(2, x)
    V2(y) = V(1, y) - V(2, y)
    V2(z) = V(1, z) - V(2, z)

    ' Take the cross product of 2 vectors to get the normal
    ' vector which will be stored in out
    Out(x) = (V1(y) * V2(z)) - (V1(z) * V2(y))
    Out(y) = (V1(z) * V2(x)) - (V1(x) * V2(z))
    Out(z) = (V1(z) * V2(y)) - (V1(y) * V2(x))
    
    ' Normalize the vector (shorten to length 1)
    Call ReduceToUnit(Out)

End Sub

Public Sub ReduceToUnit(Vector)
    
    Dim Length As Single

    ' Calculate the length of the vector
    Length = Sqr((Vector(0) * Vector(0)) + _
                  (Vector(1) * Vector(1)) + _
                  (Vector(2) * Vector(2)))
    
    ' Keep the program from blowing up by providing an exceptable
    ' value for vectors that may calculated too close to zero.
    If (Length = 0#) Then Length = 1#
    
    ' Dividing each element by the length will result in a
    ' unit normal vector.
    Vector(0) = Vector(0) / Length
    Vector(1) = Vector(1) / Length
    Vector(2) = Vector(2) / Length

End Sub




