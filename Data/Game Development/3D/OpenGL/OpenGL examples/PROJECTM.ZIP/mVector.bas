Attribute VB_Name = "mVector"
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: vector routines.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'NOTES: spherical and lerp are untested.
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
' Zero out a 3D vector
'-------------------------------------------------------------------------
Public Sub V3Zerof(v!())
   v(0) = 0
   v(1) = 0
   v(2) = 0
End Sub

Public Sub V3Zerod(v#())
   v(0) = 0
   v(1) = 0
   v(2) = 0
End Sub

'-------------------------------------------------------------------------------------
' Return vector formed from components
'-------------------------------------------------------------------------------------
Public Sub V3Makef(v!(), x!, y!, z!)
    v(0) = x
    v(1) = y
    v(2) = z
End Sub

Public Sub V4Makef(v!(), x!, y!, z!)
    v(0) = x
    v(1) = y
    v(2) = z
    v(3) = 0
End Sub

'-------------------------------------------------------------------------------------
'Vector copy
'-------------------------------------------------------------------------------------
Public Sub V2Copyf(dest!(), v!())
   dest(0) = v(0)
   dest(1) = v(1)
End Sub

Public Sub V2Copyd(dest#(), v#())
   dest(0) = v(0)
   dest(1) = v(1)
End Sub

Public Sub V3Copyf(dest!(), v!())
   dest(0) = v(0)
   dest(1) = v(1)
   dest(2) = v(2)
End Sub

Public Sub V3Copyd(dest#(), v#())
   dest(0) = v(0)
   dest(1) = v(1)
   dest(2) = v(2)
End Sub

'-------------------------------------------------------------------------------------
' Vector sum
'-------------------------------------------------------------------------------------
Public Sub V3Sumf(dest!(), A!(), B!())
   dest(0) = A(0) + B(0)
   dest(1) = A(1) + B(1)
   dest(2) = A(2) + B(2)
End Sub

Public Sub V3Sumd(dest#(), A#(), B#())
   dest(0) = A(0) + B(0)
   dest(1) = A(1) + B(1)
   dest(2) = A(2) + B(2)
End Sub

'-------------------------------------------------------------------------------------
' Vector difference a-b
'-------------------------------------------------------------------------------------
Public Sub V3Subf(dest!(), A!(), B!())
   dest(0) = A(0) - B(0)
   dest(1) = A(1) - B(1)
   dest(2) = A(2) - B(2)
End Sub

Public Sub V3Subd(dest#(), A#(), B#())
   dest(0) = A(0) - B(0)
   dest(1) = A(1) - B(1)
   dest(2) = A(2) - B(2)
End Sub

'-------------------------------------------------------------------------------------
' V3Scale - scalar times vector
'-------------------------------------------------------------------------------------
Public Sub V3Scalef(dest!(), f!, v!())
   dest(0) = f * v(0)
   dest(1) = f * v(1)
   dest(2) = f * v(2)
End Sub

Public Sub V4Scalef(dest!(), f!, v!())
   dest(0) = f * v(0)
   dest(1) = f * v(1)
   dest(2) = f * v(2)
   dest(3) = v(3)
End Sub

Public Sub V3Scaled(dest#(), f#, v#())
   dest(0) = f * v(0)
   dest(1) = f * v(1)
   dest(2) = f * v(2)
End Sub

'-------------------------------------------------------------------------------------
' V3Dot - Vector dot product
'-------------------------------------------------------------------------------------
Public Sub V3Dotf(dot!, A!(), B!())
    dot = A(0) * B(0) + A(1) * B(1) + A(2) * B(2)
End Sub

Public Sub V3Dotd(dot#, A#(), B#())
    dot = A(0) * B(0) + A(1) * B(1) + A(2) * B(2)
End Sub

Sub V3DotUnitf(dot!, A!(), B!())
Dim mag!, lngA!, lngB!
    V3Lengthf lngA, A
    V3Lengthf lngB, B
    mag = 1 / (lngA * lngB)
    dot = (A(0) * B(0) + A(1) * B(1) + A(2) * B(2)) * mag
End Sub

'-------------------------------------------------------------------------------------
' V3Negate
'-------------------------------------------------------------------------------------
Public Sub V3Negatef(dest!(), v!())
   dest(0) = -v(0)
   dest(1) = -v(1)
   dest(2) = -v(2)
End Sub

'-------------------------------------------------------------------------------------
' V3IsEqual
'-------------------------------------------------------------------------------------
Function V3IsEqualf(A!(), B!()) As Boolean
    V3IsEqualf = (A(0) = B(0)) And (A(1) = B(1)) And (A(2) = B(2))
End Function

'-------------------------------------------------------------------------------------
' V3Length
'-------------------------------------------------------------------------------------
Public Sub V3Lengthf(lng!, v!())
    lng = Sqr(v(0) * v(0) + v(1) * v(1) + v(2) * v(2))
    'If lng = 0 Then
        'Debug.Assert 0
        'lng = 0.00001
    'End If
End Sub

Public Sub V3Length3f(lng!, x!, y!, z!)
   lng = x * x + y * y + z * z
   lng = Sqr(lng)
End Sub

Public Sub V3Lengthd(lng#, v#())
   lng = v(0) * v(0) + v(1) * v(1) + v(2) * v(2)
   lng = Sqr(lng)
End Sub

'-------------------------------------------------------------------------------------
' V3Normalize
'-------------------------------------------------------------------------------------
Public Sub V3Normalizef(v!())
Dim lng!
    V3Lengthf lng, v
    If lng <> 0 Then
        lng = 1 / lng
        v(0) = v(0) * lng
        v(1) = v(1) * lng
        v(2) = v(2) * lng
    End If
End Sub

Public Sub V3Normalize3f(x!, y!, z!)
Dim lng!
    V3Length3f lng, x, y, z
    If lng <> 0 Then
        lng = 1 / lng
        x = x * lng
        y = y * lng
        z = z * lng
    End If
End Sub

Public Sub V3Normalized(v#())
Dim lng#
    V3Lengthd lng, v
    If (lng <> 0) Then
        lng = 1 / lng
        v(0) = v(0) * lng
        v(1) = v(1) * lng
        v(2) = v(2) * lng
    End If
End Sub

'-------------------------------------------------------------------------------------
Public Sub V3NormalizeEPS(v!())
Dim lng!
    lng = (v(0) * v(0)) + (v(1) * v(1)) + (v(2) * v(2))
    If lng > ZERO_EPS Then
        lng = 1 / Sqr(lng)
    Else
        lng = 1
    End If
    v(0) = v(0) * lng
    v(1) = v(1) * lng
    v(2) = v(2) * lng
End Sub

Public Sub V4Normalizef(v!())
Dim lng!
    V3Lengthf lng, v
    If lng <> 0 Then
        lng = 1 / lng
        v(0) = v(0) * lng
        v(1) = v(1) * lng
        v(2) = v(2) * lng
    End If
End Sub

'-------------------------------------------------------------------------------------
' V3Distance
'-------------------------------------------------------------------------------------
Sub V3Distance(lng!, A!(), B!())
Dim v!()
  V3Subf v, A, B
  V3Lengthf lng, v
End Sub

'-------------------------------------------------------------------------------------
'V3Midpoint
'-------------------------------------------------------------------------------------
Public Sub V3Midpoint(dest!(), A!(), B!())
Dim temp!(0 To 2)
    V3Sumf temp, A, B
    V3Scalef temp, 0.5, temp
    V3Copyf temp, dest
End Sub

'-------------------------------------------------------------------------------------
' V3Cross - 3D Vector cross product yeilding vector
'-------------------------------------------------------------------------------------
Public Sub V3Crossf(dest!(), A!(), B!())
   dest(0) = A(1) * B(2) - A(2) * B(1)
   dest(1) = A(2) * B(0) - A(0) * B(2)
   dest(2) = A(0) * B(1) - A(1) * B(0)
End Sub

Public Sub V3Crossd(dest#(), A#(), B#())
   dest(0) = A(1) * B(2) - A(2) * B(1)
   dest(1) = A(2) * B(0) - A(0) * B(2)
   dest(2) = A(0) * B(1) - A(1) * B(0)
End Sub

'-------------------------------------------------------------------------------------
' Vector perp -- assumes that n is of unit length
' accepts vector v, subtracts out any component parallel to n
'-------------------------------------------------------------------------------------
Public Sub V3Perpf(dest!(), v!(), n!())
Dim dot!
   V3Dotf dot, v, n
   dest(0) = v(0) - dot * n(0)
   dest(1) = v(1) - dot * n(1)
   dest(2) = v(2) - dot * n(2)
End Sub

Public Sub V3Perpd(vp#(), v#(), n#())
Dim dot#
   V3Dotd dot, v, n
   vp(0) = v(0) - dot * n(0)
   vp(1) = v(1) - dot * n(1)
   vp(2) = v(2) - dot * n(2)
End Sub

'-------------------------------------------------------------------------------------
' Vector reflection -- assumes n is of unit length
' Takes vector v, reflects it against reflector n, and returns dest
'-------------------------------------------------------------------------------------
Public Sub V3Reflectf(dest!(), v!(), n!())
Dim dot!
   V3Dotf dot, v, n
   dest(0) = v(0) - 2 * dot * n(0)
   dest(1) = v(1) - 2 * dot * n(1)
   dest(2) = v(2) - 2 * dot * n(2)
End Sub

Public Sub V3Reflectd(vr#(), v#(), n#())
Dim dot#
   V3Dotd dot, v, n
   vr(0) = v(0) - 2 * dot * n(0)
   vr(1) = v(1) - 2 * dot * n(1)
   vr(2) = v(2) - 2 * dot * n(2)
End Sub

'-------------------------------------------------------------------------------------
'  V3Lerp: linear interpolation of two vectors.
'-------------------------------------------------------------------------------------
Sub V3Lerp(dest!(), A!(), B!(), alpha!)
    dest(0) = A(0) + ((B(0) - A(0)) * alpha)
    dest(1) = A(1) + ((B(1) - A(1)) * alpha)
    dest(2) = A(2) + ((B(2) - A(2)) * alpha)
End Sub

'  vec_combine: compute linear combination of two vectors.
Sub V3Combine(dest!(), A!(), B!(), fas!, bs!)
  dest(0) = (fas * A(0)) + (bs * B(0))
  dest(1) = (fas * A(1)) + (bs * B(1))
  dest(2) = (fas * A(2)) + (bs * B(2))
End Sub

'-------------------------------------------------------------------------------------
' Convert a vector in XYZ space to spherical coordinates
' * The spherical coordinates is represented using a vector as follows:
' *   vx = latitude
' *   vy = longitude
' *   vz = rotation
'-------------------------------------------------------------------------------------
Sub V3ToSpherical(dest!(), v!())
Dim tx!, ty!, tz!
    tx = v(0)
    ty = v(1)
    tz = v(2)
    V3Normalize3f tx, ty, tz
    dest(0) = RadToDegf(Arcsin(ty))   ' Latitude
    If (tx * tx + tz * tz < 0.0005) Then   ' Longitude
        dest(1) = 0            ' Undefined when latitude = +/- 90
    Else
        dest(1) = RadToDegf(Atan2(tx, tz))
    End If
    If dest(1) < 0 Then
        dest(1) = dest(1) + 360
    End If
End Sub

'-------------------------------------------------------------------------------------
' Convert spherical coordinates to XYZ space
'-------------------------------------------------------------------------------------
Sub V3FromSpherical(dest!(), v!())
Dim slat!, clat!, slon!, clon!
    slat = Sin(v(0))
    clat = Cos(v(0))
    slon = Sin(v(1))
    clon = Cos(v(1))
    dest(0) = clat * slon
    dest(1) = slat
    dest(2) = clat * clon
End Sub

'in counterclockwise order: p2,p1,p3
Public Sub CalcNorm(norm!(), p1x!, p1y!, p1z!, _
                             p2x!, p2y!, p2z!, _
                             p3x!, p3y!, p3z!)
Dim crossX!, crossY!, crossZ!
Dim abX!, abY!, abZ!
Dim acX!, acY!, acZ!
Dim sqrLength!
Dim invLength!

    abX = p2x - p1x '      ' calculate p2 - p1
    abY = p2y - p1y
    abZ = p2z - p1z

    acX = p3x - p1x '      ' calculate p3 - p1
    acY = p3y - p1y
    acZ = p3z - p1z

    crossX = (abY * acZ) - (abZ * acY) '   ' get cross product
    crossY = (abZ * acX) - (abX * acZ) '   ' (p2 - p1) X (p3 - p1)
    crossZ = (abX * acY) - (abY * acX)

    sqrLength = (crossX * crossX) + (crossY * crossY) + _
                 (crossZ * crossZ)

    If (sqrLength > ZERO_EPS) Then
        invLength = (1 / Sqr(sqrLength))
    Else
        invLength = 1
    End If

    norm(0) = crossX * invLength
    norm(1) = crossY * invLength
    norm(2) = crossZ * invLength
End Sub





