class AwesomeGame extends UTDeathmatch;

var int EnemiesLeft;
var array<AwesomeEnemySpawner> EnemySpawners;

simulated function PostBeginPlay()
{
    local AwesomeEnemySpawner ES;

    super.PostBeginPlay();

    GoalScore = EnemiesLeft;

    foreach DynamicActors(class'AwesomeEnemySpawner', ES)
        EnemySpawners[EnemySpawners.length] = ES;

    ActivateSpawners();
}

function ActivateSpawners()
{
    local int i;

    for(i=0; i<EnemySpawners.length; i++)
        EnemySpawners[i].SpawnEnemy();
}

function ScoreObjective(PlayerReplicationInfo Scorer, Int Score)
{
    local int i;

    EnemiesLeft--;
    super.ScoreObjective(Scorer, Score);

    if(EnemiesLeft == 0)
    {
        for(i=0; i<EnemySpawners.length; i++)
            EnemySpawners[i].FreezeEnemy();
    }
}

defaultproperties
{
    EnemiesLeft=10
    bScoreDeaths=false
    PlayerControllerClass=class'AwesomeGame.AwesomePlayerController'
    DefaultPawnClass=class'AwesomeGame.AwesomePawn'
    DefaultInventory(0)=None
}
