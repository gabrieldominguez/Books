class AwesomeActor extends Actor
    placeable;

enum EAltitude
{
    ALT_Underground,
    ALT_Surface,
    ALT_Sky,
    ALT_Space,
};

var EAltitude Altitude;

function PostBeginPlay()
{
    Altitude = ALT_Sky;
    `log("Altitude:" @ Altitude);

    `log("Is ALT_Sky greater than ALT_Surface?");
    `log(EAltitude.ALT_Sky > EAltitude.ALT_Surface);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
