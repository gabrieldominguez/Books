VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CTeapot"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'FUNCTION: Main class of the app.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim rotX!, rotY!
Dim teaList&
Dim patchData&(0 To 9, 0 To 15)
Dim cpData!(0 To 126, 0 To 2)

Private Sub Class_Initialize()
FillArrayl patchData, _
     102, 103, 104, 105, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, _
     12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, _
     24, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, _
     96, 96, 96, 96, 97, 98, 99, 100, 101, 101, 101, 101, 0, 1, 2, 3, _
     0, 1, 2, 3, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, _
     118, 118, 118, 118, 124, 122, 119, 121, 123, 126, 125, 120, 40, 39, 38, 37, _
     41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, _
     53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 28, 65, 66, 67, _
     68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, _
     80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95
FillArray3f cpData, 0, _
    0.2, 0, 2.7, 0.2, -0.112, 2.7, 0.112, -0.2, 2.7, 0, -0.2, 2.7, 1.3375, 0, 2.53125
FillArray3f cpData, 5, _
    1.3375, -0.749, 2.53125, 0.749, -1.3375, 2.53125, 0, -1.3375, 2.53125, 1.4375, 0, 2.53125, 1.4375, -0.805, 2.53125
FillArray3f cpData, 10, _
    0.805, -1.4375, 2.53125, 0, -1.4375, 2.53125, 1.5, 0, 2.4, 1.5, -0.84, 2.4, 0.84, -1.5, 2.4
FillArray3f cpData, 15, _
    0, -1.5, 2.4, 1.75, 0, 1.875, 1.75, -0.98, 1.875, 0.98, -1.75, 1.875, 0, -1.75, 1.875
FillArray3f cpData, 20, _
    2, 0, 1.35, 2, -1.12, 1.35, 1.12, -2, 1.35, 0, -2, 1.35, 2, 0, 0.9
FillArray3f cpData, 25, _
    2, -1.12, 0.9, 1.12, -2, 0.9, 0, -2, 0.9, -2, 0, 0.9, 2, 0, 0.45
FillArray3f cpData, 30, _
    2, -1.12, 0.45, 1.12, -2, 0.45, _
    0, -2, 0.45, 1.5, 0, 0.225, 1.5, -0.84, 0.225
FillArray3f cpData, 35, _
    0.84, -1.5, 0.225, 0, -1.5, 0.225, 1.5, 0, 0.15, 1.5, -0.84, 0.15, 0.84, -1.5, 0.15
FillArray3f cpData, 40, _
    0, -1.5, 0.15, -1.6, 0, 2.025, -1.6, -0.3, 2.025, -1.5, -0.3, 2.25, -1.5, 0, 2.25
FillArray3f cpData, 45, _
    -2.3, 0, 2.025, -2.3, -0.3, 2.025, -2.5, -0.3, 2.25, _
    -2.5, 0, 2.25, -2.7, 0, 2.025
FillArray3f cpData, 50, _
    -2.7, -0.3, 2.025, -3, -0.3, 2.25, -3, 0, 2.25, -2.7, 0, 1.8, -2.7, -0.3, 1.8
FillArray3f cpData, 55, _
    -3, -0.3, 1.8, -3, 0, 1.8, _
    -2.7, 0, 1.575, -2.7, -0.3, 1.575, -3, -0.3, 1.35
FillArray3f cpData, 60, _
    -3, 0, 1.35, -2.5, 0, 1.125, -2.5, -0.3, 1.125, -2.65, -0.3, 0.9375, -2.65, 0, 0.9375
FillArray3f cpData, 65, _
    -2, -0.3, 0.9, -1.9, -0.3, 0.6, -1.9, 0, 0.6, 1.7, 0, 1.425, 1.7, -0.66, 1.425
FillArray3f cpData, 70, _
    1.7, -0.66, 0.6, 1.7, 0, 0.6, 2.6, 0, 1.425, _
    2.6, -0.66, 1.425, 3.1, -0.66, 0.825
FillArray3f cpData, 75, _
    3.1, 0, 0.825, 2.3, 0, 2.1, 2.3, -0.25, 2.1, 2.4, -0.25, 2.025, 2.4, 0, 2.025
FillArray3f cpData, 80, _
    2.7, 0, 2.4, _
    2.7, -0.25, 2.4, 3.3, -0.25, 2.4, 3.3, 0, 2.4, 2.8, 0, 2.475
FillArray3f cpData, 85, _
    2.8, -0.25, 2.475, 3.525, -0.25, 2.49375, 3.525, 0, 2.49375, _
    2.9, 0, 2.475, 2.9, -0.15, 2.475
FillArray3f cpData, 90, _
    3.45, -0.15, 2.5125, 3.45, 0, 2.5125, 2.8, 0, 2.4, 2.8, -0.15, 2.4, 3.2, -0.15, 2.4
FillArray3f cpData, 95, _
    3.2, 0, 2.4, 0, 0, 3.15, _
    0.8, 0, 3.15, 0.8, -0.45, 3.15, 0.45, -0.8, 3.15
FillArray3f cpData, 100, _
    0, -0.8, 3.15, 0, 0, 2.85, 1.4, 0, 2.4, 1.4, -0.784, 2.4, 0.784, -1.4, 2.4
FillArray3f cpData, 105, _
    0, -1.4, 2.4, _
    0.4, 0, 2.55, 0.4, -0.224, 2.55, 0.224, -0.4, 2.55, 0, -0.4, 2.55
FillArray3f cpData, 110, _
    1.3, 0, 2.55, 1.3, -0.728, 2.55, 0.728, -1.3, 2.55, 0, -1.3, 2.55, _
    1.3, 0, 2.4
FillArray3f cpData, 115, _
    1.3, -0.728, 2.4, 0.728, -1.3, 2.4, 0, -1.3, 2.4, 0, 0, 0, _
    1.425, -0.798, 0
FillArray3f cpData, 120, _
    1.5, 0, 0.075, 1.425, 0, 0, 0.798, -1.425, 0, 0, -1.5, 0.075, 0, -1.425, 0
cpData(125, 0) = 1.5
cpData(125, 1) = -0.84
cpData(125, 2) = 0.075
cpData(126, 0) = 0.84
cpData(126, 1) = -1.5
cpData(126, 2) = 0.075 '127
End Sub


Public Sub InitGL()

    glEnable GL_DEPTH_TEST
    glDepthFunc GL_LESS

    glFrontFace GL_CW
    glEnable GL_AUTO_NORMAL
    glEnable GL_NORMALIZE

    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .SetAmbient 0.1745, 0.01175, 0.01175
        .SetDiffuse 0.61424, 0.04136, 0.04136
        .SetSpecular 0.727811, 0.626959, 0.626959
        .SpecExp = 0.6 * 128
        .SetMaterial
    End With
    '
    glClearColor 0.5, 0.5, 0.5, 1
    glColor3f 1, 1, 1

    Teapot 14
    
    glClearColor 0.3, 0.3, 0.3, 0
'    float position() = {0.0, 3.0, 3.0, 0.0};
'    glLightfv GL_LIGHT0, GL_POSITION, position
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetPosition 0, 3, 3
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
        .TwoSide = True
    End With
'    glOrtho(-6.0, 6.0, -6.0, 6.0, -1.0, 10.0);
    With gCtl.Camera
        .FarPlane = 10
        .NearPlane = -1
'        .FieldOfView = 45
        '.SetEyePos 2, 2, 2
        '.SetTargetPos 0, 0, 0
        .SetOrtho -6, 6, -6, 6
        .View = glxOrtho
    End With
    '
'    Set m_Mat = gCtl.NewMaterial
'    With m_Mat
'        .Face = faceFront
'        .SetDiffuse 0.5, 0.28, 0.38
'        .SetSpecular 0.2, 0.2, 0.2
'        .SpecExp = 30
'    End With

'    QuadObj = gluNewQuadric
'    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler

End Sub

Public Sub Draw()
    glPushMatrix
    glTranslatef 0, 0, -5
    glRotatef rotY, 0, 1, 0
    glRotatef rotX, 1, 0, 0
    glCallList teaList
    glPopMatrix
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub Key(KeyCode%)
Dim s$
    s = Chr$(KeyCode)
    Select Case (s)
    Case "X":    rotX = rotX + 5
    Case "x":    rotX = rotX - 5
    Case "Y":    rotY = rotY + 5
    Case "y":    rotY = rotY - 5
    End Select
    'no need to re-render
End Sub

Public Sub Teapot(grid&)
'the vertex data must be forced to be contiguous in memory
Dim p(0 To 3, 0 To 3) As POINT3F ', 0 To 2)
Dim q(0 To 3, 0 To 3) As POINT3F ' 0 To 2) '(4)(4)(3),
Dim r(0 To 3, 0 To 3) As POINT3F ' 0 To 2) '(4)(4)(3),
Dim s(0 To 3, 0 To 3) As POINT3F ' 0 To 2) 's(4)(4)(3);
Dim i&, j&, k&, l&
    teaList = glGenLists(1)
    glNewList teaList, GL_COMPILE
    glPushMatrix
    glRotatef 270, 1, 0, 0
    For i = 0 To 9
    For j = 0 To 3
        For k = 0 To 3
        For l = 0 To 2
            p(j, k).p(l) = cpData(patchData(i, j * 4 + k), l)
            q(j, k).p(l) = cpData(patchData(i, j * 4 + (3 - k)), l)
            If (l = 1) Then
                q(j, k).p(l) = q(j, k).p(l) * -1
            End If
            If (i < 6) Then
                r(j, k).p(l) = cpData(patchData(i, j * 4 + (3 - k)), l)
                If (l = 0) Then
                    r(j, k).p(l) = r(j, k).p(l) * -1
                End If
                s(j, k).p(l) = cpData(patchData(i, j * 4 + k), l)
                If (l = 0) Then
                    s(j, k).p(l) = s(j, k).p(l) * -1
                End If
                If (l = 1) Then
                    s(j, k).p(l) = s(j, k).p(l) * -1
                End If
            End If
        Next
        Next
    Next
    glMap2f GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4, p(0, 0).p(0)
    glEnable GL_MAP2_VERTEX_3
    glMapGrid2f grid, 0, 1, grid, 0, 1
    glEvalMesh2 GL_FILL, 0, grid, 0, grid
    glMap2f GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4, q(0, 0).p(0)
    glEvalMesh2 GL_FILL, 0, grid, 0, grid
    If (i < 6) Then
        glMap2f GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4, r(0, 0).p(0)
        glEvalMesh2 GL_FILL, 0, grid, 0, grid
        glMap2f GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4, s(0, 0).p(0)
        glEvalMesh2 GL_FILL, 0, grid, 0, grid
    End If
    Next
    glDisable GL_MAP2_VERTEX_3
    glPopMatrix
    glEndList
End Sub

