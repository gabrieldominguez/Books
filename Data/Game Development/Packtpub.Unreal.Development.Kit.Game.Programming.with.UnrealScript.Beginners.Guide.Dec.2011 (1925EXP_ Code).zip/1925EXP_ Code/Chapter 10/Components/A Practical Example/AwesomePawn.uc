class AwesomePawn extends UTPawn;

var bool bInvulnerable;
var float InvulnerableTime;

var SpotLightComponent Flashlight;

simulated function PostBeginPlay()
{
    super.PostBeginPlay();

    if(ArmsMesh[0] != none)
        ArmsMesh[0].SetHidden(true);
    if(ArmsMesh[1] != none)
        ArmsMesh[1].SetHidden(true);
}

simulated function SetMeshVisibility(bool bVisible)
{
    super.SetMeshVisibility(bVisible);
    Mesh.SetOwnerNoSee(false);
}

event Bump(Actor Other, PrimitiveComponent OtherComp, vector HitNormal)
{
    if(AwesomeEnemy(Other) != none && !bInvulnerable)
    {
        bInvulnerable = true;
        SetTimer(InvulnerableTime, false, 'EndInvulnerable');
        TakeDamage(AwesomeEnemy(Other).BumpDamage, none, Location, vect(0,0,0), class'UTDmgType_LinkPlasma');
    }
}

function EndInvulnerable()
{
    bInvulnerable = false;
}

defaultproperties
{
    InvulnerableTime=0.6

    Begin Object Class=SpotLightComponent Name=MyFlashlight
        bEnabled=true
        Radius=1024.000000
        Brightness=1.90000
    End Object
    Components.Add(MyFlashlight)
    Flashlight=MyFlashlight
}