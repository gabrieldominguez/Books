Attribute VB_Name = "mMain"
Option Explicit

' globals
Public g3D As C3DText 'main class
Public gCtl As glxCtl 'ref to the ocx on frm3DText
Public gAC As C3dAttrContext 'positioning attributes
Public gBB As C3dBoundingBox
Public bSuspended As Boolean
'
'configuration related variables
Public optDemoType As SSDemoTypes
Public optRotationStyle As SSRotationStyles     ' rotation style
Public optTessFactor!
Public optSpeed! ' rotation speed
Public optSize&   ' window size
Public optSurfaceStyle As SSSurfaceStyles
Public optFontName$ 'As String * LF_FACESIZE      ' font face name
Public optBold As Boolean
Public optItalic As Boolean
Public optCharSet As Byte
Public optText As String ' * TEXT_BUF_SIZE '+1) ' display string
Public optTexQuality& 'not written to reg
Public optTextureFile$ ' As glxTextureFile   ' texture file
Public optTextFile$ ' strings file

Public Sub Main()
If App.PrevInstance Then End
Set gAC = New C3dAttrContext
Set gBB = New C3dBoundingBox
Set g3D = New C3DText
Load frm3dText
Set gCtl = frm3dText.glxCtl1
g3D.Init
gCtl.Init
frm3dText.Show
gCtl.Animate = True
End Sub

'*************************************************************************\
'* MapValue
'* Maps the value along an input range, to a proportional one along an
'* output range.  Each range must be monotonically increasing or decreasing.
'* NO boundary conditions checked - responsibility of caller.
'*************************************************************************/
'fIn: input range, fOut: output range
Public Function MapValue(fInVal!, fIn1!, fIn2!, fOut1!, fOut2!)
Dim fDist!, fOutVal!
    ' how far along the input range is fInVal?, in %
    fDist = (fInVal - fIn1) / (fIn2 - fIn1)
    ' use this distance to interpolate into output range
    fOutVal = fDist * (fOut2 - fOut1) + fOut1
    MapValue = fOutVal
End Function

'*************************************************************************\
'* MapValueI
'* Similar to above, but maps integer values
'* Currently, only works for increasing ranges
'*************************************************************************/
Public Function MapValueI&(inVal&, in1&, in2&, out1&, out2&)
' input range ' output range
Dim inDiv&, outVal&, fScale!, fComp!
    If (inVal >= in2) Then
        MapValueI = out2
        Exit Function
    End If
    If (inVal <= in1) Then
        MapValueI& = out1
        Exit Function
    End If
    inDiv = Abs(in2 - in1) + 1
    fScale = (inDiv - 1) / inDiv
    fComp = 1 + 1 / inDiv
    outVal = MapValue(inVal * fComp, _
                        CSng(in1), in2 + 0.999, _
                        CSng(out1), out2 + 0.999)
    MapValueI& = outVal
End Function

Public Function ArcCos(X)
ArcCos = Atn(-X / Sqr(-X * X + 1)) + 2 * Atn(1)
End Function

Public Function ArcSin(X)
ArcSin = Atn(X / Sqr(-X * X + 1))
End Function

'*************************************************************************\
'* CalcChordalDeviation
'*************************************************************************/
Public Function CalcChordalDeviation!(hdc&)
Dim otm As OUTLINETEXTMETRIC
Dim CD!, mincd!   ' chordal deviations
    ' Query font metrics
    If (GetOutlineTextMetrics(hdc, Len(otm), otm) <= 0) Then
        ' cmd failed, or buffer size=0
        CalcChordalDeviation = 1
        Exit Function
    End If

    ' minimum chordal deviation is limited by design space
    mincd = 1 / otm.otmEMSquare
    ' now map optTessFactor to m_ChordalDeviation
    CD = MapValue(optTessFactor, _
                   0, 1, FMAX_CHORDAL_DEVIATION, mincd)   ' chordalDeviation range
    If (optTessFactor = 0) Then
        ' make sure get lowest resolution
        CD = 1
    End If
    CalcChordalDeviation = CD
End Function


