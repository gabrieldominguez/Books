Attribute VB_Name = "gleExtrusionRaw"
Option Explicit
'
' * MODULE NAME: ex_raw.c
' *
' * FUNCTION:
' * This module contains code that draws extrusions with square
' * ("raw join style") end styles.  It also inserts colors and normals
' * where necessary, if appropriate.
' *
' * HISTORY:
' * written by Linas Vepstas August/September 1991
' * split into multiple compile units, Linas, October 1991
' * added normal vectors Linas, October 1991
' * "code complete" (that is, I'm done), Linas Vepstas, October 1991
' * work around OpenGL's lack of support for concave polys, June 1994
'
'-------------------------------------------------------------------------
'FUNCTION: ExtrusionRawJoin is the only public routine here.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------==
' This routine draws "raw" style extrusions.  By "raw" style, it is
' * meant extrusions with square ends: ends that are cut at 90 degrees to
' * the length of the extrusion.  End caps are NOT drawn, unless the end cap
' * style is indicated.
'
'public sub extrusion_raw_join (ncp&,       ' number of contour points
'                         gleDouble contour()(2),    ' 2D contour
'                         gleDouble cont_normal()(2),' 2D contour normal vecs
'                         gleDouble up(3),   ' up vector for contour
'                         int npoints,       ' numpoints in poly-line
'                         gleDouble point_array()(3),    ' polyline
'                         float color_array()(3),    ' color of polyline
'                         gleDouble xform_array()(2)(3))   ' 2D contour xforms
'-------------------------------------------------------------------------==
Public Sub ExtrusionRawJoin(gc As gleGC)
Dim i&, j&, inext&
'Dim m(0 To 15)
Dim m#(0 To 15)
Dim lng#
Dim diff#(0 To 2), bi_0#(0 To 2)        ' bisecting plane
Dim yup#(0 To 2)        ' alternate up vector
Dim nrmv#(0 To 2)
Dim m_Contour() As gleVector 'gleAffine
Dim m_Norm() As gleVector
Dim front_loop&, back_loop&  ' countour loops
Dim front_norm&, back_norm&  ' countour loops
Dim tmp&
With gc
    ' use some local variables for needed booleans
    ' alloc loop arrays if needed
    If gc.nxforms Then
        'mem_anchor = malloc (4 * ncp * 3 * sizeof(gleDouble));
        ReDim m_Norm(0 To 2 * .ncp)
        front_norm = 0
        back_norm = front_norm + .ncp
        ReDim m_Contour(0 To 2 * .ncp)
        front_loop = 0
        back_loop = front_loop + .ncp
    End If

    ' By definition, the contour passed in has its up vector pointing in
    ' the y direction
    'edx: up pre-initialized
    V3Copyd yup, .up

    ' ========== "up" vector sanity check ==========
    UpSanityCheck yup, .npoints, .point_array

    ' ignore all segments of zero length
    i = 1
    inext = i
    FIND_NON_DEGENERATE_POINT inext, .npoints, lng, diff, .point_array

    ' first time through, get the loops
    If gc.nxforms Then
        For j = 0 To .ncp - 1
            MatDotVectorAd m_Contour(front_loop + j).v, _
                     .xform_array(inext - 1), .contour(j).v
            m_Contour(front_loop + j).v(2) = 0
        Next
        If gc.ncnormals Then
            For j = 0 To .ncp - 1
                NORM_XFORM_2X2 m_Norm(j).v, _
                         .xform_array(inext - 1), _
                         .cont_normal(j).v
                m_Norm(front_norm + j).v(2) = 0
                m_Norm(back_norm + j).v(2) = 0
            Next
        End If
    End If

    ' draw tubing, not doing the first segment
    Do While (inext < .npoints - 1)

        ' get the two bisecting planes
        BISECTING_PLANE3v bi_0, .point_array(i - 1).v, _
                               .point_array(i).v, _
                               .point_array(inext).v
    
        ' reflect the up vector in the bisecting plane
        V3Reflectd yup, yup, bi_0
    
        ' rotate so that z-axis points down v2-v1 axis,
        ' * and so that origen is at v1
        uviewpoint_d m, .point_array(i).v, .point_array(inext).v, yup
        glPushMatrix
        glMultMatrixd m(0)
    
        ' There are six different cases we can have for presence and/or
        ' * absecnce of colors and normals, and for interpretation of
        ' * normals. The blechy set of nested if statements below
        ' * branch to each of the six cases
        If gc.nxforms = 0 Then
            If gc.ncolors = 0 Then
                If gc.ncnormals = 0 Then
                    draw_raw_segment_plain gc, .ncp, .contour, inext, lng
                ElseIf (gc.NormStyle And gleFACET) Then
                    draw_raw_segment_facet_n gc, .ncp, .contour, .cont_normal, _
                                                   inext, lng
                Else
                    draw_raw_segment_edge_n gc, .ncp, .contour, .cont_normal, _
                                                   inext, lng
                End If
            Else
                If gc.ncnormals = 0 Then
                    'todo - changed last 2 parm's
                    draw_raw_segment_color gc, .ncp, .contour, .color_array, inext, lng
                ElseIf (gc.NormStyle And gleFACET) Then
                    draw_raw_segment_c_and_facet_n gc, .ncp, .contour, _
                            .color_array, .cont_normal, inext, lng
                Else 'h
                    draw_raw_segment_c_and_edge_n gc, .ncp, .contour, _
                            .color_array, .cont_normal, inext, lng
                End If
             End If
        Else

            ' else -- there are scales and offsets to deal with
            For j = 0 To .ncp - 1
                MatDotVectorAd m_Contour(back_loop + j).v, _
                                 .xform_array(inext), .contour(j).v
                m_Contour(back_loop + j).v(2) = -lng
                m_Contour(front_loop + j).v(2) = 0
            Next
    
            If gc.ncnormals Then
                For j = 0 To .ncp - 1
                   NORM_XFORM_2X2 m_Norm(back_norm + j).v, _
                            .xform_array(inext), .cont_normal(j).v
                Next
            End If

            If gc.ncolors = 0 Then
                If gc.ncnormals = 0 Then
                    draw_segment_plain gc, .ncp, m_Contour, front_loop, _
                            m_Contour, back_loop, inext, lng
                ElseIf (gc.NormStyle And gleFACET) Then
                    draw_binorm_segment_facet_n gc, .ncp, m_Contour, front_loop, _
                            m_Contour, back_loop, m_Norm, front_norm, _
                            m_Norm, back_norm, inext, lng
                Else
                    draw_binorm_segment_edge_n gc, .ncp, m_Contour, front_loop, _
                            m_Contour, back_loop, m_Norm, front_norm, _
                            m_Norm, back_norm, inext, lng
                End If
                If gc.CapStyle = gleCAPS Then
                    nrmv(2) = 1
                    N3F gc, nrmv
                    draw_front_contour_cap .ncp, m_Contour, front_loop
                    nrmv(2) = -1
                    N3F gc, nrmv
                    draw_back_contour_cap .ncp, m_Contour, back_loop
                End If
            Else
            If gc.ncnormals = 0 Then
               draw_segment_color gc, .ncp, m_Contour, front_loop, _
                    m_Contour, back_loop, .color_array(inext - 1).v, _
                    .color_array(inext).v, inext, lng
            ElseIf (gc.NormStyle And gleFACET) Then
               draw_binorm_segment_c_and_facet_n gc, .ncp, _
                    m_Contour, front_loop, _
                        m_Contour, back_loop, _
                        m_Norm, front_norm, m_Norm, back_norm, _
                        .color_array(inext - 1).v, _
                                   .color_array(inext).v, _
                                   inext, lng
            Else
               draw_binorm_segment_c_and_edge_n gc, .ncp, _
                    m_Contour, front_loop, m_Contour, back_loop, _
                    m_Norm, front_norm, m_Norm, back_norm, _
                    .color_array(inext - 1).v, _
                    .color_array(inext).v, _
                                   inext, lng
            End If
            If gc.CapStyle = gleCAPS Then
                glColor3fv .color_array(inext - 1).v(0)
                nrmv(2) = 1
                N3F gc, nrmv
                draw_front_contour_cap .ncp, m_Contour, front_loop

                glColor3fv .color_array(inext).v(0)
                nrmv(2) = -1
                N3F gc, nrmv
                draw_back_contour_cap .ncp, m_Contour, back_loop
            End If
        End If
    End If

      ' pop this matrix, do the next set
      glPopMatrix

      ' flop over transformed loops
      tmp = front_loop
      front_loop = back_loop
      back_loop = tmp
      tmp = front_norm
      front_norm = back_norm
      back_norm = tmp

      i = inext
      ' ignore all segments of zero length
      FIND_NON_DEGENERATE_POINT inext, .npoints, lng, diff, .point_array

   Loop
End With
End Sub

'edx: not called
'-------------------------------------------------------------------------==
' * This routine does what it says: It draws the end-caps for the
' * "raw" join style.
'private sub draw_raw_style_end_cap (ncp&,       ' number of contour points
'                             gleDouble contour()(2),    ' 2D contour
'                             gleDouble zval,        ' where to draw cap
'                             int frontwards)    ' front or back cap
'-------------------------------------------------------------------------==
Private Sub draw_raw_style_end_cap(ncp&, contour() As gleTwoVec, _
                             zval#, frontwards As Boolean)
Dim j&
Dim tObj&
Dim pts#() '   double *pts;
   ' malloc the @#$%^&* array that OpenGL wants !
   ReDim pts(0 To 3 * ncp - 1)
   tObj = gluNewTess
   gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
   gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
   gluTessCallback tObj, GLU_END, AddressOf gleEnd
   gluTessBeginPolygon tObj, 0
        gluTessBeginContour tObj

        ' draw the loop counter clockwise for the front cap
        If (frontwards) Then
           For j = 0 To ncp - 1
              pts(3 * j) = contour(j).v(0)
              pts(3 * j + 1) = contour(j).v(1)
              pts(3 * j + 2) = zval
              gluTessVertex tObj, pts(3 * j), pts(3 * j)
           Next
        Else
           ' the sense of the loop is reversed for backfacing culling
           For j = ncp - 1 To 0 Step -1
              pts(3 * j) = contour(j).v(0)
              pts(3 * j + 1) = contour(j).v(1)
              pts(3 * j + 2) = zval
              gluTessVertex tObj, pts(3 * j), pts(3 * j)
           Next
        End If
        gluTessEndContour tObj

    gluTessEndPolygon tObj
    gluDeleteTess tObj
End Sub

'-------------------------------------------------------------------------==
' This routine does what it says: It draws a counter-clockwise cap
' * from a 3D contour loop list
'private sub draw_front_contour_cap (ncp&,   ' number of contour points
'                             gleDouble contour()(3))    ' 3D contour
'-------------------------------------------------------------------------==
Private Sub draw_front_contour_cap(ncp&, contour() As gleVector, Index&)
Dim j&
Dim tObj&
   tObj = gluNewTess
   gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
   gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
   gluTessCallback tObj, GLU_END, AddressOf gleEnd
   gluTessBeginPolygon tObj, 0
        gluTessBeginContour tObj
            For j = 0 To ncp - 1
               gluTessVertex tObj, contour(Index + j).v(0), contour(Index + j).v(0)
            Next
        gluTessEndContour tObj
   gluTessEndPolygon tObj
   gluDeleteTess tObj
End Sub


'-------------------------------------------------------------------------==
' This routine does what it says: It draws a clockwise cap
' * from a 3D contour loop list
'private sub draw_back_contour_cap (ncp&,    ' number of contour points
'                             gleDouble contour()(3))    ' 3D contour
'-------------------------------------------------------------------------==
Private Sub draw_back_contour_cap(ncp&, contour() As gleVector, Index&)
Dim j&
Dim tObj&
    tObj = gluNewTess
    gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
    gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
    gluTessCallback tObj, GLU_END, AddressOf gleEnd
    gluTessBeginPolygon tObj, 0
        gluTessBeginContour tObj
        ' draw the end cap
        ' draw the loop clockwise for the back cap
        ' the sense of the loop is reversed for backfacing culling
        For j = ncp - 1 To 0 Step -1
            gluTessVertex tObj, contour(Index + j).v(0), contour(Index + j).v(0)
        Next
        gluTessEndContour tObj
    gluTessEndPolygon tObj
    gluDeleteTess tObj
End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
' * Essentially, we assume that the proper transformations have already
' * been performed to properly orient the tube segment -- our only task
' * left is to render
' PLAIN - NO COLOR, NO NORMAL
'public sub draw_raw_segment_plain (ncp&,       ' number of contour points
'                             gleDouble contour()(2),    ' 2D contour
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_plain(gc As gleGC, ncp&, contour() As gleTwoVec, inext&, lng#)
Dim j&
Dim pt#(0 To 2)
    ' draw the tube segment
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        V3F gc, pt, j, tFRONT
        pt(2) = -lng
        V3F gc, pt, j, tBACK
    Next

   If gc.ContourStyle = gleCLOSED Then
      ' connect back up to first point of contour
      pt(0) = contour(0).v(0)
      pt(1) = contour(0).v(1)
      pt(2) = 0
      V3F gc, pt, 0, tFRONT
   
      pt(2) = -lng
      V3F gc, pt, 0, tBACK
   End If

   glEnd

   ' draw the endcaps, if the join style calls for it
   If gc.CapStyle = gleCAPS Then
      ' draw the front cap
      draw_raw_style_end_cap ncp, contour, 0, 1 'True
      ' draw the back cap
      draw_raw_style_end_cap ncp, contour, -lng, False
   End If

End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
' * Essentially, we assume that the proper transformations have already
' * been performed to properly orient the tube segment -- our only task
' * left is to render
' COLOR -- DRAW ONLY COLOR
'private sub draw_raw_segment_color (ncp&,       ' number of contour points
'                             gleDouble contour()(2),    ' 2D contour
'                             float color_array()(3),    ' color of polyline
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_color(gc As gleGC, ncp&, contour() As gleTwoVec, _
                        color_array() As gleColor, inext&, lng#)
Dim j&
Dim pt#(0 To 2)
   ' draw the tube segment
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        glColor3fv color_array(inext - 1).v(0)
        V3F gc, pt, j, tFRONT
        pt(2) = -lng
        glColor3fv color_array(inext).v(0)
        V3F gc, pt, j, tBACK
    Next
   If gc.ContourStyle = gleCLOSED Then
      ' connect back up to first point of contour
      pt(0) = contour(0).v(0)
      pt(1) = contour(0).v(1)
      pt(2) = 0
   
      glColor3fv color_array(inext - 1).v(0)
      V3F gc, pt, 0, tFRONT
   
      pt(2) = -lng
      glColor3fv color_array(inext).v(0)
      V3F gc, pt, 0, tBACK
   End If

   glEnd

   ' draw the endcaps, if the join style calls for it
   If gc.CapStyle = gleCAPS Then

      ' draw the front cap
      glColor3fv color_array(inext - 1).v(0)
      draw_raw_style_end_cap ncp, contour, 0, True

      ' draw the back cap
      glColor3fv color_array(inext).v(0)
      draw_raw_style_end_cap ncp, contour, -lng, False
   End If

End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
' * Essentially, we assume that the proper transformations have already
' * been performed to properly orient the tube segment -- our only task
' * left is to render
' EDGE_N -- DRAW ONLY EDGE NORMALS
'private sub draw_raw_segment_edge_n (ncp&,  ' number of contour points
'                             gleDouble contour()(2),    ' 2D contour
'                             gleDouble cont_normal()(2),' 2D normal vecs
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_edge_n(gc As gleGC, ncp&, contour() As gleTwoVec, _
            cont_normal() As gleTwoVec, inext&, lng#)
Dim j&
Dim pt#(0 To 2)
Dim norm#(0 To 2)
    ' draw the tube segment
    norm(2) = 0
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        norm(0) = cont_normal(j).v(0)
        norm(1) = cont_normal(j).v(1)
        N3F gc, norm
    
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        V3F gc, pt, j, tFRONT
    
        pt(2) = -lng
        V3F gc, pt, j, tBACK
    Next

    If gc.ContourStyle = gleCLOSED Then
        ' connect back up to first point of contour
        norm(0) = cont_normal(0).v(0)
        norm(1) = cont_normal(0).v(1)
        norm(2) = 0
        N3F gc, norm
        
        pt(0) = contour(0).v(0)
        pt(1) = contour(0).v(1)
        pt(2) = 0
        V3F gc, pt, 0, tFRONT
        pt(2) = -lng
        V3F gc, pt, 0, tBACK
    End If

    glEnd

    ' draw the endcaps, if the join style calls for it
    If gc.CapStyle = gleCAPS Then
    
        ' draw the front cap
        norm(0) = 0
        norm(1) = 0
        norm(2) = 1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, 0, True
        
        ' draw the back cap
        norm(2) = -1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, -lng, False
    End If
End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
' * Essentially, we assume that the proper transformations have already
' * been performed to properly orient the tube segment -- our only task
' * left is to render
' C_AND_EDGE_N -- DRAW EDGE NORMALS AND COLORS
'private sub draw_raw_segment_c_and_edge_n (ncp&,    ' number of contour points
'                             gleDouble contour()(2),    ' 2D contour
'                             float color_array()(3),    ' color of polyline
'                             gleDouble cont_normal()(2),' 2D normal vecs
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_c_and_edge_n(gc As gleGC, ncp&, contour() As gleTwoVec, _
        color_array() As gleColor, cont_normal() As gleTwoVec, inext&, lng#)
Dim j&
Dim pt#(0 To 2)
Dim norm#(0 To 2)
    ' draw the tube segment
    norm(2) = 0
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 1
        glColor3fv color_array(inext - 1).v(0)
        norm(0) = cont_normal(j).v(0)
        norm(1) = cont_normal(j).v(1)
        N3F gc, norm
        
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        V3F gc, pt, j, tFRONT
        
        glColor3fv color_array(inext).v(0)
        N3F gc, norm
        
        pt(2) = -lng
        V3F gc, pt, j, tBACK
    Next

    If gc.ContourStyle = gleCLOSED Then
        ' connect back up to first point of contour
        glColor3fv color_array(inext - 1).v(0)
        
        norm(0) = cont_normal(0).v(0)
        norm(1) = cont_normal(0).v(1)
        N3F gc, norm
        
        pt(0) = contour(0).v(0)
        pt(1) = contour(0).v(1)
        pt(2) = 0
        V3F gc, pt, 0, tFRONT
        
        
        glColor3fv color_array(inext).v(0)
        norm(0) = cont_normal(0).v(0)
        norm(1) = cont_normal(0).v(1)
        N3F gc, norm
        
        pt(2) = -lng
        V3F gc, pt, 0, tBACK
    End If

    glEnd

    ' draw the endcaps, if the join style calls for it
    If gc.CapStyle = gleCAPS Then
    
        ' draw the front cap
        glColor3fv color_array(inext - 1).v(0)
        norm(0) = 0
        norm(1) = 0
        norm(2) = 1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, 0, True
        
        ' draw the back cap
        glColor3fv color_array(inext).v(0)
        norm(2) = -1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, -lng, False
    End If
End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
' * Essentially, we assume that the proper transformations have already
' * been performed to properly orient the tube segment -- our only task
' * left is to render
' FACET_N -- DRAW ONLY FACET NORMALS

'private sub draw_raw_segment_facet_n (ncp&, ' number of contour points
'                             gleDouble contour(,2),    ' 2D contour
'                             gleDouble cont_normal(,2),' 2D normal vecs
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_facet_n(gc As gleGC, ncp&, contour() As gleTwoVec, _
            cont_normal() As gleTwoVec, inext&, lng#)
Dim j&
Dim pt#(0 To 2)
Dim norm#(0 To 2)
    ' draw the tube segment
    norm(2) = 0
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2
        ' facet normals require one normal per four vertices
        norm(0) = cont_normal(j).v(0)
        norm(1) = cont_normal(j).v(1)
        N3F gc, norm
        
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        V3F gc, pt, j, tFRONT
        
        pt(2) = -lng
        V3F gc, pt, j, tBACK
        
        pt(0) = contour(j + 1).v(0)
        pt(1) = contour(j + 1).v(1)
        pt(2) = 0
        V3F gc, pt, j + 1, tFRONT
        
        pt(2) = -lng
        V3F gc, pt, j + 1, tBACK
    Next

    If gc.ContourStyle = gleCLOSED Then
        ' connect back up to first point of contour
        norm(0) = cont_normal(ncp - 1).v(0)
        norm(1) = cont_normal(ncp - 1).v(1)
        N3F gc, norm
        
        pt(0) = contour(ncp - 1).v(0)
        pt(1) = contour(ncp - 1).v(1)
        pt(2) = 0
        V3F gc, pt, ncp - 1, tFRONT
        
        pt(2) = -lng
        V3F gc, pt, ncp - 1, tBACK
        
        pt(0) = contour(0).v(0)
        pt(1) = contour(0).v(1)
        pt(2) = 0
        V3F gc, pt, 0, tFRONT
        
        pt(2) = -lng
        V3F gc, pt, 0, tBACK
    End If
    
    glEnd
    
    ' draw the endcaps, if the join style calls for it
    If gc.CapStyle = gleCAPS Then
    
        ' draw the front cap
        norm(0) = 0
        norm(1) = 0
        norm(2) = 1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, 0, True
        
        ' draw the back cap
        norm(2) = -1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, -lng, False
    End If
End Sub

'-------------------------------------------------------------------------==
' This routine draws a segment of raw-join-style tubing.
 '* Essentially, we assume that the proper transformations have already
 '* been performed to properly orient the tube segment -- our only task
 '* left is to render
' C_AND_FACET_N -- DRAW FACET NORMALS AND COLORS

'private sub draw_raw_segment_c_and_facet_n (ncp&,   ' number of contour points
'                             gleDouble contour(,2),    ' 2D contour
'                             float color_array(,3),    ' color of polyline
'                             gleDouble cont_normal(,2),' 2D normal vecs
'                             inext&,
'                             gleDouble lng)
'-------------------------------------------------------------------------==
Private Sub draw_raw_segment_c_and_facet_n(gc As gleGC, ncp&, _
                             contour() As gleTwoVec, color_array() As gleColor, _
                             cont_normal() As gleTwoVec, inext&, lng#)
Dim j&
Dim pt#(0 To 2), norm#(0 To 2)

    ' draw the tube segment
    norm(2) = 0
    BGNTMESH gc, inext, lng
    For j = 0 To ncp - 2 '1; j++) {
        ' facet normals require one normal per four vertices;
        ' * However, we have to respecify normal each time at each vertex
        ' * so that the lighting equation gets triggered.  (V3F does NOT
        ' * automatically trigger the lighting equations -- it only
        ' * triggers when there is a local light)
        'todo- check if this is true
        glColor3fv color_array(inext - 1).v(0)
        
        norm(0) = cont_normal(j).v(0)
        norm(1) = cont_normal(j).v(1)
        N3F gc, norm
        
        pt(0) = contour(j).v(0)
        pt(1) = contour(j).v(1)
        pt(2) = 0
        V3F gc, pt, j, tFRONT
        
        glColor3fv color_array(inext).v(0)
        N3F gc, norm
        pt(2) = -lng
        V3F gc, pt, j, tBACK
    
    
        glColor3fv color_array(inext - 1).v(0)
        N3F gc, norm
        
        pt(0) = contour(j + 1).v(0)
        pt(1) = contour(j + 1).v(1)
        pt(2) = 0
        V3F gc, pt, j + 1, tFRONT
        
        glColor3fv color_array(inext).v(0)
        N3F gc, norm
        pt(2) = -lng
        V3F gc, pt, j + 1, tBACK
    Next

    If gc.ContourStyle = gleCLOSED Then
        ' connect back up to first point of contour
        pt(0) = contour(ncp - 1).v(0)
        pt(1) = contour(ncp - 1).v(1)
        pt(2) = 0
        glColor3fv color_array(inext - 1).v(0)
        
        norm(0) = cont_normal(ncp - 1).v(0)
        norm(1) = cont_normal(ncp - 1).v(1)
        N3F gc, norm
        V3F gc, pt, ncp - 1, tFRONT
        
        glColor3fv color_array(inext).v(0)
        N3F gc, norm
        
        pt(2) = -lng
        V3F gc, pt, ncp - 1, tBACK
        
        glColor3fv color_array(inext - 1).v(0)
        
        norm(0) = cont_normal(0).v(0)
        norm(1) = cont_normal(0).v(1)
        N3F gc, norm
        
        pt(0) = contour(0).v(0)
        pt(1) = contour(0).v(1)
        pt(2) = 0
        V3F gc, pt, 0, tFRONT
        
        glColor3fv color_array(inext).v(0)
        N3F gc, norm
        
        pt(2) = -lng
        V3F gc, pt, 0, tBACK
    End If
   
   glEnd

    ' draw the endcaps, if the join style calls for it
    If gc.CapStyle = gleCAPS Then
    
        ' draw the front cap
        glColor3fv color_array(inext - 1).v(0)
        norm(0) = 0
        norm(1) = 0
        norm(2) = 1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, 0, True
        
        ' draw the back cap
        glColor3fv color_array(inext).v(0)
        norm(2) = -1
        N3F gc, norm
        draw_raw_style_end_cap ncp, contour, -lng, False
    End If

End Sub

