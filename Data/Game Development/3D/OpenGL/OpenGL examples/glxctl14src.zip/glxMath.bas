Attribute VB_Name = "glxMath"
Option Explicit

'-------------------------------------------------------------------------------------
'set current color from RGB255 values
Public Sub SetGLColor(ByVal Color&)
Dim r%, g%, B%
    r = GetRValue(Color)
    g = GetGValue(Color)
    B = GetBValue(Color)
    glColor3f r / 255, g / 255, B / 255
End Sub

'-------------------------------------------------------------------------------------
'return the 255 values for the color components
Public Function GetRValue(ByVal X As Long) As Byte
    GetRValue = (X \ &H10000) And &HFF
End Function

Public Function GetGValue(ByVal X As Long) As Byte
    GetGValue = (X \ &H100) And &HFF
End Function

Public Function GetBValue(ByVal X As Long) As Byte
    GetBValue = X And &HFF
End Function

'-------------------------------------------------------------------------------------
Public Function DegToRadf!(ByVal A!)
DegToRadf = A * PI * ONE_OVER_180
End Function

Public Function RadToDegf!(ByVal A!)
RadToDegf = (A * 180) * ONE_OVER_PI
End Function

'-------------------------------------------------------------------------
Public Function ArcSin!(ByVal X!)
If X >= 1 Then
    ArcSin = PI / 2
ElseIf X <= -1 Then
    ArcSin = -PI / 2
Else
    ArcSin = Atn(X / Sqr(-X * X + 1))
End If
End Function

'-------------------------------------------------------------------------
Public Function ArcCos!(ByVal X!)
If X >= 1 Then
    ArcCos = 0
ElseIf X <= -1 Then
    ArcCos = PI
Else
    ArcCos = Atn(-X / Sqr(-X * X + 1)) + 2 * Atn(1)
End If
End Function

'-------------------------------------------------------------------------
Public Function ArcCosd#(ByVal X#)
Dim tmp#
If X >= 1 Then
    ArcCosd = 0
ElseIf X <= -1 Then
    ArcCosd = PI
Else
    ArcCosd = Atn(-X / Sqr(-X * X + 1)) + 2 * Atn(1)
End If
End Function

'-------------------------------------------------------------------------
'Ugggh! Here's a new atan2. Anyone want to write a short
'essay on this function?
'in radians
'-------------------------------------------------------------------------
Function Atan2!(ByVal X!, ByVal Y!)
    'On Error Resume Next
    '0 to PI
    If Y = 0 Then
        If X = 0 Then
            Atan2 = 0
        ElseIf X > 0 Then
            Atan2 = 0 'PI / 2
        Else
            Atan2 = PI '-PI / 2
        End If
    ElseIf X = 0 Then
        If Y > 0 Then
            Atan2 = PI / 2
        Else
            Atan2 = -PI / 2
        End If
    ElseIf X > 0 Then
        Atan2 = Atn(Y / X)
    Else
        Atan2 = (PI - Atn(Abs(Y) / Abs(X))) * Sgn(Y)
    End If
End Function

Function Atan2d#(ByVal X#, ByVal Y#)
    'On Error Resume Next
    '0 to PI
    If Y = 0 Then
        If X = 0 Then
            Atan2d = 0
        ElseIf X > 0 Then
            Atan2d = 0 'PI / 2
        Else
            Atan2d = PI '-PI / 2
        End If
    ElseIf X = 0 Then
        If Y > 0 Then
            Atan2d = PI / 2
        Else
            Atan2d = -PI / 2
        End If
    ElseIf X > 0 Then
        Atan2d = Atn(Y / X)
    Else
        Atan2d = (PI - Atn(Abs(Y) / Abs(X))) * Sgn(Y)
    End If
End Function

'-------------------------------------------------------------------------
'radians
'Public Function Atan2f!(X!, Y!)
'Dim r#, r2#
'    'ATan2 = ATan2D(X, Y) * PI / 180#
'    If (Y = 0) Then
'        If (X = 0) Then
'            Atan2f = 0
'        ElseIf (X > 0) Then
'            Atan2f = PI / 2
'        Else
'            Atan2f = -PI / 2
'        End If
'        Exit Function
'    End If
'    '
'    r = Atn(X / Y)
'    '
'    '3
'    If (X < 0) And (Y < 0) Then
'        'ATan2 = r + PI
'        'ATan2 = 3 * PI / 2 - r
'        'r2 = r + PI
'        r2 = 3 * PI / 2 - r
'        'Debug.Print r2
'        Atan2f = r2
'    ElseIf (X < 0) And (Y > 0) Then
'        'Debug.Print r
'        r2 = PI / 2 - r
'        Atan2f = r2
'        'ATan2 = r2
'    '4
'    ElseIf (X > 0) And (Y < 0) Then
'        'ATan2 = r + PI
'        r2 = 3 * PI / 2 - r
'        Atan2f = 3 * PI / 2 - r
'        'Debug.Print r
'        'Debug.Print r2
'    Else
'        Atan2f = r
'    End If
'End Function

