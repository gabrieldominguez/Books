============================================================================

                                  BooGame 0.4.2.0
                     Copyright (c) The BooGame Project 2006

============================================================================

                           http://boogame.sourceforge.net


----------------------------------------------------------------------------
 Introduction
----------------------------------------------------------------------------

        BooGame is an object oriented CLS-compliant, 2D game engine
        framework that provides high-level access to video, audio, keyboard,
        mouse, joystick, embedded scripting and various image formats.
        Written in C#, its target platforms are .NET 1.1, .NET 2.0 and Mono.


----------------------------------------------------------------------------
 Features
----------------------------------------------------------------------------

        - CLS Compliant
        - Builds in Mono, .NET 1.1 and .NET 2.0
        - High level and extremely easy to use
        - Hardware accelerated 2D graphics via OpenGL
        - Audio output (wav, mp3, ogg, mid, mod, xm, it, etc)
        - TrueType Font rendering
        - User input through the keyboard, mouse and joystick
        - Scripting support
        - Texture loading (bmp, png, jpg, tga, gif, etc)
        - Tile Studio mapping support


----------------------------------------------------------------------------
 Libraries
----------------------------------------------------------------------------

        In order to provide its strong feature set, BooGame takes advantage
        of the following libraries:
        
        Scripting:
                The fantastic Boo programming language is used for its under
                laying scripting system.
                
        Graphics:
                BooGame uses OpenGL at an extremely high level to provide
                hardware accelerated 2D video rendering.
        
        Images:
                In order to support a large amount of image formats, 
                BooGame makes use of DevIL/OpenIL.
                
        Input:
                FreeGLUT is used for window, keyboard, mouse and joystick
                management.
                
        File System:
                For its advanced file system, BooGame makes use of
                PhysFS's zip loading capabilities.
                
        Audio:
                In order to provide high level audio access, BooGame uses
                FMOD Ex.


----------------------------------------------------------------------------
 Developing With BooGame
----------------------------------------------------------------------------

        To build BooGame, just run Build.bat and BooGame will use the
        provided installation of NAnt to create the Release binaries.  It
        will move all binaries and all Win32 dependancies to the /bin
        folder.

        To create the project files, you must execute the right batch file.
        If you're using Visual Studio 2005, run VS2005.bat.  If you're
        using SharpDevelop, run SharpDevelop.bat.  Be sure to remember to
        find the Windows dependancies in the lib/win32deps folder and the
        example data files in the /Data directories.

        You will find all API references in the /docs folder.  BooGames uses
        NDoc to build the API reference material.  A good way of learning
        how to use BooGame is to look at the examples and play with them.
        Change some of the values and see how it's affected.  Later on, some
        tutorials might be made to guide through the development of a simple
        BooGame program.


----------------------------------------------------------------------------
 Credits
----------------------------------------------------------------------------

        Lead Developer:
                Rob Loach (http://robloach.net)

        Contributers:
                Rick W (Pipo DeClown, Lick)
                Morgan LaMoore (morganl@gmail.com)
                Daniel Alves (http://statussoft.no-ip.org)

        Thank You:
                The Tao Framework (http://www.taoframework.com)
                Boo Programming Language (http://boo.codehaus.org)


----------------------------------------------------------------------------
 End User License Agreement
----------------------------------------------------------------------------

        BooGame
        Copyright (C) 2006 The BooGame Project
        
        This library is free software; you can redistribute it and/or
        modify it under the terms of the GNU Lesser General Public
        License as published by the Free Software Foundation; either
        version 2.1 of the License, or (at your option) any later version.
        
        This library is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
        Lesser General Public License for more details.
        
        You should have received a copy of the GNU Lesser General Public
        License along with this library; if not, write to the Free Software
        Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
        USA