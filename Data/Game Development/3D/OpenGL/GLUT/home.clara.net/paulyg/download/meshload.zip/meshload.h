

void load_simple_mesh (GLuint &list, char *file_name);


