VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CImage"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: thin wrapper on a glxTexture
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES:
'--------------------------------------------------------------------

Dim m_Filename$
Public Tex As glxTexture

Private Sub Class_Initialize()
    Set Tex = gCtl.NewTexture
End Sub

Public Property Let Filename(file$)
Dim r&, Pic As StdPicture
    m_Filename = file
    If StrComp(Right$(file, 3), "bmp") = 0 Then
        r = Tex.LoadTextureFile(file)
    Else
        Set Pic = LoadPicture(file)
        If Pic Is Nothing Then Exit Property
        r = Tex.LoadPicture(Pic)
    End If
End Property

Public Property Get Filename$()
Filename = m_Filename$
End Property


Public Function Save(Path$) As Boolean
Dim s$, file$, dest$
On Error GoTo EH
    file = ExtractFileName(m_Filename)
    dest = Path & "\" & file
    s = Dir(dest)
    If Len(s) = 0 Then
        FileCopy m_Filename, dest
    End If
    m_Filename = dest
    Save = True
    Exit Function
EH:
    'do something
    Debug.Assert 0
End Function
