class AwesomeActor extends Actor
    placeable;

var int Int1;

function PostBeginPlay()
{
    if(Int1 == 5)
    {
        `log("Int1 equals 5");
        return;
    }

    `log("This will not log");
}

defaultproperties
{
    Int1=5

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
