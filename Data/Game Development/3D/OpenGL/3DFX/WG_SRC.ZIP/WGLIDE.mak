# Microsoft Developer Studio Generated NMAKE File, Based on WGLIDE.dsp
!IF "$(CFG)" == ""
CFG=wglide - Win32 Release
!MESSAGE No configuration specified. Defaulting to wglide - Win32 Release.
!ENDIF 

!IF "$(CFG)" != "wglide - Win32 Release" && "$(CFG)" != "wglide - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "WGLIDE.mak" CFG="wglide - Win32 Release"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "wglide - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "wglide - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "wglide - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\glide2x.dll"

!ELSE 

ALL : "$(OUTDIR)\glide2x.dll"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\B2wg.obj"
	-@erase "$(INTDIR)\Cwg.obj"
	-@erase "$(INTDIR)\Detmmx.obj"
	-@erase "$(INTDIR)\Dib.obj"
	-@erase "$(INTDIR)\Dxdraw.obj"
	-@erase "$(INTDIR)\Exports.obj"
	-@erase "$(INTDIR)\Gamma.obj"
	-@erase "$(INTDIR)\Gammadlg.obj"
	-@erase "$(INTDIR)\Imports.obj"
	-@erase "$(INTDIR)\Inifile.obj"
	-@erase "$(INTDIR)\Main.obj"
	-@erase "$(INTDIR)\Msgbox.obj"
	-@erase "$(INTDIR)\Osswg.obj"
	-@erase "$(INTDIR)\Ovlwg.obj"
	-@erase "$(INTDIR)\Pcopy.obj"
	-@erase "$(INTDIR)\Sbwg.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\Wg.res"
	-@erase "$(OUTDIR)\glide2x.dll"
	-@erase "$(OUTDIR)\glide2x.exp"
	-@erase "$(OUTDIR)\glide2x.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /G5 /Gz /MT /W3 /GX /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS"\
 /D "WIN32_LEAN_AND_MEAN" /D "__MSC__" /FAcs /Fa"$(INTDIR)\\"\
 /Fp"$(INTDIR)\WGLIDE.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Wg.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\WGLIDE.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo\
 /subsystem:windows /dll /incremental:no /pdb:"$(OUTDIR)\glide2x.pdb"\
 /machine:I386 /out:"$(OUTDIR)\glide2x.dll" /implib:"$(OUTDIR)\glide2x.lib" 
LINK32_OBJS= \
	"$(INTDIR)\B2wg.obj" \
	"$(INTDIR)\Cwg.obj" \
	"$(INTDIR)\Detmmx.obj" \
	"$(INTDIR)\Dib.obj" \
	"$(INTDIR)\Dxdraw.obj" \
	"$(INTDIR)\Exports.obj" \
	"$(INTDIR)\Gamma.obj" \
	"$(INTDIR)\Gammadlg.obj" \
	"$(INTDIR)\Imports.obj" \
	"$(INTDIR)\Inifile.obj" \
	"$(INTDIR)\Main.obj" \
	"$(INTDIR)\Msgbox.obj" \
	"$(INTDIR)\Osswg.obj" \
	"$(INTDIR)\Ovlwg.obj" \
	"$(INTDIR)\Pcopy.obj" \
	"$(INTDIR)\Sbwg.obj" \
	"$(INTDIR)\Wg.res"

"$(OUTDIR)\glide2x.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\glide2x.dll"

!ELSE 

ALL : "$(OUTDIR)\glide2x.dll"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\B2wg.obj"
	-@erase "$(INTDIR)\Cwg.obj"
	-@erase "$(INTDIR)\Detmmx.obj"
	-@erase "$(INTDIR)\Dib.obj"
	-@erase "$(INTDIR)\Dxdraw.obj"
	-@erase "$(INTDIR)\Exports.obj"
	-@erase "$(INTDIR)\Gamma.obj"
	-@erase "$(INTDIR)\Gammadlg.obj"
	-@erase "$(INTDIR)\Imports.obj"
	-@erase "$(INTDIR)\Inifile.obj"
	-@erase "$(INTDIR)\Main.obj"
	-@erase "$(INTDIR)\Msgbox.obj"
	-@erase "$(INTDIR)\Osswg.obj"
	-@erase "$(INTDIR)\Ovlwg.obj"
	-@erase "$(INTDIR)\Pcopy.obj"
	-@erase "$(INTDIR)\Sbwg.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(INTDIR)\Wg.res"
	-@erase "$(OUTDIR)\glide2x.dll"
	-@erase "$(OUTDIR)\glide2x.exp"
	-@erase "$(OUTDIR)\glide2x.ilk"
	-@erase "$(OUTDIR)\glide2x.lib"
	-@erase "$(OUTDIR)\glide2x.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /G5 /Gz /MTd /W3 /Gm /GX /Zi /Od /D "_DEBUG" /D "WIN32" /D\
 "_WINDOWS" /D "WIN32_LEAN_AND_MEAN" /D "__MSC__" /FAcs /Fa"$(INTDIR)\\"\
 /Fp"$(INTDIR)\WGLIDE.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Wg.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\WGLIDE.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo\
 /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\glide2x.pdb" /debug\
 /machine:I386 /out:"$(OUTDIR)\glide2x.dll" /implib:"$(OUTDIR)\glide2x.lib" 
LINK32_OBJS= \
	"$(INTDIR)\B2wg.obj" \
	"$(INTDIR)\Cwg.obj" \
	"$(INTDIR)\Detmmx.obj" \
	"$(INTDIR)\Dib.obj" \
	"$(INTDIR)\Dxdraw.obj" \
	"$(INTDIR)\Exports.obj" \
	"$(INTDIR)\Gamma.obj" \
	"$(INTDIR)\Gammadlg.obj" \
	"$(INTDIR)\Imports.obj" \
	"$(INTDIR)\Inifile.obj" \
	"$(INTDIR)\Main.obj" \
	"$(INTDIR)\Msgbox.obj" \
	"$(INTDIR)\Osswg.obj" \
	"$(INTDIR)\Ovlwg.obj" \
	"$(INTDIR)\Pcopy.obj" \
	"$(INTDIR)\Sbwg.obj" \
	"$(INTDIR)\Wg.res"

"$(OUTDIR)\glide2x.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(CFG)" == "wglide - Win32 Release" || "$(CFG)" == "wglide - Win32 Debug"
SOURCE=.\B2wg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_B2WG_=\
	".\Dib.h"\
	".\Gamma.h"\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\B2wg.obj" : $(SOURCE) $(DEP_CPP_B2WG_) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_B2WG_=\
	".\Dib.h"\
	".\Gamma.h"\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\B2wg.obj" : $(SOURCE) $(DEP_CPP_B2WG_) "$(INTDIR)"


!ENDIF 

SOURCE=.\Cwg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_CWG_C=\
	".\B2wg.h"\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Osswg.h"\
	".\Ovlwg.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	".\Sbwg.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Cwg.obj" : $(SOURCE) $(DEP_CPP_CWG_C) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_CWG_C=\
	".\B2wg.h"\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Osswg.h"\
	".\Ovlwg.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	".\Sbwg.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Cwg.obj" : $(SOURCE) $(DEP_CPP_CWG_C) "$(INTDIR)"


!ENDIF 

SOURCE=.\Detmmx.c

"$(INTDIR)\Detmmx.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Dib.c
DEP_CPP_DIB_C=\
	".\Msgbox.h"\
	

"$(INTDIR)\Dib.obj" : $(SOURCE) $(DEP_CPP_DIB_C) "$(INTDIR)"


SOURCE=.\Dxdraw.cpp

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_DXDRA=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	

"$(INTDIR)\Dxdraw.obj" : $(SOURCE) $(DEP_CPP_DXDRA) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_DXDRA=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	

"$(INTDIR)\Dxdraw.obj" : $(SOURCE) $(DEP_CPP_DXDRA) "$(INTDIR)"


!ENDIF 

SOURCE=.\Exports.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_EXPOR=\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Exports.obj" : $(SOURCE) $(DEP_CPP_EXPOR) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_EXPOR=\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Exports.obj" : $(SOURCE) $(DEP_CPP_EXPOR) "$(INTDIR)"


!ENDIF 

SOURCE=.\Gamma.c

"$(INTDIR)\Gamma.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Gammadlg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_GAMMA=\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Gammadlg.obj" : $(SOURCE) $(DEP_CPP_GAMMA) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_GAMMA=\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Gammadlg.obj" : $(SOURCE) $(DEP_CPP_GAMMA) "$(INTDIR)"


!ENDIF 

SOURCE=.\Imports.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_IMPOR=\
	".\Inifile.h"\
	".\Msgbox.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Imports.obj" : $(SOURCE) $(DEP_CPP_IMPOR) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_IMPOR=\
	".\Inifile.h"\
	".\Msgbox.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Imports.obj" : $(SOURCE) $(DEP_CPP_IMPOR) "$(INTDIR)"


!ENDIF 

SOURCE=.\Inifile.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_INIFI=\
	".\Detmmx.h"\
	".\Dxdraw.h"\
	".\Inifile.h"\
	".\Main.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Inifile.obj" : $(SOURCE) $(DEP_CPP_INIFI) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_INIFI=\
	".\Detmmx.h"\
	".\Dxdraw.h"\
	".\Inifile.h"\
	".\Main.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Inifile.obj" : $(SOURCE) $(DEP_CPP_INIFI) "$(INTDIR)"


!ENDIF 

SOURCE=.\Main.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_MAIN_=\
	".\Cwg.h"\
	".\Imports.h"\
	".\Inifile.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Main.obj" : $(SOURCE) $(DEP_CPP_MAIN_) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_MAIN_=\
	".\Cwg.h"\
	".\Imports.h"\
	".\Inifile.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Main.obj" : $(SOURCE) $(DEP_CPP_MAIN_) "$(INTDIR)"


!ENDIF 

SOURCE=.\Msgbox.c

"$(INTDIR)\Msgbox.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Osswg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_OSSWG=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Osswg.obj" : $(SOURCE) $(DEP_CPP_OSSWG) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_OSSWG=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Osswg.obj" : $(SOURCE) $(DEP_CPP_OSSWG) "$(INTDIR)"


!ENDIF 

SOURCE=.\Ovlwg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_OVLWG=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Ovlwg.obj" : $(SOURCE) $(DEP_CPP_OVLWG) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_OVLWG=\
	".\Dxdraw.h"\
	".\Errcode.h"\
	".\Gamma.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Ovlwg.obj" : $(SOURCE) $(DEP_CPP_OVLWG) "$(INTDIR)"


!ENDIF 

SOURCE=.\Pcopy.c

"$(INTDIR)\Pcopy.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Sbwg.c

!IF  "$(CFG)" == "wglide - Win32 Release"

DEP_CPP_SBWG_=\
	".\Dib.h"\
	".\Gamma.h"\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Sbwg.obj" : $(SOURCE) $(DEP_CPP_SBWG_) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "wglide - Win32 Debug"

DEP_CPP_SBWG_=\
	".\Dib.h"\
	".\Gamma.h"\
	".\Gammadlg.h"\
	".\Inifile.h"\
	".\Main.h"\
	".\Msgbox.h"\
	".\Pcopy.h"\
	".\Pointers.h"\
	{$(INCLUDE)}"3dfx.h"\
	{$(INCLUDE)}"glide.h"\
	{$(INCLUDE)}"glidesys.h"\
	{$(INCLUDE)}"glideutl.h"\
	{$(INCLUDE)}"sst1vid.h"\
	

"$(INTDIR)\Sbwg.obj" : $(SOURCE) $(DEP_CPP_SBWG_) "$(INTDIR)"


!ENDIF 

SOURCE=.\Wg.rc

"$(INTDIR)\Wg.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)



!ENDIF 

