//--------------------------------------------------------------
// Animaci�n en 3D con OpenGL
// MOVIMIENTO SISTEMA SOLAR.
// Objetivo: Mostrar la animaci�n de objetos.
// Pulsar
// 'd'=aumenta los dias  o  'D'=disminuye los dias
// 'y'=aumenta los a�os  o  'Y'=disminuye los a�os
// 'm'=aumenta los meses o  'M'=disminuye los meses
// Daniel Beber - Diego Milone - Computaci�n II - 07/Junio/2002
//--------------------------------------------------------------

#include <stdio.h>
#include <GL/glut.h>

int year = 0, moon = 0, day = 0;

void init(void)
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
}

void display(void)
{
   glClear (GL_COLOR_BUFFER_BIT);
   glColor3f (1.0, 1.0, 1.0);

   glPushMatrix();

   glutWireSphere(.8, 20, 16);   /* Sol */

	glRotatef ((GLfloat) year, 0.0, 1.0, 0.0);
	glTranslatef (1.5, 0.0, 0.0);
	glRotatef ((GLfloat) day, 0.0, 1.0, 0.0);
	glColor3f (0.5, 0.5, 1.0);
	glutSolidSphere(0.3, 10, 8);    /* Planeta */

	glRotatef ((GLfloat) moon, 0.0, 1.0, 0.0);
	glTranslatef (1.0, 0.0, 0.0);
	glColor3f (0.0, 0.5, 0.5);
	glutWireSphere(0.1, 10, 8);    /* Luna */

   glPopMatrix();
   glutSwapBuffers();
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 20.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   gluLookAt (0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case 'd':
         day = (day + 10) % 360;
         glutPostRedisplay();
         break;
      case 'D':
         day = (day - 10) % 360;
         glutPostRedisplay();
         break;
      case 'y':
         year = (year + 5) % 360;
         glutPostRedisplay();
         break;
      case 'Y':
         year = (year - 5) % 360;
         glutPostRedisplay();
         break;
	  case 'm':
         moon = (moon + 5) % 360;
         glutPostRedisplay();
         break;
      case 'M':
         moon = (moon - 5) % 360;
         glutPostRedisplay();
         break;
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

void FuncionTimer(int value)
{ // Establece con qu� velocidad (en tiempo) se redibuja la pantalla
  glutPostRedisplay();                   // Redibujar la ventana
  glutTimerFunc(10, FuncionTimer, 0);    // Setup el pr�ximo timer
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize (500, 500);
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("Planetas - Pulsar 'd'-'D'-'m'-'M'-'y'-'Y'");
   init ();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutTimerFunc(10, FuncionTimer, 0); // velocidad (en tiempo) para mostrar
   glutMainLoop();
   return 0;
}

/*  MAKEFILE =============================================================
CXX=g++
OPCIONES=-g -Wall -I../util -I/usr/include/GL -I/bin -I/usr/include/w32api
DIRECTORIOS=
BIBLIOTECAS=-L/lib -lglut32 -lglu32 -lopengl32  -lm
all:
	${CXX} ${OPCIONES} animacion.cpp -o animacion ${DIRECTORIOS} ${BIBLIOTECAS}

void glutSolidSphere(GLdouble radius, GLint slices, GLint stacks);
void glutWireSphere(GLdouble radius,GLint slices, GLint stacks);

radius The radius of the sphere.
slices The number of subdivisions around the Z axis (similar to lines of longitude).
stacks The number of subdivisions along the Z axis (similar to lines of latitude).

*/
