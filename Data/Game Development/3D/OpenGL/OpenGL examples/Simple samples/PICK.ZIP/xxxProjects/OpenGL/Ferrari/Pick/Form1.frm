VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   213
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   312
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim m_hGLRC As Long 'parametro para criar area opengl
Const jl = 200

Function Initialize() As Boolean
Dim pfd As PIXELFORMATDESCRIPTOR
Dim r&, pos!(0 To 3)
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    r = ChoosePixelFormat(hDC, pfd)
    If r = 0 Then
        MsgBox "Fail"
        Initialize = False
        Exit Function
    End If
    r = SetPixelFormat(hDC, r, pfd)
 
    m_hGLRC = wglCreateContext(hDC)
    wglMakeCurrent hDC, m_hGLRC
    

    glClearColor 0, 0, 0, 1
    glClearDepth 1
    glShadeModel (GL_SMOOTH)
    
    glEnable GL_DEPTH_TEST
    glFrontFace GL_CCW
    
    '========
   
    Initialize = True
    
End Function

Sub EndProc()
    If m_hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hGLRC
    End If
End Sub

Sub Draw()
glColor3f 1, 1, 0
glLoadName (0)
glBegin (GL_QUADS)
    glVertex3d 0, 0, 0
    glVertex3d 50, 0, 0
    glVertex3d 50, 50, 0
    glVertex3d 0, 50, 0
glEnd

glColor3f 1, 0, 0
glLoadName (1)
glBegin (GL_QUADS)
    glVertex3d 0, 0, 50
    glVertex3d 50, 0, 50
    glVertex3d 50, 50, 50
    glVertex3d 0, 50, 50
glEnd

glColor3f 0, 1, 0
glLoadName (2)
glBegin (GL_QUADS)
    glVertex3d 0, 0, 100
    glVertex3d 50, 0, 100
    glVertex3d 50, 50, 100
    glVertex3d 0, 50, 100
glEnd

End Sub

Sub Render()
Static Busy As Boolean
Static rotacao As Integer, rz As Integer
    If Busy Then Exit Sub
    Busy = True
    '
    wglMakeCurrent hDC, m_hGLRC
    '=================================================
        
    glClear clrColorBufferBit Or clrDepthBufferBit
    Setviewport
     
    Draw
     
    '=================================================
    SwapBuffers hDC
    '
    wglMakeCurrent 0, 0
    Busy = False
End Sub

Sub Resize(ByVal w&, ByVal h&)
    glViewport 0, 0, w, h
    Setviewport
End Sub

Private Sub Setviewport()
Dim w As Long, h As Long

glMatrixMode GL_PROJECTION
glLoadIdentity
'===========================================
w = Me.ScaleWidth
h = Me.ScaleHeight
If w = 0 Then w = 1
If h = 0 Then h = 1

glOrtho -100, 100, -100, 100, -100, 100
gluLookAt 10, 10, 30, -10, -10, -10, 0, 0, 1

'===========================================
glMatrixMode GL_MODELVIEW
glLoadIdentity
End Sub

Private Sub Form_Load()
Initialize
Me.FontSize = 18
Me.ForeColor = RGB(255, 255, 255)
End Sub

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 1 Then Selection X, Y
End Sub

Private Sub Form_Paint()
Form_Resize
End Sub

Sub Selection(X As Single, Y As Single)
Dim hits As Long
Dim selectbuf(0 To 1023) As GLuint
Dim near As Long, dist As Double, itens() As Long
Dim w As Long, h As Long
Dim viewport(0 To 3) As Long

    '
    wglMakeCurrent hDC, m_hGLRC

    glSelectBuffer 1024, selectbuf(0)
    glRenderMode GL_SELECT
    glInitNames
    glPushName -1
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glGetIntegerv GL_VIEWPORT, viewport(0)
    gluPickMatrix X, viewport(3) - Y, 0.01, 0.01, viewport(0)
        
    w = Me.ScaleWidth
    h = Me.ScaleHeight
    glOrtho -100, 100, -100, 100, -100, 100
    gluLookAt 10, 10, 30, -10, -10, -10, 0, 0, 1
    
        Draw
        hits = glRenderMode(VBOpenGL.GL_Render)   'HERE HERE HERE
                      
        If hits = 0 Then Exit Sub
        If hits > 0 Then
            Beep
            ReDim itens(0 To hits - 1)
            near = 0
            dist = 4294967295#
            Do While (hits)
                If (selectbuf((hits - 1) * 4 + 1) < dist) Then
                    dist = selectbuf((hits - 1) * 4 + 1)
                    near = selectbuf((hits - 1) * 4 + 3)
                End If
                hits = hits - 1
            Loop
            Me.PSet (X, Y), RGB(255, 0, 0)
            Print near
        End If
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
EndProc
End Sub

Private Sub Form_Resize()
Dim w1 As Long, h1 As Long
    w1 = Me.ScaleWidth
    h1 = Me.ScaleHeight
    Resize w1, h1
    Render
End Sub
