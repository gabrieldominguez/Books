VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "About Wav2MP3 Wizard"
   ClientHeight    =   3390
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   3480
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3390
   ScaleWidth      =   3480
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdOk 
      Caption         =   "&Ok"
      Height          =   375
      Left            =   2880
      TabIndex        =   1
      Top             =   50
      Width           =   495
   End
   Begin VB.Label lblAbout 
      BackColor       =   &H80000009&
      BorderStyle     =   1  'Fixed Single
      Height          =   2775
      Left            =   120
      TabIndex        =   2
      Top             =   480
      Width           =   3255
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Wav2MP3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   480
      TabIndex        =   0
      Top             =   0
      Width           =   1620
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim Lines As String

Private Sub cmdOk_Click()
    frmAbout.Hide
    frmMain.Enabled = True
    frmMain.SetFocus
End Sub

Private Sub Command1_Click()
    
End Sub

Private Sub Form_Load()
    Open "FILE_ID.DIZ" For Input As #1

    Do While Not EOF(1)
        Input #1, Lines
        lblAbout.Caption = lblAbout.Caption & Lines & vbNewLine
    Loop
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmMain.Enabled = True
    frmMain.SetFocus
End Sub
