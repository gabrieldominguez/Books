using System;
using Microsoft.DirectX;
using System.Collections;

namespace ParticleSystems
{
    namespace Verlet
    {
        namespace GlobalConstraints
        {
            /// <summary>
            /// AxisAlignedBox umplements IGlobalConstraint. Makes sure that all
            /// particles are kept within the axis aligned box that's defined
            /// by two opposite two corner vectors.
            /// </summary>
            public class AxisAlignedBox : IGlobalConstraint
            {
                /// <summary>
                /// Constructor
                /// </summary>
                /// <param name="corner">A corner vector</param>
                /// <param name="oppositeCorner">A corner vector</param>
                public AxisAlignedBox(Vector3 corner, Vector3 oppositeCorner)
                {
                    mCorner = Vector3.Minimize(corner, oppositeCorner);
                    mOppositeCorner = Vector3.Maximize(corner, oppositeCorner);
                }

                /// <summary>
                /// Applies the global constraint to all particles in the list
                /// </summary>
                /// <param name="particles">An array of particles</param>
                public void Apply(Particle[] particles)
                {
                    int lIter = 0;
                    int lLength = particles.Length;
                    for(; lIter < lLength; ++lIter)
                    {
                        particles[lIter].Position = 
                            Vector3.Minimize(
                                mOppositeCorner, 
                                Vector3.Maximize(
                                    mCorner, 
                                    particles[lIter].Position));
                    }
                }

                /// <summary>
                /// Corner vector
                /// </summary>
                public Vector3 Corner
                {
                    get
                    {
                        return mCorner;
                    }
                }

                /// <summary>
                /// Opposite corner vector
                /// </summary>
                public Vector3 OppositeCorner
                {
                    get
                    {
                        return mOppositeCorner;
                    }
                }

                private Vector3 mCorner;
                private Vector3 mOppositeCorner;
            }
        }

    }
}