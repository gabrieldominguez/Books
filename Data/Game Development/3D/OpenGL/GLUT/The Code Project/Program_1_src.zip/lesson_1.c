//*************************************************************************
//
//  File Name: Lesson 1
//  Author   : Ali Baderedine
//  
//  Description: Just openning a window using GLUT library...
//  
//*************************************************************************

#include <gl/glut.h>

// Link the lib files to the program. This is not necessary 
// if you have added the lib names using Project/Settings/Link
#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "glut32.lib")
#pragma comment (lib, "glu32.lib")

//  define the window position on screen
int window_X_position;
int window_Y_position;

//  variables representing the window size
int window_width = 512;
int window_height = 512;

//  variable representing the window title
char *window_title = "Lesson 1";

//  Tells whether to display the window full screen or not
//  This is a boolean, but you know C doesn't support boolean.
//  Press Alt + Esc to exit a full screen.
int fullScreen = 0;

//  Function that initializes some values that won't change
//  throughout the program...
void init (void);

//  This function is used to display all the graphics objects
//  on the screen. It is the most important function in OpenGL.
//  Don't be confused, you can give 'display' another name like 'foo'...
//  This function gains its importance when you write the command
//  glutDisplayFunc (display) or glutDisplayFunc (foo) in function 'main'.
void display (void);

//  This function centers your window on the screen
void centerOnScreen (void);

void init ()
{	
	//  Set the clear color to be black. If you have any confusions about 
	//  how the color can be set, then here is a brief description.
	//  First, you must be familiar with RGBA. The A is alpha and is
	//  used for transperancy. The values range from 0.0 to 1.0
	//  To display yellow (255, 255, 0), then (255/255.0, 255/255.0, 0, 0) = 
	//  (1.0, 1.0, 0.0, 0.0) is the argument you specify to glClearColor.
	glClearColor (0.0, 0.0, 0.0, 0.0);
}

void display ()
{
	//  Clear the window or more specifically the frame buffer...
	//  This happens by replacing all the contents of the frame
	//  buffer by the clear color (black in our case)
	glClear (GL_COLOR_BUFFER_BIT);
	
	/* There is nothing to be displayed */
	
	//  Copy the contents of the frame buffer to the window so that
	//  they can be displayed... In other words, it forces execution 
	//  of GL commands in finite time
	glFlush ();
}

void centerOnScreen (void)
{
	//  Set the window position such that the window becomes centered
	window_X_position = (glutGet (GLUT_SCREEN_WIDTH) - window_width)/2;
	window_Y_position = (glutGet (GLUT_SCREEN_HEIGHT) - window_height)/2;
}

void main (int argc, char **argv)
{
	//  Center the window on the screen... Notice that I'm really 
	//  doing nothing but changing the varaibles window_X_position
	//  and window_Y_position.
	centerOnScreen ();

	//  Connect to the windowing system + create a window
	//  with the specified dimensions and position
	//  + set the display mode + specify the window title.
	glutInit(&argc, argv);
	glutInitWindowSize (window_width, window_height);
	glutInitWindowPosition (window_X_position, window_Y_position);
	glutInitDisplayMode (GLUT_RGB);
	glutCreateWindow (window_title);
	
	//  Initialize stuff that remain constant throughout the
	//  program.
	init();

	if (fullScreen)
		glutFullScreen ();
	
	// Set the display function
	glutDisplayFunc (display);

	glutMainLoop();
}

