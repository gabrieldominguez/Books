Attribute VB_Name = "mTexture"
Option Explicit
Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (Dest As Byte, Src As Byte, ByVal length&)


'---------------------------------------------------------------------------------------
Public Function FixPictureRGBA(Pic As Picture, w&, h&, _
                        Components&, GLFormat&, _
                        Data() As Byte) As Boolean
'------------------------------------
Dim r&, i&, j&
Dim bi As BITMAPINFO256
Dim siz&
Dim tmp As Byte
Dim DataSize&
Dim DataSizeTmp&
Dim tmpData() As Byte, pad&, pSrc&, pDest&
Dim Opacity!
Dim mr As Byte, mb As Byte, mg As Byte, mcol&
    If Pic Is Nothing Then Exit Function
    GLFormat = GL_RGBA
    Components = 4
    '
    'get the dimensions
    bi.bmiHeader.biSize = Len(bi.bmiHeader)
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 0
    bi.bmiHeader.biCompression = BI_RGB
    r = GetDIBits(frmMain.hDC, Pic.Handle, 0, 0, ByVal 0&, _
                ByVal VarPtr(bi), DIB_RGB_COLORS)
    'Debug.Print r
    'Debug.Assert 0
    h = bi.bmiHeader.biHeight
    w = bi.bmiHeader.biWidth
    pad = w Mod 4
    DataSizeTmp = Abs(h * w * 3)
    DataSize = Abs(h * w * 4)
    ReDim Data(0 To DataSize - 1)
    ReDim tmpData(0 To DataSizeTmp - 1 + pad * h)
    bi.bmiHeader.biBitCount = 24
    r = GetDIBits(frmMain.hDC, Pic.Handle, 0, bi.bmiHeader.biHeight, _
            tmpData(0), ByVal VarPtr(bi), DIB_RGB_COLORS)
    'Debug.Print r
    ' swap R and B
    If CX.UseMask Then
        'use lower left corner if color = -1
        mcol = CX.MaskColor
        If mcol = -1 Then
            mr = tmpData(2)
            mb = tmpData(1)
            mg = tmpData(0)
        Else
            mr = gCtl.Ex.GetRValue(mcol)
            mb = gCtl.Ex.GetBValue(mcol)
            mg = gCtl.Ex.GetGValue(mcol)
        End If
        For i = 0 To h - 1
            For j = 0 To w - 1
                Data(pDest) = tmpData(pSrc + 2)
                Data(pDest + 1) = tmpData(pSrc + 1)
                Data(pDest + 2) = tmpData(pSrc)
                If Data(pDest) = mr And _
                    Data(pDest + 1) = mb And _
                    Data(pDest + 2) = mg Then
                        Data(pDest + 3) = 0
                Else
                        Data(pDest + 3) = 1
                End If
                pSrc = pSrc + 3
                pDest = pDest + 4
            Next
            pSrc = pSrc + pad
        Next
    Else
        Opacity = CX.Opacity
        For i = 0 To h - 1
            For j = 0 To w - 1
                Data(pDest) = tmpData(pSrc + 2)
                Data(pDest + 1) = tmpData(pSrc + 1)
                Data(pDest + 2) = tmpData(pSrc)
                Data(pDest + 3) = Opacity * 255
                pSrc = pSrc + 3
                pDest = pDest + 4
            Next
            pSrc = pSrc + pad
        Next
    '
    End If
    'Debug.Assert 0
    ScaleImg w, h, GLFormat, Components, Data
'------------------------------------
Exit Function
ErrorHandler:
Exit Function
End Function


Public Function Max(a, b)
Max = IIf(a > b, a, b)
End Function

Public Function Min(a, b)
Min = IIf(a < b, a, b)
End Function

Public Function ScaleImg(ImgWidth&, ImgHeight&, ImgFormat&, Components&, Data() As Byte) As Boolean
Dim xPow2#, yPow2#, ixPow2&, iyPow2&, i&
Dim xSize2&, ySize2&, glMaxTexDim&
Dim pData() As Byte
    glGetIntegerv GL_MAX_TEXTURE_SIZE, glMaxTexDim
    If glMaxTexDim <= 0 Then Exit Function

    If ImgFormat = GL_COLOR_INDEX Then Debug.Assert 0
    'Exit Function
        ' We limit the max dimension here for performance reasons
        glMaxTexDim = Min(256, glMaxTexDim)
        If ImgWidth <= glMaxTexDim Then
            xPow2 = Log(ImgWidth) / Log(2)
        Else
            xPow2 = Log(glMaxTexDim) / Log(2)
        End If
        If ImgHeight <= glMaxTexDim Then
            yPow2 = Log(ImgHeight) / Log(2#)
        Else
            yPow2 = Log(glMaxTexDim) / Log(2#)
        End If
        ixPow2 = Int(xPow2)
        iyPow2 = Int(yPow2)
        ' Always scale to higher nearest power
        If (xPow2 <> ixPow2) Then
            ixPow2 = ixPow2 + 1
        End If
        If (yPow2 <> iyPow2) Then
            iyPow2 = iyPow2 + 1
        End If
        'todo
        xSize2 = 2 ^ ixPow2
        ySize2 = 2 ^ iyPow2
        If xSize2 <> ImgWidth Or ySize2 <> ImgHeight Then
            'Debug.Assert 0
            'pData = (BYTE *) malloc(xSize2 * ySize2 * components * sizeof)
            ReDim pData(0 To xSize2 * ySize2 * Components - 1)
            glPixelStorei GL_UNPACK_ALIGNMENT, 1
            If (gluScaleImage(ImgFormat, ImgWidth, ImgHeight, _
                      GL_UNSIGNED_BYTE, Data(0), _
                      xSize2, ySize2, GL_UNSIGNED_BYTE, _
                      pData(0))) Then
                ' glu failure
                MsgBox "ValidateTextureSize : gluScaleImage failure"
                Exit Function
            End If
            ' set the new width,height,data
            ImgWidth = xSize2
            ImgHeight = ySize2
            ReDim Data(0 To UBound(pData) - 1)
            CopyToByteFromByte Data(0), pData(0), UBound(pData) - 1
        End If
    ScaleImg = True
End Function


