VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3DListEntry"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'*************************************************************************\
'FUNCTION:
'This class holds the information for a single character.
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98

'*************************************************************************\
Public listNum As Integer       ' display list number
Dim m_Glyph$  '  glyph value (the character)
Dim lpgmf(1 To 1) As GLYPHMETRICSFLOAT      ' ptr to glyphmetrics

Private Sub Class_Initialize()
    listNum = glGenLists(1)
End Sub

Private Sub Class_Terminate()
If listNum Then
    glDeleteLists listNum, 1
End If
End Sub

Public Property Get Glyph() As String
Glyph = m_Glyph
End Property

Public Property Let Glyph(ByVal char As String)
m_Glyph = char
End Property

Public Property Get gmBlackBoxX() As Single
gmBlackBoxX = lpgmf(1).gmfBlackBoxX
End Property

Public Property Let gmBlackBoxX(ByVal X As Single)
lpgmf(1).gmfBlackBoxX = X
End Property

Public Property Get gmBlackBoxY() As Single
gmBlackBoxY = lpgmf(1).gmfBlackBoxY
End Property

Public Property Let gmBlackBoxY(ByVal Y As Single)
lpgmf(1).gmfBlackBoxY = Y
End Property

Public Property Get gmptGlyphOriginX() As Single
gmptGlyphOriginX = lpgmf(1).gmfptGlyphOrigin.X
End Property

Public Property Let gmptGlyphOriginX(ByVal X As Single)
lpgmf(1).gmfptGlyphOrigin.X = X
End Property

Public Property Get gmptGlyphOriginY() As Single
gmptGlyphOriginY = lpgmf(1).gmfptGlyphOrigin.Y
End Property

Public Property Let gmptGlyphOriginY(ByVal Y As Single)
lpgmf(1).gmfptGlyphOrigin.Y = Y
End Property


Public Property Get gmCellIncX() As Single
gmCellIncX = lpgmf(1).gmfCellIncX
End Property

Public Property Let gmCellIncX(ByVal X As Single)
lpgmf(1).gmfCellIncX = X
End Property

Public Property Get gmCellIncY() As Single
gmCellIncY = lpgmf(1).gmfCellIncY
End Property

Public Property Let gmCellIncY(ByVal Y As Single)
lpgmf(1).gmfCellIncY = Y
End Property

'/******************************Public*Routine******************************\
'* Calls wglUseFontOutlines() to create a command list for the supplied
'* character.
'* Allocates memory for the characters glyphmetrics as well
'\**************************************************************************/
Public Function CreateList(hdc&, c$, _
                            chordalDeviation!, extrusion!, nFormat&) As Boolean
    CreateList = wglUseFontOutlines(hdc, Asc(c), 1, listNum, _
               chordalDeviation, _
               extrusion, _
               nFormat, lpgmf(1))
End Function




