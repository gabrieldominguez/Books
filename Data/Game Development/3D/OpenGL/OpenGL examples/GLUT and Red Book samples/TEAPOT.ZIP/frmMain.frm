VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Form1"
   ClientHeight    =   5250
   ClientLeft      =   510
   ClientTop       =   2265
   ClientWidth     =   5880
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5250
   ScaleWidth      =   5880
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3795
      Left            =   270
      TabIndex        =   0
      Top             =   495
      Width           =   4335
      _ExtentX        =   7646
      _ExtentY        =   6694
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, shift As Integer)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else: Exit Sub
    End Select
    KeyCode = 0
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.Key KeyAscii
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CX = New CTeapot
glxCtl1.Init
glxCtl1.Animate = True
End Sub

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, shift As Integer)
'
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


