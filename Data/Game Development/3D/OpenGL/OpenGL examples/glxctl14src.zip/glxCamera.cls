VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxCamera"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: handles resize events and projection
'   - enable this module with UseCamera
'   - handles setting the aspect ratio
'   - to use, set the view parameters
'       -EyePos
'       -Target
'       -Near and FarPlane, FOV, or
'       -SetOrtho
'       then return true from the resize event
'   - 'View' toggles between Ortho and Perspective
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY: Feb 99 - changed it to use a matrix.
'           -added pitch, roll, yaw
'-------------------------------------------------------------------------
Const DEG = 57.2958
Public Enum glxViewConstants
    glxPerspective = 0
    glxOrtho = 1
    glxTop = 2
    glxFront = 3
    glxBottom = 4
    glxLeft = 5
    glxBack = 6
    glxRight = 7
End Enum
'projection
Private m_FieldOfView As Double
Private m_NearPlane As Double
Private m_FarPlane As Double
Private m_AspectRatio As Double
'view
Dim m_View As glxViewConstants
Dim m_OrthoLeft#, m_OrthoRight#, m_OrthoTop#, m_OrthoBottom#
Dim m_Width&, m_Height&
'Private m_OEye!(0 To 2) 'eye pos for ortho views
Private m_Eye!(0 To 2)
Private m_Target!(0 To 2)
Private m_Up!(0 To 2)
Dim m_Normal!(0 To 2)
Dim m_Distance!
Dim Matrix!(0 To 15)
'debug
Dim GLU As Boolean


'---------------------------------------------------------
'SETUP
'---------------------------------------------------------

Private Sub Class_Initialize()
    m_AspectRatio = 1
    m_FarPlane = 1000
    m_NearPlane = 0.1
    m_FieldOfView = 45
    m_View = glxPerspective
    m_OrthoLeft = -10
    m_OrthoRight = 10
    m_OrthoTop = 10
    m_OrthoBottom = -10
    '
    Reset
End Sub

'---------------------------------------------------------
'VIEWPORT
'---------------------------------------------------------

'Adjusts the viewport to match the window size. Should be called for Resize events
Public Sub OnSize(ByVal W&, ByVal H&, Default As Boolean)
If H = 0 Then H = 1
m_AspectRatio = W / H
glViewport 0, 0, W, H
m_Width = W: m_Height = H
'Debug.Print UC.DebugID
'Debug.Print m_Eye(2)
If Default <> 0 Then
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End If
End Sub

Public Sub SetProjection()
Dim l#, r#, B#, t#
Dim W#, H#
If m_View = glxPerspective Then
    gluPerspective m_FieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
Else
    'glLoadIdentity
    W = m_Width: H = m_Height
    If W = 0 Then W = 1
    If H = 0 Then H = 1
    If W < H Then
        l = m_OrthoLeft
        r = m_OrthoRight
        t = m_OrthoTop * H / W
        B = m_OrthoBottom * H / W
    Else
        l = m_OrthoLeft * W / H
        r = m_OrthoRight * W / H
        t = m_OrthoTop
        B = m_OrthoBottom
    End If
    glOrtho l, r, B, t, m_NearPlane, m_FarPlane

End If
'Update
End Sub

'---------------------------------------------------------
'PROJECTION PROPERTIES
'---------------------------------------------------------

'Returns the coordinates of the left, right, bottom, and top
'clipping planes.
Public Sub GetOrtho(Left#, Right#, Bottom#, Top#)
    Left = m_OrthoLeft
    Right = m_OrthoRight
    Bottom = m_OrthoBottom
    Top = m_OrthoTop
End Sub

'Sets the coordinates of the left, right, bottom, and top
'clipping planes.
Public Sub SetOrtho(ByVal Left#, ByVal Right#, ByVal Bottom#, ByVal Top#)
    m_OrthoLeft = Left
    m_OrthoRight = Right
    m_OrthoTop = Top
    m_OrthoBottom = Bottom
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End Sub

'---------------------------------------------------------
'Returns the current ratio of viewport w/h
Public Property Get AspectRatio() As Double
    AspectRatio = m_AspectRatio
End Property

'---------------------------------------------------------
'Returns/sets the far clipping plane
Public Property Let FarPlane(ByVal NewValue As Double)
    m_FarPlane = NewValue
End Property

Public Property Get FarPlane() As Double
    FarPlane = m_FarPlane
End Property

'---------------------------------------------------------
'Returns/sets the near clipping plane
Public Property Let NearPlane(ByVal NewValue As Double)
    m_NearPlane = NewValue
End Property

Public Property Get NearPlane() As Double
    NearPlane = m_NearPlane
End Property

'---------------------------------------------------------
'Returns/sets the field of view angle, in degrees, in the y-direction
Public Property Let FieldOfView(ByVal NewValue As Double)
    m_FieldOfView = NewValue
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End Property

Public Property Get FieldOfView() As Double
    FieldOfView = m_FieldOfView
End Property

'---------------------------------------------------------
'Returns/sets the projection mode
Public Property Get View() As glxViewConstants
    View = m_View
End Property

Public Property Let View(ByVal NewView As glxViewConstants)
    m_View = NewView
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
    UC.Trackball.Reset
End Property

'-------------------------------------------------------------------------------------
' Change the ViewAngle of the camera so that more or less of a scene
' occupies the viewport. A value > 1 is a zoom-in. A value < 1 is a zoom-out.
'-------------------------------------------------------------------------------------
Sub Zoom(distance!)
    If distance <= 0 Then Exit Sub
    m_FieldOfView = m_FieldOfView / distance
    If m_FieldOfView > 160 Then m_FieldOfView = 160
    If m_FieldOfView < 1 Then m_FieldOfView = 1
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End Sub

'---------------------------------------------------------
'DRAWING METHODS
'---------------------------------------------------------

'---------------------------------------------------------
Public Sub Update()
    If GLU Then
        ApplyInvRotation
        ApplyNegTranslation
    Else
        glMultMatrixf Matrix(0)
    End If
End Sub

'---------------------------------------------------------
Public Sub Reset()
    m_Distance = 1
    MatIdentityf Matrix
    m_ComputeLookAt
End Sub

'---------------------------------------------------------
Private Sub ApplyRotation()
Dim m2!(0 To 15)
    MatCopyf m2, Matrix
    m2(12) = 0
    m2(13) = 0
    m2(14) = 0
    glMultMatrixf m2(0)
End Sub

'---------------------------------------------------------
Private Sub ApplyInvRotation()
Dim m2!(0 To 15)
    MatCopyf m2, Matrix
    m2(12) = 0
    m2(13) = 0
    m2(14) = 0
    MatInvertf m2, m2
    glMultMatrixf m2(0)
End Sub

'---------------------------------------------------------
Private Sub ApplyNegTranslation()
    glTranslatef -m_Eye(0), -m_Eye(1), -m_Eye(2)
End Sub

'---------------------------------------------------------
Private Sub ApplyTranslation()
    glTranslatef m_Eye(0), m_Eye(1), m_Eye(2)
End Sub

'---------------------------------------------------------
'VIEW PROPERTIES
'---------------------------------------------------------

'-------------------------------------------------------------------------------------
'GetMatrix
'-------------------------------------------------------------------------------------
Public Sub GetMatrix(mOut!())
Dim i&
    For i = 0 To 15: mOut(i) = Matrix(i): Next
End Sub

'-------------------------------------------------------------------------------------
'SetMatrix
'-------------------------------------------------------------------------------------
Public Sub SetMatrix(m!())
Dim i&
    For i = 0 To 15: Matrix(i) = m(i): Next
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
' Set the matrix using gluLookAt command
'-------------------------------------------------------------------------------------
Public Sub LookAt(EyeX!, EyeY!, EyeZ!, TgtX!, TgtY!, TgtZ!, UpX!, UpY!, UpZ!)
    m_Eye(0) = EyeX
    m_Eye(1) = EyeY
    m_Eye(2) = EyeZ
    m_Target(0) = TgtX
    m_Target(1) = TgtY
    m_Target(2) = TgtZ
    m_Up(0) = UpX
    m_Up(1) = UpY
    m_Up(2) = UpZ
    m_OrthogonalizeViewUp
    m_ComputeMatrix
End Sub


Private Sub m_ComputeMatrix()
    'get distance and normal
    m_ComputeViewPlaneNormalv
    If GLU Then
        MatLookAt Matrix, m_Eye, m_Target, m_Up
    Else
        MatViewPoint Matrix, m_Eye, m_Target, m_Up
        MatInvertf Matrix, Matrix
    End If
End Sub

'-------------------------------------------------------------------------------------
' Compute the view plane normal from the eye position and target.
'-------------------------------------------------------------------------------------
Private Sub m_ComputeViewPlaneNormalv()
Dim dx!, dy!, dz!
    dx = m_Eye(0) - m_Target(0)
    dy = m_Eye(1) - m_Target(1)
    dz = m_Eye(2) - m_Target(2)
    m_Distance = Sqr(dx * dx + dy * dy + dz * dz)
    If m_Distance > 0 Then
        m_Normal(0) = dx / m_Distance
        m_Normal(1) = dy / m_Distance
        m_Normal(2) = dz / m_Distance
    Else
        Debug.Assert 0
    End If
End Sub

'-------------------------------------------------------------------------------------
Private Sub m_ComputeLookAt()
Dim v!(0 To 2)
    If GLU Then
        m_Eye(0) = -Matrix(12)
        m_Eye(1) = -Matrix(13)
        m_Eye(2) = -Matrix(14)
        '
        m_Up(0) = Matrix(4)
        m_Up(1) = Matrix(5)
        m_Up(2) = Matrix(6)
        '
        If m_Distance <= 0 Then m_Distance = 1
        m_Target(0) = m_Eye(0) - Matrix(8) * m_Distance
        m_Target(1) = m_Eye(1) - Matrix(9) * m_Distance
        m_Target(2) = m_Eye(2) - Matrix(10) * m_Distance
        m_ComputeViewPlaneNormalv
    Else
        v(0) = -Matrix(12): v(1) = -Matrix(13): v(2) = -Matrix(14)
        MatDotVectorf m_Eye, Matrix, v
        v(0) = 0: v(1) = 0: v(2) = 1
        MatDotVectorf m_Normal, Matrix, v
        SetTargetDistance m_Distance
        v(0) = 0: v(1) = 1: v(2) = 0
        MatDotVectorf m_Up, Matrix, v
    End If
End Sub

'---------------------------------------------------------
'returns the eye coordinates used in calls to gluLookAt
Public Sub GetEyePos(EyeX!, EyeY!, EyeZ!)
    EyeX! = m_Eye(0)
    EyeY! = m_Eye(1)
    EyeZ! = m_Eye(2)
End Sub

'---------------------------------------------------------
'Sets the eye coordinates used in calls to gluLookAt
Public Sub SetEyePos(ByVal EyeX!, ByVal EyeY!, ByVal EyeZ!)
    m_Eye(0) = EyeX
    m_Eye(1) = EyeY
    m_Eye(2) = EyeZ
    m_ComputeMatrix
End Sub

'---------------------------------------------------------
'returns the target coordinates used in calls to gluLookAt
Public Sub GetTargetPos(TargetX!, TargetY!, TargetZ!)
    TargetX = m_Target(0)
    TargetY = m_Target(1)
    TargetZ = m_Target(2)
End Sub

'---------------------------------------------------------
'Sets the target coordinates used in calls to gluLookAt
Public Sub SetTargetPos(ByVal TargetX!, ByVal TargetY!, ByVal TargetZ!)
    m_Target(0) = TargetX
    m_Target(1) = TargetY
    m_Target(2) = TargetZ
    m_ComputeMatrix
End Sub

'---------------------------------------------------------
'Sets the up vector used in calls to gluLookAt
'doesn't affect named views
'---------------------------------------------------------
Public Sub SetUp(ByVal UpX!, ByVal UpY!, ByVal UpZ!)
    V3Normalize3f UpX, UpY, UpZ
    m_Up(0) = UpX
    m_Up(1) = UpY
    m_Up(2) = UpZ
    m_ComputeMatrix
End Sub

'---------------------------------------------------------
'returns the up vector used in calls to gluLookAt
'-------------------------------------------------------------------------------------
Public Sub GetUp(UpX!, UpY!, UpZ!)
    UpX = m_Up(0)
    UpY = m_Up(1)
    UpZ = m_Up(2)
End Sub

'---------------------------------------------------------
'OBSOLETE!!!! - THIS IS SAME AS EyePos
'---------------------------------------------------------
'returns the eye offsets from the target when using named ortho views
'---------------------------------------------------------
Public Sub GetOrthoEyePos(EyeX!, EyeY!, EyeZ!)
    EyeX = m_Eye(0)
    EyeY = m_Eye(1)
    EyeZ = m_Eye(2)
End Sub

'---------------------------------------------------------
'Sets the eye offsets from the target when using named ortho views
Public Sub SetOrthoEyePos(ByVal EyeX!, ByVal EyeY!, ByVal EyeZ!)
    m_Eye(0) = EyeX
    m_Eye(1) = EyeY
    m_Eye(2) = EyeZ
    m_ComputeMatrix
End Sub

'-------------------------------------------------------------------------------------
'sets distance of target from eye
'-------------------------------------------------------------------------------------
Public Sub SetTargetDistance(X!)
    ' Distance should be greater than .0002
    If X < 0.0002 Then
        X = 0.0002
    End If
    ' recalculate Target
    m_Target(0) = m_Eye(0) - m_Normal(0) * X
    m_Target(1) = m_Eye(1) - m_Normal(1) * X
    m_Target(2) = m_Eye(2) - m_Normal(2) * X
End Sub

'-------------------------------------------------------------------------------------
'sets distance of eye from target
'-------------------------------------------------------------------------------------
Public Sub SetEyeDistance(X!)
    ' Distance should be greater than .0002
    If X < 0.0002 Then
        X = 0.0002
    End If
    ' recalculate Target
    m_Eye(0) = m_Target(0) + m_Normal(0) * X
    m_Eye(1) = m_Target(1) + m_Normal(1) * X
    m_Eye(2) = m_Target(2) + m_Normal(2) * X
    m_ComputeMatrix
End Sub

'-------------------------------------------------------------------------------------
' returns the eye distance from the target.
'-------------------------------------------------------------------------------------
Public Sub GetEyeDistance(d!)
Dim dx!, dy!, dz!
    dx = m_Target(0) - m_Eye(0)
    dy = m_Target(1) - m_Eye(1)
    dz = m_Target(2) - m_Eye(2)
    d = Sqr(dx * dx + dy * dy + dz * dz)
End Sub

'-------------------------------------------------------------------------------------
' return the view plane normal.
'-------------------------------------------------------------------------------------
Public Sub GetViewPlaneNormalv(v!())
    v(0) = m_Normal(0)
    v(1) = m_Normal(1)
    v(2) = m_Normal(2)
End Sub

'-------------------------------------------------------------------------------------
' Set the direction that the camera points.
' Adjusts eye position to be consistent with the view plane normal.
'-------------------------------------------------------------------------------------
Sub SetViewPlaneNormal(X!, Y!, z!)
Dim norm!, d!, dx!, dy!, dz!, dot_product!
    ' normalize it
    norm = Sqr(X * X + Y * Y + z * z)
    If norm = 0 Then
        Debug.Assert 0
        Exit Sub
    End If
    X = X / norm
    Y = Y / norm
    z = z / norm
    '
    m_Normal(0) = X
    m_Normal(1) = Y
    m_Normal(2) = z
    
    GetEyeDistance d
    ' Distance should be greater than .002
    If d < 0.002 Then d = 0.002
    m_Eye(0) = m_Target(0) + m_Normal(0) * d
    m_Eye(1) = m_Target(1) + m_Normal(1) * d
    m_Eye(2) = m_Target(2) + m_Normal(2) * d
    m_ComputeMatrix
End Sub

'---------------------------------------------------------
'VIEW METHODS
'---------------------------------------------------------

'-------------------------------------------------------------------------------------
'TRANSLATE ALONG CAMERA AXES
'-------------------------------------------------------------------------------------
'Sub Dolly(distance!)
'    TranslateZ distance
'End Sub

'-------------------------------------------------------------------------------------
Sub TranslateX(distance!)
Dim m1!(0 To 15)
    MatIdentityf m1
    MatSetTranslationf m1, distance, 0, 0
    MatMultiplyf Matrix, Matrix, m1
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
Sub TranslateY(distance!)
Dim m1!(0 To 15)
    MatIdentityf m1
    MatSetTranslationf m1, 0, -distance, 0
    MatMultiplyf Matrix, Matrix, m1
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
Sub TranslateZ(distance!)
Dim m1!(0 To 15)
    MatIdentityf m1
    MatSetTranslationf m1, 0, 0, distance
    MatMultiplyf Matrix, Matrix, m1
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
Sub TranslateXYZ(X!, Y!, z!)
Dim m1!(0 To 15)
    MatIdentityf m1
    MatSetTranslationf m1, X, Y, z
    MatMultiplyf Matrix, Matrix, m1
    m_ComputeLookAt
End Sub

'---------------------------------------------------------
Public Sub Pan(X!, Y!)
Dim m1!(0 To 15)
    MatIdentityf m1
    MatSetTranslationf m1, X, Y, 0
    MatMultiplyf Matrix, Matrix, m1
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
'ROTATE ON CAMERA AXES
'-------------------------------------------------------------------------------------

'-------------------------------------------------------------------------------------
'incremental rotations
'-------------------------------------------------------------------------------------
Public Sub RotateX(ByVal Angle!)
Dim m!(0 To 15)
    Angle = DegToRadf(Angle)
    MatRotX_CS m, Cos(Angle), Sin(Angle)
    MatMultiplyf Matrix, Matrix, m
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateY(ByVal Angle!)
Dim m!(0 To 15)
    Angle = DegToRadf(Angle)
    MatRotY_CS m, Cos(Angle), Sin(Angle)
    MatMultiplyf Matrix, Matrix, m
    m_ComputeLookAt
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateZ(ByVal Angle!)
Dim m!(0 To 15)
    Angle = DegToRadf(Angle)
    MatRotZ_CS m, Cos(Angle), Sin(Angle)
    MatMultiplyf Matrix, Matrix, m
    m_ComputeLookAt
End Sub

'
'Sub Orbit(dx1!, dy1!, dx2!, dy2!)
'Dim m!(0 To 15), m2!(0 To 15), v!(0 To 2)
'Dim q!(0 To 3)
'    If dx1 = dx2 And dy1 = dy2 Then Exit Sub
'    ' translate to target
'    MatIdentityf m
'    MatSetTranslationf m, -m_Target(0), -m_Target(1), -m_Target(2)
'    QuatTrackball q, dx1, dy1, dx2, dy2
'    QuatToMatrix q, m2
'    MatMultiplyf m, m, m2
'    ' translate back
'    MatTranslatef m, m_Target(0), m_Target(1), m_Target(2)
'    ' now transform position
'    MatXFormPointf m_Eye, m_Eye, m
'    m_ComputeMatrix
'End Sub

'-------------------------------------------------------------------------------------
' Rotate the camera about the view up vector centered at the target.
'-------------------------------------------------------------------------------------
'Sub Azimuth(Angle!)
'Dim m!(0 To 15)
'Dim v!(0 To 2)
''    MatIdentityf m
''    ' translate to target
''    MatSetTranslationf m, m_Target(0), m_Target(1), m_Target(2)
''    ' rotate about view up
''    MatRotAxisDegf m, Angle, m_Up
''    ' translate back
''    MatTranslatef m, -m_Target(0), -m_Target(1), -m_Target(2)
''    ' now transform position
''    MatMultiplyPointf m_Eye, m_Eye, m
''    m_ComputeMatrix
''
'    Angle = DegToRadf(Angle)
'    MatIdentityf m
'    MatSetTranslationf m, -m_Target(0), -m_Target(1), -m_Target(2)
'    'MatRotateOnAxisRadf m, Angle, m_Up, glxSelf
'    MatRotateRadf m, Angle, AXIS_Y, glxSelf
'    MatTranslatef m, m_Target(0), m_Target(1), m_Target(2)
'    'V3Negatef v, m_Eye
'    'MatXFormPointf m_Eye, v, m
'    'V3Negatef m_Eye, m_Eye
'    MatXFormPointf m_Eye, m_Eye, m
'    m_ComputeMatrix
'    'm_ComputeLookAt
'    'SetEyeDistance m_Distance
'End Sub

'-------------------------------------------------------------------------------------
' Rotate the camera about the cross product of the view plane normal and
' the view up vector centered on the target.
'-------------------------------------------------------------------------------------
'Sub Elevation(Angle!)
'Dim axis!(0 To 2), m!(0 To 15)
'    ' elevation is a rotation of camera position about cross between
'    ' view plane normal and view up
'    axis(0) = m_Normal(1) * m_Up(2) - m_Normal(2) * m_Up(1)
'    axis(1) = m_Normal(2) * m_Up(0) - m_Normal(0) * m_Up(2)
'    axis(2) = m_Normal(0) * m_Up(1) - m_Normal(1) * m_Up(0)
'    MatIdentityf m
'    ' translate to target
'    MatSetTranslationf m, -m_Target(0), -m_Target(1), -m_Target(2)
'    ' rotate about view up
'    MatRotAxisDegf m, angle, axis
'    ' translate to target
'    MatTranslatef m, m_Target(0), m_Target(1), m_Target(2)
'    ' now transform position
'    MatMultiplyPointf m_Eye, m_Eye, m
'    m_ComputeViewPlaneNormalv
'    m_OrthogonalizeViewUp
'End Sub


'-------------------------------------------------------------------------------------
' Recompute the view up vector so that it is perpendicular to the
' view plane normal.
'-------------------------------------------------------------------------------------
'Private
Sub m_OrthogonalizeViewUp()
Dim temp!(0 To 2), Up2!(0 To 2)
Dim lng!, lng2!, ratio!
    m_ComputeViewPlaneNormalv
    V3Crossf temp, m_Normal, m_Up
    V3Normalizef temp
    'lng = m_Up(0) * m_Up(0) + m_Up(1) * m_Up(1) + m_Up(2) * m_Up(2)
    V3Crossf Up2, temp, m_Normal
    V3Normalizef Up2
    'lng2 = Up2(0) * Up2(0) + Up2(1) * Up2(1) + Up2(2) * Up2(2)
    'ratio = Sqr(lng2 / lng)
    m_Up(0) = Up2(0) ' * ratio
    m_Up(1) = Up2(1) ' * ratio
    m_Up(2) = Up2(2) ' * ratio
End Sub


'---------------------------------------------------------
Public Sub Draw()
     DrawTarget 0.5
     DrawEye 0.5
     DrawAxis 1, 3
     DrawLineOfSight 2
End Sub

'---------------------------------------------------------
Public Sub DrawAxis(Optional nSize! = 1, Optional LineWidth& = 1)
Dim z!(0 To 2)
Dim X!(0 To 2)
Dim Y!(0 To 2)

    glPushMatrix
        glPushAttrib GL_LIGHTING
        glDisable GL_LIGHTING
        glLineWidth LineWidth
        'z
        V3Copyf z, m_Normal
        V3Scalef z, nSize, z
        z(0) = m_Eye(0) - z(0)
        z(1) = m_Eye(1) - z(1)
        z(2) = m_Eye(2) - z(2)
        '
        V3Copyf Y, m_Up
        V3Normalizef Y
        V3Scalef Y, nSize, Y
        Y(0) = m_Eye(0) + Y(0)
        Y(1) = m_Eye(1) + Y(1)
        Y(2) = m_Eye(2) + Y(2)
        'x
        V3Crossf X, m_Up, m_Normal
        V3Normalizef X
        V3Scalef X, nSize, X
        X(0) = m_Eye(0) + X(0)
        X(1) = m_Eye(1) + X(1)
        X(2) = m_Eye(2) + X(2)
        glBegin GL_LINES
            'x
            glColor3f 1, 0, 0
            glVertex3fv m_Eye(0)
            glVertex3fv X(0)
        glEnd
        glBegin GL_LINES
            'y
            glColor3f 0, 1, 0
            glVertex3fv m_Eye(0)
            glVertex3fv Y(0)
        glEnd
        glBegin GL_LINES
            'z
            glColor3f 0, 0, 1
            glVertex3fv m_Eye(0)
            glVertex3fv z(0)
        glEnd
        glPopAttrib
    glPopMatrix
End Sub

'---------------------------------------------------------
Public Sub DrawTarget(Optional nSize! = 0.5, Optional Color& = &H80)
    glPushMatrix
        If GLU Then
        Else
            glPushAttrib GL_LIGHTING
            glDisable GL_LIGHTING
            glTranslatef m_Target(0), m_Target(1), m_Target(2)
            ApplyInvRotation
        End If
        SetGLColor Color
        UC.Shapes.WireCube nSize
        glPopAttrib
    glPopMatrix
End Sub

'---------------------------------------------------------
Public Sub DrawEye(Optional nSize! = 0.5, Optional Color& = &HFFFFFF)
Dim m!(0 To 15)
    glPushMatrix
        If GLU Then
        Else
            MatInvertf m, Matrix
            glMultMatrixf m(0)
            'ApplyRotation
            'ApplyTranslation
            'ApplyInvRotation
        End If
        glTranslatef 0, 0, -nSize / 2
        glPushAttrib GL_LIGHTING
            glDisable GL_LIGHTING
            SetGLColor Color
            UC.Shapes.WireCube nSize
            glTranslatef 0, 0, -nSize
            UC.Shapes.WireCylinder nSize * 0.5, nSize / 3, nSize / 2, 12, 1
        glPopAttrib
    glPopMatrix
End Sub

'---------------------------------------------------------
Public Sub DrawLineOfSight(Optional LineWidth& = 2, Optional Color& = &H61B9DE)
Dim m!(0 To 15)
    glPushMatrix
        glPushAttrib GL_LIGHTING
        glDisable GL_LIGHTING
        glLineWidth LineWidth&
        SetGLColor Color
        If GLU Then
        Else
            'MatInvertf m, Matrix
            'glMultMatrixf m(0)
            glBegin GL_LINES
                glVertex3f m_Eye(0), m_Eye(1), m_Eye(2)
                glVertex3f m_Target(0), m_Target(1), m_Target(2)
            glEnd
        End If
        glPopAttrib
    glPopMatrix
End Sub

'---------------------------------------------------------
'UNTESTED
'---------------------------------------------------------
'-------------------------------------------------------------------------------------
' Returns the orientation of the camera. This is a vector of X,Y and Z
' rotations that when performed in the order RotateZ, RotateX, and finally
' RotateY, will yield the same 3x3 rotation matrix for the camera.
Public Sub GetOrientation(v!())
Dim m!(0 To 15)
    MatToEuler Matrix, v
End Sub

'-------------------------------------------------------------------------------------
' Returns the Angle/Axis orientation of the camera.
'-------------------------------------------------------------------------------------
Public Sub GetOrientationAxis(Angle!, Axis!())
Dim m!(0 To 15)
Dim scaleX!, scaleY!, scaleZ!
Dim temp!(0 To 15)
Dim quat!(0 To 3)
Dim mag!
    m_GetScale scaleX, scaleY, scaleZ
    MatCopyf temp, Matrix
    MatScalef temp, 1 / scaleX, 1 / scaleY, 1 / scaleZ
    quat(0) = 0.25 * (1 + temp(0) + temp(5) + temp(10))
    If (quat(0) > 0.0001) Then
        quat(0) = Sqr(quat(0))
        quat(1) = (temp(9) - temp(6)) / (4 * quat(0))
        quat(2) = (temp(2) - temp(8)) / (4 * quat(0))
        quat(3) = (temp(4) - temp(1)) / (4 * quat(0))
    Else
        quat(0) = 0
        quat(1) = -0.5 * (temp(5) + temp(10))
        If (quat(1) > 0.0001) Then
            quat(1) = Sqr(quat(1))
            quat(2) = temp(4) / (2 * quat(1))
            quat(3) = temp(8) / (2 * quat(1))

        Else
            quat(1) = 0
            quat(2) = 0.5 * (1 - temp(10))
            If (quat(2) > 0.0001) Then
                quat(2) = Sqr(quat(2))
                quat(3) = temp(9) / (2 * quat(2))
            Else
                quat(2) = 0
                quat(3) = 1
            End If
        End If
    End If

    ' calc the wxyz
    mag = Sqr(quat(1) * quat(1) + quat(2) * quat(2) + quat(3) * quat(3))

    If (mag) Then
        Angle = 180# * 2# * ArcCos(quat(0)) / 3.1415926
        Axis(0) = quat(1) / mag
        Axis(1) = quat(2) / mag
        Axis(2) = quat(3) / mag
    Else
        Angle = 0
        Axis(0) = 0
        Axis(1) = 0
        Axis(2) = 1
    End If
End Sub

' Return the x, y, z scale factors of the current transformation matrix as
' an array of three float numbers.
Private Sub m_GetScale(X!, Y!, z!)
Dim i&, v!(0 To 2)
    For i = 0 To 2
        v(i) = Sqr(Matrix(i) * Matrix(i) + _
                     Matrix(4 + i) * Matrix(4 + i) + _
                     Matrix(8 + i) * Matrix(8 + i))
    Next
    X = v(0): Y = v(1): z = v(2)
End Sub

