Attribute VB_Name = "mTexas"
Option Explicit

''
' * texas.c
' *
' * FUNCTION:
' * Draws a brand in the shape of Texas.  Both the handle, and the
' * cross-section of the brand are in the shape of Texas.
' *
' * Note that the contours are specified in clockwise order.
' * Thus, enabling backfacing polygon removal will cause the front
' * polygons to disappear.
' *
' * HISTORY:
' * -- created by Linas Vepstas October 1991
' * -- heavily modified to draw more texas shapes, Feb 1993, Linas
' * -- converted to use GLUT -- December 1995, Linas
' *
' */
' =========================================================== */
Public IDTexas&
Public Texas As gleExtrusion
Public THandle As gleExtrusion

Const HNUM = 4
Const NUMTXPOINTS = 18
Const TSCALE = 4
Const SCALEz = 0.5
Const NUM_TEXAS_PTS = 17
Dim i&

' =========================================================== */
Public Sub InitTexas()
    Set Texas = gCtl.NewExtrusion
    Set THandle = gCtl.NewExtrusion
    ' configure the pipeline */
    init_spine
    init_xsection
    
    With Texas
        .TextureEnabled = CX.TextureEnabled
        .ContourStyle = gleCLOSED
        .TextureMode = CX.TextureStyle
    End With
    With THandle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .ContourStyle = gleCLOSED
    End With
    IDTexas = glGenLists(1)
    glNewList IDTexas, lstCompile
        DrawTexas
    glEndList
End Sub

' =========================================================== */
Public Sub DrawTexas()
    glPushMatrix
    ' draw the brand and the handle */
    'gleExtrusion (NUM_TEXAS_PTS-1, texas_xsection, texas_normal,
    '             NULL, NUMTXPOINTS, tspine, tcolors);
    'gleExtrusion (NUM_TEXAS_PTS-1, texas_xsection, texas_normal,
    '             NULL, HNUM, brand_points, brand_colors);
    THandle.Draw
    Texas.Draw
    glPopMatrix
End Sub

Private Sub BrandPoints(x#, y#, z#)
With THandle
    .SetPt i, TSCALE * (x), TSCALE * (y), TSCALE * (z)
    i = i + 1
End With
End Sub

' =========================================================== */
Private Sub init_spine()
Dim ir&, ig&, ib&
Dim r!, g!, b!
With Texas
    .JoinStyle = CX.JoinStyle
    .NormStyle = CX.NormStyle
    .NumPoints = NUMTXPOINTS
    .NUMCOLORS = NUMTXPOINTS
    .NumContourPoints = NUM_TEXAS_PTS
    .NumContourNormals = NUM_TEXAS_PTS
    i = 0
    TexasPoints -1.5, 2  '    ' panhandle */
    TexasPoints -0.75, 2
    TexasPoints -0.75, 1.38
    TexasPoints -0.5, 1.25
    TexasPoints 0.88, 1.12
    TexasPoints 1, 0.62
    TexasPoints 1.12, 0.1
    TexasPoints 0.5, -0.5
    TexasPoints 0.2, -1.12     ' corpus */
    TexasPoints 0.3, -1.5      ' brownsville */
    TexasPoints -0.25, -1.45
    TexasPoints -1.06, -0.3
    TexasPoints -1.38, -0.3
    TexasPoints -1.65, -0.6
    TexasPoints -2.5, 0.5     ' midland */
    TexasPoints -1.5, 0.5
    TexasPoints -1.5, 2       ' panhandle */
    TexasPoints -0.75, 2

    For i = 0 To NUMTXPOINTS - 1
        ir = ir + 33
        ig = ig + 47
        ib = ib + 89
        ir = ir Mod 255
        ig = ig Mod 255
        ib = ib Mod 255
        r = ir / 255
        g = ig / 255
        b = ib / 255
        
        .SetColor i, r, g, b
    Next
End With
With THandle
    .JoinStyle = CX.JoinStyle
    .NormStyle = CX.NormStyle
    .NumPoints = HNUM
    .NUMCOLORS = HNUM
    .NumContourPoints = NUM_TEXAS_PTS
    .NumContourNormals = NUM_TEXAS_PTS
   i = 0
   BrandPoints 0, 0, 0.1
   BrandPoints 0, 0, 0
   BrandPoints 0, 0, -5
   BrandPoints 0, 0, -5.1

   .SetColor 0, 1, 0.6, 0.6
   .SetColor 1, 1, 0.5, 0.5
   .SetColor 2, 1, 0.4, 0.4
   .SetColor 3, 1, 0.3, 0.3
End With
End Sub

Private Sub TexasPoints(x#, y#)
With Texas
    .SetPt i, TSCALE * (x), TSCALE * (y), TSCALE * (0#)
    i = i + 1
End With
End Sub


' =========================================================== */
Private Sub init_xsection()
    ' outline of extrusion */
    'edx: must be counterclockwise
    i = 0
    Set CurModel = Texas
    Texas.SetContourNormal 0, -1, 0
    CONTOUR2 0, -0.75, 2#, SCALEz
    CONTOUR2 1, -1.5, 2#, SCALEz    ' panhandle */
    CONTOUR2 2, -1.5, 0.5, SCALEz
    CONTOUR2 3, -2.5, 0.5, SCALEz    ' midland */
    CONTOUR2 4, -1.65, -0.6, SCALEz
    CONTOUR2 5, -1.38, -0.3, SCALEz
    CONTOUR2 6, -1.06, -0.3, SCALEz
    CONTOUR2 7, -0.25, -1.45, SCALEz
    CONTOUR2 8, 0.3, -1.5, SCALEz   ' brownsville */
    CONTOUR2 9, 0.2, -1.12, SCALEz  ' corpus */
    CONTOUR2 10, 0.5, -0.5, SCALEz
    CONTOUR2 11, 1.12, 0.1, SCALEz
    CONTOUR2 12, 1, 0.62, SCALEz
    CONTOUR2 13, 0.88, 1.12, SCALEz
    CONTOUR2 14, -0.5, 1.25, SCALEz
    CONTOUR2 15, -0.75, 1.38, SCALEz
    CONTOUR2 16, -0.75, 2, SCALEz
    i = 0
    Set CurModel = THandle
    Texas.SetContourNormal 0, -1, 0
    CONTOUR2 0, -0.75, 2#, SCALEz
    CONTOUR2 1, -1.5, 2#, SCALEz    ' panhandle */
    CONTOUR2 2, -1.5, 0.5, SCALEz
    CONTOUR2 3, -2.5, 0.5, SCALEz    ' midland */
    CONTOUR2 4, -1.65, -0.6, SCALEz
    CONTOUR2 5, -1.38, -0.3, SCALEz
    CONTOUR2 6, -1.06, -0.3, SCALEz
    CONTOUR2 7, -0.25, -1.45, SCALEz
    CONTOUR2 8, 0.3, -1.5, SCALEz   ' brownsville */
    CONTOUR2 9, 0.2, -1.12, SCALEz  ' corpus */
    CONTOUR2 10, 0.5, -0.5, SCALEz
    CONTOUR2 11, 1.12, 0.1, SCALEz
    CONTOUR2 12, 1, 0.62, SCALEz
    CONTOUR2 13, 0.88, 1.12, SCALEz
    CONTOUR2 14, -0.5, 1.25, SCALEz
    CONTOUR2 15, -0.75, 1.38, SCALEz
    CONTOUR2 16, -0.75, 2, SCALEz
End Sub


' ===================== END OF FILE ================== */


