/*//////////////////////////////////////////////////////////////////////////////
//
//  An ASCII milkshape object loader - couldn't get the binary files to read
//  properly (datatype _issues_)
//
//////////////////////////////////////////////////////////////////////////////*/

typedef float vec3_t[3];
typedef float vec2_t[2];

typedef unsigned int ind3_t[3];



typedef struct {
   unsigned int     NumVertices;

   vec3_t  *Vertices;
   vec3_t  *VertexNormals;
   vec2_t  *UV;

   unsigned int     NumIndices;

   ind3_t  *Indices;
   vec3_t  *FaceNormals;

   unsigned int     MaterialIndex;

} mlkMesh_t;

typedef struct {

   vec3_t Diffuse;
   vec3_t Emission;
   char   TextureMap[32];
   unsigned int TextureId[1];

} mlkMat_t;

typedef struct {
   unsigned int   NumMeshes;
   unsigned int   NumMaterials;
   mlkMesh_t      *Mesh;
   mlkMat_t       *Material;
} mlkObject_t;


mlkObject_t* mlkLoad ( char *file_name );
void mlkDrawObject ( mlkObject_t *object );
void mlkFreeObject ( mlkObject_t *object );
