Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CWave
Public optRGB As Boolean ', doubleBuffer;
Public optSmooth As Boolean ' = GL_FALSE;
Public optLighting  As Boolean '= GL_TRUE;
Public optDepth  As Boolean '= GL_TRUE;
Public optStepMode  As Boolean '= GL_FALSE;
Public optSpinMode  As Boolean '= GL_FALSE;
Public colorIndexes(1 To 2) As POINT3F

'
Public Const PI = 3.141592654
Public xRotation!, yRotation!, zTranslation!
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Type Facet
    Color(0 To 2) As Single
    Normal(0 To 2) As Single
End Type

Type Coordinate
    Vertex(0 To 2) As Single
    Normal(0 To 2) As Single
End Type

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub



