//--------------------------------------------------------------
// Animaci�n con luz y cambio de perspectiva con el mouse en 3D
// con OpenGL.
// Daniel Beber - Diego Milone - Computaci�n II - 07/Junio/2002
//--------------------------------------------------------------

#include <stdio.h>
#include <GL/glut.h>

float angle, angle2;	// Angulos

int moving, startx, starty;

GLfloat  ambient_light[] = {0.3, 0.3, 0.45, 1.0};
GLfloat   source_light[] = {0.1, 0.4, 0.8, 1.0};
GLfloat      light_pos[] = {0.0, 0.5, 0.0, 0.0};

void init( void )
{
  // Configuraci�n de un modelo simple de luz
  glEnable	 ( GL_LIGHTING );
  glLightModelfv ( GL_LIGHT_MODEL_AMBIENT,ambient_light );
  glLightfv	 ( GL_LIGHT0,GL_DIFFUSE,source_light );
  glLightfv	 ( GL_LIGHT0,GL_POSITION,light_pos );

  glEnable	 ( GL_LIGHT0 ); //activar fuente de luz

  // Enable de las propiedades del material para iluminacion
  glEnable	  ( GL_COLOR_MATERIAL );
  glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );

  // Cull de caras ocultas
  glEnable     ( GL_CULL_FACE );
  glClearColor ( 0.0, 0.0, 0.0, 0.0 );
}

void draw_earth(GLfloat color_r, GLfloat color_g, GLfloat color_b)
{  glPushMatrix ( );
   glRotatef ( 90.0, 1.0, 0.0, 0.0 );

   glColor3f ( color_r, color_g, color_b);

   GLUquadricObj*  q = gluNewQuadric ( );
   gluQuadricDrawStyle ( q, GLU_FILL );
   gluQuadricNormals   ( q, GLU_SMOOTH );

   // gluSphere ( q, 0.7, 20, 20 );  // dibujar esferas
   glutSolidCube(0.8);		       // par�metro: tama�o del cubo

   gluDeleteQuadric ( q );
   glPopMatrix ( );
}

void display ( void )
{  glClear   ( GL_COLOR_BUFFER_BIT );
   glLightfv ( GL_LIGHT0,GL_POSITION,light_pos );
   glPushMatrix   ( );

   glTranslatef ( 0.0, 0.0, -4.0 );
   glRotatef  ( angle2, 1.0, 0.0, 0.0 );
   glRotatef  ( angle, 0.0, 1.0, 0.0  );

   // cuadrado del centro
   draw_earth ( 1.0, 0.0, 0.0);

   // cuadrado de arriba
   // recordar que las traslaciones son acumulativas
   glTranslatef ( 0.0, (0.0+1.0), 0.0 );  //(x=donde_est�,y=subo,z=donde_est�)
   draw_earth ( 0.0, 1.0, 0.0 );

   // cuadrado de abajo
   glTranslatef ( 0.0, (-1.0-1.0), 0.0 );
   draw_earth ( 0.0, 0.0, 1.0 );

   // cuadrado de la derecha
   glTranslatef ( 1.0, +1.0, 0.0 );
   draw_earth ( 0.0, 0.0, 10.0 );

   glPopMatrix	( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{  glViewport	  ( 0, 0, w, h );
   glMatrixMode   ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 80, ( float ) w, 1.0, 5000.0 );
   else
      gluPerspective ( 80, ( float ) w / ( float ) h, 1.0, 5000.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );
}

void mouse ( int button, int state, int x, int y )
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {  moving = 1;
      startx = x;
      starty = y;
   }

   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      moving = 0;
}

void motion ( int x, int y )
{  if ( moving )
   {  angle  = angle + (x - startx);
      angle2 = angle2 + (y - starty);
      startx = x;
      starty = y;
      glutPostRedisplay();
   }
}

void idle_func ( void )
{  angle = angle + 0.1;
   if (angle == 360) angle = 0;
      glutPostRedisplay ( );
}

void keyboard ( unsigned char key, int x, int y )
{  switch ( key ) {
      case 27:	/*  Escape*/
	 exit ( 0 );
	 break;
      case 'f':
	 glutFullScreen ( );
	 break;
      case 'w':
	 glutReshapeWindow ( 250,250 );
	 break;
      default:
	 break;
   }
}

int main ( int argc, char** argv )
{  glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow    ("Hacer drag con el mouse");
   init ( );
   glutReshapeFunc  ( reshape	);
   glutMouseFunc    ( mouse	);
   glutMotionFunc   ( motion	);
   glutKeyboardFunc ( keyboard	);
   glutDisplayFunc  ( display	);

   // siempre rotando. Comentado la siguiente linea queda quieto
   glutIdleFunc     ( idle_func );

   glutMainLoop ( );
   return 0;
}


