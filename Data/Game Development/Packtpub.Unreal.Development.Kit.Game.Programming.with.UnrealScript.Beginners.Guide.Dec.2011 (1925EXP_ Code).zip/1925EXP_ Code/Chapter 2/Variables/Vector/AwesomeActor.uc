class AwesomeActor extends Actor
    placeable;

var vector LocationOffset;

function PostBeginPlay()
{
    LocationOffset.Z = 64.0;
    SetLocation(Location + LocationOffset);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
    End Object
    Components.Add(Sprite)
}
