VERSION 5.00
Begin VB.Form frmUnzip 
   Caption         =   "Tout d�zipper"
   ClientHeight    =   3690
   ClientLeft      =   630
   ClientTop       =   2655
   ClientWidth     =   6840
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmUnzip.frx":0000
   ScaleHeight     =   3690
   ScaleWidth      =   6840
   Begin VB.CommandButton cmdFermer 
      Caption         =   "&Fermer"
      Enabled         =   0   'False
      Height          =   435
      Left            =   5145
      TabIndex        =   1
      Top             =   3150
      Width           =   1485
   End
   Begin VB.TextBox txtInfo 
      Height          =   2640
      Left            =   105
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Text            =   "frmUnzip.frx":000C
      Top             =   420
      Width           =   6630
   End
   Begin VB.Label lblProgress 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "lblProgess"
      Height          =   195
      Left            =   105
      TabIndex        =   3
      Top             =   3255
      Width           =   720
   End
   Begin VB.Label lblCourant 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "lblCourant"
      Height          =   195
      Left            =   105
      TabIndex        =   2
      Top             =   105
      Width           =   735
   End
End
Attribute VB_Name = "frmUnzip"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdFermer_Click()
' Fermeture de la fen�tre
Unload Me
End Sub

Private Sub Form_Activate()
Dim stFile As String
Dim lgMax As Long, lgCur As Long
Dim lgCount As Long, lgTmp As Long, lgErr As Long
Dim stMsg As String, stTmp As String
' Initialisation des variables
lgCount = 0
lgErr = 0
lgCur = 0
lgMax = 0
stPassword = vbNullString
Me.Caption = LoadResString(intLOffset + 189)
' Sablier
Screen.MousePointer = vbHourglass
stFile = Dir$(stCurDir & "\*.zip")
Do While (stFile <> vbNullString)
    lgMax = lgMax + 1
    stFile = Dir$()
Loop
On Error Resume Next
stFile = Dir$(stCurDir & "\*.zip")
Do While (stFile <> vbNullString)
    lgCur = lgCur + 1
    ' Affichage du fichier courant
    lblCourant.Caption = stCurDir & stFile
    lblProgress.Caption = LoadResString(intLOffset + resMnuFichier) & " : " & lgCur & " / " & lgMax
    DoEvents
    Err.Clear
    ' Appel de la fonction de d�compression
    lgTmp = VBUnZip32(0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, _
                   stCurDir & stFile, stCurDir)
    ' Comptabilisation des op�rations
    If (lgTmp <> 0) Then lgErr = lgErr + 1 Else lgCount = lgCount + 1
    If (uZipInfo <> vbNullString) Then
        ' Conversion des simples vbLf en vbCrLf
        ' (sans perdre les vbCrLf existants)
        stTmp = Trim$(Replace(uZipInfo, vbCrLf, vbLf))
        stTmp = Replace(stTmp, vbLf, vbCrLf)
        ' Ajout du texte dans la zone d'information
        txtInfo.Text = txtInfo.Text & stTmp
        txtInfo.SelStart = Len(txtInfo.Text)
    End If
    DoEvents
    stFile = Dir$()
Loop
' R�sum� de la d�compression
stMsg = Replace(LoadResString(intLOffset + 188), "\n", vbCrLf)
stMsg = Replace(stMsg, "%1", CStr(lgCount))
stMsg = Replace(stMsg, "%2", CStr(lgErr))
txtInfo.Text = txtInfo.Text & vbCrLf & vbCrLf & stMsg
Screen.MousePointer = vbNormal
' Activer le bouton de fermeture
cmdFermer.Enabled = True
End Sub

Private Sub Form_Load()
' Initialisation des zones
txtInfo.Text = vbNullString
lblCourant.Caption = vbNullString
lblProgress.Caption = vbNullString
' Centrage de la fen�tre
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2
End Sub

Private Sub Form_Resize()
' Redimensionnement de la fen�tre
On Error Resume Next
txtInfo.Move txtInfo.Left, txtInfo.Top, Me.Width - 330, Me.Height - 1460
cmdFermer.Move Me.Width - 1815, Me.Height - 945
lblProgress.Move lblProgress.Left, Me.Height - 840
End Sub
