Attribute VB_Name = "mScrew"
Option Explicit

'
' * screw.c
' *
' * FUNCTION:
' * Draws a screw shape.
' *
' * HISTORY:
' * -- created by Linas Vepstas October 1991
' * -- heavily modified to draw more texas shapes, Feb 1993, Linas
' * -- converted to use GLUT -- December 1995, Linas
' *
' */
' =========================================================== */

Const SCALEz = 1.3
Const NUM_PTS = 20
'extern void TextureStyle (int msg);
Public Screw As gleScrew
Public IDScrew&

' =========================================================== */
Sub InitScrew()
Dim style&
    Set Screw = gCtl.NewScrew
    ' pick model-vertex-cylinder coords for texture mapping */
    'TextureStyle 509
    With Screw
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .ContourStyle = gleCLOSED
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .NumContourNormals = NUM_PTS
        .NumContourPoints = NUM_PTS
        .startZ = -6
        .endz = 9
        .twist = 220
    End With
    init_contour
    IDScrew = glGenLists(1)
    glNewList IDScrew, lstCompile
        DrawScrew
    glEndList
End Sub

' =========================================================== */

Sub DrawScrew()
    glPushMatrix
    glColor3f 0.5, 0.6, 0.6
'   gleScrew (20, contour, norms,
'                 NULL, -6.0, 9.0, lasty);
    Screw.twist = CX.MouseY
    Screw.Draw
    glPopMatrix
End Sub

Sub contour(x#, y#, i&)
Dim ax#, ay#, alen#
Static dx#, dy#
With Screw
    .SetContourPt i, SCALEz * (x), SCALEz * (y)
    If (i <> 0) Then
        ax = x - dx
        ay = y - dy
        alen = 1 / Sqr(ax * ax + ay * ay)
        ax = ax * alen
        ay = ay * alen
        .SetContourNormal i, ay, -ax
    End If
    i = i + 1
    dx = x
    dy = y
End With
End Sub


Sub init_contour()
Dim i&
   ' outline of extrusion */
   i = 0
   'edx: changed the normals
   Screw.SetContourNormal 0, 1, 0
   contour 1, 1, i
   contour 1, 2.9, i
   contour 0.9, 3, i
   contour -0.9, 3, i
   contour -1, 2.9, i

   contour -1, 1, i
   contour -2.9, 1, i
   contour -3, 0.9, i
   contour -3, -0.9, i
   contour -2.9, -1, i

   contour -1, -1, i
   contour -1, -2.9, i
   contour -0.9, -3, i
   contour 0.9, -3, i
   contour 1, -2.9, i

   contour 1, -1, i
   contour 2.9, -1, i
   contour 3, -0.9, i
   contour 3, 0.9, i
   contour 2.9, 1, i

   'contour 1, 1, i     ' repeat so that last normal is computed */
End Sub
   


' ===================== END OF FILE ================== */

