Attribute VB_Name = "mCylAndCones"
Option Explicit

Dim Cone As glePolyCone
Dim Cyl As glePolyCylinder
Const NPTS = 25
Dim inc1!, inc2!, inc3!

Public Sub InitCylAndCones()
inc1 = 0.1
inc2 = 0.2
inc3 = 0.25
Set Cone = gCtl.NewPolyCone
    With Cone
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureMode = CX.TextureStyle
        .TextureEnabled = CX.TextureEnabled
        .NUMCOLORS = NPTS
        .NumRadiusPts = NPTS
    End With
Set Cyl = gCtl.NewPolyCylinder
    With Cyl
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureMode = CX.TextureStyle
        .TextureEnabled = CX.TextureEnabled
        .NumPoints = 7
        .NUMCOLORS = 7
        .radius = 0.6

        .SetColors 0, 0, 0, 0, 0.8, 0.3, 0.8, 0.3, 0, 0.2, 0.3, 0.9, _
            0.2, 0.8, 0.5, 0, 0.8, 0.3, 0, 0.8, 0.3
        .SetPts -10, -10, 0, -10, 10, 0, 10, 10, 0, 10, -10, 0, _
            -10, -10, 0, -10, 9.9, 0, 10, 10, 0
    End With
    SetPts
End Sub
Public Sub SetPts()
    With Cone
        .SetRadii 0.1, 0.1, 0.3, 0.5, _
            0.3, 0.5, 0.6, 0.5, _
            0.4, 0.5, 1.8, 3, _
            1.8, 0.3, 0.3, 0.5, _
            0.3, 0.4, 0.3, 0.4, _
            0.4, 0.2, 0.2, 0.1, _
            0.1
        .NumPoints = NPTS
        .SetPts -11, 0, 0, -10, 0, 0, -8, 0, 0, -7, 1, 0, _
            -6, -1.1, 0, -4.5, 1.3, 0, -3.5, -0.8, 0, -2.5, 0.5, 0, _
            -1.5, 0, 0, -0.8, 0, 0, -0.4, 0, 0, 0, 0, 0, _
            0.4, 0, 0, 0.8, 0, 0, 1.5, 0, 0, 2.5, 0.7, 0, _
            3.5, -0.8, 0, 4.5, 1.2, 0, 6, -1, 0, 7, 0.8, 0, _
            8, 0, 0, 8.5, 0, 0, 9, 0, 0, 10, 0, 0, _
            11, 0, 0
        .SetColors 0, 0, 0, 0.5, 0, 0, 1, 0.8, 0.3, 0.2, 0.3, 0.3, _
            1, 1, 0.8, 0.3, 0.3, 0.3, 0.2, 0.2, 0.1, 0.3, 0.4, 0.3, _
            0.6, 0.7, 0.3, 1, 1, 0.3, 1, 0.8, 0.3, 1, 0.8, 0.3, _
            1, 0.8, 0.3, 0.8, 0.8, 0.3, 0.6, 0.7, 0.3, 0.3, 0.4, 0.3, _
             0.3, 0.3, 0.3, 0.3, 0.4, 0.3, 0.2, 0.2, 0.1, 0.4, 0.2, 0.3, _
            0.6, 0.6, 0.3, 1, 0.3, 0.3, 0.6, 0.4, 0.4, 0.7, 0.2, 0.2, _
            1, 0.8, 0.3
    End With

End Sub

Public Sub DrawCylAndCones()
Static y1!, y2!, y3!
'debug
y1 = y1 + inc1
y2 = y2 + inc2
y3 = y3 + inc3
If Abs(y1) >= 1 Then inc1 = -inc1
If Abs(y2) >= 1.3 Then inc2 = -inc2
If Abs(y3) >= 1.6 Then inc3 = -inc3
With Cone
    .SetPt 3, -7, -y1, 0
    .SetPt 4, -6, y1, 0
    .SetPt 5, -4.5, -y1, 0
    .SetPt 6, -3.5, y1, 0
    .SetPt 7, -2.5, -y1, 0
    '
    .SetPt 20, 8, -y1, 0
    .SetPt 19, 7, y1, 0
    .SetPt 18, 6, -y1, 0
    .SetPt 17, 4.5, y1, 0
    .SetPt 16, 3.5, -y1, 0
    .SetPt 15, 2.5, y1, 0
End With
Cone.Draw
Cyl.Draw
End Sub


