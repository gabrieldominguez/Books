VERSION 5.00
Begin VB.Form dlgText 
   Caption         =   "Form1"
   ClientHeight    =   4530
   ClientLeft      =   5640
   ClientTop       =   4395
   ClientWidth     =   6300
   LinkTopic       =   "Form1"
   ScaleHeight     =   4530
   ScaleWidth      =   6300
   Begin VB.TextBox Text1 
      Height          =   4425
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Top             =   60
      Width           =   6015
   End
End
Attribute VB_Name = "dlgText"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim a As CArea
Dim m_Dirty As Boolean

Private Sub Form_Load()
Dim s$, i&
    Set a = Areas.SelectedArea
    If a Is Nothing Then
        Debug.Assert 0
        Unload Me
        Exit Sub
    End If
    On Error Resume Next
    Text1.Fontname = a.Font
    Text1.Text = a.Text
End Sub

Private Sub Form_Resize()
    Text1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub Form_Unload(Cancel As Integer)
    dlgTextX = Left
    dlgTextY = Top
    If m_Dirty Then
        a.Text = Text1.Text
        frmMain.Dirty = True
    End If
End Sub

Private Sub Text1_Change()
    m_Dirty = True
End Sub
