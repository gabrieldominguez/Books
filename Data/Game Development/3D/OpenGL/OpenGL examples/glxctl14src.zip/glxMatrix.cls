VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxMatrix"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: Matrix class. A wrapper for the Mat... functions
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY:
'NOTES: this isn't finished or well tested. Don't use it yet! I may change
'several routines it uses
'-------------------------------------------------------------------------

Dim m!(0 To 15)
'a stack of matrices
Dim Stack!() '1 To 10, 0 To 15)
Dim ptr& 'stack pointer
Dim m_StackSize&

Private Sub Class_Initialize()
    m_StackSize = 10
    Identity
End Sub

Private Sub Class_Terminate()
'
End Sub

'-------------------------------------------------------------------------------------
'MATRIX STACK
'Pushing leaves a copy of the current matrix on the top of the stack.
'Manipulate it, use it, then pop it to restore the former current matrix.
'-------------------------------------------------------------------------------------
Public Function Push() As Boolean
Dim i&
    ptr = ptr + 1
    If ptr > m_StackSize Then
        m_StackSize = m_StackSize + 10
        ReDim Preserve Stack(1 To m_StackSize, 0 To 15)
    End If
    For i = 0 To 15
        Stack(ptr, i) = m(i)
    Next
    Push = True
End Function

'-------------------------------------------------------------------------------------
Public Function Pop() As Boolean
Dim i&
    If ptr < 1 Then
        Debug.Assert 0
        Exit Function
    End If
    For i = 0 To 15
        m(i) = Stack(ptr, i)
    Next
    ptr = ptr - 1
    Pop = True
End Function

'-------------------------------------------------------------------------------------
'Apply
'-------------------------------------------------------------------------------------
Public Sub Apply()
    glMultMatrixf m(0)
End Sub

'-------------------------------------------------------------------------------------
'GetMatrix
'-------------------------------------------------------------------------------------
Public Function GetMatrix(mOut!()) As Boolean
Dim i&
    On Error GoTo EH
    For i = 0 To 15: mOut(i) = m(i): Next
    GetMatrix = True
    Exit Function
EH:
    Exit Function
End Function

'-------------------------------------------------------------------------------------
'SetMatrix
'-------------------------------------------------------------------------------------
Public Function SetMatrix(mSrc!()) As Boolean
Dim i&
    On Error GoTo EH
    For i = 0 To 15: m(i) = mSrc(i): Next
    SetMatrix = True
    Exit Function
EH:
    Exit Function
End Function

'-------------------------------------------------------------------------------------
'Identity
'-------------------------------------------------------------------------------------
Public Sub Identity()
   m(0) = 1: m(1) = 0: m(2) = 0: m(3) = 0:
   m(4) = 0: m(5) = 1: m(6) = 0: m(7) = 0
   m(8) = 0: m(9) = 0: m(10) = 1: m(11) = 0
   m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1
End Sub

'-------------------------------------------------------------------------------------
'Copy
'-------------------------------------------------------------------------------------
Public Function Copy(mFrom!()) As Boolean
Dim i&
    On Error GoTo EH
    For i = 0 To 15: m(i) = mFrom(i): Next
    Copy = True
    Exit Function
EH:
    Exit Function
End Function

Public Function CopyTo(mOut!()) As Boolean
Dim i&
    On Error GoTo EH
    For i = 0 To 15: mOut(i) = m(i): Next
    CopyTo = True
    Exit Function
EH:
    Exit Function
End Function

'-------------------------------------------------------------------------------------
'Transpose
'-------------------------------------------------------------------------------------
Public Sub Transpose()
    MatTransposef m
End Sub

'-------------------------------------------------------------------------------------
'Invert
'-------------------------------------------------------------------------------------
Public Function Invert() As Boolean
    Invert = MatInvertf(m, m)
End Function

'-------------------------------------------------------------------------------------
'Translate
'-------------------------------------------------------------------------------------
Public Sub SetTranslation(ByVal x!, ByVal y!, ByVal z!)
    Identity
    m(12) = x: m(13) = y: m(14) = z
End Sub

'-------------------------------------------------------------------------------------
Public Sub SetTransOnly(ByVal x!, ByVal y!, ByVal z!)
    m(12) = x: m(13) = y: m(14) = z
End Sub

'-------------------------------------------------------------------------------------
Public Sub Translate(ByVal x!, ByVal y!, ByVal z!)
    MatTranslatef m, x, y, z
End Sub

'-------------------------------------------------------------------------------------
Public Sub TranslateX(ByVal distance!)
    MatTranslateOnOwnAxisf m, distance, AXIS_X
End Sub

'-------------------------------------------------------------------------------------
Public Sub TranslateY(ByVal distance!)
    MatTranslateOnOwnAxisf m, distance, AXIS_Y
End Sub

'-------------------------------------------------------------------------------------
Public Sub TranslateZ(ByVal distance!)
    MatTranslateOnOwnAxisf m, distance, AXIS_Z
End Sub

'-------------------------------------------------------------------------------------
Public Sub TranslateOnAxis(Axis!(), ByVal distance!)
    MatTranslateOnAxisf m, Axis, distance
End Sub

'-------------------------------------------------------------------------------------
'Scale
'-------------------------------------------------------------------------------------
Sub SetScale(ByVal x!, ByVal y!, ByVal z!)
    Identity
    m(0) = x: m(5) = y: m(10) = z
End Sub

Sub SetScaleOnly(ByVal x!, ByVal y!, ByVal z!)
    m(0) = x: m(5) = y: m(10) = z
End Sub

Sub ScaleSelf(ByVal x!, ByVal y!, ByVal z!)
    MatScaleOnOwnAxisf m, x, y, z
End Sub

'-------------------------------------------------------------------------------------
' Rotate
'-------------------------------------------------------------------------------------

'-------------------------------------------------------------------------------------
' rotation about the x-axis
'-------------------------------------------------------------------------------------
Public Sub SetRotationX(ByVal theta!)
    MatSetRotationXRadf m, DegToRadf(theta)
End Sub

'-------------------------------------------------------------------------------------
' rotation about the y-axis
'-------------------------------------------------------------------------------------
Public Sub SetRotationY(ByVal theta!)
    MatSetRotationYRadf m, DegToRadf(theta)
End Sub

'-------------------------------------------------------------------------------------
'rotation about the z-axis
'-------------------------------------------------------------------------------------
Public Sub SetRotationZ(ByVal theta!)
    MatSetRotationZRadf m, DegToRadf(theta)
End Sub

'-------------------------------------------------------------------------------------
'rotation about an axis
'-------------------------------------------------------------------------------------
Public Sub SetRotation(ByVal theta!, x!, y!, z!)
     MatSetRotationRadf m, DegToRadf(theta), x, y, z
End Sub

'-------------------------------------------------------------------------------------
'incremental rotations
'-------------------------------------------------------------------------------------
Public Sub RotateX(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_X, glxSelf
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateY(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_Y, glxSelf
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateZ(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_Z, glxSelf
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateWorldX(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_X, glxWorld
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateWorldY(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_Y, glxWorld
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateWorldZ(ByVal theta!)
    MatRotateRadf m, DegToRadf(theta), AXIS_Z, glxWorld
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateOnAxis(ByVal theta!, Axis!())
    MatRotateOnAxisRadf m, DegToRadf(theta), Axis, glxSelf
End Sub

'-------------------------------------------------------------------------------------
Public Sub RotateAroundAxis(ByVal theta!, Axis!())
    MatRotateOnAxisRadf m, DegToRadf(theta), Axis, glxWorld
End Sub

'-------------------------------------------------------------------------------------
'EULER
'-------------------------------------------------------------------------------------
Public Sub GetEuler(x!, y!, z!)
Dim v!(0 To 2)
    MatToEuler m, v
    x = v(0): y = v(1): z = v(2)
End Sub

'-------------------------------------------------------------------------------------
'VRML
'-------------------------------------------------------------------------------------
Public Sub GetAxisAngle(Angle!, x!, y!, z!)
Dim v!(0 To 2)
End Sub

Public Sub SetAxisAngle(Angle!, x!, y!, z!)
Dim v!(0 To 2)
End Sub



