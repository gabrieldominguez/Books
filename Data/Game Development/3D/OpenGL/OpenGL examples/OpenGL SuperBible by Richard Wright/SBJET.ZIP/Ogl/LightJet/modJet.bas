Attribute VB_Name = "mJet"
Public Sub RenderScene()

' Routine to draw jet
    
    Dim V(2, 2) As Single
    Dim Normal(2) As Single
    
    
    glClear clrColorBufferBit + clrDepthBufferBit
   
    ' Save matrix state and do the rotation
    glPushMatrix
    glRotatef xRot, 1#, 0#, 0#
    glRotatef yRot, 0#, 1#, 0#
    
    ' Nose Cone ****************************
    ' Set material color
    'glRGB 0, 255, 0
    glRGB 0, 0, 255
    
    glBegin bmTriangles
        glNormal3f 0#, -1#, 0#
        glVertex3f 0#, 0#, 60#
        glVertex3f -15#, 0#, 30#
        glVertex3f 15#, 0#, 30#
    'glEnd
    
    ' Vertices for this panel
    
    ' Declaration 1
    V(0, 0) = 15#
    V(0, 1) = 0#
    V(0, 2) = 30#
    V(1, 0) = 0#
    V(1, 1) = 15#
    V(1, 2) = 30#
    V(2, 0) = 0#
    V(2, 1) = 0#
    V(2, 2) = 60#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 15#, 0#, 30#
        glVertex3f 0#, 15#, 30#
        glVertex3f 0#, 0#, 60#
    'glEnd
    
    ' Declaration 2
    V(0, 0) = 0#
    V(0, 1) = 0#
    V(0, 2) = 60#
    V(1, 0) = 0#
    V(1, 1) = 15#
    V(1, 2) = 30#
    V(2, 0) = -15#
    V(2, 1) = 0#
    V(2, 2) = 30#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 0#, 60#
        glVertex3f 0#, 15#, 30#
        glVertex3f -15#, 0#, 30#
    'glEnd
    
    ' Body of the Plane ****************************
    ' Light Grey
    glRGB 192, 192, 192
    
    ' Declaration 3
    V(0, 0) = -15#
    V(0, 1) = 0#
    V(0, 2) = 30#
    V(1, 0) = 0#
    V(1, 1) = 15#
    V(1, 2) = 30#
    V(2, 0) = 0#
    V(2, 1) = 0#
    V(2, 2) = -56#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f -15#, 0#, 30#
        glVertex3f 0#, 15#, 30#
        glVertex3f 0#, 0#, -56#
    'glEnd
    
    ' Declaration 4
    V(0, 0) = 0#
    V(0, 1) = 0#
    V(0, 2) = -56#
    V(1, 0) = 0#
    V(1, 1) = 15#
    V(1, 2) = 30#
    V(2, 0) = 15#
    V(2, 1) = 0#
    V(2, 2) = 30#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 0#, -56#
        glVertex3f 0#, 15#, 30#
        glVertex3f 15#, 0#, 30#
    'glEnd
    
    'glBegin bmTriangles
        glNormal3f 0#, -1#, 0#
        glVertex3f 15#, 0#, 30#
        glVertex3f -15#, 0#, 30#
        glVertex3f 0#, 0#, -56#
    'glEnd
    
    ' Left Wing ****************************
    ' Large triangle for bottom of wing
    ' Dark Grey
    
    glRGB 128, 128, 128
    
    ' Declaration 5
    V(0, 0) = 0#
    V(0, 1) = 2#
    V(0, 2) = 27#
    V(1, 0) = -60#
    V(1, 1) = 2#
    V(1, 2) = -8#
    V(2, 0) = 60#
    V(2, 1) = 2#
    V(2, 2) = -8#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 2#, 27#
        glVertex3f -60#, 2#, -8#
        glVertex3f 60#, 2#, -8#
    'glEnd
   
    ' Declaration 6
    V(0, 0) = 60#
    V(0, 1) = 2#
    V(0, 2) = -8#
    V(1, 0) = 0#
    V(1, 1) = 7#
    V(1, 2) = -8#
    V(2, 0) = 0#
    V(2, 1) = 2#
    V(2, 2) = 27#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 60#, 2#, -8#
        glVertex3f 0#, 7#, -8#
        glVertex3f 0#, 2#, 27#
    'glEnd
    
    ' Declaration 7
    V(0, 0) = 60#
    V(0, 1) = 2#
    V(0, 2) = -8#
    V(1, 0) = -60#
    V(1, 1) = 2#
    V(1, 2) = -8#
    V(2, 0) = 0#
    V(2, 1) = 7#
    V(2, 2) = -8#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 60#, 2#, -8#
        glVertex3f -60#, 2#, -8#
        glVertex3f 0#, 7#, -8#
    'glEnd
    
    ' Declaration 8
    V(0, 0) = 0#
    V(0, 1) = 2#
    V(0, 2) = 27#
    V(1, 0) = 0#
    V(1, 1) = 7#
    V(1, 2) = -8#
    V(2, 0) = -60#
    V(2, 1) = 2#
    V(2, 2) = -8#
    Call CalcNormal(V, Normal)
    ' Other wing of top section
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 2#, 27#
        glVertex3f 0#, 7#, -8#
        glVertex3f -60#, 2#, -8#
    'glEnd
    
    ' Tail Section ****************************
    ' Bottom of back fin
    glRGB 255, 255, 0
    
    'glBegin bmTriangles
        glNormal3f 0#, -1#, 0#
        glVertex3f -30#, -0.5, -57#
        glVertex3f 30#, -0.5, -57#
        glVertex3f 0#, -0.5, -40#
    'glEnd
    
    ' Declaration 9
    V(0, 0) = 0#
    V(0, 1) = -0.5
    V(0, 2) = -40#
    V(1, 0) = 30#
    V(1, 1) = -0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = 4#
    V(2, 2) = -57#
    Call CalcNormal(V, Normal)
    
    ' Top of Left Side
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, -0.5, -40#
        glVertex3f 30#, -0.5, -57#
        glVertex3f 0#, 4#, -57#
    'glEnd
    
    ' Declaration 10
    V(0, 0) = 0#
    V(0, 1) = 4#
    V(0, 2) = -57#
    V(1, 0) = -30#
    V(1, 1) = -0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = -0.5
    V(2, 2) = -40#
    Call CalcNormal(V, Normal)
    
    ' Top of right side
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 4#, -57#
        glVertex3f -30#, -0.5, -57#
        glVertex3f 0#, -0.5, -40#
    'glEnd
    
    ' Declaration 11
    V(0, 0) = 30#
    V(0, 1) = -0.5
    V(0, 2) = -57#
    V(1, 0) = -30#
    V(1, 1) = -0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = 4#
    V(2, 2) = -57#
    Call CalcNormal(V, Normal)
    
    ' Back of bottom of tail
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 30#, -0.5, -57#
        glVertex3f -30#, -0.5, -57#
        glVertex3f 0#, 4#, -57#
    'glEnd
    
    ' Declaration 12
    V(0, 0) = 0#
    V(0, 1) = 0.5
    V(0, 2) = -40#
    V(1, 0) = 3#
    V(1, 1) = 0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = 25#
    V(2, 2) = -65#
    Call CalcNormal(V, Normal)
    
    ' Top of Tail Section Left
    glRGB 255, 0, 0
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, -0.5, -40#
        glVertex3f 3#, 0.5, -57#
        glVertex3f 0#, 25#, -65#
    'glEnd
    
    ' Declaration 13
    V(0, 0) = 0#
    V(0, 1) = 25#
    V(0, 2) = -65#
    V(1, 0) = -3#
    V(1, 1) = -0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = 0.5
    V(2, 2) = -40#
    Call CalcNormal(V, Normal)
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 0#, 25#, -65#
        glVertex3f -3#, -0.5, -57#
        glVertex3f 0#, 0.5, -40#
    'glEnd
    
    ' Declaration 14
    V(0, 0) = 3#
    V(0, 1) = 0.5
    V(0, 2) = -57#
    V(1, 0) = -3#
    V(1, 1) = 0.5
    V(1, 2) = -57#
    V(2, 0) = 0#
    V(2, 1) = 25#
    V(2, 2) = -65#
    Call CalcNormal(V, Normal)
    
    ' Back of horizontal section
    'glBegin bmTriangles
        glNormal3f Normal(0), Normal(1), Normal(2)
        glVertex3f 3#, 0.5, -57#
        glVertex3f -3#, 0.5, -57#
        glVertex3f 0#, 25#, -65#
    glEnd
    
    ' Restore Transformations
    glPopMatrix
    
    SwapBuffers frmDisplay.hDC
    
    ' Flush drawing commands
    glFlush
    
End Sub
