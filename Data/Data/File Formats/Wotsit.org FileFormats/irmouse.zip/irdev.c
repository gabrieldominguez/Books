#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/serial.h>
#include <linux/serial.h>
#include <termios.h>
#include <unistd.h>

#define BAUD		B1200
#define IR_BUTTONDOWN	0xa0
#define IR_BUTTONUP	0xaa
#define MINNEED		3
#define REPEATWAIT	20

void dtr_set(int fd) {
};

void dtr_clear(int fd) {
};

void setup(int fd) {
  struct termios info,info2;

  /* set speed */
  tcgetattr(fd,&info);
  cfsetispeed(&info,BAUD);
  cfsetospeed(&info,BAUD);
  cfmakeraw(&info);   /* make it raw */
  tcsetattr(fd,TCSANOW,&info);
  tcsendbreak(fd,0);
  tcgetattr(fd,&info);
  tcgetattr(fd,&info2);
  cfsetispeed(&info2,B0);
  cfsetospeed(&info2,B0);
  tcsetattr(fd,TCSANOW,&info2);
  sleep(1);
  tcsetattr(fd,TCSANOW,&info);
};

char codetostr_buffer[128];
char *codetostr(unsigned char ch) {
  switch (ch) {
    case 0x01 : return "Help";
    case 0x02 : return "Start";
    case 0x03 : return "Phone";
    case 0x04 : return "TV";
    case 0x05 : return "Gde";
    case 0x06 : return "CD";
    case 0x07 : return "Msg";
    case 0x08 : return "Select";
    case 0x0a : return "Channel +";
    case 0x09 : return "Volume +";
    case 0x0b : return "Mute";
    case 0x0c : return "Volume -";
    case 0x0d : return "Channel -";
    case 0x0e : return "Skip Prev";
    case 0x0f : return "Play";
    case 0x10 : return "Skip Next";
    case 0x11 : return "Menu";
    case 0x12 : return "Stop";
    case 0x13 : return "Pause";
    case 0x14 : return "Number 3";
    case 0x15 : return "Number 1";
    case 0x16 : return "Number 2";
    case 0x17 : return "Number 6";
    case 0x18 : return "Number 4";
    case 0x19 : return "Number 5";
    case 0x1a : return "Number 9";
    case 0x1b : return "Number 8";
    case 0x1c : return "Number 7";
    case 0x1d : return "Number 0";
    case 0x1e : return "Symbol #";
    case 0x1f : return "Symbol *";
    case 0x23 : return "Terminate";
    case 0x38 : return "Mouse up";
    case 0x39 : return "Left Mouse Down";
    case 0x3a : return "Right Mouse Down";
    case 0x3b : return "Both Mouse Down";
  };
  sprintf(codetostr_buffer,"Unknown '0x%x'",ch);
  return codetostr_buffer;
};
main () {
  int fd;
  struct serial_struct info;
  int br;
  unsigned char ch;
  unsigned char repeatch;
  int repeatcount;
  int codecount[256];
  int instate=0;
  long x=0;
  long y=0;
  int s;

  if ((fd=open("/dev/irmouse",O_RDWR))<0) {
    printf("Can't open!\n");
    exit();
  };
  setup(fd);
  bzero(codecount);
  repeatch=0x0;
  while (repeatch!=0x8) {
    br=read(fd,&ch,sizeof(ch));
    if (!br) break;
    if (ch>=0x40) {
      /* handle codes and mousepad */
      if (ch>0x6f) {
        if (ch==IR_BUTTONUP) {
          bzero(codecount,sizeof(codecount));
          instate=0;
        };
        if (ch==IR_BUTTONDOWN) {
          bzero(codecount,sizeof(codecount));
          instate=0;
        };
      } else { /* if ch > 0x6f */
        s=(ch>>4)-3;
        switch (ch&0xf) {
          case 0x0: y-=4*s; x+=0*s; break;
          case 0x1: y-=3*s; x+=1*s; break;
          case 0x2: y-=2*s; x+=2*s; break;
          case 0x3: y-=1*s; x+=3*s; break;
          case 0x4: y+=0*s; x+=4*s; break;
          case 0x5: y+=1*s; x+=3*s; break;
          case 0x6: y+=2*s; x+=2*s; break;
          case 0x7: y+=3*s; x+=1*s; break;
          case 0x8: y+=4*s; x+=0*s; break;
          case 0x9: y+=3*s; x-=1*s; break;
          case 0xa: y+=2*s; x-=2*s; break;
          case 0xb: y+=1*s; x-=3*s; break;
          case 0xc: y+=0*s; x-=4*s; break;
          case 0xd: y-=1*s; x-=3*s; break;
          case 0xe: y-=2*s; x-=2*s; break;
          case 0xf: y-=3*s; x-=1*s; break;
        };
        fprintf(stderr,"\nPosition [%d,%d,%d]",x,y,s);
      };
    } else { /* if ch>=0x40 */
      switch (instate) {
        case 0:   /* normal waiting for something */
                if ((codecount[ch]++)>MINNEED) {
                  bzero(codecount,sizeof(codecount));
                  fprintf(stderr,"\n%s",codetostr(ch));
                  instate=1;
                  repeatcount=REPEATWAIT;
                  repeatch=ch;
                };
                break;
      case 1: /* waiting for repeatcount repeats of char before repeating */
                if (ch==repeatch) {
                  if (repeatcount--<=0) instate=2;
                } else {
                  instate=0;
                };
                break;
        case 2: /* repeat incomming chars */
                if (ch==repeatch) {
                  fprintf(stderr,".");
                } else {
                  instate=0;
                };
                break;
      };
    }; /* if ch>=0x40 */
  };
  close(fd);
  fprintf(stderr,"\n");
};
