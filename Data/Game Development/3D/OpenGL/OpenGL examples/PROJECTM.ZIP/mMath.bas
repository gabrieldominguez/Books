Attribute VB_Name = "mMath"
Option Explicit
'----------------------------------------------------------------
Public Const PI = 3.14159265358979
Public Const M_PI = 3.14159265358979
Public Const ONE_OVER_180 = 1 / 180
Public Const ONE_OVER_PI = (1 / PI)
Public Const ZERO_EPS = 0.00000001
Public Const FLOAT_MAX = 3.402823466E+38
Public Const FLOAT_MIN = 1.175494351E-38
'----------------------------------------------------------------
Public Type POINT4F
    v(0 To 3) As Single
End Type
Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

'------------------------------------------------------------
Public Function ULong(lng&) As Double
On Error GoTo EH
    'ULong = CDbl(lng) And &HFFFF
    If lng < 0 Then
        ULong = 2147483648# + 2147483648# + lng
    Else
        ULong = lng
    End If
    Exit Function
EH:
    Debug.Assert 0
    Resume Next
End Function

'------------------------------------------------------------
Public Function Max(A, B)
Max = IIf(A > B, A, B)
End Function

Public Function Min(A, B)
Min = IIf(A < B, A, B)
End Function

'------------------------------------------------------------
Public Function DegToRadf!(A!)
DegToRadf = A * PI * ONE_OVER_180
End Function

Public Function RadToDegf!(A!)
RadToDegf = (A * 180) * ONE_OVER_PI
End Function

'------------------------------------------------------------
'return the 255 values for the color components
Public Function GetRValue(x As Long) As Byte
    GetRValue = (x \ &H10000) And &HFF
End Function

Public Function GetGValue(x As Long) As Byte
    GetGValue = (x \ &H100) And &HFF
End Function

Public Function GetBValue(x As Long) As Byte
    GetBValue = x And &HFF
End Function

'------------------------------------------------------------
Public Function Arcsin(x!)
If x >= 1 Then
    Arcsin = PI / 2
ElseIf x <= -1 Then
    Arcsin = -PI / 2
Else
    Arcsin = Atn(x / Sqr(-x * x + 1))
End If
End Function

'------------------------------------------------------------
Public Function ArcCos!(x!)
If x >= 1 Then
    ArcCos = 0
ElseIf x <= -1 Then
    ArcCos = PI
Else
    ArcCos = Atn(-x / Sqr(-x * x + 1)) + 2 * Atn(1)
End If
End Function

'-------------------------------------------------------------------------
'Is this correct?
Function Atan2!(ByVal x!, ByVal y!)
    'On Error Resume Next
    '0 to PI
    If y = 0 Then
        If x = 0 Then
            Atan2 = 0
        ElseIf x > 0 Then
            Atan2 = 0 'PI / 2
        Else
            Atan2 = PI '-PI / 2
        End If
    ElseIf x = 0 Then
        If y > 0 Then
            Atan2 = PI / 2
        Else
            Atan2 = -PI / 2
        End If
    ElseIf x > 0 Then
        Atan2 = Atn(y / x)
    Else
        Atan2 = (PI - Atn(Abs(y) / Abs(x))) * Sgn(y)
    End If
End Function

