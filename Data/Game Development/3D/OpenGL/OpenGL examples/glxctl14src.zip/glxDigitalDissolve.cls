VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxDigitalDissolve"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
''*****************************Module*Header*******************************\
'* Module Name: /COMMON/clear.hxx
'* Defines and externals for screen saver common shell
'* Copyright (c) 1996 Microsoft Corporation
'-------------------------------------------------------------------------
'-------------------------------------------------------------------------
'FUNCTION: does what it says, a digital dissolve
'
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

Const SS_CLEAR_BASE_DIV = 32
Const SS_CLEAR_BASE_SIZE = 16

Dim m_rectBuf() As Boolean
Dim m_rectBufSize&, m_rectSize&
Dim m_AutoCalibrate As Boolean
Dim m_idealTime!

Private Sub Class_Initialize()
    m_rectSize = SS_CLEAR_BASE_SIZE
    m_idealTime = 2
End Sub

Private Sub Class_Terminate()
'-------------------------------------------------------------------------
End Sub

'-------------------------------------------------------------------------
'* CalibrateClear
'* Try to calibrate the clear so it takes the specified time
'-------------------------------------------------------------------------
Public Function CalibrateClear&(ByVal Width&, ByVal Height&, ByVal fClearTime!)
Dim factor!, idealNRects&, nRects&, baseSize&
Dim Timer As New glxTimer
Dim elapsed!
    baseSize = IIf(Width < Height, Width, Height) / SS_CLEAR_BASE_DIV
    If (baseSize = 0) Then
        baseSize = 1
    End If
    Timer.Start

    If m_AutoCalibrate Then
        ' Clear a small region (quarter-screen) and extrapolate
        Clear Width \ 2, Height \ 1, baseSize
    Else
        Clear Width, Height, baseSize
    End If
    elapsed = Timer.TimerStop()
    If m_AutoCalibrate Then
        ' extrapolate to full screen time
        ' this approximation resulted in clears being somewhat less than ideal
        elapsed = elapsed * 4
    End If
    ' Adjust size of rects for ideal clear time
    If elapsed <= 0 Then
        m_rectSize = 1
        CalibrateClear = m_rectSize
        Exit Function
    End If

    nRects = m_RectangleCount(Width, Height, baseSize)
    factor = fClearTime / elapsed
    idealNRects = (factor * nRects)
    'note:
    m_rectSize = (Sqr((Width * Height) / idealNRects) + 1) '0.5)
    If (m_rectSize = 0) Then
        m_rectSize = 1
    End If
    CalibrateClear = m_rectSize
End Function

'-------------------------------------------------------------------------
'*
'DIGITAL_DISSOLVE_CLEAR::Clear
'* Clears by drawing random rectangles
'-------------------------------------------------------------------------
Public Function ClearRandom(ByVal Width&, ByVal Height&) As Boolean
    ClearRandom = Clear(Width, Height, m_rectSize)
End Function

Public Function Clear(ByVal Width&, ByVal Height&, ByVal nSize&) As Boolean
Dim pRect As Boolean, bCalibrate As Boolean
Dim count&, nRects&, i&, xDim&, yDim&
Dim up&, down&, searchUp As Boolean
Dim x&, y&
    If (nSize <= 0) Or Width = 0 Or Height = 0 Then
        Clear = False
        Exit Function
    End If
    ' determine xdim, ydim from size
    xDim = UC.Ex.RoundUp(Width / nSize)
    yDim = UC.Ex.RoundUp(Height / nSize)

    ' figure out how many rects needed
    nRects = xDim * yDim
    count = nRects
    ' make sure enough room
    If (ValidateBufSize(nRects)) = 0 Then
        Debug.Assert 0
        Clear = False
        Exit Function
    End If
    ' reset the rect array to uncleared
    For i = 0 To count - 1
        m_rectBuf(i) = False
    Next
    ' Clear random rectangles
    glEnable GL_SCISSOR_TEST
    Do While (count)
        ' pick a random rect
        i = UC.Ex.RandomInt(nRects - 1)
        If (m_rectBuf(i)) Then
            ' This rect has already been cleared - find an empty one
            ' Scan up and down from x,y, looking at the array linearly
            up = i
            down = i
            Do While m_rectBuf(i)
                If searchUp Then
                    ' search up side
                    If (up < (nRects - 1)) Then
                        up = up + 1
                    End If
                    i = up
                Else
                    ' search down side
                    If down > 0 Then
                        down = down - 1
                    End If
                    i = down
                End If
                searchUp = Not searchUp
            Loop
        End If
    
        ' clear the x,y rect
        'note: some incomplete clears, maybe increase nSize by 1
        x = (i Mod xDim) * nSize
        y = (i \ xDim) * nSize
        'glScissor (i Mod xDim) * nSize, (i / xDim) * nSize, nSize, nSize + 1
        glScissor x, y, nSize, nSize + 1
        glClear GL_COLOR_BUFFER_BIT
        glFlush

        m_rectBuf(i) = True  ' mark as taken
        count = count - 1
    Loop
    glDisable GL_SCISSOR_TEST
    Clear = True
End Function

'-------------------------------------------------------------------------
'* RectangleCount
'*
'-------------------------------------------------------------------------
Private Function m_RectangleCount&(ByVal Width&, ByVal Height&, ByVal SIZE&)
m_RectangleCount = UC.Ex.RoundUp(Width / SIZE) * UC.Ex.RoundUp(Height / SIZE)
End Function

'-------------------------------------------------------------------------
'* ValidateBufSize
'*
'-------------------------------------------------------------------------
Private Function ValidateBufSize(ByVal nRects&) As Boolean
On Error GoTo errorhandler
    If (nRects > m_rectBufSize) Then
        ' need a bigger rect buf
        'BOOL *r = (BOOL *) LocalAlloc( LMEM_FIXED, sizeof(BOOL) * nRects )
        ReDim m_rectBuf(0 To nRects - 1)
        m_rectBufSize = nRects
    End If
    ValidateBufSize = True
errorhandler:
Exit Function
End Function

'-------------------------------------------------------------------------
'* DrawGdiRect
'*
'* Clears the rect with the brush
'-------------------------------------------------------------------------
'Public Sub DrawGdiSquare(hdc&, hbr&, l&, t&, r&, b&) ' As RECT)
'Dim rc As rect
'    If pRect.width = 0 Or pRect.height = 0 Then
'        Exit Sub
'    End If
'    FillRect hdc, pRect, hbr
'    GdiFlush
'End Sub


'#ifdef SS_INITIAL_CLEAR
''-------------------------------------------------------------------------------
'|
'|    RectWipeClear(width, height):
'|       - Does a rectangular wipe (or clear) by drawing in a sequence
'|         of rectangles using Gdi
'|       MOD: add calibrator capability to adjust speed for different
'|            architectures
'|       MOD: this can be further optimized by caching the brush
'|
'-------------------------------------------------------------------------------*/
'Public Sub ss_GdiRectWipeClear(hWnd&, Width&, Height&)
'Dim Hdc&, hbr&, rc As RECT
'Dim i&, j&, xinc&, yinc&, numDivs&
'Dim xmin&, xmax&, ymin&, ymax&
'Dim repCount&
'    repCount = 10
'    numDivs = 500
'    xinc = 1
'    yinc = 1
'    numDivs = Height
'    xmin = ymin = 0
'    xmax = Width
'    ymax = Height
'
'    Hdc = GetDC(hWnd)
'
'    hbr = CreateSolidBrush(RGB(0, 0, 0))
'    For i = 0 To (numDivs / 2 - 2)
'      For j = 0 To repCount - 1
'        rc.Left = xmin
'        rc.Top = ymin
'        rc.Right = xmax
'        rc.Bottom = ymin + yinc
'        FillRect Hdc, rc, hbr
'        rc.Top = ymax - yinc
'        rc.Bottom = ymax
'        FillRect Hdc, rc, hbr
'        rc.Top = ymin + yinc
'        rc.Right = xmin + xinc
'        rc.Bottom = ymax - yinc
'        FillRect Hdc, rc, hbr
'        rc.Left = xmax - xinc
'        rc.Top = ymin + yinc
'        rc.Right = xmax
'        rc.Bottom = ymax - yinc
'        FillRect Hdc, rc, hbr
'      Next
'
'      xmin = xmin + xinc
'      xmax = xmax - xinc
'      ymin = ymin + yinc
'      ymax = ymax - yinc
'    Next
'    ' clear last square in middle
'    rc.Left = xmin
'    rc.Top = ymin
'    rc.Right = xmax
'    rc.Bottom = ymax
'    FillRect Hdc, rc, hbr
'    DeleteObject (hbr)
'    ReleaseDC hWnd, Hdc
'    GdiFlush
'End Sub

'-------------------------------------------------------------------------
'RectWipeClear
'* Clears by drawing top, bottom, left, right rectangles that shrink in size
'* towards the center.
'* Calibration is used to try to maintain an ideal clear time.
'-------------------------------------------------------------------------
'Public Function ss_RectWipeClear&(Width&, Height&, repCount&)
'Dim i&, j&, xinc&, yinc&, numDivs&
'Dim xmin&, xmax&, ymin&, ymax&, w&, H&
'Dim bCalibrate As Boolean
'Dim elapsed As Double
'Static idealTime#
'idealTime# = 0.7
'Dim Timer As New glxTimer
'    xinc = 1
'    yinc = 1
'    numDivs = Height ' assumes height <= width
'
'    xmin = ymin = 0
'    xmax = Width - 1
'    ymax = Height - 1
'
'    glClearColor 0, 0, 0, 0
'    glEnable (GL_SCISSOR_TEST)
'    If (repCount = 0) Then
'        bCalibrate = True
'        repCount = 1
'        Timer.Start
'    End If
'    For i = 0 To numDivs / 2 - 1
'      w = xmax - xmin + 1
'      H = ymax - ymin + 1
'      For j = 0 To repCount - 1
'        ' bottom
'        glScissor xmin, ymin, w, 1
'        glClear GL_COLOR_BUFFER_BIT
'        ' left
'        glScissor xmin, ymin, 1, H
'        glClear GL_COLOR_BUFFER_BIT
'        ' right
'        glScissor xmax, ymin, 1, H
'        glClear (GL_COLOR_BUFFER_BIT)
'        ' top
'        glScissor xmin, ymax, w, 1
'        glClear GL_COLOR_BUFFER_BIT
'        glFlush ' to eliminate 'bursts'
'      Next
'      xmin = xmin + xinc
'      xmax = xmax - xinc
'      ymin = ymin + yinc
'      ymax = ymax - yinc
'    Next
'    If (bCalibrate) Then
'        elapsed = Timer.TimerStop()
'        ' try to maintain ideal clear time
'        If (elapsed < idealTime) Then
'            ' increase repCount to slow down the clear
'            If (elapsed = 0#) Then
'                repCount = 10  ' just in case
'            Else
'                repCount = ((idealTime / elapsed) + 0.5)
'            End If
'        End If
'    End If
'    glDisable GL_SCISSOR_TEST
'    ss_RectWipeClear = repCount
'End Function



