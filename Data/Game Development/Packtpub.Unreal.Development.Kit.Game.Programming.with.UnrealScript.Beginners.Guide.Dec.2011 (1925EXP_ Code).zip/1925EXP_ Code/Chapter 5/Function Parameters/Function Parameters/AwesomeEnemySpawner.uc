class AwesomeEnemySpawner extends AwesomeActor
    placeable;

var TestEnemy MySpawnedEnemy;

function PostBeginPlay()
{
    super.PostBeginPlay();

    DoSomething(5.0, true);
    DoSomething(5.0, false);
    DoSomething(5.0);
}

function DoSomething(float MyFloat, optional bool MyBool)
{
    `log(MyFloat @ MyBool);
}

function SpawnEnemy()
{
    MySpawnedEnemy = spawn(class'TestEnemy', self,, Location);
}

function EnemyDied()
{
    SpawnEnemy();
}

function FreezeEnemy()
{
    if(MySpawnedEnemy != none)
        MySpawnedEnemy.Freeze();
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}