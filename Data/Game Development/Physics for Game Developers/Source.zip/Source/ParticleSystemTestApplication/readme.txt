========================================================================
    Managed DirectX Application Wizard : "ParticleSystemTestApplication" Project Overview
========================================================================

The Managed DirectX Application Wizard has created this "ParticleSystemTestApplication" project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

ParticleSystemTestApplication.csproj
    This is the main project file for projects generated using the Managed DirectX Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Managed DirectX Application Wizard.


d3dapp.cs
d3denumeration.cs
d3dfont.cs
d3dutil.cs
D3DSettingForm.cs
    These files contain base classes for setting up and rendering to Managed Direct3D devices.

D3DTriangle.cs
    This file contains code to render a triangle to a Managed Direct3D device.
