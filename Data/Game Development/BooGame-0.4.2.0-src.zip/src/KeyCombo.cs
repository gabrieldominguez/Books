/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;

namespace BooGame
{
    /// <summary>
    /// A combination of keys that when pressed in order are activated.
    /// </summary>
    /// <remarks>
    /// <example>
    /// The following is an example of how to setup the key combo system:
    /// <code>
    /// // Create the key combo (ABCD)
    /// KeyCombo abcd = new KeyCombo('a', 'b', 'c','d');
    /// 
    /// // Make the game state call the combo
    /// Core.Game.OnKeyDown += new KeyboardEventHandler(abcd.OnKeyDown);
    /// 
    /// // Setup the activated event when the combo is pressed
    /// abcd.Activated += new KeyComboEventHandler(abcd_Activated);
    /// 
    /// // Add the abcd_Activated function
    /// void abcd_Activated(object sender, KeyComboEventArgs e)
    /// {
    ///     // An example of what you can do when the combo is pushed
    ///     Display.WindowCaption += "!";
    /// }
    /// </code>
    /// </example>
    /// </remarks>
    public class KeyCombo : KeyCollection
    {
        static KeyCombo()
        {
            Core.Initialize();
        }
        private KeyCollection m_KeySequence = new KeyCollection();
        public KeyCombo() : base()
        {
        }

        public KeyCombo(params Keys[] keys)
            : this()
        {
            this.Add(keys);
        }

        public KeyCombo(params char[] chars)
            : this()
        {
            this.Add(chars);
        }

        public KeyCombo(KeyCollection keys) : this()
        {
            this.Add(keys);
        }

        public KeyCombo(Keys key) : this()
        {
            this.Add(key);
        }

        public KeyCombo(KeyCombo keys) : this()
        {
            this.Add(keys);
        }

        public int Add(KeyCombo keys)
        {
            foreach (Keys key in keys)
                this.Add(key);
            return this.Count;
        }

        private bool m_Tracking = true;
        /// <summary>
        /// Gets and sets whether the key combo is bring tracked.
        /// </summary>
        public bool Tracking
        {
            get { return m_Tracking; }
            set { m_Tracking = value; }
        }
        
        /// <summary>
        /// Call this function during an OnKeyDown event.
        /// </summary>
        /// <param name="sender">Sender object</param>
        /// <param name="e">The arguments passed to the event.</param>
        public void OnKeyDown(object sender, KeyboardEventArgs e)
        {
            OnKeyDown(e);
        }

        /// <summary>
        /// Call this function during an OnKeyDown event.
        /// </summary>
        /// <param name="e">The arguments associated with the event.</param>
        public virtual void OnKeyDown(KeyboardEventArgs e)
        {
            if(this.Count <= 0)
                return;
            if (m_Tracking)
            {
                m_KeySequence.Add(e.Key);
                if (m_KeySequence.Count < this.Count)
                    return;
                while (m_KeySequence.Count > this.Count)
                    m_KeySequence.RemoveAt(0);
                bool working = true;
                for (int i = 0; i < this.Count; i++)
                {
                    if (m_KeySequence[i] != this[i])
                    {
                        working = false;
                        break;
                    }
                }
                if (working)
                {
                    m_KeySequence.Clear();
                    if (Activated != null)
                        Activated(this, new KeyComboEventArgs(this));
                }
            }
        }

        /// <summary>
        /// This event is invoked when the key combo is activated.
        /// </summary>
        public event KeyComboEventHandler Activated;

    }

    /// <summary>
    /// Describes a event with the keyboard.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="e">The arguments associated with the event.</param>
    public delegate void KeyComboEventHandler(object sender, KeyComboEventArgs e);

    /// <summary>
    /// Arguments passed to a key combination event.
    /// </summary>
    public class KeyComboEventArgs : EventArgs
    {
        public KeyComboEventArgs(KeyCombo combo)
        {
            m_Combo = combo;
        }
        private KeyCombo m_Combo;
        /// <summary>
        /// Gets the combo associated with the event.
        /// </summary>
        public KeyCombo Combo
        {
            get { return m_Combo; }
        }
    }

    /// <summary>
    /// A sequence of keys.
    /// </summary>
    public class KeyCollection : CollectionBase, ICollection
    {
        public KeyCollection() : base()
        {
        }

        public KeyCollection(params Keys[] keys)
        {
            this.Add(keys);
        }

        public KeyCollection(params char[] chars)
        {
            this.Add(chars);
        }

        public KeyCollection(KeyCollection keys)
        {
            this.Add(keys);
        }

        public KeyCollection(Keys key)
        {
            this.Add(key);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public Keys this[int index]
        {
            get { return ((Keys)List[index]); }
            set { List[index] = value; }
        }

        public int Add(Keys key)
        {
            return (List.Add(key));
        }

        public int Add(Keys[] keys)
        {
            foreach(Keys key in keys)
                this.Add(key);
            return this.Count;
        }

        public int Add(params char[] chars)
        {
            foreach (char chr in chars)
                this.Add(Keyboard.CharToKey(chr));
            return this.Count;
        }

        public int Add(KeyCollection keyCollection)
        {
            for (int i = 0; i < keyCollection.Count; i++)
                this.List.Add(keyCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Keys keys)
        {
            List.Insert(index, keys);
        }

        public void Remove(Keys keys)
        {
            List.Remove(keys);
        }

        public int IndexOf(Keys keys)
        {
            return (List.IndexOf(keys));
        }

        public bool Contains(Entity keys)
        {
            return (List.Contains(keys));
        }

        public virtual void CopyTo(Keys[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }
    }
}
