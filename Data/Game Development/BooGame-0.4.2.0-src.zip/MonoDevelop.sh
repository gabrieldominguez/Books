#!/bin/sh
./tools/Prebuild/Prebuild /target monodev /file Prebuild.xml /pause
