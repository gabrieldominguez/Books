VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CGLETest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'
'debug multiple instances
Public debugID&
'
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_StartX&, m_StartY&
Dim m_MouseX&, m_MouseY&
Public xRotation!, yRotation!, zRotation!
Dim zTranslation!
Dim m_JoinStyle&
Dim m_NormStyle&
Dim m_TextureMode As gleTextureModes
Dim m_TextureEnabled As Boolean
Dim m_CurID&


Private Sub Class_Initialize()
optMouseTrack = True
m_JoinStyle = gleANGLE
m_NormStyle = gleEDGE
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    glEnable glcCullFace
    glDepthFunc cfLEqual
    With gCtl.Lights(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 0.8, 1, 1
        .SetPosition 10, 10, 10
        .Enabled = True
    End With
    With gCtl.Lights(liLight1)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 1, 1, 1
        .SetPosition 0, 0, 150
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 0.3, 0.3, 0.3
        .TwoSide = True
    End With
    '' roughly, measured in centimeters */
    'glFrustum (-9.0, 9.0, -9.0, 9.0, 50.0, 150.0);
    With gCtl.Camera
        .FarPlane = 800
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 0, 0, 20
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFront
        .SetDiffuse 1, 0.8, 0.38
        .SetSpecular 0.2, 0.2, 0.2
        .SpecExp = 30
    End With
    glShadeModel GL_SMOOTH
    glColorMaterial GL_FRONT_AND_BACK, GL_DIFFUSE
    glEnable GL_COLOR_MATERIAL

    ' set a nice color
    glDisable GL_COLOR_MATERIAL
    m_Mat.SetMaterial
    '
    gCtl.MouseRotate = optMouseTrack
    '
    m_CreateTextures
    glEnable GL_TEXTURE_2D
    m_TextureEnabled = True
    'this will create the lists
    TextureStyle = GLE_TEXTURE_VERTEX_FLAT
    ''m_CreateLists
    '
    QuadObj = gluNewQuadric
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    CurObject = 1 'obj to draw
End Sub

Private Sub m_CreateLists()
    InitBeam
    InitCandle 'lathe
    InitCones
    InitCyl

    InitHelix
    InitScrew
    InitSuper
    InitSpiral
    InitTexas '-extr
    InitTwist 'tx-extr
    InitToroid
    '
    'these aren't in lists
    InitCylAndCones
    InitExtrusions
    InitSpirals
    InitLathes
End Sub

Public Sub Draw()
    glPushMatrix
    glTranslatef 0#, 0#, -15#
    If optMouseTrack = 0 Then
        glTranslatef 0, 0, zTranslation
        glRotatef xRotation, 1, 0, 0
        glRotatef yRotation, 0, 1, 0
    Else
        gCtl.Trackball.Update
    End If
    'enlarge the GLUT primitives
    If m_CurID < 11 Then
        glScalef 4, 4, 4
    End If
    With gCtl.Shapes
        glPushMatrix
        Select Case m_CurID
        Case 1:
            glTranslatef -2, 0, 0
            .SolidCone 1, 2, 16, 16
            glTranslatef 4, 0, 0
            .WireCone 1, 2, 16, 16
        Case 2
            glTranslatef -2, 0, 0
            .SolidCube 1
            glTranslatef 4, 0, 0
            .WireCube 1
        Case 3
            glTranslatef -2, 0, 0
            .SolidDodecahedron
            glTranslatef 4, 0, 0
            .WireDodecahedron
        Case 4
            glTranslatef -2, 0, 0
            .SolidIcosahedron
            glTranslatef 4, 0, 0
            .WireIcosahedron
        Case 5
            glTranslatef -2, 0, 0
            .SolidOctahedron
            glTranslatef 4, 0, 0
            .WireOctahedron
        Case 6:
            glTranslatef -2, 0, 0
            .SolidSphere 1, 16, 16
            glTranslatef 4, 0, 0
            .WireSphere 1, 16, 16
        Case 7
            glTranslatef -2, 0, 0
            .SolidTetrahedron
            glTranslatef 4, 0, 0
            .WireTetrahedron
        Case 8
            glTranslatef -2, 0, 0
            .SolidTorus 0.5, 1, 16, 16
            glTranslatef 4, 0, 0
            .WireTorus 0.5, 1, 16, 16
        Case 9
            glTranslatef -2, 0, 0
            .SolidCylinder 1, 1, 1, 16, 16
            glTranslatef 4, 0, 0
            .WireCylinder 1, 1, 1, 16, 16
    'GLE primitives
    'each primitive can be drawn from
    'a display list, or 'live' for animation
        Case 11
            'glCallList IDCylinder
            DrawCylinder
        Case 12
            'glCallList IDCone
            DrawCone
        Case 13 'extrusion
            DrawTexas
        Case 14 'twist ext
            'glCallList IDTwoid
            DrawTwoid
            'glCallList IDTwoid
            'DrawBeam
        Case 15 'super extr
            glCallList IDSuper
            'DrawSuper
        Case 16 'spiral
            glCallList IDArrow
            'DrawSpiral
        Case 17 'lathe
            'glCallList IDCandle
            DrawCandle
        Case 18 'helicoid
            'glCallList idhelix1
            DrawHelix 1
        Case 19 'toroid
            'glCallList idtoroid
            DrawToroid
        Case 20 'screw
            'glCallList idscrew
            DrawScrew
        Case 22
            DrawCylAndCones
        Case 23
            DrawExtrusions
        Case 24
            DrawSpirals
        Case 25
            DrawLathes
        Case 26
        'vrml
        Case 30
            .Box 5, 10, 8
        Case 31
            glTranslatef 0, 0, -5
            .Cone 3, 0, 5
        Case 32
            glTranslatef 0, 0, -5
            .Cylinder 2, 2, 8
        Case 33
            .Sphere 5
        End Select
        glPopMatrix
    End With
    '
    glPopMatrix
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    yRotation = yRotation + 5 Mod 360
    Case vbKeyRight:
    yRotation = yRotation - 5 Mod 360
    Case vbKeyUp:
    xRotation = xRotation + 5 Mod 360
    Case vbKeyDown:
    xRotation = xRotation - 5 Mod 360
    Case vbKeyPageUp:
    zTranslation = zTranslation + 1
    Case vbKeyPageDown:
    zTranslation = zTranslation - 1
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii%)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "X":    xRotation = xRotation + 5 Mod 360
    Case "x":    xRotation = xRotation - 5 Mod 360
    Case "Y":    yRotation = yRotation + 5 Mod 360
    Case "y":    yRotation = yRotation - 5 Mod 360
    Case "Z":    zRotation = zRotation + 5 Mod 360
    Case "z":    zRotation = zRotation - 5 Mod 360
    End Select
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      'm_bMoving = False
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
'    m_MouseX = x
'    m_MouseY = y
'    If Button = 0 Then
'        Exit Sub
'    ElseIf Button = 1 Then
'        If (m_bMoving) Then
'        End If
'    Else
'    End If
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    ' Rotate the scene with the left mouse button. */
'    If Button = 1 Then
'        m_bMoving = True
'        m_StartX = x
'        m_StartY = y
'    Else
'    End If
End Sub

' ======================================================= */
'there are four different join styles,
' and two different normal vector styles */
Public Property Get JoinStyle&()
    JoinStyle = m_JoinStyle
End Property

Public Property Let JoinStyle(msg&)
    m_JoinStyle = msg
    'recreate the lists
    m_CreateLists
End Property

' ======================================================= */
Public Property Get NormStyle&()
    NormStyle = m_NormStyle
End Property

Public Property Let NormStyle(msg&)
    m_NormStyle = msg
    'recreate the lists
    m_CreateLists
End Property

' ======================================================= */
Public Property Get MouseY() As Long
MouseY = m_MouseY
End Property

Public Property Get MouseX() As Long
MouseX = m_MouseX
End Property

' ======================================================= */
Public Property Get CurObject() As Long
CurObject = m_CurID
End Property

Public Property Let CurObject(ByVal NewValue As Long)
m_CurID = NewValue
If m_CurID >= 11 And m_CurID < 30 Then
    glDisable GL_NORMALIZE
Else
    glEnable GL_NORMALIZE
End If
If m_CurID < 11 Then
    glDisable GL_COLOR_MATERIAL
    ' set a nice color
    m_Mat.SetMaterial
Else
    glEnable GL_COLOR_MATERIAL
End If
End Property

' ======================================================= */
Public Property Get TextureEnabled() As Boolean
TextureEnabled = m_TextureEnabled
End Property

Public Property Let TextureEnabled(ByVal NewValue As Boolean)
If NewValue Then
    glEnable GL_TEXTURE_2D
    m_TextureEnabled = True
Else
    glDisable GL_TEXTURE_2D
    m_TextureEnabled = False
End If
m_CreateLists
End Property

Public Property Get TextureStyle&()
TextureStyle = m_TextureMode
End Property

Public Property Let TextureStyle(msg&)
With gCtl
    Select Case (msg)
    Case 1:
        m_TextureMode = GLE_TEXTURE_VERTEX_FLAT
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 0.1, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 2:
        m_TextureMode = GLE_TEXTURE_NORMAL_FLAT
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 0.1, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 3:
        m_TextureMode = GLE_TEXTURE_VERTEX_CYL
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 1#, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 4:
        m_TextureMode = GLE_TEXTURE_NORMAL_CYL
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 1#, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 5:
        m_TextureMode = GLE_TEXTURE_VERTEX_SPH
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glMatrixMode GL_MODELVIEW
    Case 6:
        m_TextureMode = GLE_TEXTURE_NORMAL_SPH
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glMatrixMode GL_MODELVIEW
    Case 7
        m_TextureMode = GLE_TEXTURE_VERTEX_MODEL_FLAT
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 0.1, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 8
        m_TextureMode = GLE_TEXTURE_NORMAL_MODEL_FLAT
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 0.1, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 9
        m_TextureMode = GLE_TEXTURE_VERTEX_MODEL_CYL
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 1#, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 10
        m_TextureMode = GLE_TEXTURE_NORMAL_MODEL_CYL
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glScalef 1#, 0.1, 1#
        glMatrixMode GL_MODELVIEW
    Case 11
        m_TextureMode = GLE_TEXTURE_VERTEX_MODEL_SPH
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glMatrixMode GL_MODELVIEW
    Case 12:
        m_TextureMode = GLE_TEXTURE_NORMAL_MODEL_SPH
        glMatrixMode GL_TEXTURE
        glLoadIdentity
        glMatrixMode GL_MODELVIEW
    End Select
End With
m_CreateLists
End Property

' ======================================================= */
Private Sub m_CreateTextures()
    'load the stock texture
    Set check_texture = gCtl.NewTexture
    check_texture.CreateCheckTexture
    Set current_texture = check_texture
End Sub

Public Property Let Texture(ByVal Index As Long)
Select Case Index
    Case 1:
        If check_texture Is Nothing Then
        End If
        Set current_texture = check_texture
    Case 2:
        If barberpole_texture Is Nothing Then
            m_CreateBarberpoleTexture
        End If
        Set current_texture = barberpole_texture
    Case 3:
        If wild_tooth_texture Is Nothing Then
            m_CreateWildToothTexture
        End If
        Set current_texture = wild_tooth_texture
    Case 4:
        If planet_texture Is Nothing Then
            'load a file
            Set planet_texture = gCtl.NewTexture
            With planet_texture
                'this makes the texture current
                .LoadTextureFile App.Path & "\stone040.bmp"
            End With
        End If
       Set current_texture = planet_texture
End Select
current_texture.SetTexture
End Property

' ======================================================= */
Private Sub m_CreateBarberpoleTexture()
Dim i&, j&, ID&
Dim pixmap(0 To TEXTURE_SIZE * TEXTURE_SIZE * 3 - 1) As Byte
   Set barberpole_texture = gCtl.NewTexture
    For i = 0 To TEXTURE_SIZE - 1
        For j = 0 To TEXTURE_SIZE - 1
            pixmap(3 * TEXTURE_SIZE * i + 3 * j) = 255 * ((i + j) / 32 Mod 2)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 1) = 255 * ((i + j) / 32 Mod 2)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 2) = 255 * ((i + j) / 32 Mod 2)
        Next
    Next
    barberpole_texture.SetData TEXTURE_SIZE, TEXTURE_SIZE, _
            3, GL_RGB, _
            UBound(pixmap) + 1, pixmap
End Sub

' ======================================================= */
Private Sub m_CreateWildToothTexture()
Dim i&, j&, ID&
Dim pixmap(0 To TEXTURE_SIZE * TEXTURE_SIZE * 3 - 1) As Byte
    Set wild_tooth_texture = gCtl.NewTexture
    For i = 0 To TEXTURE_SIZE - 1
        For j = 0 To TEXTURE_SIZE - 1
            pixmap(3 * TEXTURE_SIZE * i + 3 * j) = _
            255 * IIf((((((i + j) / 32) Mod 2) = (((i - j) / 32) Mod 2))), 1, 0)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 1) = _
            255 * IIf((((((i + j) / 32) Mod 2) = (((i - j) / 32) Mod 2))), 1, 0)
            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 2) = _
            255 * IIf((((((i + j) / 32) Mod 2) = (((i - j) / 32) Mod 2))), 1, 0)
        Next
    Next
    wild_tooth_texture.SetData TEXTURE_SIZE, TEXTURE_SIZE, _
            3, GL_RGB, _
            UBound(pixmap) + 1, pixmap
End Sub


' ======================================================= *
'Private Sub m_CreatePlanetTexture()
'Dim i&, j&, n#
'Dim pixmap() As Byte
'Dim mi&, mj&
'Dim r&, g&, b&
'   Set planet_texture = gCtl.NewTexture
'    n = TEXTURE_SIZE * TEXTURE_SIZE * 3 - 1
'    ReDim pixmap(0 To n) As Byte
'    For i = 0 To TEXTURE_SIZE - 1
'        For j = 0 To TEXTURE_SIZE - 1
'            mi = i - TEXTURE_SIZE / 2
'            mj = j - TEXTURE_SIZE / 2
'            '
'            r = (100 * mi * mi + ((40 * mj * mj) \ (2 ^ 8))) \ (2 ^ 16)
'            'Debug.Print Hex(r)
'            '
'            g = (10 * mi * mi + 4 * mj * mj) \ (2 ^ 16)
'            'Debug.Print Hex(g)
'            '
'            b = (1000 * mi * mi + 400 * mj * mj) \ (2 ^ 24)
'            'Debug.Print Hex(b)
'            '
'            pixmap(3 * TEXTURE_SIZE * i + 3 * j) = r
'            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 1) = g
'            pixmap(3 * TEXTURE_SIZE * i + 3 * j + 2) = b
'        Next
'    Next
'    With planet_texture.Image
'        .sizeX = TEXTURE_SIZE
'        .sizeY = TEXTURE_SIZE
'        .SetData VarPtr(pixmap(0)), TEXTURE_SIZE * TEXTURE_SIZE * 3
'        .Components = 3
'        .Format = GL_RGB
'    End With
'End Sub


