VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.1#0"; "Comdlg32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmDialog 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Form1"
   ClientHeight    =   3270
   ClientLeft      =   825
   ClientTop       =   1980
   ClientWidth     =   5940
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3270
   ScaleWidth      =   5940
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton btnTexture 
      Caption         =   "Texture..."
      Height          =   375
      Left            =   4500
      TabIndex        =   12
      Top             =   1260
      Width           =   1320
   End
   Begin VB.CommandButton btnCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   4500
      TabIndex        =   11
      Top             =   720
      Width           =   1320
   End
   Begin VB.CommandButton btnOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   4500
      TabIndex        =   0
      Top             =   225
      Width           =   1320
   End
   Begin VB.Frame Frame4 
      Caption         =   "Size"
      Height          =   1005
      Left            =   3060
      TabIndex        =   6
      Top             =   2115
      Width           =   2760
      Begin msComctlLib.Slider slSize 
         Height          =   375
         Left            =   135
         TabIndex        =   8
         Top             =   540
         Width           =   2490
         _ExtentX        =   4392
         _ExtentY        =   661
         _Version        =   327682
         LargeChange     =   10
         SmallChange     =   5
         Max             =   100
         SelStart        =   50
         TickStyle       =   3
         Value           =   50
      End
      Begin VB.Label Label5 
         Caption         =   "Max"
         Height          =   240
         Left            =   2115
         TabIndex        =   16
         Top             =   270
         Width           =   420
      End
      Begin VB.Label Label4 
         Caption         =   "Min"
         Height          =   195
         Left            =   225
         TabIndex        =   15
         Top             =   270
         Width           =   555
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "Resolution"
      Height          =   1005
      Left            =   90
      TabIndex        =   5
      Top             =   2115
      Width           =   2805
      Begin msComctlLib.Slider slRes 
         Height          =   375
         Left            =   135
         TabIndex        =   7
         Top             =   540
         Width           =   2490
         _ExtentX        =   4392
         _ExtentY        =   661
         _Version        =   327682
         LargeChange     =   10
         SmallChange     =   5
         Max             =   200
         SelStart        =   50
         TickStyle       =   3
         Value           =   50
      End
      Begin VB.Label Label3 
         Caption         =   "Max"
         Height          =   240
         Left            =   2115
         TabIndex        =   14
         Top             =   270
         Width           =   420
      End
      Begin VB.Label Label2 
         Caption         =   "Min"
         Height          =   195
         Left            =   225
         TabIndex        =   13
         Top             =   270
         Width           =   555
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Color Usage"
      Height          =   735
      Left            =   90
      TabIndex        =   4
      Top             =   1260
      Width           =   4245
      Begin VB.CheckBox optSmooth 
         Caption         =   "Smooth shading"
         Height          =   330
         Left            =   2295
         TabIndex        =   10
         Top             =   270
         Value           =   1  'Checked
         Width           =   1815
      End
      Begin VB.CheckBox optCycle 
         Caption         =   "Color-cycling"
         Height          =   285
         Left            =   495
         TabIndex        =   9
         Top             =   315
         Value           =   1  'Checked
         Width           =   1545
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Object"
      Height          =   1095
      Left            =   90
      TabIndex        =   1
      Top             =   90
      Width           =   4245
      Begin VB.ComboBox cmbStyle 
         Height          =   315
         Left            =   1485
         TabIndex        =   3
         Text            =   "Combo1"
         Top             =   540
         Width           =   2400
      End
      Begin VB.Label Label1 
         Alignment       =   1  'Right Justify
         Caption         =   "Style:"
         Height          =   285
         Left            =   450
         TabIndex        =   2
         Top             =   585
         Width           =   825
      End
   End
   Begin MSComDlg.CommonDialog CD 
      Left            =   5040
      Top             =   270
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   327681
      CancelError     =   -1  'True
   End
End
Attribute VB_Name = "frmDialog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public OK As Boolean
Dim m_Tex$

Private Sub btnCancel_Click()
Hide
End Sub

Private Sub btnOK_Click()
optType = cmbStyle.ListIndex + 1
optSmoothShading = IIf(optSmooth.value, True, False)
optColorCycle = IIf(optCycle.value, True, False)
optSize = slSize.value
optTesselFact = slRes.value / 100
optTextureFile = m_Tex
SaveIniSettings
OK = True
Hide
End Sub

Private Sub btnTexture_Click()
m_Tex = GetTextureFile
End Sub

Private Sub Form_Load()
GetIniSettings
m_Tex = optTextureFile
optCycle.value = IIf(optColorCycle, 1, 0)
optSmooth.value = IIf(optSmoothShading, 1, 0)
slSize.value = optSize
slRes.value = optTesselFact * 100
With cmbStyle
    .AddItem "Explode"
    .AddItem "Drop"
    .AddItem "Strip"
    .AddItem "Textured Flag"
'    .AddItem "Lem"
'    .AddItem "Win"
    .ListIndex = optType - 1
End With
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode = 0 Then
    Hide
    Cancel = True
End If
End Sub
