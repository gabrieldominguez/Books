Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CXXX
'
Public Const PI = 3.141592654
Public Const FLOAT_MAX = 3.402823466E+38
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type
Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (Dest As Byte, Src As Byte, ByVal length&)

'----------------------------------------------------------------------------
Public Sub Main()
Set gCtl = frmMain.glxCtl1
Set CX = New CXXX
gCtl.Init
frmMain.Show
'this enables a VB timer to fire Paint events:
'gCtl.Animate = True
End Sub

'----------------------------------------------------------------------------
Public Sub CheckError()
Dim s$
    Do
        s = gCtl.GetErr
        If Len(s) Then
            Debug.Print s
            Debug.Assert 0
        Else: Exit Sub
        End If
    Loop
End Sub

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(A() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(A!(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(A&(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(A() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        A(i).p(0) = n(j)
        A(i).p(1) = n(j + 1)
        A(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(A() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        A(i, j).p(0) = n(cnt)
        A(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

Public Function Max(A, b)
Max = IIf(A > b, A, b)
End Function

Public Function Min(A, b)
Min = IIf(A < b, A, b)
End Function

'------------------------------------------------------------
Public Function ULong(lng&) As Double
On Error GoTo EH
    If lng < 0 Then
        ULong = 2147483648# + 2147483648# + lng
    Else
        ULong = lng
    End If
    Exit Function
EH:
    Debug.Assert 0
    Resume Next
End Function


