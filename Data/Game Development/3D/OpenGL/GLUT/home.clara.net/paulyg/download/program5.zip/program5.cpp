/*
*  Program 5, Use lighting and a GLUsphere.
*  Read in real .tga images!
*
*/

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>

#include "tgaload.h"

#define MAX_NO_TEXTURES 2

#define EARTH_TEXTURE   0
#define CLOUD_TEXTURE   1

GLuint  texture_id [MAX_NO_TEXTURES];

// Angles here
float angle, angle2, cloud_rot;
float zoom = -4.0;

int moving, startx, starty;

GLfloat  ambient_light[] = { 0.2, 0.2, 0.2, 1.0 };
GLfloat   source_light[] = { 0.9, 0.8, 0.8, 1.0 };
GLfloat      light_pos[] = { 7.0, 0.0, 3.0, 1.0 };


void init ( void )
{
   // Set up simple lighting model
   glEnable       ( GL_LIGHTING );
   glLightModelfv ( GL_LIGHT_MODEL_AMBIENT, ambient_light );
   glLightfv      ( GL_LIGHT0, GL_DIFFUSE,  source_light  );
   glLightfv      ( GL_LIGHT0, GL_POSITION, light_pos     );
   glEnable       ( GL_LIGHT0 );

   // Enable material properties for lighting
   glEnable ( GL_COLOR_MATERIAL );
   glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );

   glEnable      ( GL_TEXTURE_2D );
   glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
   glGenTextures ( 2, texture_id );

   texture_id [ EARTH_TEXTURE ] = tgaLoadAndBind ( "earth.tga",  TGA_LOW_QUALITY );
   texture_id [ CLOUD_TEXTURE ] = tgaLoadAndBind ( "clouds.tga", TGA_LUMINANCE | TGA_LOW_QUALITY );

/*	image_t   temp_image;

   glBindTexture ( GL_TEXTURE_2D, texture_id[EARTH_TEXTURE] );
   tgaLoad  ( "earth.tga", &temp_image, TGA_FREE | TGA_LOW_QUALITY );

   glBindTexture ( GL_TEXTURE_2D, texture_id[CLOUD_TEXTURE] );
   tgaLoad  ( "clouds.tga", &temp_image, TGA_FREE | TGA_LUMINANCE | TGA_LOW_QUALITY ); */

   glEnable ( GL_BLEND );
   glEnable ( GL_CULL_FACE );

   glBlendFunc ( GL_ONE, GL_ONE );

   glClearColor ( 0.0, 0.0, 0.0, 0.0 );
}




void draw_sphere ( int tex_id )
{
   glPushMatrix  ( );
   glRotatef     ( -90.0, 1.0, 0.0, 0.0 );
   glColor4f     ( 1.0, 1.0, 1.0, 1.0  );
   glBindTexture ( GL_TEXTURE_2D, texture_id[tex_id] );
   GLUquadricObj*  q = gluNewQuadric ( );
   gluQuadricDrawStyle ( q, GLU_FILL   );
   gluQuadricNormals   ( q, GLU_SMOOTH );
   gluQuadricTexture   ( q, GL_TRUE    );
   gluSphere ( q, 1.0, 20, 20 );
   gluDeleteQuadric ( q );
   glPopMatrix ( );
}

void display ( void )
{
   glClear      ( GL_COLOR_BUFFER_BIT );
   glLightfv    ( GL_LIGHT0, GL_POSITION, light_pos );
   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, zoom );
   glRotatef ( angle2, 1.0, 0.0, 0.0 );
   glRotatef ( angle, 0.0, 1.0, 0.0  );
   glDisable ( GL_BLEND );
   draw_sphere ( EARTH_TEXTURE );
   glRotatef   ( cloud_rot, 0.0, 1.0, 0.0 );
   glEnable    ( GL_BLEND );
   draw_sphere ( CLOUD_TEXTURE );
   glPopMatrix ( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{
   glViewport   ( 0, 0, (GLint) w, (GLint) h );
   glMatrixMode ( GL_PROJECTION);
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, (GLdouble)w, 1.0, 100.0 );
   else 
      gluPerspective ( 45, (GLdouble)w/(GLdouble)h, 1.0, 100.0 );
   glMatrixMode ( GL_MODELVIEW );
   glLoadIdentity ( );
}

void mouse ( int button, int state, int x, int y )
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {
      moving = 1;
      startx = x;
      starty = y;
   }
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      moving = 0;

   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
   {
      moving = 2;
      starty = y;
   }
   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_UP )
      moving = 0;
}

void motion ( int x, int y )
{
   if ( moving == 1 )
   {
      angle = angle + (x - startx);
      angle2 = angle2 + (y - starty);
      startx = x;
      starty = y;
      glutPostRedisplay ( );
   }
   if ( moving == 2 )
   {
      zoom = (zoom + ((y - starty) * 0.1));
      starty = y;
      glutPostRedisplay ( );
   }
}

void idle_func ( void )
{
   angle = angle + 0.05;
   if ( angle == 360 )
      angle = 0;

   cloud_rot = cloud_rot + 0.1;
   if ( cloud_rot == 360 )
      cloud_rot = 0;
   glutPostRedisplay();
}

#pragma argsused
void keyboard ( unsigned char key, int x, int y )
{
   int i;

   switch ( key )
   {
      case 27:
         exit ( 0 );
      break;

      case 'l':
         for ( i = 0; i <= MAX_NO_TEXTURES; i++ )
         {
            glBindTexture   ( GL_TEXTURE_2D, texture_id[i] );
            tgaSetTexParams ( GL_LINEAR, GL_LINEAR, GL_MODULATE );
         }
      break;

      case 'n':
         for (i=0; i<=MAX_NO_TEXTURES; i++)
         {
            glBindTexture   ( GL_TEXTURE_2D, texture_id[i] );
            tgaSetTexParams ( GL_NEAREST, GL_NEAREST, GL_MODULATE );
         }
      break;

      case 'f':
         glutFullScreen ( );
      break;

      case 'w':
         glutReshapeWindow ( 500,500 );
      break;

      default:
      break;
   }
}

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGBA display mode, and handle input events.
 */
int main ( int argc, char** argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( argv[0] );

   init ( );

   glutReshapeFunc  ( reshape   );
   glutMouseFunc    ( mouse     );
   glutMotionFunc   ( motion    );
   glutKeyboardFunc ( keyboard  );
   glutDisplayFunc  ( display   );
   glutIdleFunc     ( idle_func );
   glutMainLoop ( );

   return 0;
}
