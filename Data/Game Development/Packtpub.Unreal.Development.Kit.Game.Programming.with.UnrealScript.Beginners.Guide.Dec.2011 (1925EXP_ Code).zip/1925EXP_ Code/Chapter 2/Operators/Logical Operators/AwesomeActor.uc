class AwesomeActor extends Actor
    placeable;

var bool bRaining;
var float CurrentMoney, RequiredMoney;
var string Day, Month;

function PostBeginPlay()
{
    `log(!bRaining && CurrentMoney > RequiredMoney);
    `log(Day == "Tuesday" || Day == "Thursday");
    `log(Day == "Tuesday" ^^ Month == "January");
}

defaultproperties
{
    CurrentMoney=20.0
    RequiredMoney=15.0

    Day="Tuesday"
    Month="January"

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
