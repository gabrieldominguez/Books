VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'----------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net, Feb 99
'HISTORY: -
'NOTES: This template uses an offscreen memDC. It enables this in
'   "Init". When InitGL is called, it can get the hDC of the ocx,
'   which will be the offscreen dc.
'
'   -You can use this template to create a 'normal' gl app with
'       camera navigation functions by simply commenting out the
'       code in 'Init'. In this case, DrawGDI will never be called
'       and the you can't draw on top of the gl rendering.
'
'   -I'm still working on the object manipulation code, so you can't
'       move things yet
'   -Orbit isn't implemented
'
'   - Nodes: a collection of top-level objects.
'   - Node: an integral object which has a transform.
'
'   - A Node can be a mesh - like a kick-boxer - or it can be the arm,
'       fist, torso, leg, etc., of same, existing as a child of a encompassing
'       Node. A Node is a site for a transform of some kind.
'----------------------------------------------------------------

Public Enum GLEditStates
    STATE_SELECT = 1
    'objects
    STATE_MOVE = 2
    STATE_ROTATE = 3
    STATE_ARCROTATE = 4
    STATE_SCALE = 5
    'view
    STATE_ZOOM = 6
    STATE_DOLLY = 7
    STATE_PAN = 8
    STATE_ORBIT = 9
    STATE_PITCH = 10
    STATE_YAW = 11
    STATE_ROLL = 12
End Enum
Public Enum GLViews
    GLVIEW_PERSPECTIVE = 0
    GLVIEW_FRONT = 1
    GLVIEW_TOP = 2
    GLVIEW_RIGHT = 3
    GLVIEW_LEFT = 4
    GLVIEW_BACK = 5
    GLVIEW_BOTTOM = 6
End Enum
'----------------------------------------------------------------
Dim m_GLEditState As GLEditStates
Dim m_View As GLViews
'----------------------------------------------------------------
Dim m_bTexture As Boolean 'flag to enable use of textures
Dim m_bDragging As Boolean 'flag for mouse drag
Dim m_Grids As Boolean 'flag for drawing grids
Dim m_MouseX&, m_MouseY& 'current mouse pos
Dim m_StartX&, m_StartY& 'mouse down pos
Dim m_StartDX!, m_StartDY! 'a calculated value of mouse pos,
Dim m_hDC& 'this template uses an offscreen buffer
Dim m_Width&, m_Height&  'ocx window size
Dim m_Cam As Boolean 'flag for drawing the camera's icon
'----------------------------------------------------------------
Dim m_MatCyan As glxMaterial 'test material
Dim m_MatRed As glxMaterial
Dim m_MatBlue As glxMaterial
Dim m_MatGreen As glxMaterial
Dim m_MatWhite As glxMaterial

Private Sub Class_Initialize()
'
End Sub

Private Sub Class_Terminate()
    Set Nodes = Nothing
    'Set Manipulator = Nothing
    If QuadObj Then gluDeleteQuadric QuadObj
End Sub

Public Sub Init()
    gCtl.UseMemDC = True
End Sub

Public Sub InitGL()
Dim Node As CNode
Dim Node2 As CNode
Dim h!
    glClearColor 0.3, 0.3, 0.3, 0 'off-black so we can see goofs
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Camera
'        .FarPlane = 100
'        .NearPlane = 0.01
'        .FieldOfView = 45
        .SetEyePos 3, 2, 10
'        .SetTargetPos 0, 0, 0
    End With
    'create a new material
    Set m_MatBlue = gCtl.NewMaterial
    With m_MatBlue
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.3, 0.3, 0.7
        .SetSpecular 0.6, 0.6, 0.6
        .SpecExp = 60
    End With
    'use existing mat's in ocx
    With gCtl.Materials
        Set m_MatRed = .GetMaterialIndex(RED_PLASTIC)
        Set m_MatCyan = .GetMaterialIndex(CYAN_PLASTIC)
        Set m_MatGreen = .GetMaterialIndex(GREEN_PLASTIC)
        Set m_MatWhite = .GetMaterialIndex(WHITE_PLASTIC)
    End With
    
    With gCtl
        '.Trackball.Button = 1
        .MouseRotate = True 'for debugging, till I get a trackball in the camera
        .Grid = glxGridX
        .SetWorldSize 20, 20, 20
        .Axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
    '
    QuadObj = gluNewQuadric
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    '
    m_hDC = gCtl.hDC 'this will be the memDC the ocx is using
    '
    'Set Manipulator = New CManipulator
'    With Node
'        Set .Material = m_MatCyan
'        .SetTranslation 1, 3, -10
'        .SetRotation 90, 1, 0, 0
'    End With
    '----------------------------------------------------------------
    Set Nodes = New CNodes
        Set Node = Nodes.Add("", Nothing)
        With Node
            Set .Material = m_MatBlue
            .SetTranslation 0, 0, 10
            .SetScale 0.3, 0.3, 0.3
        End With
        Set Node = Nodes.Add("", Nothing)
        With Node
            Set .Material = m_MatRed
            .SetTranslation 10, 0, 0
            .SetScale 0.3, 0.3, 0.3
        End With
        Set Node = Nodes.Add("", Nothing)
        With Node
            Set .Material = m_MatGreen
            .SetTranslation 0, 10, 0
            .SetScale 0.3, 0.3, 0.3
        End With
        Set Node = Nodes.Add("", Nothing)
        With Node
            Set .Material = m_MatCyan
            .SetTranslation 0, 0, 0
            .SetScale 0.3, 0.3, 0.3
        End With
        Set Node2 = Nodes.Add("", Node)
        With Node2
            'Set .Material = m_MatWhite
            .SetRotation 90, 0, 1, 0
            .SetTranslation -1.5, 0, 0
            .SetScale 0.1, 0.1, 3
            .Geometry = geoCylinder
        End With
    '----------------------------------------------------------------
    m_GLEditState = STATE_SELECT
End Sub

'----------------------------------------------------------------
Public Sub Draw()
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    'draw our app's geometry
    Nodes.Draw
    'the following is testing the glxCamera
    If m_Cam Then
        gCtl.Camera.Draw
    End If
    '
    CheckError
End Sub

'----------------------------------------------------------------
'don't do anything here if you're not using a memDC!!!
'----------------------------------------------------------------
Public Sub DrawGDI()
Dim s$
    s = "Perspective"
    'do drawing here. Either call GDI directly or
    'use a utility routine in the ocx.
    'GDI:
    'TextOut m_hDC, 8, 5, s, Len(s)
    'use ocx utility routine:
    With gCtl
        .GDIText 8, 5, s
    End With
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
    m_Width = width
    m_Height = height
End Function

'----------------------------------------------------------------
Public Sub KeyDown(KeyCode%, Shift%)
'With gCtl.Camera
'    Select Case (KeyCode)
'    Case vbKeyLeft:
'        If Shift = 0 Then
'            .Azimuth 10
'        Else
'            .Yaw 10
'        End If
'    Case vbKeyRight:
'        If Shift = 0 Then
'            .Azimuth -10
'        Else
'            .Yaw -10
'        End If
'    Case vbKeyUp:
'        If Shift = 0 Then
'            .Elevation 10
'        Else
'            .Pitch 10
'        End If
'    Case vbKeyDown:
'        If Shift = 0 Then
'            .Elevation -10
'        Else
'            .Pitch -10
'        End If
'    Case vbKeyAdd
'        If Shift = 0 Then
'            .Dolly 1.1
'        Else
'            .Roll 10
'        End If
'    Case vbKeySubtract
'        If Shift = 0 Then
'            .Dolly 0.9
'        Else
'            .Roll -10
'        End If
'    Case 27:
'        Unload frmMain
'        Exit Sub
'    Case Else: Exit Sub
'    End Select
'    gCtl.Render
'End With
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

'----------------------------------------------------------------
Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim dx!, dy!
    m_MouseX = x
    m_MouseY = y
    Select Case Button
    Case 0: Exit Sub
    Case 1 'Left
        m_bDragging = True
        m_StartX = x
        m_StartY = y
        dx = 2 * m_MouseX / m_Width - 1
        dy = 2 * (m_Height - m_MouseY) / m_Height - 1
        m_StartDX = dx
        m_StartDY = dy
        'Manipulator.MouseDown dx, dy
    Case 2 'Right
    Case 4 'Middle
    End Select
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim dx!, dy!, inc!
Dim tx!, ty!
    Select Case Button
    Case 0: Exit Sub
    Case 1 'Left
        With gCtl.Camera
            dx = 2 * m_MouseX / m_Width - 1
            dy = 2 * (m_Height - m_MouseY) / m_Height - 1
            'Debug.Print "dx:" & dx
            'Debug.Print "dy:" & dy
            Select Case EditState
            Case STATE_SELECT:
            'manipulate the model
            Case STATE_MOVE, STATE_ROTATE, STATE_ARCROTATE, STATE_SCALE: 'scale_ X, Y
                'Manipulator.MouseMove dx, dy
            'manipulate view
            Case STATE_ZOOM:
                If y > m_MouseY Then
                    .Zoom 0.95
                ElseIf y < m_MouseY Then
                    .Zoom 1.05
                End If
            Case STATE_DOLLY
                If y > m_MouseY Then
                    .TranslateZ -0.5 '0.95
                ElseIf y < m_MouseY Then
                    .TranslateZ 0.5 '1.05
                End If
            Case STATE_PAN:
                dx = x - m_MouseX
                dy = y - m_MouseY
                dx = dx * 0.03 'm_Zoom / 50
                dy = dy * 0.03 'm_Zoom / 50
                .Pan dx, -dy
            Case STATE_ORBIT
                If Shift = 0 Then
                    '.Azimuth X - m_MouseX
                Else
                    '.Orbit m_StartDX, m_StartDY, dx, dy
                End If
            Case STATE_PITCH:
                .RotateX y - m_MouseY
            Case STATE_YAW:
                .RotateY x - m_MouseX
            Case STATE_ROLL:
                tx = dx - m_StartDX
                ty = dy - m_StartDY
                inc = Atan2(tx, ty)
                If dx < 0 Then inc = -inc
                'Debug.Print "Roll inc2:" & inc
                .RotateZ inc
            Case Else: Debug.Assert 0
            End Select
        m_StartDX = dx
        m_StartDY = dy
        End With
    Case 2 'Right
    Case 4 'Middle
    End Select
    m_MouseX = x
    m_MouseY = y
    gCtl.Render
End Sub

'----------------------------------------------------------------
Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Select Case Button
    Case 0: Exit Sub
    Case 1 'Left
        'If m_bDragging Then Manipulator.MouseUp
    Case 2 'Right
    Case 4 'Middle
    End Select
    m_bDragging = False
End Sub

'----------------------------------------------------------------
Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, z#, z1#, z2#
    'ocx returns right clicks
    If Not m_bDragging Then Exit Sub
    z = FLOAT_MAX
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                z1 = ULong(items(ptr))
                Debug.Print " z1 = " & z1
                ptr = ptr + 1
            '3.z2
                z2 = ULong(items(ptr))
                Debug.Print " z2 = " & z2
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < z Then
                        z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'If Not Manipulator.OnPick(Picked) Then
            Nodes.OnPick Picked
        'End If
    End If
End Sub

'------------------------------------------------------------
Public Property Get EditState() As GLEditStates
    EditState = m_GLEditState
End Property

Public Property Let EditState(ByVal NewValue As GLEditStates)
    m_GLEditState = NewValue
    Select Case m_GLEditState
    Case STATE_SELECT: SetCursor 0
    Case STATE_MOVE: SetCursor CURSOR_MOVE
    Case STATE_ROTATE: SetCursor CURSOR_ROTATE
    Case STATE_ARCROTATE: SetCursor CURSOR_ARCROTATE
    Case STATE_SCALE: SetCursor CURSOR_SCALE
    Case STATE_ZOOM: SetCursor CURSOR_ZOOM
    Case STATE_DOLLY: SetCursor CURSOR_DOLLY
    Case STATE_PAN: SetCursor CURSOR_PAN
    Case STATE_ORBIT: SetCursor CURSOR_ORBIT
    Case STATE_PITCH: SetCursor CURSOR_PITCH
    Case STATE_YAW: SetCursor CURSOR_YAW
    Case STATE_ROLL: SetCursor CURSOR_ROLL
    Case Else: Debug.Assert 0
    End Select
End Property

'------------------------------------------------------------
Public Property Get Grids() As Boolean
    Grids = m_Grids
End Property

Public Property Let Grids(ByVal NewValue As Boolean)
    m_Grids = NewValue
End Property

'------------------------------------------------------------
Public Property Get DrawCamera() As Boolean
    DrawCamera = m_Cam
End Property

Public Property Let DrawCamera(ByVal NewValue As Boolean)
    m_Cam = NewValue
End Property

'------------------------------------------------------------
'the ocx has some cursors - ID => 200
Public Sub SetCursor(ByVal ID As glxCursors, Optional Img As Picture)
    With gCtl
    Select Case ID
    Case CURSOR_ZOOM, CURSOR_PAN, CURSOR_DOLLY, CURSOR_ARCROTATE, _
        CURSOR_PITCH, CURSOR_YAW, CURSOR_ROLL, CURSOR_MOVE, _
        CURSOR_ROTATE, CURSOR_SCALE, CURSOR_ORBIT
        .MousePointer = ID
    Case 99
        .MousePointer = 99
        Set .MouseIcon = Img
    Case Else
        If ID > 15 Or ID < 0 Then
            Debug.Assert 0
            ID = 0
        End If
        .MousePointer = ID
    End Select
    End With
End Sub

