class AwesomeGame extends UTDeathmatch;

var int EnemiesLeft;
var array<AwesomeEnemySpawner> EnemySpawners;

var float MinSpawnerDistance, MaxSpawnerDistance;

var bool bSpawnBoss;

simulated function PostBeginPlay()
{
    local AwesomeEnemySpawner ES;

    super.PostBeginPlay();

    GoalScore = 1;

    foreach DynamicActors(class'AwesomeEnemySpawner', ES)
        EnemySpawners[EnemySpawners.length] = ES;

    SetTimer(5.0, false, 'ActivateSpawners');
}

function ActivateSpawners()
{
    local int i;
    local array<AwesomeEnemySpawner> InRangeSpawners;
    local AwesomePlayerController PC;

    foreach LocalPlayerControllers(class'AwesomePlayerController', PC)
        break;
    if(PC.Pawn == none)
    {
        SetTimer(1.0, false, 'ActivateSpawners');
        return;
    }

    for(i=0; i<EnemySpawners.length; i++)
    {
        if(VSize(PC.Pawn.Location - EnemySpawners[i].Location) > MinSpawnerDistance && VSize(PC.Pawn.Location - EnemySpawners[i].Location) < MaxSpawnerDistance)
        {
            if(EnemySpawners[i].CanSpawnEnemy())
                InRangeSpawners[InRangeSpawners.length] = EnemySpawners[i];
        }
    }

    if(InRangeSpawners.length == 0)
    {
        `log("No enemy spawners within range!");
        SetTimer(1.0, false, 'ActivateSpawners');
        return;
    }

    if(bSpawnBoss)
        InRangeSpawners[Rand(InRangeSpawners.length)].SpawnBoss();
    else
    {
        InRangeSpawners[Rand(InRangeSpawners.length)].SpawnEnemy();
        SetTimer(1.0 + FRand() * 3.0, false, 'ActivateSpawners');
    }
}

function EnemyKilled()
{
    local int i;

    EnemiesLeft--;
    if(EnemiesLeft <= 0)
    {
        for(i=0; i<EnemySpawners.length; i++)
            EnemySpawners[i].MakeEnemyRunAway();
        ClearTimer('ActivateSpawners');
        bSpawnBoss = true;
        ActivateSpawners();
    }
}

function ScoreObjective(PlayerReplicationInfo Scorer, Int Score)
{
    super.ScoreObjective(Scorer, Score);
}

defaultproperties
{
    MinSpawnerDistance=1700.0
    MaxSpawnerDistance=3000.0
    EnemiesLeft=10
    bScoreDeaths=false
    PlayerControllerClass=class'AwesomeGame.AwesomePlayerController'
    DefaultPawnClass=class'AwesomeGame.AwesomePawn'
    DefaultInventory(0)=None
}
