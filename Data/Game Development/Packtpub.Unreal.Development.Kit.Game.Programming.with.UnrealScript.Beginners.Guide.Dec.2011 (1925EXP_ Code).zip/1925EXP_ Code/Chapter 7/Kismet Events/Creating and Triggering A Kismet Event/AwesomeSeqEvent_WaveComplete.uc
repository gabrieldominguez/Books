class AwesomeSeqEvent_WaveComplete extends SequenceEvent;

defaultproperties
{
    ObjName="Wave Complete"
    ObjCategory="Awesome Game"
    VariableLinks.Empty
    bPlayerOnly=false
}
