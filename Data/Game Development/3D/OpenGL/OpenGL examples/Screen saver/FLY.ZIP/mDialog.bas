Attribute VB_Name = "mDialog"
Option Explicit

Private Sub m_Init()
    ' set some default values
    optColorCycle = True
    optSmoothShading = True
    optSize = 100
    optTesselFact = 100
    optType = 1
    optTextureFile = ""
End Sub


'/******************************Public*Routine*****************************
'* getIniSettings
'* Get the screen saver configuration options from .INI file/registry.
'\*************************************************************************
Public Sub GetIniSettings()
Dim Settings, i&
Dim iPos&
'
' Initialize the global settings
m_Init
Settings = GetAllSettings(regAppName, regSection)
If Not IsEmpty(Settings) Then
For i = LBound(Settings, 1) To UBound(Settings, 1)
    Select Case Settings(i, 0)
    Case regColorCycle '
        optColorCycle = Settings(i, 1)
    Case regSmoothshading
        optSmoothShading = Settings(i, 1)
    Case regTessFactor
        optTesselFact = Settings(i, 1)
        'gCtl.ClampToRange2 iPos, 0, 200
        'optTesselFact = iPos / 100
    Case regSize
        optSize = Settings(i, 1)
    Case regType
        optType = Settings(i, 1)
    Case regTextureFile
        optTextureFile = Settings(i, 1)
    End Select
Next
End If
End Sub


'/******************************Public*Routine*****************************
'* saveIniSettings
'* Save the screen saver configuration option to the .INI file/registry.
'\*************************************************************************
Public Sub SaveIniSettings()
    SaveSetting regAppName, regSection, regColorCycle, optColorCycle
    SaveSetting regAppName, regSection, regSmoothshading, optSmoothShading
    SaveSetting regAppName, regSection, regTessFactor, optTesselFact
    SaveSetting regAppName, regSection, regSize, optSize
    SaveSetting regAppName, regSection, regType, optType
    SaveSetting regAppName, regSection, regTextureFile, optTextureFile
End Sub

Public Function GetTextureFile$()
    On Error Resume Next
    With frmDialog
        .CD.Filter = "Image files|*.bmp;*.jpg;*.jpeg;*.gif;*.dib|All files|*.*"
        .CD.FilterIndex = 1
        .CD.flags = cdlOFNFileMustExist
        .CD.ShowOpen
        If Err = cdlCancel Then Exit Function
        GetTextureFile$ = .CD.FileName
    End With
End Function

Public Function DoConfigure()
    frmDialog.Show vbModal
    DoConfigure = frmDialog.OK
    Unload frmDialog
End Function

Public Function GetFile$()
    On Error Resume Next
    With frmDialog
        .CD.Filter = "Text files|*.txt|All files|*.*"
        .CD.FilterIndex = 1
        .CD.flags = cdlOFNFileMustExist
        .CD.ShowOpen
        If Err = cdlCancel Then Exit Function
        GetFile$ = .CD.FileName
    End With
End Function

