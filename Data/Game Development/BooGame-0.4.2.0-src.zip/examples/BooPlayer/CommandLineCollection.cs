/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;

namespace BooPlayer
{
    /// <summary>
    /// Used to interpret a set of command line arguments.
    /// </summary>
    public class CommandLineCollection : IEnumerable
    {
        private string[] m_RawArguments;

        private Hashtable m_Arguments = new Hashtable();
        public Hashtable Arguments { get { return m_Arguments; } }

        public CommandLineCollection(string[] args)
        {
            m_RawArguments = args;
            if (args.Length < 1)
                return;

            int idx = 0;
            string arg = null, lastArg = null;

            while (idx < args.Length)
            {
                arg = args[idx];

                if (arg.Length > 2 && arg[0] == '/')
                {
                    arg = arg.Substring(1);
                    lastArg = arg;
                    m_Arguments[arg] = "";
                }
                else
                {
                    if (lastArg != null)
                    {
                        m_Arguments[lastArg] = arg;
                        lastArg = null;
                    }
                }
                idx++;
            }
        }

        public bool WasPassed(string argument)
        {
            return m_Arguments.ContainsKey(argument);
        }

        public string this[int index]
        {
            get
            {
                if (m_RawArguments.Length > index)
                    return (string)m_RawArguments[index];
                else
                    return null;
            }
        }

        public string this[string index]
        {
            get
            {
                if (WasPassed(index))
                    return (string)(m_Arguments[index]);
                else
                    return null;
            }
        }
        public IEnumerator GetEnumerator()
        {
            return m_Arguments.Keys.GetEnumerator();
        }
    }
}
