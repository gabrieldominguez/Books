<%@ Page Language="c#" Debug="true" Explicit="True" %>

<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Drawing" %>
<%@ Import Namespace="System.Web.Mail" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="Microsoft.CSharp" %>
<%@ Import Namespace="System.Drawing.Imaging" %>
<%@ Import Namespace="System.CodeDom.Compiler" %>
<%@ Import Namespace="System.Reflection" %>
<%@ Import Namespace="System.Collections" %>

<script language="C#" runat="server">

    private void Page_Load(object sender, System.EventArgs e)
    {
    }

</script>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Ray Tracing</title>
</head>
<!--#include file="~/scripts.aspx"-->
<body style="padding-right: 0px; padding-left: 0px; padding-bottom: 0px; margin: 0px;
    padding-top: 0px; text-align: left;">
    <form id="form1" runat="server">
        <!--#include file="~/template2.aspx"-->

<!----------------------------- Article Starts ----------------------------->


<p><a title="Basic ray tracing part II" href="http://www.simsysbr.com/articles/raytracing/raytracingappIII.zip">download source</a></p>

<p><a title="Basic ray tracing" href="http://www.simsysbr.com/articles/raytracing/raytracingappIII.aspx">see sample</a></p>

<p />

<p>
<table class=" htmtableborders" style="WIDTH: 100%" cellspacing="1" cellpadding="1" border="1">
<tbody>
<tr>
<td colspan="3">
<p align="center">
        <img height="200" alt="Screenshot - raytracingX.png" src="http://www.simsysbr.com/articles/raytracing/raytracingXVI.aspx" width="200" /><br />
    &nbsp;</p>
</td>
    <td align="center" colspan="1" valign="top">
        <img height="200" alt="Screenshot - raytracingX.png" src="http://www.simsysbr.com/articles/raytracing/raytracingXV.aspx" width="200" />&nbsp;<br />
        </td>
</tr>
</tbody>
</table>
</p>

<h2 style="text-align: left">Introduction</h2>

<p style="text-align: left">Previously we have seem ray tracing and mapping in spheres and &nbsp;triangles with
    simple illumination model, now we will extend this with reflections and refractions.
</p>

<h2 style="text-align: left">Background</h2>

<p style="text-align: left">
    &nbsp;</p>
        <p style="text-align: left">
            &nbsp;</p>
        <p style="text-align: left">
            &nbsp;</p>
        <p style="text-align: left">
            &nbsp;</p>
        <p style="text-align: left">
            The mapping function:</p>

<pre style="text-align: left">public static double GetCoord(double i1, double i2, double w1, double w2, double p)
{
return ((p - i1) / (i2 - i1)) * (w2 - w1) + w1;
}</pre>

<p style="text-align: left">Since now we have 2 R<sup>3</sup> points (Eye position and Screen pixel represented in virtual coordinates) we can obtain the ray representation:</p>

<p style="text-align: left">3D lines equations can be represented in the form: </p>

<ul>
<li style="text-align: left">x = px + t*vx </li>

<li style="text-align: left">y = py + t*vy </li>

<li style="text-align: left">z = pz + t*vz </li>
</ul>

<p style="text-align: left">Where (px,py,pz) are all the points lying in the 3D line, t is a scalar parameter, and (vx,vy,vz) is a direction vector. </p>

<p style="text-align: left">The above equation can be obtained by the definition where a line can be defined by 2 points, so given P1(x1,y1,z1) and P2(x2,y2,z2) we have: </p>

<ul>
<li style="text-align: left">v = (x2-x1,y2-y1,z2-z1) </li>
</ul>

<p style="text-align: left">replacing the found v and p we have: </p>

<ul>
<li style="text-align: left">x = x1 + t*(x2-x1) </li>

<li style="text-align: left">y = y1 + t*(y2-y1) </li>

<li style="text-align: left">z = z1 + t*(z2-z1) </li>
</ul>

<p style="text-align: left">So we can be sure that all (x,y,z) which satisfies the above equation belongs to the line defined by P1P2. </p>

<h2 style="text-align: left">Line x Sphere Intersection</h2>

<p style="text-align: left">Spheres can be represented in the form: </p>

<ul>
<li style="text-align: left">r<sup>2</sup> = (x-cx)<sup>2</sup>+(y-cy)<sup>2</sup>+(z-cz)<sup>2 </sup></li>
</ul>

<p style="text-align: left">where </p>

<ul>
<li style="text-align: left">r is the sphere radius </li>

<li style="text-align: left">(cx,cy,cz) is the center of the sphere </li>
</ul>

<p style="text-align: left">So we can be sure that all x,y,x points lies on the sphere surface.</p>

<p style="text-align: left">Our objective now is to determine the intersection equation between a given line and a sphere it must be a set of (x,y,z) points which satisfies both equations. It is simple to imagine that a line intersecting a sphere can result 0 intersections, 1 intersection (if tangent) or at most 2 intersections. </p>

<p style="text-align: left">The equations:</p>

<ul>
<li style="text-align: left">r<sup>2</sup> = (x-cx)<sup>2</sup>+(y-cy)<sup>2</sup>+(z-cz)<sup>2</sup> </li>

<li style="text-align: left">x = x1 + t*(x2-x1) </li>

<li style="text-align: left">y = y1 + t*(y2-y1) </li>

<li style="text-align: left">z = z1 + t*(z2-z1) </li>
</ul>

<p style="text-align: left">replacing x, y and z we have: </p>

<ul>
<li style="text-align: left">r<sup>2</sup> = (x1 + t*(x2-x1)-cx)<sup>2</sup> + (y1 + t*(y2-y1) -cy)<sup>2</sup> + (z1+ t*(z2-z1)-cz)<sup>2 </sup></li>
</ul>

<p style="text-align: left">lets create a variable for the vector: </p>

<ul>
<li style="text-align: left">vx = x2 - x1 </li>

<li style="text-align: left">vy = y2 - y1 </li>

<li style="text-align: left">vz = z2 - z1 </li>
</ul>

<p style="text-align: left">so now we have: </p>

<ul>
<li style="text-align: left">r<sup>2</sup> = (x1-cx+t*vx)<sup>2</sup> + (y1-cy+t*vy)<sup>2</sup> + (z1-cz+t*vz)<sup>2</sup> </li>

<li style="text-align: left">(x1-cx+t*vx)<sup>2 </sup>+ (y1-cy+t*vy)<sup>2</sup> + (z1-cz+t*vz)<sup>2</sup> - r<sup>2</sup> = 0 </li>
</ul>

<p style="text-align: left">Let's replace (x1,y1,z1) with (px,py,pz) just to simplify... </p>

<p style="text-align: left">Now we have a perfect 2nd degree equation which can give us 0, 1 or 2 different solutions for 't' :</p>

<pre lang="cs" style="text-align: left">double A = (vx * vx + vy * vy + vz * vz);
double B = 2.0 * (px * vx + py * vy + pz * vz - vx * cx - vy * cy - vz * cz);
double C = px * px - 2 * px * cx + cx * cx + py * py - 2 * py * cy + cy * cy +
           pz * pz - 2 * pz * cz    + cz * cz - radius * radius;
double D = B * B - 4 * A * C;
double t = -1.0;
if (D &gt;= 0)
     {
     double t1 = (-B - System.Math.Sqrt(D)) / (2.0 * A);
     double t2 = (-B + System.Math.Sqrt(D)) / (2.0 * A);
     if (t1 &gt; t2) 
          t = t1; 
     else 
          t = t2;  // we choose the nearest t from the first point
     }</pre>

<h2 style="text-align: left">Line x Triangle Intersection</h2>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">Plane equation:</p>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<ul>
<li>
<div class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">N dot (P - P3) = 0 (Eq1)</div>
</li>
</ul>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">Where Line (P1-P2) Equation:</p>

<ul>
<li>
<div class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">P and P3 are on the plane </div>
</li>

<li>
<div class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">N is the plane Normal vetor</div>
</li>
</ul>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<ul>
<li>
<div class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">P = P1 + v (P2 - P1) (Eq2)</div>
</li>
</ul>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">So the intersecion is given by:</p>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<ul>
<li>
<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">Eq1 = Eq2 or</p>
</li>

<li>
<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">N dot (P1 + v (P2 - P1)) = N dot P3 </p>
</li>
</ul>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">Now, the intersection between line and plane is found, so we need to verify if the given intersection lies inside the triangle:</p>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<pre class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;">public bool InternalSide(double p1x, double p1y, double p1z,
                             double p2x, double p2y, double p2z,
                             double ax, double ay, double az,
                             double bx, double by, double bz)
        {
            double cp1x = 0, cp1y = 0, cp1z = 0, cp2x = 0, cp2y = 0, 
                   cp2z = 0;
            tAlgebra.Cross3(bx - ax, by - ay, bz - az, p1x - ax, 
                            p1y - ay, p1z - az, ref cp1x, 
                            ref cp1y, ref cp1z);
            tAlgebra.Cross3(bx - ax, by - ay, bz - az, p2x - ax, p2y - ay, 
                            p2z - az, ref cp2x, ref cp2y, ref cp2z);
 
            if (tAlgebra.Dot3(cp1x, cp1y, cp1z, cp2x, cp2y, cp2z) &gt;= 0)
                return true;
            else
                return false;
        }
    
        public bool PointInTriangle(double px, double py, double pz)
        {
            if (InternalSide(px, py, pz, 
                             tp1x, tp1y, tp1z, 
                             tp2x, tp2y, tp2z, 
                             tp3x, tp3y, tp3z) &amp;&amp;
                InternalSide(px, py, pz, 
                             tp2x, tp2y, tp2z, 
                             tp1x, tp1y, tp1z, 
                             tp3x, tp3y, tp3z) &amp;&amp;
                InternalSide(px, py, pz, 
                             tp3x, tp3y, tp3z, 
                             tp1x, tp1y, tp1z, 
                             tp2x, tp2y, tp2z))
                return true;
            else
                return false;
        }
</pre>

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<p class="MsoNormal" style="MARGIN: 0in 0in 0pt; text-align: left;" />

<h2 style="text-align: left">The code</h2>

<h4 style="text-align: left">Cube.obj file</h4>

<ul>
<li style="text-align: left">v = vertex </li>

<li style="text-align: left">f = face </li>
</ul>

<pre style="text-align: left">#
# cube.obj
#
  
v -1.000000 -1.000000  1.000000
v -1.000000  1.000000  1.000000
v  1.000000  1.000000  1.000000
v  1.000000 -1.000000  1.000000
v -1.000000 -1.000000 -1.000000
v -1.000000  1.000000 -1.000000
v  1.000000  1.000000 -1.000000
v  1.000000 -1.000000 -1.000000
 
f 5 8 7
f 7 6 5
f 1 4 3
f 3 2 1
f 5 1 2
f 2 6 5
f 8 4 3
f 3 7 8
f 8 4 1
f 1 5 8
f 7 3 2
f 2 6 7
  </pre>

<h4 style="text-align: left">Algebra class</h4>

<pre style="text-align: left">    public class tAlgebra
    {
        public tAlgebra()
        {
        }
        
        //i' = i - (2 * n * dot(i, n))
        public static void Reflect(double ix, double iy, double iz, 
            double nx, double ny, double nz,
            ref double iix, ref double iiy, ref double iiz)
        {
            iix = ix - (2.0 * nx * Dot3(nx, ny, nz, ix, iy, iz));
            iiy = iy - (2.0 * ny * Dot3(nx, ny, nz, ix, iy, iz));
            iiz = iz - (2.0 * nz * Dot3(nx, ny, nz, ix, iy, iz));
            Normalize(ref iix, ref iiy, ref iiz);
        }
        public static void Cross3(double ux, double uy, double uz, 
                                  double wx, 
                  double wy, double wz,
                          ref double vx, ref double vy, 
                                  ref double vz)
        {
            // u x w
            vx = wz * uy - wy * uz;
            vy = wx * uz - wz * ux;
            vz = wy * ux - wx * uy;
        }
        public static double Dot3(double x1, double y1, double z1, 
                  double x2, double y2, double z2)
        {
            return (x1 * x2) + (y1 * y2) + (z1 * z2);
        }
        public static double GetCosAngleV1V2(double v1x, double v1y, 
             double v1z, double v2x, double v2y, double v2z)
        {
            /* incident angle
            // inters pt (i)
            double ix, iy, iz;
            ix = px+t*vx;
            iy = py+t*vy;
            iz = pz+t*vz;
          
            // normal at i
            double nx, ny, nz;
            nx = ix - cx;
            ny = iy - cy;
            nz = iz - cz;
            */
            double x, y, z;
            x = v1x; y = v1y; z = v1z;
            Normalize(ref x, ref y, ref z);
            v1x = x; v1y = y; v1z = z;
            
            x = v2x; y = v2y; z = v2z;
            Normalize(ref x, ref y, ref z);
            v2x = x; v2y = y; v2z = z;
            
            // cos(t) = (v.w) / (|v|.|w|)
            double n = (v1x * v2x + v1y * v2y + v1z * v2z) ;
            double d = (modv(v1x, v1y, v1z) * modv(v2x, v2y, v2z));
            
            if(Math.Abs(d)&lt;1.0E-10) return 0;
            return n/d ;
        }
        public static double modv(double vx, double vy, double vz)
        {
            return System.Math.Sqrt(vx * vx + vy * vy + vz * vz);
        }
        public static double GetCoord(double i1, double i2, double w1, 
                                      double w2, double p)
        {
            return ((p - i1) / (i2 - i1)) * (w2 - w1) + w1;
        }
       
        public static void Normalize(ref double vx, ref double vy, 
                                     ref double vz)
        {
            double mod_v = tAlgebra.modv(vx, vy, vz);
            if (Math.Abs(mod_v) &lt; 1.0E-10) return;
            vx = vx / mod_v;
            vy = vy / mod_v;
            vz = vz / mod_v;
        }
    }</pre>

<h4 style="text-align: left">Object Classes</h4>

<pre style="text-align: left">    public class tObject
    {
        public tObject()
        {
        }
        public double ambientR, ambientG, ambientB;
        public double diffuseR, diffuseG, diffuseB;
        public double specularR, specularG, specularB;
        public double shininess;
    }
    public class tTriangle : tObject
    {
        public tTriangle()
        {
        }
        
        public void Init()
        {
            getNormal(ref tnormalX, ref tnormalY, ref tnormalZ);
        }
        public bool SameSide(double p1x, double p1y, double p1z,
                             double p2x, double p2y, double p2z,
                             double ax, double ay, double az,
                             double bx, double by, double bz)
        {
            double cp1x = 0, cp1y = 0, cp1z = 0, cp2x = 0, cp2y = 0, 
                   cp2z = 0;
            tAlgebra.Cross3(bx - ax, by - ay, bz - az, p1x - ax, 
              p1y - ay, p1z - az, ref cp1x, ref cp1y, ref cp1z);
            tAlgebra.Cross3(bx - ax, by - ay, bz - az, p2x - ax, 
              p2y - ay, p2z - az, ref cp2x, ref cp2y, ref cp2z);
            if (tAlgebra.Dot3(cp1x, cp1y, cp1z, cp2x, cp2y, cp2z) &gt;= 0)
                return true;
            else
                return false;
        }
        public bool PointInTriangle(double px, double py, double pz)
        {
            if (SameSide(px, py, pz, tp1x, tp1y, tp1z, 
                    tp2x, tp2y, tp2z, tp3x, tp3y, tp3z) &amp;&amp;
                SameSide(px, py, pz, tp2x, tp2y, tp2z, 
                    tp1x, tp1y, tp1z, tp3x, tp3y, tp3z) &amp;&amp;
                SameSide(px, py, pz, tp3x, tp3y, tp3z, 
                    tp1x, tp1y, tp1z, tp2x, tp2y, tp2z))
                return true;
            else
                return false;
        }
        
        // ray p1, ray p2
        public double GetInterSect(double p1x, double p1y, double p1z, 
                                 double p2x, double p2y, double p2z)
        {
            double v1x = tp3x - p1x; double v1y = tp3y - p1y; 
            double v1z = tp3z - p1z;
            double v2x = p2x - p1x;  double v2y = p2y - p1y;  
            double v2z = p2z - p1z;
            double dot1 = tAlgebra.Dot3(tnormalX, tnormalY, tnormalZ, 
                                        v1x, v1y, v1z);
            double dot2 = tAlgebra.Dot3(tnormalX, tnormalY, tnormalZ, 
                                        v2x, v2y, v2z);
            if (Math.Abs(dot2) &lt; 1.0E-6) 
                return -1; // division by 0 means parallel
            double u = dot1 / dot2;
            // point in triangle?
            if(!PointInTriangle(p1x+u*(p2x-p1x), 
                            p1y+u*(p2y-p1y), p1z+u*(p2z-p1z)))
                return -1;
            return u;
        }
        public void getNormal(ref double vx, ref double vy, ref double vz)
        {
            double ux = tp3x - tp1x, uy = tp3y - tp1y, uz = tp3z - tp1z;
            double wx = tp2x - tp1x, wy = tp2y - tp1y, wz = tp2z - tp1z;
            
            // u x w
            vx = wz * uy - wy * uz;
            vy = wx * uz - wz * ux;
            vz = wy * ux - wx * uy;
        }
        
        
        public double tp1x, tp1y, tp1z;
        public double tp2x, tp2y, tp2z;
        public double tp3x, tp3y, tp3z;
        public double tnormalX, tnormalY, tnormalZ;
    }

 </pre>

<h4 style="text-align: left">The program</h4>

<pre style="text-align: left">        int scz = 200;
         
        System.IO.FileStream file = new System.IO.FileStream(
                             Server.MapPath("./data/cube.obj"), 
                             System.IO.FileMode.Open, 
                             System.IO.FileAccess.Read);
        System.IO.StreamReader reader = new System.IO.StreamReader(file);
        string filebody = reader.ReadToEnd();
        file.Close();
 
        string[] lines = filebody.Split('\n');
        ArrayList pointArrayX = new ArrayList();
        ArrayList pointArrayY = new ArrayList();
        ArrayList pointArrayZ = new ArrayList();
 
        System.Collections.ArrayList obj3dArrayList;
        obj3dArrayList = new System.Collections.ArrayList();
 
        double rx = 0.5000;
        double ry = 0.5000;
        double rz = 0.0000;
                 
        foreach (string line in lines)
        {
            if (line.Length &lt; 1) continue;
            string auxline = line;
            if (auxline.IndexOf("mtllib") &gt;= 0)
            {
                auxline = auxline.Replace("mtllib", "");
                GetMaterial(auxline);
            }
            else
            if (auxline[0] == 'v')
            {
                auxline = auxline.Replace("v ", "");
                string[] points = auxline.Split(' ');
                double x = double.Parse(points[0]);
                double y = double.Parse(points[1]);
                double z = double.Parse(points[2]);
                pointArrayX.Add(x);
                pointArrayY.Add(y);
                pointArrayZ.Add(z);
            }
            else
            if (auxline[0] == 'f')
            {
                auxline = auxline.Replace("f ", "");
                string[] vertices = auxline.Split(' ');
                int a = int.Parse(vertices[0])-1;
                int b = int.Parse(vertices[1])-1;
                int c = int.Parse(vertices[2])-1;
 
                tTriangle tri1 = new tTriangle();
                tri1.tp1x = (double) pointArrayX[a]; 
                tri1.tp1y = (double) pointArrayY[a]; 
                tri1.tp1z = (double) pointArrayZ[a];
                
                tri1.tp2x = (double) pointArrayX[b]; 
                tri1.tp2y = (double) pointArrayY[b]; 
                tri1.tp2z = (double) pointArrayZ[b];
                tri1.tp3x = (double) pointArrayX[c]; 
                tri1.tp3y = (double) pointArrayY[c]; 
                tri1.tp3z = (double) pointArrayZ[c];
                 
                Algebra.RotX(rx, ref tri1.tp1y, ref tri1.tp1z);
                Algebra.RotX(rx, ref tri1.tp2y, ref tri1.tp2z);
                Algebra.RotX(rx, ref tri1.tp3y, ref tri1.tp3z);
                Algebra.RotY(ry, ref tri1.tp1x, ref tri1.tp1z);
                Algebra.RotY(ry, ref tri1.tp2x, ref tri1.tp2z);
                Algebra.RotY(ry, ref tri1.tp3x, ref tri1.tp3z);
                Algebra.RotZ(rz, ref tri1.tp1x, ref tri1.tp1y);
                Algebra.RotZ(rz, ref tri1.tp2x, ref tri1.tp2y);
                Algebra.RotZ(rz, ref tri1.tp3x, ref tri1.tp3y);
                 
                // ambient properties for the material   
                tri1.ambientR = 0.3;
                tri1.ambientG = 0.4;
                tri1.ambientB = 0.5;
                // specular properties for the material   
                tri1.specularR = 0.911;
                tri1.specularG = 0.911;
                tri1.specularB = 0.911;
                tri1.shininess = 10.6;
                tri1.diffuseR = 0.3775;
                tri1.diffuseG = 0.3775;
                tri1.diffuseB = 0.5775;
                obj3dArrayList.Add(tri1);
                tri1.Init();
            }
             
        }
 
        Bitmap newBitmap = new Bitmap(scz, scz, 
               PixelFormat.Format32bppArgb);
        Graphics g = Graphics.FromImage(newBitmap);
 
        Pen blackPen = new Pen(Color.Black);
        Color clrBackground = Color.Black;
        g.FillRectangle(new SolidBrush(clrBackground), 
                        new Rectangle(0, 0, scz, scz));
 
        Rectangle rect = new Rectangle(0, 0, scz, scz);
 
        Graphics graphics = g;
 
        double px = 0.0;
        double py = 0.0;
        double pz = 600.0;
 
        double lpx = 1.5;
        double lpy = 1.7;
        double lpz = 500.0;
         
        double lp2x = lpx;
        double lp2y = lpy;
        double lp2z = lpz-0.1;
 
        double lvx = lp2x - lpx;
        double lvy = lp2y - lpy;
        double lvz = lp2z - lpz;
         
        tAlgebra.Normalize(ref lvx, ref lvy, ref lvz);
 
        // virtual mapping size
        double fMax = 2.5;
 
        for (int i = rect.Left; i &lt;= rect.Right; i++)
        {
            double x = tAlgebra.GetCoord(rect.Left, 
                        rect.Right, -fMax, fMax, i);
 
            for (int j = rect.Top; j &lt;= rect.Bottom; j++)
            {
                double y = tAlgebra.GetCoord(rect.Top, 
                           rect.Bottom, fMax, -fMax, j);
 
                double t = 1.0E10;
 
                double vx = x - px, vy = y - py, vz = -pz;
 
                double mod_v = tAlgebra.modv(vx, vy, vz);
                vx = vx / mod_v;
                vy = vy / mod_v;
                vz = vz / mod_v;
 
                bool bShadow = false;
 
                tTriangle triangleHit = null;
 
                for (int k = 0; k &lt; (int)obj3dArrayList.Count; k++)
                {
                    tTriangle triN = (tTriangle)obj3dArrayList[k];
                    double taux = triN.GetInterSect(px, py, pz, x, y, 0.0);
                    if (taux &lt; 0) continue;
 
                    if (taux &gt; 0 &amp;&amp; taux &lt; t)
                    {
                        t = taux;
                        triangleHit = triN;
                    }
                }
 
                Color color;
                color = Color.FromArgb(10, 20, 10);
 
                Pen pen = new Pen(Color.Black);
 
                if (triangleHit != null)
                {
                    double intersx = px + t * vx, 
                           intersy = py + t * vy, intersz = pz + t * vz;
                    double l2px = intersx - lpx, 
                           l2py = intersy - lpy, l2pz = intersz - lpz;
                    tAlgebra.Normalize(ref l2px, ref l2py, ref l2pz);
                     
                    double vNormalX = triangleHit.tnormalX, 
                           vNormalY = triangleHit.tnormalY, 
                           vNormalZ = triangleHit.tnormalZ;
                    tAlgebra.Normalize(ref vNormalX, ref vNormalY, 
                                       ref vNormalZ);
                     
                    double cost = tAlgebra.GetCosAngleV1V2(l2px, l2py, l2pz, 
                               vNormalX, vNormalY, vNormalZ);
                    if (cost &lt; 0) cost = 0;
                     
                    double vReflX = 0, vReflY = 0, vReflZ = 0;
                    double vEye2IntersX = intersx - px, 
                           vEye2IntersY = intersy - py, 
                           vEye2IntersZ = intersz - pz;
                    tAlgebra.Reflect(l2px, l2py, l2pz, vNormalX, vNormalY, 
                          vNormalZ, ref vReflX, ref vReflY, ref vReflZ);
                         
                    tAlgebra.Normalize(ref vReflX, ref  vReflY, ref vReflZ);
                    tAlgebra.Normalize(ref vEye2IntersX, ref vEye2IntersY, 
                             ref vEye2IntersZ);
                    double cosf = tAlgebra.GetCosAngleV1V2(vReflX, vReflY, 
                            vReflZ, vEye2IntersX, vEye2IntersY, 
                            vEye2IntersZ);
 
                    if (cosf &lt; 0) 
                        cosf = 0;
                                        
                    double result1 = cost * 255.0;
                    double result2 = Math.Pow(cosf, triangleHit.shininess) *
                               255.0;
                     
                    double rgbR = (triangleHit.ambientR * 255.0) + 
                      (triangleHit.diffuseR * result1) +
                      (triangleHit.specularR * result2);
                    double rgbG = (triangleHit.ambientG * 255.0) + 
                       (triangleHit.diffuseG * result1) +
                       (triangleHit.specularG * result2);
                    double rgbB = (triangleHit.ambientB * 255.0) + 
                       (triangleHit.diffuseB * result1) +
                       (triangleHit.specularB * result2);
 
                    rgbR = Math.Min(rgbR, 255);
                    rgbG = Math.Min(rgbG, 255);
                    rgbB = Math.Min(rgbB, 255);
                    rgbR = Math.Max(rgbR, 0);
                    rgbG = Math.Max(rgbG, 0);
                    rgbB = Math.Max(rgbB, 0);
                     
                    color = Color.FromArgb((int)rgbR, (int)rgbG, (int)rgbB);
                    pen = new Pen(color);
                }
 
                Brush brs = new SolidBrush(color);
                graphics.FillRectangle(brs, i, j, 1, 1);
 
                graphics.DrawLine(pen, i, j, i + 1, j + 1);
                brs.Dispose();
 
            }// for pixels lines
        }// for pixels columns
        ///////////////////////////////////////
 
        MemoryStream tempStream = new MemoryStream();
        newBitmap.Save(tempStream, ImageFormat.Png);
        Response.ClearContent();
        Response.ContentType = "image/png";
        Response.BinaryWrite(tempStream.ToArray());
        Response.Flush();</pre>

<p style="text-align: left" />





<!----------------------------- Article Ends ----------------------------->        <!--#include file="~/templatebottom2.aspx"-->
    </form>
</body>
</html>
