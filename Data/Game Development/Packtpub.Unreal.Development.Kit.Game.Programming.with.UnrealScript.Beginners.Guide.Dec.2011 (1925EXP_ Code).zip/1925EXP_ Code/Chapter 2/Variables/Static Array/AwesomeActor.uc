class AwesomeActor extends Actor
    placeable;

var int Baskets[4];
var int TestNumber;

function PostBeginPlay()
{
    TestNumber = 2;

    Baskets[0] = 2;
    Baskets[1] = 13;
    Baskets[2] = 4;
    Baskets[3] = 1;

    `log("Test Basket:" @ Baskets[TestNumber]);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
