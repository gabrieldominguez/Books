class UberActor extends AwesomeActor
    placeable;

function UberFunction()
{
    `log("UberFunction was called!");
}

defaultproperties
{
}
