// =============================================================================
//    PRIMER EJEMPLO DE USO DE OPENGL
//    Computaci�n II
//
//    Objetivo: Comentar las funciones m�s importantes introductorias a OpenGL.
//    Daniel, 2001/09/12
// =============================================================================

#include <GL/glut.h>
#include "ejemplos.cpp"

// =============================================================================

void RefrescaPantalla(int width, int height)
{ // funci�n que se llama con el evento de cambiar el tama�o de la pantalla.

  glViewport(0, 0, width, height); // "VIEWING"
  // "Viewport" hace referencia a la salida por la ventana.
  // Que relaci�n hay con el cero,cero de la ventana "interna" y el cero,cero
  // de la ventana que saldr� en la pantalla.

  glMatrixMode(GL_PROJECTION);
  // Con este comando se dice que el glLoadIdentity(), que est� a
  // continuaci�n, van a afectar a la proyecci�n de la matriz del
  // modelo, en vez de la matriz modelview ("punto de vista").

  glLoadIdentity();
  // La matriz de transformaci�n va a ser la matriz identidad. Esto es necesario
  // porque las transform. se realizan multiplicando por la actual matriz de
  // transform.. Si no se carga la matriz identidad las transformaciones
  // se van a ir acumulando.

  gluOrtho2D(-1, 1, -1, 1);        // "PROJECTION"
  // Establece el sistema de coordenadas de c�mo un objeto es mostrado en la
  // pantalla. Adem�s, con los par�metros se establece el rango de coordenada
  // de lo que se ver�. La proyecci�n ortogonal no cambia el volumen de los
  // objetos con la distancia de la c�mara, esto no sucede con vistas en
  // perspectiva.
  // Especificar el tipo de proyecci�n es como cambiar el lente a una c�mara.

  glMatrixMode(GL_MODELVIEW);  // Vuelve al modelo de matriz "punto de vista"
}

void Dibujar(void)
{ // funci�n que es llamada repetida-veces para redibujar la pantalla.

  glClear(GL_COLOR_BUFFER_BIT);   // Limpia la pantalla con el color dado por
                                  // glClearColor().

  glLoadIdentity();

  // EJEMPLOS DE CAMBIOS EN EL MODELO (Modeling Transformation) ================
  // Realizar pruebas eliminando las barras de comentario.
  // Las transformaciones son acumulativas y no permutativas.
  // La acumulaci�n de transformaciones se "vuelve a cero" con glLoadIdentity();

  // glTranslatef (0.0, -0.5, 0.0); // Se traslada el objeto a -0.5 en "y".
  // glScalef(1.0,2.0,1.0);         // Se duplica todas las coord. "y".
  // glRotatef(90,0,0,1);           // Rota el modelo respecto al eje "z" que
                                    // sale de la pantalla.

  // EJEMPLOS DE CAMBIOS DEL PUNTO DE VISTA (Viewing Transformation) ===========
  // Esto se realiza con gluLookAt();
  // Esto no realiza un cambio en las coordenadas del objeto,
  // (como las Model Transformation) sino s�lo del punto de vista.
  // Con gluLookAt() se define la linea por donde va la vista.
  // Falta poner un ejemplo de llamado.

  // INICIO DE LOS DIBUJOS =====================================================
  Lineas();  // ver el orden de los dibujos. De atr�s para adelante.
  Puntos();
  Figuras3D();
  // FIN DE LOS DIBUJOS ========================================================

  glFlush();
  // Asegura que el dibujo sea mostrado por pantalla.
  // En caso de estar en red no espera a que se termine el paquete,
  // lo manda al server para que lo ejecute. Si no se trabaja con cliente y
  // servidor, flFlush() no es necesario.

  glutSwapBuffers();
  // Tener doble buffer tiene la ventaja que cuando se est� mostrado por
  // pantalla, en el otro buffer se est� dibujando la pr�xima imagen.
  // Cada frame es mostrado �nicamente cuando el dibujo ha sido terminado,
  // si se observa la pantalla, nunca se ver� un dibujo parcial.
}


int main(int argc, char *argv[])
{
  // Se crea la ventana gr�fica e inicializa el sistema ========================
  glutInit(&argc, argv);          // negocia una sesi�n con el sistema operativo
  glutInitWindowSize(400, 400);          // tama�o inicial de la ventana gr�fica

  glutInitWindowPosition(100, 100);    // posici�n inicial de la ventana gr�fica

  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);   // Modo de display. Color: RGB.
                                                 // Buffer: doble.

  (void)glutCreateWindow("Demo Computaci�n II");   // Crea y establece el t�tulo
                                        // El "void" es porque devuelve un "int"

  glutReshapeFunc(RefrescaPantalla);              // Comunica con que funci�n se
                                                  // va a redibujar la pantalla

  glEnable(GL_POINT_SMOOTH);  // Habilita antialiasing.
                              // Para l�neas: GL_LINE_SMOOTH

  glutDisplayFunc(Dibujar); //Comunica cual es la funci�n encargada de hacer el
                            // dibujo y los repetidos refrescos de pantalla.

  glClearColor(0, 0, 0, 0); // Establece con que color va a limpiar la pantalla.
                            // Limpia con glClear().

  // Muestra y refresca constantemente la ventana gr�fica con el dibujo ========
  glutMainLoop();

  return 0;
}


