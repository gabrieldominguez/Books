VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "pyramideGouraud"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'co-ordinates of the pyramide
Private xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd, xe, ye, ze As GLfloat

'dimension of the pyramide
Private de As Single

'center of the pyramide
Private xcentre, ycentre, zcentre As Single

'name given to the pyramide (not use here)
Public nom As String

Private ratio As Single 'number of color

'eye position (camera)
Private x50, y50, z50 As Single

'angles of each polygon with the camera
Private angle1 As GLfloat
Private angle2 As GLfloat
Private angle3 As GLfloat
Private angle4 As GLfloat

'vector normal of each face polygon
Private xn1, yn1, zn1 As Single
Private xn2, yn2, zn2 As Single
Private xn3, yn3, zn3 As Single
Private xn4, yn4, zn4 As Single

'color (r,v,b) of each vertex of a polygon (Gouraud Shading)
Private rouge_a, vert_a, bleu_a As GLfloat
Private rouge_b, vert_b, bleu_b As GLfloat
Private rouge_c, vert_c, bleu_c As GLfloat
Private rouge_d, vert_d, bleu_d As GLfloat
Private rouge_e, vert_e, bleu_e As GLfloat

Public Sub affichage(ByVal xoeil As Single, ByVal yoeil As Single, ByVal zoeil As Single)

'light source and camera are in the same place

'use co-ordinate of the camera
x50 = xoeil
y50 = yoeil
z50 = zoeil

'calculate angle between polygons and camera
poly_aed
poly_eab
poly_ebc
poly_ecd

'calculate a color for each vertex
calcul_couleurA
calcul_couleurB
calcul_couleurC
calcul_couleurD
calcul_couleurE

'if the polygon is visible (angle>0)
'then draw on the frame buffer
If angle1 > 0 Then
aed
End If

If angle2 > 0 Then
eab
End If

If angle3 > 0 Then
ebc
End If

If angle4 > 0 Then
ecd
End If


End Sub

Public Sub rotation_gauche()

'rotate without glrotated

Dim a, b As Single

'center of rotation
a = xcentre
b = zcentre

Dim t, e, f As Double

Dim degr� As Double

degr� = 12

'convert in radians
t = degr� * 0.017453293

e = Cos(t)
f = Sin(t)

Dim un, deux As Single

'first point
un = xa - a
deux = za - b
xa = a + un * e - deux * f
za = b + un * f + deux * e

'second point
un = xb - a
deux = zb - b
xb = a + un * e - deux * f
zb = b + un * f + deux * e

'third point
un = xc - a
deux = zc - b
xc = a + un * e - deux * f
zc = b + un * f + deux * e

'fourth point
un = xd - a
deux = zd - b
xd = a + un * e - deux * f
zd = b + un * f + deux * e

'top of the pyramide
un = xe - a
deux = ze - b
xe = a + un * e - deux * f
ze = b + un * f + deux * e

End Sub
Public Sub rotation_droite()

'rotate without glrotated

Dim a, b As Single

'center of rotation
a = xcentre
b = zcentre

Dim t, e, f As Double

Dim degr� As Double

degr� = -12

'convertion in radians
t = degr� * 0.017453293

e = Cos(t)
f = Sin(t)

Dim un, deux As Single

'first point
un = xa - a
deux = za - b
xa = a + un * e - deux * f
za = b + un * f + deux * e

'second point
un = xb - a
deux = zb - b
xb = a + un * e - deux * f
zb = b + un * f + deux * e

'third point
un = xc - a
deux = zc - b
xc = a + un * e - deux * f
zc = b + un * f + deux * e

'fourth point
un = xd - a
deux = zd - b
xd = a + un * e - deux * f
zd = b + un * f + deux * e

'top of the pyramide
un = xe - a
deux = ze - b
xe = a + un * e - deux * f
ze = b + un * f + deux * e

End Sub
Public Sub poly_aed()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double


'vector ea
xbc = xa - xe
ybc = ya - ye
zbc = za - ze

'vector ed
xbd = xd - xe
ybd = yd - ye
zbd = zd - ze


'normal vector of the face
xn1 = (ybd * zbc) - (zbd * ybc)
yn1 = (zbd * xbc) - (xbd * zbc)
zn1 = (xbd * ybc) - (ybd * xbc)


'barycentre of the face
baryx1 = (xa + xe + xd) / 3
baryy1 = (ya + ye + yd) / 3
baryz1 = (za + ze + zd) / 3


'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn1) ^ 2 + (yn1) ^ 2 + (zn1) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn1 * xvo1
int2 = yn1 * yvo1
int3 = zn1 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle1 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_eab()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double


'vector ea
xbc = xe - xa
ybc = ye - ya
zbc = ze - za

'vector eb
xbd = xb - xe
ybd = yb - ye
zbd = zb - ze

'normal vector of the face
xn2 = (ybd * zbc) - (zbd * ybc)
yn2 = (zbd * xbc) - (xbd * zbc)
zn2 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xa + xe + xb) / 3
baryy1 = (ya + ye + yb) / 3
baryz1 = (za + ze + zb) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn2) ^ 2 + (yn2) ^ 2 + (zn2) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn2 * xvo1
int2 = yn2 * yvo1
int3 = zn2 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle2 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_ebc()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double

'vector be
xbc = xe - xb
ybc = ye - yb
zbc = ze - zb

'vector bc
xbd = xc - xb
ybd = yc - yb
zbd = zc - zb

'normal vector of the face
xn3 = (ybd * zbc) - (zbd * ybc)
yn3 = (zbd * xbc) - (xbd * zbc)
zn3 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xc + xe + xb) / 3
baryy1 = (yc + ye + yb) / 3
baryz1 = (zc + ze + zb) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn3) ^ 2 + (yn3) ^ 2 + (zn3) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn3 * xvo1
int2 = yn3 * yvo1
int3 = zn3 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle3 = a10b10 / (a10 * b10)

End Sub
Public Sub poly_ecd()

Dim xbd, ybd, zbd, xbc, ybc, zbc As Single
Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double

'vector ce
xbc = xe - xc
ybc = ye - yc
zbc = ze - zc

'vector cd
xbd = xd - xc
ybd = yd - yc
zbd = zd - zc


'normal vector of the face
xn4 = (ybd * zbc) - (zbd * ybc)
yn4 = (zbd * xbc) - (xbd * zbc)
zn4 = (xbd * ybc) - (ybd * xbc)

'barycentre of the face
baryx1 = (xc + xe + xd) / 3
baryy1 = (yc + ye + yd) / 3
baryz1 = (zc + ze + zd) / 3

'x50,y50,z50 co-ordinate of the camera
'vector from camera to barycentre
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'lenght of the two vectors
a10 = Sqr((xn4) ^ 2 + (yn4) ^ 2 + (zn4) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn4 * xvo1
int2 = yn4 * yvo1
int3 = zn4 * zvo1

a10b10 = int1 + int2 + int3

'angle between the two vectors
angle4 = a10b10 / (a10 * b10)

End Sub



Public Sub aed()

'draw polygon "aed" and give the color for each vertex

glBegin bmPolygon

glColor3f rouge_a, vert_a, bleu_a
glVertex3f xa, ya, za

glColor3f rouge_e, vert_e, bleu_e
glVertex3f xe, ye, ze

glColor3f rouge_d, vert_d, bleu_d
glVertex3f xd, yd, zd

glEnd

End Sub

Public Sub eab()

'draw polygon "eab" and give the color for each vertex

glBegin bmPolygon

glColor3f rouge_e, vert_e, bleu_e
glVertex3f xe, ye, ze

glColor3f rouge_a, vert_a, bleu_a
glVertex3f xa, ya, za

glColor3f rouge_b, vert_b, bleu_b
glVertex3f xb, yb, zb

glEnd

End Sub

Public Sub ebc()

'draw polygon "ebc" and give the color for each vertex

glBegin bmPolygon

glColor3f rouge_e, vert_e, bleu_e
glVertex3f xe, ye, ze

glColor3f rouge_b, vert_b, bleu_b
glVertex3f xb, yb, zb

glColor3f rouge_c, vert_c, bleu_c
glVertex3f xc, yc, zc

glEnd


End Sub

Public Sub ecd()

'draw polygon "ecd" and give the color for each vertex

glBegin bmPolygon

glColor3f rouge_e, vert_e, bleu_e
glVertex3f xe, ye, ze

glColor3f rouge_c, vert_c, bleu_c
glVertex3f xc, yc, zc

glColor3f rouge_d, vert_d, bleu_d
glVertex3f xd, yd, zd

glEnd


End Sub

Public Sub calcul_couleurA()

Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double
Dim xn, yn, zn As Single
Dim angle As Single

'average of the two normal vectors of the two polygons that meet
'on the point "a".
'this give the normal vector of "a"

xn = (xn1 + xn2) / 2
yn = (yn1 + yn2) / 2
zn = (zn1 + zn2) / 2


'the point "a"
baryx1 = xa
baryy1 = ya
baryz1 = za


'x50,y50,z50 co-ordinate of the camera
'vector between the camera and the point
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'calculate the length of the two vectors
a10 = Sqr((xn) ^ 2 + (yn) ^ 2 + (zn) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

' "produit scalaire"
int1 = xn * xvo1
int2 = yn * yvo1
int3 = zn * zvo1

a10b10 = int1 + int2 + int3

'calculate angle between the two vectors
'( vector from the point and vector from the camera to point)
angle = a10b10 / (a10 * b10)

Dim r As GLfloat
Dim v As GLfloat
Dim b As GLfloat

'give "angle" and receive r,v,b (parameters of color)
determine_couleur angle, r, v, b

'save color of point "a" in variables
rouge_a = r
vert_a = v
bleu_a = b

End Sub
Public Sub determine_couleur(ByVal angle As Single, r As GLfloat, v As GLfloat, b As GLfloat)

'angle between 0 and 1

'blue dark : r=10  v=10   b=210

'blue light  :  r=160   v=160   b=210

'there are 150 shades of blue by default (160-10)


Dim couleur As GLfloat
couleur = 10 + (angle * ratio)

Dim convertion As GLfloat
convertion = 0.00390625

r = couleur * convertion
v = couleur * convertion
b = 210 * convertion

End Sub


Public Sub calcul_couleurB()

Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double
Dim xn, yn, zn As Single
Dim angle As Single


'average of the two normal vectors of the two polygons that meet
'on the point "b".
'this give the normal vector of "b"
xn = (xn3 + xn2) / 2
yn = (yn3 + yn2) / 2
zn = (zn3 + zn2) / 2


'point "b"
baryx1 = xb
baryy1 = yb
baryz1 = zb


'x50,y50,z50 co-ordinate of the camera
'vector between the camera and the point
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'calculate the length of the two vectors
a10 = Sqr((xn) ^ 2 + (yn) ^ 2 + (zn) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn * xvo1
int2 = yn * yvo1
int3 = zn * zvo1

a10b10 = int1 + int2 + int3

'calculate angle between the two vectors
'( vector from the point and vector from the camera to point)
angle = a10b10 / (a10 * b10)

Dim r As GLfloat
Dim v As GLfloat
Dim b As GLfloat

'give "angle" and receive r,v,b (parameters of color)
determine_couleur angle, r, v, b

'save color of point "b" in variables
rouge_b = r
vert_b = v
bleu_b = b

End Sub

Public Sub calcul_couleurC()

Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double
Dim xn, yn, zn As Single
Dim angle As Single

'average of the two normal vectors of the two polygons that meet
'on the point "c".
'this give the normal vector of "c"
xn = (xn3 + xn4) / 2
yn = (yn3 + yn4) / 2
zn = (zn3 + zn4) / 2

'point "c"
baryx1 = xc
baryy1 = yc
baryz1 = zc


'x50,y50,z50 co-ordinate of the camera
'vector between the camera and the point
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'calculate the length of the two vectors
a10 = Sqr((xn) ^ 2 + (yn) ^ 2 + (zn) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn * xvo1
int2 = yn * yvo1
int3 = zn * zvo1

a10b10 = int1 + int2 + int3

'calculate angle between the two vectors
'( vector from the point and vector from the camera to point)
angle = a10b10 / (a10 * b10)

Dim r As GLfloat
Dim v As GLfloat
Dim b As GLfloat

'give "angle" and receive r,v,b (parameters of color)
determine_couleur angle, r, v, b

'save color of point "c" in variables
rouge_c = r
vert_c = v
bleu_c = b



End Sub

Public Sub calcul_couleurD()

Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double
Dim xn, yn, zn As Single
Dim angle As Single

'average of the two normal vectors of the two polygons that meet
'on the point "d".
'this give the normal vector of "d"
xn = (xn1 + xn4) / 2
yn = (yn1 + yn4) / 2
zn = (zn1 + zn4) / 2

'point "d"
baryx1 = xd
baryy1 = yd
baryz1 = zd


'x50,y50,z50 co-ordinate of the camera
'vector between the camera and the point
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'calculate the length of the two vectors
a10 = Sqr((xn) ^ 2 + (yn) ^ 2 + (zn) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn * xvo1
int2 = yn * yvo1
int3 = zn * zvo1

a10b10 = int1 + int2 + int3

'calculate angle between the two vectors
'( vector from the point and vector from the camera to point)
angle = a10b10 / (a10 * b10)

Dim r As GLfloat
Dim v As GLfloat
Dim b As GLfloat

'give "angle" and receive r,v,b (parameters of color)
determine_couleur angle, r, v, b

'save color of point "d" in variables
rouge_d = r
vert_d = v
bleu_d = b


End Sub

Public Sub calcul_couleurE()

Dim baryx1, baryy1, baryz1 As Single
Dim xvo1, yvo1, zvo1 As Single
Dim a10, b10, a10b10 As Double
Dim int1, int2, int3 As Double
Dim xn, yn, zn As Single
Dim angle As Single

'average of the four normal vectors of the four polygons that meet
'on the point "e".
'this give the normal vector of "e"
xn = (xn1 + xn2 + xn3 + xn4) / 4
yn = (yn1 + yn2 + yn3 + yn4) / 4
zn = (zn1 + zn2 + zn3 + zn4) / 4

'point "e"
baryx1 = xe
baryy1 = ye
baryz1 = ze


'x50,y50,z50 co-ordinate of the camera
'vector between the camera and the point
xvo1 = baryx1 - x50
yvo1 = baryy1 - y50
zvo1 = baryz1 - z50

'calculate the length of the two vectors
a10 = Sqr((xn) ^ 2 + (yn) ^ 2 + (zn) ^ 2)
b10 = Sqr((xvo1) ^ 2 + (yvo1) ^ 2 + (zvo1) ^ 2)

'"produit scalaire"
int1 = xn * xvo1
int2 = yn * yvo1
int3 = zn * zvo1

a10b10 = int1 + int2 + int3

'calculate angle between the two vectors
'( vector from the point and vector from the camera to point)
angle = a10b10 / (a10 * b10)

Dim r As GLfloat
Dim v As GLfloat
Dim b As GLfloat

'give "angle" and receive r,v,b (parameters of color)
determine_couleur angle, r, v, b

'save color of point "e" in variables
rouge_e = r
vert_e = v
bleu_e = b


End Sub

Private Sub Class_Initialize()

ratio = 150 '150 colors at the beginning

de = 0.6 'dimension de la pyramide

xcentre = 0
ycentre = 0
zcentre = 0

xa = xcentre - 3 * de
ya = ycentre
za = zcentre - 3 * de

xb = xcentre + 3 * de
yb = ycentre
zb = zcentre - 3 * de

xc = xcentre + 3 * de
yc = ycentre
zc = zcentre + 3 * de

xd = xcentre - 3 * de
yd = ycentre
zd = zcentre + 3 * de

'sommet
xe = xcentre
ye = ycentre + 5 * de
ze = zcentre


End Sub



Public Sub couleurs(ByVal colors As Long)

'give the number of color need to
'smothly shade the pyramide

ratio = colors


End Sub
