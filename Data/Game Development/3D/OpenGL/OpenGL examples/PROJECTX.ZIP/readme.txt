
VB can be downright psychotic at times. Follow this procedure to get the template project into a new directory and ready for use:


To use ProjectX:

1. Copy these files to a new directory:
ProjectX.vbp
frmMain.frm
mConstants.bas
CXX.cls

2. Run VB and load the ProjectX.vbp. 

2. Rename CXXX to whatever the main class will be named. You can leave the CX's, or change them too. Change the two CXXX references to the new class name.

3. Rename the project, and save the CXXX.cls and ProjectX.vbp under new names if you wish.

4. Now select 'Add Project' and add the glxUTCtl project to the group.

5. Add a control to to the form.

6. 

7. Now run it. You should a blue ball in the center of the screen.


