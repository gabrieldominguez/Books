Attribute VB_Name = "mConstants"
Option Explicit
Public Enum NextRotationProcConstants
    procNone = 0
    procRandom = 1
    procWobble = 2
End Enum
Public Enum BoundingBoxProcConstants
    procCalcBoundingBox = 0
    procCalcBoundingBoxGeneric = 1
End Enum
Public Enum TrigTableToUse
    trigNormal = 0
    trigInv = 1
End Enum
' demo types
Public Enum SSDemoTypes
    DEMO_STRING = 0    ' static string
    DEMO_CLOCK = 1       ' digital clock
    DEMO_VSTRING = 2     ' variable string (actually a subset of DEMO_STRING)
End Enum
' surface styles
Public Enum SSSurfaceStyles
    SURFSTYLE_SOLID = 0
    SURFSTYLE_TEX = 1
    SURFSTYLE_WIREFRAME = 2
End Enum
' rotation styles
Public Enum SSRotationStyles
    ROTSTYLE_NONE = 0
    ROTSTYLE_SEESAW = 1
    ROTSTYLE_WOBBLE = 2
    ROTSTYLE_RANDOM = 3
    NUM_ROTSTYLES = 4
End Enum

Public Enum SSAxes
    X_AXIS = 0
    Y_AXIS = 1
    Z_AXIS = 2
    NUM_AXIS = 3
End Enum

    ' registry or registry-derived attributes
' Resource constants
Public Const regAppName = "OpenGL 3D Text"
Public Const regSection = "Settings" '1002
' registry attribute strings:
Public Const regDemoType = "DemoType"
Public Const regRotStyle = "RotationStyle"
Public Const regTessFactor = "Tesselation"
Public Const regSize = "Size"
Public Const regSpeed = "Speed"
Public Const regSurfStyle = "SurfaceStyle"
Public Const regFont = "Font"
Public Const regCharSet = "Charset"
Public Const regBold = "FontBold"
Public Const regItalic = "FontItalic"
Public Const regText = "Text"
Public Const regTexture = "Texture"
Public Const regTextFile = "TextFile"
'
Public Const SS_DEBUG = 1
Public Const FMAX_CHORDAL_DEVIATION = 0.008!
Public Const FMIN_DEPTH = 0.15
Public Const FMAX_DEPTH = 0.6
Public Const FMIN_VIEW_ANGLE = 90
Public Const FMAX_VIEW_ANGLE = 130
Public Const FMIN_RANDOM_ANGLE = 45
Public Const FMAX_RANDOM_ANGLE = 89
Public Const FMIN_SEESAW_ANGLE = 63
Public Const FMAX_SEESAW_ANGLE = 88
Public Const FMIN_WOBBLE_ANGLE = 30
Public Const FMAX_WOBBLE_ANGLE = 55
Public Const FMIN_WOBBLE_ANGLE2 = 40
Public Const FMAX_WOBBLE_ANGLE2 = 80
Public Const MIN_ROT_STEP = 1
Public Const MAX_ROT_STEP = 20
Public Const FMAX_ZOOM = 5
Public Const MIN_FRAMES = 16
Public Const FILE_BUF_SIZE = 180
Public Const FLT_MAX = 3.402823466E+38
Public Const FLT_MIN = 1.175494351E-38
' number of calibration cycles
Public Const MAX_CALIBRATE = 2
Public Const PI = 3.14159265358979
Public Const PI_OVER_2 = PI / 2
Public Const PI_OVER_4 = PI / 4
Public Const MAX_IROT = 100               ' max integer rotation level (from slider)
Public Const MIN_SLIDER = 0
Public Const MAX_SLIDER = 100
Public Const MAX_DEMO = 2            ' max demo index
Public Const NUM_DEMOS = (MAX_DEMO + 1)
Public Const SIZE_LIST_LUT = 512
' Default texture resource
Public Const TEXQUAL_DEFAULT = 0
Public Const TEXQUAL_HIGH = 1

Type POINT2F
    x As Single
    y As Single
End Type
Type POINT3F
    x As Single
    y As Single
    z As Single
End Type
Type POINT2I
    x As Single
    y As Single
End Type
Type POINT3I
    x As Single
    y As Single
    z As Single
End Type





