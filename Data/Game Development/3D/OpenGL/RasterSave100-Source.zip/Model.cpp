#ifdef  _WIN32
#include <windows.h>
#endif//_WIN32

#include <stdio.h>
#include <GL/gl.h>

#include "Model.h"

//-----------------------------------------------------------------------------

// edge flags
#define EDGE_MASK   0x00E0
#define EDGE_AB     0x0020
#define EDGE_BC     0x0040
#define EDGE_CA     0x0080

//-----------------------------------------------------------------------------

Model::Model() {
    Reset();
}

Model::~Model() {
    Free();
}

void Model::Draw() const {
	if (_list[0]) {
		// draw from display list if available
		glCallList(_list[0]);
	} else if (_nfaces) {
		// first time, we build display list
		glNewList(_list[0]=glGenLists(1), GL_COMPILE_AND_EXECUTE);
		glBegin(GL_TRIANGLES);
			for (long n=0; n<_nfaces; n++) {
				int *f=&_face[n*4];
				glNormal3fv(&_norm[n*3]);
				glVertex3fv(&_vert[f[0]*3]);
				glVertex3fv(&_vert[f[1]*3]);
				glVertex3fv(&_vert[f[2]*3]);
			}
		glEnd();
		glEndList();
	}
}//Draw

void Model::DrawWire() const {
    if (!_nfaces) return;

	if (_list[1]) {
		// draw from display list if available
		glCallList(_list[1]);
	} else if (_nfaces) {
		// first time, we build display list
		glNewList(_list[1]=glGenLists(1), GL_COMPILE_AND_EXECUTE);
			glBegin(GL_LINES);
				for (long n=0; n<_nfaces; n++) {
					int *f=&_face[n*4], flags=f[3];
					float *a=&_vert[f[0]*3], *b=&_vert[f[1]*3], *c=&_vert[f[2]*3];
					if (flags & EDGE_AB) {
						glVertex3fv(a);
						glVertex3fv(b);
					}
					if (flags & EDGE_BC) {
						glVertex3fv(b);
						glVertex3fv(c);
					}
					if (flags & EDGE_CA) {
						glVertex3fv(c);
						glVertex3fv(a);
					}
				}
			glEnd();
		glEndList();
	}
}//DrawWire

bool Model::Load(const char *name) {
    // supports only ASE format so far
    return LoadASE(name);
}

void Model::Reset() {
    _vert   = NULL;
    _norm   = NULL;
    _face   = NULL;
    _nfaces = 0;
    _nverts = 0;
	_list[0]= 0;
	_list[1]= 0;
}

void Model::Free() {
    delete [] _vert;
    delete [] _norm;
    delete [] _face;
	if (_list[0]) glDeleteLists(_list[0],1);
	if (_list[1]) glDeleteLists(_list[1],1);
    Reset();
}

bool Model::LoadASE(const char *name) {
    Free();

    FILE *fp = fopen(name,"r");
    if (!fp) return false;

    int
        nVertex=0,
        nFaces =0;

    int   a,b,c, idx;
    float x,y,z;

    char line[256], *token;
    do {
        token = (fscanf(fp,"%255s",line)==1)?line:NULL;
        if (token) {
            if (!strcmp(token,"*MESH_VERTEX") && _vert) {
                //-- read mesh vertex
                if ((fscanf(fp, "%d %f %f %f", &idx, &x,&y,&z) == 4) &&
                    (idx >= 0) && (idx < nVertex)
                ) {
                    float *v = &_vert[idx*3];
                    v[0]=x; v[1]=y; v[2]=z;
                }
            } else if (!strcmp(token,"*MESH_FACE")) {
                //-- read mesh face
                if ((fscanf(fp,"%d: A: %d B: %d C: %d", &idx, &a,&b,&c) == 4) &&
                    (idx >= 0) && (idx < nFaces)
                ) {
                    // store the face (3 vertex indices)
                    int *f = &_face[idx*4];
                    f[0]=a; f[1]=b; f[2]=c;

                    // check visible edges
                    int ab,bc,ca;
                    if (fscanf(fp, "%*s %d %*s %d %*s %d", &ab,&bc,&ca)==3) {
                        // ignored: smoothing group ID
                        // ignored: mesh mtlid
                        // store edge flags
                        f[3]= (ab?EDGE_AB:0) | (bc?EDGE_BC:0) | (ca?EDGE_CA:0);
                    } else
                        f[3]=0;
                }
            } else if (!strcmp(token,"*MESH_FACENORMAL")) {
                //-- read face normal
                if ((fscanf(fp, "%d %f %f %f", &idx, &x,&y,&z) == 4) &&
                    (idx >= 0) && (idx < nFaces)
                ) {
                    float *n = &_norm[idx*3];
                    n[0]=x; n[1]=y; n[2]=z;
                }
            } else if (!strcmp(token,"*MESH_NUMVERTEX") && !_vert) {
                //-- read no.of vertices
                if (fscanf(fp,"%d",&nVertex)==1) {
                    // allocate storage
                    _vert = new float[3*nVertex];
                } else
                    nVertex = 0;
            } else if (!strcmp(token,"*MESH_NUMFACES") && !_face) {
                //-- read no.of faces
                if (fscanf(fp,"%d",&nFaces)==1) {
                    // allocate storage
                    _face = new int[4*nFaces];
                    _norm = new float[3*nFaces];
                } else
                    nFaces = 0;
            } else {
                // unknown / unhandled token type - ignore
            }
        }//if(token)
    } while (token);

    fclose(fp);

    _nfaces = nFaces;
    _nverts = nVertex;
    if (!_nfaces || !_nverts) Free();

    return (_vert!=NULL);
}//LoadASE
