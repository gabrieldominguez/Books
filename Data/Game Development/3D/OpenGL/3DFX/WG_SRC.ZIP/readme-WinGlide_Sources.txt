Notes from the Author
---------------------

Although it's old, the WinGlide code is the only thing I have in okay shape
for a good release without spending too much time working on it.  You can
release it to the public if you want to and think it's a good idea.  There
are a few things that should be listed with it too.

- Based on WinGlide v0.5 source, written by Justin Frankel of Nullsoft.
- It's the Voodoo/Voodoo2 in a window hack, rather than complete Glide drivers.
- The cwdohnal@ucdavis.edu email address does not work anymore.
- There are some thread synchronization bugs with the gamma correction
  dialog box.  They're fairly unlikely to cause problems, but it's still bad
  that they're there.  I never fixed them as I discovered them a while after
  the final release and it was only a side feature (also never encountered a
  failure, just know that it is possible).

wg_src.zip is the original glide2x compatible one.  wg3x_src.zip is for the
glide3x version.  The glide3x version also has some header files in the
g3inc directory.  I can't remember for sure, but I might have put these
there to prevent header file conflicts with the 2x one.  There's a very
slight chance I deleted an incorrect file when deleting some of the extra
compiler generated stuff and I didn't do a complete build test on it since I
don't have Glide header and library files installed anymore.

Chris Dohnal
cwdohnal@mindspring.com