/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

using Tao.OpenGl;

namespace BooGame
{
	/// <summary>
	/// Represents a 2D tile map.
	/// </summary>
	[Serializable]
	public class Map : Entity
	{
		private AnimationCollection m_Animations = new AnimationCollection();
		/// <summary>
		/// Animations directly relating to the map.
		/// </summary>
		public AnimationCollection Animations
		{
			get{ return m_Animations; }
		}

        /// <summary>
        /// Creates a new map with the given width and height.
        /// </summary>
        /// <param name="width">The width of the tile map.</param>
        /// <param name="height">The height of the tile map.</param>
		public Map(int width, int height)
		{
			m_Tiles = new Tile[width, height];
		}

        /// <summary>
        /// Creates a 10x10 tile map.
        /// </summary>
		public Map() : this(10,10)
		{
		}


		#region IEntity Members

        /// <summary>
        /// Gets and sets the entire width of the tile map.
        /// </summary>
		public override float Width
		{
			get
            {
                return (float)m_TileWidth * (float)MapWidth * this.ScaleX;
			}
			set
			{
				this.ScaleX = value / (float)(m_TileWidth * MapWidth);
			}
		}

        /// <summary>
        /// Gets and sets the entire height of the tile map.
        /// </summary>
		public override float Height
		{
			get
			{
                return (float)TileOverlap * (float)MapHeight * this.ScaleY;
			}
			set
			{
                this.ScaleY = value / (float)(TileOverlap * MapHeight);
			}
		}

        private int m_TileWidth = 0;
        private int m_TileHeight = 0;
        /// <summary>
        /// Gets the width of each tile.
        /// </summary>
        public int TileWidth
        {
            get
            {
                return m_TileWidth;
            }
        }
        /// <summary>
        /// Gets the height of each tile.
        /// </summary>
        public int TileHeight
        {
            get
            {
                return m_TileHeight;
            }
        }

        /// <summary>
        /// Gets the number of tiles wide the map is.
        /// </summary>
		public int MapWidth
		{
			get
			{
				return m_Tiles.GetLength(0);
			}
		}
        /// <summary>
        /// Gets the number of tiles high the map is.
        /// </summary>
		public int MapHeight
		{
			get
			{
				return m_Tiles.GetLength(1);
			}
		}

        /// <summary>
        /// Gets and sets the tile at the given index on the map.
        /// </summary>
        /// <param name="index">The index of the tile.</param>
        /// <returns>The tile at the given location.</returns>
        public Tile this[int index]
        {
            get
            {
                int tilesWide = MapWidth;
                int x = index % tilesWide;
                return m_Tiles[x, (index - x) / tilesWide];
            }
            set
            {
                int tilesWide = MapWidth;
                int x = index % tilesWide;
                m_Tiles[x, (index - x) / tilesWide] = value;
            }
        }

		/// <summary>
		/// Gets and sets the tile at the given location.
		/// </summary>
		/// <param name="x">The x coordinate of the tile.</param>
		/// <param name="y">The y coordinate of the tile.</param>
		/// <returns>The tile at the wanted location.</returns>
		public Tile this[int x, int y]
		{
			get
			{
				return m_Tiles[x,y];
			}
			set
			{
				m_Tiles[x,y] = value;
			}
		}
		
        /// <summary>
        /// Fills the map up with the given tile.
        /// </summary>
        /// <param name="tile">The tile to fill the map.</param>
		public void Fill(Tile tile)
		{
			int mapWidth = MapWidth;
			int mapHeight = MapHeight;
			for(int x = 0; x < mapWidth; x++)
				for(int y = 0; y < mapHeight; y++)
					m_Tiles[x,y] = new Tile(tile);
		}
		
		private Tile[,] m_Tiles;
        /// <summary>
        /// Gets an array representing all the tiles on the map.
        /// </summary>
		public Tile[,] Tiles
		{
			get
			{
				return m_Tiles;
			}
		}

        /// <summary>
        /// Draws the map onto the screen.
        /// </summary>
		public override void Draw()
		{
			if(!Visible)
				return;
			Gl.glPushMatrix();
			
			//CAMERA
			if(IsWorldObject)
				Camera.ApplyMatrix();

			// Location
            Gl.glTranslatef((int)this.X, (int)this.Y, 0f);

			// Rotation
			Gl.glRotatef(this.Rotation, 0f, 0f, 1f);

			// Stretch
			Gl.glScalef(this.ScaleX, this.ScaleY, 1f);

			// Hotspot
			Gl.glTranslatef(-this.HotSpot.X, -this.HotSpot.Y, 0f);

            // Alpha and diffuse
            Gl.glColor4f(Tint.R, Tint.G, Tint.B, Alpha);

			int layerWidth = MapWidth;
			int layerHeight = MapHeight;

			for(int x = 0; x < layerWidth; x++)
			{
				for(int y = 0; y < layerHeight; y++)
				{
					Tile tile = m_Tiles[x,y];
                    if (tile != null)
                    {
                        TileSet tileset = tile.TileSet;
                        if (tileset != null)
                            tileset.QuickDraw(tile.TileX, tile.TileY, tileset.TileWidth * x, TileOverlap * y);
                    }
				}
			}
			
			Gl.glPopMatrix();
		}

        /// <summary>
        /// Updates the map and its tile contents.
        /// </summary>
		public override void Update()
		{
            if (Enabled)
            {
                foreach (Tile tile in m_Tiles)
                    if (tile != null)
                        tile.Update();

                base.Update();
            }
		}

		#endregion

        private int m_TileOverlap = 0;
        /// <summary>
        /// Gets and sets the vertical overlap of tiles on this map.
        /// </summary>
        /// <remarks>If it is 0, it is defaulted to the height of the tiles.</remarks>
        public int TileOverlap
        {
            get
            {
                if(m_TileOverlap == 0)
                    return m_TileHeight;
                return m_TileOverlap;
            }
            set
            {
                m_TileOverlap = value;
            }
        }

        /// <summary>
        /// Gets the tile at the given location.
        /// </summary>
        /// <param name="x">The x coordinate.</param>
        /// <param name="y">The y coordinate.</param>
        /// <param name="byLocation">If the x and y location represents the actual physical location of the tile.</param>
        /// <returns>The located tile, otherwise null.</returns>
        public Tile GetTile(float x, float y, bool byLocation)
        {
            if (byLocation)
            {
                x = (x - this.X - this.HotSpot.X) / this.TileWidth * this.ScaleX;
                y = (y - this.Y - this.HotSpot.Y) / this.TileHeight * this.ScaleY;
            }
            if ((x < 0) || (y < 0) || (x >= MapWidth) || (y >= MapHeight))
            {
                return null;
            }
            return m_Tiles[(int)x, (int)y];
        }

        /// <summary>
        /// Gets the location and size of the tile at the given location.
        /// </summary>
        /// <param name="x">The x coordinate.</param>
        /// <param name="y">The y coordinate.</param>
        /// <param name="byLocation">If the x and y location represents the actual physical location of the tile.</param>
        /// <returns>A rectangle representing the tile's coordinates, otherwise an empty rectangle.</returns>
        public RectangleF GetTileLocation(float x, float y, bool byLocation)
        {
            if (byLocation)
            {
                x = (x - this.X - this.HotSpot.X) / this.TileWidth * this.ScaleX;
                y = (y - this.Y - this.HotSpot.Y) / this.TileHeight * this.ScaleY;
            }
            if ((x < 0) || (y < 0) || (x >= MapWidth) || (y >= MapHeight))
            {
                return RectangleF.Empty;
            }
            return new RectangleF(
                this.TileWidth * (int)x * this.ScaleX + this.X - this.HotSpot.X,
                this.TileHeight * (int)y * this.ScaleY + this.Y - this.HotSpot.Y,
                this.TileWidth * this.ScaleX,
                this.TileHeight * this.ScaleY);
        }

		/// <summary>
		/// Sets the data of the tile map.
		/// </summary>
        /// <remarks>This is used for Tile Studio support.</remarks>
		/// <param name="tileset"></param>
		/// <param name="data"></param>
		/// <param name="mapCodes"></param>
		/// <param name="bounds"></param>
		public void SetData(TileSet tileset, int[] data, byte[] mapCodes, byte[] bounds)
		{
			int mapWidth = m_Tiles.GetLength(0);
			int mapHeight = m_Tiles.GetLength(1);
            m_TileWidth = tileset.TileWidth;
            m_TileHeight = tileset.TileHeight;
			int index = 0;
			TileCollection tiles = new TileCollection(tileset);
			index = 0;
			for(int y = 0; y < mapHeight; y++)
			{
				for(int x = 0; x < mapWidth; x++)
				{
                    switch (data[index].CompareTo(0))
                    {
                        case -1: // animated tile
                            int animationIndex = Math.Abs(data[index]) - 1;
                            if (this.Animations.Count > animationIndex)
                            {
                                m_Tiles[x, y] = new AnimatedTile(this.Animations[animationIndex]);
                            }
                            else
                            {
                                m_Tiles[x, y] = new Tile(); //empty tile
                            }
                            break;
                        case 0: // blank
                            m_Tiles[x, y] = new Tile(); //empty tile
                            break;
                        case 1: // normal tile
                            m_Tiles[x, y] = new Tile(tiles[data[index] - 1]);
                            break;
                    }
					index++;
				}
			}

			// set map codes
			if(mapCodes != null)
			{
				index = 0;
				for(int y = 0; y < mapHeight; y++)
				{
					for(int x = 0; x < mapWidth; x++)
					{
						m_Tiles[x,y].MapCode = mapCodes[index];
						index++;
					}
				}
			}

			// set map codes
			if(bounds != null)
			{
				index = 0;
				for(int y = 0; y < mapHeight; y++)
				{
					for(int x = 0; x < mapWidth; x++)
					{
						m_Tiles[x,y].Bounds = (TileBounds)bounds[index];
						index++;
					}
				}
			}
		}

        /// <summary>
        /// Loads a map from a Tile Studio code outputed file.
        /// </summary>
        /// <param name="filename">The tile map file to load.</param>
        /// <returns>The new generated map.</returns>
		public static Map FromFile(string filename)
		{
			Script script = new Script(filename);
			script.Compile();
			return (Map)script.Invoke("Script", "CreateMap", null, null);
		}

	}

    /// <summary>
    /// Describes a tile's boundries.
    /// </summary>
	public enum TileBounds
	{
		// TODO: Debug it and see if this is correct
        /// <summary>
        /// No tile bounds.
        /// </summary>
		None = 0,
        /// <summary>
        /// The top edge has the boundry.
        /// </summary>
		Top = 0x01,
        /// <summary>
        /// The right edge has the boundry.
        /// </summary>
		Right = 0x02, // Left
        /// <summary>
        /// The bottom edge has the boundry.
        /// </summary>
		Bottom = 0x04,
        /// <summary>
        /// The left edge has the boundry.
        /// </summary>
		Left = 0x08, // Right
        /// <summary>
        /// The boundry goes through the middle starting at the bottom left and going to the top right.
        /// </summary>
        DiagonalUp = 0x80,
        /// <summary>
        /// The boundry goes through the middle starting at the top left and going to the bottom right.
        /// </summary>
		DiagonalDown = 0x80 | Top
	}
}
