VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CWave"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION:Demonstrates the palette in the ocx when in 256
'   color mode. Demonstrates color index mode.
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY: fixed SetColorMap to build a palette and
'   'set it in the ocx.
'   'index mode draws now, but I don't think all the
'   'index stuff in 256 colors is right.
'/*************************************************************************
Dim m_MatFront As glxMaterial
Dim m_MatBack As glxMaterial
Dim m_bTexture As Boolean
'#define PI 3.14159265358979323846
Dim clearMask&
Dim Contouring&
Dim WidthX&, WidthY&
Dim theMesh As glwMesh
Dim contourTexture1(0 To 15) As Byte
Dim contourTexture2(0 To 15) As Byte
'Dim colorIndexes1&(0 To 2)
'Dim colorIndexes2&(0 To 2)

Private Sub Class_Initialize()
Dim i&
FillArrayb contourTexture1, _
    255, 255, 255, 255, _
    255, 255, 255, 255, _
    255, 255, 255, 255, _
    127, 127, 127, 127
FillArrayb contourTexture2, _
    255, 255, 255, 255, _
    255, 127, 127, 127, _
    255, 127, 127, 127, _
    255, 127, 127, 127
'
    'comment out this to have it build a palette
    'optRGB = True
    optLighting = True
    WidthX = 10
    WidthY = 10

End Sub

Public Sub Init()
    If optRGB = 0 Then
    gCtl.pfPixelType = PFD_TYPE_COLORINDEX
    End If
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    glShadeModel GL_FLAT
    glFrontFace GL_CW
    glEnable GL_DEPTH_TEST
    '
    gCtl.ClearMode = clrBoth
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
        .TwoSide = True
    End With
    With gCtl.Camera
        .FarPlane = 10
        .NearPlane = 0.01
        .FieldOfView = 45 '???
        .SetEyePos 0, 0, 2
        .SetTargetPos 0, 0, 0
    End With
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
    End With
    '
    InitMaterials
    InitTexture
    Set theMesh = New glwMesh
    theMesh.Init WidthX, WidthY
End Sub

Public Sub Draw()
    With gCtl
        .Trackball.Update
    End With
    glTranslatef 0, 0.4, -1.8
    glScalef 2, 2, 2
    glRotatef -35, 1, 0, 0
    glRotatef 35, 0, 0, 1
    theMesh.Animate
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub Key(KeyCode%)
Dim s$
Dim map!(0 To 3)
    s = Chr$(KeyCode)
    Select Case (s)
    Case "X":  '  zRotation = zRotation + 5
    Case "x":  '  zRotation = zRotation - 5
    Case "c":
        Contouring = Contouring + 1
        map(2) = 20 '= {0, 0, 20, 0};
        If (Contouring = 1) Then
            
            glTexImage2D GL_TEXTURE_2D, 0, 1, 4, 4, 0, GL_LUMINANCE, _
                 GL_UNSIGNED_BYTE, contourTexture1(0)
            glTexGeni GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
            glTexGeni GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
            glTexGenfv GL_S, GL_OBJECT_PLANE, map(0)
            glTexGenfv GL_T, GL_OBJECT_PLANE, map(0)
            glEnable GL_TEXTURE_2D
            glEnable GL_TEXTURE_GEN_S
            glEnable GL_TEXTURE_GEN_T
        ElseIf (Contouring = 2) Then
            glTexGeni GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR
            glTexGeni GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR
            glPushMatrix
            glMatrixMode GL_MODELVIEW
            glLoadIdentity
            glTexGenfv GL_S, GL_EYE_PLANE, map(0)
            glTexGenfv GL_T, GL_EYE_PLANE, map(0)
            glPopMatrix
        Else
            Contouring = 0
            glDisable GL_TEXTURE_GEN_S
            glDisable GL_TEXTURE_GEN_T
            glDisable GL_TEXTURE_2D
        End If
    Case "s":
        optSmooth = Not optSmooth
        If (optSmooth) Then
            glShadeModel GL_SMOOTH
        Else
            glShadeModel GL_FLAT
        End If
    Case "l":
        optLighting = Not optLighting
        If (optLighting) Then
            glEnable GL_LIGHTING
            glEnable GL_LIGHT0
            If (optRGB) Then
                glEnable GL_COLOR_MATERIAL
            End If
        Else
            glDisable GL_LIGHTING
            glDisable GL_LIGHT0
            If (optRGB) Then
                glDisable GL_COLOR_MATERIAL
            End If
        End If
    Case "d":
        optDepth = Not optDepth
        If (optDepth) Then
            glEnable GL_DEPTH_TEST
            clearMask = clearMask Or GL_DEPTH_BUFFER_BIT
            gCtl.ClearMode = clrBoth
        Else
            glDisable GL_DEPTH_TEST
            clearMask = clearMask And Not GL_DEPTH_BUFFER_BIT
            gCtl.ClearMode = clrColor
        End If
    Case " ":
        optStepMode = Not optStepMode
        If (optStepMode) Then
            'glutIdleFunc (0)
            'glutDisplayFunc(Animate);
        Else
            'glutIdleFunc(Animate);
            'glutDisplayFunc(0);
        End If
    Case "n":
        If (optStepMode) Then
            theMesh.NextFrame = 1
        End If
    Case "a":
        optSpinMode = Not optSpinMode
    End Select
End Sub


Public Function SetColorMap&()
Dim pPal As LOGPALETTE
Dim hPal&, Count&, i&, j&
Dim Color!(0 To 2)
Dim percent!
Dim indexes&(0 To 2)
    colorIndexes(1).p(0) = 1
    colorIndexes(1).p(1) = 255 * 0.3
    colorIndexes(1).p(2) = 128
    colorIndexes(2).p(0) = 128
    colorIndexes(2).p(1) = 255 * 0.8
    colorIndexes(2).p(2) = 255
    Count = 256
    pPal.palVersion = &H300
    pPal.palNumEntries = Count
    For i = 0 To 1
        Select Case i
          Case 0:        'Color = green
            Color(0) = 0.2
            Color(1) = 1
            Color(2) = 0.2
            indexes(0) = 1
            indexes(1) = 255 * 0.3
            indexes(2) = 128
          Case 1:        'Color = red
            Color(0) = 1
            Color(1) = 0.2
            Color(2) = 0.2
            indexes(0) = 128
            indexes(1) = 255 * 0.8
            indexes(2) = 255
        End Select
        For j = indexes(0) To indexes(1) - 1
            percent = 255 * (0.2 + 0.8 * (j - indexes(0)) / (indexes(1) - indexes(0)))
            'don't do this in a loop, it's very slow
            'gCtl.Palette.SetColor j + 10, percent * Color(0), percent * Color(1), percent * Color(2)
            pPal.palPalEntry(j).peRed = percent * Color(0)
            pPal.palPalEntry(j).peGreen = percent * Color(1)
            pPal.palPalEntry(j).peBlue = percent * Color(2)
            pPal.palPalEntry(j).peFlags = PC_NOCOLLAPSE
        Next j
        For j = indexes(1) To indexes(2) - 1
            percent = 255 * ((j - indexes(1)) / (indexes(2) - indexes(1)))
            pPal.palPalEntry(j).peRed = percent * (1 - Color(0)) + Color(0)
            pPal.palPalEntry(j).peGreen = percent * (1 - Color(1)) + Color(1)
            pPal.palPalEntry(j).peBlue = percent * (1 - Color(2)) + Color(2)
            pPal.palPalEntry(j).peFlags = PC_NOCOLLAPSE
        Next j
    Next i
    hPal = CreatePalette(pPal)
    If hPal Then gCtl.Palette.SetPalette hPal
End Function



Public Sub InitMaterials()
Set m_MatFront = gCtl.NewMaterial
Set m_MatBack = gCtl.NewMaterial
    With m_MatFront
        .Face = faceFront
        .SetDiffuse 1, 1, 0.2
        .SetSpecular 0.5, 0.5, 0.2
        .SpecExp = 60
        .SetMaterial
    End With

    With m_MatBack
        .Face = faceBack
        .SetDiffuse 0.5, 0.28, 0.38
        .SetSpecular 0.2, 0.2, 0.2
        .SpecExp = 60
        .SetMaterial
    End With

    If (optRGB) Then
        glColorMaterial GL_FRONT_AND_BACK, GL_DIFFUSE
    End If
    If (optRGB) Then
        glEnable GL_COLOR_MATERIAL
    Else
        SetColorMap
    End If

End Sub

Public Sub InitTexture()
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
    glTexEnvf GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
End Sub




