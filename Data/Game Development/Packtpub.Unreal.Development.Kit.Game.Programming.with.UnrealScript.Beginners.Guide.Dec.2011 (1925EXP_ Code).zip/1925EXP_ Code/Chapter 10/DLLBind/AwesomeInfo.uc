class AwesomeInfo extends Info
    placeable
    DLLBind(AwesomeDLL);

dllimport final function DLLFunction(string s);

simulated function PostBeginPlay()
{
    local string s;
    s = "Hi DLL!";
    DLLFunction(s);
}

defaultproperties
{
}
