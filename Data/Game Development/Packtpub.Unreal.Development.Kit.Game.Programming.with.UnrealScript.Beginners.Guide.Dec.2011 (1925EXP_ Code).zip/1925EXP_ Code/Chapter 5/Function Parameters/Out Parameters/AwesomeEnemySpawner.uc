class AwesomeEnemySpawner extends AwesomeActor
    placeable;

var TestEnemy MySpawnedEnemy;

function PostBeginPlay()
{
    local float MyF;
    local int MyI;

    super.PostBeginPlay();

    DoSomething(MyF, MyI);
    `log(MyF @ MyI);
}

function DoSomething(out float MyFloat, out int MyInt)
{
    MyFloat = 5.0;
    MyInt = 18;
}

function SpawnEnemy()
{
    MySpawnedEnemy = spawn(class'TestEnemy', self,, Location);
}

function EnemyDied()
{
    SpawnEnemy();
}

function FreezeEnemy()
{
    if(MySpawnedEnemy != none)
        MySpawnedEnemy.Freeze();
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}