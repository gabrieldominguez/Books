Attribute VB_Name = "glxSubClass"
Option Explicit

Public Function WndProc(ByVal hWnd As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
    WndProc = UC.Palette.PaletteProc(hWnd, msg, wParam, lParam)
End Function

