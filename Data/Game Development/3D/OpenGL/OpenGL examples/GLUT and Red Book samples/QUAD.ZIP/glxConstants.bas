Attribute VB_Name = "mConstants"
Option Explicit
Public Const RD = 1
Public Const WT = 2

Public gCtl As glxCtl
Public CX As CQuad
'
Public Const PI = 3.141592654
Public Const M_PI = 3.14159265358979
Public xRotation!, yRotation!
Public zRotation!, zTranslation!
Public Const black = 0
Public Const gray = 128
Public Const white = 255
Public Const brickImageWidth = 16
Public Const brickImageHeight = 16
Public clrRed&(0 To 3) ' =0xA4,0x00,0x00,0xFF
Public clrWhite&(0 To 3) ' =0xFF,0xFF,0xFF,0xFF
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        If v = RD Then
            a(i) = clrRed&(0)
            a(i + 1) = clrRed&(1)
            a(i + 2) = clrRed&(2)
            a(i + 3) = clrRed&(3)
        Else
            a(i) = clrWhite&(0)
            a(i + 1) = clrWhite&(1)
            a(i + 2) = clrWhite&(2)
            a(i + 3) = clrWhite&(3)
        End If
        i = i + 4
    Next
End Sub


'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub



