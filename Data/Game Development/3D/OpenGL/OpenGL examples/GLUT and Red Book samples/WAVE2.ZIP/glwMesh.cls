VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "glwMesh"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Dim m_widthX As Long
Dim m_widthY As Long
Dim m_NumFacets As Long
Dim m_NumCoords As Long
Dim m_NumFrames As Long
Dim m_Coords() As Coordinate
Dim m_Facets() As Facet
Dim m_Height!
Dim m_CheckerSize&
Dim m_CurFrame&, m_NextFrame&

Private Sub Class_Initialize()
    m_NumFrames = 10
    m_Height = 0.2
    m_CheckerSize = 2
End Sub

Public Sub Init(WidthX&, WidthY&)
Dim cn&, fn&
Dim dp1!(0 To 2), dp2!(0 To 2)
Dim pt1&, pt2&, pt3& '***;
Dim angle!, d!, x!, y!
Dim numFacets&, numCoords&, frameNum&, i&, j&

    m_widthX = WidthX
    m_widthY = WidthY

    numFacets = m_widthX * m_widthY
    numCoords = (m_widthX + 1) * (m_widthY + 1)

    m_NumCoords = numCoords
    m_NumFacets = numFacets

    ReDim m_Coords(0 To m_NumFrames * m_NumCoords - 1)
    ReDim m_Facets(0 To m_NumFrames * m_NumFacets - 1)

    For frameNum = 0 To m_NumFrames - 1
    For i = 0 To m_widthX
        x = i / m_widthX
        For j = 0 To m_widthY
            y = j / m_widthY
            d = Sqr(x * x + y * y)
            If (d = 0) Then
                d = 0.0001
            End If
            angle = 2 * PI * d + (2 * PI / m_NumFrames * frameNum)
    
            cn = m_GetCoord(frameNum, i, j)
    
            m_Coords(cn).Vertex(0) = x - 0.5
            m_Coords(cn).Vertex(1) = y - 0.5
            m_Coords(cn).Vertex(2) = (m_Height - m_Height * d) * Cos(angle)
    
            m_Coords(cn).Normal(0) = -(m_Height / d) * x * ((1 - d) * 2 * PI * _
                       Sin(angle) + Cos(angle))
            m_Coords(cn).Normal(1) = -(m_Height / d) * y * ((1 - d) * 2 * PI * _
                       Sin(angle) + Cos(angle))
            m_Coords(cn).Normal(2) = -1
    
            d = 1 / Sqr(m_Coords(cn).Normal(0) * m_Coords(cn).Normal(0) + _
                       m_Coords(cn).Normal(1) * m_Coords(cn).Normal(1) + 1)
            m_Coords(cn).Normal(0) = m_Coords(cn).Normal(0) * d
            m_Coords(cn).Normal(1) = m_Coords(cn).Normal(1) * d
            m_Coords(cn).Normal(2) = m_Coords(cn).Normal(2) * d
        Next j
    Next i
    For i = 0 To m_widthX - 1
    For j = 0 To m_widthY - 1
        fn = m_GetFacet(frameNum, i, j)
        'If (((i / m_CheckerSize) Mod 2) ^ ((j / m_CheckerSize))) Mod 2 Then
        If (i + j) Mod 2 Then
            If (optRGB) Then
            m_Facets(fn).Color(0) = 1
            m_Facets(fn).Color(1) = 0.2
            m_Facets(fn).Color(2) = 0.2
            Else
            m_Facets(fn).Color(0) = colorIndexes(1).p(0)
            m_Facets(fn).Color(1) = colorIndexes(1).p(1)
            m_Facets(fn).Color(2) = colorIndexes(1).p(2)
            End If
        Else
            If (optRGB) Then
            m_Facets(fn).Color(0) = 0.2
            m_Facets(fn).Color(1) = 1
            m_Facets(fn).Color(2) = 0.2
            Else
            m_Facets(fn).Color(0) = colorIndexes(2).p(0)
            m_Facets(fn).Color(1) = colorIndexes(2).p(1)
            m_Facets(fn).Color(2) = colorIndexes(2).p(2)
            End If
        End If
        '
        pt1 = m_GetCoord(frameNum, i, j)
        pt2 = m_GetCoord(frameNum, i, j + 1)
        pt3 = m_GetCoord(frameNum, i + 1, j + 1)

        dp1(0) = m_Coords(pt2).Vertex(0) - m_Coords(pt1).Vertex(0)
        dp1(1) = m_Coords(pt2).Vertex(1) - m_Coords(pt1).Vertex(1)
        dp1(2) = m_Coords(pt2).Vertex(2) - m_Coords(pt1).Vertex(2)

        dp2(0) = m_Coords(pt3).Vertex(0) - m_Coords(pt2).Vertex(0)
        dp2(1) = m_Coords(pt3).Vertex(1) - m_Coords(pt2).Vertex(1)
        dp2(2) = m_Coords(pt3).Vertex(2) - m_Coords(pt2).Vertex(2)

        m_Facets(fn).Normal(0) = dp1(1) * dp2(2) - dp1(2) * dp2(1)
        m_Facets(fn).Normal(1) = dp1(2) * dp2(0) - dp1(0) * dp2(2)
        m_Facets(fn).Normal(2) = dp1(0) * dp2(1) - dp1(1) * dp2(0)

        d = 1 / Sqr(m_Facets(fn).Normal(0) * m_Facets(fn).Normal(0) + _
                   m_Facets(fn).Normal(1) * m_Facets(fn).Normal(1) + _
                   m_Facets(fn).Normal(2) * m_Facets(fn).Normal(2))

        m_Facets(fn).Normal(0) = m_Facets(fn).Normal(0) * d
        m_Facets(fn).Normal(1) = m_Facets(fn).Normal(1) * d
        m_Facets(fn).Normal(2) = m_Facets(fn).Normal(2) * d
    Next j
    Next i
    Next frameNum
End Sub



Public Property Get NumFrames() As Long
NumFrames = m_NumFrames
End Property

Public Property Let NumFrames(ByVal NewValue As Long)
m_NumFrames = NewValue
End Property

Public Property Get NextFrame() As Long
NextFrame = m_NextFrame
End Property

Public Property Let NextFrame(ByVal NewValue As Long)
m_NextFrame = NewValue
End Property

Public Property Get WidthX() As Long
WidthX = m_widthX
End Property

Public Property Get WidthY() As Long
WidthY = m_widthY
End Property

Public Sub Animate()
Dim i&, j&
Dim cn&, fn&
Dim lastcolor& '
Dim thisColor& '
    If (m_NextFrame Or optStepMode = 0) Then
        m_CurFrame = m_CurFrame + 1
    End If
    If (m_CurFrame >= m_NumFrames) Then
        m_CurFrame = 0
    End If
    If ((m_NextFrame Or optStepMode = 0) And optSpinMode) Then
        glRotatef 5, 0, 0, 1
    End If
    m_NextFrame = 0
    For i = 0 To m_widthX - 1
        glBegin GL_QUAD_STRIP
        lastcolor = -1 'NULL
        For j = 0 To m_widthY - 1
            fn = m_GetFacet(m_CurFrame, i, j)
            If optSmooth = 0 And optLighting Then
                glNormal3fv m_Facets(fn).Normal(0)
            End If
            If (optLighting) Then
                If (optRGB) Then
                    thisColor = fn 'Face.Color
                    glColor3fv m_Facets(fn).Color(0)
                Else
                    thisColor = fn 'Face.Color
                    glMaterialfv GL_FRONT_AND_BACK, GL_COLOR_INDEXES, m_Facets(fn).Color(0)
                End If
            Else
                If (optRGB) Then
                    thisColor = fn 'Face.Color
                    glColor3fv m_Facets(fn).Color(0)
                Else
                    thisColor = fn 'Face.Color
                    '
                    glIndexf m_Facets(fn).Color(1) + 10
                End If
            End If
    
            If lastcolor = -1 Then
            ElseIf (m_Facets(thisColor).Color(0) <> m_Facets(lastcolor).Color(0) And optSmooth) Then
            Else: GoTo skip
            End If
           
                If (lastcolor > -1) Then
                    glEnd
                    glBegin GL_QUAD_STRIP
                End If
                cn = m_GetCoord(m_CurFrame, i, j)
                If (optSmooth And optLighting) Then
                    glNormal3fv m_Coords(cn).Normal(0)
                End If
                glVertex3fv m_Coords(cn).Vertex(0)
    
                cn = m_GetCoord(m_CurFrame, i + 1, j)
                If (optSmooth And optLighting) Then
                    glNormal3fv m_Coords(cn).Normal(0)
                End If
                glVertex3fv m_Coords(cn).Vertex(0)
skip:
            
            cn = m_GetCoord(m_CurFrame, i, j + 1)
            If (optSmooth And optLighting) Then
                glNormal3fv m_Coords(cn).Normal(0)
            End If
            glVertex3fv m_Coords(cn).Vertex(0)
    
            cn = m_GetCoord(m_CurFrame, i + 1, j + 1)
            If (optSmooth And optLighting) Then
                glNormal3fv m_Coords(cn).Normal(0)
            End If
            glVertex3fv m_Coords(cn).Vertex(0)
    
            lastcolor = thisColor
        Next
    glEnd
    Next
End Sub

Private Function m_GetCoord&(frame&, x&, y&)
m_GetCoord = frame * m_NumCoords + x + y * (m_widthX + 1)
End Function

Private Function m_GetFacet&(frame&, x&, y&)
m_GetFacet = frame * m_NumFacets + (x) + (y * WidthX)
End Function



