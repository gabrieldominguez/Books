class AwesomePlayerController extends UTPlayerController;

var AwesomeActor MyAwesomeActor;

var vector PlayerViewOffset;

simulated function PostBeginPlay()
{
    super.PostBeginPlay();
    bNoCrosshair = true;
}

exec function StartFire( optional byte FireModeNum )
{
    super.StartFire(FireModeNum);

    MyAwesomeActor = spawn(class'AwesomeActor',,, Pawn.Location);
    `log(MyAwesomeActor @ "<-- MyAwesomeActor");

    if(UberActor(MyAwesomeActor) != none)
        UberActor(MyAwesomeActor).UberFunction();
    else
        `log("MyAwesomeActor is not an UberActor.");
}

simulated event GetPlayerViewPoint(out vector out_Location, out Rotator out_Rotation)
{
    super.GetPlayerViewPoint(out_Location, out_Rotation);

    if(Pawn != none)
    {
        Pawn.Mesh.SetOwnerNoSee(false);
        if(Pawn.Weapon != none)
            Pawn.Weapon.SetHidden(true);

        out_Location = Pawn.Location + PlayerViewOffset;
        out_Rotation = rotator(Pawn.Location - out_Location);
    }
}

function Rotator GetAdjustedAimFor( Weapon W, vector StartFireLoc )
{
    return Pawn.Rotation;
}

defaultproperties
{
    PlayerViewOffset=(X=-64,Y=0,Z=1024)
}
