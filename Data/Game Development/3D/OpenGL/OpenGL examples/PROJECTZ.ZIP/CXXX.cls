VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'----------------------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY: - updated Oct 98
'   Feb 99 - changed it to not use a timer
'NOTES: The quadobj is just for testing.
'----------------------------------------------------------------------------
Dim m_Mat As glxMaterial
Dim QuadObj&, QID&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&

Private Sub Class_Initialize()
'
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.1
        .FieldOfView = 45
        .SetEyePos -1, 3, 10
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetSpecular 0.6, 0.8, 0.8
        .SpecExp = 120
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .Axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
    QuadObj = gluNewQuadric
    QID = 1 'name for the ball
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    
End Sub

Public Sub Draw()
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    glLoadName QID
    m_Mat.SetMaterial
    gluSphere QuadObj, 1, 16, 16
    CheckError
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If m_bMoving Then
        End If
        gCtl.Render
    ElseIf Button = 2 Then
        gCtl.Render
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, Z#, z1#, z2#
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    Z = FLOAT_MAX ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                z1 = ULong(items(ptr))
                Debug.Print " z1 = " & z1
                ptr = ptr + 1
            '3.z2
                z2 = ULong(items(ptr))
                Debug.Print " z2 = " & z2
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < Z Then
                        Z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub







