VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxGlyphs"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'---------------------------------------------------------------------------------
'FUNCTION: this class is a collection of chars in a particular font
'The class handles the creation of a font display list.
'It is extensively modified from the original SDK sample.
'The class manages font creation and the conversion of a string into a
'display list.
'AUTHOR: adapted by edx - edx@hk.super.net, Feb 98
'   - derived from 3dText SDK sample
'HISTORY: - moved to glxCtl, April 98
'
'---------------------------------------------------------------------------------

Dim mCol As Collection
Dim m_Face$
Dim m_hFont&
Dim m_Extrusion!
Dim m_ChordalDeviation!
Dim m_PolygonMode As glxFontFormat

'---------------------------------------------------------------------------------
Private Sub Class_Initialize()
    Set mCol = New Collection
    m_Extrusion = 0.1
    
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
    If m_hFont Then
        DeleteObject m_hFont
    End If
End Sub

'---------------------------------------------------------------------------------
Public Property Get face() As String
face = m_Face$
End Property

Public Property Let face(ByVal vNewValue As String)
m_Face = vNewValue
End Property

'---------------------------------------------------------------------------------
Public Property Get hFont&()
hFont = m_hFont
End Property

Public Property Let hFont(ByVal vNewValue&)
If m_hFont Then
    DeleteObject m_hFont
End If
m_hFont = vNewValue
End Property

'---------------------------------------------------------------------------------
Public Property Get PolygonMode() As glxFontFormat
PolygonMode = m_PolygonMode
End Property

Public Property Let PolygonMode(ByVal vNewValue As glxFontFormat)
m_PolygonMode = vNewValue
End Property

Public Property Get Extrusion() As Single
Extrusion = m_Extrusion
End Property

Public Property Let Extrusion(ByVal NewValue As Single)
m_Extrusion = NewValue
End Property

Public Property Get ChordalDeviation() As Single
ChordalDeviation = m_ChordalDeviation
End Property

Public Property Let ChordalDeviation(ByVal NewValue As Single)
m_ChordalDeviation = NewValue
End Property

'
Public Function Create(ByVal c$, ByVal Bold As Boolean, ByVal Italic As Boolean) As glxGlyph
Dim char As glxGlyph, sKey$, s$
    s = Left(c, 1)
    sKey = s
    If Bold Then sKey = sKey & "B"
    If Italic Then sKey = sKey & "I"
    Set char = m_Item(sKey)
    If Not char Is Nothing Then
        Set Create = char
        Exit Function
    End If
    Set char = New glxGlyph
    char.sKey = sKey
    With UC
        If m_hFont = 0 Then
            .Font.CreateFont .hDC, m_Face, 0, Bold, Italic
        End If
        char.CreateFromFont c, hFont, m_PolygonMode, m_Extrusion, m_ChordalDeviation
    End With
    'presumes that only errors are attempts to add
    'an existing entry
    On Error Resume Next
    mCol.Add char
    If Err Then
        Debug.Assert 0
    Else
        Set Create = char
    End If
End Function

Public Property Get Item(ByVal char$, ByVal Bold As Boolean, ByVal Italic As Boolean) As glxGlyph
Dim sKey$
    sKey = char
    If Bold Then sKey = sKey & "B"
    If Italic Then sKey = sKey & "I"
    Set Item = m_Item(sKey)
End Property

Private Function m_Item(Key$) As glxGlyph
Dim char As glxGlyph, i&
    If mCol.count Then
        For i = 1 To mCol.count
            Set char = mCol(i)
            If Not char Is Nothing Then
                If StrComp(char.sKey, Key, vbTextCompare) = 0 Then
                    Set m_Item = char
                    Exit Function
                End If
            End If
        Next
    End If
End Function

Public Property Get count() As Long
    count = mCol.count
End Property

Public Sub Remove(ByVal char$, ByVal Bold As Boolean, ByVal Italic As Boolean)
Dim ch As glxGlyph, i&
Dim sKey$
    sKey = char
    If Bold Then sKey = sKey & "B"
    If Italic Then sKey = sKey & "I"
    If mCol.count Then
        For i = 1 To mCol.count
            Set ch = mCol(i)
            If Not ch Is Nothing Then
                If StrComp(ch.sKey, sKey, vbTextCompare) = 0 Then
                    mCol.Remove i
                    Exit Sub
                End If
            End If
        Next
    End If
    
End Sub

Public Property Get NewEnum() As IUnknown
    Set NewEnum = mCol.[_NewEnum]
End Property


Public Sub Clear()
Dim i&
    For i = 1 To mCol.count
        mCol.Remove 1
    Next
End Sub

'-------------------------------------------------------------------------
'* ConvertStringToList
'* - Translate a string into display list numbers
'* - If no entry in the list table, update the table
'-------------------------------------------------------------------------
Public Sub ConvertStringToList(str$, ByVal Bold As Boolean, _
    ByVal Italic As Boolean, Lists%())
Dim strLen&, glyph As glxGlyph
Dim c$, i&
    ' Go thru the string, making sure every char has a display list
    ' Copy the display list # into Lists
    strLen = Len(str)
    ReDim Lists(0 To strLen)
    For i = 1 To strLen ' strLen--, str++
        c = Mid$(str, i, 1)
        Set glyph = Create(c, Bold, Italic)
        Lists(i - 1) = glyph.listNum
    Next
    ' zero terminate
    Lists(strLen) = 0
End Sub

'/******************************Public*Routine******************************\
'* GetStringExtent
'* Calculate a string's origin and extent in world coordinates.
'* The origin is determined by the first character's location, and thereafter
'* each char's location is determined by adding the previous char's cellInc
'* values.
'* This will work for all string orientations.
'-------------------------------------------------------------------------
Public Sub GetStringExtent(szString$, _
                  extentX!, extentY!, _
                  originX!, originY!, Bold As Boolean, Italic As Boolean)
Dim lng&
Dim i&, c$ '    TCHAR *c;
Dim cIndex% '    TUCHAR cindex;
Dim lpgmf As GLYPHMETRICSFLOAT
Dim cellOrigin As POINTFLOAT
Dim extentOrigin As POINTFLOAT
Dim extentLowerRight As POINTFLOAT
Dim boxOrigin As POINTFLOAT, boxLowerRight As POINTFLOAT
'Dim listLUT As C3DListEntry,
Dim glyph As glxGlyph
    'listLUT = pwfc.listLUT
    extentOrigin.x = FLOAT_MAX
    extentOrigin.y = -FLOAT_MAX
    extentLowerRight.x = -FLOAT_MAX
    extentLowerRight.y = FLOAT_MAX
    extentX = 0
    extentY = 0
    originX = 0
    originY = 0
    lng = Len(szString)
    If lng = 0 Then
        Debug.Assert 0
        Exit Sub       ' otherwise extents will be calc'd erroneously
    End If
    'c = szString
    For i = 1 To lng
        c = Mid$(szString, i, 1)
        cIndex = Asc(c)
        Set glyph = Item(c, Bold, Italic)
        ' calc global position of this char's BlackBox (this is
        '  'upper left')
        If glyph Is Nothing Then
            Debug.Assert 0
        End If
        With glyph
        boxOrigin.x = cellOrigin.x + .gmptGlyphOriginX
        boxOrigin.y = cellOrigin.y + .gmptGlyphOriginY

        ' calc lower right position
        boxLowerRight.x = boxOrigin.x + .gmBlackBoxX
        boxLowerRight.y = boxOrigin.y - .gmBlackBoxY

        ' compare against the current bounding box

        If boxOrigin.x < extentOrigin.x Then
            extentOrigin.x = boxOrigin.x
        End If
        If (boxOrigin.y > extentOrigin.y) Then
            extentOrigin.y = boxOrigin.y
        End If
        If (boxLowerRight.x > extentLowerRight.x) Then
            extentLowerRight.x = boxLowerRight.x
        End If
        If (boxLowerRight.y < extentLowerRight.y) Then
            extentLowerRight.y = boxLowerRight.y
        End If

        ' set global position of next cell
        cellOrigin.x = cellOrigin.x + .gmCellIncX
        cellOrigin.y = cellOrigin.y + .gmCellIncY
        End With
    Next
    ' Check for possible total lack of glyphmetric info
    If (extentOrigin.x = FLOAT_MAX) Then
        ' Can assume if this value is still maxed out that all glyphmetric
        ' info was NULL
        Debug.Assert 0
        originX = 0
        originY = 0
        extentX = 0
        extentY = 0
        lng = 0
        Exit Sub
    End If

    originX = extentOrigin.x
    originY = extentOrigin.y
    extentX = extentLowerRight.x - extentOrigin.x
    extentY = extentOrigin.y - extentLowerRight.y
    'm_TextLength = lng
End Sub




