VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CStrip"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'/******************************Module*Header******************************
'* Module Name: genstrip.c
'FUNCTION:
'* The Ribbon and 2 Ribbon styles of the 3D Flying Objects screen saver.
'* Animation of 1 or 2 quad strips floating about.
'* Copyright (c) 1994 Microsoft Corporation
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************
Const PREC = 40

Dim stripMesh As glxMesh
Dim myrotInc#
Dim rotA!, rotB!
Dim rotStepA!
Dim rotStepB!
Dim mxrot#
Dim myrot#
Dim mzrot#
Dim mxrotInc#
Dim mzrotInc#
' Use Hermite basis, pg 488, FVD
Dim m!(0 To 3, 0 To 3)

Private Sub Class_Initialize()
mxrotInc = 0.1
mzrotInc = 0.1
rotB! = (PI / 2)
rotStepA! = (PI / (2 * PREC))
rotStepB! = (PI / (4 * PREC))
m(0, 0) = 2
m(0, 1) = -2
m(0, 2) = 1
m(0, 3) = 1
m(1, 0) = -3
m(1, 1) = 3
m(1, 2) = -2
m(1, 3) = -1
m(2, 2) = 1
m(3, 0) = 1
End Sub

Private Sub Class_Terminate()
    Set stripMesh = Nothing
End Sub
    
Private Sub m_GenStrip()
Static counter&
Dim i&
Dim xx!(0 To 3), yy!(0 To 3), zz!(0 To 3)
Dim cx!(0 To 3), cy!(0 To 3), cz!(0 To 3)
Dim d!, t!, t2!, t3!
Dim p1!(0 To 2), p2!(0 To 2), v1!(0 To 2), v2!(0 To 2)
Dim norm!(0 To 2)
Dim sinVal!, angle!, angleStep!
Static sideSin!
Dim X!, Y!
    t = 0
    d = 1 / PREC
    angleStep = PI / PREC
    p1(0) = -0.5
    '?
    'p2(0) = 0.5
    'v1(0) = 1.5
    'v1(1) = 1.5
    p2(0) = 0.5 * Sin(rotB)
    v1(0) = 4 * Cos(rotA)
    v1(1) = 4 * Sin(rotA)
    v2(1) = 3
    
    rotA = rotA + rotStepA
    rotB = rotB + rotStepB
    counter = counter + 1
    If counter >= (2 * PREC) Then
        rotStepA = -rotStepA
        counter = 0
    End If

    angle = sideSin
    sideSin = sideSin + PI / 80
    xx(0) = p1(0)
    xx(1) = p2(0)
    xx(2) = v1(0)
    xx(3) = v2(0)
    '
    yy(0) = p1(1)
    yy(1) = p2(1)
    yy(2) = v1(1)
    yy(3) = v2(1)
    '
    zz(0) = p1(2)
    zz(1) = p2(2)
    zz(2) = v1(2)
    zz(3) = v2(2)
    For i = 0 To 3
        cx(i) = xx(0) * m(i, 0) + xx(1) * m(i, 1) + _
                xx(2) * m(i, 2) + xx(3) * m(i, 3)
        cy(i) = yy(0) * m(i, 0) + yy(1) * m(i, 1) + _
                yy(2) * m(i, 2) + yy(3) * m(i, 3)
        cz(i) = zz(0) * m(i, 0) + zz(1) * m(i, 1) + _
                zz(2) * m(i, 2) + zz(3) * m(i, 3)
    Next
    'generate the vertexes
    For i = 0 To PREC - 1
        t = t + d
        t2 = t * t
        t3 = t2 * t
        X = cx(0) * t3 + cx(1) * t2 + cx(2) * t + cx(3)
        Y = cy(0) * t3 + cy(1) * t2 + cy(2) * t + cy(3)
        sinVal = Sin(angle) / 5
        If (sinVal < 0) Then
            sinVal = -sinVal
        End If
        angle = angle + angleStep
        stripMesh.SetVertex i, X, 0.25, Y ' extrusion ' + sinVal;
        stripMesh.SetVertex PREC + i, X, -0.25, Y ' - sinVal;
    Next

    stripMesh.NumFaces = 0
    stripMesh.ClearNorms
    '
    'set the face data
    For i = 0 To PREC - 2
        stripMesh.FaceMaterial(i) = 0
        'get the normal for the face - c,a,b
        stripMesh.CalcNormal norm, i, PREC + i, i + 1
        stripMesh.SetFaceNormal i, norm
        'add this face's normal to the normal array
        stripMesh.IncrementNormal i, norm
        stripMesh.IncrementNormal PREC + i, norm
        If (i <> (PREC - 1)) Then
            stripMesh.IncrementNormal i + 1, norm
            stripMesh.IncrementNormal PREC + i + 1, norm
        End If
        'set the indices into the point array
        stripMesh.pA(i) = i
        stripMesh.pB(i) = PREC + i
        stripMesh.pC(i) = i + 1
        stripMesh.pD(i) = PREC + i + 1
        stripMesh.NumFaces = stripMesh.NumFaces + 1
    Next
    stripMesh.NumPoints = 2 * PREC
    stripMesh.NormalizeNorms
End Sub


Public Sub InitStripScene()
    Set stripMesh = gCtl.NewMesh
    stripMesh.Init PREC, 2 * PREC
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glOrtho -1.1, 1.1, -1.1, 1.1, 0, 3
    glTranslatef 0, 0, -1.5
    glRotatef 50, 1, 0, 0
    glRotatef 50, 0, 1, 0
    glRotatef 12, 0, 0, 1
    glMatrixMode GL_MODELVIEW
    glDisable GL_CULL_FACE 'the ocx enables culling
    '
    With gCtl.Lights(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 0.6, 0.6, 0.6
        .SetSpecular 0.5, 0.5, 0.5
    End With
End Sub


Public Sub UpdateStripScene(flags&)
Static h&
Dim Color!(0 To 3)
    glLoadIdentity
    glRotatef mxrot * (180 / PI), 1, 0, 0
    glRotatef myrot * (180 / PI), 0, 1, 0
    glRotatef mzrot * (180 / PI), 0, 0, 1
    m_GenStrip
    If optColorCycle Then
        gCtl.Ex.HSVtoRGB CSng(h), 1, 1, Color
        glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, Color(0)
        h = h + 1
        h = h Mod 360
    Else
        Material(1).SetMaterial
    End If
    stripMesh.UpdateObject optSmoothShading
    mxrot = mxrot + mxrotInc
    myrot = myrot + myrotInc
    mzrot = mzrot + mzrotInc
End Sub



