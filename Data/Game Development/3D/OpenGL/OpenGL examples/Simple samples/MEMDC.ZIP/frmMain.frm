VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "MemDC"
   ClientHeight    =   4710
   ClientLeft      =   1815
   ClientTop       =   2370
   ClientWidth     =   5445
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   314
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   363
   Visible         =   0   'False
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseDown Button, Shift, x, y
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseMove Button, Shift, x, y
End Sub

Private Sub Form_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseUp Button, Shift, x, y
End Sub

Private Sub Form_Paint()
    CX.Draw
End Sub

Private Sub Form_Resize()
    CX.Reshape ScaleWidth, ScaleHeight
End Sub



