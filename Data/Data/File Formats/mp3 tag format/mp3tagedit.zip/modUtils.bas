Attribute VB_Name = "modUtils"
Option Explicit

' D�claration des fonctions API utilis�es
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" ( _
                        ByVal hwnd As Long, ByVal wMsg As Long, _
                        ByVal wParam As Long, lParam As Any) As Long
Private Declare Function SHFileOperation Lib "shell32.dll" Alias "SHFileOperationA" _
                        (lpFileOp As SHFILEOPSTRUCT) As Long
Private Declare Function InternetGetConnectedStateEx Lib "wininet.dll" ( _
                        ByRef lpSFlags As Long, ByVal lpszConnectionName As String, _
                        ByVal dwNameLen As Long, ByVal dwReserved As Long) As Long
Public Declare Function InternetOpen Lib "wininet.dll" Alias "InternetOpenA" ( _
                        ByVal sAgent As String, ByVal lAccessType As Long, _
                        ByVal sProxyName As String, ByVal sProxyBypass As String, _
                        ByVal lFlags As Long) As Long
Public Declare Function InternetOpenUrl Lib "wininet.dll" Alias "InternetOpenUrlA" ( _
                        ByVal hInternetSession As Long, ByVal sUrl As String, _
                        ByVal sHeaders As String, ByVal lHeadersLength As Long, _
                        ByVal lFlags As Long, ByVal lContext As Long) As Long
Public Declare Function InternetReadFile Lib "wininet.dll" ( _
                        ByVal hFile As Long, ByVal sBuffer As String, _
                        ByVal lNumBytesToRead As Long, _
                        lNumberOfBytesRead As Long) As Integer
Public Declare Function InternetCloseHandle Lib "wininet.dll" ( _
                        ByVal hInet As Long) As Integer

' Pour le redimensionnement automatique des colonnes du contr�le ListView
Private Const LVM_FIRST = &H1000
Private Const LVM_SETCOLUMNWIDTH = LVM_FIRST + 30
Private Const LVSCW_AUTOSIZE = -1
' Pour l'acc�s internet
Public Const INTERNET_FLAG_NO_CACHE_WRITE = &H4000000 ' Pas d'�criture en cache
' Pour l'API SHFileOperation
Private Const FO_DELETE = &H3
Private Const FOF_ALLOWUNDO = &H40
Private Const FOF_NOCONFIRMATION = &H10

Private Type SHFILEOPSTRUCT
    hwnd As Long
    wFunc As Long
    pFrom As String
    pTo As String
    fFlags As Integer
    fAnyOperationsAborted As Boolean
    hNameMappings As Long
    lpszProgressTitle As String
End Type

' Variables globales utilis�es par l'application

' R�pertoire courant
Public stCurDir As String
' V�rification de mise � jour
Public blUpdate As Boolean
' Chemin pour application de d�compression
Public stUnzip As String

' =================== Fonctions d'acc�s r�seau/internet ====================

Public Function IsConnected() As Boolean
' Cette fonction v�rifie si une connexion r�seau est active
Dim lgLen As Long, lgFlags As Long
Dim stNomConnexion As String
Dim blConnected As Boolean
lgLen = 256
stNomConnexion = Space$(lgLen)
blConnected = InternetGetConnectedStateEx(lgFlags, stNomConnexion, lgLen, 0&)
IsConnected = blConnected
End Function

Public Function GetUrlFile(stUrl As String) As String
' R�cup�re le contenu d'une page/d'un fichier sur internet
Dim lgInternet As Long, lgSession As Long
Dim stBuf As String * 1024
Dim inRes As Integer
Dim lgRet As Long
Dim stTotal As String
stTotal = vbNullString
' R�cup�re un pointeur vers la connexion internet courante
lgSession = InternetOpen("VBTagEdit", 1, vbNullString, vbNullString, 0)
If lgSession Then
    ' R�cup�re un pointeur vers l'URL
    lgInternet = InternetOpenUrl(lgSession, stUrl, vbNullString, _
                                0, INTERNET_FLAG_NO_CACHE_WRITE, 0)
    If lgInternet Then
        Do
            ' Lecture de la page dans le buffer (par bloc de 1024)
            inRes = InternetReadFile(lgInternet, stBuf, 1024, lgRet)
            stTotal = stTotal & Mid$(stBuf, 1, lgRet)
        Loop While (lgRet <> 0)
    End If
    ' Lib�ration du pointeur
    inRes = InternetCloseHandle(lgInternet)
End If
' Retourne le r�sultat
GetUrlFile = stTotal
End Function

' ==================== Fonctions pour contr�le ListView ====================

Public Sub AdjustColListView(lvwListView As Object, frmAppel As Form)
Dim lgFor As Long
For lgFor = 0 To lvwListView.ColumnHeaders.Count - 1
' Ajuste la largeur des colonnes � leur contenu
    Call SendMessage(lvwListView.hwnd, LVM_SETCOLUMNWIDTH, lgFor, LVSCW_AUTOSIZE)
' V�rifie que le titre la colonne est toujours visible compl�tment, ...
    If lvwListView.ColumnHeaders(lgFor + 1).Width < _
       frmAppel.TextWidth(lvwListView.ColumnHeaders(lgFor + 1).Text) + 180 Then
' ... sinon, augmente la taille de la colonne
        lvwListView.ColumnHeaders(lgFor + 1).Width = _
            frmAppel.TextWidth(lvwListView.ColumnHeaders(lgFor + 1).Text) + 180
    End If
Next lgFor
End Sub

Public Sub ListViewColumnClick(lswListView As Object, ColHeadIndex As Long)
' Permet de trier les donn�es � l'int�rieur des colonnes par ordre
' croissant ou d�croissant lorsque l'on clique sur l'entete.
If ((ColHeadIndex - 1) = lswListView.SortKey) Then
    If lswListView.SortOrder = 0 Then ' lvwAscending
        lswListView.SortOrder = 1 ' lvwDescending
    Else
        lswListView.SortOrder = 0 ' lvwAscending
    End If
Else
    lswListView.SortKey = ColHeadIndex - 1
    lswListView.SortOrder = 0 ' lvwAscending
End If
lswListView.Sorted = True
End Sub

Public Sub SetListViewColumnName(lswListView As Object, ParamArray tabColumn())
' Permet de d�finir les colonnes d'un ListView en une seule ligne...
Dim lgFor As Long
lswListView.ColumnHeaders.Clear
For lgFor = 0 To UBound(tabColumn)
    lswListView.ColumnHeaders.Add , , tabColumn(lgFor)
Next lgFor
End Sub

' ================= Fonctions pour manipulation de cha�nes =================

Public Function PadR(stTexte As String, lgPadR As Long, _
                     Optional stCar As String = " ") As String
' Compl�te la cha�ne avec un caract�re donn� � droite
PadR = Left$(stTexte & String$(lgPadR, stCar), lgPadR)
End Function

' ================ Fonctions pour manipulation de fichiers =================

Public Function Deprotege(stFichier As String) As Boolean
' Fonction g�n�rique pour enlever la protection du fichier
Dim blOk As Boolean
Dim stPrompt As String, stTitre As String
blOk = True
If ((GetAttr(stFichier) And vbReadOnly) = vbReadOnly) Then
    stPrompt = Replace(LoadResString(intLOffset + 159), "%f", stFichier) & _
               vbCrLf & LoadResString(intLOffset + 160)
    stTitre = LoadResString(intLOffset + 161)
    If (MsgBox(stPrompt, vbQuestion + vbOKCancel, stTitre) <> vbOK) Then
        blOk = False
    Else
        ' Gestion d'erreur
        On Error Resume Next
        Err.Clear
        ' Enl�ve l'attribut lecture seule
        SetAttr stFichier, GetAttr(stFichier) And Not vbReadOnly
        blOk = (Err.Number = 0)
    End If
End If
Deprotege = blOk
End Function

Public Sub EffaceVersCorbeille(stFichier As String)
' Efface un fichier en l'envoyant � la corbeille
Dim lgRes As Long
Dim shFile As SHFILEOPSTRUCT
With shFile
' Constante indiquant une suppression
    .wFunc = FO_DELETE
' Affecte le nom du fichier
    .pFrom = stFichier
' Constantes pour indiquer qu'on pourra restaurer le fichier et qu'il ne
' faut pas faire appara�tre de fen�tre de confirmation pour l'op�ration.
    .fFlags = FOF_ALLOWUNDO Or FOF_NOCONFIRMATION
End With
lgRes = SHFileOperation(shFile)
End Sub

Public Function NomFichierValide(stNom As String, _
                 Optional stReplace As String = vbNullString) As String
' Suppression des caract�res interdits dans un nom de fichier
stNom = Replace(stNom, "\", stReplace)
stNom = Replace(stNom, "/", stReplace)
stNom = Replace(stNom, ":", stReplace)
stNom = Replace(stNom, "*", stReplace)
stNom = Replace(stNom, "?", stReplace)
stNom = Replace(stNom, "<", stReplace)
stNom = Replace(stNom, ">", stReplace)
stNom = Replace(stNom, "|", stReplace)
stNom = Replace(stNom, """", stReplace)
' Retourne la nouvelle valeur
NomFichierValide = stNom
End Function

Public Function StringToFile(stString As String, stFile As String) As String
' Enregistrement d'une chaine dans un fichier. En cas de r�ussite la fonction
' retourne une cha�ne vide, sinon, un message d'erreur.
' Cette fonction est l'inverse de la pr�c�dente
Dim inFree As Integer
Dim stTmp As String
On Error GoTo ErrStringToFile
inFree = FreeFile
Open stFile For Output As #inFree
Print #inFree, stString;
Close #inFree
StringToFile = vbNullString
Exit Function
ErrStringToFile:
StringToFile = "Erreur (" & Err.Number & "), " & Err.Description
End Function

' =============== Fonctions d'�change pour contr�le ListBox ================

Public Sub Echange(lstSource As ListBox, lstDestination As ListBox)
' Ajout d'un �l�ment de la liste Source vers la liste Destination
Dim lgTmp As Long
If (lstSource.ListCount > 0) Then
    If (lstSource.ListIndex > -1) Then
        lgTmp = lstSource.ListIndex
        lstDestination.AddItem lstSource.List(lgTmp)
        lstDestination.ItemData(lstDestination.NewIndex) = _
                                lstSource.ItemData(lgTmp)
        lstSource.RemoveItem lgTmp
    End If
End If
lstSource.SetFocus
If (lstSource.ListCount > lgTmp) Then
    lstSource.ListIndex = lgTmp
ElseIf (lstSource.ListCount > 0) Then
    lstSource.ListIndex = lstSource.ListCount - 1
End If
If (lstSource.SelCount > 0) Then
    For lgTmp = 0 To lstSource.ListCount - 1
        If lstSource.Selected(lgTmp) Then
            lstSource.ListIndex = lgTmp
            Exit For
        End If
    Next lgTmp
    Call Echange(lstSource, lstDestination)
End If
End Sub

Public Sub EchangeTout(lstSource As ListBox, lstDestination As ListBox)
' Ajout de tous les �l�ments de la liste Source vers la liste Destination
Dim lgTmp As Long
For lgTmp = 1 To lstSource.ListCount
    lstSource.ListIndex = 0
    lstDestination.AddItem lstSource.List(lstSource.ListIndex)
    lstDestination.ItemData(lstDestination.NewIndex) = _
                            lstSource.ItemData(lstSource.ListIndex)
    lstSource.RemoveItem lstSource.ListIndex
Next lgTmp
End Sub

Public Function InList(lstListe As ListBox, stElement As String, _
                       Optional blItemData As Boolean = False) As Boolean
' V�rifie la pr�sence d'un �l�ment dans une liste
Dim lgFor As Long
For lgFor = 1 To lstListe.ListCount
    If blItemData Then
        If (lstListe.ItemData(lgFor - 1) = CLng(stElement)) Then
            InList = True
            Exit Function
        End If
    Else
        If (lstListe.List(lgFor - 1) = stElement) Then
            InList = True
            Exit Function
        End If
    End If
Next lgFor
InList = False
End Function

Public Sub SelAllText(txtTmp As TextBox)
txtTmp.SelStart = 0
txtTmp.SelLength = Len(txtTmp.Text)
End Sub
