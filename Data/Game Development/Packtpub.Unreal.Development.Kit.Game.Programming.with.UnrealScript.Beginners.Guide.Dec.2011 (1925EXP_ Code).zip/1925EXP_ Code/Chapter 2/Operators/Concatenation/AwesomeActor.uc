class AwesomeActor extends Actor
    placeable;

var string String1, String2, AtSign, DollarSign;

function PostBeginPlay()
{
    AtSign = String1 @ String2;
    DollarSign = String1 $ String2;
    `log("At sign:" @ AtSign);
    `log("Dollar sign:" @ DollarSign);

    String1 @= String2;
    `log("String1:" @ String1);
}

defaultproperties
{
    String1="This is"
    String2="a test."

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
