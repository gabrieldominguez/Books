@rem Generates build (.build) project files for NAnt
.\tools\Prebuild\Prebuild.exe /target nant /file Prebuild.xml
