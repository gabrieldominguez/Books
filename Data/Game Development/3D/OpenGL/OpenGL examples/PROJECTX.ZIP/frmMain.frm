VERSION 5.00
Object = "*\A..\glxCtl.vbp"
Begin VB.Form frmMain 
   Caption         =   "ProjectX"
   ClientHeight    =   5250
   ClientLeft      =   630
   ClientTop       =   1995
   ClientWidth     =   5880
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5250
   ScaleWidth      =   5880
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4875
      Left            =   45
      TabIndex        =   0
      Top             =   180
      Width           =   5730
      _ExtentX        =   10107
      _ExtentY        =   8599
      BorderStyle     =   1
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub


Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


