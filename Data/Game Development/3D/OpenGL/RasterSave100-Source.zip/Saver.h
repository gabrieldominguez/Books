#ifndef Saver_H
#define Saver_H

// Saver.h
// James Ward 02/10/01 (espresso@crema.co.uk)
//
// Generic Screen Saver Manager
//

//-----------------------------------------------------------------------------

#ifdef  _WIN32
  #include <windows.h>
#endif//_WIN32

#include <GL/gl.h>
#include <GL/glu.h>

//-----------------------------------------------------------------------------

/**
 * Generic screen saver. Derive a custom implementation from this, filling in
 * just the few methods that you need to use - then create a single instance
 * of your custom screen saver at file scope.
 */
class Saver {
public:
	Saver();
	virtual ~Saver();

	virtual void OnCreate();
	virtual void OnDestroy();
	virtual void OnPaint();
	virtual void OnTimer();
	virtual void OnResize(int width, int height);

public:
	void Repaint();					// force a repaint
	void SwapBuffers();				// swap display buffers
	void SetTimerInterval(int ms);	// set timer interval (ms)

	int  Width()  const;			// returns width  (pixels)
	int  Height() const;			// returns height (pixels)

	DWORD Ticks() const;			// returns elapsed time (ms)
};

//-----------------------------------------------------------------------------

#endif//Saver_H
