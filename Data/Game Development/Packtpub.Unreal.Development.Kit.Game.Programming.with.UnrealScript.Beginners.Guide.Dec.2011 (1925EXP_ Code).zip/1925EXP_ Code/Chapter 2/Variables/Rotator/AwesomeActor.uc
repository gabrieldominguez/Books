class AwesomeActor extends Actor
    placeable;

function PostBeginPlay()
{
    `log("Rotation:" @ Rotation);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)

    Begin Object Class=ArrowComponent Name=Arrow
    End Object
    Components.Add(Arrow)
}
