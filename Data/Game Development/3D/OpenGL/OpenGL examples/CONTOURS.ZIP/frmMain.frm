VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.1#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Contours"
   ClientHeight    =   5190
   ClientLeft      =   1170
   ClientTop       =   3045
   ClientWidth     =   5625
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5190
   ScaleWidth      =   5625
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4290
      Left            =   270
      TabIndex        =   0
      Top             =   225
      Width           =   4740
      _ExtentX        =   8361
      _ExtentY        =   7567
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuNew 
         Caption         =   "New contour"
      End
      Begin VB.Menu mnuFDone 
         Caption         =   "Close contour"
      End
      Begin VB.Menu mnuFClear 
         Caption         =   "Clear"
      End
      Begin VB.Menu mnuFSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFExit 
         Caption         =   "Exit"
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "View"
      Begin VB.Menu mnuVWire 
         Caption         =   "Wire"
      End
      Begin VB.Menu mnuVGrid 
         Caption         =   "Grid"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuVLights 
         Caption         =   "Lights"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "Help"
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_Resize()
    glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Paint()
'comment the below if you use a timer to paint
    gCtl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
    CX.Pick items
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, default As Boolean)
    default = CX.Reshape(width, height)
End Sub


Private Sub mnuFClear_Click()
    CX.Clear
End Sub

Private Sub mnuFDone_Click()
    CX.Done
End Sub

Private Sub mnuFExit_Click()
    Unload Me
End Sub


Private Sub mnuHelp_Click()
Dim s$
    s = "1. Select 'New contour'" & vbCrLf
    s = s & "2. Click to place contour points." & vbCrLf
    s = s & "3. Click first point or select 'Done' to close contour." & vbCrLf
    MsgBox s
End Sub

Private Sub mnuNew_Click()
    CX.NewContour
End Sub

Private Sub mnuVGrid_Click()
    mnuVGrid.Checked = Not mnuVGrid.Checked
    CX.m_Grids = mnuVGrid.Checked
    gCtl.Render
End Sub

Private Sub mnuVLights_Click()
    mnuVLights.Checked = Not mnuVLights.Checked
    optLights = mnuVLights.Checked
    gCtl.Render
End Sub

Private Sub mnuVWire_Click()
    mnuVWire.Checked = Not mnuVWire.Checked
    If mnuVWire.Checked Then
        glPolygonMode GL_FRONT_AND_BACK, GL_LINE
    Else
        glPolygonMode GL_FRONT_AND_BACK, GL_FILL
    End If
    gCtl.Render
End Sub
