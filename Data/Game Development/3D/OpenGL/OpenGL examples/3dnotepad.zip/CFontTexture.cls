VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CFontTexture"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'--------------------------------------------------------------------------
'FUNCTION: displays text using font texture
'AUTHOR: edx - edx@hk.super.net, Dec 98
'HISTORY:This version of this class is for display, so the design
'   routines have been removed
'NOTES: See "A Simple OpenGL-based API for Texture Mapped Text", by Mark Kilgard for a
'   discussion of the technique and sample code.
'   This code is not a port of txf - the file format is called 'ftx' to distinguish
'   it from txf files, because they are not equivalent.
'   An ftx file consists of a glxTEXFONTDATA strgctlture followed by an array of bytes.
'   The glxTEXFONTDATA is always the same size. It contains the glyph metrics and the
'   texture coordinates.
'   The size of the array of image data depends upon the size of the image used to create
'   the file. It's size can be obtained from the BmpHeight, BmpWidth fields of the glxTEXFONTDATA
'   strgctlture.
'--------------------------------------------------------------------------
Private Type glxGLYPHDATA
    'glyph metrics, in pixels
    a As Long '
    b As Long
    'C As Long
    'gWidth As Long 'width of the cell in the bitmap
    gAdvance As Long 'amount of width to use when drawing
    'tex coords of the glyph
    TexLeft As Single
    TexTop As Single
    TexRight As Single
    TexBottom As Single
End Type
Private Type glxTEXFONTDATA
    Name As String
    NumGlyphs As Long
    'size in pixels
    BmpHeight As Long
    BmpWidth As Long
    BmpFontHeight As Long
    'size in tex coords
    Glyph(1 To 94) As glxGLYPHDATA
End Type
Public ID&
Dim m_Data() As Byte 'texture image
Dim m_DataSize&
Dim m_FontData As glxTEXFONTDATA 'glyph data
'Dim m_Ready As Boolean 'image data has been updated?
Dim m_TexID& 'gl Texture ID
Dim m_Factor! 'size adjustment when displaying
Const SCALEF = 100

Private Sub Class_Initialize()
Dim i&, IDs&(0)
    glGenTextures 1, IDs(0)
    m_TexID = IDs(0)
    If m_TexID = 0 Then
        MsgBox "Must initialize gl before using this class!"
        Debug.Assert 0
    End If
End Sub

Private Sub Class_Terminate()
'
End Sub

'--------------------------------------------------------------------------
'load an ftx file and bind the texture
'--------------------------------------------------------------------------
Public Function LoadFTX(Filename$) As Boolean
Dim fn&, w&, h&
    fn = FreeFile
    Open Filename For Binary As fn
    Get #fn, , m_FontData
    h = m_FontData.BmpHeight
    w = m_FontData.BmpWidth
    If h <> 128 And h <> 256 And h <> 512 Then GoTo EH
    If w <> 128 And w <> 256 And w <> 512 Then GoTo EH
    m_DataSize = h * w * 2
    ReDim m_Data(0 To m_DataSize - 1)
    Get #fn, , m_Data
    Close #fn
    glBindTexture GL_TEXTURE_2D, m_TexID
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
    'don't use 'f', use 'i'
    CheckError
    glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    CheckError
    'Create texture
    glTexImage2D GL_TEXTURE_2D, 0, 2, m_FontData.BmpWidth, m_FontData.BmpHeight, 0, _
            GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, m_Data(0)
    SetSizeFactor
    'm_Ready = True
    LoadFTX = True
    Exit Function
EH:
    Debug.Print Err.Description
    Debug.Assert 0
    MsgBox "Error opening file:" & vbCrLf & Err.Description
    Exit Function
    Resume Next
End Function


'---------------------------------------------------------
'return a string to print
'---------------------------------------------------------
Public Function GetNextWord$(Text$, pos&)
Dim s$, r&, char&
Dim InWord As Boolean
    Do While pos <= Len(Text)
        char = Asc(mId$(Text, pos, 1))
        If char = 32 Then
            If InWord Then
                GetNextWord = s
                Exit Function
            Else
                GetNextWord = " "
                pos = pos + 1
                Exit Function
            End If
        ElseIf char > 32 And char < 127 Then
            s = s + Chr$(char)
            pos = pos + 1
            InWord = True
        ElseIf char = 13 Then
            If InWord Then
                GetNextWord = s
                Exit Function
            Else
                GetNextWord = Chr$(13)
                pos = pos + 2
                Exit Function
            End If
        ElseIf char = 9 Then
            If InWord Then
                GetNextWord = s
                Exit Function
            Else
                GetNextWord = "    "
                pos = pos + 1
                Exit Function
            End If
        End If
    Loop
    'last word
    GetNextWord = s
End Function

'---------------------------------------------------------
'draws a string at the specified location
'---------------------------------------------------------
Public Function DrawWord!(Text$, X!, Y!, h!)
Dim i&, char&, w!, l!
    For i = 1 To Len(Text)
        'Get character index
        char = Asc(mId$(Text, i, 1)) - 31
        'this will drop missing glyphs, or use caps if available
        If char > m_FontData.NumGlyphs Then
            If char + 31 >= 97 And char + 31 <= 122 Then
                char = char - 32
            End If
            If char > m_FontData.NumGlyphs Then
                char = 1
            End If
        ElseIf char < 0 Then
            char = 1
        End If 'NumGlyphs
        'draw a quad with texture coordinates
        w = m_FontData.Glyph(char).b / SCALEF
        l = X + m_FontData.Glyph(char).a / SCALEF
        'bottom left
        glTexCoord2f m_FontData.Glyph(char).TexLeft, m_FontData.Glyph(char).TexBottom
        glVertex2f l, Y - h
        'bottom right
        glTexCoord2f m_FontData.Glyph(char).TexRight, m_FontData.Glyph(char).TexBottom
        glVertex2f l + w, Y - h
        'upper right
        glTexCoord2f m_FontData.Glyph(char).TexRight, m_FontData.Glyph(char).TexTop
        glVertex2f l + w, Y
        'upper left
        glTexCoord2f m_FontData.Glyph(char).TexLeft, m_FontData.Glyph(char).TexTop
        glVertex2f l, Y
    
        'Move to next character
        X = X + m_FontData.Glyph(char).gAdvance / SCALEF
    Next
    DrawWord = X
End Function

'---------------------------------------------------------
'
'---------------------------------------------------------
Public Sub DrawText(Text$, Width!, Optional Height!)
Dim i&, char&, X!, Y!, pos&, s$
Dim l!, w!, h!, wordw!
    If m_TexID = 0 Then
        Debug.Assert 0
        Exit Sub
    End If
    glBindTexture GL_TEXTURE_2D, m_TexID
    '
    glPushAttrib amAllAttribBits
    glEnable GL_TEXTURE_2D
    glAlphaFunc GL_GEQUAL, 0.0625
    glEnable GL_ALPHA_TEST
    glEnable GL_BLEND
    glBlendFunc GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
    'glEnable GL_POLYGON_OFFSET
    'glPolygonOffset 0, -3
    glPolygonMode faceFrontAndBack, pgmFILL
    h = m_FontData.BmpFontHeight / SCALEF '* m_Factor
    
    'draw quads
    glBegin GL_QUADS
    glNormal3f 0, 0, 1
    pos& = 1
    Do While pos < Len(Text)
        s = GetNextWord(Text, pos)
        If s = Chr$(13) Then
            Y = Y - h
            X = 0
            If -Y > Height Then Exit Do
        Else
            wordw = 0
            For i = 1 To Len(s)
                'Get character index
                char = Asc(mId$(s, i, 1)) - 31
                'this will drop missing glyphs, or use caps if available
                If char > m_FontData.NumGlyphs Then
                    If char + 31 >= 97 And char + 31 <= 122 Then
                        char = char - 32
                    End If
                    If char > m_FontData.NumGlyphs Then
                        char = 1
                    End If
                ElseIf char < 0 Then
                    Debug.Assert 0
                    If char = -18 Then 'cr
                        Y = Y - h
                    End If
                    GoTo skip
                End If 'NumGlyphs
                wordw = wordw + m_FontData.Glyph(char).gAdvance / SCALEF
skip:
            Next
            If X + wordw > Width Then
                X = 0
                Y = Y - h
                If -Y > Height Then Exit Do
            End If
            X = DrawWord(s, X, Y, h)
            wordw = 0
        End If
    Loop
    glEnd
    glPopAttrib
    
End Sub

'adjust the font so that all textures display about the same size.
'256x256 is taken as a base.
Public Sub SetSizeFactor()
    If m_FontData.BmpWidth = 128 And m_FontData.BmpHeight = 128 Then
        m_Factor = 2
    ElseIf m_FontData.BmpWidth = 128 And m_FontData.BmpHeight = 256 Then
        m_Factor = 1.5
    ElseIf m_FontData.BmpWidth = 256 And m_FontData.BmpHeight = 128 Then
        m_Factor = 1.5
    ElseIf m_FontData.BmpWidth = 512 And m_FontData.BmpHeight = 512 Then
        m_Factor = 0.5
    ElseIf m_FontData.BmpWidth = 512 And m_FontData.BmpHeight = 256 Then
        m_Factor = 0.75
    ElseIf m_FontData.BmpWidth = 256 And m_FontData.BmpHeight = 512 Then
        m_Factor = 0.75
    Else
        m_Factor = 1
    End If
End Sub

Public Property Get Fontname$()
    Fontname = m_FontData.Name
End Property

