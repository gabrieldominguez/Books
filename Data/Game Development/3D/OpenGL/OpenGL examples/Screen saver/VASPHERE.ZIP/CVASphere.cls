VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CVASphere"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'FUNCTION: Main class of the app.
'   - times the benefit of vertex arrays
'note: not sure if the timing code is accurate,
'   take it with a grain of salt if you're trying
'   to compare this to the C sample
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
Const NUMLISTS = 3
Const NUMRINGS = 50
Const NUMSECTIONS = 50
Dim Sphere As TSphere
Dim m_Vertexes() As TVertex
Dim m_Triangles() As TTriangle
Dim m_NumVertices&, m_NumTriangles&
Dim m_bDisplayList As Boolean
Dim m_CurrentType&
Dim m_DisplayLists&(0 To NUMLISTS - 1)
Dim dwTotalMillis&
Dim m_TotalTriangles&
Dim pszListType$(0 To NUMLISTS - 1)
Dim m_Material As glxMaterial

Private Sub Class_Initialize()
    m_bDisplayList = True
    pszListType$(0) = "Vertex Array"
    pszListType$(1) = "Direct Triangles"
    pszListType$(2) = "Direct Strips"
End Sub

Private Sub Class_Terminate()
Set m_Material = Nothing
End Sub

Public Sub Init()
    m_NumVertices = (NUMRINGS + 1) * NUMSECTIONS + 2
    m_NumTriangles = (NUMRINGS + 1) * NUMSECTIONS * 2
    ReDim m_Vertexes(0 To m_NumVertices - 1)
    ReDim m_Triangles(0 To m_NumTriangles - 1)
End Sub

Public Sub InitGL()
Dim fv4!(0 To 3) '4)
Dim iv1&(0), i&
Dim dlBase&
    m_InitSphere
    glClearColor 0.1, 0.1, 0.1, 1
    With gCtl.Camera
        .NearPlane = 0.01
        .FarPlane = 45
        .FieldOfView = 45
        .SetEyePos 0, 2, 5
    End With
    fv4(0) = 0.05
    fv4(1) = 0.05
    fv4(2) = 0.05
    fv4(3) = 1
    glLightModelfv GL_LIGHT_MODEL_Ambient, fv4(0)
    'gCtl.Lights.SetAmbient 0.05, 0.05, 0.05
    fv4(0) = 0
    fv4(1) = 1
    fv4(2) = 1
    fv4(3) = 0
    glLightfv GL_LIGHT0, GL_POSITION, fv4(0)
    fv4(0) = 0.5
    fv4(1) = 0.5
    fv4(2) = 0.5
    fv4(3) = 1
    glLightfv GL_LIGHT0, GL_DIFFUSE, fv4(0)
'    With gCtl.Lights(liLight0)
'        .SetAmbient 0, 0, 0
'        .SetSpecular 0, 0, 0 '0.6, 0.6, 0.6
'        '.Mode = lmPoint
'        .SetDiffuse 0.1, 0.1, 0.1
'        .SetPosition 0, 1, 1
'        .Enabled = True
'    End With
    glEnable GL_LIGHT0
    glEnable GL_LIGHTING
'    Dim r!, g!, b!, a!
'    With gCtl.Lights(liLight0)
'        .GetAmbient r, g, b, a
'        .GetDiffuse r, g, b, a
'        .GetSpecular r, g, b, a
'        .GetPosition r, g, b
'        r = .Mode
'    End With
    
    fv4(0) = 0.6
    fv4(1) = 0.6
    fv4(2) = 0.6
    fv4(3) = 1
    glMaterialfv GL_FRONT, GL_SPECULAR, fv4(0)
    iv1(0) = 40
    glMaterialiv GL_FRONT, GL_SHININESS, iv1(0)
'    Set m_Material = gCtl.NewMaterial
'    With m_Material
'        .SetSpecular 0.6, 0.6, 0.6
'        .SpecExp = 0.35 '        iv1(0) = 40
'        .SetMaterial
'    End With

    glEnable GL_CULL_FACE
    
    glEnableClientState GL_VERTEX_ARRAY
    glEnableClientState GL_NORMAL_ARRAY
    glEnableClientState GL_COLOR_ARRAY
    '
    glColorMaterial GL_FRONT, GL_AMBIENT_AND_DIFFUSE
    glEnable GL_COLOR_MATERIAL

    dlBase = glGenLists(NUMLISTS)
    For i = 0 To NUMLISTS - 1
        m_DisplayLists(i) = dlBase + i
        glNewList m_DisplayLists(i), GL_COMPILE
        m_DrawFunc i
        glEndList
    Next
End Sub

Public Function Resize() As Boolean
    Resize = True
End Function

Public Sub Draw()
Dim dwMillis#
Dim szMsg$
    dwMillis = GetTickCount
    glRotatef Sphere.r(0), 1, 0, 0
    glRotatef Sphere.r(1), 0, 1, 0
    glRotatef Sphere.r(2), 0, 0, 1
    If (m_bDisplayList) Then
        glCallList m_DisplayLists(m_CurrentType)
    Else
        m_DrawFunc m_CurrentType
    End If
    m_UpdateSphere
    dwMillis = GetTickCount - dwMillis
    dwTotalMillis = dwTotalMillis + dwMillis
    m_TotalTriangles = m_TotalTriangles + m_NumTriangles
    If (dwTotalMillis > 1000) Then
        szMsg = IIf(m_bDisplayList, "Display List ", "") & ": "
        szMsg = szMsg & pszListType(m_CurrentType) & " : " '
        szMsg = szMsg & Int(m_TotalTriangles * 1000# / dwTotalMillis)
        szMsg = szMsg & " tri/sec"
        frmMain.Caption = szMsg
        m_ResetTotals
    End If
End Sub

Private Sub m_DrawFunc(n&)
    Select Case n
    Case 0: m_DrawVertexArray
    Case 1: m_DrawTriangles
    Case 2: m_DrawStrips
    End Select
End Sub

Private Sub m_DrawVertexArray()
    glDrawElements GL_TRIANGLES, m_NumTriangles * 3, GL_UNSIGNED_INT, m_Triangles(0)
End Sub

Private Sub m_DrawTriangles()
Dim i&
    glBegin GL_TRIANGLES
    For i = 0 To m_NumTriangles - 1
        m_SetVertex m_Triangles(i).iv1
        m_SetVertex m_Triangles(i).iV2
        m_SetVertex m_Triangles(i).iV3
    Next
    glEnd
End Sub

Private Sub m_DrawStrips()
Dim iIdxBase&, j&, i&
    ' Triangle fans for top and bottom caps
    glBegin GL_TRIANGLE_FAN
    m_SetVertex 0
    iIdxBase = 1
    For i = 0 To NUMSECTIONS
        m_SetVertex iIdxBase + (i Mod NUMSECTIONS)
    Next
    glEnd
    glBegin GL_TRIANGLE_FAN
    m_SetVertex m_NumVertices - 1
    iIdxBase = m_NumVertices - NUMSECTIONS - 1
    For i = NUMSECTIONS To 0 Step -1
        m_SetVertex iIdxBase + (i Mod NUMSECTIONS)
    Next
    glEnd
    ' Triangle strips for each ring
    iIdxBase = 1
    For j = 0 To NUMRINGS - 1
        glBegin GL_TRIANGLE_STRIP
        For i = 0 To NUMSECTIONS
            m_SetVertex iIdxBase + (i Mod NUMSECTIONS)
            m_SetVertex iIdxBase + (i Mod NUMSECTIONS) + NUMSECTIONS
        Next
        glEnd
        iIdxBase = iIdxBase + NUMSECTIONS
    Next
End Sub

Private Sub m_UpdateSphere()
    Sphere.r(0) = Sphere.r(0) + Sphere.dr(0)
    Sphere.r(1) = Sphere.r(1) + Sphere.dr(1)
    Sphere.r(2) = Sphere.r(2) + Sphere.dr(2)
End Sub

Private Sub m_InitSphere()
    m_GenerateSphere 1
    glVertexPointer 3, GL_FLOAT, Len(m_Vertexes(0)), m_Vertexes(0).pt(0)
    glNormalPointer GL_FLOAT, Len(m_Vertexes(0)), m_Vertexes(0).n(0)
    glColorPointer 3, GL_FLOAT, Len(m_Vertexes(0)), m_Vertexes(0).Color(0)
    Randomize
    Sphere.r(0) = 0
    Sphere.r(1) = 0
    Sphere.r(2) = 0
    Sphere.dr(0) = DROT - Rnd * (2 * DROT)
    Sphere.dr(1) = DROT - Rnd * (2 * DROT)
    Sphere.dr(2) = DROT - Rnd * (2 * DROT)
End Sub

Private Sub m_GenerateSphere(fRadius!)
Dim fTheta!, fPhi!              ' Angles used to sweep around sphere '
Dim fDTheta!, fDPhi!           ' Angle between each section and ring '
Dim fX!, fY!, fZ!, fV!, fRSinTheta!  ' Temporary variables '
Dim i&, j&, n&, m&                ' counters '
    ' Generate vertices at the top and bottom points.
    '
    m_Vertexes(0).pt(0) = 0 'x
    m_Vertexes(0).pt(1) = fRadius 'y
    m_Vertexes(0).pt(2) = 0 'z
    m_Vertexes(0).n(0) = 0 'x
    m_Vertexes(0).n(1) = 1 'y
    m_Vertexes(0).n(2) = 0 'z
    m_Vertexes(0).Color(2) = 255
    m_Vertexes(m_NumVertices - 1).pt(0) = 0
    m_Vertexes(m_NumVertices - 1).pt(1) = -fRadius
    m_Vertexes(m_NumVertices - 1).pt(2) = 0
    m_Vertexes(m_NumVertices - 1).n(0) = 0
    m_Vertexes(m_NumVertices - 1).n(1) = -1
    m_Vertexes(m_NumVertices - 1).n(2) = 0
    m_Vertexes(m_NumVertices - 1).Color(1) = 255

    '
    'Generate vertex points for rings
     '
    fDTheta = PI / (NUMRINGS + 2)
    fDPhi = 2 * PI / NUMSECTIONS
    n = 1 ' vertex being generated, begins at 1 to skip top point '
    fTheta = fDTheta

    For i = 0 To NUMRINGS
        fY = (fRadius * Cos(fTheta)) ' y is the same for each ring '
        fV = fTheta / PI ' v is the same for each ring '
        fRSinTheta = (fRadius * Sin(fTheta))
        fPhi = 0
        For j = 0 To NUMSECTIONS - 1
            fX = (fRSinTheta * Sin(fPhi))
            fZ = (fRSinTheta * Cos(fPhi))
            m_Vertexes(n).pt(0) = fX
            m_Vertexes(n).pt(2) = fZ
            m_Vertexes(n).pt(1) = fY
            m_Vertexes(n).n(0) = fX / fRadius
            m_Vertexes(n).n(1) = fY / fRadius
            m_Vertexes(n).n(2) = fZ / fRadius
            If (n And 1) Then
                m_Vertexes(n).Color(2) = 255 ' = RGB_COLOR(0, 0, 255)
            Else
                m_Vertexes(n).Color(1) = 255 ' = RGB_COLOR(0, 255, 0)
            End If
            fPhi = fPhi + fDPhi
            n = n + 1
        Next
        fTheta = fTheta + fDTheta
    Next
    '
    ' Generate triangles for top and bottom caps.
    '
    For i = 0 To NUMSECTIONS - 1
        m_Triangles(i).iv1 = 0
        m_Triangles(i).iV2 = i + 1
        m_Triangles(i).iV3 = 1 + ((i + 1) Mod NUMSECTIONS)
        m_Triangles(m_NumTriangles - NUMSECTIONS + i).iv1 = m_NumVertices - 1
        m_Triangles(m_NumTriangles - NUMSECTIONS + i).iV2 = m_NumVertices - 2 - i
        m_Triangles(m_NumTriangles - NUMSECTIONS + i).iV3 = m_NumVertices - 2 - ((1 + i) Mod NUMSECTIONS)
    Next

    '
    ' Generate triangles for the rings
    '
    m = 1 ' first vertex in current ring,begins at 1 to skip top point'
    n = NUMSECTIONS ' triangle being generated, skip the top cap '
    
    For i = 0 To NUMRINGS - 1
        For j = 0 To NUMSECTIONS - 1
            m_Triangles(n).iv1 = m + j
            m_Triangles(n).iV2 = m + NUMSECTIONS + j
            m_Triangles(n).iV3 = m + NUMSECTIONS + ((j + 1) Mod NUMSECTIONS)
            m_Triangles(n + 1).iv1 = m_Triangles(n).iv1
            m_Triangles(n + 1).iV2 = m_Triangles(n).iV3
            m_Triangles(n + 1).iV3 = m + ((j + 1) Mod NUMSECTIONS)
            n = n + 2
        Next
        m = m + NUMSECTIONS
    Next
End Sub

Private Sub m_SetVertex(iVert&)
    glColor3fv m_Vertexes(iVert).Color(0)
    glNormal3fv m_Vertexes(iVert).n(0)
    glVertex3fv m_Vertexes(iVert).pt(0)
End Sub

Private Sub m_ResetTotals()
    dwTotalMillis = 0
    m_TotalTriangles = 0
End Sub

Public Sub Keyd()  'CALLBACK
    m_bDisplayList = Not m_bDisplayList
    m_ResetTotals
End Sub

Public Sub KeySPACE()  'CALLBACK
    m_CurrentType = (m_CurrentType + 1) Mod NUMLISTS
    m_ResetTotals
End Sub

