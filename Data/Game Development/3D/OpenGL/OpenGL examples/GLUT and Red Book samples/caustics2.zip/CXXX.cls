VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CCaustic"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'' Copyright (c) Mark J. Kilgard, 1997. */
'
'' This program is freely distributable without licensing fees and is
'   provided without guarantee or warrantee expressed or implied. This
'   program is -not- in the public domain. */
'
'' X compile line: cc -o underwater underwater.c texload.c dino.c -lglut -lGLU -lGL -lXmu -lXext -lX11 -lm */
'
'' This code compiles and works with any of 1) OpenGL 1.0 with no
'   texture extensions, 2) OpenGL 1.0 with texture extensions, or 3)
'   OpenGL 1.1. */
'===========================================================
'FUNCTION: Main class of the app.
'   - demostrates loading rgb and bw files
'   - slow loads can attributed to the code in the ocx
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'===========================================================
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
'
#If 0 Then  ' For debugging different OpenGL versions. */
#Const GL_VERSION_1_1 = 1
#End If
'
' Texture object compatibility. */
#If GL_VERSION_1_1 Then
#Const TEXTURE_OBJECT = 1
'#ElseIf GL_EXT_texture_object Then
'#Const TEXTURE_OBJECT = 1
'#define glBindTexture(A,B)     glBindTextureEXT(A,B)
'#define glGenTextures(A,B)     glGenTexturesEXT(A,B)
'#define glDeleteTextures(A,B)  glDeleteTexturesEXT(A,B)
'#ifndef GL_REPLACE
'#define GL_REPLACE GL_REPLACE_EXT
'#End If
#Else
' Define to nothing; but HaveTexObj will not be true in this case. */
'#define glBindTexture(A,B)
'#define glGenTextures(A,B)
'#define glDeleteTextures(A,B)
#End If

Const NUM_PATTERNS = 32
Const FLOOR_FILE = "floor.rgb"

Enum PassTypes
    PASS_NORMAL = 1
    PASS_CAUSTIC = 2
End Enum

Enum MenuOptions
    M_POSITIONAL = 1
    M_DIRECTIONAL = 2
    M_GREENISH_LIGHT = 3
    M_WHITE_LIGHT = 4
    M_NO_CAUSTICS = 5
    M_WITH_CAUSTICS = 6
    M_SWITCH_MODEL = 7
    M_INCREASE_RIPPLE_SIZE = 8
    M_DECREASE_RIPPLE_SIZE = 9
End Enum
  

Dim HaveTexObj As Boolean
Dim dinoDisplayList&
Dim causticScale!
Dim lightPosition!(0 To 3)
Dim lightDiffuseColor!(0 To 3), defaultDiffuseMaterial!(0 To 3)
Dim CausticIncrement&, CurrentCaustic&
Dim lightAngle!, lightHeight!
Dim angle!  ' in degrees */
Dim angle2!   ' in degrees */
Dim m_bMoving As Boolean
Dim m_StartX&, m_StartY&
Dim lightMoving As Boolean
Dim lightStartX&, lightStartY&
Dim floorVertices(0 To 3) As POINT3F

Private Sub Class_Initialize()
    optCurModel = MODEL_SPHERE
    causticScale! = 1
    lightHeight! = 20
    CausticIncrement = 1
    optUseMipmaps = True
    optShowCaustics = True
    optCausticMotion = True
    ' XXX Diffuse light color component > 1.0 to brighten caustics. */
    FillArrayf lightDiffuseColor, 1, 1.5, 1, 1     ' XXX Green = 1.5 */
    FillArrayf defaultDiffuseMaterial, 0.8, 0.8, 0.8, 1
    optDirectionalLight = True
    angle = 150
    angle2 = 30
    floorVertices(0).p(0) = -20
    floorVertices(0).p(2) = 20
    floorVertices(1).p(0) = 20
    floorVertices(1).p(2) = 20
    floorVertices(2).p(0) = 20
    floorVertices(2).p(2) = -20
    floorVertices(3).p(0) = -20
    floorVertices(3).p(2) = -20
End Sub


Public Sub InitGL()
Dim i&, Filename$
Dim imagedata As glxImage
    glClearColor 0.3, 0.3, 0.3, 0
    ' Setup initial OpenGL rendering state. */
    glLightfv GL_LIGHT0, GL_DIFFUSE, lightDiffuseColor(0)
    glEnable GL_LIGHT0
    glEnable GL_LIGHTING
    glEnable GL_DEPTH_TEST
    glEnable GL_CULL_FACE


    ' For rendering the MODEL_DINO object. */
    dinoDisplayList = MakeDinosaur

    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
        .TwoSide = True
    End With
    ' Setup the projection and view. */
    'gluPerspective 40, 1, 20, 100
    gluLookAt 0, 8, 60, 0, 8, 0, 0, 1, 0
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 0, 8, 60
        .SetTargetPos 0, 8, 0
    End With
    '
'Dim i&
'  GLubyte *imageData;

'    For i = 1 To n
'      causticIncrement = 2;
'    } else if (!strcmp("-evenlesstex", argv(i))) {
'      ' Only use 8 caustic textures.  Saves even more texture memory for
'     slow machines.  Temporal rippling suffers. */
'      causticIncrement = 4;
'    } else if (!strcmp("-nomipmap", argv(i))) {
'      ' Don't use linear mipmap linear texture filtering; instead
'     use linear filtering. */
'      optUseMipmaps = 0;
'    } else {
'      fprintf(stderr, "usage: caustics (-lesstex)\n");
'      fprintf(stderr, "       -lesstex uses half the caustic textures.\n");
'      fprintf(stderr, "       -evenlesstex uses one fourth of the caustic textures.\n");
'      exit(1);
'    }
'  }


    glEnable GL_TEXTURE_2D
#If TEXTURE_OBJECT Then ' Replace texture environment not in OpenGL 1.0. */
    If (HaveTexObj) Then
        glTexEnvf GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE
    End If
#End If
    frmSplash.Move (Screen.width - frmSplash.width) \ 2, (Screen.height - frmSplash.height) \ 2
    frmSplash.Show
    ' Load the caustic ripple textures. */
    For i = 0 To NUM_PATTERNS - 1 Step CausticIncrement
        frmSplash.Progress = i + 1 & " of " & NUM_PATTERNS \ CausticIncrement
        frmSplash.Progress.Refresh
        Filename = App.Path & "\data\caust" & i & ".bw"
        Set imagedata = gCtl.NewImage
        If imagedata.LoadFile(Filename) Then
            If (HaveTexObj) Then
                glBindTexture GL_TEXTURE_2D, i + 1
            Else
                glNewList i + 101, GL_COMPILE
            End If
            With imagedata
            If (optUseMipmaps) Then
                glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR
                glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
                .BuildMipMaps
            Else
                glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
                glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
                .SetTexImage
            End If
            End With
            If HaveTexObj = False Then
              glEndList
            End If
        Else
            Debug.Print "could not load image file " & Filename
        End If
        Set imagedata = Nothing
    Next
    Unload frmSplash

    ' Load an RGB file for the floor texture. */
    Set imagedata = gCtl.NewImage
    If imagedata.LoadFile(FLOOR_FILE) Then
        If (HaveTexObj) Then
            glBindTexture GL_TEXTURE_2D, 100
        Else
            glNewList 100, GL_COMPILE
        End If
        glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
        With imagedata
        If (optUseMipmaps) Then
            glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR
            glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
            .BuildMipMaps
        Else
            glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
            glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
            .SetTexImage
        End If
        End With
        If HaveTexObj = False Then
          glEndList
        End If
    Else
      Debug.Print "Could not load image file " & FLOOR_FILE
    End If
    Set imagedata = Nothing
End Sub

'void
'visible(int vis)
'{
'  ' Stop the animation when the window is not visible. */
'  if (vis == GLUT_VISIBLE)
'    updateIdleFunc(
'  Else
'    glutIdleFunc(NULL
'}
Public Sub Draw()
  
  ' Clear depth and color buffer. */
  'glClear GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT

  ' Reposition the light source. */
  lightPosition(0) = 12 * Cos(lightAngle)
  lightPosition(1) = lightHeight
  lightPosition(2) = 12 * Sin(lightAngle)
  If optDirectionalLight Then
    lightPosition(3) = 0
  Else
    lightPosition(3) = 1
  End If

  glPushMatrix
    ' Perform scene rotations based on user mouse input. */
    glRotatef angle2, 1, 0, 0
    glRotatef angle, 0, 1, 0
    
    ' Position the light again, after viewing rotation. */
    glLightfv GL_LIGHT0, GL_POSITION, lightPosition(0)

    ' Draw the light location. */
    drawLightLocation

    ' Normal pass rendering the scene (caustics get added
    '   after this pass). */
    drawScene PASS_NORMAL

    If optShowCaustics Then
      ' Disable depth buffer update and exactly match depth
     'buffer values for slightly faster rendering. */
      glDepthMask GL_FALSE
      glDepthFunc GL_EQUAL

      ' Multiply the source color (from the caustic luminance
     'texture) with the previous color from the normal pass.  The
     'caustics are modulated into the scene. */
      glBlendFunc GL_ZERO, GL_SRC_COLOR
      glEnable GL_BLEND

      drawScene PASS_CAUSTIC

      ' Restore fragment operations to normal. */
      glDepthMask GL_TRUE
      glDepthFunc GL_LESS
      glDisable GL_BLEND
    End If
  glPopMatrix
  '
    'updateIdleFunc (void)
    ' Must be both displaying the caustic patterns and have the
    ' caustics in rippling motion to need an idle callback. */
    If optShowCaustics And optCausticMotion Then
    CurrentCaustic = (CurrentCaustic + CausticIncrement) Mod NUM_PATTERNS
    End If
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub Key(KeyCode%)
Dim s$
    s = Chr$(KeyCode)
    Select Case (s)
    Case "X":  '  zRotation = zRotation + 5
    Case "x":  '  zRotation = zRotation - 5
    Case " ":  ' Spacebar toggles caustic rippling motion. */
        optCausticMotion = Not optCausticMotion
    End Select
    'no need to re-render
End Sub

Public Sub drawLightLocation()
    glPushMatrix
    glDisable GL_LIGHTING
    glDisable GL_TEXTURE_2D
    glColor3f 1, 1, 0
    If (optDirectionalLight) Then
        ' Draw an arrowhead.
        glDisable GL_CULL_FACE
        glTranslatef lightPosition(0), lightPosition(1), lightPosition(2)
        glRotatef lightAngle * -180 / PI, 0, 1, 0
        glRotatef Atn(lightHeight / 12) * 180 / PI, 0, 0, 1
        glBegin GL_TRIANGLE_FAN
            glVertex3f 0, 0, 0
            glVertex3f 2, 1, 1
            glVertex3f 2, -1, 1
            glVertex3f 2, -1, -1
            glVertex3f 2, 1, -1
            glVertex3f 2, 1, 1
        glEnd
    
      ' Draw a white line from light direction. */
        glColor3f 1, 1, 1
        glBegin GL_LINES
            glVertex3f 0, 0, 0
            glVertex3f 5, 0, 0
        glEnd
        glEnable GL_CULL_FACE
    Else
        ' Draw a yellow ball at the light source. */
        glTranslatef lightPosition(0), lightPosition(1), lightPosition(2)
        glutSolidSphere 1, 5, 5
    End If
    glEnable GL_TEXTURE_2D
    glEnable GL_LIGHTING
    glPopMatrix
End Sub

' Draw a floor (possibly textured). */
Public Sub drawFloor(Pass&)
    If Pass = PASS_NORMAL Then
        If HaveTexObj Then
            glBindTexture GL_TEXTURE_2D, 100
        Else
            glCallList 100
        End If
    End If
    ' The glTexCoord2f calls get ignored when in texture generation
    ' mode (ie, when modulating in caustics). */
     glBegin GL_QUADS
        glNormal3f 0, 1, 0
        glTexCoord2f 0, 0
        glVertex3fv floorVertices(0).p(0)
        glTexCoord2f 0, 2
        glVertex3fv floorVertices(1).p(0)
        glTexCoord2f 2, 2
        glVertex3fv floorVertices(2).p(0)
        glTexCoord2f 2, 0
        glVertex3fv floorVertices(3).p(0)
    glEnd
End Sub

Public Sub drawObject(Pass&)
  If Pass = PASS_NORMAL Then
    ' The objects are not textured (they could be if someone
    '   wanted them to be) so disable texture in the normal pass.  In
    '   the caustic pass, we want to avoid disabling texture though. */
    glDisable GL_TEXTURE_2D
  End If

  glPushMatrix

    ' If object is dino, put feet on the floor. */
    glTranslatef 0, (IIf(optCurModel = MODEL_DINO, 8, 12)), 0

    Select Case optCurModel
    Case MODEL_SPHERE:
      glutSolidSphere 6, 12, 12
    Case MODEL_CUBE:
      glutSolidCube 7
    Case MODEL_DINO:
      glCallList dinoDisplayList
      glMaterialfv GL_FRONT, GL_DIFFUSE, defaultDiffuseMaterial(0)
    End Select
  glPopMatrix

  If Pass = PASS_NORMAL Then
    glEnable GL_TEXTURE_2D
  End If
End Sub

Public Sub drawScene(Pass&)
  ' The 0.03 in the Y column is just to shift the texture coordinates
  '   a little based on Y (depth in the water) so that vertical faces
  '   (like on the cube) do not get totally vertical caustics. */
Dim sPlane!(0 To 3)
Dim tPlane!(0 To 3)
FillArrayf sPlane, 0.05, 0.03, 0, 0
FillArrayf tPlane, 0, 0.03, 0.05, 0
' The causticScale determines how large the caustic "ripples" will
'     be.  See the "Increate/Decrease ripple size" menu options. */
    sPlane(0) = 0.05 * causticScale
    sPlane(1) = 0.03 * causticScale

    tPlane(1) = 0.03 * causticScale
    tPlane(2) = 0.05 * causticScale

    If Pass = PASS_CAUSTIC Then
        ' Set current color to "white" and disable lighting
        '   to emulate OpenGL 1.1's GL_REPLACE texture environment. */
        glColor3f 1, 1, 1
        glDisable GL_LIGHTING

        ' Generate the S & T coordinates for the caustic textures
        '   from the object coordinates. */

        glTexGeni GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
        glTexGeni GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR
        glTexGenfv GL_S, GL_OBJECT_PLANE, sPlane(0)
        glTexGenfv GL_T, GL_OBJECT_PLANE, tPlane(0)
        glEnable GL_TEXTURE_GEN_S
        glEnable GL_TEXTURE_GEN_T

        If HaveTexObj Then
            glBindTexture GL_TEXTURE_2D, CurrentCaustic + 1
        Else
            glCallList CurrentCaustic + 101
        End If
    End If

    drawFloor Pass
    drawObject Pass

  If Pass = PASS_CAUSTIC Then
    glEnable GL_LIGHTING
    glDisable GL_TEXTURE_GEN_S
    glDisable GL_TEXTURE_GEN_T
  End If
End Sub

Public Sub MouseUp(Button As Integer, shift As Integer, X As Single, y As Single)
      m_bMoving = False
      lightMoving = 0
End Sub

Public Sub MouseMove(Button As Integer, shift As Integer, X As Single, y As Single)
    ' Rotate the light position with the middle mouse button. */
    
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If (m_bMoving) Then
            angle = angle + (X - m_StartX)
            angle2 = angle2 + (y - m_StartY)
            m_StartX = X
            m_StartY = y
        End If
    Else
        If (lightMoving) Then
            lightAngle = lightAngle + (X - lightStartX) / 40
            lightHeight = lightHeight + (lightStartY - y) / 20
            lightStartX = X
            lightStartY = y
        End If
    End If
End Sub

Public Sub MouseDown(Button As Integer, shift As Integer, X As Single, y As Single)
    ' Rotate the scene with the left mouse button.
    If Button = 1 Then
        m_bMoving = True
        m_StartX = X
        m_StartY = y
    Else
        lightMoving = 1
        lightStartX = X
        lightStartY = y
    End If
End Sub


Public Sub MenuSelect(v&)
    Select Case v
    Case M_POSITIONAL:
        optDirectionalLight = 0
    Case M_DIRECTIONAL:
        optDirectionalLight = True
    Case M_GREENISH_LIGHT:
        lightDiffuseColor(0) = 1
        lightDiffuseColor(1) = 1.5  ' XXX Green = 1.5 */
        lightDiffuseColor(2) = 1
        glLightfv GL_LIGHT0, GL_DIFFUSE, lightDiffuseColor(0)
    Case M_WHITE_LIGHT:
        lightDiffuseColor(0) = 1.5  ' XXX Red = 1.5 */
        lightDiffuseColor(1) = 1.5  ' XXX Green = 1.5 */
        lightDiffuseColor(2) = 1.5  ' XXX Blue = 1.5 */
        glLightfv GL_LIGHT0, GL_DIFFUSE, lightDiffuseColor(0)
    Case M_WITH_CAUSTICS, M_NO_CAUSTICS:
        optShowCaustics = Not optShowCaustics
    Case M_INCREASE_RIPPLE_SIZE:
        causticScale = causticScale / 1.5
    Case M_DECREASE_RIPPLE_SIZE:
        causticScale = causticScale * 1.5
    End Select
End Sub

