Attribute VB_Name = "mConstants"
Option Explicit

'reversed down and up here
Public Enum pzlDirections
    pzlLEFT = 0
    pzlDOWN = 3
    pzlRIGHT = 2
    pzlUP = 1
End Enum

Public gCtl As glxCtl
Public CX As CGLPuzzle
'
Public Const PI = 3.141592654
Public Const NUMPIECES = 10
Public Const NBOXFACES = 26 '(sizeof(boxfaces)/sizeof(boxfaces(0)))
Public Const NCONTFACES = 24 '(sizeof(containerfaces) / sizeof(containerfaces(0)))

Public Const BOXWIDTH = 4
Public Const BOXHEIGHT = 5
Public Const OFFSETX = -2
Public Const OFFSETY = -2.5
Public Const OFFSETZ = -0.5
Public Const HASHSIZE = 10691
Public Const MOVE_SPEED = 0.2
Public Const MAX_LIST_SIZE = 30000
Public Const LIMIT# = 4294967295#


Type TConfiguration
    m(0 To BOXHEIGHT - 1, 0 To BOXWIDTH - 1) As Byte
End Type

Public Type TPuzzle
    Backptr As Long 'CPuzzle
    Solnptr As Long 'CPuzzle
    Pieces As TConfiguration
    Nextptr As Long 'CPuzzle
    Hashvalue As Long
End Type

Public Puzzles() As TPuzzle
Public PuzzleCount&
Public StartPuzzle& 'index of first or current puzzle
Public HashTable(0 To HASHSIZE - 1) As Long
Public StartConfig As TConfiguration
Public thePuzzle As TConfiguration
Public convert(0 To NUMPIECES) As Byte ' + 1) =
Public xadds&(0 To 3), yadds&(0 To 3)
'
'hash data
'Public min#, max#
'Public cols&, dups&


'Declare Sub CopyToPtrFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
'    (ByVal DestAddr&, ByVal SrcAddr&, ByVal length&)
'Declare Sub CopyToStrFromPtr Lib "kernel32" Alias "RtlMoveMemory" _
'    (ByVal Str$, ByVal SrcAddr&, ByVal length&)

Public xRotation!, yRotation!, zTranslation!
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Type COLOR255
    c(0 To 2) As Byte
End Type

Public Sub Main()
Set gCtl = frmMain.glxCtl1
Set CX = New CGLPuzzle
gCtl.Init
frmMain.Show
gCtl.Animate = True
End Sub

'*************************************************************************
'solution code
'*************************************************************************
Public Function Solution(Config As TConfiguration)
    If (Config.m(4, 1) = 10 And Config.m(4, 2) = 10) Then
        Solution = 1
    End If
End Function

Public Function SolvePuzzle() As Boolean
'Dim nextpuz As CPuzzleList
Dim i& ', s$
'On Error GoTo eh
    gCtl.Interval = 3000
    DoEvents
    'hash stuff
    'min = LIMIT
    'max = 0
    If (Solution(thePuzzle)) Then
        frmMain.Caption = "Puzzle already solved!"
        Exit Function
    End If
    '
    'alloc all the mem at once
    PuzzleCount = 0
    ReDim Puzzles(1 To MAX_LIST_SIZE)
    AddConfig thePuzzle, 0
    Do 'should have an index check here
        i = i + 1
        'returns true when solution is found
        If GenerateNewConfigs(i) Then
            Exit Do
        End If
        If i Mod 2000 = 0 Then
            'Debug.Print i
            frmMain.Caption = "Solving... " & i
            DoEvents
        End If
    Loop
    '
'    Debug.Print "min/max:" & min & ", " & max
'    Debug.Print "cols:" & cols
'    Debug.Print "dups:" & dups
'    Debug.Print i
'    Debug.Print PuzzleCount
    gCtl.Interval = 50
    'Debug.Assert 0
    SolvePuzzle = True
    Exit Function
eh:
    Debug.Print i
    Debug.Print PuzzleCount
    gCtl.Interval = 50
    MsgBox Err & vbCrLf & Err.Description
    Debug.Assert 0
    freeSolutions
    frmMain.Caption = "I can't solve it!  " & i & " positions examined"
    SolvePuzzle = 0
End Function

Public Function GenerateNewConfigs(index&) As Boolean 'puzzle As CPuzzle
Dim x&, y&, direction&
Dim newpieces As TConfiguration
'
'create a new config for testing
'Set newpieces = New TConfiguration
    'pieces.Copy puzzle.pieces
    With Puzzles(index)
    For x = 0 To BOXWIDTH - 1
    For y = 0 To BOXHEIGHT - 1
        'find the space
        If (.Pieces.m(y, x) = 0) Then
            For direction = 0 To 3
                If (canmove0(.Pieces, x, y, direction, newpieces)) Then
                    'add this congig to the table
                    If (AddConfig(newpieces, index)) Then
                        GenerateNewConfigs = True
                    End If
                End If
            Next
        End If
    Next
    Next
    End With
End Function


'called when solving the puzzle
Public Function AddConfig(Config As TConfiguration, back&) As Boolean ' As TPuzzle
Dim Hashvalue&, newhash&
Dim NewPuzzle& ' As CPuzzle
Dim i&, j&
    'generate a hash
    Hashvalue = Hash(Config)
    newhash = Hashvalue Mod HASHSIZE
    
    'see if the spot is taken
    NewPuzzle = HashTable(newhash)
    'if already taken
    Do While NewPuzzle > 0
        'if it has same hash value, see if it is the
        'same configuration
        If Puzzles(NewPuzzle).Hashvalue = Hashvalue Then
            For i = 0 To BOXWIDTH - 1
                For j = 0 To BOXHEIGHT - 1
                If (convert(Config.m(j, i)) <> _
                    convert(Puzzles(NewPuzzle).Pieces.m(j, i))) Then
                    'cols = cols + 1
                    GoTo nomatch
                End If
                Next
          Next
          'it is the same, no need to add
          'dups = dups + 1
          Exit Function
        End If
nomatch:
        NewPuzzle = Puzzles(NewPuzzle).Nextptr
    Loop

    'insert this piece in the table
    PuzzleCount = PuzzleCount + 1
    With Puzzles(PuzzleCount)
        .Hashvalue = Hashvalue
        'save a ref to the one already there
        .Nextptr = HashTable(newhash)
        'copy the data
        .Pieces = Config
        .Backptr = back
        'insert our index in table
        HashTable(newhash) = PuzzleCount
    End With
    '
    'save our index if this is first
    If back = 0 Then
        StartPuzzle = PuzzleCount
    End If
    '
    If Solution(Config) Then
        SolidifyChain PuzzleCount
        AddConfig = True
        Exit Function
    End If

End Function

Public Function Hash&(Config As TConfiguration)
Dim i&, j&, v As Currency, n&, c#, mask#
Dim s$, k&, t!
    For i = 0 To BOXHEIGHT - 1
        For j = 0 To BOXWIDTH - 1
            v = v + convert(Config.m(i, j))
            v = v * 2
'            If v > int_limit Then
'                Stop
'            End If
        Next
    Next
    'If v > max Then max = v
    'If v < min Then min = v
    Hash = v
End Function

'called when puzzle is solved
'pass in the index of the solution puzzle
Public Sub SolidifyChain(puzzle As Long) 'TPuzzle)
Dim i&, ndx&, x&
    ndx = puzzle
    Do While Puzzles(ndx).Backptr
        i = i + 1
        '
        x = Puzzles(ndx).Backptr
        Puzzles(x).Solnptr = ndx
        ndx = x
    Loop
    frmMain.Caption = i & " moves to complete!"
End Sub

Public Sub freeSolutions()
'Dim nextlist As CPuzzleList
Dim puz As TPuzzle, nextpuz As TPuzzle
Dim i&
    Erase Puzzles
    StartPuzzle = 0
End Sub

' Checks if a space can move in a given direction
'returns True if a piece can be moved into the space x,y
Public Function canmove0(Pieces As TConfiguration, _
    ByVal x&, ByVal y&, ByVal direction&, newpieces As TConfiguration) As Boolean
Dim piece As Byte
Dim xadd&, yadd&
Dim l&, m&
Dim newx&, newy&
    
    'determine which direction to test
    'xadds = -1, 0, 1, 0
    'yadds = 0, -1, 0, 1
    xadd = xadds(direction)
    yadd = yadds(direction)
    
    'exit if blocked by edge of board
    If (x + xadd < 0) Or _
        (x + xadd >= BOXWIDTH) Or _
        (y + yadd < 0) Or _
        (y + yadd >= BOXHEIGHT) Then
        Exit Function
    End If
    '
    'if space already empty, exit
    piece = Pieces.m(y + yadd, x + xadd)
    If (piece = 0) Then
        Exit Function
    End If
    '
    'copy old config
    newpieces = Pieces
    '
    'mark the piece's space as empty
    For l = 0 To BOXWIDTH - 1
        For m = 0 To BOXHEIGHT - 1
            If (newpieces.m(m, l) = piece) Then
                newpieces.m(m, l) = 0
            End If
        Next
    Next
    '
    'try to move the piece
    xadd = -xadd
    yadd = -yadd
    '
    For l = 0 To BOXWIDTH - 1
    For m = 0 To BOXHEIGHT - 1
        If (Pieces.m(m, l) = piece) Then
            newx = l + xadd
            newy = m + yadd
            'if the move is blocked by edge, exit
            If (newx < 0) Or (newx >= BOXWIDTH) Or _
              (newy < 0) Or (newy >= BOXHEIGHT) Then
                Exit Function
            End If
            'if all parts of the piece don't go into spaces, exit
            If (newpieces.m(newy, newx) <> 0) Then
                Exit Function
            End If
            'mark the piece's new position
            newpieces.m(newy, newx) = piece
        End If
    Next
    Next
    'piece can move
    canmove0 = True
End Function

' Checks if a piece can move
Public Function canmove(Pieces As TConfiguration, ByVal x&, ByVal y&, _
            ByVal direction&, newpieces As TConfiguration) As Boolean
Dim xadd&, yadd&
Dim r As Boolean
    'Debug.Print "----------------"
    'Debug.Print "canmove dir:" & direction
'    Debug.Print "x=" & x
'    Debug.Print "y=" & y

    xadd = xadds(direction)
    yadd = yadds(direction)
    
    If (x + xadd < 0) Or (x + xadd >= BOXWIDTH) Or _
      (y + yadd < 0) Or (y + yadd >= BOXHEIGHT) Then
        'Debug.Print "Off of board "
        Exit Function
    End If
    'for the big pieces, recurse on the other half of the piece
    If (Pieces.m(y + yadd, x + xadd) = Pieces.m(y, x)) Then
        canmove = canmove(Pieces, x + xadd, y + yadd, direction, newpieces)
        'Debug.Print "checking other end "
        Exit Function
    End If
    'is the space empty?
    If (Pieces.m(y + yadd, x + xadd) <> 0) Then
        'Debug.Print "space not empty "
        Exit Function
    End If
    'check if its valid
    r = canmove0(Pieces, x + xadd, y + yadd, (direction + 2) Mod 4, newpieces)
    'Debug.Print "canmove = " & r
    canmove = r
End Function

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

Public Sub FillConfig(c As TConfiguration, ParamArray v())
Dim i&, j&, k&
    For i = 0 To BOXHEIGHT - 1
    For j = 0 To BOXWIDTH - 1
        c.m(i, j) = v(k)
        k = k + 1
    Next: Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayP3F(cnt&, a() As POINT3F, ParamArray n())
Dim v, i&, j&
    For i = 0 To cnt - 1
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillFaceArray(cnt&, a() As Long, ParamArray n())
Dim i&, j&
    For i = 0 To cnt - 1
        a(i, 0) = n(j)
        a(i, 1) = n(j + 1)
        a(i, 2) = n(j + 2)
        a(i, 3) = n(j + 3)
        j = j + 4
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillColorArray(a() As COLOR255, ParamArray n())
Dim i&, j&
    For i = 0 To NUMPIECES
        a(i).c(0) = n(j)
        a(i).c(1) = n(j + 1)
        a(i).c(2) = n(j + 2)
        j = j + 3
    Next
End Sub


