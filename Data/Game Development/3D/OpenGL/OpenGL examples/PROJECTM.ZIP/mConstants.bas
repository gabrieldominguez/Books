Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CXXX
'Public Manipulator As CManipulator
Public Nodes As CNodes
Public QuadObj&
'
Dim m_NextID&

'----------------------------------------------------------------------------
Public Sub Main()
    frmMain.Show
    'gCtl.Animate = True
End Sub

'----------------------------------------------------------------------------
Public Function NextID&()
    m_NextID = m_NextID + 1
    NextID = m_NextID
End Function

'----------------------------------------------------------------------------
Public Sub CheckError()
Dim s$
    Do
        s = gCtl.GetErr
        If Len(s) Then
            Debug.Print s
            Debug.Assert 0
        Else
            Exit Sub
        End If
    Loop
End Sub

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(A() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(A!(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(A&(), ParamArray n())
Dim v, i&
    For Each v In n
        A(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(A() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        A(i).p(0) = n(j)
        A(i).p(1) = n(j + 1)
        A(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(A() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        A(i, j).p(0) = n(cnt)
        A(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub




