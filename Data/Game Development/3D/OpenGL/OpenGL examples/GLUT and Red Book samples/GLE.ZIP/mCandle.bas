Attribute VB_Name = "mCandle"
Option Explicit


''
' * candlestick.c
' *
' * FUNCTION:
' * Draws a skewed candlestick shape using the Lathe primitive
' *
' * HISTORY:
' * -- created by Linas Vepstas October 1991
' * -- C++ and OO playing around Linas Vepstas June 1993
' * -- converted to use GLUT -- December 1995, Linas
' *
' */
' =========================================================== */
Public IDCandle&
Public Candle As gleLathe
Public Mat As glxMaterial
' =========================================================== */
' =========================================================== */

Const SCALEz = 1
Const NUMPTS = 41

' =========================================================== */
'todo - th
'Sub FACET(i&, x#, y#)
'Dim ax#, ay#, alen#
'Static dx#, dy#
'With Candle
'    .SetContourPt i, SCALEz * (x), SCALEz * (y)
'    If (i <> 0) Then
'        ax = x - dx
'        ay = y - dy
'        alen = 1 / Sqr(ax * ax + ay * ay)
'        ax = ax * alen
'        ay = ay * alen
'        'these points are being specified clockwise
'        .SetContourNormal (i), -ay, ax
'    End If
'    dx = x
'    dy = y
'End With
'End Sub

Public Sub InitCandle()
Dim j&
Dim theta#, dtheta#, style&

    Set Candle = gCtl.NewLathe
    Set Mat = gCtl.NewMaterial
    With Mat ' define candle color */
        .SetAmbient 0.25, 0.25, 0.25
        .SetDiffuse 0.8, 0.6, 0.175
        .SetSpecular 0.45, 0.45, 0.45
        .Shininess = 100
    End With

    With Candle
        ' define lathe/spiral parameters */
        .dzdTheta = -0.015 * 150
        .startRadius = 1.5
        .sweepTheta = 360
        ' initialize contour up vector */
        .SetUp 1, 0, 0
        ' define candlestick contour */
        .NumContourPoints = NUMPTS
        .NumContourNormals = NUMPTS

        Set CurModel = Candle
        .SetContourNormal 0, 0, -1
        CONTOUR2 0, 7#, 0
        CONTOUR2 1, 10#, 0
        CONTOUR2 2, 10#, 3.8
        CONTOUR2 3, 9.7, 3.8
        CONTOUR2 4, 9.62, 3.75
        CONTOUR2 5, 9.56, 3.75
        CONTOUR2 6, 9.5, 3.8
        CONTOUR2 7, 9.2, 3.8
        CONTOUR2 8, 8.8, 2.8
        CONTOUR2 9, 8.15, 1.8
        CONTOUR2 10, 8.3, 0.9
        CONTOUR2 11, 8#, 0.8
        CONTOUR2 12, 7.5, 0.2
        CONTOUR2 13, 7#, 0
        CONTOUR2 14, 5.8, 0
        CONTOUR2 15, 5.2, 0.6
        CONTOUR2 16, 4.6, 0
        CONTOUR2 17, 1.6, 0
        '
        dtheta = M_PI / 14
        theta = 0
        For j = 18 To 31
            '.SetContourNormal j, -Cos(theta), Sin(theta)
            CONTOUR2 j, 1.5 * Cos(theta), 1.5 * Sin(theta)
            theta = theta + dtheta
        Next
        CONTOUR2 32, -1.4, 0
        CONTOUR2 33, -4.6, 0
        CONTOUR2 34, -5.2, 0.6
        CONTOUR2 35, -5.8, 0
        CONTOUR2 36, -8, 0
        CONTOUR2 37, -9.6, 2
        CONTOUR2 38, -10, 2
        CONTOUR2 39, -10, 0
        CONTOUR2 40, -8, 0

        ' initialize the transofrms */
        .SetStartXForm 0, 1, 0, 0, 0, 1, 0
        .SetdXformdTheta 0, 0, 0, 0, 0, 0

        ' set the initial join style */
        '.NormStyle = gleEDGE 'orFACET
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
    End With
    IDCandle = glGenLists(1)
    glNewList IDCandle, lstCompile
        DrawCandle
    glEndList
End Sub

' =========================================================== */
Public Sub DrawCandle()
    glPushMatrix
        glEnable GL_NORMALIZE
        glEnable glcColorMaterial
        Mat.SetMaterial
        Candle.Draw
        glDisable GL_NORMALIZE
        glDisable glcColorMaterial
    glPopMatrix
End Sub
' ===================== END OF FILE ================== */


