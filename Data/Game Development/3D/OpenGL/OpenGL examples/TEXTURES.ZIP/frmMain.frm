VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.1#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Textures"
   ClientHeight    =   7845
   ClientLeft      =   645
   ClientTop       =   2100
   ClientWidth     =   9225
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   523
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   615
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4290
      Left            =   45
      TabIndex        =   45
      Top             =   0
      Width           =   4470
      _ExtentX        =   7885
      _ExtentY        =   7567
   End
   Begin glCtl.glxCtl glxCtl2 
      Height          =   2040
      Left            =   45
      TabIndex        =   44
      Top             =   4320
      Width           =   2220
      _ExtentX        =   3916
      _ExtentY        =   3598
   End
   Begin VB.Frame Frame3 
      Height          =   1365
      Left            =   2340
      TabIndex        =   29
      Top             =   6390
      Width           =   2220
      Begin VB.CommandButton btnPickColor 
         Height          =   285
         Left            =   1665
         TabIndex        =   43
         Top             =   540
         Width           =   420
      End
      Begin VB.CheckBox chkMask 
         Caption         =   "Mask color"
         Height          =   240
         Left            =   135
         TabIndex        =   42
         Top             =   585
         Width           =   1365
      End
      Begin VB.TextBox txtOpacity 
         Height          =   285
         Left            =   945
         TabIndex        =   31
         Top             =   990
         Width           =   375
      End
      Begin VB.Label lblFilename 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         ForeColor       =   &H80000008&
         Height          =   240
         Left            =   90
         TabIndex        =   41
         Top             =   225
         Width           =   2040
      End
      Begin VB.Label Label6 
         Caption         =   "opacity"
         Height          =   240
         Left            =   270
         TabIndex        =   30
         Top             =   1035
         Width           =   780
      End
   End
   Begin VB.Frame Frame2 
      Height          =   1365
      Left            =   45
      TabIndex        =   22
      Top             =   6390
      Width           =   2220
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   10
         Left            =   1395
         TabIndex        =   40
         Top             =   990
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   11
         Left            =   1755
         TabIndex        =   39
         Top             =   990
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   3
         Left            =   1755
         TabIndex        =   38
         Top             =   270
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   9
         Left            =   1035
         TabIndex        =   37
         Top             =   990
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   8
         Left            =   675
         TabIndex        =   36
         Top             =   990
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   7
         Left            =   1755
         TabIndex        =   35
         Top             =   630
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   6
         Left            =   1395
         TabIndex        =   34
         Top             =   630
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   5
         Left            =   1035
         TabIndex        =   33
         Top             =   630
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   4
         Left            =   675
         TabIndex        =   32
         Top             =   630
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   2
         Left            =   1395
         TabIndex        =   28
         Top             =   270
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   1
         Left            =   1035
         TabIndex        =   27
         Top             =   270
         Width           =   330
      End
      Begin VB.TextBox txtMat 
         Height          =   285
         Index           =   0
         Left            =   675
         TabIndex        =   26
         Top             =   270
         Width           =   330
      End
      Begin VB.Label Label5 
         Caption         =   "spec."
         Height          =   240
         Left            =   135
         TabIndex        =   25
         Top             =   1035
         Width           =   510
      End
      Begin VB.Label Label4 
         Caption         =   "diffuse"
         Height          =   240
         Left            =   135
         TabIndex        =   24
         Top             =   675
         Width           =   555
      End
      Begin VB.Label Label3 
         Caption         =   "amb."
         Height          =   240
         Left            =   135
         TabIndex        =   23
         Top             =   315
         Width           =   555
      End
   End
   Begin VB.Frame Frame1 
      Height          =   1365
      Left            =   4635
      TabIndex        =   18
      Top             =   6390
      Width           =   4515
      Begin VB.CheckBox chkHeadlight 
         Caption         =   "Headlight"
         Height          =   240
         Left            =   180
         TabIndex        =   21
         Top             =   990
         Width           =   1230
      End
      Begin VB.CheckBox chkTexture 
         Caption         =   "Texture"
         Height          =   240
         Left            =   180
         TabIndex        =   20
         Top             =   630
         Value           =   1  'Checked
         Width           =   1140
      End
      Begin VB.CheckBox chkWire 
         Caption         =   "Wireframe"
         Height          =   195
         Left            =   180
         TabIndex        =   19
         Top             =   270
         Width           =   1275
      End
   End
   Begin VB.Frame frmTexEnv 
      Caption         =   "TexEnv mode"
      Height          =   1320
      Left            =   6930
      TabIndex        =   12
      Top             =   1035
      Width           =   2175
      Begin VB.OptionButton optTexEnv 
         Caption         =   "Modulate"
         Height          =   240
         Index           =   1
         Left            =   180
         TabIndex        =   15
         Top             =   585
         Width           =   1500
      End
      Begin VB.OptionButton optTexEnv 
         Caption         =   "Decal"
         Height          =   240
         Index           =   0
         Left            =   180
         TabIndex        =   14
         Top             =   270
         Width           =   1500
      End
      Begin VB.OptionButton optTexEnv 
         Caption         =   "Blend"
         Height          =   240
         Index           =   2
         Left            =   180
         TabIndex        =   13
         Top             =   900
         Width           =   1500
      End
   End
   Begin VB.Frame frmTexGen 
      Caption         =   "TexGen mode"
      Height          =   1320
      Left            =   4635
      TabIndex        =   8
      Top             =   1035
      Width           =   2175
      Begin VB.OptionButton optTexGen 
         Caption         =   "Spheremap"
         Height          =   240
         Index           =   2
         Left            =   180
         TabIndex        =   11
         Top             =   900
         Width           =   1500
      End
      Begin VB.OptionButton optTexGen 
         Caption         =   "Object linear"
         Height          =   240
         Index           =   0
         Left            =   180
         TabIndex        =   10
         Top             =   270
         Width           =   1500
      End
      Begin VB.OptionButton optTexGen 
         Caption         =   "Eye linear"
         Height          =   240
         Index           =   1
         Left            =   180
         TabIndex        =   9
         Top             =   585
         Width           =   1500
      End
   End
   Begin VB.Frame frmMIN 
      Caption         =   "MIN"
      Height          =   960
      Left            =   6930
      TabIndex        =   5
      Top             =   0
      Width           =   2175
      Begin VB.OptionButton optMin 
         Caption         =   "Nearest"
         Height          =   240
         Index           =   0
         Left            =   180
         TabIndex        =   7
         Top             =   270
         Width           =   1500
      End
      Begin VB.OptionButton optMin 
         Caption         =   "Linear"
         Height          =   240
         Index           =   1
         Left            =   180
         TabIndex        =   6
         Top             =   585
         Width           =   1500
      End
   End
   Begin VB.ListBox List2 
      Height          =   1620
      Left            =   4635
      TabIndex        =   2
      Top             =   4725
      Width           =   4470
   End
   Begin VB.ListBox List1 
      Height          =   1815
      Left            =   4635
      TabIndex        =   1
      Top             =   2655
      Width           =   4470
   End
   Begin VB.Frame frmMag 
      Caption         =   "MAG"
      Height          =   960
      Left            =   4635
      TabIndex        =   0
      Top             =   0
      Width           =   2175
      Begin VB.OptionButton optMag 
         Caption         =   "Linear"
         Height          =   240
         Index           =   1
         Left            =   180
         TabIndex        =   4
         Top             =   585
         Width           =   1500
      End
      Begin VB.OptionButton optMag 
         Caption         =   "Nearest"
         Height          =   240
         Index           =   0
         Left            =   180
         TabIndex        =   3
         Top             =   270
         Width           =   1500
      End
   End
   Begin MSComDlg.CommonDialog CD 
      Left            =   360
      Top             =   270
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      CancelError     =   -1  'True
   End
   Begin VB.Image Loader 
      BorderStyle     =   1  'Fixed Single
      Height          =   2040
      Left            =   2295
      Stretch         =   -1  'True
      Top             =   4320
      Width           =   2205
   End
   Begin VB.Label Label2 
      Caption         =   "Blend destination"
      Height          =   240
      Left            =   4680
      TabIndex        =   17
      Top             =   4500
      Width           =   1950
   End
   Begin VB.Label Label1 
      Caption         =   "Blend source"
      Height          =   285
      Left            =   4725
      TabIndex        =   16
      Top             =   2430
      Width           =   1725
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3900
      Left            =   9270
      Picture         =   "frmMain.frx":0000
      Top             =   90
      Visible         =   0   'False
      Width           =   3900
   End
   Begin VB.Menu mnuFile 
      Caption         =   "Texture"
      Begin VB.Menu mnuFOpen 
         Caption         =   "Open"
      End
      Begin VB.Menu mnuFCheck 
         Caption         =   "Check"
      End
      Begin VB.Menu mnuFResource 
         Caption         =   "Resource"
      End
      Begin VB.Menu mnuFImage1 
         Caption         =   "Image1"
      End
      Begin VB.Menu mnuTSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOMaterial 
         Caption         =   "Material"
         Shortcut        =   {F12}
      End
   End
   Begin VB.Menu mnuModel 
      Caption         =   "Model"
      Begin VB.Menu mnuMGLXBox 
         Caption         =   "glxBox"
      End
      Begin VB.Menu mnuMGLUSphere 
         Caption         =   "gluSphere"
      End
      Begin VB.Menu mnuMBox 
         Caption         =   "Box"
      End
      Begin VB.Menu mnuMBillboard 
         Caption         =   "Billboard"
         Visible         =   0   'False
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub btnPickColor_Click()
On Error Resume Next
    'cd.Flags =cdlCCRGBInit
    CD.ShowColor
    If Err Then Exit Sub
    CX.MaskColor = CD.Color
End Sub


Private Sub chkMask_Click()
    CX.UseMask = (chkMask.value <> 0)
End Sub

Private Sub chkTexture_Click()
    CX.Texture = chkTexture.value
    gCtl.Render
End Sub

Private Sub chkWire_Click()
    CX.Wireframe = chkWire.value
End Sub

Private Sub chkHeadlight_Click()
    CX.Headlight = chkHeadlight.value
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub


Private Sub Form_Load()
List1.AddItem "GL_ZERO"
List1.AddItem "GL_ONE"
List1.AddItem "GL_DST_COLOR"
List1.AddItem "GL_ONE_MINUS_DST_COLOR"
List1.AddItem "GL_SRC_ALPHA"
List1.AddItem "GL_ONE_MINUS_SRC_ALPHA"
List1.AddItem "GL_DST_ALPHA"
List1.AddItem "GL_ONE_MINUS_DST_ALPHA"
List1.AddItem "GL_SRC_ALPHA_SATURATE"
List2.AddItem "GL_ZERO"
List2.AddItem "GL_ONE"
List2.AddItem "GL_DST_COLOR"
List2.AddItem "GL_ONE_MINUS_DST_COLOR"
List2.AddItem "GL_SRC_ALPHA"
List2.AddItem "GL_ONE_MINUS_SRC_ALPHA"
List2.AddItem "GL_DST_ALPHA"
List2.AddItem "GL_ONE_MINUS_DST_ALPHA"

End Sub


Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
    CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
    CX.InitGL
End Sub

Private Sub glxCtl1_Init()
    CX.Init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    CX.MouseUp Button, Shift, x, y
End Sub

'if not using double-buffering, uncomment the below
Private Sub glxCtl1_Paint()
    gCtl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
    CX.Pick items
End Sub

Private Sub glxCtl1_Resize(Width As Long, Height As Long, Default As Boolean)
    Default = CX.Reshape(Width, Height)
End Sub

Private Sub glxCtl2_Draw()
    CX.Draw2
End Sub

Private Sub glxCtl2_InitGL()
    CX.InitGL2
End Sub

Private Sub glxCtl2_Paint()
    gCtl2.Render
End Sub

Private Sub glxCtl2_Resize(Width As Long, Height As Long, Default As Boolean)
    Default = True
End Sub

Private Sub List1_Click()
    CX.Blend 1, List1.ListIndex + 1
End Sub

Private Sub List2_Click()
    CX.Blend 2, List1.ListIndex + 1
End Sub

Private Sub mnuFCheck_Click()
    CX.UseCheck
End Sub

Private Sub mnuFImage1_Click()
    CX.UsePicture Image1.Picture
End Sub

Private Sub mnuFOpen_Click()
Dim Pic As StdPicture, s$
    On Error Resume Next
    CD.Filter = "Graphic files|*.jpg;*.gif;*.bmp;*.bw;*.rgb;*.rgba;*.la|All files|*.*"
    CD.ShowOpen
    If Err Then Exit Sub
    s = CD.FileName
    If StrComp(Right$(s, 3), ".bw", 1) = 0 Then
        CX.TextureFile = CD.FileName
    ElseIf StrComp(Right$(s, 4), ".rgb", 1) = 0 Then
        CX.TextureFile = CD.FileName
    ElseIf StrComp(Right$(s, 5), ".rgba", 1) = 0 Then
        CX.TextureFile = CD.FileName
    ElseIf StrComp(Right$(s, 3), ".la", 1) = 0 Then
        CX.TextureFile = CD.FileName
    Else
        Set Pic = LoadPicture(CD.FileName)
        CX.UsePicture Pic
    End If
End Sub

Private Sub mnuFResource_Click()
    CX.UseResource
End Sub

Private Sub mnuMBillboard_Click()
    CX.Model = 4
    gCtl.Render
End Sub

Private Sub mnuMBox_Click()
    CX.Model = 3
    gCtl.Render
End Sub


Private Sub mnuMGLUSphere_Click()
    CX.Model = 2
    gCtl.Render
End Sub

Private Sub mnuMGLXBox_Click()
    CX.Model = 1
    gCtl.Render
End Sub


Private Sub mnuOMaterial_Click()
    CX.NextMaterial
End Sub

Private Sub optMag_Click(index As Integer)
    CX.MAG = index
End Sub

Private Sub optMin_Click(index As Integer)
    CX.Min = index
End Sub

Private Sub optTexEnv_Click(index As Integer)
    CX.TexEnvMode = index
End Sub

Private Sub optTexGen_Click(index As Integer)
    CX.TexGenMode = index
End Sub

Private Sub txtMat_Change(index As Integer)
Dim v!(0 To 3), x&, i&
    Select Case index
    Case 0, 1, 2, 3: x = 0
    Case 4, 5, 6, 7: x = 4
    Case Else: x = 8
    End Select
    v(0) = Val(txtMat(x))
    v(1) = Val(txtMat(x + 1))
    v(2) = Val(txtMat(x + 2))
    v(3) = Val(txtMat(x + 3))
    For i = 0 To 3
        If v(i) < 0 Then
            v(i) = 0
        ElseIf v(i) > 1 Then v(i) = 1
        End If
    Next
    CX.SetMaterial x \ 4, v
End Sub

Private Sub txtOpacity_Change()
Dim o!
    o = Val(txtOpacity)
    If o < 0 Then
        o = 0
    ElseIf o > 1 Then o = 1
    End If
    CX.Opacity = Val(txtOpacity)
End Sub
