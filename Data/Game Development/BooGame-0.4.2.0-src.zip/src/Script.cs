/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Reflection;
using System.Collections;

using Boo;
using Boo.Lang;
using Boo.Lang.Compiler;
using Boo.Lang.Compiler.IO;
using Boo.Lang.Compiler.Pipelines;
using Boo.Lang.Interpreter;

namespace BooGame
{
	/// <summary>
	/// Interface to interpret and compile Boo scripts.
	/// </summary>
	public class Script
	{
		#region Interpreter
		
		private static InteractiveInterpreter m_Interpreter;

		static Script()
		{
			Core.Initialize();
			m_Interpreter = new InteractiveInterpreter();
			m_Interpreter.Ducky = true;
            m_Interpreter.References.Add(Assembly.GetExecutingAssembly());
            m_Interpreter.References.Add(Assembly.GetCallingAssembly());
            m_Interpreter.References.Add(Assembly.GetEntryAssembly());
            m_Interpreter.Eval(
                "import BooGame" + Environment.NewLine
                + "import BooGame.Gui" + Environment.NewLine
                + "import BooGame.Gui.Widgets" + Environment.NewLine
                + "import System" + Environment.NewLine
                + "import System.Drawing");
            m_Interpreter.Print = new CompilerGenerated.___callable0(Terminal.WriteLine);
            m_Interpreter.RememberLastValue = true;
		}

		/// <summary>
		/// Ensures that the module is initialized.
		/// </summary>
		internal static void Initialize()
		{
		}

        /// <summary>
        /// Allows the interpreter to access the given assembly.
        /// </summary>
        /// <param name="assembly">The assembly to reference.</param>
        public static void AddReference(Assembly assembly)
        {
            m_Interpreter.References.Add(assembly);
        }

        /// <summary>
        /// Sets a value within the interpreter.
        /// </summary>
        /// <param name="name">The name of the variable.</param>
        /// <param name="val">The value to set.</param>
		public static void SetValue(string name, object val)
		{
			m_Interpreter.SetValue(name, val);
		}
        /// <summary>
        /// Gets a value from the interpreter.
        /// </summary>
        /// <param name="name">The name of the variable.</param>
        /// <returns>The value of that variable.</returns>
		public static object GetValue(string name)
		{
			return m_Interpreter.GetValue(name);
		}

        /// <summary>
        /// Interprets and executes the given code.
        /// </summary>
        /// <param name="code">The code to execute.</param>
        /// <returns>Any returning output value.</returns>
		public static object DoCode(string code)
		{
			CompilerContext context = m_Interpreter.Eval(code);
			if(context.Errors.Count > 0)
				m_Interpreter.DisplayErrors(context.Errors);
			return m_Interpreter.LastValue;
		}

		#endregion Interpreter
		
		private CompilerContext m_Context;
		private AssemblyCollection m_References = new AssemblyCollection();
		private CompilerInputCollection m_Input = new CompilerInputCollection();
        
        /// <summary>
        /// Creates a new script object to read and compile Boo scripts.
        /// </summary>
		public Script()
		{
			m_References.Add(System.Reflection.Assembly.GetExecutingAssembly());
		}

        /// <summary>
        /// Creates a new script object, loading in the given script file.
        /// </summary>
        /// <param name="file"></param>
		public Script(string file) : this()
		{
			AddFile(file);
		}

        /// <summary>
        /// Compiles all code read into the current script object.
        /// </summary>
		public void Compile()
		{
			Boo.Lang.Compiler.CompilerParameters para = new CompilerParameters();
			para.Debug = false;
			para.Ducky = true;
			para.GenerateInMemory = true;
			para.References = m_References;
			foreach(ICompilerInput input in m_Input)
				para.Input.Add(input);
			para.Pipeline = new CompileToMemory();
			BooCompiler compiler = new BooCompiler(para);
			m_Context = compiler.Run();
			if(m_Context.GeneratedAssembly == null)
			{
                CompilationError[] errors = new CompilationError[m_Context.Errors.Count];
                for(int i = 0; i < errors.Length; i++)
                {
                    CompilerError err = m_Context.Errors[i];
                    errors[i] = new CompilationError(err.ToString());
                    errors[i].Code = err.Code;
                    errors[i].Column = err.LexicalInfo.Column;
                    errors[i].Line = err.LexicalInfo.Line;
                    errors[i].Filename = err.LexicalInfo.FileName;
                    errors[i].Source = errors[i].Source;
                }
				string errMessage = String.Empty;
				foreach(CompilerError error in m_Context.Errors)
                    errMessage += error.ToString() + Environment.NewLine;
                throw new CompilationErrors(errMessage, errors);
			}
		}

        /// <summary>
        /// Get the MethodInfo of the wanted method.
        /// </summary>
        /// <param name="methodName">The name of the method to get.</param>
        /// <returns>The MethodInfo of the wanted function.</returns>
        /// <exception cref="MissingMethodException">Thrown when the method can't be found.</exception>
		public MethodInfo GetMethod(string methodName)
		{
			foreach(Module module in m_Context.GeneratedAssembly.GetModules())
			{
				MethodInfo info = module.GetMethod(methodName);
				if(info != null)
					return info;
				foreach(Type type in module.GetTypes())
				{
					 info = type.GetMethod(methodName);
					if(info != null)
						return info;
				}
			}
			throw new MissingMethodException("Unknown", methodName);
		}

		public MethodInfo GetMethod(string target, string methodName)
		{
			Type type = m_Context.GeneratedAssembly.GetType(target, true, true);
			return type.GetMethod(methodName);
		}

		public object Invoke(string target, string methodName, object obj, object[] parameters)
		{
			return GetMethod(target, methodName).Invoke(obj, parameters);
		}

		public object Invoke(string target, string methodName, object obj)
		{
			return GetMethod(target, methodName).Invoke(obj, null);
		}

		public object Invoke(string target, string methodName)
		{
			return GetMethod(target, methodName).Invoke(null, null);
		}

        /// <summary>
        /// Creates an instance of the given class within the generated assembly.
        /// </summary>
        /// <param name="target">The type name.</param>
        /// <returns>The generated object.</returns>
		public object CreateInstance(string target)
		{
			Type type = m_Context.GeneratedAssembly.GetType(target, true, true);
			return Activator.CreateInstance(type);
		}

        /// <summary>
        /// Adds code to the script.
        /// </summary>
        /// <param name="name">The name of the module.</param>
        /// <param name="code">The code to add.</param>
		public void AddCode(string name, string code)
		{
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			string[] lines = code.Split('\n');
			foreach(string line in lines)
			{
				if(line.StartsWith("#include "))
				{
					string file = line.Substring("#include ".Length).Trim();
					bool add = true;
					foreach(StringInput input in m_Input)
					{
						if(input.Name == file)
						{
							add = false;
							break;
						}
					}
					if(add)
						AddCode(file, FileSystem.GetString(file));
				}
				else
					builder.Append(line);
			}
			m_Input.Add(new StringInput(name, builder.ToString()));
		}
        /// <summary>
        /// Loads in code from a script file.
        /// </summary>
        /// <param name="filename">The script file to load in through the file system.</param>
		public void AddFile(string filename)
		{
			AddCode(filename, FileSystem.GetString(filename));
		}
	}
    public class CompilationErrors : ApplicationException, IEnumerable
    {
        public CompilationErrors(string message, Exception innerException)
            : base(message, innerException)
        {
        }
        public CompilationErrors(string message)
            : base(message)
        {
        }

        public CompilationErrors()
        {
        }

        public CompilationErrors(CompilationError[] errors)
        {
            m_Errors = errors;
        }

        public CompilationErrors(string message, CompilationError[] errors) : base(message)
        {
            m_Errors = errors;
        }
        public CompilationError[] Errors
        {
            get { return m_Errors; }
        }
        private CompilationError[] m_Errors;

        public CompilationError this[int index]
        {
            get { return m_Errors[index]; }
        }

        public IEnumerator GetEnumerator()
        {
            return m_Errors.GetEnumerator();
        }

    }

    public class CompilationError : ApplicationException
    {
        public CompilationError(string message, Exception innerException)
            : base(message, innerException)
        {
        }
        public CompilationError(string message)
            : base(message)
        {
        }

        public CompilationError()
        {
        }

        private string m_Code = null;
        public string Code 
        {
            get { return m_Code; }
            set { m_Code = value; }
        }

        private int m_Line = -1;
        public int Line 
        {
            get { return m_Line; }
            set { m_Line = value; }
        }

        private int m_Column = -1;
        public int Column
        {
            get { return m_Column; }
            set { m_Column = value; }
        }

        private string m_Filename = null;
        public string Filename
        { 
            get { return m_Filename; }
            set { m_Filename = value; }
        }
    }
}
