VERSION 5.00
Begin VB.Form frmDisplay 
   Caption         =   "Lighted Jet"
   ClientHeight    =   6000
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   ScaleHeight     =   400
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   400
   StartUpPosition =   3  'Windows Default
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFile_Exit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEffects 
      Caption         =   "&Effects"
      Begin VB.Menu mnuEffects_Lights 
         Caption         =   "&Lights On"
      End
      Begin VB.Menu mnuEffects_Specular 
         Caption         =   "&Specular On"
      End
      Begin VB.Menu mnuEffects_Shine 
         Caption         =   "S&hine On"
      End
   End
End
Attribute VB_Name = "frmDisplay"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Paint()
        Call RenderScene
End Sub

Private Sub Form_Resize()
    Dim Fact As GLfloat
    Dim nRange As GLfloat
    Dim WinAW As GLfloat, WinAH As GLfloat
    
    WinAW = frmDisplay.ScaleWidth
    WinAH = frmDisplay.ScaleHeight
    
    nRange = 80#
    glViewport 0#, 0#, WinAW, WinAH
    glMatrixMode mmProjection
    glLoadIdentity
    
    If WinAW <= WinAH Then
      Fact = WinAH / WinAW
      glOrtho -nRange, nRange, -nRange * Fact, nRange * Fact, -nRange, nRange
    Else
      Fact = WinAW / WinAH
      glOrtho -nRange * Fact, nRange * Fact, -nRange, nRange, -nRange, nRange
    End If
    
    glMatrixMode mmModelView
    glLoadIdentity
       
End Sub

Private Sub Form_Unload(Cancel As Integer)
    bAppRunning = False
End Sub

Private Sub mnuEffects_Lights_Click()
    If bLight = False Then
      bLight = True
      mnuEffects_Lights.Checked = True
      mnuEffects_Specular.Enabled = True
      If bSpecular = True Then
        mnuEffects_Shine.Enabled = True
      Else
        mnuEffects_Shine.Enabled = False
      End If
    Else
      bLight = False
      mnuEffects_Lights.Checked = False
      mnuEffects_Specular.Enabled = False
      mnuEffects_Shine.Enabled = False
    End If
    Call SetupRC
End Sub

Private Sub mnuEffects_Specular_Click()
    If bSpecular = False Then
      bSpecular = True
      mnuEffects_Specular.Checked = True
      mnuEffects_Shine.Enabled = True
    Else
      bSpecular = False
      mnuEffects_Specular.Checked = False
      mnuEffects_Shine.Enabled = False
    End If
    Call SetupRC
End Sub

Private Sub mnuEffects_Shine_Click()
    If bShine = False Then
      bShine = True
      mnuEffects_Shine.Checked = True
    Else
      bShine = False
      mnuEffects_Shine.Checked = False
    End If
    
    Call SetupRC
End Sub


Private Sub mnuFile_Exit_Click()
    bAppRunning = False
End Sub


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
  Select Case KeyCode
    Case vbKeyUp
      xRot = xRot - 5#
    Case vbKeyDown
      xRot = xRot + 5#
    Case vbKeyLeft
      yRot = yRot - 5#
    Case vbKeyRight
      yRot = yRot + 5#
  End Select
  If xRot > 360# Then xRot = 0#
  If xRot < -360 Then xRot = 0#
  If yRot > 360# Then yRot = 0#
  If yRot < -360# Then yRot = 0#
  Call RenderScene
End Sub

