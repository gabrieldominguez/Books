class AwesomeActor extends Actor
    placeable;

var int Int1;

function PostBeginPlay()
{
    Int1 = 2;
    
    switch(Int1)
    {
        case 1:
            `log("Int1 == 1");
            break;
        case 2:
            `log("Int1 == 2");
            break;
        case 3:
            `log("Int1 == 3");
            break;
        default:
            `log("Int1 isn't any of those!");
    }
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
