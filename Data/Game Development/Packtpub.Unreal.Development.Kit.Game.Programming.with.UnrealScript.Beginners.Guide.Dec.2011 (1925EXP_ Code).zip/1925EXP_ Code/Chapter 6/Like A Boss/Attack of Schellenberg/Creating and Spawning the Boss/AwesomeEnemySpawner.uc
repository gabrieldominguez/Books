class AwesomeEnemySpawner extends AwesomeActor
    placeable;

var AwesomeEnemy MySpawnedEnemy;

function SpawnEnemy()
{
    if(MySpawnedEnemy == none)
        MySpawnedEnemy = spawn(class'AwesomeEnemy_Minion', self,, Location);
}

function bool CanSpawnEnemy()
{
    return MySpawnedEnemy == none;
}

function MakeEnemyRunAway()
{
    if(MySpawnedEnemy != none)
        MySpawnedEnemy.RunAway();
}

function SpawnBoss()
{
    spawn(class'AwesomeBoss', self,, Location);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}