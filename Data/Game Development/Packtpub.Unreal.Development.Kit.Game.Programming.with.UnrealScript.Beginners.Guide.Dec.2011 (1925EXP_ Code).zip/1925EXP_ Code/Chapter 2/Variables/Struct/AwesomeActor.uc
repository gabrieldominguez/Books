class AwesomeActor extends Actor
    placeable;

struct SmallBox
{
    var int Chocolates;
    var int Cookies;
};

struct Basket
{
    var string Fortunes[4];
    var SmallBox TheBox;
    var string BasketColor;
    var int NumberOfKittens, BallsOfString;
    var float BasketSize;
};

var Basket MyBasket;

function PostBeginPlay()
{
    MyBasket.NumberOfKittens = 4;
    MyBasket.BasketColor = "Yellow";
    MyBasket.BasketSize = 12.0;
    MyBasket.BallsOfString = 2;
    MyBasket.Fortunes[2] = "Now you're programming!";
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
