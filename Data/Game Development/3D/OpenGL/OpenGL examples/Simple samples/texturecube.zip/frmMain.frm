VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.1#0"; "COMDLG32.OCX"
Begin VB.Form frmMain 
   Caption         =   "GLTrackballTexturedCube (c) Mysaksoft 1988"
   ClientHeight    =   4590
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4875
   DrawStyle       =   1  'Dash
   Icon            =   "frmMain.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   306
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   325
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox pctTextureLoader 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   1515
      Left            =   600
      ScaleHeight     =   101
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   101
      TabIndex        =   0
      Top             =   150
      Visible         =   0   'False
      Width           =   1515
   End
   Begin MSComDlg.CommonDialog cdlgFileOpen 
      Left            =   75
      Top             =   75
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   327681
      DialogTitle     =   "Open Bitmap"
      Filter          =   "Bitmaps (*.bmp;*.rle)|*.bmp;*.rle|Myers/Mares OpenGL Texture (*.mot)|*.mot|All Files (*.*)|*.*"
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
' GLTextureCube - original code by Ryan Mayers
' GLTextureCube: A cross of GLBitmapTexture and GLCube, making an open
' texture-mapped rotatable cube.
'Trackaball routines adied by Michal Husak husakm@vscht.cz

' Declaration of varibales for trackball

Dim spinning As Boolean, moving As Boolean
Dim beginx As Integer, beginy As Integer
Dim W As Integer, H As Integer
Dim curquat(3) As GLfloat
Dim lastquat(3) As GLfloat
Dim newModel As Boolean
Dim scaling As Boolean
Dim scalefactor As Single
Dim anim As Boolean
Dim StopAll As Boolean
'End of declarations for trackball


Dim hPalette As Long
Dim hGLRC As Long
Dim bitmapImage() As GLubyte
Dim bitmapHeight As GLfloat
Dim bitmapWidth As GLfloat
Dim bitmapFilename As String
Dim xAngle As GLfloat
Dim yAngle As GLfloat
Dim zAngle As GLfloat
Dim xScale As GLfloat
Dim yScale As GLfloat
Dim displayListInited As GLboolean
Dim doubleBuffer As GLboolean

'Trackball part 1
Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error Resume Next
        If Button = vbLeftButton Then
            spinning = False
            anim = False
            moving = True
            beginx = X
            beginy = Y
            If Shift = 1 Then
                scaling = True
                Else
                scaling = False
            End If
        End If
End Sub
'Trackball part 2
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = vbLeftButton Then
        moving = False
        scaling = False
    End If
End Sub
'Trackball part 3
Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)

    H = frmMain.ScaleHeight
    W = frmMain.ScaleWidth
    
    If scaling Then
        scalefactor = scalefactor * (1 + ((beginy - Y) / H))
        beginx = X
        beginy = Y
        newModel = True
        Form_Paint
        spinning = True
        GoTo konec
    End If
     
    If moving Then
        trackball lastquat, ((2 * beginx - W) / W), ((H - 2 * beginy) / H), ((2 * X - W) / W), ((H - 2 * Y) / H)
      
        beginx = X
        beginy = Y
        spinning = True
        anim = True
    End If
konec:
End Sub
'Trackball part 4
Private Sub recalcModelView()
    
    Dim m(15) As GLfloat
    glPopMatrix
    glPushMatrix
    build_rotmatrix m, curquat
    glMultMatrixf m(0)
    If scalefactor = 1 Then
            glDisable GL_NORMALIZE
        Else
            glEnable GL_NORMALIZE
    End If
    
    glScalef scalefactor, scalefactor, scalefactor
    newModel = False

End Sub
'Trackball part 5
Private Sub animate()
Dim I As Integer
    
            add_quats lastquat, curquat, curquat
            newModel = True
            Form_Paint
End Sub
Sub FatalError(ByVal strMessage As String)
    MsgBox "Fatal Error: " & strMessage, vbCritical + vbApplicationModal + vbOKOnly + vbDefaultButton1, "Fatal Error In " & App.Title
    Unload frmMain
    Set frmMain = Nothing
    End
End Sub
Sub SetupPixelFormat(ByVal hDC As Long)
    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim PixelFormat As Integer
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 16
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    PixelFormat = ChoosePixelFormat(hDC, pfd)
    If PixelFormat = 0 Then FatalError "Could not retrieve pixel format!"
    SetPixelFormat hDC, PixelFormat, pfd
End Sub
Sub SetupPalette(ByVal lhDC As Long)
    Dim PixelFormat As Long
    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim pPal As LOGPALETTE
    Dim PaletteSize As Long
    PixelFormat = GetPixelFormat(lhDC)
    DescribePixelFormat lhDC, PixelFormat, Len(pfd), pfd
    If (pfd.dwFlags And PFD_NEED_PALETTE) <> 0 Then
        PaletteSize = 2 ^ pfd.cColorBits
    Else
        Exit Sub
    End If
    
    pPal.palVersion = &H300
    pPal.palNumEntries = PaletteSize
    Dim redMask As Long
    Dim GreenMask As Long
    Dim BlueMask As Long
    Dim I As Long
    redMask = 2 ^ pfd.cRedBits - 1
    GreenMask = 2 ^ pfd.cGreenBits - 1
    BlueMask = 2 ^ pfd.cBlueBits - 1
    For I = 0 To PaletteSize - 1
        With pPal.palPalEntry(I)
            .peRed = I
            .peGreen = I
            .peBlue = I
            .peFlags = 0
        End With
    Next
    GetSystemPaletteEntries hDC, 0, 256, VarPtr(pPal.palPalEntry(0))
    hPalette = CreatePalette(pPal)
    If hPalette <> 0 Then
        SelectPalette lhDC, hPalette, False
        RealizePalette lhDC
    End If
End Sub
Private Sub LoadImage()

    Dim intFileHandle As Integer

    ' Open a file.
    ' The file should be BMP with pictures 64x64,128x128,256x256 .....
    cdlgFileOpen.ShowOpen
    bitmapFilename = cdlgFileOpen.filename
  
    If bitmapFilename = "" Then
        Unload frmMain
        Set frmMain = Nothing
        End
    End If
    
    If UCase(Right(bitmapFilename, 3)) = "BMP" Then
        pctTextureLoader.Picture = LoadPicture(bitmapFilename)
        CreateMapImage
    ElseIf UCase(Right(bitmapFilename, 3)) = "MOT" Then
        intFileHandle = FreeFile
        Open bitmapFilename For Binary Access Read Lock Read Write As intFileHandle
        Get #intFileHandle, , bitmapWidth
        Get #intFileHandle, , bitmapHeight
        ReDim bitmapImage(2, bitmapHeight - 1, bitmapWidth - 1)
        Get #intFileHandle, , bitmapImage
        Close intFileHandle
    End If
End Sub
Private Sub CreateMapImage()
    ' Create the array as needed for the image.
    
    bitmapHeight = pctTextureLoader.ScaleHeight
    bitmapWidth = pctTextureLoader.ScaleWidth
    
    ReDim bitmapImage(2, bitmapHeight - 1, bitmapWidth - 1)
    
    ' Fill the array with the bitmap data...  This could take
    ' a while...
    
    Dim X As Double, Y As Double
    Dim c As Long
    
    pctTextureLoader.ScaleMode = 3                  ' Pixels
    
    For X = 0 To bitmapWidth - 1
        For Y = 0 To bitmapHeight - 1
            c = pctTextureLoader.Point(X, Y)                ' Returns in long format.
            bitmapImage(0, X, bitmapHeight - Y - 1) = c Mod 256
            bitmapImage(1, X, bitmapHeight - Y - 1) = (c And 65280) / 256
            bitmapImage(2, X, bitmapHeight - Y - 1) = (c And 16711680) / 256 / 256
        Next
    Next
    
End Sub

Private Sub Form_Load()

   
 
    'Seting the trackball variables
    
    spinning = False
    moving = False
    anim = False
    StopAll = False
    H = frmMain.ScaleHeight
    W = frmMain.ScaleWidth
    newModel = True
    scaling = False
    scalefactor = 1
    trackball curquat, 0, 0, 0, 0
    
   ' End of trackball variables
   
    Show


    LoadImage                           ' Load the image into the buffer.
 
    displayListInited = GL_FALSE

    
    Dim hGLRC As Long                   ' Bind to the hdc.
    SetupPixelFormat hDC
    hGLRC = wglCreateContext(hDC)
    wglMakeCurrent hDC, hGLRC
    
    glEnable GL_DEPTH_TEST
    glDepthFunc GL_LESS
    
    glPixelStorei GL_UNPACK_ALIGNMENT, 1    ' Load the texture.
    glTexImage2D GL_TEXTURE_2D, 0, 3, bitmapWidth, bitmapHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, bitmapImage(0, 0, 0)
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
    glTexEnvf GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL
    glEnable GL_TEXTURE_2D
    glShadeModel GL_FLAT
    
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glFrustum -1, 1, -1, 1, 1, 10
    glViewport 0, 0, frmMain.ScaleWidth, frmMain.ScaleHeight
  
   
    glMatrixMode GL_MODELVIEW
    glTranslatef 0, 0, -4
    
       ' animation cycle
    Do
           
            DoEvents
                If StopAll Then Exit Do ' stop the program
            If anim Then animate
            
    Loop

    
    
End Sub




Private Sub Form_Paint()

      
    ' Trackball component
    If newModel Then
        recalcModelView
    End If
    ' end of trackball component

    If displayListInited = GL_TRUE Then
        glCallList 1
    Else
        glNewList 1, GL_COMPILE_AND_EXECUTE
        glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
        glBegin GL_QUADS
    
        ' Z axis
    
        glTexCoord2f 0, 0
        glVertex3f -1, 1, 1
        glTexCoord2f 1, 0
        glVertex3f 1, 1, 1
        glTexCoord2f 1, 1
        glVertex3f 1, -1, 1
        glTexCoord2f 0, 1
        glVertex3f -1, -1, 1
       
        glTexCoord2f 0, 0
        glVertex3f -1, 1, -1
        glTexCoord2f 1, 0
        glVertex3f 1, 1, -1
        glTexCoord2f 1, 1
        glVertex3f 1, -1, -1
        glTexCoord2f 0, 1
        glVertex3f -1, -1, -1
       
        ' Y axis
       
        glTexCoord2f 0, 0
        glVertex3f -1, 1, -1
        glTexCoord2f 1, 0
        glVertex3f 1, 1, -1
        glTexCoord2f 1, 1
        glVertex3f 1, 1, 1
        glTexCoord2f 0, 1
        glVertex3f -1, 1, 1
       
        glTexCoord2f 0, 0
        glVertex3f -1, -1, -1
        glTexCoord2f 1, 0
        glVertex3f 1, -1, -1
        glTexCoord2f 1, 1
        glVertex3f 1, -1, 1
        glTexCoord2f 0, 1
        glVertex3f -1, -1, 1
    
        ' X axis
    
        glTexCoord2f 0, 0
        glVertex3f 1, 1, -1
        glTexCoord2f 1, 0
        glVertex3f 1, 1, 1
        glTexCoord2f 1, 1
        glVertex3f 1, -1, 1
        glTexCoord2f 0, 1
        glVertex3f 1, -1, -1
          
        glTexCoord2f 0, 0
        glVertex3f -1, 1, -1
        glTexCoord2f 1, 0
        glVertex3f -1, 1, 1
        glTexCoord2f 1, 1
        glVertex3f -1, -1, 1
        glTexCoord2f 0, 1
        glVertex3f -1, -1, -1
          
    glEnd
    glEndList
    displayListInited = GL_TRUE
    End If
        
    SwapBuffers hDC
End Sub
Private Sub Form_Resize()

   

    glViewport 0, 0, frmMain.ScaleWidth, frmMain.ScaleHeight
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    
    gluPerspective 40, frmMain.ScaleWidth / frmMain.ScaleHeight, 1, 40
   
     gluLookAt 0, 0, 5, 0, 0, 0, 0, 1, 0
   
    glMatrixMode GL_MODELVIEW
   
    Form_Paint

End Sub
Private Sub Form_Unload(Cancel As Integer)
        
    StopAll = True
    
    If hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext hGLRC
    End If
    If hPalette <> 0 Then
        DeleteObject hPalette
    End If
End Sub

