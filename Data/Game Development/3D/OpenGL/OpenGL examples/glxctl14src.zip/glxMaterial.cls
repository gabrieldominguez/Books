VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxMaterial"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: utility class for SDK samples
'   - does a nice material transition effect
'   - you can create materials without filling arrays, and then
'   - call 'SetMaterial' to make a material current
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

Dim m_a(0 To 3) As Single    ' As RGBA
Dim m_d(0 To 3) As Single     'As RGBA
Dim m_s(0 To 3) As Single ' As RGBA
Dim m_specExp As Single
Dim m_Face As glFaceConstants

Private Sub Class_Initialize()
UC.Ex.FillArrayf m_a, 0.2, 0.2, 0.2, 1
UC.Ex.FillArrayf m_d, 0.8, 0.8, 0.8, 1
UC.Ex.FillArrayf m_s, 0, 0, 0, 1
m_Face = faceFrontAndBack
End Sub

Private Sub Class_Terminate()
'
End Sub

Public Property Get Ambient!(ByVal Index&)
Ambient = m_a(Index)
End Property

Public Property Let Ambient(ByVal Index&, ByVal NewValue!)
m_a(Index) = NewValue
End Property

Public Property Get Diffuse!(ByVal Index&)
Diffuse = m_d(Index)
End Property

Public Property Let Diffuse(ByVal Index&, ByVal NewValue!)
m_d(Index) = NewValue
End Property

Public Property Get Specular!(ByVal Index&)
Specular = m_s(Index)
End Property

Public Property Let Specular(ByVal Index&, ByVal NewValue!)
m_s(Index) = NewValue
End Property

'this is too confusing. SpecExp was suppossed to be clamped
'value - 0 to 1, but I keep forgetting.
Public Property Get SpecExp!()
SpecExp = m_specExp
End Property

Public Property Let SpecExp(ByVal NewValue!)
m_specExp = NewValue
'catch my old errors
If m_specExp < 1 Then m_specExp = m_specExp * 128
If m_specExp > 128 Then m_specExp = 128
End Property

Public Property Get Shininess!()
Shininess = m_specExp
End Property

Public Property Let Shininess(ByVal NewValue!)
m_specExp = NewValue
If m_specExp > 128 Then m_specExp = 128
End Property

Public Sub SetAmbient(ByVal r!, ByVal g!, ByVal B!, Optional A! = 1)
m_a(0) = r
m_a(1) = g
m_a(2) = B
m_a(3) = A
End Sub

Public Sub SetDiffuse(ByVal r!, ByVal g!, ByVal B!, Optional A! = 1)
m_d(0) = r
m_d(1) = g
m_d(2) = B
m_d(3) = A
End Sub

Public Sub SetSpecular(ByVal r!, ByVal g!, ByVal B!, Optional A! = 1)
m_s(0) = r
m_s(1) = g
m_s(2) = B
m_s(3) = A
End Sub

''---------------------------------------------------------------------------------
'SetMaterial
'* Set specified material with MATERIAL structure
'-------------------------------------------------------------------------
Public Sub SetMaterial()
    glMaterialfv m_Face, GL_AMBIENT, m_a(0)
    glMaterialfv m_Face, GL_DIFFUSE, m_d(0)
    glMaterialfv m_Face, GL_SPECULAR, m_s(0)
    glMaterialf m_Face, GL_SHININESS, m_specExp ' * 128
End Sub


''---------------------------------------------------------------------------------
'CreateMaterialGradient
'* Given 2 materials and a count, create an incremental material, such
'* that adding it 'count' times to the first material will generate the
'* 2nd material.
'-------------------------------------------------------------------------
Public Sub CreateMaterialGradient(matInc As glxMaterial, startMat As glxMaterial, _
                       endMat As glxMaterial, ByVal transCount&)
Const FMAT_GRAD_FUDGE = 1.0001
Dim fTransCount!
    If transCount = 0 Then
        Set matInc = endMat
        Exit Sub
    End If
    ' Add fudge factor to avoid round-off error, which could result in
    ' invalid material values.
    fTransCount = transCount * FMAT_GRAD_FUDGE
    matInc.Ambient(0) = (endMat.Ambient(0) - startMat.Ambient(0)) / fTransCount
    matInc.Ambient(1) = (endMat.Ambient(1) - startMat.Ambient(1)) / fTransCount
    matInc.Ambient(2) = (endMat.Ambient(2) - startMat.Ambient(2)) / fTransCount
    matInc.Specular(0) = (endMat.Specular(0) - startMat.Specular(0)) / fTransCount
    matInc.Specular(1) = (endMat.Specular(1) - startMat.Specular(1)) / fTransCount
    matInc.Specular(2) = (endMat.Specular(2) - startMat.Specular(2)) / fTransCount
    matInc.Diffuse(0) = (endMat.Diffuse(0) - startMat.Diffuse(0)) / fTransCount
    matInc.Diffuse(1) = (endMat.Diffuse(1) - startMat.Diffuse(1)) / fTransCount
    matInc.Diffuse(2) = (endMat.Diffuse(2) - startMat.Diffuse(2)) / fTransCount
    matInc.SpecExp = (endMat.SpecExp - startMat.SpecExp) / fTransCount
End Sub

''---------------------------------------------------------------------------------
'TransitionMaterial
'* Given a material, add to it the incremental material, and set the
'* result as the current material
'-------------------------------------------------------------------------
Public Sub TransitionMaterial(transMat As glxMaterial, transMatInc As glxMaterial)
    transMat.Ambient(0) = transMat.Ambient(0) + transMatInc.Ambient(0)
    transMat.Ambient(1) = transMat.Ambient(1) + transMatInc.Ambient(1)
    transMat.Ambient(2) = transMat.Ambient(2) + transMatInc.Ambient(2)
    transMat.Diffuse(0) = transMat.Diffuse(0) + transMatInc.Diffuse(0)
    transMat.Diffuse(1) = transMat.Diffuse(1) + transMatInc.Diffuse(1)
    transMat.Diffuse(2) = transMat.Diffuse(2) + transMatInc.Diffuse(2)
    transMat.Specular(0) = transMat.Specular(0) + transMatInc.Specular(0)
    transMat.Specular(1) = transMat.Specular(1) + transMatInc.Specular(1)
    transMat.Specular(2) = transMat.Specular(2) + transMatInc.Specular(2)
    transMat.SpecExp = transMatInc.SpecExp
    transMat.SetMaterial
End Sub

Public Property Get face() As glFaceConstants
face = m_Face
End Property

Public Property Let face(ByVal NewValue As glFaceConstants)
Select Case NewValue
Case faceFront, faceBack, faceFrontAndBack
    m_Face = NewValue
End Select
End Property

