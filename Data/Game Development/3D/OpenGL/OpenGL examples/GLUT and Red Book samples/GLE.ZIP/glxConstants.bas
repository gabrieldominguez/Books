Attribute VB_Name = "mConstants"
Public gCtl As glxCtl
Public CX As CGLETest
'
Public Const PI = 3.141592654
Public Const M_PI = 3.14159265358979
Public optMouseTrack As Boolean
Public Const TEXTURE_SIZE& = 256

Public current_texture As glxTexture

Public planet_texture As glxTexture
Public check_texture As glxTexture
Public barberpole_texture As glxTexture
Public wild_tooth_texture As glxTexture

Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type
'
'this variable is used for setting contours
Public CurModel As Object

'set curmodel before using
'counterclockwise
Public Sub CONTOUR2(ByVal i&, ByVal x#, ByVal y#, Optional dSCALE# = 1)
Dim ax#, ay#, alen#
Static x2#, y2#
With CurModel
    x = dSCALE * x
    y = dSCALE * y
    .SetContourPt i, x, y
    If i > 0 Then
        NORMAL2 x2, y2, x, y, ax, ay
        .SetContourNormal (i), ax, -ay
    End If
    x2 = x
    y2 = y
End With
End Sub

'counterclockwise
Public Sub NORMAL2(x1#, y1#, x2#, y2#, nx#, ny#)
Dim alen#
    nx = x2 - x1
    ny = y2 - y1
    alen = 1 / Sqr(nx * nx + ny * ny)
    nx = nx * alen
    ny = ny * alen
End Sub


Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

