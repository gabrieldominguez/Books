Attribute VB_Name = "mMain"
Option Explicit
'******************************Module*Header******************************
'FUNCTION: This sample shows how to mix GL and GDI.
'The sample renders to an offscreen memory DIB, then
'blits the DIB to the form.
'AUTHOR: Thanks to Karl Stadler who worked out a lot of this.
'He uses this to implement AutoCAD cursors.
'HISTORY: -
'NOTES: The DIB is resized in Reshape so it matches the size
'of the display DC (the window where it will be blitted, in this
'case, frmMain). Beware of memory leaks.
'You can use this technique facilitate printing. Other possibilities
'which I haven't explored include layers and compositing.
'
'The next version of the ocx (1.4>) will have this functionality.
'I haven't really timed it, but this seems marginally faster than
'using SwapBuffers (on a MS software implementation).
'*************************************************************************
Public pfd As PIXELFORMATDESCRIPTOR
Public hDC&, hMemDC&, hRC&
Public QuadObj&
Public WinWidth&, WinHeight&
Dim hBmpOld&
Dim hBmp&
'
'GDI stuff
Dim m_DrawMode As ROP2Modes
'pen
Dim m_DrawWidth As Long
Dim m_ForeColor As OLE_COLOR
Dim m_DrawStyle As PenStyles
'brush
Dim m_FillColor As OLE_COLOR
Dim m_FillStyle As Long

Dim m_CurPen As Long          'Handle of current pen
Dim m_OldPen As Long          'Handle of old pen
Dim m_CurBrush As Long        'Handle of current brush
Dim m_OldBrush As Long        'Handle of old brush
Public Enum PenStyles
    psSolid = PS_SOLID
    psDash = PS_DASH
    psDot = PS_DOT
    psDashDot = PS_DASHDOT
    psDashDotDot = PS_DASHDOTDOT
    psNull = PS_NULL
    psInsideFrame = PS_INSIDEFRAME
End Enum
Public Enum ROP2Modes
    r2Black = R2_BLACK 'Pixel is always 0.
    r2CopyPen = R2_COPYPEN 'Pixel is the pen color.
    r2MaskNotPen = R2_MASKNOTPEN 'Pixel is a combination of the colors common to both the screen and the inverse of the pen.
    r2MaskPen = R2_MASKPEN ' Pixel is a combination of the colors common to both the pen and the screen.
    r2MaskPenNot = R2_MASKPENNOT ' Pixel is a combination of the colors common to both the pen and the inverse of the screen.
    r2MergNotPen = R2_MERGENOTPEN 'Pixel is a combination of the screen color and the inverse of the pen color.
    r2MergePen = R2_MERGEPEN ' Pixel is a combination of the pen color and the screen color.
    r2MergePenNot = R2_MERGEPENNOT ' Pixel is a combination of the pen color and the inverse of the screen color.
    r2NOP = R2_NOP ' Pixel remains unchanged.
    r2Not = R2_NOT 'Pixel is the inverse of the screen color.
    r2NotCopyPen = R2_NOTCOPYPEN ' Pixel is the inverse of the pen color.
    r2NotMaskPen = R2_NOTMASKPEN ' Pixel is the inverse of the R2_MASKPEN color.
    r2NotMergePen = R2_NOTMERGEPEN 'Pixel is the inverse of the R2_MERGEPEN color.
    r2NotXORPen = R2_NOTXORPEN ' Pixel is the inverse of the R2_XORPEN color.
    r2White = R2_WHITE ' Pixel is always 1.
    r2XORPen = R2_XORPEN ' Pixel is a combination of the colors in the pen and in the screen, but not in both.
End Enum
Public Enum HatchStyles
    hsBDiagonal = HS_BDIAGONAL ' A 45-degree upward, left-to-right hatch
    hsCross = HS_CROSS ' Horizontal and vertical cross-hatch
    hsDiagCross = HS_DIAGCROSS ' 45-degree crosshatch
    hsFDiagonal = HS_FDIAGONAL ' A 45-degree downward, left-to-right hatch
    hsHorizontal = HS_HORIZONTAL ' Horizontal hatch
    hsVertical = HS_VERTICAL
End Enum

'----------------------------------------------------------------------------
Public Sub Main()
Set CX = New CXXX
CX.InitGL
frmMain.Show
End Sub

'-------------------------------------------------------------------------
' release the RC and Memory Device Context.
'-------------------------------------------------------------------------
Public Sub ReleaseRC()
Dim r&
    wglMakeCurrent 0, 0
    wglDeleteContext hRC
    If hBmpOld Then
        hBmp = SelectObject(hMemDC, hBmpOld)
        DeleteObject hBmp: hBmp = 0
    End If
    'GDI objects
    If m_OldPen Then
        SelectObject hMemDC, m_OldPen: m_OldPen = 0
    End If
    If m_CurPen <> 0 Then
        DeleteObject m_CurPen: m_CurPen = 0
    End If
    If m_OldBrush <> 0 Then
        SelectObject hMemDC, m_OldBrush: m_OldBrush = 0
    End If
    If m_CurBrush <> 0 Then
        DeleteObject m_CurBrush: m_CurBrush = 0
    End If
    If hMemDC Then
        r = DeleteDC(hMemDC)
    End If
End Sub

'-------------------------------------------------------------------------
' Create a DIB section
'-------------------------------------------------------------------------
Public Function ReCreateDIB(W&, H&) As Boolean
Dim bits() As Byte
Dim bpp&
Dim bfh As BITMAPFILEHEADER, bi As BITMAPINFO
Dim ptr&
Dim dwSizeImage&, s$
Dim hCurBmp&
    bpp = 24
    dwSizeImage = W * H * bpp / 8 ' i.e. 3
    ' set the pixel data in the pic
    bi.bmiHeader.biSize = Len(bi.bmiHeader)
    bi.bmiHeader.biWidth = W
    bi.bmiHeader.biHeight = H
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 24
    bi.bmiHeader.biCompression = BI_RGB
    bi.bmiHeader.biSizeImage = dwSizeImage
    bi.bmiHeader.biXPelsPerMeter = 2952
    bi.bmiHeader.biYPelsPerMeter = 2952
    'delete current BMP
    hCurBmp = SelectObject(hMemDC, hBmpOld)
    DeleteObject hCurBmp
    ' Create a DIB surface
    hBmp = CreateDIBSection(hDC, bi, DIB_RGB_COLORS, ptr, 0, 0)
    If hBmp Then
        ' Select the DIB Surface into the dc
        hBmpOld = SelectObject(hMemDC, hBmp)
        If hBmpOld = 0 Then
            Debug.Assert 0
        End If
        ReCreateDIB = True
    Else
        Debug.Print "CreateDIBSection Error"
        Debug.Assert 0
    End If
End Function

'-------------------------------------------------------------------------
' Create a DIB section
'-------------------------------------------------------------------------
Public Function CreateDIB(W&, H&) As Boolean
Dim bits() As Byte
Dim bpp&
Dim bfh As BITMAPFILEHEADER, bi As BITMAPINFO
Dim ptr&
Dim dwSizeImage&, s$
    bpp = 24
    dwSizeImage = W * H * bpp / 8 ' i.e. 3
    ' set the pixel data in the pic
    bi.bmiHeader.biSize = Len(bi.bmiHeader)
    bi.bmiHeader.biWidth = W
    bi.bmiHeader.biHeight = H
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 24
    bi.bmiHeader.biCompression = BI_RGB
    bi.bmiHeader.biSizeImage = dwSizeImage
    bi.bmiHeader.biXPelsPerMeter = 2952
    bi.bmiHeader.biYPelsPerMeter = 2952
    ' Create a DIB surface
    hBmp = CreateDIBSection(hDC, bi, DIB_RGB_COLORS, ptr, 0, 0)
    If hBmp Then
        ' Select the DIB Surface into the dc
        hBmpOld = SelectObject(hMemDC, hBmp)
        If hBmpOld = 0 Then
            Debug.Assert 0
        End If
        CreateDIB = True
    Else
        Debug.Print "CreateDIBSection Error"
        Debug.Assert 0
    End If
End Function

'-------------------------------------------------------------------------
' Set up a Memory Device Context.
' Call this once at startup.
'-------------------------------------------------------------------------
Public Function CreateMemDC() As Boolean
On Error GoTo eh
    hDC = frmMain.hDC
    ' Create Compatible Memory Device Context
    hMemDC = CreateCompatibleDC(hDC)
    If hMemDC = 0 Then
        Debug.Print "CompatibleDC Error"
        GoTo eh
    End If
    If Not CreateDIB(frmMain.ScaleWidth, frmMain.ScaleHeight) Then
        Debug.Print "CreateDIB failed"
        GoTo eh
    End If
    ' Set up a Pixel format for the DIB surface
    If Not m_SetupPixelFormat(hMemDC, hRC) Then
        Debug.Print "SetPixelFormat failed"
        GoTo eh
    End If
    'set up GDI stuff
    SetBkMode hMemDC, 1   'Transparent
    m_ForeColor = QBColor(15) 'white
    m_DrawWidth = 1
    m_FillStyle = 1  'default  transparent
    m_FillColor = QBColor(15)
    DrawStyle = psSolid 'cause pen to be created
    CreateMemDC = True
    Exit Function
eh:
    Screen.MousePointer = 0
    Debug.Assert 0
    Exit Function
    Resume Next
End Function

'-----------------------------------------------------------------
'* SetupPixelFormat
'* Choose pixel format according to supplied flags.  If gpfd is non-0,
'* call DescribePixelFormat with it.
'-----------------------------------------------------------------
Private Function m_SetupPixelFormat(hDC&, hRC&) As Boolean
Dim PixelFormat&
Dim flags&
    'flags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_TYPE_RGBA Or PFD_DOUBLEBUFFER
    flags = PFD_DRAW_TO_BITMAP Or PFD_SUPPORT_OPENGL Or PFD_SUPPORT_GDI
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = flags
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    PixelFormat = ChoosePixelFormat(hDC, pfd)
    If PixelFormat Then
        If SetPixelFormat(hDC, PixelFormat, pfd) Then
            DescribePixelFormat hDC, PixelFormat, _
                            Len(pfd), pfd
            If pfd.dwFlags And PFD_NEED_SYSTEM_PALETTE Then
                'not supported as of now
                Debug.Assert 0
                Exit Function
            End If
            ' Create a OpenGL context
            hRC = wglCreateContext(hDC)
            If hRC = 0 Then
                MsgBox "OpenGL Context Error"
                Exit Function
            End If
            ' Setting up the current OpenGL context
            If wglMakeCurrent(hDC, hRC) = 0 Then
                MsgBox "Error:wglMakeCurrent Failed"
                Exit Function
            End If
            m_SetupPixelFormat = True
        End If
    Else
        MsgBox "ChoosePixelFormat failed"
        Exit Function
    End If
End Function

'-------------------------------------------------------------------------
' PROPERTIES FOR GDI
'-------------------------------------------------------------------------
    
Public Property Get Drawmode() As ROP2Modes
    Drawmode = m_DrawMode
End Property

Public Property Let Drawmode(ByVal vNewValue As ROP2Modes)
    If vNewValue <= 0 Then vNewValue = 1
    If vNewValue > 16 Then vNewValue = 16
    m_DrawMode = vNewValue
    SetROP2 hMemDC, m_DrawMode
End Property

'-------------------------------------------------------------------------
Public Property Get ForeColor() As OLE_COLOR
    ForeColor = m_ForeColor
End Property

Public Property Let ForeColor(ByVal vNewValue As OLE_COLOR)
    m_ForeColor = vNewValue
    m_CreatePen
End Property

'-------------------------------------------------------------------------
Public Property Get FillColor() As OLE_COLOR
    FillColor = m_FillColor
End Property

Public Property Let FillColor(ByVal vNewValue As OLE_COLOR)
    m_FillColor = vNewValue
    m_CreateBrush
End Property

'-------------------------------------------------------------------------
Public Property Get DrawWidth() As Long
    DrawWidth = m_DrawWidth
End Property

Public Property Let DrawWidth(ByVal vNewValue As Long)
    If vNewValue < 0 Then vNewValue = 0
    m_DrawWidth = vNewValue
    m_CreatePen
End Property

'-------------------------------------------------------------------------
Public Sub SetPen(ByVal DrawStyle As PenStyles, ByVal DrawWidth As Long, ByVal ForeColor As OLE_COLOR)
    m_DrawStyle = DrawStyle
    m_DrawWidth = DrawWidth
    m_ForeColor = ForeColor
    m_CreatePen
End Sub

'-------------------------------------------------------------------------
Public Property Get DrawStyle() As PenStyles
    DrawStyle = m_DrawStyle
End Property

Public Property Let DrawStyle(ByVal vNewValue As PenStyles)
    If vNewValue < 0 Then vNewValue = 0
    If vNewValue > 6 Then vNewValue = 6
    m_DrawStyle = vNewValue
    m_CreatePen
End Property

'-------------------------------------------------------------------------
Public Property Get FillStyle() As Long
    FillStyle = m_FillStyle
End Property

Public Property Let FillStyle(ByVal vNewValue As Long)
    If vNewValue < 0 Then vNewValue = 0
    If vNewValue > 7 Then vNewValue = 7
    m_FillStyle = vNewValue
    m_CreateBrush
End Property

'-------------------------------------------------------------------------
' GDI DRAWING ROUTINES
'-------------------------------------------------------------------------
Public Sub GDILine(ByVal x1 As Long, ByVal y1 As Long, ByVal x2 As Long, ByVal y2 As Long)
    MoveToEx hMemDC, x1, y1, ByVal 0&
    LineTo hMemDC, x2, y2
End Sub

Public Sub GDICircle(ByVal x As Long, ByVal y As Long, ByVal r As Long)
    Chord hMemDC, x - r, y - r, x + r, y + r, x + r, y, x + r, y
End Sub

Public Sub GDIText(ByVal x As Long, ByVal y As Long, loctext As String)
    TextOut hMemDC, x, y, loctext, Len(loctext)
End Sub

'-------------------------------------------------------------------------
' PRIVATE UTILITY ROUTINES FOR GDI
'-------------------------------------------------------------------------
    
'-------------------------------------------------------------------------
'create a pen using current properties
'-------------------------------------------------------------------------
Private Function m_CreatePen&()
Dim locPen As Long
    SetTextColor hMemDC, m_ForeColor
    locPen = CreatePen(m_DrawStyle, m_DrawWidth, m_ForeColor)
    Debug.Assert (locPen <> 0)
    If m_OldPen = 0 Then
        'store oldpen only the first time (default-Pen of DC)
        m_OldPen = SelectObject(hMemDC, locPen)
    Else
        SelectObject hMemDC, locPen
        DeleteObject m_CurPen
    End If
    m_CurPen = locPen
End Function

'-------------------------------------------------------------------------
'create a pen using current properties
'-------------------------------------------------------------------------
Private Sub m_CreateBrush()
Dim locBrush As Long
Dim logbr As LOGBRUSH
    logbr.lbColor = m_FillColor
    Select Case m_FillStyle
    Case 0: logbr.lbStyle = BS_SOLID
    Case 1: logbr.lbStyle = BS_NULL
    Case Else: logbr.lbStyle = BS_HATCHED
    End Select
    
    If m_FillStyle > 2 Then
        logbr.lbHatch = m_FillStyle - 2
    Else
        logbr.lbHatch = 0
    End If
    locBrush = CreateBrushIndirect(logbr)
    Debug.Assert (locBrush <> 0)
    If m_OldBrush = 0 Then
        'store oldBrush only the first time (default-Brush of DC)
        m_OldBrush = SelectObject(hMemDC, locBrush)
    Else
        SelectObject hMemDC, locBrush
        DeleteObject m_CurBrush
    End If
       
    m_CurBrush = locBrush
End Sub



