//--------------------------------------------------------------------------
// Clase TFuncionGL
//--------------------------------------------------------------------------
#include <GL/glut.h>    // opengl y utilizades
//--------------------------------------------------------------------------
class TFuncionGL
{ private:
    static void Refrescar(int Ancho, int Alto);  // necesariamente "static"
    static void Dibujar();
  public:
    void CrearVentana(int argc, char** argv);
    void Mostrar();
};
//--------------------------------------------------------------------------
// Refrescar: se llama, por ejemplo, ante el cambio de tama�o
//--------------------------------------------------------------------------
void TFuncionGL::Refrescar(int Ancho, int Alto)
{ glViewport(0, 0, Ancho, Alto);
}
//--------------------------------------------------------------------------
// Dibujar: grafica la funci�n y se llama despu�s de refrescar
//--------------------------------------------------------------------------
void TFuncionGL::Dibujar()
{ float x, y, xG, yG;
  int i, Puntos;

  glClear(GL_COLOR_BUFFER_BIT);

  // dibuja los ejes
  glColor3f(0.0f, 0.0f, 0.0f);
  glLineWidth(1);
  glBegin(GL_LINES);
    glVertex2f(-1.0f, 0.0f);
    glVertex2f(1.0f, 0.0f);
    glVertex2f(0.0f, 1.0f);
    glVertex2f(0.0f, -1.0f);
  glEnd();

  // dibuja la funcion sen(x)/x
  glColor3f(0.0f, 0.0f, 1.0f);
  glLineWidth(1);
  Puntos=1001;
  glBegin( GL_LINE_STRIP );
    for (i=-Puntos/2;i<Puntos/2;i++)
    { x=50.0*i/Puntos;        // coordenas reales
      if (x!=0) y=sin(x)/x;
      else y=1.0;
      xG=x*2.0/50.0; yG=y;    // coordenas gr�ficas
      glVertex2f(xG, yG);     // graficaci�n
    }
  glEnd();
};
//--------------------------------------------------------------------------
// CrearVentana: configura la ventana principal (no la muestra)
//--------------------------------------------------------------------------
void TFuncionGL::CrearVentana(int argc, char** argv)
{ // inicializaci�n
  glutInit(&argc, argv);
  glutInitWindowSize(401, 301);
  glutInitWindowPosition(100, 100);
  glutInitDisplayMode(GLUT_RGB);
  glutCreateWindow("Funci�n con OpenGL");

  // Indica a que funci�n llamar para:
  glutReshapeFunc(Refrescar);   // cambiar el tama�o de la ventana
  glutDisplayFunc(Dibujar);     // dibujar
  glClearColor(1, 1, 1, 0);     // establece el color cuando se borra
};
//--------------------------------------------------------------------------
// Mostrar: se mantiene mostrando la ventana hasta que sea cerrada
//--------------------------------------------------------------------------
void TFuncionGL::Mostrar()
{ glutMainLoop();
};
//--------------------------------------------------------------------------
