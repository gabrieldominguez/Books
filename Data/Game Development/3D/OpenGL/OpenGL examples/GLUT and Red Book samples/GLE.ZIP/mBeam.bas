Attribute VB_Name = "mBeam"
Option Explicit
' * beam.c
' *
' * FUNCTION:
' * Show how twisting is applied.
' *
' * HISTORY:
' * -- linas Vepstas October 1991
' * -- heavily modified to draw corrugated surface, Feb 1993, Linas
' * -- modified to demo twistoid March 1993
' * -- port to glut Linas Vepstas March 1995
' */

' =========================================================== */
Public IDBeam&
Dim Beam As gleTwistExtrusion
Const NUM_BEAM_PTS = 22
Const TSCALE = 9
Const xSCALE = 0.2
Const NUM_XSECTION_PTS = 12

' =========================================================== */
'todo - th
Sub XSECTION(x#, y#, i&)
Dim ax#, ay#, alen#
Static dx#, dy#
With Beam
    .SetContourPt i, xSCALE * (x), xSCALE * (y)
    If (i <> 0) Then
        ax = x - dx
        ay = y - dy
        alen = 1 / Sqr(ax * ax + ay * ay)
        ax = ax * alen
        ay = ay * alen
        'these points are being specified clockwise
        .SetContourNormal (i - 1), ay, ax
    End If
    i = i + 1
    dx = x
    dy = y
End With
End Sub

' =========================================================== */
Public Sub InitBeam()
Dim i&
    Set Beam = gCtl.NewTwist
With Beam
    .JoinStyle = CX.JoinStyle
    .NormStyle = CX.NormStyle
    .NumContourPoints = NUM_XSECTION_PTS
    .NumContourNormals = NUM_XSECTION_PTS
    .NumPoints = NUM_BEAM_PTS
    .NumtwistPts = NUM_BEAM_PTS
    .TextureEnabled = CX.TextureEnabled
    .TextureMode = CX.TextureStyle
    Do While i < 22
        .SetPt i, TSCALE * -1.1 + (i) / 10, _
             TSCALE * 0, _
              TSCALE * 0
        i = i + 1
    Loop
    i = 0
    XSECTION -6, 6, i
    XSECTION 6, 6, i
    XSECTION 6, 5, i
    XSECTION 1, 5, i
    XSECTION 1, -5, i
    XSECTION 6, -5, i
    XSECTION 6, -6, i
    XSECTION -6, -6, i
    XSECTION -6, -5, i
    XSECTION -1, -5, i
    XSECTION -1, 5, i
    XSECTION -6, 5, i
    .SetContourNormal 11, 0, 1
End With
    IDBeam = glGenLists(1)
    glNewList IDBeam, lstCompile
        DrawBeam
    glEndList
End Sub

Sub TwistBeam(howmuch#)
Dim i&, z#
With Beam
    For i = 0 To 21
        z = (i - 14) / 10
        .twist(i) = howmuch * Exp(-3 * z * z)
    Next
End With
End Sub

' =========================================================== */

Public Sub DrawBeam()
    TwistBeam (CX.MouseX - 121) / 8
'   gleTwistExtrusion (NUM_XSECTION_PTS, xsection, xnormal,
'              NULL, NUM_BEAM_PTS, beam_spine, NULL, beam_twists);
    glPushMatrix
        glTranslatef 16, 0, 0
        glScaled 2.8, 2.8, 2.8
        Beam.Draw
    glPopMatrix
End Sub
' ------------------ end of file -------------------- */

