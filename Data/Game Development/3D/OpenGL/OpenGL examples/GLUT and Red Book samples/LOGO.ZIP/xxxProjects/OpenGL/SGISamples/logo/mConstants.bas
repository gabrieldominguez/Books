Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CLogo
Public xRotation!, yRotation!, zTranslation!
Public plane#(0 To 3) ' = {1.0, 0.0, -1.0, 0.0};
'
Public Const PI = 3.141592654
'Public Const black = 0
Public Const gray = 128
'Public Const white = 255
Public Const BL = &H0
Public Const WH = &HFF
Public Const CHECKIMAGEWIDTH = 8
Public Const CHECKIMAGEHEIGHT = 8
Public Const BRICKIMAGEWIDTH = 16
Public Const BRICKIMAGEHEIGHT = 16
Public Const RD = 1
Public Const WT = 2

Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type
Public clrRed(0 To 3) As Byte '= &HA4,&H00,&H00,&HFF
Public clrWhite(0 To 3) As Byte '= &HFF,&HFF,&HFF,&HFF

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillColorArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        If v = RD Then
            a(i) = clrRed(0)
            a(i + 1) = clrRed(1)
            a(i + 2) = clrRed(2)
            a(i + 3) = clrRed(3)
        Else
            a(i) = clrWhite(0)
            a(i + 1) = clrWhite(1)
            a(i + 2) = clrWhite(2)
            a(i + 3) = clrWhite(3)
        End If
        i = i + 4
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArray2f(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArray3f(a() As POINT3F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        a(i, j).p(2) = n(cnt + 2)
        cnt = cnt + 3
    Next
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillTSCPArray(a() As POINT2F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        j = j + 2
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillCPArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub



