VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY: - updated Oct 98
'NOTES: The quadobj is just for testing.
'*************************************************************************
Dim QID&, GridListID&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
Dim m_SizeX!, m_SizeY!, m_SizeZ!
Dim m_Grid&, m_GridStep!
Dim m_EyeDist!
Dim angle!  ' in degrees */
Dim angle2!   ' in degrees */


Private Sub Class_Initialize()
    m_SizeX! = 100
    m_SizeY = 100
    m_SizeZ! = 100
    angle = 150
    angle2 = 30
    m_EyeDist = 10
End Sub

Private Sub Class_Terminate()
    ReleaseRC
End Sub

Public Sub InitGL()
    If Not CreateMemDC Then
        Debug.Assert 0
        Exit Sub
    End If
    glClearColor 0.3, 0.3, 0.3, 0
    glClearDepth 1
    glEnable GL_DEPTH_TEST
    glEnable GL_LIGHTING
    glEnable glcLight0
    '----------------------------------------------------------------------------
    Set Camera = New CCamera
    With Camera
        .FarPlane = 1000
        .NearPlane = 0.1
        .FieldOfView = 45
        .SetEyePos 0, 0, m_EyeDist
        .SetTargetPos 0, 0, 0
    End With
    '
    '----------------------------------------------------------------------------
    m_Grid = glxGridX
    m_GridStep = 10
    m_Grids = True
    CreateGrids
    QuadObj = gluNewQuadric
    QID = 1 'name for the ball
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    '----------------------------------------------------------------------------
    
End Sub

Public Sub Draw()
    'GL drawing
    wglMakeCurrent hMemDC, hRC
    glClear clrColorBufferBit Or clrDepthBufferBit
    glLoadIdentity
    Camera.Update
    glPushMatrix
        ' Perform scene rotations based on user mouse input. */
        glRotatef angle2, 1, 0, 0
        glRotatef angle, 0, 1, 0
        If m_Grids Then
            glCallList GridListID
        End If
        glLoadName QID
        gluSphere QuadObj, 1, 16, 16
    glPopMatrix
    glFlush
    'GDI drawing
    DrawGDI
    BitBlt frmMain.hDC, 0, 0, WinWidth, WinHeight, hMemDC, 0, 0, SRCCOPY
    CheckError
End Sub

Public Sub DrawGDI()
    GDIText 10, 10, "Drawing 1"
End Sub

Public Sub Reshape(width&, height&)
    Camera.OnSize width, height, True
    WinWidth = width
    WinHeight = height
    ReCreateDIB width, height
    Draw
End Sub

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 2 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 2 Then
        If Shift = 1 Then
            If (y - m_StartY) > 0 Then
                m_EyeDist = m_EyeDist * 1.05 '
            Else
                m_EyeDist = m_EyeDist * 0.95 '
            End If
            If m_EyeDist < 1 Then m_EyeDist = 1
            If m_EyeDist > 500 Then m_EyeDist = 500
            Camera.SetEyePos 0, 0, m_EyeDist
        Else
            angle = angle + (x - m_StartX)
            angle2 = angle2 + (y - m_StartY)
        End If
            Draw
            m_StartX = x
            m_StartY = y
    Else
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

'Public Sub Pick(items() As Long)
'Dim Name&, ptr&, i&, j&, cnt&, n&
'Dim Picked&, z#, z1!
'    'bug: ocx returns right clicks
'    If Not m_bMoving Then Exit Sub
'    'Z = 1.79769313486232E308
'    z = 10000000000# ' a big number, limit of the data type
'    Debug.Print "/////////////////////////////////////"
'    cnt = gCtl.hits
'    Debug.Print "Count:" & cnt
'    If cnt Then
'        For i = 1 To cnt
'            'Debug.Print "Name " & i & ":"
'            '1.number of names on stack
'                n = items(ptr)
'                Debug.Print " number of names = " & n
'                ptr = ptr + 1
'            '2.z1
'                Debug.Print " z1 = " & items(ptr)
'                z1 = items(ptr)
'                ptr = ptr + 1
'            '3.z2
'                Debug.Print " z2 = " & items(ptr)
'                ptr = ptr + 1
'            '4.names
'            For j = 1 To n
'                Debug.Print "    name " & (j) & " = " & items(ptr)
'                If items(ptr) <> -1 Then
'                    'get the lowest z-value, nearest node
'                    If z1 < z Then
'                        z = z1
'                        Picked = items(ptr)
'                    End If
'                End If
'                ptr = ptr + 1
'            Next
'        Next
'    Else
'        Exit Sub
'    End If
'    Debug.Print "Selected: " & Picked
'    If Picked > 0 Then
'        'gCtl.Render
'    End If
'End Sub

Public Sub DrawAxes()
Dim nRange&
Dim clr!(0 To 3)
Dim x!, z!
glGetFloatv GL_CURRENT_COLOR, clr(0)
glPushMatrix
    'draw axes
    glNormal3f 0, 1, 0
    glBegin GL_LINES
        'x
        glColor3f 1, 0, 0
        nRange = m_SizeX
        glVertex3f -nRange, 0, 0
        glVertex3f nRange, 0, 0
       'y
        glColor3f 0, 1, 0
        nRange = m_SizeY
        glVertex3f 0, -nRange, 0
        glVertex3f 0, nRange, 0
        'z
        glColor3f 0, 0, 1
        nRange = m_SizeZ
        glVertex3f 0, 0, -nRange
        glVertex3f 0, 0, nRange
    glEnd
glPopMatrix
glColor4f clr(0), clr(1), clr(2), clr(3)
End Sub

'
Public Sub DrawGrid(ByVal axis&, Size1&, Size2&, ByVal nStep&, Optional Color& = &HC0C0C0)
Dim x!, z!
Dim clr!(0 To 3)
glGetFloatv GL_CURRENT_COLOR, clr(0)
glPushMatrix
    If nStep = 0 Then nStep = 1
    'validate range
    If Size1 < nStep Then Size1 = nStep
    If Size2 < nStep Then Size2 = nStep
    ' Draw Grid in Grey
    glColor3f 0.5, 0.5, 0.5
    glNormal3f 0, 1, 0
    'color axes R,G,B for X,Y,Z
    If axis = 2 Then
        glRotatef 90, 1, 0, 0
    ElseIf axis = 3 Then
        glRotatef 90, 0, 0, 1
    End If
    glBegin GL_LINES
        'Z lines going into z
        For x = -Size1 To Size1 Step nStep
            glVertex3f x, 0, -Size2
            glVertex3f x, 0, Size2
        Next
        'X lines parallel to x
        For z = -Size2 To Size2 Step nStep
            glVertex3f Size1, 0, z
            glVertex3f -Size1, 0, z
        Next
    glEnd
glPopMatrix
glColor4f clr(0), clr(1), clr(2), clr(3)
End Sub

'creates the WORLD_LIST
Public Sub CreateGrids()
Dim n&, gs&, x&, y&, z&
glPushMatrix
    GridListID = glGenLists(1)
    glNewList GridListID, GL_COMPILE
    glPushAttrib GL_LIGHTING_BIT
    glDisable GL_LIGHTING
    '
    n = m_Grid
    gs = m_GridStep
    x = m_SizeX
    y = m_SizeY
    z = m_SizeZ
    If n And glxGridX Then DrawGrid 1, x \ 2, z \ 2, gs ', &H880000
    If n And glxGridY Then DrawGrid 2, y \ 2, x \ 2, gs ', &H8800
    If n And glxGridZ Then DrawGrid 3, z \ 2, y \ 2, gs ', &H88
    DrawAxes
    glPopAttrib
    glEndList
glPopMatrix
End Sub










