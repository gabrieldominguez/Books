class AwesomeActor extends Actor
    placeable;

var string DeathMessage;

function PostBeginPlay()
{
    DeathMessage = "Tom Stewart killed me!";
    `log("Death message:" @ DeathMessage);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
