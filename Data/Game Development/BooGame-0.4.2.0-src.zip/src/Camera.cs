/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

using Tao.OpenGl;

namespace BooGame
{
	/// <summary>
	/// Module for the movable camera for moving the screen's visible area.
	/// </summary>
	public sealed class Camera
	{
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Camera()
        {
        }

		private static float m_X = 0f;
		private static float m_Y = 0f;
        /// <summary>
        /// Gets and sets the Y coordinate of the camera's top edge.
        /// </summary>
		public static float Y
		{
			get{ return m_Y; }
			set{ m_Y = value; }
		}

        /// <summary>
        /// Gets and sets the X coordinate of the camera's left edge.
        /// </summary>
		public static float X
		{
			get{ return m_X; }
			set{ m_X = value; }
		}

        /// <summary>
        /// Gets and sets the X coordinate of the camera's left edge.
        /// </summary>
        public static float Left
        {
            get
            {
                return Camera.X;
            }
            set
            {
                Camera.X = value;
            }
        }

        /// <summary>
        /// Gets and sets the X coordinate of the camera's right edge.
        /// </summary>
        public static float Right
        {
            get
            {
                return Camera.Left + Camera.Width;
            }
            set
            {
                Camera.Left = value - Camera.Width;
            }
        }

        /// <summary>
        /// Gets and sets the Y coordinate of the camera's top edge.
        /// </summary>
        public static float Top
        {
            get
            {
                return Camera.Y;
            }
            set
            {
                Camera.Y = value;
            }
        }

        /// <summary>
        /// Gets and sets the Y coordinate of the camera's bottom edge.
        /// </summary>
        public static float Bottom
        {
            get
            {
                return Camera.Top + Camera.Height;
            }
            set
            {
                Camera.Top = value - Camera.Height;
            }
        }

        /// <summary>
        /// Gets and sets the width of the displayable screen.
        /// </summary>
        public static float Width
        {
            get
            {
                return Display.Width * Camera.ScaleX;
            }
            set
            {
                Camera.ScaleX = value / Display.Width;
            }
        }

        /// <summary>
        /// Gets and sets the height of the displayable screen.
        /// </summary>
        public static float Height
        {
            get
            {
                return Display.Height * Camera.ScaleY;
            }
            set
            {
                Camera.ScaleY = value / Display.Height;
            }
        }

        /// <summary>
        /// Gets and sets the center point of the display.
        /// </summary>
        public static PointF Center
        {
            get
            {
                return new PointF(Left + Width / 2f, Top + Height / 2f);
            }
            set
            {
                Left = value.X - Width / 2f;
                Top = value.Y - Height / 2f;
            }
        }

        /// <summary>
        /// Gets and sets a rectangle representing the camera's displayable screen.
        /// </summary>
        public static RectangleF Rectangle
        {
            get
            {
                return new RectangleF(Left, Top, Width, Height);
            }
            set
            {
                Left = value.X;
                Top = value.Y;
                Width = value.Width;
                Height = value.Height;
            }
        }

        /// <summary>
        /// Gets and sets the camera's X and Y coordinates.
        /// </summary>
        public static PointF Location
        {
            get
            {
                return new PointF(X, Y);
            }
            set
            {
                X = value.X;
                Y = value.Y;
            }
        }

        /// <summary>
        /// Gets and sets the scale of the displayable screen.
        /// </summary>
		public static float Scale
		{
			get
			{
				return (m_ScaleX + m_ScaleY) / 2f;
			}
			set
			{
				m_ScaleX = value;
				m_ScaleY = value;
			}
		}

		private static float m_ScaleX = 1f;
        /// <summary>
        /// Gets and sets the X scale of the displayable screen.
        /// </summary>
		public static float ScaleX
		{
			get{ return m_ScaleX; }
			set{ m_ScaleX = value; }
		}

		private static float m_ScaleY = 1f;
        /// <summary>
        /// Gets and sets the Y scale of the displayable screen.
        /// </summary>
		public static float ScaleY
		{
			get{ return m_ScaleY; }
			set{ m_ScaleY = value; }
		}

        /// <summary>
        /// Moves the GL context to the correct location for the camera.
        /// </summary>
		internal static void ApplyMatrix()
		{
			// Location
			Gl.glTranslatef(-Camera.X, -Camera.Y, 0f);

			// Stretch
			Gl.glScalef(m_ScaleX, m_ScaleY, 1f);
		}
	}
}
