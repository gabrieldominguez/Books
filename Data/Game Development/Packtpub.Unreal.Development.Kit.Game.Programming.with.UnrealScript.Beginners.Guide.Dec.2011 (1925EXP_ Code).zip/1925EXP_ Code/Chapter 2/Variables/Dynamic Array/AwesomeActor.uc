class AwesomeActor extends Actor
    placeable;

var array<int> Baskets;

function PostBeginPlay()
{
    Baskets[3] = 9;
    `log("Basket array length:" @ Baskets.length);
    
    Baskets[Baskets.length] = 23;
    `log("Basket array length:" @ Baskets.length);
    `log("Last basket:" @ Baskets[Baskets.length - 1]);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
