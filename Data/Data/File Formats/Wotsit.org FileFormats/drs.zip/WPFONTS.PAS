program wpfonts;
{ tested with WP.DRS from DrawPerfect 1.0 }
uses graph,crt,dos;
const multx=1;
      multy=1;
      divx=20;
      divy=30;
      num=6;

type buffer=array[0..65534] of byte;
     index_type=array[0..67] of record
                                   offset:longint;
                                   lengte:word;
                                   xxxxxx:word
                                end;
     nindex_type=array[0..67] of word;
     names_type=array[0..1540] of byte;
     inhoud=record
               typ:word; { 4=bitmap, 8=outline}
               aantal_chars:word;
               table_offset:word;
               data_offset :word;
               data_lengte :word;
            end;
     table=array[0..32766] of word;
     data=array[0..65534] of byte;

     index_ptr=^index_type;
     table_ptr=^table;
     data_ptr=^data;
     pr=(_6,_7,_a,_b,_77);
     typ77=record x,y:integer end;
     typ6=record
                lengte:byte;
                data:array[1..255] of record x,y:shortint end
                end;
     typ7=record
                lengte:byte;
                data:array[1..255] of record x,y:integer end
                end;
     typa=record x1,y1,x2,y2,x3,y3:shortint end;
     typb=record x1,y1,x2,y2,x3,y3:integer end;
     line=record
                case code:pr of
                     $6 :(_6 :typ6);
                     $7 :(_7 :typ7);
                     $a :(_a :typa);
                     $b :(_b :typb);
                     $77:(_77:typ77)
                end;

var bezcoef:array[0..num,1..3]of real;
    heap:pointer;
procedure init_bezier;

var i,n:byte;
    x:real;
begin
for n:=0 to num do
    begin
    x:=n/num;
    bezcoef[n,1]:=x*(3+x*(x-3));
    bezcoef[n,2]:=x*x*(3-2*x);
    bezcoef[n,3]:=x*x*x;
    end;
end;

procedure init_graph;
var graphdriver,graphmode:integer;
begin {init}
  GraphDriver := ega;
  graphmode:= egahi;
  InitGraph(GraphDriver, GraphMode,getenv('BGIPATH'));
  SetTextStyle(DefaultFont, HorizDir, 1);
  SetTextJustify(LeftText, BottomText);
end; {init}

procedure init_fonts(var f:file;
                     var index:index_ptr;
                     var font_table:table_ptr;
                     var font_data:data_ptr;
                     var nindex:nindex_type;
                     var names:names_type);
begin
assign(f,'wp.drs');
{$i-}
reset(f,1);
{$i+}
if ioresult<>0
   then begin
        writeln('WP.DRS not found.');
        halt(1)
        end;
seek(f,$12d0);
getmem(index,$218);
blockread(f,index^,$218);
font_table:=nil;
font_data:=nil;
seek(f,$14e8);
blockread(f,nindex,sizeof(nindex_type));
seek(f,$156e);
blockread(f,names,sizeof(names_type));
mark(heap);
end;

procedure load_font( var f:file;
                         font_nr:byte;
                     var font:inhoud;
                     var font_table:table_ptr;
                     var font_data:data_ptr;
                     var index:index_ptr);

var font_offset:longint;
begin
    release(heap);
    font_offset:=$123a+index^[font_nr].offset;
    seek(f,font_offset);
    blockread(f,font,sizeof(font));
    seek(f,font_offset+font.table_offset);
    getmem(font_table,font.aantal_chars*2+2);
    blockread(f,font_table^,font.aantal_chars*2+2);
    seek(f,font_offset+font.data_offset);
    getmem(font_data,font.data_lengte);
    blockread(f,font_data^,font.data_lengte);
end;

procedure bezier(    x,y:word;
                 var dx,dy:integer;
                     x1,y1,x2,y2,x3,y3:integer);
var n,i:byte;
    c:real;
    dxx,dyy:integer;
begin
for n:=0 to num do
    begin
    dxx:=dx+round(x1*bezcoef[n,1]+x2*bezcoef[n,2]+x3*bezcoef[n,3]);
    dyy:=dy+round(y1*bezcoef[n,1]+y2*bezcoef[n,2]+y3*bezcoef[n,3]);
    lineto(x+(dxx*multx)div divx,y-(dyy*multy)div divy)
    end;
dx:=dxx;
dy:=dyy
end;


procedure display( font:inhoud;
                   font_table:table_ptr;
                   font_data:data_ptr;
               var x,y:word;
                   ch:byte);
var lengte:word;
    m,n,p:word;
    dx,dy:integer;
    hulp:^line;
    breedte:^word;

begin
n:=font_table^[ch];
lengte:=0;
repeat
      lengte:=lengte+font_data^[n];
      n:=n+1;
until font_data^[n-1]<255;
breedte:=addr(font_data^[n]);
if x+(breedte^*multx) div divx>getmaxx
   then begin
        x:=0;
        y:=y+(1000*multy) div divy
        end;
m:=n+2;
while m<n+lengte do
      begin
      case font_data^[m] of
       $78,$77: begin
                hulp:=addr(font_data^[m]);
                dx:=hulp^._77.x;
                dy:=hulp^._77.y;
                m:=m+5;
                moveto(x+(dx*multx) div divx ,y-(dy*multy)div divy)
                end;
           $7:  begin
                hulp:=addr(font_data^[m]);
                for p:=1 to font_data^[m+1] do
                    begin
                    dx:=dx+hulp^._7.data[p].x;
                    dy:=dy+hulp^._7.data[p].y;
                    lineto(x+(dx*multx) div divx ,y-(dy*multy)div divy)
                    end;
                m:=m+2+font_data^[m+1]*4
                end;
           $6:  begin
                hulp:=addr(font_data^[m]);
                for p:=1 to font_data^[m+1] do
                    begin
                    dx:=dx+hulp^._6.data[p].x;
                    dy:=dy+hulp^._6.data[p].y;
                    lineto(x+(dx*multx) div divx ,y-(dy*multy)div divy)
                    end;
                m:=m+2+font_data^[m+1]*2
                end;
           $a:  begin
                hulp:=addr(font_data^[m]);
                with hulp^._a do
                     bezier(x,y,dx,dy,x1,y1,x2,y2,x3,y3);
                m:=m+7;
                end;
           $b:  begin
                hulp:=addr(font_data^[m]);
                with hulp^._b do
                     bezier(x,y,dx,dy,x1,y1,x2,y2,x3,y3);
                m:=m+13;
                end;
           else begin
                writeln('error:',font_data^[m]);
                end;
           end{case}
      end;{while}
x:=x+(breedte^*multx)div divx;
end;

var f:file;
    font:inhoud;
    font_table:table_ptr;
    font_data:data_ptr;
    index:index_ptr;
    nindex:nindex_type;
    names:names_type;
    font_nr:integer;
    font_offset:longint;
    ch:byte;
    x,y:word;
    c:char;
    name:^string;
    f1,f2,count:integer;
begin
init_bezier;
init_graph;
directvideo:=false;
init_fonts(f,index,font_table,font_data,nindex,names);
count:=1;
if (paramcount=1) then
   val(paramstr(1),f1,count);
if count=0 then
   f2:=f1 else
   begin
   f1:=16;f2:=66;
   end;
for font_nr:=f1 to f2 do
    begin
    clearviewport;
    x:=getmaxx;
    y:=0;
    name:=addr(names[nindex[font_nr]]);
    gotoxy(1,1);writeln('font nr:',font_nr,' :',name^);
    load_font(f,font_nr,font,font_table,font_data,index);
    if (font.typ=8) then
       begin
       for ch:=33 to font.aantal_chars-1 do
           display(font,font_table,font_data,x,y,ch);
       end else
    if (font.typ=4) then
       begin
       writeln('font is bitmap...')
       end else
    writeln('unknown fonttype');
    c:=readkey;
    end;
close(f);
closegraph;
end.
