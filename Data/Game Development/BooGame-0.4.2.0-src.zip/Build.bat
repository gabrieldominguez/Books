@REM Builds BooGame using NAnt and then moves the build into
@REM the bin folder

@ECHO OFF

@REM Create NAnt Project Files
tools\Prebuild\Prebuild.exe /target nant /file Prebuild.xml

@REM Build using NAnt
tools\NAnt\NAnt.exe -t:net-1.1 -buildfile:BooGame.build clean
tools\NAnt\NAnt.exe -t:net-1.1 -buildfile:BooGame.build build-release

@REM Assembly Dependancies
xcopy lib\net-1.1\*.dll bin\assemblies\*.* /Q /Y
xcopy src\bin\Release\*.dll bin\assemblies\*.* /Q /Y

@REM Win32 Dependancies
xcopy lib\win32deps\*.* bin\win32deps\*.* /Q /Y

@REM Examples
xcopy src\bin\Release\*.dll bin\examples\*.* /Q /Y
xcopy lib\win32deps\*.* bin\examples\*.* /Q /Y
xcopy lib\net-1.1\*.dll bin\examples\*.* /Q /Y
xcopy examples\BooPlayer\bin\Release\BooPlayer.exe bin\examples\*.* /Q /Y
xcopy examples\BooPlayer\Data\*.* bin\examples\*.* /Q /Y
xcopy examples\BouncingSprites\bin\Release\*.exe bin\examples\*.* /Q /Y
xcopy examples\BouncingSprites\Data\*.* bin\examples\*.* /Q /Y
xcopy examples\ScrollDemo\bin\Release\ScrollDemo.exe bin\examples\*.* /Q /Y
xcopy examples\ScrollDemo\Data\*.* bin\examples\*.* /Q /Y
xcopy examples\Sint\bin\Release\Sint.exe bin\examples\*.* /Q /Y
xcopy examples\Sint\Data\*.* bin\examples\*.* /Q /Y
xcopy examples\GuiExample\bin\Release\GuiExample.exe bin\examples\*.* /Q /Y

@REM Clean NAnt Project Files
tools\Prebuild\Prebuild.exe /file Prebuild.xml /clean nant /removedir obj /yes