
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _OSSWG_
#define _OSSWG_

#include <windows.h>

extern BOOL OssWGInitialize(HWND, DWORD, DWORD);
extern VOID OssWGShutdown(VOID);
extern VOID OssWGCopy3DfxFrameBuffer(VOID);

#endif //_OSSWG_
