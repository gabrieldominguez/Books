/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    /// <summary>
    /// A PictureBox control for displaying an image on the screen as a GUI widget.
    /// </summary>
    public class PictureBox : Container
    {
        public PictureBox(Texture picture)
        {
            Texture = picture;
        }

        public PictureBox(Tile tile)
        {
            m_Tile = tile;
        }
        public PictureBox(Texture picture, ColorF border, ColorF background) : base(border, background)
        {
            Texture = picture;
        }

        public PictureBox(Tile tile, ColorF border, ColorF background) : base(border, background)
        {
            m_Tile = tile;
        }
        public PictureBox(Texture picture, ColorF border)
            : base(border)
        {
            Texture = picture;
        }

        public PictureBox(Tile tile, ColorF border)
            : base(border)
        {
            m_Tile = tile;
        }

        private Tile m_Tile;
        /// <summary>
        /// Gets and sets the tile to be displayed.
        /// </summary>
        public Tile Tile
        {
            get { return m_Tile; }
            set { m_Tile = value; }
        }

        /// <summary>
        /// Gets and sets the texture associated with the picture.
        /// </summary>
        public Texture Texture
        {
            get
            {
                return m_Tile.TileSet.Texture;
            }
            set
            {
                m_Tile = new Tile(value);
            }
        }

        public override void Draw()
        {
            if (Visible)
            {
                m_Tile.Draw(this.AbsoluteX, this.AbsoluteY, this.Width, this.Height, this.HotSpot.X, this.HotSpot.Y, this.Rotation, this.ScaleX, this.ScaleY, this.Tint);
                base.Draw();
            }
        }
    }
}
