// =============================================================================
//    PRIMER EJEMPLO DE USO DE OPENGL
//    Computaci�n II
//
//    2001/09/12
//    Daniel Beber
// =============================================================================

void Lineas() //================================================================
{
  glPushMatrix();
  // El par glPushMatrix() y glPopMatrix() es necesario si hay transformaciones.
  // Es �til cuando a trav�s de transformaciones se parte de un lugar
  // (se pone la matriz actual en el stack), se realizan transformaciones hasta
  // otro lugar (se agregan matrices de transformaci�n al stack), pero al final
  // se quiere volver al punto de partida, esto se hace con glPopMatrix().
  // En esta funcion, que no hay transformaciones, no es necesario.

  GLfloat pt[] = {-0.8, 0.8}; // otra forma de ingresar las coordenadas.

  // glBegin() define el objeto a ser dibujado con las coordenadas y colores
  // definidos hasta el glEnd().

  glBegin(GL_LINE_STRIP);    // GL_LINES - GL_LINE_STRIP - GL_LINE_LOOP
   glVertex2f (  0.2f,  0.2f );
   glVertex2f (  0.4f, -0.4f );
   glVertex2f ( -0.6f, -0.6f );
   glVertex2fv ( pt );       // v:pointer to a vector
  glEnd();

  glPopMatrix();
}

void Puntos() //================================================================
{
  glPushMatrix();

  glPointSize(20);
  // Establece el tama�o del punto (en pixeles). Por defecto es un pixel.
  // Se ha puesto glEnable(GL_POINT_SMOOTH);
  // para habilitar el antialiasing en los puntos, es disable por defecto.

  GLfloat MiColor[] = { 0.0 , 0.0 , 1.0};
  GLfloat pt[] = {-0.8, 0.8}; // otra forma de ingresar las coordenadas.

  // se muestra distintas formas de ingresar los colores.

  glBegin( GL_POINTS );
   glColor3f ( 1.0f, 0.0f, 0.0f ); glVertex2f (  0.2f,  0.2f ); // red
   glColor3ub( 0, 255, 0 )       ; glVertex2f (  0.4f, -0.4f ); // green
   glColor3fv( MiColor )         ; glVertex2f ( -0.6f, -0.6f ); // blue
   glColor3ub( 0, 255, 255 )     ; glVertex2fv ( pt );
  glEnd();

  glPopMatrix();
}

void Figuras3D() //========================================================
{
  glPushMatrix();

  // observar que primero se realiza las transformaciones luego el dibujo.
  glColor3ub( 155, 155, 155 );
  glTranslatef (0.0, 0.0, 0.0);
  glRotatef(70,1,0,0);  // Rota el modelo respecto al eje "x".
                        // El eje "z" sale de la pantalla.

  // Figuras tridimensionales predefinidas.
  // glutWireSphere(0.8,50,50);
  glutWireTorus(0.2,0.8,50,50);  // c�rculo perpendicular al eje "z".
  // glutWireTeapot(0.5);

  glPopMatrix();
}



//   Suffix  -  Data Type - Typical Corresponding C - OpenGL Type Definition
//   ------------------------------------------------------------------------
//     b      8-bit integer       signed char                 GLbyte
//    ub      8-bit unsigned      unsigned char               GLubyte
//                  integer
//     i     32-bit integer          long                     GLint
//     f     32-bit floating         float                    GLFloat
//                  point

