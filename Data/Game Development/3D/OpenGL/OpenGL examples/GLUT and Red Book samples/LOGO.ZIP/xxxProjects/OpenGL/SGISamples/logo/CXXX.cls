VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CLogo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'FUNCTION: Main class of the app.
'
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
Dim m_MatF As glxMaterial
Dim m_MatB As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
'Dim black!(0 To 2) '3) = {0.0, 0.0, 0.0};
'Dim white!(0 To 2) ') = {1.0, 1.0, 1.0};
'Dim gray!(0 To 2) ' = {0.5, 0.5, 0.5};
'Dim blue!(0 To 2) ' = {0.0, 0.0, 1.0};
'Dim colorIndexes&(0 To 2) ' = {0, 200, 255};

Dim polyMode&
Dim m_bDithering As Boolean
Dim m_bShade&
Dim m_bDoStipple&


Dim SingleCylinderID&
Dim DoubleCylinderID&
Dim ElbowID&, LogoID&
'Dim imageHeight&
'Dim imageWidth&

Dim CheckImage(0 To 3 * CHECKIMAGEWIDTH * CHECKIMAGEHEIGHT - 1) As Byte
'GLubyte *image = checkImage;
Dim BrickImage(0 To 4 * BRICKIMAGEWIDTH * BRICKIMAGEHEIGHT - 1) As Byte
Dim stipple(0 To 4 * 32 - 1) As Byte
'
Dim tscp(0 To 17) As POINT2F ' * 2 - 1) '(18)(2) = {
Dim scp(0 To 17) As POINT3F '18)(3) = {
Dim dcp(0 To 17) As POINT3F '18)(3) = {
Dim ep(0 To 6, 0 To 8) As POINT3F 'float ep(7)(9)(3) = {
Dim en(0 To 6, 0 To 8) As POINT3F 'float ep(7)(9)(3) = {
Dim tep(0 To 6, 0 To 8) As POINT2F 'float tep(7)(9)(2) = {


Private Sub Class_Initialize()
clrRed(0) = &HA4
clrRed(3) = &HFF
clrWhite(0) = &HFF
clrWhite(1) = &HFF
clrWhite(2) = &HFF
clrWhite(3) = &HFF
'white(0) = 1
'white(1) = 1
'white(2) = 1
'gray(0) = 0.5
'gray(1) = 0.5
'gray(2) = 0.5
'blue(2) = 1
'colorIndexes(1) = 200
'colorIndexes(2) = 255
plane(0) = 1 '{1.0, 0.0, -1.0, 0.0};
plane(2) = -1
xRotation = 30
yRotation = 30
zTranslation = -15
'imageHeight& = CHECKIMAGEHEIGHT
'imageWidth& = CHECKIMAGEWIDTH
FillArrayb CheckImage, _
    BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, _
    WH, WH, BL, BL, BL, WH, WH, WH, WH, WH, WH, BL, BL, BL, WH, WH, _
    WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, _
    BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, _
    WH, WH, BL, BL, BL, WH, WH, WH, WH, WH, WH, BL, BL, BL, WH, WH, _
    WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, _
    BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, _
    WH, WH, BL, BL, BL, WH, WH, WH, WH, WH, WH, BL, BL, BL, WH, WH, _
    WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, _
    BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, _
    WH, WH, BL, BL, BL, WH, WH, WH, WH, WH, WH, BL, BL, BL, WH, WH, _
    WH, BL, BL, BL, WH, WH, WH, BL, BL, BL, WH, WH, WH, BL, BL, BL
FillColorArrayb BrickImage, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD
FillArrayb stipple, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &HF, &HF0, &H0, &H0, &HF, &HF0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0, _
    &H0, &H0, &H0, &H0, &H0, &H0, &H0, &H0
FillTSCPArray tscp, _
    0, 0, 1, 0, 0, 0.125, 1, 0.125, 0, 0.25, 1, 0.25, 0, 0.375, 1, 0.375, 0, 0.5, _
    1, 0.5, 0, 0.625, 1, 0.625, 0, 0.75, 1, 0.75, 0, 0.875, 1, 0.875, 0, 1, 1, 1
FillCPArray scp, _
    1, 0, 0, 1, 0, 5, 0.707107, 0.707107, 0, 0.707107, 0.707107, 5, _
    0, 1, 0, 0, 1, 5, -0.707107, 0.707107, 0, _
    -0.707107, 0.707107, 5, -1, 0, 0, -1, 0, 5, _
    -0.707107, -0.707107, 0, -0.707107, -0.707107, 5, 0, -1, 0, _
    0, -1, 5, 0.707107, -0.707107, 0, 0.707107, -0.707107, 5, 1, 0, 0, 1, 0, 5
FillCPArray dcp, _
    1, 0, 0, 1, 0, 7, 0.707107, 0.707107, 0, 0.707107, 0.707107, 7, 0, 1, 0, _
    0, 1, 7, -0.707107, 0.707107, 0, -0.707107, 0.707107, 7, -1, 0, 0, -1, 0, 7, _
    -0.707107, -0.707107, 0, -0.707107, -0.707107, 7, 0, -1, 0, 0, -1, 7, 0.707107, -0.707107, 0, _
    0.707107, -0.707107, 7, 1, 0, 0, 1, 0, 7
FillArray3f ep, _
    1, 0, 0, 0.707107, 0.707107, 0, 0, 1, 0, -0.707107, 0.707107, 0, -1, 0, 0, -0.707107, -0.707107, 0, 0, -1, 0, 0.707107, -0.707107, 0, 1, 0, 0, _
    1, 0.034074, 0.258819, 0.707107, 0.717087, 0.075806, 0, 1, 0, _
    -0.707107, 0.717087, 0.075806, -1, 0.034074, 0.258819, -0.707107, -0.648939, 0.441832, _
    0, -0.931852, 0.517638, 0.707107, -0.648939, 0.441832, 1, 0.034074, 0.258819, 1, 0.133975, 0.5, 0.707107, 0.746347, 0.146447, 0, 1, 0, -0.707107, 0.746347, 0.146447, -1, 0.133975, 0.5, -0.707107, -0.478398, 0.853553, 0, -0.732051, 1, 0.707107, -0.478398, 0.853553, 1, 0.133975, 0.5, _
    1, 0.292893, 0.707107, 0.707107, 0.792893, 0.207107, 0, 1, 0, -0.707107, 0.792893, 0.207107, -1, 0.292893, 0.707107, -0.707107, -0.207107, 1.207107, 0, -0.414214, 1.414214, 0.707107, -0.207107, 1.207107, 1, 0.292893, 0.707107, _
    1, 0.5, 0.866025, 0.707107, 0.853553, 0.253653, 0, 1, 0, -0.707107, 0.853553, 0.253653, -1, 0.5, 0.866025, -0.707107, 0.146447, 1.478398, 0, 0, 1.732051, 0.707107, 0.146447, 1.478398, 1, 0.5, 0.866025, _
    1, 0.741181, 0.965926, 0.707107, 0.924194, 0.282913, 0, 1, 0, -0.707107, 0.924194, 0.282913, -1, 0.741181, 0.965926, -0.707107, 0.558168, 1.648939, 0, 0.482362, 1.931852, 0.707107, 0.558168, 1.648939, 1, 0.741181, 0.965926, 1, 1, 1, _
    0.707107, 1, 0.292893, 0, 1, 0, -0.707107, 1, 0.292893, -1, 1, 1, -0.707107, 1, 1.707107, 0, 1, 2, 0.707107, 1, 1.707107, 1, 1, 1
'note" 8th line was missing next to last point
FillArray3f en, _
    1, 0, 0, 0.707107, 0.707107, 0, 0, 1, 0, -0.707107, 0.707107, 0, -1, 0, 0, _
    -0.707107, -0.707107, 0, 0, -1, 0, 0.707107, -0.707107, 0, 1, 0, 0, _
    1, 0, 0, 0.707107, 0.683013, -0.183013, 0, 0.965926, -0.258819, -0.707107, 0.683013, -0.183013, -1, 0, 0, _
    -0.707107, -0.683013, 0.183013, 0, -0.965926, 0.258819, 0.707107, -0.683013, 0.183013, 1, 0, 0, _
    1, 0, 0, 0.707107, 0.612372, -0.353553, 0, 0.866025, -0.5, -0.707107, 0.612372, -0.353553, -1, 0, 0, _
    -0.707107, -0.612372, 0.353553, 0, -0.866025, 0.5, 0.707107, -0.612372, 0.353553, 1, 0, 0, _
    1, 0, 0, 0, 0.707107, -0.707107, -0.707107, 0.5, -0.5, -1, 0, 0, -0.707107, -0.5, 0.5, _
    0, -0.707107, 0.707107, 0.707107, -0.5, 0.5, 0.707107, -0.5, 0.5, 1, 0, 0, _
    1, 0, 0, 0.707107, 0.353553, -0.612372, 0, 0.5, -0.866025, -0.707107, 0.353553, -0.612372, -1, 0, 0, _
    -0.707107, -0.353553, 0.612372, 0, -0.5, 0.866025, 0.707107, -0.353553, 0.612372, 1, 0, 0, _
    1, 0, 0, 0.707107, 0.183013, -0.683013, 0, 0.258819, -0.965926, -0.707107, 0.183013, -0.683013, -1, 0, 0, _
    -0.707107, -0.183013, 0.683013, 0, -0.258819, 0.965926, 0.707107, -0.183013, 0.683013, 1, 0, 0, _
    1, 0, 0, 0.707107, 0, -0.707107, 0, 0, -1, -0.707107, 0, -0.707107, -1, 0, 0, _
    -0.707107, 0, 0.707107, 0, 0, 1, 0.707107, 0, 0.707107, 1, 0, 0
FillArray2f tep, _
    0, 0, 0.125, 0, 0.25, 0, 0.375, 0, 0.5, 0, 0.625, 0, 0.75, 0, 0.875, 0, 1, 0, _
    0, 0.16667, 0.125, 0.16667, 0.25, 0.16667, 0.375, 0.16667, 0.5, 0.16667, 0.625, 0.16667, 0.75, 0.16667, 0.875, 0.16667, 1, 0.16667, _
    0, 0.33333, 0.125, 0.33333, 0.25, 0.33333, 0.375, 0.33333, 0.5, 0.33333, 0.625, 0.33333, 0.75, 0.33333, 0.875, 0.33333, 1, 0.33333, _
    0, 0.5, 0.125, 0.5, 0.25, 0.5, 0.375, 0.5, 0.5, 0.5, 0.625, 0.5, 0.75, 0.5, 0.875, 0.5, 1, 0.5, _
    0, 0.6667, 0.125, 0.6667, 0.25, 0.6667, 0.375, 0.6667, 0.5, 0.6667, 0.625, 0.6667, 0.75, 0.6667, 0.875, 0.6667, 1, 0.6667, _
    0, 0.83333, 0.125, 0.83333, 0.25, 0.83333, 0.375, 0.83333, 0.5, 0.83333, 0.625, 0.83333, 0.75, 0.83333, 0.875, 0.83333, 1, 0.83333, _
    0, 1, 0.125, 1, 0.25, 1, 0.375, 1, 0.5, 1, 0.625, 1, 0.75, 1, 0.875, 1, 1, 1
End Sub

Public Sub InitGL()
    glFrontFace GL_CW
    glEnable GL_DEPTH_TEST
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
        .TwoSide = True
    End With
    'gluPerspective 90, 1, 1, 200
    With gCtl.Camera
        .FarPlane = 300
        .NearPlane = 0.01
        .FieldOfView = 90
        .SetEyePos 2, 1, 2
        .SetTargetPos 1.5, 1, 0
    End With
    '
    Set m_MatF = gCtl.NewMaterial
    With m_MatF
        .face = faceFront
        .SetDiffuse 0.5, 0.28, 0.38
        .SetSpecular 0.2, 0.2, 0.2
        .SpecExp = 30
    End With
    m_MatF.SetMaterial
    Set m_MatB = gCtl.NewMaterial
    With m_MatB
        .face = faceBack
        .SetDiffuse 1, 1, 0.2
        .SetSpecular 0.5, 0.5, 0.2
        .SpecExp = 50
    End With
    m_MatB.SetMaterial
    glEnable GL_CLIP_PLANE0

    glTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL
    glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
    glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
    glTexImage2D GL_TEXTURE_2D, 0, 3, CHECKIMAGEWIDTH, CHECKIMAGEHEIGHT, 0, _
         GL_RGB, GL_UNSIGNED_BYTE, CheckImage(0)
    glEnable GL_TEXTURE_2D

    glCullFace GL_BACK
    glEnable GL_CULL_FACE

    BuildLists

    m_bDithering = True
    m_bShade = True
    m_bDoStipple = False
    polyMode = GL_BACK

End Sub

Public Sub Draw()
    glPushMatrix

    glTranslatef 0, 0, zTranslation
    glRotatef 30, 1, 0, 0
    glRotatef yRotation, 0, 1, 0
    glClipPlane GL_CLIP_PLANE0, plane(0)
    glCallList LogoID
    glPopMatrix
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, shift%)
    Select Case (KeyCode)
    ' start of view position functions */
    Case vbKeyLeft: yRotation = yRotation + 0.5
    Case vbKeyRight: yRotation = yRotation - 0.5
    Case vbKeyUp: plane(3) = plane(3) + 2
    Case vbKeyDown: plane(3) = plane(3) - 2
    Case vbKeyPageUp:
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii%)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "z":    zTranslation = zTranslation - 1
    Case "Z":    zTranslation = zTranslation + 1
    Case "1":    glPolygonMode polyMode, GL_POINT
    Case "2":    glPolygonMode polyMode, GL_LINE
    Case "3":    glPolygonMode polyMode, GL_FILL
    Case "4":
    Select Case polyMode
        Case GL_BACK:          polyMode = GL_FRONT
        Case GL_FRONT:          polyMode = GL_FRONT_AND_BACK
        Case GL_FRONT_AND_BACK:          polyMode = GL_BACK
    End Select
    Case "5":    glHint GL_POLYGON_SMOOTH_HINT, GL_NICEST
    Case "6":
        glEnable GL_POLYGON_SMOOTH
        glBlendFunc GL_SRC_ALPHA, GL_ONE
        glEnable GL_BLEND
        glDisable GL_DEPTH_TEST
    Case "7":
        glDisable GL_POLYGON_SMOOTH
        glBlendFunc GL_ONE, GL_ZERO
        glDisable GL_BLEND
        glEnable GL_DEPTH_TEST
    Case "8":
        m_bDithering = Not m_bDithering
        If m_bDithering Then
            glEnable GL_DITHER
        Else: glDisable GL_DITHER
        End If
    Case "9":
        m_bDoStipple = Not m_bDoStipple
        If m_bDoStipple Then
            glPolygonStipple stipple(0)
            glEnable GL_POLYGON_STIPPLE
        Else
            glDisable GL_POLYGON_STIPPLE
        End If
    Case "0":
        m_bShade = Not m_bShade
        If m_bShade Then
            glShadeModel GL_SMOOTH
        Else: glShadeModel GL_FLAT
        End If
        Case "q":    glDisable GL_CULL_FACE
        Case "w":
            glEnable GL_CULL_FACE
            glCullFace GL_FRONT
    Case "e":
        glEnable GL_CULL_FACE
        glCullFace GL_BACK
    Case "r":    glFrontFace GL_CW
    Case "t":    glFrontFace GL_CCW
    Case "y":
        glPixelStorei GL_UNPACK_ALIGNMENT, 1
        glPixelStorei GL_UNPACK_LSB_FIRST, 0
        glPolygonStipple stipple(0)
    Case "u":
        glPixelStorei GL_UNPACK_ALIGNMENT, 1
        glPixelStorei GL_UNPACK_LSB_FIRST, 1
        glPolygonStipple stipple(0)
    Case "a":
    glEnable GL_TEXTURE_2D
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
        glTexImage2D GL_TEXTURE_2D, 0, 4, BRICKIMAGEWIDTH, _
             BRICKIMAGEHEIGHT, 0, GL_RGBA, GL_UNSIGNED_BYTE, BrickImage(0)
    Case "s":
        glEnable GL_TEXTURE_2D
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
        glTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
        glTexImage2D GL_TEXTURE_2D, 0, 3, CHECKIMAGEWIDTH, _
             CHECKIMAGEHEIGHT, 0, GL_RGB, GL_UNSIGNED_BYTE, CheckImage(0)
    Case "d":
        glDisable GL_TEXTURE_2D
    Case "f":
        glTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL
    Case "g":
        glTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    End Select
End Sub


Public Sub BendForward()
    glTranslatef 0, 1, 0
    glRotatef 90, 1, 0, 0
    glTranslatef 0, -1, 0

End Sub

Public Sub BendLeft()
    glRotatef -90, 0, 0, 1
    glTranslatef 0, 1, 0
    glRotatef 90, 1, 0, 0
    glTranslatef 0, -1, 0
End Sub

Public Sub BendRight()
    glRotatef 90, 0, 0, 1
    glTranslatef 0, 1, 0
    glRotatef 90, 1, 0, 0
    glTranslatef 0, -1, 0
End Sub

Public Sub BuildSingleCylinder()
    glNewList SingleCylinderID, GL_COMPILE

    glBegin GL_TRIANGLE_STRIP
       glNormal3fv scp(0).p(0): glTexCoord2fv tscp(0).p(0): glVertex3fv scp(0).p(0)
       glNormal3fv scp(0).p(0): glTexCoord2fv tscp(1).p(0): glVertex3fv scp(1).p(0)
       glNormal3fv scp(2).p(0): glTexCoord2fv tscp(2).p(0): glVertex3fv scp(2).p(0)
       glNormal3fv scp(2).p(0): glTexCoord2fv tscp(3).p(0): glVertex3fv scp(3).p(0)
       glNormal3fv scp(4).p(0): glTexCoord2fv tscp(4).p(0): glVertex3fv scp(4).p(0)
       glNormal3fv scp(4).p(0): glTexCoord2fv tscp(5).p(0): glVertex3fv scp(5).p(0)
       glNormal3fv scp(6).p(0): glTexCoord2fv tscp(6).p(0): glVertex3fv scp(6).p(0)
       glNormal3fv scp(6).p(0): glTexCoord2fv tscp(7).p(0): glVertex3fv scp(7).p(0)
       glNormal3fv scp(8).p(0): glTexCoord2fv tscp(8).p(0): glVertex3fv scp(8).p(0)
       glNormal3fv scp(8).p(0): glTexCoord2fv tscp(9).p(0): glVertex3fv scp(9).p(0)
       glNormal3fv scp(10).p(0): glTexCoord2fv tscp(10).p(0): glVertex3fv scp(10).p(0)
       glNormal3fv scp(10).p(0): glTexCoord2fv tscp(11).p(0): glVertex3fv scp(11).p(0)
       glNormal3fv scp(12).p(0): glTexCoord2fv tscp(12).p(0): glVertex3fv scp(12).p(0)
       glNormal3fv scp(12).p(0): glTexCoord2fv tscp(13).p(0): glVertex3fv scp(13).p(0)
       glNormal3fv scp(14).p(0): glTexCoord2fv tscp(14).p(0): glVertex3fv scp(14).p(0)
       glNormal3fv scp(14).p(0): glTexCoord2fv tscp(15).p(0): glVertex3fv scp(15).p(0)
       glNormal3fv scp(16).p(0): glTexCoord2fv tscp(16).p(0): glVertex3fv scp(16).p(0)
       glNormal3fv scp(16).p(0): glTexCoord2fv tscp(17).p(0): glVertex3fv scp(17).p(0)
    glEnd

    glEndList
End Sub

Public Sub BuildDoubleCylinder()
    glNewList DoubleCylinderID, GL_COMPILE

    glBegin GL_TRIANGLE_STRIP
    glNormal3fv dcp(0).p(0): glTexCoord2fv tscp(0).p(0): glVertex3fv dcp(0).p(0)
    glNormal3fv dcp(0).p(0): glTexCoord2fv tscp(1).p(0): glVertex3fv dcp(1).p(0)
    glNormal3fv dcp(2).p(0): glTexCoord2fv tscp(2).p(0): glVertex3fv dcp(2).p(0)
    glNormal3fv dcp(2).p(0): glTexCoord2fv tscp(3).p(0): glVertex3fv dcp(3).p(0)
    glNormal3fv dcp(4).p(0): glTexCoord2fv tscp(4).p(0): glVertex3fv dcp(4).p(0)
    glNormal3fv dcp(4).p(0): glTexCoord2fv tscp(5).p(0): glVertex3fv dcp(5).p(0)
    glNormal3fv dcp(6).p(0): glTexCoord2fv tscp(6).p(0): glVertex3fv dcp(6).p(0)
    glNormal3fv dcp(6).p(0): glTexCoord2fv tscp(7).p(0): glVertex3fv dcp(7).p(0)
    glNormal3fv dcp(8).p(0): glTexCoord2fv tscp(8).p(0): glVertex3fv dcp(8).p(0)
    glNormal3fv dcp(8).p(0): glTexCoord2fv tscp(9).p(0): glVertex3fv dcp(9).p(0)
    glNormal3fv dcp(10).p(0): glTexCoord2fv tscp(10).p(0): glVertex3fv dcp(10).p(0)
    glNormal3fv dcp(10).p(0): glTexCoord2fv tscp(11).p(0): glVertex3fv dcp(11).p(0)
    glNormal3fv dcp(12).p(0): glTexCoord2fv tscp(12).p(0): glVertex3fv dcp(12).p(0)
    glNormal3fv dcp(12).p(0): glTexCoord2fv tscp(13).p(0): glVertex3fv dcp(13).p(0)
    glNormal3fv dcp(14).p(0): glTexCoord2fv tscp(14).p(0): glVertex3fv dcp(14).p(0)
    glNormal3fv dcp(14).p(0): glTexCoord2fv tscp(15).p(0): glVertex3fv dcp(15).p(0)
    glNormal3fv dcp(16).p(0): glTexCoord2fv tscp(16).p(0): glVertex3fv dcp(16).p(0)
    glNormal3fv dcp(16).p(0): glTexCoord2fv tscp(17).p(0): glVertex3fv dcp(17).p(0)
    glEnd

    glEndList
End Sub


Public Sub BuildElbow()

   glNewList ElbowID, GL_COMPILE

    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(0, 0).p(0)
    glTexCoord2fv tep(0, 0).p(0)
    glVertex3fv ep(0, 0).p(0)
    '
    glNormal3fv en(1, 0).p(0): glTexCoord2fv tep(1, 0).p(0): glVertex3fv ep(1, 0).p(0)
    glNormal3fv en(0, 1).p(0): glTexCoord2fv tep(0, 1).p(0): glVertex3fv ep(0, 1).p(0)
    glNormal3fv en(1, 1).p(0): glTexCoord2fv tep(1, 1).p(0): glVertex3fv ep(1, 1).p(0)
    glNormal3fv en(0, 2).p(0): glTexCoord2fv tep(0, 2).p(0): glVertex3fv ep(0, 2).p(0)
    glNormal3fv en(1, 2).p(0): glTexCoord2fv tep(1, 2).p(0): glVertex3fv ep(1, 2).p(0)
    glNormal3fv en(0, 3).p(0): glTexCoord2fv tep(0, 3).p(0): glVertex3fv ep(0, 3).p(0)
    glNormal3fv en(1, 3).p(0): glTexCoord2fv tep(1, 3).p(0): glVertex3fv ep(1, 3).p(0)
    glNormal3fv en(0, 4).p(0): glTexCoord2fv tep(0, 4).p(0): glVertex3fv ep(0, 4).p(0)
    glNormal3fv en(1, 4).p(0): glTexCoord2fv tep(1, 4).p(0): glVertex3fv ep(1, 4).p(0)
    glNormal3fv en(0, 5).p(0): glTexCoord2fv tep(0, 5).p(0): glVertex3fv ep(0, 5).p(0)
    glNormal3fv en(1, 5).p(0): glTexCoord2fv tep(1, 5).p(0): glVertex3fv ep(1, 5).p(0)
    glNormal3fv en(0, 6).p(0): glTexCoord2fv tep(0, 6).p(0): glVertex3fv ep(0, 6).p(0)
    glNormal3fv en(1, 6).p(0): glTexCoord2fv tep(1, 6).p(0): glVertex3fv ep(1, 6).p(0)
    glNormal3fv en(0, 7).p(0): glTexCoord2fv tep(0, 7).p(0): glVertex3fv ep(0, 7).p(0)
    glNormal3fv en(1, 7).p(0): glTexCoord2fv tep(1, 7).p(0): glVertex3fv ep(1, 7).p(0)
    glNormal3fv en(0, 8).p(0): glTexCoord2fv tep(0, 8).p(0): glVertex3fv ep(0, 8).p(0)
    glNormal3fv en(1, 8).p(0): glTexCoord2fv tep(1, 8).p(0): glVertex3fv ep(1, 8).p(0)
    glEnd
    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(1, 0).p(0): glTexCoord2fv tep(1, 0).p(0): glVertex3fv ep(1, 0).p(0)
    glNormal3fv en(2, 0).p(0): glTexCoord2fv tep(2, 0).p(0): glVertex3fv ep(2, 0).p(0)
    glNormal3fv en(1, 1).p(0): glTexCoord2fv tep(1, 1).p(0): glVertex3fv ep(1, 1).p(0)
    glNormal3fv en(2, 1).p(0): glTexCoord2fv tep(2, 1).p(0): glVertex3fv ep(2, 1).p(0)
    glNormal3fv en(1, 2).p(0): glTexCoord2fv tep(1, 2).p(0): glVertex3fv ep(1, 2).p(0)
    glNormal3fv en(2, 2).p(0): glTexCoord2fv tep(2, 2).p(0): glVertex3fv ep(2, 2).p(0)
    glNormal3fv en(1, 3).p(0): glTexCoord2fv tep(1, 3).p(0): glVertex3fv ep(1, 3).p(0)
    glNormal3fv en(2, 3).p(0): glTexCoord2fv tep(2, 3).p(0): glVertex3fv ep(2, 3).p(0)
    glNormal3fv en(1, 4).p(0): glTexCoord2fv tep(1, 4).p(0): glVertex3fv ep(1, 4).p(0)
    glNormal3fv en(2, 4).p(0): glTexCoord2fv tep(2, 4).p(0): glVertex3fv ep(2, 4).p(0)
    glNormal3fv en(1, 5).p(0): glTexCoord2fv tep(1, 5).p(0): glVertex3fv ep(1, 5).p(0)
    glNormal3fv en(2, 5).p(0): glTexCoord2fv tep(2, 5).p(0): glVertex3fv ep(2, 5).p(0)
    glNormal3fv en(1, 6).p(0): glTexCoord2fv tep(1, 6).p(0): glVertex3fv ep(1, 6).p(0)
    glNormal3fv en(2, 6).p(0): glTexCoord2fv tep(2, 6).p(0): glVertex3fv ep(2, 6).p(0)
    glNormal3fv en(1, 7).p(0): glTexCoord2fv tep(1, 7).p(0): glVertex3fv ep(1, 7).p(0)
    glNormal3fv en(2, 7).p(0): glTexCoord2fv tep(2, 7).p(0): glVertex3fv ep(2, 7).p(0)
    glNormal3fv en(1, 8).p(0): glTexCoord2fv tep(1, 8).p(0): glVertex3fv ep(1, 8).p(0)
    glNormal3fv en(2, 8).p(0): glTexCoord2fv tep(2, 8).p(0): glVertex3fv ep(2, 8).p(0)
    glEnd
    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(2, 0).p(0): glTexCoord2fv tep(2, 0).p(0): glVertex3fv ep(2, 0).p(0)
    glNormal3fv en(3, 0).p(0): glTexCoord2fv tep(3, 0).p(0): glVertex3fv ep(3, 0).p(0)
    glNormal3fv en(2, 1).p(0): glTexCoord2fv tep(2, 1).p(0): glVertex3fv ep(2, 1).p(0)
    glNormal3fv en(3, 1).p(0): glTexCoord2fv tep(3, 1).p(0): glVertex3fv ep(3, 1).p(0)
    glNormal3fv en(2, 2).p(0): glTexCoord2fv tep(2, 2).p(0): glVertex3fv ep(2, 2).p(0)
    glNormal3fv en(3, 2).p(0): glTexCoord2fv tep(3, 2).p(0): glVertex3fv ep(3, 2).p(0)
    glNormal3fv en(2, 3).p(0): glTexCoord2fv tep(2, 3).p(0): glVertex3fv ep(2, 3).p(0)
    glNormal3fv en(3, 3).p(0): glTexCoord2fv tep(3, 3).p(0): glVertex3fv ep(3, 3).p(0)
    glNormal3fv en(2, 4).p(0): glTexCoord2fv tep(2, 4).p(0): glVertex3fv ep(2, 4).p(0)
    glNormal3fv en(3, 4).p(0): glTexCoord2fv tep(3, 4).p(0): glVertex3fv ep(3, 4).p(0)
    glNormal3fv en(2, 5).p(0): glTexCoord2fv tep(2, 5).p(0): glVertex3fv ep(2, 5).p(0)
    glNormal3fv en(3, 5).p(0): glTexCoord2fv tep(3, 5).p(0): glVertex3fv ep(3, 5).p(0)
    glNormal3fv en(2, 6).p(0): glTexCoord2fv tep(2, 6).p(0): glVertex3fv ep(2, 6).p(0)
    glNormal3fv en(3, 6).p(0): glTexCoord2fv tep(3, 6).p(0): glVertex3fv ep(3, 6).p(0)
    glNormal3fv en(2, 7).p(0): glTexCoord2fv tep(2, 7).p(0): glVertex3fv ep(2, 7).p(0)
    glNormal3fv en(3, 7).p(0): glTexCoord2fv tep(3, 7).p(0): glVertex3fv ep(3, 7).p(0)
    glNormal3fv en(2, 8).p(0): glTexCoord2fv tep(2, 8).p(0): glVertex3fv ep(2, 8).p(0)
    glNormal3fv en(3, 8).p(0): glTexCoord2fv tep(3, 8).p(0): glVertex3fv ep(3, 8).p(0)
    glEnd
    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(3, 0).p(0): glTexCoord2fv tep(3, 0).p(0): glVertex3fv ep(3, 0).p(0)
    glNormal3fv en(4, 0).p(0): glTexCoord2fv tep(4, 0).p(0): glVertex3fv ep(4, 0).p(0)
    glNormal3fv en(3, 1).p(0): glTexCoord2fv tep(3, 1).p(0): glVertex3fv ep(3, 1).p(0)
    glNormal3fv en(4, 1).p(0): glTexCoord2fv tep(4, 1).p(0): glVertex3fv ep(4, 1).p(0)
    glNormal3fv en(3, 2).p(0): glTexCoord2fv tep(3, 2).p(0): glVertex3fv ep(3, 2).p(0)
    glNormal3fv en(4, 2).p(0): glTexCoord2fv tep(4, 2).p(0): glVertex3fv ep(4, 2).p(0)
    glNormal3fv en(3, 3).p(0): glTexCoord2fv tep(3, 3).p(0): glVertex3fv ep(3, 3).p(0)
    glNormal3fv en(4, 3).p(0): glTexCoord2fv tep(4, 3).p(0): glVertex3fv ep(4, 3).p(0)
    glNormal3fv en(3, 4).p(0): glTexCoord2fv tep(3, 4).p(0): glVertex3fv ep(3, 4).p(0)
    glNormal3fv en(4, 4).p(0): glTexCoord2fv tep(4, 4).p(0): glVertex3fv ep(4, 4).p(0)
    glNormal3fv en(3, 5).p(0): glTexCoord2fv tep(3, 5).p(0): glVertex3fv ep(3, 5).p(0)
    glNormal3fv en(4, 5).p(0): glTexCoord2fv tep(4, 5).p(0): glVertex3fv ep(4, 5).p(0)
    glNormal3fv en(3, 6).p(0): glTexCoord2fv tep(3, 6).p(0): glVertex3fv ep(3, 6).p(0)
    glNormal3fv en(4, 6).p(0): glTexCoord2fv tep(4, 6).p(0): glVertex3fv ep(4, 6).p(0)
    glNormal3fv en(3, 7).p(0): glTexCoord2fv tep(3, 7).p(0): glVertex3fv ep(3, 7).p(0)
    glNormal3fv en(4, 7).p(0): glTexCoord2fv tep(4, 7).p(0): glVertex3fv ep(4, 7).p(0)
    glNormal3fv en(3, 8).p(0): glTexCoord2fv tep(3, 8).p(0): glVertex3fv ep(3, 8).p(0)
    glNormal3fv en(4, 8).p(0): glTexCoord2fv tep(4, 8).p(0): glVertex3fv ep(4, 8).p(0)
    glEnd
    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(4, 0).p(0): glTexCoord2fv tep(4, 0).p(0): glVertex3fv ep(4, 0).p(0)
    glNormal3fv en(5, 0).p(0): glTexCoord2fv tep(5, 0).p(0): glVertex3fv ep(5, 0).p(0)
    glNormal3fv en(4, 1).p(0): glTexCoord2fv tep(4, 1).p(0): glVertex3fv ep(4, 1).p(0)
    glNormal3fv en(5, 1).p(0): glTexCoord2fv tep(5, 1).p(0): glVertex3fv ep(5, 1).p(0)
    glNormal3fv en(4, 2).p(0): glTexCoord2fv tep(4, 2).p(0): glVertex3fv ep(4, 2).p(0)
    glNormal3fv en(5, 2).p(0): glTexCoord2fv tep(5, 2).p(0): glVertex3fv ep(5, 2).p(0)
    glNormal3fv en(4, 3).p(0): glTexCoord2fv tep(4, 3).p(0): glVertex3fv ep(4, 3).p(0)
    glNormal3fv en(5, 3).p(0): glTexCoord2fv tep(5, 3).p(0): glVertex3fv ep(5, 3).p(0)
    glNormal3fv en(4, 4).p(0): glTexCoord2fv tep(4, 4).p(0): glVertex3fv ep(4, 4).p(0)
    glNormal3fv en(5, 4).p(0): glTexCoord2fv tep(5, 4).p(0): glVertex3fv ep(5, 4).p(0)
    glNormal3fv en(4, 5).p(0): glTexCoord2fv tep(4, 5).p(0): glVertex3fv ep(4, 5).p(0)
    glNormal3fv en(5, 5).p(0): glTexCoord2fv tep(5, 5).p(0): glVertex3fv ep(5, 5).p(0)
    glNormal3fv en(4, 6).p(0): glTexCoord2fv tep(4, 6).p(0): glVertex3fv ep(4, 6).p(0)
    glNormal3fv en(5, 6).p(0): glTexCoord2fv tep(5, 6).p(0): glVertex3fv ep(5, 6).p(0)
    glNormal3fv en(4, 7).p(0): glTexCoord2fv tep(4, 7).p(0): glVertex3fv ep(4, 7).p(0)
    glNormal3fv en(5, 7).p(0): glTexCoord2fv tep(5, 7).p(0): glVertex3fv ep(5, 7).p(0)
    glNormal3fv en(4, 8).p(0): glTexCoord2fv tep(4, 8).p(0): glVertex3fv ep(4, 8).p(0)
    glNormal3fv en(5, 8).p(0): glTexCoord2fv tep(5, 8).p(0): glVertex3fv ep(5, 8).p(0)
    glEnd
    glBegin GL_TRIANGLE_STRIP
    glNormal3fv en(5, 0).p(0): glTexCoord2fv tep(5, 0).p(0): glVertex3fv ep(5, 0).p(0)
    glNormal3fv en(6, 0).p(0): glTexCoord2fv tep(6, 0).p(0): glVertex3fv ep(6, 0).p(0)
    glNormal3fv en(5, 1).p(0): glTexCoord2fv tep(5, 1).p(0): glVertex3fv ep(5, 1).p(0)
    glNormal3fv en(6, 1).p(0): glTexCoord2fv tep(6, 1).p(0): glVertex3fv ep(6, 1).p(0)
    glNormal3fv en(5, 2).p(0): glTexCoord2fv tep(5, 2).p(0): glVertex3fv ep(5, 2).p(0)
    glNormal3fv en(6, 2).p(0): glTexCoord2fv tep(6, 2).p(0): glVertex3fv ep(6, 2).p(0)
    glNormal3fv en(5, 3).p(0): glTexCoord2fv tep(5, 3).p(0): glVertex3fv ep(5, 3).p(0)
    glNormal3fv en(6, 3).p(0): glTexCoord2fv tep(6, 3).p(0): glVertex3fv ep(6, 3).p(0)
    glNormal3fv en(5, 4).p(0): glTexCoord2fv tep(5, 4).p(0): glVertex3fv ep(5, 4).p(0)
    glNormal3fv en(6, 4).p(0): glTexCoord2fv tep(6, 4).p(0): glVertex3fv ep(6, 4).p(0)
    glNormal3fv en(5, 5).p(0): glTexCoord2fv tep(5, 5).p(0): glVertex3fv ep(5, 5).p(0)
    glNormal3fv en(6, 5).p(0): glTexCoord2fv tep(6, 5).p(0): glVertex3fv ep(6, 5).p(0)
    glNormal3fv en(5, 6).p(0): glTexCoord2fv tep(5, 6).p(0): glVertex3fv ep(5, 6).p(0)
    glNormal3fv en(6, 6).p(0): glTexCoord2fv tep(6, 6).p(0): glVertex3fv ep(6, 6).p(0)
    glNormal3fv en(5, 7).p(0): glTexCoord2fv tep(5, 7).p(0): glVertex3fv ep(5, 7).p(0)
    glNormal3fv en(6, 7).p(0): glTexCoord2fv tep(6, 7).p(0): glVertex3fv ep(6, 7).p(0)
    glNormal3fv en(5, 8).p(0): glTexCoord2fv tep(5, 8).p(0): glVertex3fv ep(5, 8).p(0)
    glNormal3fv en(6, 8).p(0): glTexCoord2fv tep(6, 8).p(0): glVertex3fv ep(6, 8).p(0)
    glEnd

    glEndList
End Sub

Public Sub BuildLogo()

    glNewList LogoID, GL_COMPILE

    glTranslatef 5.5, -3.5, 4.5
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendRight
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendLeft
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendRight
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendLeft
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendRight
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -7
    glCallList DoubleCylinderID
    BendForward
    glCallList ElbowID
    glTranslatef 0, 0, -5
    glCallList SingleCylinderID
    BendLeft
    glCallList ElbowID

    glEndList
End Sub

Public Sub BuildLists()
    SingleCylinderID = glGenLists(1)
    DoubleCylinderID = glGenLists(1)
    ElbowID = glGenLists(1)
    LogoID = glGenLists(1)

    BuildSingleCylinder
    BuildDoubleCylinder
    BuildElbow
    BuildLogo

End Sub





