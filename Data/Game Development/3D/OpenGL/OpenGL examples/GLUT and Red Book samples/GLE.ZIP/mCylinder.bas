Attribute VB_Name = "mCylinder"
Option Explicit
''
' * cylinder drawing demo
' *
' * FUNCTION:
' * Basic demo illustrating how to write code to draw
' * the most basic cylinder shape.
' *
' * HISTORY:
' * Linas Vepstas March 1995
' */
'
Public IDCylinder&
Dim gleCyl As glePolyCylinder

Public Const NPTS = 6

' * Initialize a bent shape with three segments.
' * The data format is a polyline.
' *
' * NOTE that neither the first, nor the last segment are drawn.
' * The first & last segment serve only to determine that angle
' * at which the endcaps are drawn.
' */
Public Sub InitCyl()
Dim i&
Static secondTime As Boolean
    Set gleCyl = gCtl.NewPolyCylinder
    ' initialize the join style here */
    With gleCyl
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .NumPoints = NPTS
        .NUMCOLORS = NPTS
        .radius = 2.3
        
        .SetColor 0, 0, 0, 0
        .SetPt 0, -6, 6, 0
        '
        .SetColor 1, 0, 0.8, 0.3
        .SetPt 1, 6, 6, 0
        
        .SetColor 2, 0.8, 0.3, 0
        .SetPt 2, 6, -6, 0
        
        .SetColor 3, 0.2, 0.3, 0.9
        .SetPt 3, -6, -6, 0
        
        .SetColor 4, 0.2, 0.8, 0.5
        .SetPt 4, -6, 6, 0
        
        .SetColor 5, 0, 0, 0
        .SetPt 5, 6, 6, 0
    End With
    IDCylinder = glGenLists(1)
    glNewList IDCylinder, lstCompile
        DrawCylinder
    glEndList
End Sub


' draw the cylinder shape */
Public Sub DrawCylinder()
    ' Phew. FINALLY, Draw the polycylinder  -- */
    glPushMatrix
    gleCyl.Draw
    glPopMatrix
End Sub
' ------------------------ end of file ------------------- */

