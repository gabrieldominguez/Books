import BooGame
import System.Drawing

public class Script:
	static def Draw():
		font.Print('Hello World!', Color.White, 120, 180)
		for i in range(0, 20):
			x as single = ((i / 20.0F) * Display.Width)
			y as single = (Display.Height - ((i / 20.0F) * Display.Height))
			Paint.Line(x, Display.Height, Display.Width, y, Color.Red)

	static font = BooGame.Font(FontFamily.GenericMonospace, 30, FontStyle.Bold)

	static def Main():
		Display.WindowCaption = 'BooGame - Hello World!'
		Display.ClearColor = Color.Black
		Core.Draw += Draw
		Core.Run()
