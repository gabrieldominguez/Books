class AwesomeEnemy extends AwesomeActor;

var float BumpDamage;
var Pawn Enemy;
var float MovementSpeed;
var float AttackDistance;

function GetEnemy()
{
    local AwesomePlayerController PC;

    foreach LocalPlayerControllers(class'AwesomePlayerController', PC)
    {
        if(PC.Pawn != none)
            Enemy = PC.Pawn;
    }
}

event TakeDamage(int DamageAmount, Controller EventInstigator, vector HitLocation, vector Momentum, class<DamageType> DamageType, optional TraceHitInfo HitInfo, optional Actor DamageCauser)
{
    if(EventInstigator != none && EventInstigator.PlayerReplicationInfo != none)
        WorldInfo.Game.ScoreObjective(EventInstigator.PlayerReplicationInfo, 1);

    if(AwesomeEnemySpawner(Owner) != none)
        AwesomeEnemySpawner(Owner).EnemyDied();

    Destroy();
}

function RunAway()
{
    GoToState('Fleeing');
}

auto state Seeking
{
    function Tick(float DeltaTime)
    {
        local vector NewLocation;
    
        if(Enemy == none)
            GetEnemy();
    
        if(Enemy != none)
        {
            NewLocation = Location;
            NewLocation += normal(Enemy.Location - Location) * MovementSpeed * DeltaTime;
            SetLocation(NewLocation);
    
            if(VSize(NewLocation - Enemy.Location) < AttackDistance)
                GoToState('Attacking');
        }
    }
}

state Attacking
{
    function Tick(float DeltaTime)
    {
        if(Enemy == none)
            GetEnemy();
    
        if(Enemy != none)
        {
            Enemy.Bump(self, CollisionComponent, vect(0,0,0));
    
            if(VSize(Location - Enemy.Location) > AttackDistance)
                GoToState('Seeking');
        }
    }
}

state Fleeing
{
    function Tick(float DeltaTime)
    {
        local vector NewLocation;
    
        if(Enemy == none)
            GetEnemy();
    
        if(Enemy != none)
        {
            NewLocation = Location;
            NewLocation -= normal(Enemy.Location - Location) * MovementSpeed * DeltaTime;
            SetLocation(NewLocation);
        }
    }
}

defaultproperties
{
    AttackDistance=96.0
    MovementSpeed=256.0
    BumpDamage=5.0
    bBlockActors=True
    bCollideActors=True

    Begin Object Class=DynamicLightEnvironmentComponent Name=MyLightEnvironment
        bEnabled=TRUE
    End Object
    Components.Add(MyLightEnvironment)

    Begin Object Class=StaticMeshComponent Name=PickupMesh
        StaticMesh=StaticMesh'UN_SimpleMeshes.TexPropCube_Dup'
        Materials(0)=Material'EditorMaterials.WidgetMaterial_X'
        LightEnvironment=MyLightEnvironment
        Scale3D=(X=0.25,Y=0.25,Z=0.5)
    End Object
    Components.Add(PickupMesh)

    Begin Object Class=CylinderComponent Name=CollisionCylinder
        CollisionRadius=32.0
        CollisionHeight=64.0
        BlockNonZeroExtent=true
        BlockZeroExtent=true
        BlockActors=true
        CollideActors=true
    End Object
    CollisionComponent=CollisionCylinder
    Components.Add(CollisionCylinder)
}
