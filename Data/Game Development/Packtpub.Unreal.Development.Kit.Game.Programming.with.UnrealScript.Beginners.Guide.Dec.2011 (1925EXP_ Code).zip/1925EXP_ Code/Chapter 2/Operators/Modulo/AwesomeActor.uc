class AwesomeActor extends Actor
    placeable;

var int Int1, Int2, IntResult;

function PostBeginPlay()
{
    IntResult = Int1 % Int2;
    `log("IntResult:" @ IntResult);
}

defaultproperties
{
    Int1=28
    Int2=5

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
