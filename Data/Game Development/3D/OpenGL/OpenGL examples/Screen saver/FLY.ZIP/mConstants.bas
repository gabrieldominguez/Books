Attribute VB_Name = "mConstants"
Option Explicit

Type POINT_N3F_V3F
    Normal(0 To 2) As Single
    vertex(0 To 2) As Single
End Type
Type MATRIX
    m(0 To 3, 0 To 3) As GLfloat
End Type


' Resource constants
Public Const regAppName = "OpenGL 3D Flying Objects"
Public Const regSection = "Settings" '1002
' registry attribute strings:
Public Const regTessFactor = "Tesselation"
Public Const regSize = "Size"
Public Const regType = "Type"
Public Const regColorCycle = "ColorCycle"
Public Const regSmoothshading = "Smoothshading"
Public Const regTextureFile = "TextureFile"
'
Public Const PI = 3.14159265358979
Public Const ZERO_EPS = 0.00000001
