VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxUtility"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: Utility routines. These are for quick testing. For
'efficiency you should have versions of these in your app.
'AUTHOR: edx - edx@hk.super.net,
'HISTORY: Feb 99 - cleaned them up a bit
'                - added debug interface
'-------------------------------------------------------------------------
Public Function Atan2Deg(X#, Y#) As Double
    Atan2Deg = Atan2d(X, Y) * 180 / M_PI
End Function

Public Function Atan2(X#, Y#) As Double
    Atan2 = Atan2d(X, Y)
End Function

Public Function Atan2Degf!(ByVal X!, ByVal Y!)
    Atan2Degf = Atan2f(X, Y) * 180 / M_PI
End Function

Public Function Atan2f!(ByVal X!, ByVal Y!)
    Atan2f = Atan2f(X, Y)
End Function

'-------------------------------------------------------------------------
'returns a value clamped within a range
'-------------------------------------------------------------------------
Public Function ClampToRange(A, lo, hi)
    If (A < lo) Then
        ClampToRange = lo
    ElseIf (A > hi) Then
        ClampToRange = hi
    Else
        ClampToRange = A
    End If
End Function

'-------------------------------------------------------------------------
'returns a value clamped within a range.
'Sets the input value A to that value also.
'-------------------------------------------------------------------------
Public Function ClampToRange2(A, lo, hi)
    If (A < lo) Then
        A = lo
        ClampToRange2 = lo
    ElseIf (A > hi) Then
        A = hi
        ClampToRange2 = hi
    Else
        ClampToRange2 = A
    End If
End Function

'------------------------------------------------------------------------------------
'Initializes an array
'------------------------------------------------------------------------------------
Public Sub FillArrayf(A!(), ParamArray n())
Dim v, i&
    On Error GoTo EH:
    For Each v In n
        A(i) = v
        i = i + 1
    Next
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'------------------------------------------------------------------------------------
Public Sub CopyArrayf(dest!(), ParamArray Src())
Dim v, i&
    On Error GoTo EH:
    For Each v In Src
        dest(i) = v
        i = i + 1
    Next
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'------------------------------------------------------------------------------------
Public Function DegToRad(A)
DegToRad = A * PI * ONE_OVER_180
End Function

Public Function RadToDeg(A)
RadToDeg = (A * 180) * ONE_OVER_PI
End Function

'-------------------------------------------------------------------------
' Generates integer random number 0..(max)
'-------------------------------------------------------------------------
Public Function RandomInt&(Max&)
RandomInt = Max * Rnd()
End Function

'-------------------------------------------------------------------------
' Generates integer random number min..max
'-------------------------------------------------------------------------
Public Function RandomIntInRange&(Min&, Max&)
Dim temp&
    If (Min = Max) Then
        RandomIntInRange = Min
        Exit Function
    ElseIf (Max < Min) Then
        temp = Min
        Min = Max
        Max = temp
    End If
    RandomIntInRange = Min + ((Max - Min + 1) * Rnd)
End Function

'-------------------------------------------------------------------------
' Generates float random number min...max
'-------------------------------------------------------------------------
Public Function RandomSng!(Min!, Max!)
Dim diff!
    diff = Max - Min
    RandomSng = Min + (diff * Rnd)
End Function

'-------------------------------------------------------------------------
Public Function LShiftl#(n&, shift&)
On Error GoTo EH
    LShiftl = n * (2 ^ shift)
    Exit Function
EH:
    Debug.Assert 0
End Function

'-------------------------------------------------------------------------
Public Function RShiftl#(n&, shift&)
On Error GoTo EH
    RShiftl = n \ (2 ^ shift)
    Exit Function
EH:
    Debug.Assert 0
End Function

'Public Function RShiftb(n As Byte, shift&) As Byte
'RShiftb = n \ (2 ^ shift)
'End Function

'-------------------------------------------------------------------------
' macro to round up floating values
'-------------------------------------------------------------------------
Public Function RoundUp(fval!)
    If (fval - Int(fval)) > 0 Then
        RoundUp = Int(fval + 1)
    Else
        RoundUp = Int(fval)
    End If
End Function

'-------------------------------------------------------------------------
'Both Int and Fix remove the fractional part of number and return the
'resulting integer value.
'The difference between Int and Fix is that if number is negative,
'Int returns the first negative integer less than or equal to number,
'whereas Fix returns the first negative integer greater than or equal to number.
'For example, Int converts -8.4 to -9, and Fix converts -8.4 to -8.
'The ceil of 2.8 is 3.0, The ceil of -2.8 is -2.0
'-------------------------------------------------------------------------
Public Function Ceil!(fval!)
    If fval > 0 Then
        If fval = Int(fval) Then
            Ceil = Int(fval)
        Else
            Ceil = Int(fval + 1)
        End If
    Else
        'Fix returns the first negative integer greater
        'than or equal to number.
        Ceil = Fix(fval)
    End If
End Function

'-------------------------------------------------------------------------
'The floor of 2.8 is 2.0, The floor of -2.8 is -3.0
'-------------------------------------------------------------------------
Public Function Floor!(fval!)
    Floor = Int(fval)
End Function

'-------------------------------------------------------------------------
'return the 255 values for the color components
'-------------------------------------------------------------------------
Public Function GetRValue(X As Long) As Byte
    GetRValue = (X \ &H10000) And &HFF
End Function

Public Function GetGValue(X As Long) As Byte
    GetGValue = (X \ &H100) And &HFF
End Function

Public Function GetBValue(X As Long) As Byte
    GetBValue = X And &HFF
End Function

'-------------------------------------------------------------------------
'set current color from RGB255 values
'-------------------------------------------------------------------------
Public Sub glRGB(r%, g%, B%)
    glColor3f r / 255, g / 255, B / 255
End Sub

'-------------------------------------------------------------------------
'set current color from RGB255 values
'-------------------------------------------------------------------------
Public Sub glColor32(Color&)
    SetGLColor Color
End Sub

'-------------------------------------------------------------------------
Public Function StringToByteArray&(A() As Byte, s$)
Dim i&
    If Len(s) Then
        For i = 1 To Len(s)
            A(i - 1) = Asc(Mid$(s, i, 1))
        Next
        A(i) = 0
    End If
End Function

'-------------------------------------------------------------------------
Public Function Max(A, B)
Max = IIf(A > B, A, B)
End Function

Public Function Min(A, B)
Min = IIf(A < B, A, B)
End Function

'-------------------------------------------------------------------------
Public Sub HSVtoRGB(H!, s!, v!, color4!())
Dim i!, f!, p!, q!, t!
    ' set alpha value, so caller doesn't have to worry about undefined value
    color4(3) = 1
    If (s = 0) Then    ' assume h is undefined
        color4(0) = v
        color4(1) = v
        color4(2) = v
    Else
        If H >= 360 Then H = 0
        H = H / 60
        i = Int(H)
        f = H - i
        p = v * (1 - s)
        q = v * (1 - (s * f))
        t = v * (1 - (s * (1 - f)))
        Select Case i
        Case 0:
            color4(0) = v
            color4(1) = t
            color4(2) = p
        Case 1:
            color4(0) = q
            color4(1) = v
            color4(2) = p
        Case 2:
            color4(0) = p
            color4(1) = v
            color4(2) = t
        Case 3:
            color4(0) = p
            color4(1) = q
            color4(2) = v
        Case 4:
            color4(0) = t
            color4(1) = p
            color4(2) = v
        Case 5:
            color4(0) = v
            color4(1) = p
            color4(2) = q
        Case Else:
            Debug.Assert 0
        End Select
    End If
End Sub


