<%@ Page Language="c#" Debug="true" Explicit="True" %>

<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Drawing" %>
<%@ Import Namespace="System.Web.Mail" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="Microsoft.CSharp" %>
<%@ Import Namespace="System.Drawing.Imaging" %>
<%@ Import Namespace="System.CodeDom.Compiler" %>
<%@ Import Namespace="System.Reflection" %>
<%@ Import Namespace="System.Collections" %>

<script language="C#" runat="server">

    private void Page_Load(object sender, System.EventArgs e)
    {
    Bitmap newBitmap = new Bitmap(200, 200, PixelFormat.Format32bppArgb);
    Graphics g = Graphics.FromImage(newBitmap);

    Pen blackPen = new Pen(Color.Black);
    Color clrBackground = Color.Black;
    g.FillRectangle(new SolidBrush(clrBackground), new Rectangle(0, 0, 200, 200));

    Rectangle rect = new Rectangle(0, 0, 200, 200);
  
    ///////////////////////////////////////
    System.Collections.ArrayList obj3dArrayList;
    obj3dArrayList = new System.Collections.ArrayList();
    obj3dArrayList.Add(new Sphere(0.0, 0.0, 90.0, 100.0, 0.0, 0.0, 255.0));
    obj3dArrayList.Add(new Sphere(-180.0, -130.0, -110.0, 15.0, 255.0, 0.0, 0.0));
    obj3dArrayList.Add(new Sphere(-140.0, -140.0, -150.0, 20.0, 255.0, 200.0, 0.0));

    Graphics graphics = g;

    double px = (double)Session["eyex"], 
    py = (double)Session["eyey"],
    pz = (double)Session["eyez"];
   
    double lpx = (double)Session["lpx"], 
    lpy = (double)Session["lpy"], 
    lpz = (double)Session["lpz"];
    
    double lvx = (double)Session["lvx"], 
    lvy = (double)Session["lvy"], 
    lvz = (double)Session["lvz"];
    
    double fMax = 200.0;

    for (int i = rect.Left; i <= rect.Right; i++)
    {
        double x = Sphere.GetCoord(rect.Left, rect.Right, -fMax, fMax, i);

        for (int j = rect.Top; j <= rect.Bottom; j++)
        {
            double y = Sphere.GetCoord(rect.Top, rect.Bottom, fMax, -fMax, j);

            double t = 1.0E10;

            double vx = x - px, vy = y - py, vz = -pz;

            double mod_v = Sphere.modv(vx, vy, vz);
            vx = vx / mod_v;
            vy = vy / mod_v;
            vz = vz / mod_v;

            bool bShadow = false;

            Sphere spherehit = null;

            for (int k = 0; k < (int)obj3dArrayList.Count; k++)
            {
                Sphere sphn = (Sphere)obj3dArrayList[k];
                double taux = Sphere.GetSphereIntersec(sphn.cx, sphn.cy, sphn.cz, sphn.radius, px, py, pz, vx, vy, vz);
                if (taux < 0) continue;

                if (taux > 0 && taux < t)
                {
                    t = taux;
                    spherehit = sphn;
                }
            }

            Color color;
            color = Color.FromArgb(10, 20, 10);

            Pen pen = new Pen(Color.Black);

            if (spherehit != null)
            {
                double itx = px + t * vx, ity = py + t * vy, itz = pz + t * vz;

                // shadow

                double tauxla = Sphere.GetSphereIntersec(spherehit.cx, spherehit.cy, spherehit.cz, spherehit.radius, lpx, lpy, lpz, itx - lpx, ity - lpy, itz - lpz);
                for (int k = 0; k < (int)obj3dArrayList.Count; k++)
                {
                    Sphere sphnb = (Sphere)(obj3dArrayList[k]);
                    if (sphnb != spherehit)
                    {
                        double tauxlb = Sphere.GetSphereIntersec(sphnb.cx, sphnb.cy, sphnb.cz, sphnb.radius, lpx, lpy, lpz, itx - lpx, ity - lpy, itz - lpz);
                        if (tauxlb > 0 && tauxla < tauxlb)
                        {
                            bShadow = true;
                            break;
                        }
                    }
                }

                double cost = Sphere.GetCosAngleV1V2(lvx, lvy, lvz, itx - spherehit.cx, ity - spherehit.cy, itz - spherehit.cz);
                if (cost < 0) cost = 0;

                double fact = 1.0;
                if (bShadow == true) fact = 0.5; else fact = 1.0;
                double rgbR = spherehit.clR * cost * fact;
                double rgbG = spherehit.clG * cost * fact;
                double rgbB = spherehit.clB * cost * fact;

                color = Color.FromArgb((int)rgbR, (int)rgbG, (int)rgbB);
                pen = new Pen(color);
            }

            Brush brs = new SolidBrush(color);
            graphics.FillRectangle(brs, i, j, 1, 1);

            graphics.DrawLine(pen, i, j, i + 1, j + 1);

        }// for pixels lines
    }// for pixels columns
    ///////////////////////////////////////

    MemoryStream tempStream = new MemoryStream();
    newBitmap.Save(tempStream, ImageFormat.Png);
    Response.ClearContent();
    Response.ContentType = "image/png";
    Response.BinaryWrite(tempStream.ToArray());
    Response.Flush();
  
    }


</script>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Raytracing</title>
</head>
<body style="padding-right: 0px; padding-left: 0px; padding-bottom: 0px; margin: 0px;
    padding-top: 0px; text-align: center;">
    <form id="form1" runat="server">
    </form>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-2275356-1";
urchinTracker();
</script></body>
</html>
