Attribute VB_Name = "gleExtrusions"
Option Explicit
'/*
' * MODULE: extrude.c
' *
' * FUNCTION:
' * Provides  code for the cylinder, cone and extrusion routines.
' * The cylinders/cones/etc. are built on top of general purpose
' * extrusions. The code that handles the general purpose extrusions
' * is in other modules.
' *
' * AUTHOR:
' * written by Linas Vepstas August/September 1991
' * added polycone, February 1993
'
'-------------------------------------------------------------------------
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------==
'edx: this is the main drawing entry point
'gleExtrusion -> calls direct
'gleHelicoid -> SuperHelix -> GenSpiral/GenLathe -> here
'gleLathe -> GenLathe ->GenSpiral -> here
'glePolyCone -> GenPolyCone -> here
'glePolycylinder -> GenPolyCone -> here
'gleScrew -> GenTwistExtrusion -> here
'gleSpiral -> GenSpiral -> here
'gleSuperExtrusion -> calls direct
'gleToroid -> SuperHelix -> GenSpiral/GenLathe -> here
'gleTwistExtrusion -> GenTwistExtrusion -> here
'-------------------------------------------------------------------------==
' * draw a general purpose extrusion
'public sub gleSuperExtrusion (ncp&,               ' number of contour points
'                gleDouble contour()(2),    ' 2D contour
'                gleDouble cont_normal()(2), ' 2D contour normals
'                gleDouble up(3),           ' up vector for contour
'                int npoints,           ' numpoints in poly-line
'                gleDouble point_array()(3),        ' polyline
'                float color_array()(3),        ' color of polyline
'                gleDouble xform_array()(2)(3))   ' 2D contour xforms
Public Sub SuperExtrusion(gc As gleGC)
   Select Case gc.JoinStyle
    Case gleRAW:
         ExtrusionRawJoin gc
    Case gleANGLE:
         ExtrusionAngleJoin gc
    Case gleCUT, gleROUND:
         ' This routine used for both cut and round styles
         ExtrusionRoundOrCutJoin gc
   End Select
End Sub

'-------------------------------------------------------------------------==
'edx: called by glePolyCylinder and glePolycone
'User specifies
'   - polyline
'   - radius_array (for cones)
'   glePolyCone builds xform_array from radius_array
'This routine builds the
'   - contour array
'   - contournormal_array
'-------------------------------------------------------------------------==
Public Sub GenPolycone(gc As gleGC, Optional r# = 1)
Dim c#, s#, i&
Dim v21#(0 To 2)
Dim lng#
Dim rad#
With gc
    .ncp = POLYCYL_TESS
    ReDim .contour(0 To POLYCYL_TESS - 1)
    .ncnormals = POLYCYL_TESS
    ReDim .cont_normal(0 To POLYCYL_TESS - 1)
    ' this if statement forces this routine into double-duty for
    ' both the polycone and the polycylinder routines
    'If gc.nxforms = 0 Then
        rad = r
    'End If

    s = Sin(2 * M_PI / POLYCYL_TESS)
    c = Cos(2 * M_PI / POLYCYL_TESS)

   .cont_normal(0).v(0) = 1
   .cont_normal(0).v(1) = 0
   .contour(0).v(0) = rad
   .contour(0).v(1) = 0

   ' draw a norm using recursion relations
    For i = 1 To POLYCYL_TESS - 1
        .cont_normal(i).v(0) = .cont_normal(i - 1).v(0) * _
                    c - .cont_normal(i - 1).v(1) * s
        .cont_normal(i).v(1) = .cont_normal(i - 1).v(0) * _
                    s + .cont_normal(i - 1).v(1) * c
        .contour(i).v(0) = rad * .cont_normal(i).v(0)
        .contour(i).v(1) = rad * .cont_normal(i).v(1)
   Next

   ' avoid degenerate vectors
   ' first, find a non-zero length segment
   i = 0
   FIND_NON_DEGENERATE_POINT i, .npoints, lng, v21, .point_array
   If (i = .npoints) Then Exit Sub

   ' next, check to see if this segment lies along x-axis
   If ((v21(0) = 0) And (v21(2) = 0)) Then
      .up(0) = 1
      .up(1) = 1
      .up(2) = 1
   Else
      .up(0) = 0
      .up(2) = 0
      .up(1) = 1
   End If

   ' edx: not possible for user to set it
   gc.ContourStyle = gleCLOSED

   ' if lighting is not turned on, don't send normals.
   ' MMODE is a good indicator of whether lighting is active
   gc.ncp = POLYCYL_TESS
   If glIsEnabled(GL_LIGHTING) = 0 Then
        Erase .cont_normal
        SuperExtrusion gc
   Else
        SuperExtrusion gc
   End If
End With
End Sub

'-------------------------------------------------------------------------==
'edx: called by gleTwistExtrusion and gleScrew
'User (or gleScrew) specifies
'   - twist_array
'This routine builds
'   - xform_array
'-------------------------------------------------------------------------==
'public sub gleTwistExtrusion (ncp&,         ' number of contour points
'                gleDouble contour()(2),    ' 2D contour
'                gleDouble cont_normal()(2), ' 2D contour normals
'                gleDouble up(3),           ' up vector for contour
'                int npoints,           ' numpoints in poly-line
'                gleDouble point_array()(3),        ' polyline
'                float color_array()(3),        ' color of polyline
'                gleDouble twist_array())   ' countour twists (in degrees)
'-------------------------------------------------------------------------
Public Sub GenTwistExtrusion(gc As gleGC, twist_array#())
Dim j&, angle#, si#, co#
With gc
    ' build 2D affine matrices from radius array
    'xforms = (gleAffine *) malloc (npoints * sizeof(gleAffine));
    .nxforms = .npoints
    ReDim .xform_array(0 To .npoints - 1)
    For j = 0 To .npoints - 1
        angle = (M_PI / 180) * twist_array(j)
        si = Sin(angle)
        co = Cos(angle)
        .xform_array(j).v0(0) = co
        .xform_array(j).v0(1) = -si
        .xform_array(j).v0(2) = 0
        .xform_array(j).v1(0) = si
        .xform_array(j).v1(1) = co
        .xform_array(j).v1(2) = 0
    Next
    SuperExtrusion gc
End With
End Sub

'-------------------------------------------------------------------------==
'edx: called by gleSpiral, and indirectly gleLathe, gleTorroid, gleHelicoid
'User (or routine) specifies
'   - contour
'   - contournormals
'This routine builds the
'   - point_array
'   - xform_array, if needed
'-------------------------------------------------------------------------==
' * The spiral primitive forms the basis for the helicoid primitive.
' *
' * Note that this primitive sweeps a contour along a helical path.
' * The algorithm assumes that the path is embedded in Euclidean space,
' * and uses parallel transport along the path.  Parallel transport
' * provides the simplest mathematical model for moving a coordinate
' * system along a curved path, but some of the effects of doing so
' * may prove to be surprising to one uninitiated to the concept.
' *
' * Thus, we provide another, related, algorithm below, called "lathe"
' * which introduces a torsion component along the path, correcting for
' * the rotation induced by the helical path.
' *
' * If the above sounds like gobldy-gook to you, you may want to brush
' * up on differential geometry. Recommend Spivak, Differential Geometry,
' * Volume 1, pages xx-xx.
'
'public sub gleSpiral (ncp&,               ' number of contour points
'             gleDouble contour()(2),    ' 2D contour
'             gleDouble cont_normal()(2), ' 2D contour normals
'             gleDouble up(3),           ' up vector for contour
'             gleDouble startRadius,
'             gleDouble drdTheta,        ' change in radius per revolution
'             gleDouble startZ,
'             gleDouble dzdTheta,        ' change in Z per revolution
'             gleDouble startXform(2)(3),
'             gleDouble dXformdTheta(2)(3), ' tangent change xform per revolution
'             gleDouble startTheta,        ' start angle, in degrees
'             gleDouble sweepTheta)        ' sweep angle, in degrees
Public Sub GenSpiral(gc As gleGC, _
                ByVal startRadius#, ByVal drdTheta#, ByVal startZ#, ByVal dzdTheta#, _
                startXform() As gleAffine, _
                dXformdTheta() As gleAffine, _
                ByVal startTheta#, ByVal sweepTheta#)
Dim deltaAngle#
Dim ptr& 'pts#() 'gleDouble *pts;
Dim xforms#() 'As gleAffine  ' *xforms;
'Dim xformPtr&
Dim delta#
Dim saved_style&
Dim ccurr#, scurr#, cprev#, sprev#
Dim cdelta#, sdelta#, ma#(0 To 1, 0 To 1), mB#(0 To 1, 0 To 1)
Dim run#(0 To 1, 0 To 1)
Dim deltaTrans#(0 To 1)
Dim trans#(0 To 1)
Dim i&
Dim startXformSize&
Dim dXformdThetaSize&
'Dim dummy_color!()
'Dim xformsZ#()  ' *xforms;
startXformSize = ArraySizeA(startXform)
dXformdThetaSize = ArraySizeA(dXformdTheta)
With gc
    ' allocate sufficient memory to store path
    .npoints = (((POLYCYL_TESS) / 360) * Abs(sweepTheta)) + 4

    If startXformSize = 0 Then
        ReDim .point_array(0 To .npoints - 1)
    Else
        ReDim .point_array(0 To .npoints - 1)
        ReDim .xform_array(0 To .npoints - 1)
    End If

    ' compute delta angle based on number of points
    deltaAngle = (M_PI / 180) * sweepTheta / (.npoints - 3)
    startTheta = startTheta * (M_PI / 180)
    startTheta = startTheta - deltaAngle
    
    ' initialize factors
    cprev = Cos(startTheta)
    sprev = Sin(startTheta)
    
    cdelta = Cos(deltaAngle)
    sdelta = Sin(deltaAngle)
    
    ' renormalize differential factors
    delta = deltaAngle / (2 * M_PI)
    dzdTheta = dzdTheta * delta
    drdTheta = drdTheta * delta
    
    ' remember, the first point is hidden, so back-step
    startZ = startZ - dzdTheta
    startRadius = startRadius - drdTheta

    ' draw spiral path using recursion relations for sine, cosine
    For i = 0 To .npoints - 1
        .point_array(i).v(0) = startRadius * cprev
        .point_array(i).v(1) = startRadius * sprev
        .point_array(i).v(2) = startZ

        startZ = startZ + dzdTheta
        startRadius = startRadius + drdTheta
        ccurr = cprev * cdelta - sprev * sdelta
        scurr = cprev * sdelta + sprev * cdelta
        cprev = ccurr
        sprev = scurr
    Next

    ' If there is a deformation matrix specified, then a deformation
    ' * path must be generated also
    If startXformSize Then
        If (dXformdThetaSize = 0) Then
            For i = 0 To .npoints - 1
                .xform_array(i).v0(0) = startXform(0).v0(0)
                .xform_array(i).v0(1) = startXform(0).v0(1)
                .xform_array(i).v0(2) = startXform(0).v0(2)
                .xform_array(i).v1(0) = startXform(0).v1(0)
                .xform_array(i).v1(1) = startXform(0).v1(1)
                .xform_array(i).v1(2) = startXform(0).v1(2)
            Next
        Else
            '
            ' * if there is a differential matrix specified, treat it a
            ' * a tangent (algebraic, infinitessimal) matrix.  We need to
            ' * project it into the group of real 2x2 matricies.  (Note that
            ' * the specified matrix is affine.  We treat the translation
            ' * components linearly, and only treat the 2x2 submatrix as an
            ' * algebraic tangenet).
            ' *
            ' * For exponentiaition, we use the well known approx:
            ' * exp(x) = lim (N->inf) (1+x/N) ** N
            ' * and take N=32.
            '
        
            ' initialize translation and delta translation
            deltaTrans(0) = delta * dXformdTheta(0).v0(2)
            deltaTrans(1) = delta * dXformdTheta(0).v1(2)
            trans(0) = startXform(0).v0(2)
            trans(1) = startXform(0).v1(2)
            
            ' prepare the tangent matrix
            delta = delta / 32
            ma(0, 0) = 1 + delta * dXformdTheta(0).v0(0)
            ma(0, 1) = delta * dXformdTheta(0).v0(1)
            ma(1, 0) = delta * dXformdTheta(0).v1(0)
            ma(1, 1) = 1 + delta * dXformdTheta(0).v1(1)
            
            ' compute exponential of matrix
            MatMultiply2X2d mB, ma, ma  ' squared
            MatMultiply2X2d ma, mB, mB  ' 4th power
            MatMultiply2X2d mB, ma, ma ' 8th power
            MatMultiply2X2d ma, mB, mB ' 16th power
            MatMultiply2X2d mB, ma, ma  ' 32nd power
        
            ' initialize running matrix
            MatCopy2X2Ad run, startXform(0)
        
            ' remember, the first point is hidden -- load some, any
            ' * xform for the first point
            .xform_array(0).v0(0) = startXform(0).v0(0)
            .xform_array(0).v0(1) = startXform(0).v0(1)
            .xform_array(0).v0(2) = startXform(0).v0(2)
            .xform_array(0).v1(0) = startXform(0).v1(0)
            .xform_array(0).v1(1) = startXform(0).v1(1)
            .xform_array(0).v1(2) = startXform(0).v1(2)
            For i = 1 To .npoints - 1
                .xform_array(i).v0(0) = run(0, 0)
                .xform_array(i).v0(1) = run(0, 1)
                .xform_array(i).v1(0) = run(1, 0)
                .xform_array(i).v1(1) = run(1, 1)
                ' integrate to get exponential matrix
                ' (Note that the group action is a left-action --
                ' * i.e. multiply on the left (not the right))
                MatMultiply2X2d ma, mB, run
                MatCopy2X2d run, ma
         
                .xform_array(i).v0(2) = trans(0)
                .xform_array(i).v1(2) = trans(1)
                trans(0) = trans(0) + deltaTrans(0)
                trans(1) = trans(1) + deltaTrans(1)
            Next
      End If
   End If

    
    ' Allow only angle joins (for performance reasons).
    ' * The idea is that if the tesselation is fine enough, then an angle
    ' * join should be sufficient to get the desired visual quality.  A
    ' * raw join would look terrible, a cut join would leave garbage
    ' * everywhere, and a round join will over-tesselate (and thus
    ' * should be avoided for performance reasons).
    '
    ' save the current join style
    'saved_style = gc.JoinStyle
    gc.JoinStyle = gleANGLE

    Erase gc.color_array
    SuperExtrusion gc
    ' restore the join style
    'gc.JoinStyle = saved_style
End With
End Sub

'-------------------------------------------------------------------------==
'edx: called by gleLathe, indirectly by gleHelicoid and gleToroid
'User specifies
'   - contour
'   - contournormals
'This routine builds
'   - translation vector and adds it to dXformdTheta
'   - startXform (if missing)
'   - dXformdTheta(if missing)
'It then calls GenSpiral
'-------------------------------------------------------------------------==
'public sub gleLathe (ncp&,               ' number of contour points
'             gleDouble contour()(2),    ' 2D contour
'             gleDouble cont_normal()(2), ' 2D contour normals
'             gleDouble up(3),           ' up vector for contour
'             gleDouble startRadius,
'             gleDouble drdTheta,        ' change in radius per revolution
'             gleDouble startZ,
'             gleDouble dzdTheta,        ' change in Z per revolution
'             gleDouble startXform(2)(3),
'             gleDouble dXformdTheta(2)(3), ' tangent change xform per revln
'             gleDouble startTheta,        ' start angle, in degrees
'             gleDouble sweepTheta)        ' sweep angle, in degrees
'-------------------------------------------------------------------------==
Public Sub GenLathe(gc As gleGC, _
             ByVal startRadius#, ByVal drdTheta#, ByVal startZ#, ByVal dzdTheta#, _
             startXform() As gleAffine, _
             dXformdTheta() As gleAffine, ByVal startTheta#, ByVal sweepTheta#)
Dim localup#(0 To 2)
Dim lng#, trans#(0 To 1)
Dim Start(0 To 0) As gleAffine
Dim delt(0 To 0) As gleAffine '#(0 To 1, 0 To 2)
Dim startXformSize&
Dim dXformdThetaSize&

With gc
   ' Because the spiral always starts on the axis, and proceeds in the
   ' positive y direction, we can see that valid up-vectors must lie
   ' in the x-z plane. Therefore, we make sure we have a valid up
   ' vector by projecting it onto the x-z plane, and normalizing.
    If (.up(1) <> 0) Then
        localup(0) = .up(0)
        localup(1) = 0
        localup(2) = .up(2)
        V3Lengthd lng, localup
        If (lng <> 0) Then
           lng = 1 / lng
           localup(0) = localup(0) * lng
           localup(2) = localup(2) * lng
           V3Scaled localup, lng, localup
        Else
           ' invalid up vector was passed in
           localup(0) = 0
           localup(2) = 1
        End If
    Else
        V3Copyd localup, .up
    End If

    ' the dzdtheta derivative and the drdtheta derivative form a vector
    ' * in the x-z plane.  dzdtheta is the z component, and drdtheta is
    ' * the x component.  We need to convert this vector into the local
    ' * coordinate system defined by the up vector.  We do this by
    ' * applying a 2D rotation matrix.
    '
    trans(0) = localup(2) * drdTheta - localup(0) * dzdTheta
    trans(1) = localup(0) * drdTheta + localup(2) * dzdTheta

    ' now, add this translation vector into the affine xform
    startXformSize = ArraySizeA(startXform)
    dXformdThetaSize = ArraySizeA(dXformdTheta)
    If (startXformSize <> 0) Then
        If (dXformdThetaSize <> 0) Then
           MatCopy3X3d delt(0), dXformdTheta(0)
           delt(0).v0(2) = delt(0).v0(2) + trans(0)
           delt(0).v1(2) = delt(0).v1(2) + trans(1)
        Else
           'Hmm- the transforms don't exist
           delt(0).v0(0) = 0
           delt(0).v0(1) = 0
           delt(0).v0(2) = trans(0)
           delt(0).v1(0) = 0
           delt(0).v1(1) = 0
           delt(0).v1(2) = trans(1)
        End If
        GenSpiral gc, _
              startRadius, 0, startZ, 0, _
              startXform, delt, _
              startTheta, sweepTheta

    Else
        ' Hmm- the transforms don't exist
        Start(0).v0(0) = 1
        Start(0).v0(1) = 0
        Start(0).v0(2) = 0
        Start(0).v1(0) = 0
        Start(0).v1(1) = 1
        Start(0).v1(2) = 0
    
        delt(0).v0(0) = 0
        delt(0).v0(1) = 0
        delt(0).v0(2) = trans(0)
        delt(0).v1(0) = 0
        delt(0).v1(1) = 0
        delt(0).v1(2) = trans(1)
        GenSpiral gc, _
              startRadius, 0, startZ, 0, _
              Start, delt, _
              startTheta, sweepTheta
    End If
End With
End Sub

'-------------------------------------------------------------------------==
'edx: called by gleHelicoid and gleToroid
'User specifies
'   - parameters
'This routine builds
'   - contour
'   - contournormals
'Then calls Lathe or Spiral to generate points
'-------------------------------------------------------------------------==
' * Super-Helicoid primitive
'public sub super_helix ( rToroid#,
'             gleDouble startRadius,
'             gleDouble drdTheta,        ' change in radius per revolution
'             gleDouble startZ,
'             gleDouble dzdTheta,        ' change in Z per revolution
'             gleDouble startXform(2)(3),
'             gleDouble dXformdTheta(2)(3), ' tangent change xform per revol
'             gleDouble startTheta,        ' start angle, in degrees
'             gleDouble sweepTheta,        ' sweep angle, in degrees
'             HelixCallback helix_callback)
'-------------------------------------------------------------------------==
Public Sub SuperHelix(gc As gleGC, ByVal rToroid#, ByVal startRadius#, ByVal drdTheta#, ByVal startZ#, _
                ByVal dzdTheta#, _
                startXform() As gleAffine, _
                dXformdTheta() As gleAffine, _
                ByVal startTheta#, ByVal sweepTheta#, ByVal helix_callback&) ' As HelixCallback)
Dim c_saved_style&
Dim n_saved_style&
Dim c#, s#, i&
With gc
    .ncp = POLYCYL_TESS
    .ncnormals = POLYCYL_TESS
    ReDim .contour(0 To POLYCYL_TESS - 1)
    ReDim .cont_normal(0 To POLYCYL_TESS - 1)
    ' initialize sine and cosine for circle recusrion equations
    s = Sin(2 * M_PI / POLYCYL_TESS)
    c = Cos(2 * M_PI / POLYCYL_TESS)

    .cont_normal(0).v(0) = 1
    .cont_normal(0).v(1) = 0
    .contour(0).v(0) = rToroid
    .contour(0).v(1) = 0

    ' draw a norm using recursion relations
    For i = 1 To POLYCYL_TESS - 1
        .cont_normal(i).v(0) = .cont_normal(i - 1).v(0) * c - .cont_normal(i - 1).v(1) * s
        .cont_normal(i).v(1) = .cont_normal(i - 1).v(0) * s + .cont_normal(i - 1).v(1) * c
        .contour(i).v(0) = rToroid * .cont_normal(i).v(0)
        .contour(i).v(1) = rToroid * .cont_normal(i).v(1)
    Next

   ' make up vector point along x axis
   .up(0) = 1
   .up(1) = 0
   .up(2) = 0

   ' save the current join style
   c_saved_style = gc.ContourStyle
   gc.ContourStyle = gleCLOSED
   n_saved_style = gc.NormStyle
   gc.NormStyle = glePATH_EDGE

    ' if lighting is not turned on, don't send normals.
    ' * MMODE is a good indicator of whether lighting is active
    If (glIsEnabled(GL_LIGHTING) = 0) Then
        Erase gc.cont_normal
    End If
    '
    Select Case helix_callback
    Case hc_gleSpiral
        GenSpiral gc, startRadius, drdTheta, startZ, _
            dzdTheta, startXform, dXformdTheta, startTheta, sweepTheta
    Case hc_gleLathe
        GenLathe gc, startRadius, drdTheta, startZ, _
            dzdTheta, startXform, dXformdTheta, startTheta, sweepTheta
    End Select
   
   ' restore the join style
   gc.ContourStyle = c_saved_style
   gc.NormStyle = n_saved_style
End With
End Sub

