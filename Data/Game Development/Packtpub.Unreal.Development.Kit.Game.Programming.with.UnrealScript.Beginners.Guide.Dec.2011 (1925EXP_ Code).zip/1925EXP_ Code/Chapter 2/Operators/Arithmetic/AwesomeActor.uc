class AwesomeActor extends Actor
    placeable;

var float Float1, Float2;
var int Int1;

var vector Vect1, Vect2, VectResult;

function PostBeginPlay()
{
    Float2 = Int1 / Float1;
    `log("Float2:" @ Float2);

    Int1++;
    `log("Int1" @ Int1);

    VectResult = Vect1 + Vect2;
    `log("VectResult:" @ VectResult);
}

defaultproperties
{
    Int1=5
    Float1=2.0

    Vect1=(X=1.0,Y=4.5,Z=12.0)
    Vect2=(X=2.0,Y=4.0,Z=8.0)

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
