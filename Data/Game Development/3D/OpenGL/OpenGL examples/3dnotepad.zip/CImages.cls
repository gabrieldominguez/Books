VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CImages"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"No"
Attribute VB_Ext_KEY = "Collection" ,"CImage"
Attribute VB_Ext_KEY = "Member0" ,"CImage"
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: manages the textures, basically so the same image
'doesn't get loaded twice.
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES:
'--------------------------------------------------------------------

'local variable to hold collection
Private mCol As Collection
'Dim NextID&

'---------------------------------------------------------
'loads a image if it is not already loaded
'---------------------------------------------------------
Public Function LoadImage(Name$) As CImage
Dim i&
    For i = 1 To mCol.Count
        If mCol(i).Filename = Name Then
            Set LoadImage = mCol(i)
            Exit Function
        End If
    Next
    Set LoadImage = Add(Name)
End Function


Private Function Add(Filename$) As CImage
Dim ni As CImage, r&
    Set ni = New CImage
    ni.Filename = Filename
    mCol.Add ni, Format$(ni.Tex.TexID)
    Set Add = ni
End Function

Public Property Get Item(ID&) As CArea
    Set Item = mCol(ID)
End Property

Public Property Get Count() As Long
    Count = mCol.Count
End Property

Public Sub Remove(ID&)
    mCol.Remove ID
End Sub

Public Property Get NewEnum() As IUnknown
    Set NewEnum = mCol.[_NewEnum]
End Property

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub

Public Function Save(Path$) As Boolean
Dim i&
    For i = 1 To mCol.Count
        mCol(i).Save Path
    Next
    Save = True
End Function
