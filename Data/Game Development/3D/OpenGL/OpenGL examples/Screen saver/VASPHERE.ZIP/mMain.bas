Attribute VB_Name = "mMain"
Option Explicit

Public gSphere As CVASphere
Public gCtl As glxCtl

Public Sub Main()
Dim n&
If App.PrevInstance Then End
    '
    Set gSphere = New CVASphere
    Load frmMain
    'the ocx now exists
    Set gCtl = frmMain.glxCtl1
    gCtl.Init 'fires InitGL event
    frmMain.Show
    gCtl.Animate = True 'start timer

End Sub

       
    

