/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;

namespace ScrollDemo
{
    /// <summary>
    /// BooGame demonstration of using a Tile Studio map (ScrollDemo).
    /// </summary>
    public class ScrollDemo : GameState
    {
        public static void Main()
        {
            // Give BooGame the ability to load files from the zip file
            FileSystem.AddSearchPath("ScrollDemoData.zip");

            // Setup the game system
            Core.Game = new ScrollDemo();
            Display.ClearColor = Color.Black;
            Keyboard.KeyRepeat = false;
            Display.WindowCaption = "BooGame - Scroll Demo";
            Joystick.Enabled = true;  // Allow use of the joystick

            // Run the system
            Core.Run();
        }

        // Load the Tile Studio map scripts
        Map foreground = Map.FromFile("BlocksLevel1.map");
        Map background = Map.FromFile("BackGrMap1.map");

        // Constant describing how fast the maps move
        const float acceleration = 80f;

        // Input method (Keyboard, Mouse or Joystick)
        string inputMethod = "Keyboard";

        public ScrollDemo()
        {
            // Add the background and foreground map objects
            Entities.Add(background);
            Entities.Add(foreground);

            foreground.Velocity.X = -acceleration;
            foreground.Velocity.Y = -acceleration;
            background.Velocity.X = foreground.Velocity.X / 2f;
            background.Velocity.Y = foreground.Velocity.Y / 2f;
        }

        public override void MouseMotion(MouseEventArgs args)
        {
            if (inputMethod == "Mouse")
            {
                // Move the maps based on the location of the mouse on the screen
                foreground.Velocity.X = (args.MouseX - Display.Width / 2f) / Display.Width / 2f * acceleration * -10f;
                foreground.Velocity.Y = (args.MouseY - Display.Height / 2f) / Display.Height / 2f * acceleration * -10f;
                background.Velocity.X = foreground.Velocity.X / 2f;
                background.Velocity.Y = foreground.Velocity.Y / 2f;
            }
        }

        public override void JoystickAxisMovement(JoystickEventArgs args)
        {
            if (inputMethod == "Joystick")
            {
                // Move the screen with the joystick movement
                foreground.Velocity.X = -(Joystick.X / acceleration * 10f);
                foreground.Velocity.Y = -(Joystick.Y / acceleration * 10f);

                background.Velocity.X = foreground.Velocity.X / 2f;
                background.Velocity.Y = foreground.Velocity.Y / 2f;
            }
        }

        public override void KeyDown(KeyboardEventArgs args)
        {
            // Change input method
            switch (args.Key)
            {
                case Keys.K: inputMethod = "Keyboard"; break;
                case Keys.J: inputMethod = "Joystick"; break;
                case Keys.M: inputMethod = "Mouse"; break;
                case Keys.Escape: Core.QuitApplication(); break; // quit on hitting escape
            }

            if (inputMethod == "Keyboard")
            {
                // Arrows move the map objects
                switch (args.Key)
                {
                    case Keys.RightArrow:
                        foreground.Velocity.X -= acceleration;
                        background.Velocity.X -= acceleration / 2f;
                        break;
                    case Keys.LeftArrow:
                        foreground.Velocity.X += acceleration;
                        background.Velocity.X += acceleration / 2f;
                        break;
                    case Keys.DownArrow:
                        foreground.Velocity.Y -= acceleration;
                        background.Velocity.Y -= acceleration / 2f;
                        break;
                    case Keys.UpArrow:
                        foreground.Velocity.Y += acceleration;
                        background.Velocity.Y += acceleration / 2f;
                        break;
                }
            }
        }

        public override void Update()
        {
            // Move the map object entities
            base.Update();

            // Make sure the map doesn't go off the side of the screen
            if (foreground.Y > 0 && foreground.Velocity.Y > 0)
            {
                background.Y = foreground.Y = 0;
                background.Velocity.Y = foreground.Velocity.Y = 0f;
            }

            if (foreground.X > 0 && foreground.Velocity.X > 0)
            {
                background.X = foreground.X = 0;
                background.Velocity.X = foreground.Velocity.X = 0f;
            }
            if (foreground.Bottom < Display.Height && foreground.Velocity.Y < 0)
            {
                foreground.Bottom = Display.Height;
                background.Velocity.Y = foreground.Velocity.Y = 0f;
            }
            if (foreground.Right < Display.Width && foreground.Velocity.X < 0)
            {
                foreground.Right = Display.Width;
                background.Velocity.X = foreground.Velocity.X = 0f;
            }

            // Report the FPS
            Display.WindowCaption = "BooGame - Scroll Demo - " + Timer.Fps.ToString("#.0") + " FPS";
        }

        public override void Draw()
        {
            // Since the background is smaller then the rest of the
            // map, we have to tile the whole map.....

            // Draw map tiled to the right
            background.X += background.Width;
            background.Draw();

            // Draw map tiled to the right/down
            background.Y += background.Height;
            background.Draw();

            // Draw map tiled down
            background.X -= background.Width;
            background.Draw();

            // Move tile back to original location
            background.Y -= background.Height;

            // Draw everything else
            base.Draw();

            // Display instructions
            BooGame.Font.Default.Print("K - Use Keyboard\nJ - Use Joystick\nM - Use Mouse", Color.White);
            BooGame.Font.Default.Print(inputMethod, Color.White, Display.Width - 10, Camera.Top, ContentAlignment.TopRight);
        }
    }
}
