Attribute VB_Name = "gleExtrusionAngle"
Option Explicit

''
' * MODULE NAME: ex_angle.c
' *
' * FUNCTION:
' * This module contains code that draws extrusions with angled
' * joins ("angle join style").  It also inserts colors and normals
' * where necessary, if appropriate.
' *
' * HISTORY:
' * written by Linas Vepstas August/September 1991
' * split into multiple compile units, Linas, October 1991
' * added normal vectors Linas, October 1991
' * "code complete" (that is, I'm done), Linas Vepstas, October 1991
' * work around OpenGL's lack of support for concave polys, June 1994
'
'-------------------------------------------------------------------------
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------=
'public sub extrusion_angle_join (ncp&,     ' number of contour points
'                           gleDouble contour()(2),  ' 2D contour
'                           gleDouble cont_normal()(2), ' 2D normal vecs
'                           gleDouble up(3), ' up vector for contour
'                           int npoints,     ' numpoints in poly-line
'                           gleDouble point_array()(3),  ' polyline
'                           float color_array()(3),  ' color of polyline
'                           gleDouble xform_array()(2)(3))  ' 2D contour xforms
Public Sub ExtrusionAngleJoin(gc As gleGC)
Dim i&, j&
Dim inext&, inextnext&
Dim m#(0 To 15)
Dim lng#, lng_seg#
Dim diff#(0 To 3)
Dim bi_0#(0 To 2), bi_1#(0 To 2)  ' bisecting plane
Dim bisector_0#(0 To 2), bisector_1#(0 To 2)   ' bisecting plane
Dim end_point_0#(0 To 2), end_point_1#(0 To 2)
Dim origin#(0 To 2), neg_z#(0 To 2)
Dim yup#(0 To 2)         ' alternate up vector
'
Dim back_loopPtr&  ' contours in 3D
Dim norm_loopPtr& '  double *norm_loop;
'   double *front_normPtr, *back_normPtr, *tmp; ' contour normals in 3D
Dim front_normPtr& '
Dim back_normPtr& '
Dim tmpPtr& ' contour normals in 3D
Dim first_time&
'
Dim m_Contour() As gleVector 'gleAffine
Dim m_Norm() As gleVector
With gc
    ' By definition, the contour passed in has its up vector pointing in
    ' the y direction
    'edx: up is always initialized before entry to 0,1,0
    V3Copyd yup, .up
    
    ' ========== "up" vector sanity check ==========
    UpSanityCheck yup, .npoints, .point_array
    
    ' the origin is at the origin
    origin(0) = 0
    origin(1) = 0
    origin(2) = 0
    
    ' and neg_z is at neg z
    neg_z(0) = 0
    neg_z(1) = 0
    neg_z(2) = 1

    ' ignore all segments of zero length
    i = 1
    inext = i
    FIND_NON_DEGENERATE_POINT inext&, .npoints, lng, diff, .point_array
    lng_seg = lng   ' store for later use

    ' get the bisecting plane
    BISECTING_PLANE3v bi_0, .point_array(0).v, _
                           .point_array(1).v, _
                           .point_array(inext).v
    ' reflect the up vector in the bisecting plane
    V3Reflectd yup, yup, bi_0

    ' malloc the storage we'll need for relaying changed contours to the
    ' drawing routines.
'    mem_anchor =  malloc (2 * 3 * ncp * sizeof(double)
'                      +  2 * 3 * ncp * sizeof(gleDouble));
    'edx: these arrays are split up to avoid confusion
    If .ncp Then
        ReDim m_Contour(0 To 2 * .ncp - 1)
        ReDim m_Norm(0 To 2 * .ncp - 1)
    Else: Debug.Assert 0
    End If
    ' contours
    back_loopPtr = .ncp
    ' norms
    front_normPtr = 0
    back_normPtr = front_normPtr + .ncp
    norm_loopPtr = front_normPtr

   ' may as well get the normals set up now
    If gc.ncnormals Then
        If gc.nxforms = 0 Then
            For j = 0 To .ncp - 1
                m_Norm(j).v(0) = .cont_normal(j).v(0)
                m_Norm(j).v(1) = .cont_normal(j).v(1)
                m_Norm(j).v(2) = 0
            Next
        Else
            For j = 0 To .ncp - 1
'                NORM_XFORM_2X2 m_norm,3*j, _ (&front_normPtr(3*j)),
'                              xform_array(inext-1),
'                              cont_normal (j));
'                front_normPtr(3*j+2) = 0;
'                back_normPtr(3*j+2) = 0;
                NORM_XFORM_2X2 m_Norm(front_normPtr + j).v, _
                              .xform_array(inext - 1), _
                              .cont_normal(j).v
                m_Norm(front_normPtr + j).v(2) = 0
                m_Norm(back_normPtr + j).v(2) = 0
            Next
        End If
    End If

    first_time = True
    ' draw tubing, not doing the first segment
    Do While inext < .npoints - 1
        inextnext = inext
        ' ignore all segments of zero length
        FIND_NON_DEGENERATE_POINT inextnext, .npoints, lng, diff, .point_array
        
        ' get the next bisecting plane
        BISECTING_PLANE3v bi_1, .point_array(i).v, _
                               .point_array(inext).v, _
                              .point_array(inextnext).v

        ' rotate so that z-axis points down v2-v1 axis,
        ' and so that origin is at v1
        uviewpoint_d m, .point_array(i).v, .point_array(inext).v, yup
        glPushMatrix
        glMultMatrixd m(0)

        ' rotate the bisecting planes into the local coordinate system
        MatDotVectord bisector_0, m, bi_0
        MatDotVectord bisector_1, m, bi_1

        neg_z(2) = -lng_seg

        ' draw the tube
        ' --------- START OF TMESH GENERATION --------------
        For j = 0 To .ncp - 1

            ' if there are normals, and there are either affine xforms, OR
            ' * path-edge normals need to be drawn, then compute local
            ' * coordinate system normals.
            If gc.ncnormals Then
                ' set up the back normals. (The front normals we inherit
                ' from previous pass through the loop)
                If gc.nxforms Then
                    ' do up the normal vectors with the inverse transpose
                    NORM_XFORM_2X2 m_Norm(back_normPtr + j).v, _
                                  .xform_array(inext), _
                                  .cont_normal(j).v
                End If

                ' Note that if the xform array is NULL, then normals are
                '* constant, and are set up outside of the loop.
                '
                '  if there are normal vectors, and the style calls for it,
                '  then we want to project the normal vectors into the
                '  bisecting plane. (This style is needed to make toroids, etc.
                ' look good: Without this, segmentation artifacts show up
                '* under lighting.
                If gc.NormStyle And glePATH_EDGE Then
                    ' Hmm, if no affine xforms, then we haven't yet set
                    ' back vector. So do it.
                    If gc.nxforms = 0 Then
                        m_Norm(back_normPtr + j).v(0) = .cont_normal(j).v(0)
                        m_Norm(back_normPtr + j).v(1) = .cont_normal(j).v(1)
                    End If

                    ' now, start with a fresh normal (z component equal to
                    ' zero), project onto bisecting plane (by computing
                    ' perpendicular componenet to bisect vector, and renormalize
                    ' (since projected vector is not of unit length
                    m_Norm(front_normPtr + j).v(2) = 0
                    V3Perpd m_Norm(front_normPtr + j).v, _
                        m_Norm(front_normPtr + j).v, bisector_0
                    V3Normalized m_Norm(front_normPtr + j).v

                    m_Norm(back_normPtr + j).v(2) = 0
                    V3Perpd m_Norm(back_normPtr + j).v, _
                        m_Norm(back_normPtr + j).v, bisector_1
                    V3Normalized m_Norm(back_normPtr + j).v
                End If
            End If

            ' Next, we want to define segments. We find the endpoints of
            '  the segments by intersecting the contour with the bisecting
            '  plane.  If there is no local affine transform, this is easy.
            '
            '  If there is an affine tranform, then we want to remove the
            '  torsional component, so that the intersection points won't
            '  get twisted out of shape.  We do this by applying the
            '  local affine transform to the entire coordinate system.
            If gc.nxforms = 0 Then
                end_point_0(0) = .contour(j).v(0)
                end_point_0(1) = .contour(j).v(1)
                
                end_point_1(0) = .contour(j).v(0)
                end_point_1(1) = .contour(j).v(1)
            Else
                ' transform the contour points with the local xform
                MatDotVectorAd end_point_0, _
                                 .xform_array(inext - 1), .contour(j).v
                MatDotVectorAd end_point_1, _
                                 .xform_array(inext - 1), .contour(j).v
            End If

            end_point_0(2) = 0
            end_point_1(2) = -lng_seg

            ' The two end-points define a line.  Intersect this line
            ' * against the clipping plane defined by the PREVIOUS
            ' * tube segment.
    
            'INNERSECT (&front_loopPtr(3*j)), ' intersection point (returned)
            '           origin,     ' point on intersecting plane
            '           bisector_0,     ' normal vector to plane
            '           end_point_0,    ' point on line
            '           end_point_1);   ' another point on the line
            INNERSECT m_Contour(j).v, _
                    origin, bisector_0, _
                    end_point_0, end_point_1

            ' The two end-points define a line.  Intersect this line
            ' * against the clipping plane defined by the NEXT
            ' * tube segment.

            ' if there's an affine coordinate change, be sure to use it
            If gc.nxforms Then
                ' transform the contour points with the local xform
                MatDotVectorAd end_point_0, _
                             .xform_array(inext), .contour(j).v
                MatDotVectorAd end_point_1, _
                             .xform_array(inext), .contour(j).v
            End If

            INNERSECT m_Contour(back_loopPtr + j).v, _
                    neg_z, bisector_1, _
                    end_point_0, end_point_1

        Next

        ' --------- END OF TMESH GENERATION --------------
        
        ' v^v^v^v^v^v^v^v^v  BEGIN END CAPS v^v^v^v^v^v^v^v^v^v^v^v
        
        ' if end caps are required, draw them. But don't draw any
        ' * but the very first and last caps
        If gc.CapStyle = gleCAPS Then
            If first_time Then
                If gc.ncolors Then
                    glColor3fv .color_array(inext - 1).v(0)
                End If
                first_time = False
                'draw_angle_style_front_cap (.ncp, bisector_0, (gleVector *) front_loopPtr);
                draw_angle_style_front_cap gc, .ncp, bisector_0, m_Contour, 0 'front_loopPtr
            End If
            If (inext = .npoints - 2) Then
                If gc.ncolors Then
                    glColor3fv .color_array(inext).v(0)
                End If
                'draw_angle_style_back_cap .ncp, bisector_1, (gleVector *) back_loopPtr);
                draw_angle_style_back_cap gc, .ncp, bisector_1, m_Contour, back_loopPtr
            End If
        End If
      ' v^v^v^v^v^v^v^v^v  END END CAPS v^v^v^v^v^v^v^v^v^v^v^v

      ' |||||||||||||||||| START SEGMENT DRAW ||||||||||||||||||||
      ' There are six different cases we can have for presence and/or
      ' * absecnce of colors and normals, and for interpretation of
      ' * normals. The blechy set of nested if statements below
      ' * branch to each of the six cases
      If (gc.nxforms = 0) And (gc.NormStyle And glePATH_EDGE = 0) Then
            If gc.ncolors = 0 Then
                If gc.ncnormals = 0 Then
                    draw_segment_plain gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, inext, lng_seg
                ElseIf gc.NormStyle And gleFACET Then
                    draw_segment_facet_n gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, norm_loopPtr, inext, lng_seg
                Else
                    draw_segment_edge_n gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, norm_loopPtr, inext, lng_seg
                End If
            Else
                If gc.ncnormals = 0 Then
                    draw_segment_color gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                   .color_array(inext - 1).v, _
                                   .color_array(inext).v, inext, lng_seg
            ElseIf gc.NormStyle And gleFACET Then
                draw_segment_c_and_facet_n gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, norm_loopPtr, _
                                    .color_array(inext - 1).v, _
                                    .color_array(inext).v, inext, lng_seg
            Else
                draw_segment_c_and_edge_n gc, .ncp, _
                                    m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, norm_loopPtr, _
                                    .color_array(inext - 1).v, _
                                   .color_array(inext).v, inext, lng_seg
             End If
          End If
      Else
         If gc.ncolors = 0 Then
            If gc.ncnormals = 0 Then
               draw_segment_plain gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, inext, lng_seg
            ElseIf gc.NormStyle And gleFACET Then
               draw_binorm_segment_facet_n gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, front_normPtr, _
                                    m_Norm, back_normPtr, _
                                    inext, lng_seg
            Else
               draw_binorm_segment_edge_n gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, front_normPtr, _
                                    m_Norm, back_normPtr, _
                                    inext, lng_seg
            End If
         Else
            If gc.ncnormals = 0 Then
               draw_segment_color gc, .ncp, m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    .color_array(inext - 1).v, _
                                   .color_array(inext).v, inext, lng_seg
            ElseIf gc.NormStyle And gleFACET Then
               draw_binorm_segment_c_and_facet_n gc, .ncp, _
                                    m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, front_normPtr, _
                                    m_Norm, back_normPtr, _
                                    .color_array(inext - 1).v, _
                                    .color_array(inext).v, inext, lng_seg
            Else
               draw_binorm_segment_c_and_edge_n gc, .ncp, _
                                    m_Contour, 0, _
                                    m_Contour, back_loopPtr, _
                                    m_Norm, front_normPtr, _
                                    m_Norm, back_normPtr, _
                                    .color_array(inext - 1).v, _
                                    .color_array(inext).v, inext, lng_seg
             End If
          End If
      End If
      ' |||||||||||||||||| END SEGMENT DRAW ||||||||||||||||||||

      ' pop this matrix, do the next set
      glPopMatrix

      ' bump everything to the next vertex
      lng_seg = lng
      i = inext
      inext = inextnext
      V3Copyd bi_0, bi_1

      ' trade norm loops
      tmpPtr = front_normPtr
      front_normPtr = back_normPtr
      back_normPtr = tmpPtr

      ' reflect the up vector in the bisecting plane
      V3Reflectd yup, yup, bi_0
   Loop
End With
End Sub


'-------------------------------------------------------------------------==
''
' * Algorithmic trivia:
' *
' * There is a slight bit of trivia which the super-duper exacto coder
' * needs to know about the code in this module. It is this:
' *
' * This module attempts to correctly treat contour normal vectors
' * by applying the inverse transpose of the 2D contour affine
' * transformation to the 2D contour normals.  This is perfectly correct,
' * when applied to the "raw" join style.  However, if the affine transform
' * has a strong rotational component, AND the join style is angle or
' * cut, then the normal vectors would continue to rotate as the
' * intersect point is extrapolated.
' *
' * The extrapolation of the inverse-transpose matrix to the intersection
' * point is not done.  This would appear to be overkill for most
' * situations.  The viewer might possibly detect an artifact of the
' * failure to do this correction IF all three of the following criteria
' * were met:
' * 1) The affine xform has a strong rotational component,
' * 2) The angle between two succesive segments is sharp (greater than 15 or
' *    30 degrees).
' * 3) The join style is angle or cut.
' *
' * However, I beleive that it is highly unlikely that the viewer will
' * detect any artifacts. The reason I beleive this is that a strong
' * rotational component will twist a segment so strongly that the more
' * visible artifact will be that a segment is composed of triangle strips.
' * As the user attempts to minimize the tesselation artifacts by shortening
' * segments, then the rotational component will decrease in proportion,
' * and the lighting artifact will fall away.
' *
' * To summarize, there is a slight inexactness in this code.  The author
' * of the code beleives that this inexactness results in miniscule
' * errors in every situation.
' *
' * Linas Vepstas March 1993
'
'
'-------------------------------------------------------------------------==

'public sub draw_angle_style_front_cap (ncp&,   ' number of contour points
'                           gleDouble bi(3),     ' biscetor
'                           gleDouble point_array()(3))  ' polyline
Public Sub draw_angle_style_front_cap(gc As gleGC, ncp&, bi#(), point_array() As gleVector, paIndex&)
Dim j&
Dim tObj& ' GLUtriangulatorObj *;

   If (bi(2) < 0) Then
      V3Scaled bi, -1, bi
   End If
    N3F gc, bi
    tObj = gluNewTess
    gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
    gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
    gluTessCallback tObj, GLU_END, AddressOf gleEnd
    gluTessBeginPolygon tObj, 0
        gluTessBeginContour tObj

        For j = 0 To ncp - 1
            gluTessVertex tObj, point_array(paIndex + j).v(0), _
                point_array(paIndex + j).v(0)
        Next
        gluTessEndContour tObj
    gluTessEndPolygon tObj
    gluDeleteTess tObj
End Sub

'-------------------------------------------------------------------------==
'public sub draw_angle_style_back_cap (ncp&,    ' number of contour points
'                           gleDouble bi(3),     ' biscetor
'                           gleDouble point_array()(3))  ' polyline
Public Sub draw_angle_style_back_cap(gc As gleGC, ncp&, bi#(), point_array() As gleVector, paIndex&)
Dim j&
Dim tObj&
   If (bi(2) > 0) Then
      V3Scaled bi, -1, bi
   End If
   N3F gc, bi

    tObj = gluNewTess
    gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
    gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
    gluTessCallback tObj, GLU_END, AddressOf gleEnd
    gluTessBeginPolygon tObj, 0
        gluTessBeginContour tObj
        For j = ncp - 1 To 0 Step -1
            gluTessVertex tObj, point_array(paIndex + j).v(0), _
                point_array(paIndex + j).v(0)
        Next
        gluTessEndContour tObj
    gluTessEndPolygon tObj
    gluDeleteTess tObj
End Sub


