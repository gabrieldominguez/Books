// Pong.boo
// A Pong implementation using BooGame
// To run, drag ontop of BooPlayer, or run BooPlayer BooPlayerPong.boo
// By: Rob Loach (http://www.robloach.net)

import BooGame
import System.Drawing

public class Pong:
   static font = BooGame.Font(FontFamily.GenericMonospace, 30, FontStyle.Bold)
   static player1score = 0
   static player2score = 0
   
   static player1 = RectangleF(20, Display.Height / 2f - 25,10,100)
   static player2 = RectangleF(Display.Width - 30, Display.Height / 2f - 25, 10, 100)
   static ball = Circle(Display.Width / 2f, Display.Height / 2f, 15)
   
   static ballSpeed = Vector(250, -350)
   static originalBallSpeed = ballSpeed.Length
   static playerSpeed = 300
   
   static def Draw():
      // Draw the score and players and the ball
      font.Print(player1score + ' : ' + player2score, Color.White, Display.Width / 2f, 0f, ContentAlignment.TopCenter)
      Paint.FilledRectangle(player1, Color.White)
      Paint.FilledRectangle(player2, Color.White)
      Paint.FilledCircle(ball, Color.White)

   static def Update():
      // Move the ball
      ball.X += ballSpeed.X * Timer.DeltaSeconds
      ball.Y += ballSpeed.Y * Timer.DeltaSeconds
      
      // Move the players
      if Keyboard.IsKeyDown(Keys.UpArrow):
         player1.Y -= playerSpeed * Timer.DeltaSeconds
      elif Keyboard.IsKeyDown(Keys.DownArrow):
         player1.Y += playerSpeed * Timer.DeltaSeconds
         
      if ballSpeed.X > 0:
         if ball.Y < player2.Y + player2.Height / 2f:
            player2.Y -= playerSpeed * Timer.DeltaSeconds
         elif ball.Y > player2.Y + player2.Height / 2f:
            player2.Y += playerSpeed * Timer.DeltaSeconds
      
      // Bound players and ball on screen
      if player1.Y < 0:
         player1.Y = 0
         player1Speed = 0
      if player1.Y + player1.Height > Display.Height:
         player1.Y = Display.Height - player1.Height
         player1Speed = 0
      if player2.Y < 0:
         player2.Y = 0
         player2Speed = 0
      if player2.Y + player2.Height > Display.Height:
         player2.Y = Display.Height - player2.Height
         player2Speed = 0
      
      if ball.Top <= 0 and ballSpeed.Y < 0:
         ballSpeed = ballSpeed.Reflection(90)
      if ball.Bottom >= Display.Height and ballSpeed.Y > 0:
         ballSpeed = ballSpeed.Reflection(90)
      if ball.Right < 0:
         player1score++
         ball.Location = PointF(Display.Width / 2f, Display.Height / 2f)
         ballSpeed.X *= -1
         ballSpeed.Length = originalBallSpeed
      elif ball.Left > Display.Width:
         player2score++
         ball.Location = PointF(Display.Width / 2f, Display.Height / 2f)
         ballSpeed.X *= -1
         ballSpeed.Length = originalBallSpeed
         
      // Check collisions
      if ballSpeed.X > 0:
         if ball.Rectangle.IntersectsWith(player2):
            ballSpeed = ballSpeed.Reflection(0)
            ballSpeed.Length += 15f
      elif ballSpeed.X < 0:
         if ball.Rectangle.IntersectsWith(player1):
            ballSpeed = ballSpeed.Reflection(0)
            ballSpeed.Length += 15f
   
   static def KeyDown(obj, e as KeyboardEventArgs):
      if e.Key == Keys.Escape:
         Core.QuitApplication()

   static def Main():
      Display.WindowCaption = 'BooGame - Pong!'
      Display.ClearColor = Color.Black
      Core.Draw += Draw
      Core.Update += Update
      Keyboard.KeyDown += KeyDown 