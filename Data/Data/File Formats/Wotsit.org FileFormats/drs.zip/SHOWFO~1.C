#include <stdio.h>
#include <stdlib.h>
#include <vga.h>
#include "wpfonts.h"
#include "device.h"

void
print_names(font_file* ff)
{
  int i;
  for(i=0;i<WP_NUMFONTS;i++)
  {
    printf("nr: % 2d name: %s \n",i,
	   &ff->file_names[ff->file_index[i].offset+1]);
  }
}

void
print_info(font_struct* fs)
{
  printf("nr: % 2d #chars: %d\n",fs->number,fs->desc.numchars);
}

extern device dev_graphic;
device* output=&dev_graphic;

int
main()
{
  font_file* ff;
  font_struct* fs;
  int i,j;
  int x,y;
  char c=0,buf[60];

  ff=wp_init_fonts(WP_FONTFILE);
  if (ff==NULL) goto no_file;

  dev_init(output);
  output->init(output);

  for(i=0;i<WP_NUMFONTS;i++)
  {
    output->clear(output);

    /* print the font nr */
    fs=wp_load_font(ff,0);
    sprintf(buf,"font nr %d",i);
    x=0;y=output->height-700;
    x+=wp_draw_string(fs,output,x,y,buf);
    wp_dispose_font(fs);

    /* show the font */
    fs=wp_load_font(ff,i);

    if (fs==NULL) goto no_font;
    if (fs->desc.type!=WP_OUTLINE)
      goto no_font;

    
    x=0;
    y=output->height-1500;

    for(j=0;j<fs->desc.numchars;j++)
    {
      x+=wp_draw_char(fs,output,x,y,j);
      if (x>output->width-512)
      {
	x=0;
	y-=1024;
      }
      if (y<0)
      {
	c=output->getch(output);
	if (c=='q') break;
	output->clear(output);
	y=output->width-1500;
      }
    }
    if (c!='q')
      c=output->getch(output);
  no_font:
    wp_dispose_font(fs);
    if (c=='q') break;
  }
 no_file:
  wp_exit_fonts(ff);
  output->exit(output);
  return 0;
}
