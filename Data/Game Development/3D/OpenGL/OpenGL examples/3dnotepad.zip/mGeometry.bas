Attribute VB_Name = "mGeometry"
Option Explicit
Dim QObj& 'GLUquadricObj


Public Sub TessPlane(Width!, Height!, tessx&, tessy&, _
                        Optional texx! = 1, Optional texy! = 1)
Dim i&, j&, x!, y!, stepx!, stepy!, x2!
Dim texstepx!, texstepy!
Dim tx!, ty!, tx2!
glBegin GL_QUAD_STRIP
    glNormal3f 0, 0, 1
    x = -Width / 2
    y = -Height / 2
    stepx = Width / tessx
    stepy = Height / tessy
    texstepx = texx / tessx
    texstepy = texy / tessy
    'draw strips from bottom left going up
    For i = 2 To tessx
        glTexCoord2f tx, ty
        glVertex2f x, y
        glTexCoord2f tx + texstepx, ty
        glVertex2f x + stepx, y
        For j = 2 To tessy
            y = y + stepy
            ty = ty + texstepy
            glTexCoord2f tx, ty
            glVertex2f x, y
            glTexCoord2f tx + texstepx, ty
            glVertex2f x + stepx, y
        Next
        y = Height / 2
        ty = texy
        glTexCoord2f tx, ty
        glVertex2f x, y
        glTexCoord2f tx + texstepx, ty
        glVertex2f x + stepx, y
        x = x + stepx
        y = -y
        glEnd
        glBegin GL_QUAD_STRIP
    Next
    'final strip
    x2 = Width / 2
    tx2 = texx
    glTexCoord2f tx, ty
    glVertex2f x, y
    glTexCoord2f tx2, ty
    glVertex2f x2, y
    For j = 2 To tessy
        y = y + stepy
        ty = ty + texstepy
        glTexCoord2f tx, ty
        glVertex2f x, y
        glTexCoord2f tx2, ty
        glVertex2f x2, y
    Next
    y = Height / 2
    ty = texy
    glTexCoord2f tx, ty
    glVertex2f x, y
    glTexCoord2f tx2, ty
    glVertex2f x2, y
glEnd
End Sub

'VRML syntax
Public Sub Box(ByVal w!, ByVal h!, ByVal depth!)
Dim n(0 To 5) As V3F
Dim faces(0 To 5) As V4I
Dim v(0 To 7) As V3F
Dim i&
    FillArray3f n, _
        -1, 0, 0, 0, 1, 0, 1, 0, 0, _
        0, -1, 0, 0, 0, 1, 0, 0, -1
    FillArray4i faces, _
          0, 1, 2, 3, 3, 2, 6, 7, 7, 6, 5, 4, _
        4, 5, 1, 0, 5, 6, 2, 1, 7, 4, 0, 3
    v(0).v(0) = -w / 2 'x
    v(0).v(1) = -h / 2 'y
    v(0).v(2) = -depth / 2 'z
    v(1).v(0) = -w / 2
    v(1).v(1) = -h / 2
    v(1).v(2) = depth / 2
    v(2).v(0) = -w / 2
    v(2).v(1) = h / 2
    v(2).v(2) = depth / 2
    v(3).v(0) = -w / 2
    v(3).v(1) = h / 2
    v(3).v(2) = -depth / 2
    v(4).v(0) = w / 2
    v(4).v(1) = -h / 2
    v(4).v(2) = -depth / 2
    v(5).v(0) = w / 2
    v(5).v(1) = -h / 2
    v(5).v(2) = depth / 2
    v(6).v(0) = w / 2
    v(6).v(1) = h / 2
    v(6).v(2) = depth / 2
    v(7).v(0) = w / 2
    v(7).v(1) = h / 2
    v(7).v(2) = -depth / 2
    For i = 5 To 0 Step -1
        glBegin GL_QUADS
            glNormal3fv n(i).v(0)
            glVertex3fv v(faces(i).v(0)).v(0)
            glVertex3fv v(faces(i).v(1)).v(0)
            glVertex3fv v(faces(i).v(2)).v(0)
            glVertex3fv v(faces(i).v(3)).v(0)
        glEnd
    Next
End Sub

'If we ever changed/used the texture or orientation state
'of QObj, we 'd need to change it to the defaults here
' with gluQuadricTexture and/or gluQuadricOrientation. */
'-----------------------------------------------------------------
Public Sub Sphere(ByVal radius!, slices, stacks)
    gluSphere QObj, radius, slices, stacks
End Sub

Public Sub Disk(ByVal InnerRadius!, ByVal OuterRadius!, slices&, Loops&)
    gluDisk QObj, InnerRadius, OuterRadius, slices, Loops
End Sub

Public Sub Cone(ByVal BaseRadius!, ByVal Height!, Bottom As Boolean, slices&, stacks&)
    gluCylinder QObj, BaseRadius, 0, Height, slices, stacks
    If Bottom Then
    glPushMatrix
        glRotatef 180, 1, 0, 0
        Disk 0, BaseRadius, slices, stacks
    glPopMatrix
    End If
End Sub

Public Sub Cylinder(ByVal BaseRadius!, ByVal TopRadius!, ByVal Height!, Optional Top = True, Optional Bottom = True, Optional slices& = 16, _
    Optional stacks& = 16)
    gluCylinder QObj, BaseRadius, TopRadius, Height, slices, stacks
    If Top Then
    glPushMatrix
        glRotatef 180, 1, 0, 0
        Disk 0, BaseRadius, slices, stacks
    glPopMatrix
    End If
    If Bottom Then
    glPushMatrix
        glTranslatef 0, 0, Height
        Disk 0, BaseRadius, slices, stacks
    glPopMatrix
    End If
End Sub

Public Sub Torus(ByVal InnerRadius!, ByVal OuterRadius!, ByVal nsides&, ByVal Rings&)
Dim i&, j&
Dim theta!, phi!, theta1!
Dim cosTheta!, sinTheta!
Dim cosTheta1!, sinTheta1!
Dim ringDelta!, sideDelta!
Dim cosPhi!, sinPhi!, dist!
  
    ringDelta = 2 * PI / Rings
    sideDelta = 2 * PI / nsides
    
    theta = 0
    cosTheta = 1
    sinTheta = 0
    For i = Rings - 1 To 0 Step -1
        theta1 = theta + ringDelta
        cosTheta1 = Cos(theta1)
        sinTheta1 = Sin(theta1)
        glBegin GL_QUAD_STRIP
        phi = 0
        For j = nsides To 0 Step -1
            
            phi = phi + sideDelta
            cosPhi = Cos(phi)
            sinPhi = Sin(phi)
            dist = InnerRadius + OuterRadius * cosPhi
            
            glNormal3f cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi
            glVertex3f cosTheta1 * dist, -sinTheta1 * dist, OuterRadius * sinPhi
            glNormal3f cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi
            glVertex3f cosTheta * dist, -sinTheta * dist, OuterRadius * sinPhi
        Next
        glEnd
    theta = theta1
    cosTheta = cosTheta1
    sinTheta = sinTheta1
    Next
End Sub


