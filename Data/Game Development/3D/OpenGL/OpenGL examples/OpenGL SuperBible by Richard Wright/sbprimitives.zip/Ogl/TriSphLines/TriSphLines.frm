VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmDisplay 
   Caption         =   "Example of Lines, Triangle and Spheres"
   ClientHeight    =   6000
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   ScaleHeight     =   400
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   400
   StartUpPosition =   3  'Windows Default
   Begin MSComDlg.CommonDialog cdlPrint 
      Left            =   3480
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFile_Print 
         Caption         =   "&Print"
      End
   End
   Begin VB.Menu mnuEffects 
      Caption         =   "&Effects"
      Begin VB.Menu mnuFlat_Shading 
         Caption         =   "&Flat Shading"
      End
      Begin VB.Menu mnuSmooth_Shading 
         Caption         =   "&Smooth Shading"
      End
   End
   Begin VB.Menu mnuAngle 
      Caption         =   "&Angle"
      Visible         =   0   'False
      Begin VB.Menu mnuAngle_Translate 
         Caption         =   "&Translate"
      End
      Begin VB.Menu mnuAngle_Rotate 
         Caption         =   "&Rotate"
      End
      Begin VB.Menu mnuEffects_TR 
         Caption         =   "T&ranslate and Rotate"
      End
      Begin VB.Menu mnuEffects_RT 
         Caption         =   "R&otate and Translate"
      End
   End
End
Attribute VB_Name = "frmDisplay"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
  Select Case KeyCode
    Case vbKeyUp
      xRot = xRot - 5#
    Case vbKeyDown
      xRot = xRot + 5#
    Case vbKeyLeft
      yRot = yRot - 5#
    Case vbKeyRight
      yRot = yRot + 5#
  End Select
  If xRot > 356# Then xRot = 0#
  If xRot < -1# Then xRot = 355#
  If yRot > 356# Then yRot = 0#
  If yRot < -1# Then yRot = 355#
  Call RenderScene
End Sub


Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If Button = vbRightButton Then
    frmDisplay.PopupMenu mnuAngle
  End If
End Sub


Private Sub Form_Paint()
        'MsgBox "Expose"
        Call RenderScene
End Sub

Private Sub Form_Resize()
    Dim WinAW As GLfloat, WinAH As GLfloat
    Dim WinW As GLfloat, WinH As GLfloat
    
    glViewport 0#, 0#, frmDisplay.ScaleWidth, frmDisplay.ScaleHeight
    
    WinAW = frmDisplay.ScaleWidth
    WinAH = frmDisplay.ScaleHeight
    
    If WinAW <= 0 Then WinAW = 1#
    If WinAH <= 0 Then WinAH = 1#
    
    If WinAW <= WinAH Then
      WinH = 400# * WinAH / WinAW
      WinW = 400#
    Else
      WinW = 400# * WinAW / WinAH
      WinH = 400#
    End If
    
    glMatrixMode mmProjection
    glLoadIdentity
    glOrtho -WinW / 2#, WinW / 2#, -WinH / 2#, WinH / 2#, 150#, -150#
    glMatrixMode mmModelView
    glLoadIdentity
   
    Call RenderScene
        
End Sub

Private Sub Form_Unload(Cancel As Integer)
    bAppRunning = False
End Sub

Private Sub mnuEffects_Cull_Click()
    If bCull = False Then
      bCull = True
      mnuEffects_Cull.Checked = True
    Else
      bCull = False
      mnuEffects_Cull.Checked = False
    End If
    Call RenderScene
End Sub

Private Sub mnuEffects_Depth_Click()
    If bDepth = False Then
      bDepth = True
      mnuEffects_Depth.Checked = True
    Else
      bDepth = False
      mnuEffects_Depth.Checked = False
    End If
    Call RenderScene
End Sub

Private Sub mnuEffects_Outline_Click()
    If bOutLine = False Then
      bOutLine = True
      mnuEffects_Outline.Checked = True
    Else
      bOutLine = False
      mnuEffects_Outline.Checked = False
    End If
    glClear clrColorBufferBit + clrDepthBufferBit
    Call RenderScene
End Sub

Private Sub mnuFile_Print_Click()
  'cdlPrint.ShowPrinter
  'If (cdlPrint.flags And cdlCancel) = cdlCancel Then
  '  MsgBox "cancel"
  'Else
  '  MsgBox "OK"
  'End If
  frmDisplay.PrintForm
End Sub

Private Sub mnuFlat_Shading_Click()
  mnuFlat_Shading.Checked = True
  mnuSmooth_Shading.Checked = False
  iFlatSmooth = 1
  Call RenderScene
End Sub

Private Sub mnuSmooth_Shading_Click()
  mnuFlat_Shading.Checked = False
  mnuSmooth_Shading.Checked = True
  iFlatSmooth = 2
  Call RenderScene
End Sub


