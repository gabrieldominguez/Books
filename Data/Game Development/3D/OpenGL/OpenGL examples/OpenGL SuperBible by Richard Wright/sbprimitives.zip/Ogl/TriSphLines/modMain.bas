Attribute VB_Name = "mMain"
Public Sub main()

    dBallRadius = 10#
    
    quadSphere = gluNewQuadric()
    gluQuadricOrientation quadSphere, qoOutside
    gluQuadricDrawStyle quadSphere, qdsFill
    gluQuadricNormals quadSphere, qnSmooth
    
    BaseRad = 2#
    TopRad = 2#
    Height = 100#
    quadCylinder = gluNewQuadric
    gluQuadricOrientation quadCylinder, qoOutside
    gluQuadricDrawStyle quadCylinder, qdsFill
    gluQuadricNormals quadCylinder, qnFlat
    
    bCull = False
    bDepth = False
    bOutLine = False
    iFlatSmooth = 1
    frmDisplay.mnuFlat_Shading.Checked = True
    frmDisplay.mnuSmooth_Shading.Checked = False
  
    Load frmDisplay
    StartOpenGL frmDisplay.hDC
    frmDisplay.Show
    Call setuprc
    
    
    bAppRunning = True
    While bAppRunning = True
        Call RenderScene
        DoEvents
    Wend
    
    StopOpenGL
    
    Unload frmDisplay
    Set frmDisplay = Nothing
    
End Sub

