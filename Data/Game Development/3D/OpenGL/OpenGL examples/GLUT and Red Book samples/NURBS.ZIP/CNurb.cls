VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CNurb"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'FUNCTION: Main class of the app.
'   - this was ported mostly for testing the gluNurb decs in the type lib
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
Dim theNurbs& ' As GLUnurbsObj
Dim sknots!(0 To S_NUMKNOTS - 1)
Dim glutnots!(0 To T_NUMKNOTS - 1)
'Point ctlpoints[S_NUMPOINTS][T_NUMPOINTS] = {
Dim ctlpoints(0 To (S_NUMPOINTS * T_NUMPOINTS - 1)) As Point4f

Private Sub Class_Initialize()
rotX = 40
rotY = 40
FillPoint4f ctlpoints(0), 4, 2, 2, 1
FillPoint4f ctlpoints(1), 4, 1.6, 2.5, 1
FillPoint4f ctlpoints(2), 4, 2, 3, 1
'
FillPoint4f ctlpoints(3), 5, 4, 2, 1
FillPoint4f ctlpoints(4), 5, 4, 2.5, 1
FillPoint4f ctlpoints(5), 5, 4, 3, 1
'
FillPoint4f ctlpoints(6), 6, 5, 2, 1
FillPoint4f ctlpoints(7), 6, 5, 2.5, 1
FillPoint4f ctlpoints(8), 6, 5, 3, 1
'
FillPoint4f ctlpoints(9), SQRT_TWO * 6, SQRT_TWO * 6, SQRT_TWO * 2, SQRT_TWO
FillPoint4f ctlpoints(10), SQRT_TWO * 6, SQRT_TWO * 6, SQRT_TWO * 2.5, SQRT_TWO
FillPoint4f ctlpoints(11), SQRT_TWO * 6, SQRT_TWO * 6, SQRT_TWO * 3, SQRT_TWO
'
FillPoint4f ctlpoints(12), 5.2, 6.7, 2, 1
FillPoint4f ctlpoints(13), 5.2, 6.7, 2.5, 1
FillPoint4f ctlpoints(14), 5.2, 6.7, 3, 1
'
FillPoint4f ctlpoints(15), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 2, SQRT_TWO
FillPoint4f ctlpoints(16), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 2.5, SQRT_TWO
FillPoint4f ctlpoints(17), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 3, SQRT_TWO
'
FillPoint4f ctlpoints(18), 4, 5.2, 2, 1
FillPoint4f ctlpoints(19), 4, 4.6, 2.5, 1
FillPoint4f ctlpoints(20), 4, 5.2, 3, 1
'
FillPoint4f ctlpoints(21), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 2, SQRT_TWO
FillPoint4f ctlpoints(22), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 2.5, SQRT_TWO
FillPoint4f ctlpoints(23), SQRT_TWO * 4, SQRT_TWO * 6, SQRT_TWO * 3, SQRT_TWO
'
FillPoint4f ctlpoints(24), 2.8, 6.7, 2, 1
FillPoint4f ctlpoints(25), 2.8, 6.7, 2.5, 1
FillPoint4f ctlpoints(26), 2.8, 6.7, 3, 1
'
FillPoint4f ctlpoints(27), SQRT_TWO * 2, SQRT_TWO * 6, SQRT_TWO * 2, SQRT_TWO
FillPoint4f ctlpoints(28), SQRT_TWO * 2, SQRT_TWO * 6, SQRT_TWO * 2.5, SQRT_TWO
FillPoint4f ctlpoints(29), SQRT_TWO * 2, SQRT_TWO * 6, SQRT_TWO * 3, SQRT_TWO
'
FillPoint4f ctlpoints(30), 2, 5, 2, 1
FillPoint4f ctlpoints(31), 2, 5, 2.5, 1
FillPoint4f ctlpoints(32), 2, 5, 3, 1
'
FillPoint4f ctlpoints(33), 3, 4, 2, 1
FillPoint4f ctlpoints(34), 3, 4, 2.5, 1
FillPoint4f ctlpoints(35), 3, 4, 3, 1
'
FillPoint4f ctlpoints(36), 4, 2, 2, 1
FillPoint4f ctlpoints(37), 4, 1.6, 2.5, 1
FillPoint4f ctlpoints(38), 4, 2, 3, 1
End Sub

Private Sub Class_Terminate()
'
End Sub

Public Sub InitGL()
    With gCtl.Camera
        .FarPlane = 10
        .FieldOfView = 45
        .NearPlane = 0.01
        .SetEyePos 7, 4, 10
        .SetTargetPos 4.5, 4.5, 2.5
    End With
    gCtl.Ex.FillArrayf sknots, -1, -1, -1, 0, 1, 2, 3, 4, 4, 5, 6, 7, 8, 9, 9, 9
    gCtl.Ex.FillArrayf glutnots, 1, 1, 1, 2, 2, 2
    theNurbs = gluNewNurbsRenderer
    gluNurbsCallback theNurbs, GLU_ERROR, AddressOf ErrorCallback
    gluNurbsProperty theNurbs, GLU_SAMPLING_TOLERANCE, 15
    gluNurbsProperty theNurbs, GLU_DISPLAY_MODE, GLU_OUTLINE_PATCH
    ExpectedError = GLU_INVALID_ENUM
    '
    'don't know what heis trying to set, it crashes VB
    'gluNurbsProperty theNurbs, &HFFFFFFFF, 15
    'gluNurbsProperty theNurbs, , 15
    'ExpectedError = GLU_NURBS_ERROR13
    'gluEndSurface theNurbs
    'ExpectedError = 0
    glColor3f 0.8, 0.8, 1
    glDisable glcLighting
    '
    'debug test of the tlb
    Dim f!
    gluGetNurbsProperty theNurbs, npSamplingTolerance, f
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
'    glViewport 0, 0, width, height
'    glMatrixMode GL_PROJECTION
'    glLoadIdentity
'    glFrustum -2, 2, -2, 2, 0.8, 10
'    gluLookAt 7, 4.5, 4, 4.5, 4.5, 2.5, 6, -3, 2
'    glMatrixMode GL_MODELVIEW
End Function

Public Sub Draw()
    'glClear GL_COLOR_BUFFER_BIT
    glPushMatrix
        glTranslatef 4, 4.5, 2.5
        glRotatef rotY, 1, 0, 0
        glRotatef rotX, 0, 1, 0
        glTranslatef -4, -4.5, -2.5
        gluBeginSurface theNurbs
        gluNurbsSurface theNurbs, S_NUMKNOTS, sknots(0), T_NUMKNOTS, glutnots(0), _
            4 * T_NUMPOINTS, 4, ctlpoints(0).pts(0), S_ORDER, _
            T_ORDER, GL_MAP2_VERTEX_4
        gluEndSurface theNurbs
    glPopMatrix
End Sub


