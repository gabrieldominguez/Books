VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES: To use fonts, you must create them with the fonttexture
'generator available on this site. Get panoramas from
'www.wasabisoft.com.
'This sample is a prototype, an attempt to
'get a sense of what kinds of issues an app like this must deal with.
'As it turned out, the result is pretty silly and completely useless.
'A real 3d notepad needs do something completely different, but I'm yet
'real clear exactly what that is. Your opinions are welcomed.
'
'I posted this code anyway because it has a useful Background class
'and because I would like to hear from others who are interested in
'the general problem of 3d documents.
'--------------------------------------------------------------------
Public Enum n3dEditModes
    n3dSelect = 0
    n3dTranslate = 1
    n3dRotate = 2
    n3dScale = 3
End Enum
Public Enum n3dViewModes
    n3dZoom = 0
    n3dArcRotate = 1
    n3dPan = 2
End Enum
Dim m_EditMode As n3dEditModes
Dim m_ViewMode As n3dViewModes
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
Dim m_FarPlane!
Dim m_bMoving As Boolean
Dim m_Rot!
Const DEG = 57.2958
Const TURNINC = PI / 60

Private Sub Class_Initialize()
    '
End Sub

Private Sub Class_Terminate()
    Set Manipulator = Nothing
    Set Areas = Nothing
    Set Images = Nothing
    Set Fonts = Nothing
    Set Panorama = Nothing
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
    'm_Grids = True
    m_FarPlane = 1000
    m_ViewMode = n3dArcRotate
    m_Rot = PI / 2
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
'    With gCtl.Lights
'        .SetAmbient 1, 1, 1
'        .TwoSide = True
'    End With
    CheckError
    With gCtl.Camera
        .FarPlane = 3000
        .NearPlane = 1
        .FieldOfView = 45
        .SetEyePos 0, 0, 10
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetSpecular 0.6, 0.8, 0.8
        .SpecExp = 120
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .Axis = glxXYZ
        .Pick = True
    End With
    QuadObj = gluNewQuadric
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    Set Areas = New CAreas
    Set Images = New CImages
    Set Fonts = New CFontTextures
    Set Manipulator = New CManipulator
    Fonts.Init
    Set Panorama = New CBackground
    CheckError
End Sub

Public Sub Draw()
    With gCtl
        .Trackball.Update
        If m_Grids Then
            .DrawGrids
            'm_Mat.SetMaterial
            'gluSphere QuadObj, 0.1, 16, 16
        End If
    End With
    Panorama.Draw
    Areas.Draw
    CheckError
End Sub

Public Function Reshape(Width&, Height&) As Boolean
    Reshape = True
    Manipulator.Resize Width, Height
End Function

Public Sub KeyDown(KeyCode%, Shift%)
Const SPEED = 0.1
Dim IncX!, IncY!, IncZ!
Dim ex!, ey!, ez!
    Select Case (KeyCode)
    Case vbKeyLeft, vbKeyRight, vbKeyUp, vbKeyDown
        With gCtl.Camera
        .GetEyePos ex, ey, ez
        Select Case (KeyCode)
        Case vbKeyLeft:
            If Shift Then
                m_Rot = m_Rot + TURNINC
                'calculate new target
                IncX = ex + 10 * Cos(m_Rot)
                IncZ = ez - 10 * Sin(m_Rot)
                .GetTargetPos ex, ey, ez
                .SetTargetPos IncX, ey, IncZ
                gCtl.Render
                Exit Sub
            Else: IncX = -SPEED
            End If
        Case vbKeyRight:
            If Shift Then
                m_Rot = m_Rot - TURNINC
                'calculate new target
                IncX = ex + 10 * Cos(m_Rot)
                IncZ = ez - 10 * Sin(m_Rot)
                .GetTargetPos ex, ey, ez
                .SetTargetPos IncX, ey, IncZ
                gCtl.Render
                Exit Sub
            Else:  IncX = SPEED
            End If
        Case vbKeyUp:
            If Shift Then
                IncY = SPEED
            Else: IncZ = -SPEED
            End If
        Case vbKeyDown:
            If Shift Then
                IncY = -SPEED
            Else: IncZ = SPEED
            End If
        End Select
        .SetEyePos ex + IncX, ey + IncY, ez + IncZ
        .GetTargetPos ex, ey, ez
        .SetTargetPos ex + IncX, ey + IncY, ez + IncZ
        End With
        gCtl.Render
    Case 27: '  Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    m_MouseX = X
    m_MouseY = Y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        m_StartX = X
        m_StartY = Y
        m_bMoving = True
        Manipulator.MouseDown X, Y
    Else
        Select Case m_ViewMode
        Case n3dZoom
            SetCursor "zoom"
            gCtl.Pick = False
        Case n3dPan
            SetCursor "pan"
            gCtl.Pick = False
        Case n3dArcRotate
            SetCursor "arcrotate"
            gCtl.Pick = False
        Case Else: Debug.Assert 0
        End Select
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        Select Case m_EditMode
        Case n3dSelect:
        Case n3dTranslate, n3dRotate, n3dScale
            Manipulator.MouseMove X, Y
            gCtl.Render
        'Case Else: Debug.Assert 0
        End Select
        'Manipulator.MouseMove X, Y
    Else
        Select Case m_ViewMode
        Case n3dZoom:
            Zoom X, Y
        Case n3dArcRotate
        Case n3dPan:
            Pan X, Y
        End Select
        gCtl.Render
    End If
    m_MouseX = X
    m_MouseY = Y
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    m_bMoving = False
    If Button = 2 Then
        Select Case m_EditMode
        Case n3dSelect
            SetCursor "select"
            gCtl.Pick = True
        Case n3dTranslate
            SetCursor "move"
            gCtl.Pick = True
        Case n3dRotate
            SetCursor "rotate"
            gCtl.Pick = True
        Case n3dScale
            SetCursor "scale"
            gCtl.Pick = True
        End Select
    End If
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, z#, z1!
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    'Z = 1.79769313486232E308
    z = 10000000000# ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                Debug.Print " z1 = " & items(ptr)
                z1 = items(ptr)
                ptr = ptr + 1
            '3.z2
                Debug.Print " z2 = " & items(ptr)
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < z Then
                        z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        Manipulator.MouseDown m_StartX, m_StartY
    End If
    Areas.Pick Picked
End Sub

'-----------------------------------------------------------------
Public Property Get ViewMode() As n3dViewModes
    ViewMode = m_ViewMode
End Property

Public Property Let ViewMode(ByVal NewValue As n3dViewModes)
    m_ViewMode = NewValue
    If m_ViewMode = n3dArcRotate Then
        gCtl.MouseRotate = True
    Else
        gCtl.MouseRotate = False
    End If
End Property

'-----------------------------------------------------------------
Public Property Get EditMode() As n3dEditModes
    EditMode = m_EditMode
End Property

Public Property Let EditMode(ByVal NewValue As n3dEditModes)
    m_EditMode = NewValue
    Select Case m_EditMode
    Case n3dSelect
        SetCursor "select"
        gCtl.Pick = True
    Case n3dTranslate
        SetCursor "move"
        gCtl.Pick = True
    Case n3dRotate
        SetCursor "rotate"
        gCtl.Pick = True
    Case n3dScale
        SetCursor "scale"
        gCtl.Pick = True
    Case Else: Debug.Assert 0
    End Select
    With Manipulator
    Select Case NewValue
    Case n3dSelect: .EditMode = mmNone
    Case n3dTranslate: .EditMode = mmTranslate
    Case n3dRotate: .EditMode = mmRotate
    Case n3dScale: .EditMode = mmScale
    Case n3dZoom, n3dPan, n3dArcRotate: .EditMode = mmNone
    Case Else: Debug.Assert 0
    End Select
    End With
End Property

Public Property Get Grids() As Boolean
    Grids = m_Grids
End Property

Public Property Let Grids(ByVal NewValue As Boolean)
    m_Grids = NewValue
End Property

'-----------------------------------------------------------------
'VIEW
'-----------------------------------------------------------------
'---------------------------------------------------------
Public Sub Pan(X!, Y!)
Dim IncX!, IncY!, nx!, ny!
Dim ex!, ey!, ez!
Const SPEED = 0.01
With gCtl.Camera
    IncX = m_MouseX - X
    IncY = m_MouseY - Y
    .GetEyePos ex, ey, ez
    ny = -IncY * SPEED
    nx = IncX * SPEED
    .SetEyePos ex + nx, ey + ny, ez
    .GetTargetPos ex, ey, ez
    .SetTargetPos ex + nx, ey + ny, ez
End With
End Sub

'---------------------------------------------------------
'move eye and target alng z axis
'----------------------------------------------------------------------------
Public Sub Zoom(X!, Y!)
Dim ex!, ey!, ez!, z!
Const SPEED = 0.01
'
With gCtl.Camera
    .GetEyePos ex, ey, ez
    'zoom speed adjustment
    z = ez + ((Y - m_MouseY) * SPEED)
    .SetEyePos ex, ey, z
    .GetTargetPos ex, ey, ez
    ez = z - 10
    .SetTargetPos ex, ey, ez
End With
End Sub

Public Sub SetCursor(s$)
Select Case s
Case "move"
    gCtl.MousePointer = 5
Case "rotate"
    gCtl.MousePointer = 99
    Set gCtl.MouseIcon = frmMain.CursorRotate.Picture
Case "scale"
    gCtl.MousePointer = 99
    Set gCtl.MouseIcon = frmMain.CursorScale.Picture
Case "zoom"
    gCtl.MousePointer = 99
    Set gCtl.MouseIcon = frmMain.CursorZoom.Picture
Case "arcrotate"
    gCtl.MousePointer = 99
    Set gCtl.MouseIcon = frmMain.CursorArcRotate.Picture
Case "pan"
    gCtl.MousePointer = 99
    Set gCtl.MouseIcon = frmMain.CursorPan.Picture
Case Else
    gCtl.MousePointer = 0
End Select
End Sub


Public Sub ResetView()
    With gCtl.Camera
        .SetEyePos 0, 0, 10
        .SetTargetPos 0, 0, 0
    End With
    gCtl.Trackball.Reset
    m_Rot = PI / 2
    gCtl.Render
End Sub

Public Sub OnNewDoc()
    Areas.Clear
    ResetView
End Sub

Public Function Save(fn&, Path$) As Boolean
    If Areas.Save(fn) Then
        If Panorama.Save(fn, Path$) Then
            If optCopyImages Then
                Images.Save Path
            End If
            Save = True
        End If
    End If
End Function

Public Function Load(fn&, Path$) As Boolean
    Areas.Clear
    Panorama.Clear
    If Areas.Load(fn, Path) Then
        Load = Panorama.Load(fn, Path)
    End If
End Function

