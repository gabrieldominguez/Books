Attribute VB_Name = "mExtrusions"
Option Explicit

Public Sub InitExtrusions()

End Sub

Public Sub DrawExtrusions()

End Sub


