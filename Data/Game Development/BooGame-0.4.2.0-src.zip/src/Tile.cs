/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;
using System.Drawing;
using Tao.OpenGl;

namespace BooGame
{
	/// <summary>
	/// A single tile on a tileset.
	/// </summary>
	[Serializable]
	public class Tile
	{
        public Tile()
        {
            m_TileX = m_TileY = 0;
            m_TileSet = null;
        }
		public Tile(TileSet tileset, int tileX, int tileY)
		{
			m_TileX = tileX;
			m_TileY = tileY;
			m_TileSet = tileset;
		}
        public Tile(Texture texture)
        {
            m_TileSet = new TileSet(texture);
            m_TileX = 0;
            m_TileY = 0;
        }
		public Tile(TileSet tileset)
		{
			m_TileSet = tileset;
		}
		public Tile(string filename)
		{
			m_TileSet = new TileSet(filename);
		}

		/// <summary>
		/// Copy constructor
		/// </summary>
		/// <param name="tile"></param>
		public Tile(Tile tile)
		{
			m_MapCode = tile.MapCode;
			m_TileX = tile.TileX;
			m_TileY = tile.TileY;
			m_TileSet = tile.TileSet;
		}
		private TileBounds m_Bounds = TileBounds.None;
        /// <summary>
        /// Gets and sets the bounds of the tile.
        /// </summary>
		public TileBounds Bounds
		{
			get
			{
				return m_Bounds;
			}
			set
			{
				m_Bounds = value;
			}
		}

        public bool LeftBoundry
        {
            get
            {
                return (Bounds & TileBounds.Left) == TileBounds.Left;
            }
        }

        public bool BottomBoundry
        {
            get
            {
                return (Bounds & TileBounds.Bottom) == TileBounds.Bottom;
            }
        }

        public bool RightBoundry
        {
            get
            {
                return (Bounds & TileBounds.Right) == TileBounds.Right;
            }
        }

        public bool TopBoundry
        {
            get
            {
                return (Bounds & TileBounds.Top) == TileBounds.Top;
            }
        }

		private int m_TileX = 0;
		private int m_TileY = 0;
		private TileSet m_TileSet;

        /// <summary>
        /// Gets and sets the current X coordinate of the tile on the tile set.
        /// </summary>
        public virtual int TileX
		{
			get{ return m_TileX; }
			set{ m_TileX = value; }
        }

        /// <summary>
        /// Gets and sets the current Y coordinate of the tile on the tile set.
        /// </summary>
        public virtual int TileY
		{
			get{ return m_TileY; }
			set{ m_TileY = value; }
		}
        
        /// <summary>
        /// Gets and sets the tile set where this tile is residing on.
        /// </summary>
		public virtual TileSet TileSet
		{
			get{ return m_TileSet; }
			set{ m_TileSet = value; }
		}

		private byte m_MapCode = 0;
        /// <summary>
        /// Gets and sets the map code of the tile.
        /// </summary>
		public byte MapCode
		{
			get
			{
				return m_MapCode;
			}
			set
			{
				m_MapCode = value;
			}
		}

        /// <summary>
        /// Draws the tile on the screen.
        /// </summary>
        internal virtual void QuickDraw()
		{
            if(m_TileSet != null)
                m_TileSet.QuickDraw(TileX, TileY);
        }

        /// <summary>
        /// Draws the tile on the given coordinates on the screen.
        /// </summary>
        /// <param name="x">The x location on the screen.</param>
        /// <param name="y">The y location on the screen.</param>
        internal virtual void QuickDraw(float x, float y)
        {
            if (m_TileSet != null)
                m_TileSet.QuickDraw(TileX, TileY, x, y);
        }

        /// <summary>
        /// Draws the tile on the given coordinates on the screen.
        /// </summary>
        /// <param name="x">The x location on the screen.</param>
        /// <param name="y">The y location on the screen.</param>
        /// <param name="width">The destination width of the tile on the screen.</param>
        /// <param name="height">The destination height of the tile on the screen.</param>
        internal virtual void QuickDraw(float x, float y, float width, float height)
        {
            if (m_TileSet != null)
                m_TileSet.QuickDraw(TileX, TileY, x, y, width, height);
        }

        /// <summary>
        /// Updates the tile.
        /// </summary>
		public virtual void Update()
		{
		}

        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY, float rotation, float scaleX, float scaleY, ColorF tint)
        {
            if (m_TileSet == null)
                return;
            if (tint.A <= 0)
                return;
            Gl.glPushMatrix();
            Camera.ApplyMatrix();
            Gl.glTranslatef(x, y, 0f);
            Gl.glRotatef(rotation, 0f, 0f, 1f);
            Gl.glScalef(scaleX, scaleY, 0f);
            Gl.glTranslatef(-hotspotX, -hotspotY, 0f);
            Gl.glColor4f(tint.R, tint.G, tint.B, tint.A);
            m_TileSet.QuickDraw(m_TileX, m_TileY);
            Gl.glEnd();
            Gl.glPopMatrix();
        }
        public void Draw(RectangleF dest, PointF hotspot, float rotation, float scaleX, float scaleY, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, hotspot.X, hotspot.Y, rotation, scaleX, scaleY, tint);
        }
        public void Draw(RectangleF dest, PointF hotspot, float rotation, float scale, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, hotspot.X, hotspot.Y, rotation, scale, scale, tint);
        }
        public void Draw(RectangleF dest, PointF hotspot, float rotation, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, hotspot.X, hotspot.Y, rotation, 1f, 1f, tint);
        }
        public void Draw(RectangleF dest, PointF hotspot, float rotation)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, hotspot.X, hotspot.Y, rotation, 1f, 1f, Color.White);
        }
        public void Draw(RectangleF dest, PointF hotspot)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, hotspot.X, hotspot.Y, 0f, 1f, 1f, Color.White);
        }
        public void Draw(RectangleF dest, float rotation)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, 0f, 0f, rotation, 1f, 1f, Color.White);
        }
        public void Draw(RectangleF dest)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(RectangleF dest, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, 0f, 0f, 0f, 1f, 1f, tint);
        }
        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY, float rotation, float scale, ColorF tint)
        {
            Draw(x, y, width, height, hotspotX, hotspotY, rotation, scale, scale, tint);
        }
        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY, float rotation, ColorF tint)
        {
            Draw(x, y, width, height, hotspotX, hotspotY, rotation, 1f, 1f, tint);
        }
        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY, float rotation, float scale)
        {
            Draw(x, y, width, height, hotspotX, hotspotY, rotation, scale, scale, Color.White);
        }
        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY, float rotation)
        {
            Draw(x, y, width, height, hotspotX, hotspotY, rotation, 1f, 1f, Color.White);
        }
        public void Draw(float x, float y, float width, float height, float hotspotX, float hotspotY)
        {
            Draw(x, y, width, height, hotspotX, hotspotY, 0f, 1f, 1f, Color.White);
        }
        public void Draw(float x, float y, float width, float height, PointF hotspot)
        {
            Draw(x, y, width, height, hotspot.X, hotspot.Y, 0f, 1f, 1f, Color.White);
        }
        public void Draw(float x, float y, float width, float height)
        {
            Draw(x, y, width, height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(float x, float y, float width, float height, ColorF tint)
        {
            Draw(x, y, width, height, 0f, 0f, 0f, 1f, 1f, tint);
        }
        public void Draw(float x, float y)
        {
            Draw(x, y, m_TileSet.TileWidth, m_TileSet.TileHeight, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(float x, float y, ColorF tint)
        {
            Draw(x, y, m_TileSet.TileWidth, m_TileSet.TileHeight, 0f, 0f, 0f, 1f, 1f, tint);
        }
        public void Draw()
        {
            Draw(0f, 0f, m_TileSet.TileWidth, m_TileSet.TileHeight, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(PointF destination, Size size)
        {
            Draw(destination.X, destination.Y, size.Width, size.Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(PointF destination)
        {
            Draw(destination.X, destination.Y, m_TileSet.TileWidth, m_TileSet.TileHeight, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        public void Draw(PointF destination, Size size, ColorF tint)
        {
            Draw(destination.X, destination.Y, size.Width, size.Height, 0f, 0f, 0f, 1f, 1f, tint);
        }
        public void Draw(PointF destination, ColorF tint)
        {
            Draw(destination.X, destination.Y, m_TileSet.TileWidth, m_TileSet.TileHeight, 0f, 0f, 0f, 1f, 1f, tint);
        }
    }


    #region TileCollection
    /// <summary>
    /// A collection of Tiles.
    /// </summary>
    [Serializable]
    public class TileCollection : CollectionBase, ICollection
    {

        public TileCollection()
            : base()
        {
        }

        public TileCollection(TileCollection tiles)
        {
            this.Add(tiles);
        }

        public TileCollection(string filename)
        {
            this.Add(filename);
        }

        public TileCollection(string filename, int tileWidth, int tileHeight)
        {
            this.Add(new TileSet(filename, tileWidth, tileHeight));
        }

        public TileCollection(Texture texture)
        {
            this.Add(texture);
        }
        public TileCollection(TileSet tileset)
        {
            this.Add(tileset);
        }
        public TileCollection(TileSet tileset, int row)
        {
            this.Add(tileset, row);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public Tile this[int index]
        {
            get
            {
                return ((Tile)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }
        public int Add(TileSet tileset)
        {
            for (int y = 0; y < tileset.TilesTall; y++)
            {
                for (int x = 0; x < tileset.TilesWide; x++)
                {
                    this.Add(new Tile(tileset, x, y));
                }
            }
            return this.Count;
        }
        public void RemoveAt(int indexStart, int length)
        {
            for (int i = indexStart + length; i > indexStart; i--)
                List.RemoveAt(i);
        }
        public int Add(TileSet tileset, int row)
        {
            for (int x = 0; x < tileset.TilesWide; x++)
            {
                this.Add(new Tile(tileset, x, row));
            }
            return this.Count;
        }
        public int Add(string filename, int tileWidth, int tileHeight)
        {
            return this.Add(new TileSet(filename, tileWidth, tileHeight));
        }

        public int Add(Texture texture)
        {
            return (List.Add(new Tile(new TileSet(texture))));
        }
        public int Add(Tile tile)
        {
            return (List.Add(tile));
        }

        public int Add(string filename)
        {
            return (List.Add(new Tile(new TileSet(filename))));
        }

        public int Add(TileCollection tileCollection)
        {
            for (int i = 0; i < tileCollection.Count; i++)
                this.Add(tileCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Tile tile)
        {
            List.Insert(index, tile);
        }

        public void Remove(Tile tile)
        {
            List.Remove(tile);
        }

        public int IndexOf(Tile tile)
        {
            return (List.IndexOf(tile));
        }

        public bool Contains(Tile tile)
        {
            return (List.Contains(tile));
        }

        public virtual void CopyTo(Tile[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }
    }
    #endregion TileCollection
}
