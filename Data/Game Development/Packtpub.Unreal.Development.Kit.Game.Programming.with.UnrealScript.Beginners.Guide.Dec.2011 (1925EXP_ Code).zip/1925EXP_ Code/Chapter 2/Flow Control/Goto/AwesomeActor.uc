class AwesomeActor extends Actor
    placeable;

function PostBeginPlay()
{
    `log("PostBeginPlay");

    goto EndOfFunction;

    `log("This will not log");

EndOfFunction:
    `log("This will log.");
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
