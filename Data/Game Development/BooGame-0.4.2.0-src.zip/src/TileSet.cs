/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;

using Tao.OpenGl;

namespace BooGame
{
	/// <summary>
	/// A tileset is just a texture with a set tile width and height for indexing of multiple tiles on the single texture.
	/// </summary>
	[Serializable]
	public class TileSet
	{
		private Texture m_Texture;
		private int m_TileWidth = -1;
		private int m_TileHeight = -1;

		public TileSet(Texture texture)
		{
			m_Texture = texture;
			m_TileWidth = texture.Width;
			m_TileHeight = texture.Height;
		}

		public TileSet(Texture texture, int tileWidth, int tileHeight)
		{
			m_Texture = texture;
			m_TileWidth = tileWidth;
			m_TileHeight = tileHeight;
		}
		public TileSet(string filename)
		{
			m_Texture = new Texture(filename);
			m_TileWidth = m_Texture.Width;
			m_TileHeight = m_Texture.Height;
		}

		public TileSet(string filename, int tileWidth, int tileHeight)
		{
			m_Texture = new Texture(filename);
			m_TileWidth = tileWidth;
			m_TileHeight = tileHeight;
		}

        /// <summary>
        /// Gets and sets the width of the tiles.
        /// </summary>
		public int TileWidth
		{
			get{ return m_TileWidth; }
			set{ m_TileWidth = value; }
		}

        /// <summary>
        /// Gets and sets the height of the tiles.
        /// </summary>
		public int TileHeight
		{
			get{ return m_TileHeight; }
			set{ m_TileHeight = value; }
		}

        /// <summary>
        /// Gets and sets the texture associated with this tile set.
        /// </summary>
		public Texture Texture
		{
			get{ return m_Texture; }
			set{ m_Texture = value; }
		}

        /// <summary>
        /// Gets and sets how many tiles fit horizontally on the texture.
        /// </summary>
		public int TilesWide
		{
			get
			{
				return m_Texture.Width / m_TileWidth;
			}
			set
			{
				m_TileWidth = m_Texture.Width / value;
			}
		}

        /// <summary>
        /// Gets and sets how many tiles fit vertically on the texture.
        /// </summary>
		public int TilesTall
		{
			get
			{
				return m_Texture.Height / m_TileHeight;
			}
			set
			{
				m_TileHeight = m_Texture.Height / value;
			}
		}

        /// <summary>
        /// Gets the tile at the given tile indexes on the texture.
        /// </summary>
        /// <param name="x">The tile x coordinate of the desired tile.</param>
        /// <param name="y">The tile y coordinate of the desired tile.</param>
        /// <returns>A new tile generated from the tile set.</returns>
		public Tile this[int x, int y]
		{
			get
			{
				return new Tile(this, x, y);
			}
		}

        /// <summary>
        /// Gets the tile at the given index.
        /// </summary>
        /// <param name="index">The index of the tile.</param>
        /// <returns>A new tile generated from the tile set.</returns>
		public Tile this[int index]
		{
			get
			{
				int tilesWide = TilesWide;
				int x = index % tilesWide;
				return new Tile(this, x, (index - x) / tilesWide);
			}
		}

        internal void QuickDraw(int tileX, int tileY)
		{
            QuickDraw(tileX, tileY, 0f, 0f, m_TileWidth, m_TileHeight);
		}

        internal void QuickDraw(int tileX, int tileY, float x, float y, float width, float height)
		{
			this.Texture.Bind();
			float tx = (float)(tileX * m_TileWidth) / (float)m_Texture.TextureWidth;
			float ty = (float)(tileY * m_TileHeight) / (float)m_Texture.TextureHeight;

			float twidth = (float)m_TileWidth / (float)m_Texture.TextureWidth;
			float theight = (float)m_TileHeight / (float)m_Texture.TextureHeight;

            Gl.glBegin(Gl.GL_QUADS);

            Gl.glTexCoord2f(tx, 1f - ty);
            Gl.glVertex2f(x, y);

            Gl.glTexCoord2f(tx + twidth, 1f - ty);
            Gl.glVertex2f(x + width, y);

            Gl.glTexCoord2f(tx + twidth, 1f - ty - theight);
            Gl.glVertex2f(x + width, y + height);

            Gl.glTexCoord2f(tx, 1f - ty - theight);
            Gl.glVertex2f(x, y + height);

			Gl.glEnd();
		}
        internal void QuickDraw(int tileX, int tileY, float x, float y)
		{
            QuickDraw(tileX, tileY, x, y, m_TileWidth, m_TileHeight);
		}

	}
}
