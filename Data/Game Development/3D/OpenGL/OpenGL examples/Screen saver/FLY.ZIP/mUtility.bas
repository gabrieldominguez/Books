Attribute VB_Name = "mUtility"
Option Explicit

'routines from 'Common', the common library used by the gl screen savers

Public Sub ss_matrixIdent(mat As MATRIX)
    mat.m(0, 0) = 1
    mat.m(0, 1) = 0
    mat.m(0, 2) = 0
    mat.m(0, 3) = 0

    mat.m(1, 0) = 0
    mat.m(1, 1) = 1
    mat.m(1, 2) = 0
    mat.m(1, 3) = 0

    mat.m(2, 0) = 0
    mat.m(2, 1) = 0
    mat.m(2, 2) = 1
    mat.m(2, 3) = 0

    mat.m(3, 0) = 0
    mat.m(3, 1) = 0
    mat.m(3, 2) = 0
    mat.m(3, 3) = 1
End Sub

Public Sub ss_xformPoint(ptOut!(), ptIn!(), mat As MATRIX)
Dim X#, Y#, Z#
    X = (ptIn(0) * mat.m(0, 0)) + (ptIn(1) * mat.m(0, 1)) + _
        (ptIn(2) * mat.m(0, 2)) + mat.m(0, 3)
    Y = (ptIn(0) * mat.m(1, 0)) + (ptIn(1) * mat.m(1, 1)) + _
        (ptIn(2) * mat.m(1, 2)) + mat.m(1, 3)
    Z = (ptIn(0) * mat.m(2, 0)) + (ptIn(1) * mat.m(2, 1)) + _
        (ptIn(2) * mat.m(2, 2)) + mat.m(2, 3)
    ptOut(0) = X
    ptOut(1) = Y
    ptOut(2) = Z
End Sub


Public Sub ss_xformNorm(ptOut!(), ptIn!(), mat As MATRIX)
Dim X#, Y#, Z#, lng#
    X = (ptIn(0) * mat.m(0, 0)) + (ptIn(1) * mat.m(0, 1)) + _
        (ptIn(2) * mat.m(0, 2))
    Y = (ptIn(0) * mat.m(1, 0)) + (ptIn(1) * mat.m(1, 1)) + _
        (ptIn(2) * mat.m(1, 2))
    Z = (ptIn(0) * mat.m(2, 0)) + (ptIn(1) * mat.m(2, 1)) + _
        (ptIn(2) * mat.m(2, 2))
    lng = (X * X) + (Y * Y) + (Z * Z)
    If (lng >= ZERO_EPS) Then
        lng = 1 / Sqr(lng)
    Else
        lng = 1
    End If
    ptOut(0) = X * lng
    ptOut(1) = Y * lng
    ptOut(2) = Z * lng
End Sub


Public Sub ss_matrixRotate(m As MATRIX, xTheta#, yTheta#, zTheta#)
Dim xScale!, yScale!, zScale!, sinX!, cosX!
Dim sinY!, cosY!, sinZ!, cosZ!
    xScale = m.m(0, 0)
    yScale = m.m(1, 1)
    zScale = m.m(2, 2)
    sinX = Sin(xTheta)
    cosX = Cos(xTheta)
    sinY = Sin(yTheta)
    cosY = Cos(yTheta)
    sinZ = Sin(zTheta)
    cosZ = Cos(zTheta)

    m.m(0, 0) = ((cosZ * cosY) * xScale)
    m.m(0, 1) = ((cosZ * -sinY * -sinX + sinZ * cosX) * yScale)
    m.m(0, 2) = ((cosZ * -sinY * cosX + sinZ * sinX) * zScale)

    m.m(1, 0) = (-sinZ * cosY * xScale)
    m.m(1, 1) = ((-sinZ * -sinY * -sinX + cosZ * cosX) * yScale)
    m.m(1, 2) = ((-sinZ * -sinY * cosX + cosZ * sinX) * zScale)

    m.m(2, 0) = (sinY * xScale)
    m.m(2, 1) = (cosY * -sinX * yScale)
    m.m(2, 2) = (cosY * cosX * zScale)
End Sub

'in counterclockwise order: p2,p1,p3
Public Sub CalcNorm(norm!(), p1x!, p1y!, p1z!, _
                             p2x!, p2y!, p2z!, _
                             p3x!, p3y!, p3z!)
Dim crossX!, crossY!, crossZ!
Dim abX!, abY!, abZ!
Dim acX!, acY!, acZ!
Dim sqrLength!
Dim invLength!

    abX = p2x - p1x '      ' calculate p2 - p1
    abY = p2y - p1y
    abZ = p2z - p1z

    acX = p3x - p1x '      ' calculate p3 - p1
    acY = p3y - p1y
    acZ = p3z - p1z

    crossX = (abY * acZ) - (abZ * acY) '   ' get cross product
    crossY = (abZ * acX) - (abX * acZ) '   ' (p2 - p1) X (p3 - p1)
    crossZ = (abX * acY) - (abY * acX)

    sqrLength = (crossX * crossX) + (crossY * crossY) + _
                 (crossZ * crossZ)

    If (sqrLength > ZERO_EPS) Then
        invLength = (1# / Sqr(sqrLength))
    Else
        invLength = 1
    End If

    norm(0) = crossX * invLength
    norm(1) = crossY * invLength
    norm(2) = crossZ * invLength
End Sub

Public Sub NormalizeNorm(n!())
Dim lng!
    lng = (n(0) * n(0)) + (n(1) * n(1)) + (n(2) * n(2))
    If (lng > ZERO_EPS) Then
        lng = (1 / Sqr(lng))
    Else
        lng = 1
        n(0) = n(0) * lng
        n(1) = n(1) * lng
        n(2) = n(2) * lng
    End If
End Sub



