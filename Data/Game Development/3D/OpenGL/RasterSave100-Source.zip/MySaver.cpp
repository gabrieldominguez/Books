#include <math.h>
#include <stdio.h>

#include "MySaver.h"

//-----------------------------------------------------------------------------

// Disable spurious VC6 warnings about floating point truncation
#ifdef  _MSC_VER
#pragma warning (disable:4305 4244)
#endif//_MSC_VER

//-----------------------------------------------------------------------------

const float
    DegRad = 3.141592654 / 180.0;	// degrees to radians

// Various constants that control the screen saver effects
//
const float
    V_RASTER_JITTER_AMP  = 0.1,     // vertical jitter amplitude
    V_RASTER_JITTER_RATE = 100.0,   // vertical jitter rate
    V_RASTER_JITTER_ROT  = 0.5,     // strength of rotation jitter
    RASTER_FADE_AMP      = 0.05,    // amplitude of raster fade effect (0..1)
    RASTER_FADE_RATE     = 0.5;     // raster fade cycle rate

// Texture list IDs - would be preferable to use bind texture, but
// that isn't necessarily supported on all cards/drivers.
//
enum {
    TEX_RASTER  = 100,  // raster texture map
    TEX_NUMBER,			// blurry number texture
    TEX_CODE,			// program code texture
    TEX_SNOW,			// snow texture
    TEX_CRTSNAP,		// blurry CRT images
    TEX_KANA			// japanese script
};

// Display list IDs
//
enum {
	LIST_SPHERE = 200	// sphere list base (there are three)
};

//-----------------------------------------------------------------------------

// registry keys & values
#define REG_KEY_APPLICATION "SOFTWARE\\Crema\\RasterSaver"
#define REG_VAL_INSTALL_DIR "InstallDir"

// fallback path (used only if we failed to read from registry - which should
// hopefully never happen unless the installer messed up)
#define FALLBACK_PATH       "C:\\Program Files\\Crema\\RasterSaver"

//-----------------------------------------------------------------------------

/**
 * Constructor
 */
MySaver::MySaver() {
	_bRasters = true;
	_bSnow    = true;
}

//-----------------------------------------------------------------------------

/**
 * Destructor
 */
/*virtual*/ MySaver::~MySaver() {
}

//-----------------------------------------------------------------------------

/**
 * Called when saver starts
 */
void MySaver::OnCreate() {
	//-- get installation path from registry
	
	HKEY appKey;
	bool gotPath = false;

	if (RegOpenKeyEx(
		HKEY_LOCAL_MACHINE, REG_KEY_APPLICATION, 0, KEY_READ, &appKey
	) == ERROR_SUCCESS) {
		// managed to open application registry key

		// read install directory path
		DWORD dwType, dwSize=1024;
		BYTE pBuff[1024];
		if ( (RegQueryValueExA(appKey, REG_VAL_INSTALL_DIR, NULL, &dwType,
			pBuff, &dwSize) == ERROR_SUCCESS) && (dwType == REG_SZ) ) {
			// convert null terminated character string to STL string, and append '\'
			_Path = string((char*)pBuff) + '\\';
			gotPath = true;
		}

		RegCloseKey(appKey);
	}

	// if we failed to read path from registry, assume typical
	// installation directory as fallback
	if (!gotPath) _Path = FALLBACK_PATH;

	// Set timer interval for refresh to 60Hz
	// (may not achieve this on all cards)
	SetTimerInterval(1000/60);

	// Load textures and models
	SetupTextures();
    SetupModels();

	// Setup OpenGL state
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_CULL_FACE);
}//OnCreate

//-----------------------------------------------------------------------------

// destroy a display list
static void ZapList(GLuint l) {
	// actually, deleting a null list is harmless, but we may as well check
	if (glIsList(l)) glDeleteLists(l,1);
}//ZapList

/**
 * Called when saver stops.
 */
void MySaver::OnDestroy() {
	// clean up display lists
	for (int n=0;n<3;n++)
		ZapList(LIST_SPHERE+n);

	// clean up texture lists
	ZapList(TEX_RASTER);
	ZapList(TEX_NUMBER);
    ZapList(TEX_CODE);
    ZapList(TEX_SNOW);
    ZapList(TEX_CRTSNAP);
    ZapList(TEX_KANA);

	// free models
	for (n=0;n<4;n++)
		_MBuild[n].Free();
}//OnDestroy

//-----------------------------------------------------------------------------

/**
 * Called when OpenGL redraw occurs
 */
void MySaver::OnPaint() {
	// Current time (seconds)
    float Time = (float)Ticks()/1000.0;

    // Width and height of OpenGL window
    int
        width  = Width(),
        height = Height();

    // Ensure height != 0 to avoid divide by zero on w/h aspect calcs.
    if (!height) height++;

    // Keep track of relative time into scene, and switch scenes as required
    static float tStart = -1;
    static int   scene  = 0;
    if (tStart < 0) {
        tStart = Time;
        scene++;
    }
    float TimeRel = Time-tStart;

    // Draw the current scene

    bool done=false;
    switch (scene%3) {
    case 0: done=Scene1(TimeRel, width, height); break;
    case 1: done=Scene2(TimeRel, width, height); break;
    case 2: done=Scene3(TimeRel, width, height); break;
	// add groovy new scenes here :)
    }
    // Request for scene change..
    if (done) tStart=-1;

    // Swap the display buffers
    SwapBuffers();
}//OnPaint

/**
 * Called on timer events
 */
void MySaver::OnTimer() {
	// refresh the display
	Repaint();
}//OnTimer

/**
 * Called when window is resized
 */
void MySaver::OnResize(int width, int height) {
	// ensure OpenGL viewport fills window
	glViewport(0,0,width,height);
}//OnResize

//-----------------------------------------------------------------------------

// Draw a bar at (x,y) of size (Width x Height)
static void myBar (float x, float y, float Width, float Height) {
    glRectf(x,y,x+Width,y+Height);
}

//-----------------------------------------------------------------------------

// Draw a sphere with specified Radius, Slices and Stacks. The Wire parameter
// can be used to draw a wireframe sphere
//
static void mySphere (float Radius, int Slices, int Stacks, bool Wire=false) {
	// something changed, create on display list
	GLUquadricObj *q = gluNewQuadric();
		if (Wire) gluQuadricDrawStyle(q, GLU_LINE);
		gluSphere(q,Radius,Slices,Stacks);
	gluDeleteQuadric(q);
}//mySphere

//-----------------------------------------------------------------------------

// Draw numeric string, using blurry number font
// Appears at (x,y), with specified size 's', valid chars are: '0123456789:'
static void myNumString (const char *str, float x, float y, float s) {
    const float ts=1.0/11.0;    // 11 chars across texture width
    float w=s*0.9, h=s;
    glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_LIGHTING);
        glCallList(TEX_NUMBER);
        for (int n=0; str[n]; n++) {
            // idx= 0..9 for digit, 10 for colon, -1 for anything else
            int idx = isdigit(str[n])?str[n]-48:(str[n]==':')?10:-1;
            if (idx >= 0) { // is it a drawable char?
                float l,r;
                l=ts*idx;
                r=l+ts-0.008;
                glPushMatrix();
                    glTranslatef(x+n*w*1.1,y,0);
                    glBegin(GL_QUADS);
                        glTexCoord2f(r,0);
                        glVertex2f(w,0);
                        glTexCoord2f(r,1);
                        glVertex2f(w,h);
                        glTexCoord2f(l,1);
                        glVertex2f(0,h);
                        glTexCoord2f(l,0);
                        glVertex2f(0,0);
                    glEnd();
                glPopMatrix();
            }
        }
    glPopAttrib();
}

//---------------------------------------------------------------------------

// Draw a block of 'code' at (x,y), with size (w*h) that can be scrolled
// vertically according to the 'scroll' parameter
void MySaver::DrawCode (float x, float y, float w, float h, float scroll) {
    glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_LIGHTING);
        glCallList(TEX_CODE);

        glPushMatrix();
            glTranslatef(x,y,0);
            glBegin(GL_QUADS);
                glTexCoord2f(1,0+scroll);
                glVertex2f(w,0);
                glTexCoord2f(1,1+scroll);
                glVertex2f(w,h);
                glTexCoord2f(0,1+scroll);
                glVertex2f(0,h);
                glTexCoord2f(0,0+scroll);
                glVertex2f(0,0);
            glEnd();
        glPopMatrix();
    glPopAttrib();
}

//---------------------------------------------------------------------------

// Draw kana string (kana) at (x,y), with height (h) - width scaled to
// match aspect.
//
void MySaver::DrawKana (float x, float y, float h, int kana) {
    const int numKana=4;
    kana%=numKana;  // take modulo no.of kana strings available
    float
        w  =h  *(float)numKana,
        vs =1.0/(float)numKana,
        u  =vs*kana,
        v  =u+vs;
    glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_LIGHTING);
        glCallList(TEX_KANA);

        glPushMatrix();
            glTranslatef(x,y,0);
            glBegin(GL_QUADS);
                glTexCoord2f(1,u);
                glVertex2f(w,0);
                glTexCoord2f(1,v);
                glVertex2f(w,h);
                glTexCoord2f(0,v);
                glVertex2f(0,h);
                glTexCoord2f(0,u);
                glVertex2f(0,0);
            glEnd();
        glPopMatrix();
    glPopAttrib();
}//kana

//---------------------------------------------------------------------------

// Draw (num) horizontal Bar Graphs at (x,y) with bar dimensions (w,h)
void MySaver::DrawBars(float x, float y, float w, float h, int num)
{
    float a = 2.0*(float)timeGetTime()/1000.0, len,y1,y2;

    for (int n=0; n<num; n++) {
        len = w*(0.8*(1.0+sin(a+0.3*n))*(1.0+cos(2.0*a+3.7*n))/2.0 + 0.2);
        y1  = y+h*n;
        y2  = y1+h*0.8;
        glRectf(x,y1,x+len,y2);
    }
}//DrawTimecode

//---------------------------------------------------------------------------

// Draw Timecode
void MySaver::DrawTimecode(int Width, int Height)
{
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE);

        {
            int ms = timeGetTime();
            int mn=(ms/60000)%60,se=(ms/1000)%60,fr=(ms/20)%50;
            char str[64];
            float cw=32.0*Width/800.0, space=0.2*cw;
            sprintf(str,"%02d:%02d:%02d", mn,se,fr);
            myNumString(str, Width-strlen(str)*cw-space,space,cw);
        }
    glPopAttrib();
}//DrawTimecode

//---------------------------------------------------------------------------

void MySaver::DrawRasters(float Time, int Width, int Height)
{
	// the '_bRasters' flag can be used to disable rasters effect
	if (!_bRasters) return;

    float Angle = 1000.0*Time/20.0;
    // texture scale
    float ts=400.0/5.0;
    // vertical jitter
    float vs = V_RASTER_JITTER_AMP * sin(V_RASTER_JITTER_RATE*DegRad*Angle);
    // Draw Rasters
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_ZERO, GL_SRC_COLOR);
        glCallList(TEX_RASTER);
        // cyclic fading to vary brightness across rasters
        float
            k = 1.0-RASTER_FADE_AMP,
            a = k+RASTER_FADE_AMP*sin(RASTER_FADE_RATE*DegRad*11.5*Angle),
            b = k+RASTER_FADE_AMP*sin(RASTER_FADE_RATE*DegRad*12.0*Angle),
            c = k+RASTER_FADE_AMP*sin(RASTER_FADE_RATE*DegRad*11.3*Angle),
            d = k+RASTER_FADE_AMP*sin(RASTER_FADE_RATE*DegRad*11.7*Angle);
        // slight rotational jitter
        glRotatef(V_RASTER_JITTER_ROT*vs,0,0,1);
        // draw the rasters
        glBegin(GL_QUADS);
            glColor4f(a,a,a,1);
            glTexCoord2f(ts,vs);
            glVertex2f(Width,0);

            glColor4f(b,b,b,1);
            glTexCoord2f(ts,ts+vs);
            glVertex2f(Width,Height);

            glColor4f(c,c,c,1);
            glTexCoord2f(0,ts+vs);
            glVertex2f(0,Height);

            glColor4f(d,d,d,1);
            glTexCoord2f(0,vs);
            glVertex2f(0,0);
        glEnd();
    glPopAttrib();
}

//---------------------------------------------------------------------------

void MySaver::DrawSnow(float Time, float x, float y, int Width, int Height,
    bool loseSync, int Image
) {
	// the '_bSnow' flag can be used to disable snow effect
	if (!_bSnow) return;

    float u=(float)rand()/RAND_MAX, v=(float)rand()/RAND_MAX;
    float border=Width/20, shade=Width/10;

    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
    glPushMatrix();
        glDisable(GL_DEPTH_TEST);
        glTranslatef(x,y,0);

        glColor4f(0,0,0, 0.2);
        // draw drop shadow
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glRectf(Width,-shade,Width+shade,Height-shade);
		glRectf(shade,-shade,Width,0);
        glDisable(GL_BLEND);

        // draw black border frame
		glRectf(0,0,Width,border);
		glRectf(Width-border,border,Width,Height-border);
		glRectf(0,Height-border,Width,Height);
		glRectf(0,border,border,Height-border);

        glColor3f(0,1,0);

        glDisable(GL_DEPTH_TEST);

        // draw snow
        glCallList(TEX_SNOW);
        glBegin(GL_QUADS);
            glTexCoord2f(1+u,0+v);
            glVertex2f(Width-border,border);

            glTexCoord2f(1+u,1+v);
            glVertex2f(Width-border,Height-border);

            glTexCoord2f(0+u,1+v);
            glVertex2f(border,Height-border);

            glTexCoord2f(0+u,0+v);
            glVertex2f(border,border);
        glEnd();

        float Angle = 1000.0*Time/10.0;

        // draw blurry crt image
        glCallList(TEX_CRTSNAP);
        glEnable(GL_BLEND);
        // use alpha to fade image in/out of snow background
        glColor4f(0,1,0, 0.7+0.2*sin(DegRad*Angle));
        // crt image jitters according to texture coords. from
        // above, and will intermittently synchronise to make
        // the picture visible briefly
        if ((((int)(Time+sin(DegRad*Angle)*6)%6)<2) || (!loseSync)) {
            u=0;
            v=0;
        }
        float
            l= (float)(Image%4)/4.0,
            r= l+0.25,
            t= (float)(Image/4)/2.0,
            b= t+0.5;
        glBegin(GL_QUADS);
            glTexCoord2f(r+u,t+v);
            glVertex2f(Width-border,border);

            glTexCoord2f(r+u,b+v);
            glVertex2f(Width-border,Height-border);

            glTexCoord2f(l+u,b+v);
            glVertex2f(border,Height-border);

            glTexCoord2f(l+u,t+v);
            glVertex2f(border,border);
        glEnd();

        // could also blend scrolling code?
        //DrawCode(0,0,Width,Height,-Time/4.0);

        DrawTimecode(Width,Height);
    glPopMatrix();
    glPopAttrib();
}//DrawSnow

//---------------------------------------------------------------------------

// Scene 1: Spinning spheres, rasters, scrolling code & timecode
//
bool MySaver::Scene1 (float Time, int Width, int Height)
{
    float Angle = 1000.0*Time/20.0;

    glClearColor(0.4,0.4,0.4,0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    int w=Width, h=Height;

    // Setup 3D Perspective View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)w/(float)h, 0.1, 10.0);
    gluLookAt(0,0,3, 0,0,0, 0,1,0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Tumble Scene
    glRotatef(Angle,     0,1,0);
    glRotatef(Angle*0.5, 1,0,0);
    glRotatef(Angle*0.1, 0,0,1);

    // Draw Scene
    glPushAttrib(GL_ENABLE_BIT);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        for (int n=0;n<3;n++) {
            float alpha=0.5+0.5*sin(DegRad*Angle);

            switch (n) {
            case 0:
                // 1st pass: black outlines
                glDisable(GL_LIGHTING);
                glColor3f(0,0,0);
                glDisable(GL_DEPTH_TEST);
                glEnable(GL_CULL_FACE);
                break;
            case 1:
                // 2nd pass: green wireframe
                glColor3f(0,1,0);
                glDisable(GL_DEPTH_TEST);
                glDisable(GL_CULL_FACE);
                break;
            case 2:
                // 3rd pass: lit shaded spheres
                glEnable(GL_LIGHTING);
                glEnable(GL_LIGHT0);
                glEnable(GL_DEPTH_TEST);
                glEnable(GL_CULL_FACE);
                break;
            }

            glPushMatrix();
                glTranslatef(0,0.4,0);
                if (n==2) glColor4f(1,0.2,0.2,alpha);
				glCallList(LIST_SPHERE+n);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(-0.4,-0.3,0);
                if (n==2) glColor4f(0.2,1,0.2,alpha);
				glCallList(LIST_SPHERE+n);
            glPopMatrix();

            glPushMatrix();
                glTranslatef(0.4,-0.3,0);
                if (n==2) glColor4f(0.2,0.2,1,alpha);
				glCallList(LIST_SPHERE+n);
            glPopMatrix();
        }
    glPopAttrib();

    // Setup 2D Ortho View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,Width,0,Height,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw Scrolling Code
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        // left hand layer
        glColor4f(0,1,0, 0.5 +0.5*sin(0.01*Angle)*cos(0.02*Angle));
        DrawCode(0,0,h,h,-Angle/100.0);
        // right hand layer
        glColor4f(1,1,0, 0.5 +0.5*cos(0.03*Angle)*sin(0.07*Angle));
        DrawCode(w-0.5*h,0.05*h,h,h,-2.0*Angle/100.0);
    glPopAttrib();

    // Draw bar graph
    {
        float vs=Height/20.0;
        glColor3f(1,1,0);
        DrawBars(4,Height-vs*4,Width/10,vs,3);
    }

    // Draw Kana Script
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        float size=Height;
        float x=(Time-5)*Width/8.0, y=Height-size;
        // draw shadow
        glColor3f(.2,.2,.2);
        glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
        DrawKana(x+size/20,y-size/20, size,3);
        // draw script
        glColor3f(0,0,1);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        DrawKana(x,y, size,3);
    glPopAttrib();

    // Draw Timecode
    glColor4f(0.7,0.7,0.6, 1);
    DrawTimecode(w,h);

    // Draw Rasters
    DrawRasters(Time, Width, Height);

    return (Time >= 5.0f);
}//Scene1

//---------------------------------------------------------------------------

// Scene 2: Snowy CRTs and twisty bendy timecodes :)
//
bool MySaver::Scene2 (float Time, int Width, int Height)
{
    float Angle = 1000.0*Time/20.0;

    glClearColor(0.4,0.4,0.4,0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Setup 3D Perspective View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)Width/(float)Height, 1.0, 1000.0);
    glTranslatef(0,0,-400);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Tumble Scene
    glRotatef(Angle,     0,1,0);
    glRotatef(Angle*0.5, 1,0,0);
    glRotatef(Angle*0.1, 0,0,1);

    // Draw Object
    glColor3f(0,1,0);
    glPushAttrib(GL_LINE_BIT);
        glLineWidth(3.0f);
        _MBuild[0].DrawWire();
        glScalef(0.7,0.7,0.7);
        glRotatef(90, 0,1,0);
        _MBuild[0].DrawWire();
    glPopAttrib();

    // Setup 2D Ortho View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,Width,0,Height,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw twisty bendy timecodes
    for (int n=0;n<90;n+=3) {
        float i=n/60.0;
        glColor4f(0.2*i,i,i, 1);
        glPushMatrix();
            glRotatef(n,0,0,1);
            glTranslatef(30.0*sin(0.1*n+DegRad*Angle),0,0);
            DrawTimecode(Width,Height);
        glPopMatrix();
    }

    // Draw Scrolling Code
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        // left hand layer
        glColor4f(0,1,0, 0.5 +0.5*sin(0.01*Angle)*cos(0.02*Angle));
        DrawCode(0,0,Height,Height,-Angle/100.0);
        // middle layer
        glColor4f(0,1,0, 0.5 +0.5*cos(0.03*Angle)*sin(0.07*Angle));
        DrawCode(Width/2,0,Height,Height,-1.5*Angle/100.0);
    glPopAttrib();

    // Draw Snowy CRTs
    DrawSnow(Time,30,50,Height/3,Height/3);
    glPushMatrix();
        //glRotatef(5.0*sin(DegRad*Angle), 0,0,1);
        //glTranslatef(Width*Time/10.0, 0,0);
        DrawSnow(
            Time,Width/4+Width/5*sin(DegRad*Angle/3),Height/3,Height/2,Height/2,
            false,              // don't lose sync on this display
            (int)(0.9*Time)%8   // image changes periodically
        );
    glPopMatrix();

    // Draw Timecode
    glColor4f(0.7,0.7,0.6, 1);
    DrawTimecode(Width,Height);

    // Draw Rasters
    DrawRasters(Time, Width, Height);

    return (Time >= 5.0f);
}//Scene2

//---------------------------------------------------------------------------

// Scene 3: Building zoom and snowy CRTs
//
bool MySaver::Scene3 (float Time, int Width, int Height)
{
    float Angle = 1000.0*Time/20.0;

    glClearColor(0.4,0.4,0.4,0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Setup 2D Ortho View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,Width,0,Height,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw Scrolling Code
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        // left hand layer
        glColor4f(0,1,0, 0.3 +0.3*sin(0.01*Angle)*cos(0.02*Angle));
        DrawCode(0,0,Height,Height,-Angle/100.0);
        // middle layer
        glColor4f(0,1,0, 0.3 +0.3*cos(0.03*Angle)*sin(0.07*Angle));
        DrawCode(Width/2,0,Height,Height,-1.5*Angle/100.0);
    glPopAttrib();

    // Setup 3D View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)Width/(float)Height, 250.0, 1000.0);
    gluLookAt(
        0,400,600,
        0,0,0,
        0,1,0
    );
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    for (int pass=0;pass<4;pass++) {
        bool wire=false;
        glPushMatrix();
        glPushAttrib(GL_LINE_BIT | GL_ENABLE_BIT | GL_POLYGON_BIT);
            switch (pass) {
            case 0: { //-- background mask
                glColor3f(0.4,0.4,0.4);
                glDisable(GL_LIGHTING);
                glDisable(GL_DEPTH_TEST);
              } break;
            case 1: { //-- outline
                wire=true;
                glColor3f(0,0,0);
                glDisable(GL_LIGHTING);
                glDisable(GL_DEPTH_TEST);
                glLineWidth(8.0);
              } break;
            case 2: { //-- shaded model
                glEnable(GL_LIGHTING);
                glEnable(GL_LIGHT0);
                glEnable(GL_DEPTH_TEST);
                glEnable(GL_BLEND);
                float alpha = (Time<2.0)?1.0 : 0.5+0.5*sin(DegRad*Angle);
                glColor4f(0.8,0.8,0.8,alpha);
              } break;
            case 3: { //-- wireframe
                wire=true;
                glDisable(GL_LIGHTING);
                glLineWidth(2.0);
                glEnable(GL_LINE_SMOOTH);
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                glDisable(GL_DEPTH_TEST);
                float alpha = (Time<2.0)?0.0:0.5-0.5*cos(Time-2.0);
                glColor4f(0,1,0,alpha);
              } break;
            }//switch(pass)

            float sub=(Time<4.0)?0:Time<7.0?(Time-4.0):3.0;
            int levels=(Time<4.0)?6:6-sub;

            glPushMatrix();
                if (Time>4.0) {
                    // zoom in..
                    float s=(Time<6.0)?(1.0+(Time-4.0)/4.0):1.5;
                    glScalef(s,s,s);
                }
                // spin about vertical axis
                glRotatef(-Angle, 0,1,0);
                // flip model coords. to align vertically
                glRotatef(-90,1,0,0);
                // shift model downwards (so we rotate roughly about centre)
                glTranslatef(0,0,-200);
                // draw the floors
                glPushMatrix();
                for (int n=0; n<(levels>5?5:levels); n++) {
                    glTranslatef(0,0,50);
                    if (wire) _MBuild[0].DrawWire(); else _MBuild[0].Draw();
                }
                glPopMatrix();
                // draw roof detail if reqd.
                if (levels==6) {
                    if (wire) {
                        _MBuild[1].DrawWire();
                        _MBuild[2].DrawWire();
                    } else {
                        _MBuild[1].Draw();
                        _MBuild[2].Draw();
                    }
                }
                // draw room highlight
                if (wire) {
                    // fade in as required
                    glColor4f(1,0,0,(Time<1.0)?0:(Time<2.0)?(Time-1.0):1);
                    _MBuild[3].DrawWire();
                }
            glPopMatrix();
        glPopAttrib();
        glPopMatrix();
    }//for(pass)

    // Setup 2D Ortho View
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,Width,0,Height,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Draw Kana Script
    glPushAttrib(GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        float size=Height/4, x=Width-Time*Width/5.0, y=0;
        // draw shadow
        glColor3f(.2,.2,.2);
        glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
        DrawKana(x+size/20,y-size/20, size,0);
        // draw script
        glColor3f(0,0,1);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        DrawKana(x,y, size,0);
        //DrawKana(Width/3.0,Height-Time*Height/8.0, size,2);
    glPopAttrib();

    // Draw Snowy CRTs
    int dim=Height/3;
    DrawSnow(Time,30,50+dim*Time/6.0,dim,dim,false,(int)(1.2*Time+2)%8);
    DrawSnow(Time,Width-1.1*dim,Height-1.1*dim,dim,dim,false,(int)(Time)%8);

    // Draw Rasters
    DrawRasters(Time, Width, Height);

    return (Time >= 8.0f);
}//Scene3

//---------------------------------------------------------------------------

/**
 * Load 8-bit greyscale texture:
 *   - must be BMP format, uncompressed, 8-bit per pixel
 *   - width and height must be a power of two
 *   - very little error checking is done, use with care
 */
static bool LoadLumaTexture (const string &name) {
    FILE *fp = fopen(name.c_str(), "rb");
    if (fp) {
		// check header
		BYTE head[2];
		if ( (fread(head,2,1,fp)!=1) || (head[0]!='B') || (head[1]!='M') ) {
			fclose(fp);
			return false;
		}

		// get dimensions
		LONG w=0,h=0;
		fseek(fp,0x12,SEEK_SET);
		if (fread(&w,sizeof(w),1,fp)!=1) w=0;
		if (fread(&h,sizeof(h),1,fp)!=1) h=0;
		// rudimentary error checking
		if ( (w<2) || (h<2) || (w>1024) || (h>1024) ) {
			fclose(fp);
			return false;
		}

		// seek to image data (cheat)
        fseek(fp,-w*h,SEEK_END);
        GLubyte *tex = new GLubyte[w*h];
		if (tex) fread(tex,w*h,1,fp);
        fclose(fp);
		if (!tex) return false;

		// load it - note: will fail for non power of two
        glTexImage2D(
            GL_TEXTURE_2D, 0,1, w,h, 0,
            GL_LUMINANCE, GL_UNSIGNED_BYTE, tex
        );

        delete [] tex;
    }

	return true;
}//LoadLumaTexture

//---------------------------------------------------------------------------

// Load texture maps
void MySaver::SetupTextures()
{
    // texture options
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glPushAttrib(GL_ENABLE_BIT);
        // create raster texture map
        BYTE raster[4][4];
        for (int i=0;i<4;i++) for (int j=0;j<4;j++)
            raster[i][j]=(i<3)?255:200;
        // load raster texture
        glNewList(TEX_RASTER, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glTexImage2D(
                GL_TEXTURE_2D, 0,1, 4,4, 0,
                GL_LUMINANCE, GL_UNSIGNED_BYTE, raster
            );
        glEndList();

		//--- blurry numbers ---
        glNewList(TEX_NUMBER, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
			LoadLumaTexture( _Path+"BlurNum.bmp" );
        glEndList();

		//--- code texture ---
        glNewList(TEX_CODE, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			LoadLumaTexture( _Path+"CodeTex.bmp" );
        glEndList();

		//--- snow texture ---
        glNewList(TEX_SNOW, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            long w=128, h=128;
            GLubyte *tex=new GLubyte[w*h];
			if (tex) {
				for (int n=0; n<w*h; n++) tex[n]=rand();
				glTexImage2D(
					GL_TEXTURE_2D, 0,1, w,h, 0,
					GL_LUMINANCE, GL_UNSIGNED_BYTE, tex
				);
			}
            delete [] tex;
        glEndList();

		//--- crt images ---
        glNewList(TEX_CRTSNAP, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			LoadLumaTexture( _Path+"CRTImages.bmp" );
        glEndList();

		//--- kana script ---
        glNewList(TEX_KANA, GL_COMPILE);
            glEnable(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			LoadLumaTexture( _Path+"kana.bmp" );
        glEndList();
    glPopAttrib();
}//SetupTextures

//---------------------------------------------------------------------------

/**
 * Load 3D models
 */
void MySaver::SetupModels()
{
	// Build sphere display lists
	//
	glNewList(LIST_SPHERE+0, GL_COMPILE);
		mySphere(0.5+0.02,16,16);
	glEndList();
	glNewList(LIST_SPHERE+1, GL_COMPILE);
		mySphere(0.5-0.02,16,16,true);
	glEndList();
	glNewList(LIST_SPHERE+2, GL_COMPILE);
		mySphere(0.5,16,16);
	glEndList();

	// Load building models
	// do this last, since it generates list IDs
	//
    _MBuild[0].Load( (_Path+"floor.ase").c_str() );
    _MBuild[1].Load( (_Path+"roof1.ase").c_str() );
    _MBuild[2].Load( (_Path+"roof2.ase").c_str() );
    _MBuild[3].Load( (_Path+"room.ase" ).c_str() );
}//SetupModels

//---------------------------------------------------------------------------
