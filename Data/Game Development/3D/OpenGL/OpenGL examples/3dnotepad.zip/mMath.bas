Attribute VB_Name = "mMath"
Option Explicit
Public Const PI = 3.14159265358979
Public Const ONE_OVER_180 = 1 / 180
Public Const ONE_OVER_PI = (1 / PI)

'------------------------------------------------------------
'Arccos(X) = Atn(-X / Sqr(-X * X + 1)) + 2 * Atn(1)
Public Function ArcCos!(x!)
Dim tmp!
If ArcCos > 1 Then
    Debug.Assert 0
End If
If x >= 1 Then
    ArcCos = 0 '2 * Atn(1)
ElseIf x <= 0 Then
    '???
    ArcCos = 2 * Atn(1)
Else
tmp = -x * x
tmp = Sqr(tmp + 1)
ArcCos = Atn(-x / tmp) + 2 * Atn(1)
End If
End Function

Public Function ArcSin(x!)
    'ArcSin = atan2(X, Sqr(1 - X * X))
    ArcSin = Atn(x / Sqr(-x * x + 1))
End Function

Public Function ClampToRange2(a, lo, hi)
'const SS_CLAMP_TO_RANGE2( a, lo, hi ) ( a = (a < lo) ? lo : ((a > hi) ? hi : a) )
    If (a < lo) Then
        a = lo
        ClampToRange2 = lo
    ElseIf (a > hi) Then
        a = hi
        ClampToRange2 = hi
    Else
        ClampToRange2 = a
    End If
End Function

Public Function Max(a, b)
Max = IIf(a > b, a, b)
End Function

Public Function Min(a, b)
Min = IIf(a < b, a, b)
End Function

Public Function Maxf!(a, b)
Maxf = IIf(a > b, a, b)
End Function

Public Function Minf!(a, b)
Minf = IIf(a < b, a, b)
End Function

Public Function Maxi&(a, b)
Maxi = IIf(a > b, a, b)
End Function

Public Function Mini&(a, b)
Mini = IIf(a < b, a, b)
End Function

Public Function RandomInt&(Max&)
RandomInt = Max * Rnd()
End Function


