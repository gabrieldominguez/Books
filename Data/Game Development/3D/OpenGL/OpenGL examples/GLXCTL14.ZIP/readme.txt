
GLXCTL.OCX

Copyright 1988 newhermetica, edx@hk.super.net
All rights Reserved

PUBLIC NOTICE:
	You have the the right to use the enclosed materials in any way you see fit, so long as you do not hold the author liable for that usage. The enclosed materials are provided for learning and demonstration purposes and are in no sense intended to be enclosed in commercial products. If you wish to redistribute these materials, please contact me by email and I will be happy to give you permission. 
	If you modify the enclosed code and then compile it, you MUST rename the project files and resulting binaries such that they do not conflict with the binaries at www.hk.super.net/~edx. You DO NOT have the right to redistribute modified binaries of these files under the same name! Consult the web site cited below for further information on compiling modifed versions of this code.
	If you develop interesting material based on the enclosed files, I would suggest you notify me, so I can post your files or provide a link to your site.  

Note: see the web site for the latest version of the usage of this code.
www.hk.super.net/~edx

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

USING THE EXECUTABLE VERSION OF GLXCTL.OCX WITH THE SAMPLES.

Every time I recompile the code, all the samples get broken. Samples which use the compiled ocx are easiest to fix. Just delete the old ocx (or picturebox), save the project and close. Start up again and add the 'glCtl' component to the toolbox.

If that doesn't work, you may need to edit some files in Notepad.

Open the vbp file in Notepad.
Find a line like this:
Object=*\A..\..\..\..\glxCtl\glxCtl.vbp
Delete this line and save the file.
In some samples, there may also a similar line in the frmMain.frm. It too should be deleted.
Then open the vbp file in VB. If it gives an error, say OK. Then add a component to
the project (right click the toolbox), select 'glCtl'. Delete the picturebox and draw a new glxCtl1
on the form. Then run it. It should run.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

USING THE SOURCE CODE OF GLXCTL.OCX WITH THE SAMPLES.

Samples which use source are a pain to fix. I'm sorry, I can't tell you exactly how to fix them, I fight with for half an hour sometimes. Roughly, you have to use Notepad to remove the references to the ocx and/or the type library from the vbp file, save the file, then restart VB, then re-add the references. Also, before you run a sample which uses the source code for the ocx, you must 'activate' the ocx project (by opening the user control form) so VB will do its registry insanity and see the project as the ocx. Just double-click the UserControl to open it, then close it again.
If I ever figure out a reliable way of dealing with all this, I'll add instructions here.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROBLEMS

VB writes paths into project files. Heres what a vbp file looks like:
Reference=*\G{00020430-0000-0000-C000-000000000046}#2.0#0#D:\WINNT\System32\StdOle2.tlb#OLE Automation
Reference=*\G{03644881-8010-11D1-95AA-000000000000}#1.1#0#..\..\..\TLB\OpenGL\vbogl.tlb#VB OpenGL API 1.2 (ANSI)
Object={BD32D7D0-DB30-11D1-9641-000000000000}#1.1#0; glxCtl.ocx
(or)
Object=*\A..\..\..\..\glxCtl\glxCtl.vbp
....snip....
As you can see, there are hard-coded paths. It is often necessary to delete the type library line and the glxCtl line from the vbp file before it will run. Sometimes there is a line in frmMain which also must be deleted. You can then reconstruct the project by opening the vbp file in VB and adding the type library reference and either the compiled ocx to the toolbox, or the source project to create a new group.

As of v1.2, I have updated most of the samples to use the compiled version of the ocx. Switching back and forth between the source code project and the compiled ocx causes lots of problems with the registry.

1. If I try to add the file project glxCtl.vbp I get the following error 'ThreadingModel is an invalid key' and it fails to load the file.

This means you need VB5 SP2. Apparently, the Service Packs can only be applied to the Professional Edition.

2. When I load a project group and try to run it, I get an "Automation error".

Click on the user control and open it. Then close it again and the project should now run. If you have a compiled ocx on your system, and you try to run a project using the source code, VB must overwrite the registry information with some temporary information. Opening the user control causes VB to do this, apparently.

3. I get a error saying VB can't create a reference to the type library.

The type library path be different on your machine. Open the References and select 'VB OpenGL API' from the list.

4. After editing the ocx source code, I can't open or run projects.

Sometimes, after a single line of code is edited in ocx project, I get several errors which prevent the project from running. Usually VB stops at a line containing a reference to one of the ocx classes and says the type is not defined. Sometimes I get an 'Error loading dll" message.
Deleting the ocx, saving and reloading doesn't help. The error messages usually make no sense. In this case, recompiling the ocx usually fixes the problem. This is a registry problem, I expect. This is the most difficult problem I have with VB, and if anyone can shed some light on the problem, please contact me.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

USING GLXCTL.OCX TO PORT GLUT SAMPLES

To translate a glut sample:
Start a new project.
Add a reference to the VBOpenGL type library. Then add the glxCtl ocx to the Components toolbox. Draw a control on the form.

1. Add a form, a class, and a module to a new VB project.

2. Add to the class:

Public Sub Init()
'do pre-gl initialization here
End Sub

Public Sub InitGL()
'do gl initialization here
End Sub

Public Function Reshape(width&, height&, def&) As Boolean
def=True
End Function

Public Sub Draw()
'draw things here
End Sub

3. Add to the form:

Private Sub Form_Load()
	Set gCtl = glxCtl1
	Set CM = New CMyClass
	glxCtl1.Init'set up GL
	glxCtl1.Animate = True'start the timer
End Sub

Private Sub Form_Resize()
	glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_Draw()
	CM.Draw
End Sub

Private Sub glxCtl1_InitGL()
	CM.InitGL
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
	Default = CM.Reshape(width, height)
End Sub

4. Add to the module:
Public gCtl As glxCtl
Public CM As CMyClass

Sorry, this is a very rudimentary tutorial. Go to my site for detailed instructions and step-by-step tutorials. You will also find numerous samples there.


