class AwesomeGame extends UTDeathmatch;

simulated function PostBeginPlay()
{
    local AwesomeWeaponUpgrade AW;

    super.PostBeginPlay();

    GoalScore = 0;

    foreach DynamicActors(class'AwesomeWeaponUpgrade', AW)
        GoalScore++;
}

defaultproperties
{
    bScoreDeaths=false
    PlayerControllerClass=class'AwesomeGame.AwesomePlayerController'
}
