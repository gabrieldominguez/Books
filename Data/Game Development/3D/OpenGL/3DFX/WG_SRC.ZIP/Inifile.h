
#ifndef _INIFILE_
#define _INIFILE_

#include <windows.h>
#include <mmsystem.h>

//WinGlide modes
#define WINGLIDE_MODE_NONE					0
#define WINGLIDE_MODE_B2					1
#define WINGLIDE_MODE_STRETCH_BLT			2
#define WINGLIDE_MODE_OVERLAY				3
#define WINGLIDE_MODE_OFF_SCREEN_SURFACE	4


extern char gszGlide2xName[MAX_PATH + 1];
extern BOOL gbUseMMX;
extern BOOL gbMultiThreading;
extern BOOL gbSystemMenuOptions;
extern BOOL gbDisableResizeSubclass;
extern BOOL gb320x240Fix;

extern DWORD gdwWinGlideMode;

extern BOOL gbEnableGammaCorrection;
extern float gRedGamma, gGreenGamma, gBlueGamma;

extern BOOL gbUseDoubleBufferedOverlay;
extern DWORD gdwBackBufferCount;
extern DWORD gdwOverlayFlags;
extern BOOL gbAutoDetectOverlayClipping;
extern COLORREF gcrColorKey;
extern BOOL gbUseFourCCSurface;
extern FOURCC gFourCC;


extern VOID DllInitLoadINIFile(VOID);
extern VOID LoadINIFile(VOID);

#endif //_INIFILE_
