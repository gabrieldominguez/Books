@rem Generates a combine (.cmbx) and a set of project files (.prjx) 
@rem for SharpDevelop (http://icsharpcode.net/OpenSource/SD/Default.aspx)
.\tools\Prebuild\Prebuild.exe /target sharpdev /file Prebuild.xml
