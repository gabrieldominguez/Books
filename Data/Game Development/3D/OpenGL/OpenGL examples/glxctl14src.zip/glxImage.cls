VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxImage"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: used by glxTexture, can also be used directly
'   - loads a DIB or bw,la,rgb,rgba file
'   - uses glxRGB to load rgb, bw files
'   - you can build bitmaps from data by setting
'       - data
'       -width,height
'       -format, components
'   - should be able to pop up a common dialog to select a file as well
'       (this is a bad idea)
'   -note: don't pass the data pointer to an app, it may not be valid
'   -do the work here, and expose a method
'AUTHOR: ported by edx - edx@hk.super.net, April 98
' see 'texture.c' in the SIGGRAPH sample code
' also the glaux lib source code.
'HISTORY:
'Oct 98
'   - added error handlers and support for Pictures
'   - added texture properties
'   - modified the interface to set data by passing a byte array rather
'       than by a pointer to the data
'   - added a mask color
'NOTES:
'   - when loading a Picture, set the mask color and UseMask before loading.
'-------------------------------------------------------------------------
Public Enum glxResID
    rStars = 1
    rBricks = 2
    r101 = 101
End Enum
'---------------------------------------------------------
Dim m_Width As Long
Dim m_Height As Long
Dim m_Format As glTIFormatConstants
Dim m_Components As GLsizei
Dim m_OrigAspectRatio As Single    ' original width/height aspect ratio
Dim m_Data() As Byte  'the DIB pixel data
Dim m_DataSize&
Dim m_MaskColor&, m_UseMask As Boolean
Dim m_maskR As Byte
Dim m_maskG As Byte
Dim m_maskB As Byte


Private Sub Class_Terminate()
    Erase m_Data
End Sub

'-------------------------------------------------------------------------
'this returns a ptr suitable for passing to GL, but
'works correctly only within the ocx
'-------------------------------------------------------------------------
Friend Function DataPtr() As Long
    DataPtr = VarPtr(m_Data(0))
End Function

'-------------------------------------------------------------------------
'this property is provided for copying or manipulating the data
'within the ocx
'-------------------------------------------------------------------------
Friend Sub SetDataPtr(ByVal pNewData&, ByVal nSize&)
On Error GoTo EH
    ReDim m_Data(0 To nSize - 1)
    CopyToByteFromPtr m_Data(0), pNewData, nSize
    m_DataSize = nSize
'-------------------------------------------------------------------------
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'returns the array of pixels
Public Sub GetPixels(Data() As Byte, nSize&)
On Error GoTo EH
    ReDim Data(0 To m_DataSize - 1)
    CopyToByteFromByte Data(0), m_Data(0), m_DataSize
    nSize = m_DataSize
'-------------------------------------------------------------------------
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'set the pixel data
Public Sub SetPixels(Data() As Byte, nSize&)
On Error GoTo EH
    If UBound(Data) <> nSize - 1 Then GoTo EH
    m_DataSize = nSize
    ReDim m_Data(0 To m_DataSize - 1)
    CopyToByteFromByte m_Data(0), Data(0), m_DataSize
'-------------------------------------------------------------------------
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
Public Property Get DataSize&()
    DataSize = m_DataSize
End Property

'-------------------------------------------------------------------------
'client apps should use this
Public Sub SetTexImage()
    glTexImage2D GL_TEXTURE_2D, 0, m_Components, _
                  m_Width, m_Height, 0, m_Format, _
                  GL_UNSIGNED_BYTE, m_Data(0)
End Sub

'-------------------------------------------------------------------------
'client apps should use this
Public Sub BuildMipMaps()
    gluBuild2DMipmaps GL_TEXTURE_2D, m_Components, _
        m_Width, m_Height, m_Format, GL_UNSIGNED_BYTE, ByVal VarPtr(m_Data(0))
End Sub

'-------------------------------------------------------------------------
Public Property Get Format() As glTIFormatConstants
    Format = m_Format
End Property

Public Property Let Format(f As glTIFormatConstants)
    m_Format = f
End Property

'-------------------------------------------------------------------------
Public Property Get Width&()
Width = m_Width
End Property

Public Property Let Width(W&)
    m_Width = W
End Property

'-------------------------------------------------------------------------
'provided for use with GLUT
Public Property Get SizeX&()
SizeX = m_Width
End Property

Public Property Let SizeX(W&)
    m_Width = W
End Property

'-------------------------------------------------------------------------
Public Property Get Height&()
Height = m_Height
End Property

Public Property Let Height(H&)
    m_Height = H
End Property

'-------------------------------------------------------------------------
'provided for use with GLUT
Public Property Get SizeY&()
SizeY = m_Height
End Property

Public Property Let SizeY(H&)
    m_Height = H
End Property

'-------------------------------------------------------------------------
Public Property Get Components&()
Components = m_Components
End Property

Public Property Let Components(n&)
m_Components = n
End Property

'-------------------------------------------------------------------------
Public Property Get OrigAspectRatio!()
OrigAspectRatio = m_OrigAspectRatio
End Property

'-------------------------------------------------------------------------
'variation allowed in the mask color
'-------------------------------------------------------------------------
Public Sub SetMaskRange(r As Byte, g As Byte, B As Byte)
m_maskR = r
m_maskG = g
m_maskB = B
End Sub

Public Sub GetMaskRange(r As Byte, g As Byte, B As Byte)
r = m_maskR
g = m_maskG
B = m_maskB
End Sub

'-------------------------------------------------------------------------
Public Property Get UseMask() As Boolean
    UseMask = m_UseMask
End Property

Public Property Let UseMask(ByVal NewValue As Boolean)
    m_UseMask = NewValue
End Property

'-------------------------------------------------------------------------
Public Property Get MaskColor() As Long
    MaskColor = m_MaskColor
End Property

Public Property Let MaskColor(ByVal NewValue&)
    m_MaskColor = NewValue
End Property

'this stuff won't work, dont use it:
'---------------------------------------------------------
'---------------------------------------------------------
Public Function SelectFile(PathName$) As Boolean 'HWND hDlg, TEXFILE *ptf )
End Function

'---------------------------------------------------------
Public Function LoadResource(ByVal ID As glxResID) As Boolean
Dim ghmodule&, hr&
Dim fLoaded As Boolean
Dim Pic As StdPicture
    On Error GoTo NotFound
    'UC.GetErr
    If ID = r101 Then
        Set Pic = LoadResPicture(ID, 0)
    ElseIf ID = rBricks Then
        Set Pic = PicBricks
    Else
        Set Pic = PicStars
    End If
    fLoaded = LoadPicture(Pic)
    'UC.GetErr
NotFound:
    If fLoaded = False Then
        fLoaded = LoadFile(App.Path & "\stone040.bmp")
        If fLoaded = False Then Exit Function
    End If
    LoadResource = fLoaded
End Function

'---------------------------------------------------------
Public Function LoadPicture(Pic As StdPicture, Optional Opacity! = 1) As Boolean
Dim r&, i&, j&
Dim bi As BITMAPINFO256
Dim tmp As Byte
Dim DataSizeTmp&
Dim tmpData() As Byte, pad&, pSrc&, pDest&
Dim MaskRange As Boolean
Dim mr&, mB&, mg&
Dim mr2&, mb2&, mg2&
On Error GoTo EH
    If Pic Is Nothing Then Exit Function

    m_Format = GL_RGBA
    m_Components = 4
    '
    'get the dimensions
    bi.bmiHeader.biSize = Len(bi.bmiHeader)
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 0
    bi.bmiHeader.biCompression = BI_RGB
    r = GetDIBits(UC.hDC, Pic.Handle, 0, 0, ByVal 0&, _
                ByVal VarPtr(bi), DIB_RGB_COLORS)
    'Debug.Print r
    'Debug.Assert 0
    m_Height = bi.bmiHeader.biHeight
    m_Width = bi.bmiHeader.biWidth
    pad = m_Width Mod 4
    DataSizeTmp = Abs(m_Height * m_Width * 3)
    m_DataSize = Abs(m_Height * m_Width * 4)
    ReDim m_Data(0 To DataSize - 1)
    ReDim tmpData(0 To DataSizeTmp - 1 + pad * m_Height)
    bi.bmiHeader.biBitCount = 24
    r = GetDIBits(UC.hDC, Pic.Handle, 0, bi.bmiHeader.biHeight, _
            tmpData(0), ByVal VarPtr(bi), DIB_RGB_COLORS)
    'Debug.Print r
    ' swap R and B
    If m_UseMask Then
        'use lower left corner if color = -1
        If m_MaskColor = -1 Then
            mr = tmpData(2)
            mB = tmpData(1)
            mg = tmpData(0)
        Else
            With UC.Ex
            mr = .GetRValue(m_MaskColor)
            mB = .GetBValue(m_MaskColor)
            mg = .GetGValue(m_MaskColor)
            End With
        End If
        '
        If m_maskR <> 0 Or m_maskG <> 0 Or m_maskB <> 0 Then
            MaskRange = True
            mr2 = mr + m_maskR
            mr = mr - m_maskR
            mg2 = mg + m_maskG
            mg = mg - m_maskG
            mb2 = mB + m_maskB
            mB = mB - m_maskB
            If mr < 0 Then mr = 0
            If mr2 > 255 Then mr2 = 255
            If mg < 0 Then mg = 0
            If mg2 > 255 Then mg2 = 255
            If mB < 0 Then mB = 0
            If mb2 > 255 Then mb2 = 255
        End If
        '
        For i = 0 To m_Height - 1
            For j = 0 To m_Width - 1
                m_Data(pDest) = tmpData(pSrc + 2)
                m_Data(pDest + 1) = tmpData(pSrc + 1)
                m_Data(pDest + 2) = tmpData(pSrc)
                If MaskRange Then
                    If m_Data(pDest) >= mr And m_Data(pDest) <= mr2 And _
                        m_Data(pDest + 1) >= mg And m_Data(pDest + 1) <= mg2 And _
                        m_Data(pDest + 2) >= mB And m_Data(pDest + 2) <= mb2 Then
                            m_Data(pDest + 3) = 0
                    Else
                            m_Data(pDest + 3) = 255
                    End If
                ElseIf m_Data(pDest) = mr And _
                    m_Data(pDest + 1) = mg And _
                    m_Data(pDest + 2) = mB Then
                        m_Data(pDest + 3) = 0
                Else
                        m_Data(pDest + 3) = 255
                End If
                pSrc = pSrc + 3
                pDest = pDest + 4
            Next
            pSrc = pSrc + pad
        Next
    Else
        Opacity = UC.Ex.ClampToRange2(Opacity, 0, 1)
        For i = 0 To m_Height - 1
            For j = 0 To m_Width - 1
                m_Data(pDest) = tmpData(pSrc + 2)
                m_Data(pDest + 1) = tmpData(pSrc + 1)
                m_Data(pDest + 2) = tmpData(pSrc)
                m_Data(pDest + 3) = Opacity * 255
                pSrc = pSrc + 3
                pDest = pDest + 4
            Next
            pSrc = pSrc + pad
        Next
    '
    End If
    'Debug.Assert 0
    ScaleP2
    LoadPicture = True
'------------------------------------
Exit Function
EH:
Debug.Assert 0
Exit Function
Resume Next
End Function


'---------------------------------------------------------
'* Loads a BMP file and prepares it for GL usage
'---------------------------------------------------------
Public Function LoadFile(ByVal FileName$) As Boolean
Dim hFile& ' File handle
Dim hMap& ' Mapping object handle
Dim pv& ' Ptr to mapped file
Dim r&
Dim Image As glxRGBImage
Dim Pic As StdPicture
On Error GoTo Cleanup
    If FileName = "" Then Exit Function
    If StrComp(Right$(FileName, 4), ".jpg", 1) = 0 Or _
        StrComp(Right$(FileName, 4), ".gif", 1) = 0 Or _
        StrComp(Right$(FileName, 5), ".jpeg", 1) = 0 Then
            Set Pic = New StdPicture
            Set Pic = vb.LoadPicture(FileName)
            If Not Pic Is Nothing Then
                LoadFile = LoadPicture(Pic)
            End If
            Exit Function
    End If
    ' Map the DIB file into memory.
    'hFile = CreateFileDef(FileName, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0)
    hFile = CreateFile(FileName, GENERIC_READ Or GENERIC_WRITE, 0&, 0&, OPEN_EXISTING, 0&, 0&)

    If (hFile = INVALID_HANDLE_VALUE) Then GoTo Cleanup
    hMap = CreateFileMappingDef(hFile, 0, PAGE_READONLY, 0, 0, 0)
    If hMap = 0 Then GoTo Cleanup
    pv = MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0)
    If pv = 0 Then GoTo Cleanup
    If StrComp(Right$(FileName, 4), ".rgb", 1) = 0 Or _
        StrComp(Right$(FileName, 3), ".bw", 1) = 0 Or _
        StrComp(Right$(FileName, 3), ".la", 1) = 0 Or _
        StrComp(Right$(FileName, 5), ".rgba", 1) = 0 Then
        Set Image = New glxRGBImage
        'glxRGB always returns RGBA format
        If Image.RGBImageLoad(pv) Then
            SetDataPtr Image.Data, Image.DataSize
            m_Width = Image.SizeX
            m_Height = Image.SizeY
            m_Components = 4 'Image.m_SizeZ
            m_Format = GL_RGBA
'            If m_Components = 3 Then
'                m_Format = GL_RGB
'            ElseIf m_Components = 4 Then
'            ElseIf m_Components = 2 Then
'                m_Format = GL_RGBA
'            Else
'                m_Format = GL_LUMINANCE '???
'            End If
            LoadFile = True
        End If
        Set Image = Nothing
    Else
        If m_DIBImageLoad(pv) Then
            LoadFile = True
        End If
    End If
Cleanup:
    If pv Then UnmapViewOfFile pv
    If hMap Then CloseHandle hMap
    If hFile <> INVALID_HANDLE_VALUE Then CloseHandle hFile
End Function

Private Function m_DIBImageLoad(pv&)
Dim fSuccess As Boolean
Dim W&, H&, ptr&, n&, ImgSize&
Dim NumColors&
Dim bmFH As BITMAPFILEHEADER ' Ptr to file header
Dim bmIH As BITMAPINFOHEADER  ' Ptr to file's info header (if it exists)
Dim ColorTable() As RGBQUAD
Dim bmIRGB As BITMAPINFO ' Ptr to DIB's BITMAPINFO
Dim i&, j&, padBytes&
Dim pjBitsRGB& ' Ptr to 24BPP RGB image in DIB section
Dim pjTKBits&  ' Ptr to final TK image bits
Dim pjSrc&     ' Ptr to image file used for conversion
Dim pjDst&     ' Ptr to TK image used for conversion
Dim pjDstBits&
'Dim pbmISource As BITMAPINFO ' Ptr to source BITMAPINFO
' These need to be cleaned up when we exit:
Dim hdcMem&, ptrI&, ptrBits&
Dim hbmRGB& ' 24BPP RGB bitmap
On Error GoTo Cleanup
    ptr = pv
    'read the unaligned BMPFILEHEADER
    If m_ReadBMPFILEHEADER(ptr, bmFH) = False Then Exit Function
    ptrI = ptr
    'read the BMPINFO in two pieces - the BMIHEADER and the color table
    If m_ReadBMPINFOHEADER(ptr, bmIH, NumColors) = False Then Exit Function
    If NumColors Then 'only support 256
        If NumColors <> 256 Then Exit Function
        ReDim ColorTable(0 To NumColors - 1)
        CopyToTypeFromPtr ColorTable(0), ptr, NumColors * Len(ColorTable(0))
        ptr = ptr + NumColors * Len(ColorTable(0))
'    Else 'is there a pad RGBQuad in a 24c DIB? The type adds one
'        ptr = ptr + Len(ColorTable(0))
    End If
    ptrBits = ptr
    ' Create a 24BPP RGB DIB section and select it into the memory DC.
    hbmRGB = m_CreateBMP(hdcMem, ptrI, bmIH, bmIRGB, pjBitsRGB, ptr, NumColors, ColorTable)
    If hbmRGB = 0 Then GoTo Cleanup
    ' Convert to TK image format (packed RGB format).
    ImgSize = Abs(bmIH.biWidth * bmIH.biHeight) * 3
    pjTKBits = GlobalAlloc(GMEM_MOVEABLE Or GMEM_ZEROINIT, ImgSize)
    If pjTKBits = 0 Then GoTo Cleanup
    pjSrc = pjBitsRGB
    If pjSrc = 0 Then Exit Function
    pjDst = GlobalLock(pjTKBits)
    pjDstBits = pjDst
    ' src lines end on LONG boundary - so need to skip over any padding bytes
    padBytes = bmIH.biWidth Mod 4
    For i = 0 To bmIH.biHeight - 1
        For j = 0 To bmIH.biWidth - 1
            ' swap R and B
            CopyToPtrFromPtr pjDst, pjSrc + 2, 1
            CopyToPtrFromPtr pjDst + 1, pjSrc + 1, 1
            CopyToPtrFromPtr pjDst + 2, pjSrc, 1
            pjSrc = pjSrc + 3
            pjDst = pjDst + 3
        Next
        pjSrc = pjSrc + padBytes
    Next
' Initialize the texture structure
    ' If we get to here, we have succeeded!
    m_Width = bmIH.biWidth
    m_Height = bmIH.biHeight
    m_OrigAspectRatio = m_Height / m_Width
    m_Format = GL_RGB
    m_Components = 3
    'm_Data = pjTKBits
    ReDim m_Data(0 To ImgSize - 1)
    m_DataSize = ImgSize
    CopyToByteFromPtr m_Data(0), pjDstBits, bmIH.biSizeImage
    fSuccess = True
'Exit Function
Cleanup:
    GlobalUnlock pjDstBits
    GlobalFree pjTKBits
    If hdcMem Then DeleteDC hdcMem
    If hbmRGB Then DeleteObject hbmRGB
' Check for error.
    m_DIBImageLoad = fSuccess
End Function

Private Function m_CreateBMP(hDC&, ptrIH&, IH As BITMAPINFOHEADER, _
                        IRGB As BITMAPINFO, pRGBBits&, pSrcBits, _
                        NumColors&, Colors() As RGBQUAD)
Dim hRGB&
Dim BMI As BITMAPINFO
Dim BMI256 As BITMAPINFO256
On Error GoTo Cleanup
    ' Create a BITMAPINFO (with color table) for the DIB file.  Because the
    ' file may not have one (BITMAPCORE case) and potential alignment problems,
    ' we will create a new one in memory we allocate.
    If IH.biClrUsed = 0 Then
        IH.biClrUsed = NumColors
    End If
    If NumColors = 256 Then
        CopyToTypeFromType BMI256, IH, Len(IH)
        CopyToTypeFromType BMI256.bmiColors(0), Colors(0), Len(Colors(0)) * NumColors
    Else
        CopyToTypeFromType BMI, IH, Len(IH)
    End If
    ' Create memory DC.
    hDC = CreateCompatibleDC(0)
    If hDC = 0 Then Exit Function
    ' Create a 24BPP RGB DIB section and select it into the memory DC.
    IRGB.bmiHeader.biSize = Len(IRGB)
    IRGB.bmiHeader.biWidth = IH.biWidth
    IRGB.bmiHeader.biHeight = IH.biHeight
    IRGB.bmiHeader.biPlanes = 1
    IRGB.bmiHeader.biBitCount = 24
    IRGB.bmiHeader.biCompression = BI_RGB
    IRGB.bmiHeader.biSizeImage = IRGB.bmiHeader.biWidth _
                                         * Abs(IRGB.bmiHeader.biHeight) * 3
    hRGB = CreateDIBSection(hDC, IRGB, DIB_RGB_COLORS, _
                              pRGBBits, 0&, 0&)
    If hRGB = 0 Then GoTo Cleanup
    If SelectObject(hDC, hRGB) = 0 Then GoTo Cleanup
    'create an appropriate bmi
    '
    ' Slam the DIB file image into the memory DC.  GDI will do the work of
    ' translating whatever format the DIB file has into RGB format.
    If NumColors = 256 Then
        If SetDIBits256(hDC, hRGB, 0, IH.biHeight, _
                       pSrcBits, BMI256, DIB_RGB_COLORS) = 0 Then GoTo Cleanup
    Else
        If SetDIBits(hDC, hRGB, 0, IH.biHeight, _
                       pSrcBits, BMI, DIB_RGB_COLORS) = 0 Then GoTo Cleanup
    End If
'    If SetDIBits(hDC, hRGB, 0, IH.biHeight, _
'                       pSrcBits, ptrIH, DIB_RGB_COLORS) = 0 Then GoTo Cleanup
    GdiFlush     ' make sure that SetDIBits executes
    m_CreateBMP = hRGB
    Exit Function
Cleanup:
    If hDC Then DeleteDC hDC
    If hRGB Then DeleteObject hRGB
End Function

''***************************************************************************                                                                       *
'/*              BITMAPFILEHEADER STRUCUTURE is as follows
' *              BITMAPFILEHEADER
' *              WORD    bfType
' >          ....                  <     add WORD if packed here!
' *              DWORD   bfSize
' *              WORD    bfReserved1
' *              WORD    bfReserved2
' *              DWORD   bfOffBits
' *                      This is the packed format, unpacked adds a WORD after bfType
''***************************************************************************                                                                       *
Private Function m_ReadBMPFILEHEADER(pv&, bmFH As BITMAPFILEHEADER) As Boolean
Dim nSize&, OffBits&
    ' Check the file header.  If the BFT_BITMAP magic number is there,
    ' then the file format is a BITMAPFILEHEADER followed immediately
    ' by either a BITMAPINFOHEADER or a BITMAPCOREHEADER.  The bitmap
    ' bits, in this case, are located at the offset bfOffBits from the
    ' BITMAPFILEHEADER.
    CopyToTypeFromPtr bmFH, pv, 2 'Len(bmFH)
    If bmFH.bfType <> BFT_BITMAP Then Exit Function
    CopyToLongFromPtr nSize, pv + OFFSET_bfSize, 4
    CopyToLongFromPtr OffBits, pv + OFFSET_bfOffBits, 4
    If nSize And OffBits Then
        bmFH.bfSize = nSize
        bmFH.bfOffBits = OffBits
        m_ReadBMPFILEHEADER = True
        pv = pv + len_BITMAPFILEHEADER
    End If
End Function

''***************************************************************************                                                                       *
' *  FUNCTION   : DibNumColors(VOID FAR * pv)                                *                                                                        *
' *  PURPOSE    : Determines the number of colors in the DIB by looking at   *
' *               the BitCount filed in the info block.                      *                                                                         *
' *  RETURNS    : The number of colors in the DIB.                           *
' * Stolen from SDK ShowDIB example.                                         *
' ***************************************************************************'
Private Function m_ReadBMPINFOHEADER(pv&, bmIH As BITMAPINFOHEADER, NumColors&) As Boolean
Dim IH As BITMAPINFOHEADER   ' UNALIGNED *
Dim ch As BITMAPCOREHEADER    'UNALIGNED *
    CopyToPtrFromPtr VarPtr(IH), pv, Len(IH)
    CopyToPtrFromPtr VarPtr(ch), pv, Len(ch)
'    '  With the BITMAPINFO format headers, the size of the palette
'     *  is in biClrUsed, whereas in the BITMAPCORE - style headers, it
'     *  is dependent on the bits per pixel ( = 2 raised to the power of
'     *  bits/pixel).
    If IH.biSize = Len(IH) Then
        CopyToPtrFromPtr VarPtr(bmIH), pv, Len(bmIH)
        pv = pv + Len(bmIH)
        If IH.biClrUsed <> 0 Then
            NumColors = bmIH.biClrUsed
            GoTo finish
        End If
        NumColors = m_DibNumColors(CLng(IH.biBitCount))
    ElseIf ch.bcSize = Len(ch) Then
        Exit Function
    Else: Exit Function
    End If
finish:
    m_ReadBMPINFOHEADER = True
    If bmIH.biSizeImage = 0 Then
        bmIH.biSizeImage = bmIH.biWidth * bmIH.biHeight * bmIH.biBitCount
    End If
End Function

Private Function m_DibNumColors&(bits&)
    Select Case bits
        Case 1: m_DibNumColors& = 2
        Case 4: m_DibNumColors& = 16
        Case 8: m_DibNumColors& = 256
        Case Else: ' A 24 bitcount DIB has no color table '
            m_DibNumColors& = 0
    End Select
End Function

'-------------------------------------------------------------------------
'SetTextureTransparency
'* Set transparency for a texture by adding or modifying the alpha data.
'* Transparency value must be between 0.0 (opaque) and 1.0 (fully transparent)
'* If the texture data previously had no alpha, add it in.
'* If bSet is TRUE, make this the current texture.
'* Note: Currently fully transparent pixels (alpha=0) will not be altered, since
'* it is assumed these should be permanently transparent (could make this an
'* option? - bPreserveTransparentPixels )
'-------------------------------------------------------------------------
Public Function SetTransparency(ByVal fTransp!) As Boolean
Dim i&, fAlpha!, bAlpha As Byte
Dim pPal& '() As RGBQUAD
    fTransp = UC.Ex.ClampToRange2(fTransp, 0, 1)
    fAlpha = 1 - fTransp
    If m_Format = GL_COLOR_INDEX Then
        Debug.Assert 0
    Else
        ' Need to setup new texture data
        If m_Components <> 4 Then
            ' Make room for alpha component
            ConvertToRGBA fAlpha
        Else ' Set alpha component
            m_SetAlpha fAlpha
        End If
        SetTransparency = True
    End If
End Function

'-------------------------------------------------------------------------
' SetTextureAlpha
' Set a constant alpha value for the texture
' Again, don't overwrite any existing 0 alpha values, as explained in
' ss_SetTextureTransparency
'-------------------------------------------------------------------------
Private Sub m_SetAlpha(fAlpha!)
Dim i&, bAlpha As Byte
    bAlpha = fAlpha * 255
    If m_Components <> 4 Then Exit Sub
    For i = 0 To (m_Width * m_Height * 4) - 1 Step 4
        If m_Data(i + 3) <> 0 Then
            m_Data(i + 3) = bAlpha
        End If
    Next
End Sub

'-------------------------------------------------------------------------
Public Function ScaleP2() As Boolean
Dim xPow2#, yPow2#, ixPow2&, iyPow2&, i&
Dim xSize2&, ySize2&, glMaxTexDim&
Dim pData() As Byte
On Error GoTo EH
    If m_Width <= 0 Or m_Height <= 0 Then
        Debug.Assert 0
        Exit Function
    End If
    glGetIntegerv GL_MAX_TEXTURE_SIZE, glMaxTexDim
    If glMaxTexDim <= 0 Then Exit Function

    If m_Format <> GL_COLOR_INDEX Then
        ' We limit the max dimension here for performance reasons
        glMaxTexDim = UC.Ex.Min(512, glMaxTexDim)
        If (m_Width <= glMaxTexDim) Then
            xPow2 = Log(m_Width) / Log(2)
        Else
            xPow2 = Log(glMaxTexDim) / Log(2)
        End If
        If (m_Height <= glMaxTexDim) Then
            yPow2 = Log(m_Height) / Log(2#)
        Else
            yPow2 = Log(glMaxTexDim) / Log(2#)
        End If
        ixPow2 = Int(xPow2)
        iyPow2 = Int(yPow2)
        ' Always scale to higher nearest power
        If (xPow2 <> ixPow2) Then
            ixPow2 = ixPow2 + 1
        End If
        If (yPow2 <> iyPow2) Then
            iyPow2 = iyPow2 + 1
        End If
        'todo
        xSize2 = 2 ^ ixPow2
        ySize2 = 2 ^ iyPow2
        If (xSize2 <> m_Width Or ySize2 <> m_Height) Then
            'pData = (BYTE *) malloc(xSize2 * ySize2 * components * sizeof)
            'Debug.Assert 0
            m_DataSize = xSize2 * ySize2 * m_Components
            ReDim pData(0 To m_DataSize - 1)
            glPixelStorei GL_UNPACK_ALIGNMENT, 1
            If (gluScaleImage(m_Format, m_Width, m_Height, _
                      GL_UNSIGNED_BYTE, m_Data(0), _
                      xSize2, ySize2, GL_UNSIGNED_BYTE, _
                      pData(0))) Then
                ' glu failure
                Debug.Print "ValidateTextureSize : gluScaleImage failure"
                Debug.Assert 0
                Exit Function
            End If
            ' set the new width,height,data
            m_Width = xSize2
            m_Height = ySize2
            ReDim m_Data(0 To m_DataSize - 1)
            CopyToByteFromByte m_Data(0), pData(0), m_DataSize
        End If
    Else   ' paletted texture case
        ' paletted texture: must be power of 2 - but might need to enforce
        ' here if not done in a8 load.  Also have to check against
        ' GL_MAX_TEXTURE_SIZE.  Could then clip it to power of 2 size
    End If
    ScaleP2 = True
'-------------------------------------------------------------------------
Exit Function
EH:
Debug.Assert 0
End Function

'-------------------------------------------------------------------------
'* ConvertTextureToRGBA
'* Convert RGB texture to RGBA
''-------------------------------------------------------------------------
Public Sub ConvertToRGBA(ByVal fAlpha!)
Dim count&, bAlpha As Byte, i&
Dim Src&, dst&
Dim pNewData() As Byte
On Error GoTo EH
    If m_Components = 4 Then Exit Sub
    fAlpha = UC.Ex.ClampToRange2(fAlpha, 0, 1)
    count = m_Width * m_Height
    m_DataSize = count * 4
    bAlpha = fAlpha * 255
    ReDim pNewData(0 To m_DataSize - 1)
    'src = data
    'dst = pNewData
    ' Note: the color ordering is ABGR, where R is lsb
    'Debug.Assert 0
    For i = 0 To count - 1
        '*((RGB8 *)dst) = *((RGB8 *)src)
        CopyToByteFromByte pNewData(dst), m_Data(Src), 3
        pNewData(dst + 3) = bAlpha
        dst = dst + 4
        Src = Src + 3
    Next
    ReDim m_Data(0 To m_DataSize - 1)
    CopyToByteFromByte m_Data(0), pNewData(0), m_DataSize
    m_Components = 4
    m_Format = GL_RGBA
'-------------------------------------------------------------------------
Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'CopyTexture
'* Make a copy of a texture.
'-------------------------------------------------------------------------
Public Function Copy(Src As glxImage) As Boolean
    If Src Is Nothing Then Exit Function
    m_Width = Src.Width
    m_Height = Src.Height
    m_Format = Src.Format
    m_Components = Src.Components
    m_OrigAspectRatio = Src.OrigAspectRatio
    ' copy image data
    SetDataPtr Src.DataPtr, Src.DataSize
End Function

'-------------------------------------------------------------------------
Public Sub DrawPixels(Optional Width&, Optional Height&)
Dim W&, H&
    If W = 0 Then W = m_Width
    If H = 0 Then H = m_Height
    glDrawPixels W, H, GL_RGB, GL_UNSIGNED_BYTE, m_Data(0)
End Sub

'-------------------------------------------------------------------------
'convert all the alpha of all the pixels which match the maskcolor
'Doesn't change other pixel alpha values
'-------------------------------------------------------------------------
Public Function ApplyMask(Optional Opacity! = 0) As Boolean
Dim mr As Byte, mB As Byte, mg As Byte, i&
On Error GoTo EH
    Opacity = UC.Ex.ClampToRange2(Opacity, 0, 1)
    If m_Format = GL_COLOR_INDEX Then
        Debug.Assert 0
    Else
        If m_Components <> 4 Then
            ConvertToRGBA 1
        End If
        'use lower left corner if color = -1
        If m_MaskColor = -1 Then
            mr = m_Data(0)
            mB = m_Data(1)
            mg = m_Data(2)
        Else
            With UC.Ex
            mr = .GetRValue(m_MaskColor)
            mB = .GetBValue(m_MaskColor)
            mg = .GetGValue(m_MaskColor)
            End With
        End If
        For i = 0 To m_DataSize - 1 Step 4
            If m_Data(i) = mr And _
                m_Data(i + 1) = mB And _
                m_Data(i + 2) = mg Then
                    m_Data(i + 3) = Opacity
            Else
                    'm_Data(i + 3) = 1
            End If
        Next
        
        ApplyMask = True
    End If
'-------------------------------------------------------------------------
Exit Function
EH:
Debug.Assert 0
End Function
