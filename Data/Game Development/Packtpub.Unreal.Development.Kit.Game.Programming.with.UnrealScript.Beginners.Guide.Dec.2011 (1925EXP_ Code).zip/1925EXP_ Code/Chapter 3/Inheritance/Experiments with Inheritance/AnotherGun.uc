class AnotherGun extends AwesomeGun;

defaultproperties
{
    MyInt=4
}
