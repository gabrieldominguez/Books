VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CQuad"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: demonstrates aspects of glu quad objects
'   - most of code of interest is in the keypress function
'AUTHOR: ported by edx - edx@hk.super.net,  April 98
'   - from a file at www.opengl.org
'HISTORY:  April 98
'/*************************************************************************

Dim black!(0 To 2)
Dim blue!(0 To 2) ' =  0, 0, 1
Dim gray!(0 To 2) ' =  {    0.5, 0.5, 0.5
Dim white!(0 To 2) ' = {    1, 1, 1
Dim doDither As Boolean
Dim shade As Boolean
Dim texture As Boolean

Dim radius1&, radius2&
Dim angle1#, angle2#
Dim slices&, stacks&, height&
Dim orientation&
Dim whichQuadric&
Dim quadObj&
Dim brickImage(0 To 4 * brickImageWidth * brickImageHeight - 1) As Byte
Dim ImageFile$
'Dim image& 'RGBImageRec *image = NULL;
Dim colorIndexes&(0 To 2)
Dim decal!
Dim modulate!
Dim repeat!
Dim nearest!
'
Dim m_MatFront As glxMaterial
Dim m_MatBack As glxMaterial
Dim m_Tex As glxTexture
Dim m_bTexture As Boolean
Dim usebrick As Boolean
Dim m_bMoving As Boolean
Dim m_StartX&, m_StartY&
Dim m_MouseX&, m_MouseY&


Private Sub Class_Initialize()
FillArrayf blue, 0, 0, 1
FillArrayf gray, 0.5, 0.5, 0.5
FillArrayf white, 1, 1, 1
doDither = GL_TRUE
shade = GL_TRUE
texture = 0 'GL_TRUE;
orientation = GLU_OUTSIDE
FillArrayi clrRed, &HA4, &H0, &H0, &HFF
FillArrayi clrWhite, &HFF, &HFF, &HFF, &HFF
FillArrayb brickImage, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    RD, RD, RD, RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, _
    WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, WT, _
    RD, RD, RD, RD, WT, RD, RD, RD, RD, RD, RD, RD, RD, RD, WT, RD
FillArrayi colorIndexes, 0, 200, 255
decal = GL_DECAL
modulate = GL_MODULATE
repeat = GL_REPEAT
nearest = GL_NEAREST
'
radius1 = 10
radius2 = 5
angle1 = 90
angle2 = 180
slices = 16
stacks = 10
height = 20
'
'ImageFile = App.Path & "\stone040.bmp"
usebrick = 0
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.5, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
        .TwoSide = True
    End With
    With gCtl.Camera
        .FarPlane = 10
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 2, 2, 2
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_MatFront = gCtl.NewMaterial
    With m_MatFront
        .face = faceFront
        .SetDiffuse 0.5, 0.28, 0.38
        .SetSpecular 0.2, 0.2, 0.2
        .SpecExp = 30
    End With
    Set m_MatBack = gCtl.NewMaterial
    With m_MatBack
        .face = faceBack
        .SetDiffuse 1, 1, 0.2
        .SetSpecular 0.5, 0.5, 0.2
        .SpecExp = 50
    End With
    Set m_Tex = gCtl.NewTexture
    glTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, decal
    m_Tex.SetDefaultTextureParams
    
    If Len(ImageFile) Then
        m_bTexture = m_Tex.LoadTextureFile(ImageFile)
    End If
    '
    With m_Tex.Image
    If m_bTexture Then
        glPixelStorei GL_UNPACK_ALIGNMENT, 1
        .BuildMipMaps
    ElseIf usebrick Then
        glPixelStorei GL_UNPACK_ALIGNMENT, 1
        .width = brickImageWidth
        .height = brickImageHeight
        .Components = 4
        .Format = GL_RGBA
        .SetPixels brickImage, (UBound(brickImage) + 1)
        m_Tex.SetTexture
    Else
'        glPixelStorei GL_UNPACK_ALIGNMENT, 1
'        .width = brickImageWidth
'        .height = brickImageHeight
'        .Components = 4
'        .Format = GL_RGBA
'        .SetData VarPtr(brickImage(0)), (UBound(brickImage) + 1)
'        m_Tex.SetTexture
        m_Tex.CreateCheckTexture
    End If
    End With
'
    quadObj = gluNewQuadric
    gluQuadricCallback quadObj, GLU_TESS_ERROR, AddressOf ErrorHandler

End Sub

Public Sub Draw()
    'glLoadIdentity
    glRotatef xRotation, 1, 0, 0
    glRotatef yRotation, 0, 1, 0
    glRotatef zRotation, 0, 0, 1

    'glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT

    glColor3f 1, 1, 1
    Select Case whichQuadric
    Case 0:
        glTranslatef 0, 0, -height / 20
        gluCylinder quadObj, radius1 / 10, radius2 / 10, height / 10, _
            slices, stacks
    Case 1:
        gluSphere quadObj, radius1 / 10, slices, stacks
    Case 2:
        gluPartialDisk quadObj, radius2 / 10, radius1 / 10, slices, _
               stacks, angle1, angle2
    Case 3:
        gluDisk quadObj, radius2 / 10, radius1 / 10, slices, stacks
    End Select
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
    'glViewport 0, 0, width, height

'    glMatrixMode GL_PROJECTION
'    glLoadIdentity
'    glFrustum -1, 1, -1, 1, 1, 10
'    gluLookAt 2, 2, 2, 0, 0, 0, 0, 0, 1
'    glMatrixMode GL_MODELVIEW
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft: yRotation = yRotation + 5
    Case vbKeyRight: yRotation = yRotation - 5
    Case vbKeyUp: xRotation = xRotation + 5
    Case vbKeyDown: xRotation = xRotation - 5
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii%)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "1":    gluQuadricDrawStyle quadObj, GLU_FILL
    Case "2":    gluQuadricDrawStyle quadObj, GLU_POINT
    Case "3":    gluQuadricDrawStyle quadObj, GLU_LINE
    Case "4":    gluQuadricDrawStyle quadObj, GLU_SILHOUETTE
    Case "0":
        shade = Not shade
        If (shade) Then
            glShadeModel GL_SMOOTH
            gluQuadricNormals quadObj, GLU_SMOOTH
        Else
            glShadeModel GL_FLAT
            gluQuadricNormals quadObj, GLU_FLAT
        End If
    Case "A":    stacks = stacks + 1
    Case "a":    If stacks > 3 Then stacks = stacks - 1
    Case "S":    slices = slices + 1
    Case "s":    If slices > 3 Then slices = slices - 1
    Case "d":
        Select Case orientation
          Case GLU_OUTSIDE:
            orientation = GLU_INSIDE
          Case Else 'GLU_INSIDE:
            orientation = GLU_OUTSIDE
        End Select
        gluQuadricOrientation quadObj, orientation
    Case "f":
        whichQuadric = (whichQuadric + 1) ' & &H3
        If whichQuadric > 3 Then whichQuadric = 0
    Case "G":    radius1 = radius1 + 1
    Case "g":
        radius1 = radius1 - 1
        If radius1 < 1 Then radius1 = 1
    Case "J":    radius2 = radius2 + 1
    Case "j":
        radius2 = radius2 - 1
        If radius2 < 1 Then radius2 = 1
    Case "H":    height = height + 2
    Case "h":
        height = height - 2
        If height < 2 Then height = 2
    Case "K":    angle1 = angle1 + 5
    Case "k":
        angle1 = angle1 - 5
        If angle1 < 5 Then angle1 = 5
    Case "L":    angle2 = angle2 + 5
    Case "l":
        angle2 = angle2 - 5
        If angle2 < 5 Then angle2 = 5
    Case "z":
        texture = Not texture
        If (texture) Then
            gluQuadricTexture quadObj, GL_TRUE
            glEnable GL_TEXTURE_2D
        Else
            gluQuadricTexture quadObj, GL_FALSE
            glDisable GL_TEXTURE_2D
        End If
    Case "q":    glDisable GL_CULL_FACE
    Case "w":
        glEnable GL_CULL_FACE
        glCullFace GL_FRONT
    Case "e":
        glEnable GL_CULL_FACE
        glCullFace GL_BACK
    Case "r":    glFrontFace GL_CW
    Case "t":    glFrontFace GL_CCW
    Case "y":
        doDither = Not doDither
        If (doDither) Then
            glEnable GL_DITHER
        Else
            glDisable GL_DITHER
        End If
    End Select
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If (m_bMoving) Then
        End If
    Else
    End If
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    ' Rotate the scene with the left mouse button. */
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub





