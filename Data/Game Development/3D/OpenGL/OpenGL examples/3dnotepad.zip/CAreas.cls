VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CAreas"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Collection" ,"CArea"
Attribute VB_Ext_KEY = "Member0" ,"CArea"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: manages the text areas and the current selection
'It also handles I/O, but I doubt the code works yet.
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES:
'--------------------------------------------------------------------

Private mCol As Collection
Dim NextID& 'unique ID used as name for picking
Dim m_SelectedArea As CArea

Public Sub Clear()
Dim i&
    Do While mCol.Count
        mCol.Remove 1
    Loop
    NextID = 0
End Sub

Public Function Save(fn&) As Boolean
Dim i&
Dim s$
    Put fn, , mCol.Count
    For i = 1 To mCol.Count
        mCol(i).Save fn
    Next
    Save = True
End Function

Public Property Get SelectedArea() As CArea
    Set SelectedArea = m_SelectedArea
End Property

Public Property Let SelectedArea(ByVal NewValue As CArea)
Dim a!, X!, Y!, z!, i&, s$
Dim F As Form
    If Not m_SelectedArea Is Nothing Then
        m_SelectedArea.Selected = False
    End If
    Set m_SelectedArea = NewValue
    With frmMain
        .Loading = True
        If m_SelectedArea Is Nothing Then
            .UpdateEditMenu False
        Else
            .UpdateEditMenu True
            m_SelectedArea.Selected = True
        End If
        .Loading = False
    End With
    Set Manipulator.Area = m_SelectedArea
    'notify dlgProperties if it is loaded
    For Each F In Forms
        If F.Name = "dlgProperties" Then
            F.Area = m_SelectedArea
            Exit For
        End If
    Next
End Property

Public Function AddNew() As CArea
Dim na As CArea
    Set na = New CArea
    NextID = NextID + 1
    na.ID = NextID
    na.Name = "Area" & Format$(NextID)
    na.Text = na.Name
    mCol.Add na, Format$(NextID)
    SelectedArea = na
    Set AddNew = na
    Set na = Nothing
    gCtl.Render
End Function

Public Property Get Item(vntIndexKey As Variant) As CArea
Attribute Item.VB_UserMemId = 0
On Error Resume Next
    Set Item = mCol(vntIndexKey)
End Property

Public Property Get Count() As Long
    Count = mCol.Count
End Property

Public Function Delete() As Boolean
Dim i&
    If m_SelectedArea Is Nothing Then
        Debug.Assert 0
        Exit Function
    End If
    For i = 1 To mCol.Count
        If mCol(i) Is m_SelectedArea Then
            mCol.Remove i
            SelectedArea = Nothing
            gCtl.Render
            Delete = True
            Exit Function
        End If
    Next
End Function

Public Property Get NewEnum() As IUnknown
Attribute NewEnum.VB_UserMemId = -4
Attribute NewEnum.VB_MemberFlags = "40"
    Set NewEnum = mCol.[_NewEnum]
End Property

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub

Public Sub Draw()
Dim i&
    For i = 1 To mCol.Count
        mCol(i).Draw
    Next
End Sub

Public Function Pick(ID&) As Boolean
Dim a As CArea
    Set a = Item(Format$(ID))
    SelectedArea = a
    If Not a Is Nothing And ID > 0 Then Pick = True
End Function

Public Function Load(fn&, Path$) As Boolean
Dim i&, cnt&, a As CArea
    Get fn, , cnt
    For i = 1 To cnt
        Set a = New CArea
        NextID = NextID + 1
        a.ID = NextID
        a.Load fn, Path
        mCol.Add a, Format$(NextID)
    Next
    Load = True
End Function

