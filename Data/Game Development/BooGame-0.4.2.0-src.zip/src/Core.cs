/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.IO;
using System.Drawing;

using Tao.FreeGlut;
using Tao.DevIl;
using Tao.OpenGl;
using Tao.PhysFs;

namespace BooGame
{
    /// <summary>
    /// The core of the BooGame system.
    /// </summary>
    public sealed class Core
    {
        /// <summary>
        /// Called when BooGame exits.
        /// </summary>
        public static event QuitEventHandler Quit;

        static Core()
        {
            Glut.glutInit();
            Glut.glutInitDisplayMode(Glut.GLUT_RGBA | Glut.GLUT_DOUBLE);
            Glut.glutInitWindowSize(640, 480);
            Glut.glutCreateWindow("BooGame - Please Wait...");

            Glut.glutDisplayFunc(new Glut.DisplayCallback(DrawCallback));
            Glut.glutCloseFunc(new Glut.CloseCallback(QuitCallback));

			// Ensure sub-systems start
            Display.Initialize();
            Timer.Initialize();
            Keyboard.Initialize();
            Mouse.Initialize();
            Joystick.Initialize();
			Script.Initialize();
            Texture.Initialize();
            Font.Initialize();
            Terminal.Enabled = true;
        }
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Core()
        {
        }

		/// <summary>
		/// Ensure engine is started.
		/// </summary>
		internal static void Initialize()
		{
		}

		private static GameState m_Game = new GameState();
        /// <summary>
        /// The current GameState to be run.
        /// </summary>
        public static GameState Game
		{
			get{ return m_Game; }
			set
			{
                GameState next = (value == null) ? new GameState() : value;
                GameState previous = m_Game;
                m_Game.Exit(new ExitEventArgs(next));
                m_Game = next;
                m_Game.Enter(new EnterEventArgs(previous));
			}
		}


        private static void QuitCallback()
        {
			QuitEventArgs args = new QuitEventArgs();
			
			m_Game.Quit(args);

            if (Quit != null)
                Quit(null, args);
        }

        /// <summary>
        /// Quits the BooGame application.
        /// </summary>
        public static void QuitApplication()
        {
            //Glut.glutDestroyWindow(Glut.glutGetWindow());
			Glut.glutLeaveMainLoop();
        }

        /// <summary>
        /// This event is called when there needs to be an update.
        /// </summary>
		public static event UpdateEventHandler Update;

        internal static void InvokeUpdate()
        {
            m_Game.Update();
            m_Game.Gui.Update();

            if (Update != null)
                Update(null, new UpdateEventArgs());

			Glut.glutPostRedisplay();
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static void DrawCallback()
        {
            Display.Clear();

			m_Game.Draw();
            m_Game.Gui.Draw();

			if(Draw != null)
				Draw(null, new DrawEventArgs());

            Glut.glutSwapBuffers();
        }

        /// <summary>
        /// This event is called when the screen needs to be redrawn.
        /// </summary>
		public static event DrawEventHandler Draw;

        /// <summary>
        /// Runs the application and starts polling events.
        /// </summary>
        public static void Run()
        {
            Timer.Reset();
            Glut.glutMainLoop();
        }
    }

    /// <summary>
    /// Describes a quit event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void QuitEventHandler(object sender, QuitEventArgs args);

    /// <summary>
    /// Describes a draw event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void DrawEventHandler(object sender, DrawEventArgs args);

    /// <summary>
    /// Describes an update event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void UpdateEventHandler(object sender, UpdateEventArgs args);

	/// <summary>
	/// Passed to the update event when Update calls are made.
	/// </summary>
	public class UpdateEventArgs : EventArgs
	{
	}

	/// <summary>
	/// Passed to the Quit event when BooGame exits.
	/// </summary>
	public class QuitEventArgs : System.EventArgs
	{
	}

	/// <summary>
	/// Passed to the Draw events when BooGame draws its screen.
	/// </summary>
	public class DrawEventArgs : EventArgs
	{
	}
}