class AwesomeSeqAct_SpawnerActivation extends SequenceAction;

event Activated()
{
    if(AwesomeGame(GetWorldInfo().Game) != none)
        AwesomeGame(GetWorldInfo().Game).ActivateSpawners();
}

defaultproperties
{
    ObjName="Spawner Activation"
    ObjCategory="Awesome Game"
    VariableLinks.Empty
}
