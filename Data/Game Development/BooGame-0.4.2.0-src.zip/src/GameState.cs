/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using BooGame.Gui;

namespace BooGame
{
    /// <summary>
    /// Represents a game state.
    /// </summary>
    /// <remarks>Use Core.Game to switch the current game state.</remarks>
    /// <seealso cref="Core.Game"/>
	[Serializable]
    public class GameState : State
    {
		private EntityCollection m_Entities = new EntityCollection();
        /// <summary>
        /// All entities assosiated with this game state.
        /// </summary>
		public EntityCollection Entities
		{
			get{ return m_Entities; }
		}

        /// <summary>
        /// Gets and sets an entity associated with this game state.
        /// </summary>
        /// <param name="index">The index of the desired entity.</param>
        /// <returns>The entity at the given index.</returns>
		public Entity this[int index]
		{
            get { return m_Entities[index]; }
            set { m_Entities[index] = value; }
		}

        private GuiManager m_Gui = new GuiManager();
        /// <summary>
        /// The graphical user interface to be used with this game state.
        /// </summary>
        public GuiManager Gui
        {
            get { return m_Gui; }
            set
            {
                m_Gui = (value == null) ? new GuiManager() : value;
            }
        }

        /// <summary>
        /// Draws all entities and GUI elements for the game state.
        /// </summary>
		public virtual void Draw()
		{
			foreach(Entity entity in m_Entities)
				entity.Draw();
            m_Gui.Draw();

            if (OnDraw != null)
                OnDraw(this, new DrawEventArgs());
		}


        /// <summary>
        /// Updates all entities and GUI elements for the game state.
        /// </summary>
		public override void Update()
		{
			foreach(Entity entity in m_Entities)
				entity.Update();
            m_Gui.Update();

            base.Update();
		}

        public virtual void KeyDown(KeyboardEventArgs args)
        {
            if (OnKeyDown != null)
                OnKeyDown(this, args);
        }
        public virtual void KeyUp(KeyboardEventArgs args)
        {
            if (OnKeyUp != null)
                OnKeyUp(this, args);
        }
        public virtual void MouseMotion(MouseEventArgs args)
        {
            if (OnMouseMotion != null)
                OnMouseMotion(this, args);
        }
        public virtual void MouseButtonUp(MouseEventArgs args)
        {
            if (OnMouseButtonUp != null)
                OnMouseButtonUp(this, args);
        }
        public virtual void MouseButtonDown(MouseEventArgs args)
        {
            if (OnMouseButtonDown != null)
                OnMouseButtonDown(this, args);
        }
        public virtual void MouseWheel(MouseEventArgs args)
        {
            if (OnMouseWheel != null)
                OnMouseWheel(this, args);
        }
        public virtual void JoystickButtonUp(JoystickEventArgs args)
        {
            if (OnJoystickButtonUp != null)
                OnJoystickButtonUp(this, args);
        }
        public virtual void JoystickButtonDown(JoystickEventArgs args)
        {
            if (OnJoystickButtonDown != null)
                OnJoystickButtonDown(this, args);
        }
        public virtual void JoystickAxisMovement(JoystickEventArgs args)
        {
            if (OnJoystickAxisMovement != null)
                OnJoystickAxisMovement(this, args);
        }
        public virtual void Quit(QuitEventArgs args) 
        {
            if (OnQuit != null)
                OnQuit(this, args);
        }

        #region Events
        public event KeyboardEventHandler OnKeyDown;
        public event KeyboardEventHandler OnKeyUp;
        public event MouseEventHandler OnMouseMotion;
        public event MouseEventHandler OnMouseButtonUp;
        public event MouseEventHandler OnMouseButtonDown;
        public event MouseEventHandler OnMouseWheel;
        public event JoystickEventHandler OnJoystickButtonUp;
        public event JoystickEventHandler OnJoystickButtonDown;
        public event JoystickEventHandler OnJoystickAxisMovement;
        public event QuitEventHandler OnQuit;
        public event DrawEventHandler OnDraw;
        #endregion Events
    }
}