Attribute VB_Name = "gleExtrusionsRoundCut"
Option Explicit
'-------------------------------------------------------------------------==
'
' * MODULE NAME: ex_cut_round.c
' *
' * FUNCTION:
' * This module contains code that draws extrusions with cut or round
' * join styles. The cut join style is a beveled edge.
' * The code also inserts colors and normals if appropriate.
' *
' * HISTORY:
' * written by Linas Vepstas August/September 1991
' * split into multiple compile units, Linas, October 1991
' * added normal vectors Linas, October 1991
' * Fixed filleting problem, Linas February 1993
' * Modified to handle round joins as well (based on common code),
' *                           Linas, March 1993
' * work around OpenGL's lack of support for concave polys, June 1994
'
'-------------------------------------------------------------------------
'FUNCTION:
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
'typedef void (*gleCapCallback) (int iloop,
'                                double cap[][3],
'                                float face_color[3],
'                                gleDouble cut_vector[3],
'                                gleDouble bisect_vector[3],
'                                double norms[][3],
'                                int frontwards);
Private Enum CapCallbackConstants
    cc_CutStyle = 1
    cc_RoundStyle = 2
    cc_NullCap = 10
End Enum

Private Sub m_CapCallback(gc As gleGC, iloop&, cap() As gleVector, face_colorPtr&, _
            cut_vector#(), cut_vectorFlag&, bisect_vector#(), _
            norms() As gleVector, normIndex&, frontwards As Boolean, _
            which As CapCallbackConstants)
    Select Case which
    Case cc_CutStyle
            m_DrawCutStyleCapCallback gc, iloop, cap, face_colorPtr, _
                cut_vector, cut_vectorFlag, bisect_vector, _
                norms, normIndex&, frontwards
    Case cc_RoundStyle
            m_DrawRoundStyleCapCallback gc, iloop, cap, face_colorPtr, _
                cut_vector, cut_vectorFlag, bisect_vector, _
                norms, normIndex&, frontwards
    Case cc_NullCap
    'no op
    Case Else: Debug.Assert 0
End Select
End Sub

'-------------------------------------------------------------------------==
' This routine draws "cut" style extrusions.
'public sub extrusion_round_or_cut_join (ncp&,  ' number of contour points
'                           gleDouble contour()(2),  ' 2D contour
'                           gleDouble cont_normal()(2),' 2D normal vecs
'                           gleDouble up(3), ' up vector for contour
'                           int npoints,     ' numpoints in poly-line
'                           gleDouble point_array()(3),  ' polyline
'                           float color_array()(3),  ' color of polyline
'                           gleDouble xform_array()(2)(3))   ' 2D contour xforms
'-------------------------------------------------------------------------==
Public Sub ExtrusionRoundOrCutJoin(gc As gleGC)
Dim i&, j&, inext&, inextnext&
Dim ma#(0 To 15)
Dim tube_lng#, seg_lng#
Dim diff#(0 To 2)
Dim bi_0#(0 To 2), bi_1#(0 To 2)     ' bisecting plane
Dim bisector_0#(0 To 2), bisector_1#(0 To 2)      ' bisecting plane
Dim cut_0#(0 To 2), cut_1#(0 To 2)    ' cutting planes
Dim lcut_0#(0 To 2), lcut_1#(0 To 2)  ' cutting planes
Dim valid_cut_0&, valid_cut_1&    ' flag -- cut vector is valid
Dim end_point_0#(0 To 2), end_point_1#(0 To 2)
Dim torsion_point_0#(0 To 2), torsion_point_1#(0 To 2)
Dim isect_point#(0 To 2)
Dim origin#(0 To 2), neg_z#(0 To 2)
Dim yup#(0 To 2)        ' alternate up vector
'Dim cap_callback As CapCallbackConstants
Dim CapCallbackFunc As CapCallbackConstants
Dim tmp_cap_callback As CapCallbackConstants
Dim dot#                 ' partial dot product
Dim first_time&
Dim cut_vecFlag& 'indicates if vector is null
Dim norm_loopPtr& ', tmpPtr& ' normal vectors, cast into 3d from 2d
'Dim front_colorPtr&, back_colorPtr&  ' pointers to segment colors
'
Dim m_Norm() As gleVector
Dim front_normPtr&, back_normPtr& ' arrays containing normal vecs
Dim front_loop() As gleVector ' arrays containing the tube ends
Dim back_loop() As gleVector
Dim frontcap() As gleVector ' arrays containing the end caps
Dim back_cap() As gleVector
Dim front_is_trimmed() As Boolean
Dim back_is_trimmed() As Boolean
Dim tmpPtr&
norm_loopPtr = -1
With gc
    first_time = True
       ' malloc the data areas that we'll need to store the end-caps
    '   mem_anchor = malloc (4 * 3*ncp*sizeof(gleDouble)
    '                      + 2 * 3*ncp*sizeof(double)
    '                      + 2 * 1*ncp*sizeof(int));
    '   front_norm = (double *) mem_anchor;
    '   back_norm = front_norm + 3*ncp;
    ReDim m_Norm(0 To 2 * .ncp - 1) As gleVector
    ReDim front_loop(0 To .ncp - 1) As gleVector
    ReDim back_loop(0 To .ncp - 1) As gleVector
    ReDim frontcap(0 To .ncp - 1) As gleVector
    ReDim back_cap(0 To .ncp) As gleVector
    ReDim front_is_trimmed(0 To .ncp - 1) As Boolean
    ReDim back_is_trimmed(0 To .ncp - 1) As Boolean
    back_normPtr = .ncp
    ' choose the right callback, depending on the choosen join style
    If gc.JoinStyle = gleCUT Then
        CapCallbackFunc = cc_CutStyle 'm_DrawCutStyleCapCallback
    Else
        CapCallbackFunc = cc_RoundStyle 'm_DrawRoundStyleCapCallback
    End If
    ' By definition, the contour passed in has its up vector pointing in
    ' * the y direction
    V3Copyd yup, .up
    
    ' ========== "up" vector sanity check ==========
    UpSanityCheck yup, .npoints, .point_array

    ' the origin is at the origin
    origin(0) = 0
    origin(1) = 0
    origin(2) = 0
    
    ' and neg_z is at neg z
    neg_z(0) = 0
    neg_z(1) = 0
    neg_z(2) = 1
    
    ' =======================================
    ' |-|-|-|-|-|-|-|-| SET UP FOR FIRST SEGMENT |-|-|-|-|-|-|-|
    
    ' ignore all segments of zero length
    i = 1
    inext = i
    FIND_NON_DEGENERATE_POINT inext, .npoints, seg_lng, diff, .point_array
    tube_lng = seg_lng ' store for later use
    
    ' may as well get the normals set up now
    If gc.ncnormals Then
        If gc.nxforms = 0 Then
            For j = 0 To .ncp - 1
                norm_loopPtr = front_normPtr
                back_normPtr = norm_loopPtr
                m_Norm(j).v(0) = .cont_normal(j).v(0)
                m_Norm(j).v(1) = .cont_normal(j).v(1)
                m_Norm(j).v(2) = 0
            Next
        Else
            For j = 0 To .ncp - 1
                NORM_XFORM_2X2 m_Norm(j).v, _
                              .xform_array(inext - 1), _
                              .cont_normal(j).v
                m_Norm(j).v(2) = 0
                m_Norm(back_normPtr + j).v(2) = 0
            Next
        End If
    Else '
        front_normPtr = -1 'Null
        back_normPtr = -1 '
        norm_loopPtr = -1 'Null
    End If

    ' get the bisecting plane
    BISECTING_PLANE3v bi_0, .point_array(i - 1).v, _
                          .point_array(i).v, _
                          .point_array(inext).v

    ' compute cutting plane
    CUTTING_PLANE valid_cut_0, cut_0, .point_array(i - 1).v, _
                         .point_array(i).v, _
                         .point_array(inext).v
   
    ' reflect the up vector in the bisecting plane
    V3Reflectd yup, yup, bi_0

    ' |-|-|-|-|-|-|-|-| START LOOP OVER SEGMENTS |-|-|-|-|-|-|-|

    ' draw tubing, not doing the first segment
    Do While (inext < .npoints - 1)
        inextnext = inext
        ' ignore all segments of zero length
        FIND_NON_DEGENERATE_POINT inextnext, .npoints, _
                                 seg_lng, diff, .point_array

        ' get the far bisecting plane
        BISECTING_PLANE3v bi_1, .point_array(i).v, _
                             .point_array(inext).v, _
                             .point_array(inextnext).v


        ' compute cutting plane
        CUTTING_PLANE valid_cut_1, cut_1, .point_array(i).v, _
                            .point_array(inext).v, _
                            .point_array(inextnext).v

        ' rotate so that z-axis points down v2-v1 axis,
        ' * and so that origen is at v1
        uviewpoint_d ma, .point_array(i).v, .point_array(inext).v, yup
        glPushMatrix
        glMultMatrixd ma(0)

        ' rotate the cutting planes into the local coordinate system
        MatDotVectord lcut_0, ma, cut_0
        MatDotVectord lcut_1, ma, cut_1
        ' rotate the bisecting planes into the local coordinate system
        MatDotVectord bisector_0, ma, bi_0
        MatDotVectord bisector_1, ma, bi_1
        neg_z(2) = -tube_lng

        ' draw the tube
        ' --------- START OF TMESH GENERATION --------------
        For j = 0 To .ncp - 1

            ' set up the endpoints for segment clipping
            If gc.nxforms = 0 Then
                V2Copyd end_point_0, .contour(j).v
                V2Copyd end_point_1, .contour(j).v
                V2Copyd torsion_point_0, .contour(j).v
                V2Copyd torsion_point_1, .contour(j).v
            Else
                ' transform the contour points with the local xform
                MatDotVectorAd end_point_0, _
                             .xform_array(inext - 1), _
                             .contour(j).v
                MatDotVectorAd torsion_point_0, _
                             .xform_array(inext), _
                             .contour(j).v
                MatDotVectorAd end_point_1, _
                             .xform_array(inext), _
                             .contour(j).v
                MatDotVectorAd torsion_point_1, _
                             .xform_array(inext - 1), _
                             .contour(j).v

                ' if there are normals and there are affine xforms,
                ' * then compute local coordinate system normals.
                ' * Set up the back normals. (The front normals we inherit
                ' * from previous pass through the loop).
                If gc.ncnormals Then
                    ' do up the normal vectors with the inverse transpose
                    NORM_XFORM_2X2 m_Norm(back_normPtr + j).v, _
                                .xform_array(inext), _
                                .cont_normal(j).v
                End If
            End If
            end_point_0(2) = 0
            torsion_point_0(2) = 0
            end_point_1(2) = -tube_lng
            torsion_point_1(2) = -tube_lng

            ' The two end-points define a line.  Intersect this line
            ' against the clipping plane defined by the PREVIOUS
            ' tube segment.

            ' if this and the last tube are co-linear, don't cut the angle
            ' if you do, a divide by zero will result.  This and last tube
            ' are co-linear when the cut vector is of zero length
            If (valid_cut_0 And gc.JoinStyle = gleCUT) Then
'               INNERSECT isect_point,  ' isect point (returned)
'                       origin,      ' point on intersecting plane
'                       lcut_0,      ' normal vector to plane
'                       end_point_0, ' point on line
'                       end_point_1);    ' another point on the line
                INNERSECT isect_point, origin, lcut_0, end_point_0, end_point_1

                ' determine whether the raw end of the extrusion would have
                ' * been cut, by checking to see if the raw end is on the
                ' * far end of the half-plane defined by the cut vector.
                ' * If the raw end is not "cut", then it is "trimmed".
                If (lcut_0(2) < 0) Then
                    V3Scaled lcut_0, -1, lcut_0
                End If
                dot = lcut_0(0) * end_point_0(0)
                dot = dot + lcut_0(1) * end_point_0(1)
    
                V3Copyd front_loop(j).v, isect_point
            Else
                ' actual value of dot not interseting; need
                ' * only be positive so that if test below fails
                dot = 1
                V3Copyd front_loop(j).v, end_point_0
            End If

'           INNERSECT isect_point,    ' intersection point (returned)
'                    origin,     ' point on intersecting plane
'                    bisector_0,     ' normal vector to plane
'                    end_point_0,    ' point on line
'                    torsion_point_1);   ' another point on the line
            INNERSECT isect_point, origin, bisector_0, end_point_0, torsion_point_1
            ' trim out interior of intersecting tube
            ' ... but save the untrimmed version for drawing the endcaps
            ' ... note that cap contains valid data ONLY when is_trimmed
            ' * is TRUE.
            If ((dot <= 0) Or (isect_point(2) < front_loop(j).v(2))) Then
                V3Copyd frontcap(j).v, front_loop(j).v
                V3Copyd front_loop(j).v, isect_point
                front_is_trimmed(j) = True
            Else
                front_is_trimmed(j) = False
            End If

            ' if intersection is behind the end of the segment,
            '* truncate to the end of the segment
            '* Note that coding front_loop (3*j+2) = -tube_lng;
            '* doesn't work when twists are involved,
            If front_loop(j).v(2) < -tube_lng Then
                V3Copyd front_loop(j).v, end_point_1
            End If

            ' ---------------------------------------------------
            ' The two end-points define a line.  We did one endpoint
            ' * above. Now do the other.Intersect this line
            ' * against the clipping plane defined by the NEXT
            ' * tube segment.

            ' if this and the last tube are co-linear, don't cut the angle
            ' * if you do, a divide by zero will result.  This and last tube
            ' * are co-linear when the cut vector is of zero length
            If (valid_cut_1 And gc.JoinStyle = gleCUT) Then
'               INNERSECT isect_point,  ' isect point (returned)
'                       neg_z,       ' point on intersecting plane
'                       lcut_1,      ' normal vector to plane
'                       end_point_1, ' point on line
'                       end_point_0);    ' another point on the line
                INNERSECT isect_point, neg_z, lcut_1, end_point_1, end_point_0

                If (lcut_1(2) > 0) Then
                    V3Scaled lcut_1, -1, lcut_1
                End If
                dot = lcut_1(0) * end_point_1(0)
                dot = dot + lcut_1(1) * end_point_1(1)
                V3Copyd back_loop(j).v, isect_point
            Else
                ' actual value of dot not interseting; need
                ' * only be positive so that if test below failes
                dot = 1
                V3Copyd back_loop(j).v, end_point_1
            End If

'           INNERSECT isect_point,    ' intersection point (returned)
'                    neg_z,      ' point on intersecting plane
'                    bisector_1,     ' normal vector to plane
'                    torsion_point_0,    ' point on line
'                    end_point_1);   ' another point on the line
            INNERSECT isect_point, neg_z, bisector_1, torsion_point_0, end_point_1

            ' cut out interior of intersecting tube
            ' ... but save the uncut version for drawing the endcaps
            ' ... note that cap contains valid data ONLY when is
            ' *_trimmed is TRUE.
            If (dot <= 0) Or (isect_point(2) > back_loop(j).v(2)) Then
                V3Copyd back_cap(j).v, back_loop(j).v
                V3Copyd back_loop(j).v, isect_point
                back_is_trimmed(j) = True
            Else
                back_is_trimmed(j) = False
            End If

            ' if intersection is behind the end of the segment,
            ' * truncate to the end of the segment
            ' * Note that coding back_loop (3*j+2) = 0;
            ' * doesn't work when twists are involved,
            If back_loop(j).v(2) > 0 Then
                V3Copyd back_loop(j).v, end_point_0
            End If
        Next

        ' --------- END OF TMESH GENERATION --------------

        ' |||||||||||||||||| START SEGMENT DRAW ||||||||||||||||||||
        ' There are six different cases we can have for presence and/or
        ' * absecnce of colors and normals, and for interpretation of
        ' * normals. The blechy set of nested if statements below
        ' * branch to each of the six cases
        'color_arraySize = ArraySize(color_array)
        If gc.nxforms = 0 Then
            If gc.ncolors = 0 Then
                If gc.ncnormals = 0 Then
                    draw_segment_plain gc, .ncp, front_loop, 0, _
                        back_loop, 0, inext, seg_lng
                ElseIf gc.NormStyle And gleFACET Then
                    draw_segment_facet_n gc, .ncp, front_loop, 0, _
                        back_loop, 0, _
                        m_Norm, norm_loopPtr, _
                                     inext, seg_lng
                Else
                    draw_segment_edge_n gc, .ncp, front_loop, 0, _
                            back_loop, 0, _
                            m_Norm, norm_loopPtr, _
                                    inext, seg_lng
                End If
            Else
                If gc.ncnormals = 0 Then
                    draw_segment_color gc, .ncp, front_loop, 0, _
                            back_loop, 0, _
                                   .color_array(inext - 1).v, _
                                   .color_array(inext).v, _
                                   inext, seg_lng
                ElseIf gc.NormStyle And gleFACET Then
                    draw_segment_c_and_facet_n gc, .ncp, _
                            front_loop, 0, _
                            back_loop, 0, _
                            m_Norm, norm_loopPtr, _
                            .color_array(inext - 1).v, _
                            .color_array(inext).v, _
                            inext, seg_lng
                Else
                    draw_segment_c_and_edge_n gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                            m_Norm, norm_loopPtr, _
                                   .color_array(inext - 1).v, _
                                   .color_array(inext).v, inext, seg_lng
                End If
            End If
        Else
            If gc.ncolors = 0 Then
                If gc.ncnormals = 0 Then
                    draw_segment_plain gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                            inext, seg_lng
                ElseIf gc.NormStyle And gleFACET Then
                    draw_binorm_segment_facet_n gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                            m_Norm, front_normPtr, _
                            m_Norm, back_normPtr, _
                            inext, seg_lng
                Else
                    draw_binorm_segment_edge_n gc, .ncp, _
                             front_loop, 0, _
                              back_loop, 0, _
                            m_Norm, front_normPtr, _
                            m_Norm, back_normPtr, _
                            inext, seg_lng
                End If
            Else
                If gc.ncnormals = 0 Then
                    draw_segment_color gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                            .color_array(inext - 1).v, _
                            .color_array(inext).v, inext, seg_lng
                ElseIf gc.NormStyle And gleFACET Then
                    draw_binorm_segment_c_and_facet_n gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                            m_Norm, front_normPtr, _
                            m_Norm, back_normPtr, _
                            .color_array(inext - 1).v, _
                            .color_array(inext).v, inext, seg_lng
                Else
                    draw_binorm_segment_c_and_edge_n gc, .ncp, _
                             front_loop, 0, _
                             back_loop, 0, _
                             m_Norm, front_normPtr, _
                            m_Norm, back_normPtr, _
                            .color_array(inext - 1).v, _
                            .color_array(inext).v, inext, seg_lng
                End If
            End If
        End If
        ' |||||||||||||||||| END SEGMENT DRAW ||||||||||||||||||||

        ' v^v^v^v^v^v^v^v^v  BEGIN END CAPS v^v^v^v^v^v^v^v^v^v^v^v

        ' if end caps are required, draw them. But don't draw any
        ' * but the very first and last caps
        If (first_time) Then
            first_time = False
            tmp_cap_callback = CapCallbackFunc
            CapCallbackFunc = cc_NullCap
            If gc.CapStyle = gleCAPS Then
                If gc.ncolors Then
                    glColor3fv .color_array(inext - 1).v(0)
                End If
                draw_angle_style_front_cap gc, .ncp, bisector_0, front_loop, 0
            End If
        End If
        ' v^v^v^v^v^v^v^v^v  END END CAPS v^v^v^v^v^v^v^v^v^v^v^v

      ' $$$$$$$$$$$$$$$$ BEGIN -1, FILLET & JOIN DRAW $$$$$$$$$$$$$$$$$
      '
      ' * Now, draw the fillet triangles, and the join-caps.
      '
      Dim f_colorPtr&, b_colorPtr&
      If gc.ncolors Then
         f_colorPtr = (inext - 1) 'color_array
         b_colorPtr = (inext) 'color_array
      Else
        'Stop
         f_colorPtr = -1 'Null
         b_colorPtr = -1 ' Null
      End If

      If gc.ncnormals = 0 Then
         ' the flag valid-cut is true if the cut vector has a valid
         ' * value (i.e. if a degenerate case has not occured).
         '
         If (valid_cut_0) Then
            cut_vecFlag = True 'lcut_0
         Else
            cut_vecFlag = 0 'Null
         End If
         m_DrawFilletsAndJoin_Plain gc, front_loop, frontcap, front_is_trimmed, _
                origin, bisector_0, f_colorPtr, b_colorPtr, _
                lcut_0, cut_vecFlag, True, CapCallbackFunc
         ' v^v^v^v^v^v^v^v^v  BEGIN END CAPS v^v^v^v^v^v^v^v^v^v^v^v
         If (inext = .npoints - 2) Then
            If gc.CapStyle = gleCAPS Then
               If gc.ncolors Then
                    glColor3fv .color_array(inext).v(0)
                End If
               draw_angle_style_back_cap gc, .ncp, bisector_1, back_loop, 0
               CapCallbackFunc = cc_NullCap
            End If
         Else
            ' restore ability to draw cap
            CapCallbackFunc = tmp_cap_callback
         End If
         ' v^v^v^v^v^v^v^v^v  END END CAPS v^v^v^v^v^v^v^v^v^v^v^v
   
         ' the flag valid-cut is true if the cut vector has a valid
         ' * value (i.e. if a degenerate case has not occured).
         '
         If (valid_cut_1) Then
            cut_vecFlag = True 'lcut_1
         Else
            cut_vecFlag = 0 ' = Null
         End If
         m_DrawFilletsAndJoin_Plain gc, _
                back_loop, back_cap, back_is_trimmed, neg_z, _
                bisector_1, b_colorPtr, f_colorPtr, lcut_1, cut_vecFlag, _
                False, CapCallbackFunc
      Else
   
         ' the flag valid-cut is true if the cut vector has a valid
         ' * value (i.e. if a degenerate case has not occured).
         '
         If (valid_cut_0) Then
            cut_vecFlag = True 'lcut_0
         Else
            cut_vecFlag = 0 ' Null
         End If
         m_DrawFilletsAndJoin_N_Norms gc, .ncp, front_loop, 0, _
                frontcap, 0, front_is_trimmed, 0, _
                origin, bisector_0, _
                m_Norm, front_normPtr, _
                f_colorPtr, b_colorPtr, lcut_0, cut_vecFlag, True, CapCallbackFunc
   
         ' v^v^v^v^v^v^v^v^v  BEGIN END CAPS v^v^v^v^v^v^v^v^v^v^v^v
         If (inext = .npoints - 2) Then
            If gc.CapStyle = gleCAPS Then
               If Not gc.ncolors = 0 Then
                    glColor3fv .color_array(inext).v(0)
                End If
               draw_angle_style_back_cap gc, .ncp, bisector_1, back_loop, 0
               CapCallbackFunc = cc_NullCap
            End If
         Else
            ' restore ability to draw cap
            CapCallbackFunc = tmp_cap_callback
         End If
         ' v^v^v^v^v^v^v^v^v  END END CAPS v^v^v^v^v^v^v^v^v^v^v^v

         ' the flag valid-cut is true if the cut vector has a valid
         ' * value (i.e. if a degenerate case has not occured).
         '
         If (valid_cut_1) Then
            cut_vecFlag = True ' lcut_1
         Else
            cut_vecFlag = 0 'Null
         End If
         m_DrawFilletsAndJoin_N_Norms gc, .ncp, _
                         back_loop, 0, _
                         back_cap, 0, _
                         back_is_trimmed, 0, _
                        neg_z, _
                        bisector_1, _
                        m_Norm, back_normPtr, _
                        b_colorPtr, _
                        f_colorPtr, _
                        lcut_1, cut_vecFlag, _
                        False, CapCallbackFunc
      End If

      ' $$$$$$$$$$$$$$$$ END FILLET & JOIN DRAW $$$$$$$$$$$$$$$$$

      ' pop this matrix, do the next set
      glPopMatrix

      ' slosh stuff over to next vertex
      tmpPtr = front_normPtr
      front_normPtr = back_normPtr
      back_normPtr = tmpPtr

      tube_lng = seg_lng
      i = inext
      inext = inextnext
      V3Copyd bi_0, bi_1
      V3Copyd cut_0, cut_1
      valid_cut_0 = valid_cut_1

      ' reflect the up vector in the bisecting plane
      V3Reflectd yup, yup, bi_0
   Loop
   ' |-|-|-|-|-|-|-|-| END LOOP OVER SEGMENTS |-|-|-|-|-|-|-|

   'free (mem_anchor);
End With
End Sub


Private Sub m_DrawCutStyleCapCallback(gc As gleGC, iloop&, cap() As gleVector, face_colorPtr&, _
            cut_vector#(), cut_vectorFlag&, _
            bisect_vector#(), norms() As gleVector, normIndex&, _
            frontwards As Boolean)
Dim i&, is_colinear&
Dim previous_vertex& '   double *previous_vertex = &H0;
Dim first_vertex& '   double *first_vertex = &H0;
Dim tObj&
    tObj = gluNewTess
    'todo - see if setting this is required
    gluTessCallback tObj, GLU_BEGIN, AddressOf gleBegin
    gluTessCallback tObj, GLU_VERTEX, AddressOf gleVertex3dv
    gluTessCallback tObj, GLU_END, AddressOf gleEnd

    If gc.ncolors Then
        glColor3fv gc.color_array(face_colorPtr).v(0)
    End If

    If frontwards Then
        ' if lighting is on, specify the endcap normal
        If cut_vectorFlag <> 0 Then
            ' if normal pointing in wrong direction, flip it.
            If (cut_vector(2) < 0) Then
                V3Scaled cut_vector, -1, cut_vector
            End If
            N3F gc, cut_vector
        End If

        ' If you have a tesselator that is happy with anything,
        ' * including degenerate points, colinear segments, etc.
        ' * then define this. Otherwise, pick one of the others.
        ' *
        ' * I beleive that the stock SGI tesselator is "lenient",
        ' * despite explicit disclaimers in the documentation.
        ' * (circa 1995).
        ' *
        ' * The Mesa tesselator is not at all forgiving of
        ' * degenerate points.
        ' * (circa 1997-1998)
        '
       ' Stop
        '#If LENIENT_TESSELATOR Then
'            gluTessBeginPolygon tObj, 0
'                gluTessBeginContour tObj
'                    For i = 0 To iloop - 1
'                       gluTessVertex tObj, cap(i).v(0), cap(i).v(0)
'                    Next
'                gluTessEndContour tObj
'            gluTessEndPolygon tObj
        '#End If ' LENIENT_TESSELATOR

        '#If DELICATE_TESSELATOR Then
        gluBeginPolygon tObj
        first_vertex = &H0
        previous_vertex = iloop - 1
        For i = 0 To iloop - 2
           COLINEAR is_colinear, cap(previous_vertex).v, cap(i).v, cap(i + 1).v
           If (is_colinear = 0) Then
              gluTessVertex tObj, cap(i).v(0), cap(i).v(0)
              previous_vertex = i
              If (first_vertex = 0) Then
                  first_vertex = previous_vertex
              End If
           End If
        Next
        
'        If first_vertex = 0 Then
'            first_vertex = cap(0)
'        End If
        COLINEAR is_colinear, cap(previous_vertex).v, cap(iloop - 1).v, cap(first_vertex).v
        If (is_colinear = 0) Then
              gluTessVertex tObj, cap(iloop - 1).v(0), cap(iloop - 1).v(0)
          End If
        
        gluEndPolygon tObj
        
        '#End If ' DELICATE_TESSELATOR
    Else

        ' if lighting is on, specify the endcap normal
        If cut_vectorFlag <> 0 Then
            ' if normal pointing in wrong direction, flip it.
            If (cut_vector(2) > 0) Then
               V3Scaled cut_vector, -1, cut_vector
            End If
            N3F gc, cut_vector
        End If
        ' the sense of the loop is reversed for backfacing culling

        '#If LENIENT_TESSELATOR Then
'              gluTessBeginPolygon tObj, 0
'                gluTessBeginContour tObj
'                    For i = iloop - 1 To 0 Step -1
'                       gluTessVertex tObj, cap(i).v(0), cap(i).v(0)
'                    Next
'                gluTessEndContour tObj
'              gluTessEndPolygon tObj
        '#End If ' LENIENT_TESSELATOR
        
        '#If DELICATE_TESSELATOR Then
              gluBeginPolygon tObj
        
              first_vertex = &H0
              previous_vertex = 0 ' cap(0)
              For i = iloop - 1 To 1 Step -1
                 COLINEAR is_colinear, cap(previous_vertex).v, cap(i).v, cap(i - 1).v
                 If (is_colinear = 0) Then
                    gluTessVertex tObj, cap(i).v(0), cap(i).v(0)
                    previous_vertex = i 'cap(i)
                    If (first_vertex = 0) Then
                        first_vertex = previous_vertex
                    End If
                 End If
              Next
        
              If (first_vertex = 0) Then
                    first_vertex = iloop - 1 'cap(iloop - 1)
                End If
              COLINEAR is_colinear, cap(previous_vertex).v, cap(0).v, cap(first_vertex).v
              If (is_colinear = 0) Then
                    gluTessVertex tObj, cap(0).v(0), cap(0).v(0)
                End If
              gluEndPolygon tObj
        '#End If ' DELICATE_TESSELATOR

    End If
    gluDeleteTess tObj

End Sub
'#End If ' NONCONCAVE_ENDCAPS


' =================== END OF FILE ===============================

'
' * MODULE NAME: round_cap.c
' *
' * FUNCTION:
' * This module contains code that draws the round end-cap for round
' * join-style tubing.
' *
' * HISTORY:
' * written by Linas Vepstas August/September 1991
' * split into multiple compile units, Linas, October 1991
' * added normal vectors Linas, October 1991
'

'-------------------------------------------------------------------------==
' This routine does what it says: It draws the end-caps for the
' * "round" join style.
'

' HACK ALERT HACK ALERT HACK ALERT HACK ALERT
' This #define should be replaced by some adaptive thingy.
' * the adaptiveness needs to depend on relative angles and diameter of
' * extrusion relative to screen size (in pixels).
'


'public sub draw_round_style_cap_callback (ncp&,
'                                  double cap()(3),
'                                  float face_color(3),
'                                  gleDouble cut(3),
'                                  gleDouble bi(3),
'                                  double norms()(3),
'                                  int frontwards)
Public Sub m_DrawRoundStyleCapCallback(gc As gleGC, ncp&, _
                                  cap() As gleVector, face_colorPtr&, _
                                  cut#(), cut_vectorFlag&, _
                                  bi#(), norms() As gleVector, normIndex&, _
                                  frontwards As Boolean)
Dim Axis#(0 To 2)
Dim xycut#(0 To 2)
Dim theta#
Dim m_Contour() As gleVector
Dim last_contour& '() As gleVector
Dim next_contour& '() As gleVector '*last_contour, *next_contour;
Dim m_Norm() As gleVector
Dim last_norm& '() As gleVector
Dim next_norm& '() As gleVector '   double *last_norm, *next_norm;
Dim cap_z#() ' As gleVector  '# '  double *cap_z;
Dim tmp# '   double *tmp;
'   char *malloced_area;
Dim i&, j&, k&
Dim m#(0 To 15)
Dim normsSize&
    If gc.ncolors Then
        glColor3fv gc.color_array(face_colorPtr).v(0)
    End If
    ' ------------ start setting up rotation matrix -------------
    ' if the cut vector is NULL (this should only occur in
    ' a degenerate case), then we can't draw anything. return.
    If (cut_vectorFlag = 0) Then Exit Sub
    ' make sure that the cut vector points inwards
    If (cut(2) > 0) Then
        V3Scaled cut, -1, cut
    End If
    
    ' make sure that the bi vector points outwards
    If (bi(2) < 0) Then
        V3Scaled bi, -1, bi
    End If

    ' determine the axis we are to rotate about to get bi-contour.
    ' Note that the axis will always lie in the x-y plane
    V3Crossd Axis, cut, bi

    ' reverse the cut vector for the back cap --
    ' need to do this to get angle right
    If (frontwards = 0) Then
        V3Scaled cut, -1, cut
    End If

    ' get angle to rotate by -- arccos of dot product of cut with cut
    ' projected into the x-y plane
    xycut(0) = 0
    xycut(1) = 0
    xycut(2) = 1
    V3Perpd xycut, cut, xycut
    V3Normalized xycut
    V3Dotd theta, xycut, cut

    theta = ArcCosd(theta)

    ' we'll tesselate round joins into a number of teeny pieces
    theta = theta / ROUND_TESS_PIECES

    ' get the matrix
    urot_axis_d m, theta, Axis

    ' ------------ done setting up rotation matrix -------------

    ' This malloc is a fancy version of:
    ' last_contour = (double *) malloc (3*ncp*sizeof(double);
    ' next_contour = (double *) malloc (3*ncp*sizeof(double);
    '/
    'malloced_area = malloc ((4*3+1) *ncp*sizeof (double));
'    last_contour = (double *) malloced_area;
'    next_contour = last_contour + 3 * ncp
    ReDim m_Contour(0 To 2 * ncp - 1)
    next_contour = ncp
    'cap_z = next_contour + 3 * ncp
    ReDim cap_z(0 To ncp - 1)
    ReDim m_Norm(0 To 2 * ncp - 1)
    last_norm = 0 'cap_z + ncp
    next_norm = ncp
    normsSize = ArraySizeV(norms)
    ' make first copy of contour
    If (frontwards) Then
        For j = 0 To ncp - 1
        'last_contour = 0 here
            m_Contour(j).v(0) = cap(j).v(0)
            m_Contour(j).v(1) = cap(j).v(1)
            m_Contour(j).v(2) = cap(j).v(2)
            cap_z(j) = cap(j).v(2)
        Next

        If normsSize Then
            For j = 0 To ncp - 1
                'last_norm = 0 here
                V3Copyd m_Norm(j).v, norms(j).v
            Next
        End If
    Else
        ' in order for backfacing polygon removal to work correctly, have
        ' to have the sense in which the joins are drawn to be reversed
        ' * for the back cap.  This can be done by reversing the order of
        ' * the contour points.  Normals are a bit trickier, since the
        ' * reversal is off-by-one for facet normals as compared to edge
        ' * normals.
        For j = 0 To ncp - 1
            k = ncp - j - 1
            'last_contour = 0
            m_Contour(k).v(0) = cap(j).v(0)
            m_Contour(k).v(1) = cap(j).v(1)
            m_Contour(k).v(2) = cap(j).v(2)
            cap_z(k) = cap(j).v(2)
        Next

        If (normsSize) Then
            If gc.NormStyle And gleFACET Then
                For j = 0 To ncp - 2
                    k = ncp - j - 2
                    'last_norm = 0
                    V3Copyd m_Norm(k).v, norms(j).v
                Next
            Else
                For j = 0 To ncp - 1
                    k = ncp - j - 1
                    'last_norm still = 0
                    V3Copyd m_Norm(k).v, norms(j).v
                Next
            End If
        End If
    End If

    ' &&&&&&&&&&&&&& start drawing cap &&&&&&&&&&&&&

    For i = 0 To ROUND_TESS_PIECES - 1
        For j = 0 To ncp - 1
            m_Contour(next_contour + j).v(2) = _
                    m_Contour(next_contour + j).v(2) - cap_z(j)
            m_Contour(last_contour + j).v(2) = _
                    m_Contour(last_contour + j).v(2) - cap_z(j)
            MatDotVectord m_Contour(next_contour + j).v, m, m_Contour(last_contour + j).v
            m_Contour(next_contour + j).v(2) = m_Contour(next_contour + j).v(2) + cap_z(j)
            m_Contour(last_contour + j).v(2) = m_Contour(last_contour + j).v(2) + cap_z(j)
        Next

        If (normsSize) Then
            For j = 0 To ncp - 1
                MatDotVectord m_Norm(next_norm + j).v, m, m_Norm(last_norm + j).v
            Next
        End If

      ' OK, now render it all
      If normsSize = 0 Then
'         draw_segment_plain ncp, (gleVector *) next_contour, _
'                                  (gleVector *) last_contour, 0, 0
         draw_segment_plain gc, ncp, m_Contour, next_contour, _
                                   m_Contour, last_contour, 0, 0
      ElseIf gc.NormStyle And gleFACET Then
         draw_binorm_segment_facet_n gc, ncp, _
                               m_Contour, next_contour, _
                               m_Contour, last_contour, _
                               m_Norm, next_norm, _
                               m_Norm, last_norm, 0, 0
      Else
         draw_binorm_segment_edge_n gc, ncp, _
                               m_Contour, next_contour, _
                               m_Contour, last_contour, _
                               m_Norm, next_norm, _
                               m_Norm, last_norm, 0, 0
     End If

      ' swap contours
      tmp = next_contour
      next_contour = last_contour
      last_contour = tmp

      tmp = next_norm
      next_norm = last_norm
      last_norm = tmp
   Next
   ' &&&&&&&&&&&&&& end drawing cap &&&&&&&&&&&&&

   ' Thou shalt not leak memory
   'free (malloced_area);
End Sub
' ==================== END OF FILE ===========================

'-------------------------------------------------------------------------==
'Public Static Sub draw_fillets_and_join_plain()
'                    (ncp&,
'                    gleDouble trimmed_loop()(3),
'                    gleDouble untrimmed_loop()(3),
'                    int is_trimmed(),
'                    gleDouble bis_origin(3),
'                    gleDouble bis_vector(3),
'                    float front_color(3),
'                    float back_color(3),
'                    gleDouble cut_vector(3),
'                    int face,
'                    gleCapCallback cap_callback)
'-------------------------------------------------------------------------==
Private Sub m_DrawFilletsAndJoin_Plain(gc As gleGC, _
                    trimmed_loop() As gleVector, _
                    untrimmed_loop() As gleVector, _
                    is_trimmed() As Boolean, _
                    bis_origin#(), _
                    bis_vector#(), _
                    front_colorPtr&, _
                    back_colorPtr&, _
                    cut_vector#(), cut_vectorFlag&, _
                    face As Boolean, _
                    cap_callback&)
Dim istop&
Dim icnt&, icnt_prev&, iloop&
Dim cap_loop() As gleVector
Dim sect#(0 To 2)
Dim tmp_vec#(0 To 2)
Dim c_save_style&
Dim save_style&
Dim was_trimmed As Boolean
Dim dummy_norms() As gleVector
With gc
    'cap_loop = (double *) malloc ((ncp+3)*3*sizeof (double));
    ReDim cap_loop(0 To .ncp + 2)
    '
    ' * If the first point is trimmed, keep going until one
    ' * is found that is not trimmed, and start join there.
    '
    
    icnt = 0
    iloop = 0
    c_save_style = gc.ContourStyle
    If is_trimmed(0) = 0 Then
        ' if the first point on the contour isn't trimmed, go ahead and
        ' * drop an edge down to the bisecting plane, (thus starting the
        ' * join).  (Only need to do this for cut join, its bad if done for
        ' * round join). (Also, do this only for open contours; leads to
        ' * bugs when done for closed contours).
        '
        If gc.JoinStyle = gleCUT And _
              (c_save_style <> gleCLOSED) Then
           V3Sumd tmp_vec, trimmed_loop(0).v, bis_vector
           INNERSECT sect, _
                      bis_origin, _
                      bis_vector, _
                      trimmed_loop(0).v, _
                      tmp_vec
           V3Copyd cap_loop(iloop).v, sect
           iloop = iloop + 1
        End If
        V3Copyd cap_loop(iloop).v, trimmed_loop(0).v
        iloop = iloop + 1
        icnt_prev = icnt
        icnt = icnt + 1
    Else
        ' else, loop until an untrimmed point is found
        was_trimmed = True
        Do While is_trimmed(icnt)
            icnt_prev = icnt
            icnt = icnt + 1
            If icnt >= .ncp Then
                'return;    ' oops - everything was trimmed
                Exit Sub
            End If
        Loop
    End If

    ' Start walking around the end cap.  Every time the end loop is
    ' trimmed, we know we'll need to draw a fillet triangle.  In
    ' addition, after every pair of visibility changes, we draw a cap.
    If gc.ContourStyle = gleCLOSED Then
        istop = .ncp
    Else
        istop = .ncp - 1
    End If

    ' save the join style, and disable a closed contour.
    ' Need to do this so partial contours don't close up.
    gc.ContourStyle = gleOPEN

   'for (; icnt_prev < istop; icnt_prev ++, icnt ++, icnt %= ncp)
    Do While icnt_prev < istop
        ' There are four interesting cases for drawing caps and fillets:
        ' *    1) this & previous point were trimmed.  Don't do anything,
        ' *       advance counter.
        ' *    2) this point trimmed, previous not -- draw fillet, and
        ' *       draw cap.
        ' *    3) this point not trimmed, previous one was -- compute
        ' *       intersection point, draw fillet with it, and save
        ' *       point for cap contour.
        ' *    4) this & previous point not trimmed -- save for endcap.
        ' Case 1 -- noop, just advance pointers
        If is_trimmed(icnt_prev) And is_trimmed(icnt) Then
        ' Case 2 --  Hah! first point! compute intersect & draw fillet!
        ElseIf is_trimmed(icnt_prev) And is_trimmed(icnt) = 0 Then
            ' important note: the array "untrimmed" contains valid
            ' * untrimmed data ONLY when is_trim is TRUE.  Otherwise,
            ' * only "trim" containes valid data
            ' compute intersection
            INNERSECT sect, bis_origin, bis_vector, _
                       untrimmed_loop(icnt_prev).v, trimmed_loop(icnt).v
            ' Draw Fillet
            m_DrawFilletTrianglePlain gc, trimmed_loop(icnt_prev).v, _
                        trimmed_loop(icnt).v, sect, face, _
                        front_colorPtr, back_colorPtr
            V3Copyd cap_loop(iloop).v, sect
            iloop = iloop + 1
            V3Copyd cap_loop(iloop).v, trimmed_loop(icnt).v
            iloop = iloop + 1
        ' Case 3 -- add to collection of points
        ElseIf is_trimmed(icnt_prev) = 0 And is_trimmed(icnt) = 0 Then
            V3Copyd cap_loop(iloop).v, trimmed_loop(icnt).v
            iloop = iloop + 1
        ' Case 4 -- Hah! last point!  draw fillet & draw cap!
        ElseIf is_trimmed(icnt_prev) = 0 And is_trimmed(icnt) Then
            was_trimmed = True
            ' important note: the array "untrimmed" contains valid
            ' * untrimmed data ONLY when is_trim is TRUE.  Otherwise,
            ' * only "trim" containes valid data
            ' compute intersection
            INNERSECT sect, bis_origin, bis_vector, _
                       trimmed_loop(icnt_prev).v, untrimmed_loop(icnt).v
            ' Draw Fillet
            m_DrawFilletTrianglePlain gc, trimmed_loop(icnt_prev).v, _
                        trimmed_loop(icnt).v, sect, face, _
                        front_colorPtr, back_colorPtr

            V3Copyd cap_loop(iloop).v, sect
            iloop = iloop + 1

            ' draw cap
            If (iloop >= 3) Then
                   m_CapCallback gc, iloop, cap_loop, front_colorPtr, _
                            cut_vector, cut_vectorFlag, _
                            bis_vector, dummy_norms, 0, face, cap_callback
            End If
            ' reset cap counter
            iloop = 0
        End If
        icnt_prev = icnt_prev + 1
        icnt = icnt + 1
        icnt = icnt Mod .ncp
    Loop

    ' now, finish up in the same way that we started.  If the last
    ' point of the contour is visible, drop an edge to the bisecting
    ' plane, thus finishing the join, and then, draw the join!
    
    icnt = icnt - 1 ' decrement to make up for loop exit condititons
    icnt = icnt + .ncp
    icnt = icnt Mod .ncp
    If is_trimmed(icnt) = 0 And (iloop >= 2) Then
   
        V3Sumd tmp_vec, trimmed_loop(icnt).v, bis_vector
        INNERSECT sect, bis_origin, bis_vector, trimmed_loop(icnt).v, tmp_vec
        V3Copyd cap_loop(iloop).v, sect
        iloop = iloop + 1

        ' if nothing was ever trimmed, then we want to draw the
        ' * cap the way the user asked for it -- closed or not closed.
        ' * Therefore, reset the closure flag to its original state.
        '
        If was_trimmed = 0 Then
            gc.ContourStyle = c_save_style
        End If
        ' draw cap
        m_CapCallback gc, iloop, cap_loop, front_colorPtr, _
                cut_vector, cut_vectorFlag, bis_vector, _
                       dummy_norms, 0, face, cap_callback
   End If
   ' rest to the saved style
   gc.ContourStyle = c_save_style
End With
End Sub

'-------------------------------------------------------------------------==
'Public Sub draw_fillets_and_join_n_norms()
'                    (ncp&,
'                    gleDouble trimmed_loop()(3),
'                    gleDouble untrimmed_loop()(3),
'                    int is_trimmed(),
'                    gleDouble bis_origin(3),
'                    gleDouble bis_vector(3),
'                    double normals()(3),
'                    float front_color(3),
'                    float back_color(3),
'                    gleDouble cut_vector(3),
'                    int face,
'                    gleCapCallback cap_callback)
'-------------------------------------------------------------------------==
Private Sub m_DrawFilletsAndJoin_N_Norms(gc As gleGC, ncp&, _
                    trimmed_loop() As gleVector, tlIndex&, _
                    untrimmed_loop() As gleVector, utlIndex&, _
                    is_trimmed() As Boolean, itIndex&, _
                    bis_origin#(), _
                    bis_vector#(), _
                    normals() As gleVector, nIndex&, _
                    front_colorPtr&, _
                    back_colorPtr&, _
                    cut_vector#(), cut_vectorFlag&, _
                    face As Boolean, _
                    cap_callback&) ' As gleCapCallback)
Dim istop&, icnt&, icnt_prev&, iloop&
Dim cap_loop() As gleVector
Dim norm_loop() As gleVector ' double *cap_loop, *norm_loop;
Dim sect#(0 To 2)
Dim tmp_vec#(0 To 2)
Dim c_save_style&
Dim was_trimmed&
    'cap_loop = (double *) malloc ((ncp+3)*3*2*sizeof (double));
    ReDim cap_loop(0 To ncp + 2)
    ReDim norm_loop(0 To ncp + 2)
    '
    ' * If the first point is trimmed, keep going until one
    ' * is found that is not trimmed, and start join there.
    '
    icnt = 0
    iloop = 0
    c_save_style = gc.ContourStyle
    If is_trimmed(tlIndex) = 0 Then
        ' if the first point on the contour isn't trimmed, go ahead and
        ' * drop an edge down to the bisecting plane, (thus starting the
        ' * join).  (Only need to do this for cut join, its bad if done for
        ' * round join).  (Also, leads to bugs when done for closed
        ' * contours ... do this only if contour is open).
        '
        If gc.JoinStyle = gleCUT And _
            c_save_style <> gleCLOSED Then
            V3Sumd tmp_vec, trimmed_loop(tlIndex).v, bis_vector
            INNERSECT sect, bis_origin, bis_vector, _
                      trimmed_loop(tlIndex).v, tmp_vec
            V3Copyd cap_loop(iloop).v, sect
            V3Copyd norm_loop(iloop).v, normals(nIndex).v
            iloop = iloop + 1
        End If
        V3Copyd cap_loop(iloop).v, trimmed_loop(tlIndex).v
        V3Copyd norm_loop(iloop).v, normals(nIndex).v
        iloop = iloop + 1
        icnt_prev = icnt
        icnt = icnt + 1
    Else
        ' else, loop until an untrimmed point is found
        was_trimmed = True
        Do While is_trimmed(itIndex + icnt)
            icnt_prev = icnt
            icnt = icnt + 1
            If (icnt >= ncp) Then
                'return;    ' oops - everything was trimmed
                Exit Sub
            End If
        Loop
    End If

    ' Start walking around the end cap.  Every time the end loop is
    ' * trimmed, we know we'll need to draw a fillet triangle.  In
    ' * addition, after every pair of visibility changes, we draw a cap.
    If (gc.ContourStyle = gleCLOSED) Then
        istop = ncp
    Else
        istop = ncp - 1
    End If

    ' save the join style, and disable a closed contour.
    ' * Need to do this so partial contours don't close up.
    gc.ContourStyle = gleOPEN
    'for (; icnt_prev < istop; icnt_prev ++, icnt ++, icnt %= ncp) {
    Do While icnt_prev < istop

        ' There are four interesting cases for drawing caps and fillets:
        ' *    1) this & previous point were trimmed.  Don't do anything,
        ' *       advance counter.
        ' *    2) this point trimmed, previous not -- draw fillet, and
        ' *       draw cap.
        ' *    3) this point not trimmed, previous one was -- compute
        ' *       intersection point, draw fillet with it, and save
        ' *       point for cap contour.
        ' *    4) this & previous point not trimmed -- save for endcap.
        '
        
        ' Case 1 -- noop, just advance pointers
        If (is_trimmed(itIndex + icnt_prev) And is_trimmed(itIndex + icnt)) Then
        ' Case 2 --  Hah! first point! compute intersect & draw fillet!
        ElseIf (is_trimmed(itIndex + icnt_prev) And is_trimmed(itIndex + icnt) = 0) Then

            ' important note: the array "untrimmed" contains valid
            ' * untrimmed data ONLY when is_trim is TRUE.  Otherwise,
            ' * only "trim" containes valid data
    
            ' compute intersection
            INNERSECT sect, bis_origin, bis_vector, _
                       untrimmed_loop(utlIndex + icnt_prev).v, _
                       trimmed_loop(tlIndex + icnt).v
            ' Draw Fillet
            m_DrawFilletTriangleNNorms gc, trimmed_loop(tlIndex + icnt_prev).v, _
                    trimmed_loop(tlIndex + icnt).v, sect, face, _
                    front_colorPtr, back_colorPtr, _
                    normals(nIndex + icnt_prev).v, _
                    normals(nIndex + icnt).v
            V3Copyd cap_loop(iloop).v, sect
            V3Copyd norm_loop(iloop).v, normals(nIndex + icnt_prev).v
            iloop = iloop + 1
            V3Copyd cap_loop(iloop).v, trimmed_loop(tlIndex + icnt).v
            V3Copyd norm_loop(iloop).v, normals(nIndex + icnt).v
            iloop = iloop + 1
        ' Case 3 -- add to collection of points
        ElseIf (is_trimmed(itIndex + icnt_prev) = 0 And is_trimmed(itIndex + icnt) = 0) Then
           V3Copyd cap_loop(iloop).v, trimmed_loop(tlIndex + icnt).v
           V3Copyd norm_loop(iloop).v, normals(nIndex + icnt).v
           iloop = iloop + 1
        ' Case 4 -- Hah! last point!  draw fillet & draw cap!
        ElseIf (is_trimmed(itIndex + icnt_prev) = 0 And is_trimmed(itIndex + icnt)) Then
            was_trimmed = True
            
            ' important note: the array "untrimmed" contains valid
            ' * untrimmed data ONLY when is_trim is TRUE.  Otherwise,
            ' * only "trim" containes valid data
            
            ' compute intersection
            INNERSECT sect, bis_origin, bis_vector, _
                    trimmed_loop(tlIndex + icnt_prev).v, _
                    untrimmed_loop(utlIndex + icnt).v
            
            ' Draw Fillet
            m_DrawFilletTriangleNNorms gc, trimmed_loop(tlIndex + icnt_prev).v, _
                    trimmed_loop(tlIndex + icnt).v, sect, _
                    face, front_colorPtr, back_colorPtr, _
                    normals(nIndex + icnt_prev).v, _
                    normals(nIndex + icnt).v
            
            V3Copyd cap_loop(iloop).v, sect
            
            ' OK, maybe phong normals are wrong, but at least facet
            ' * normals will come out OK.
            If (gc.NormStyle And gleFACET) Then
               V3Copyd norm_loop(iloop).v, normals(nIndex + icnt_prev).v
            Else
               V3Copyd norm_loop(iloop).v, normals(nIndex + icnt).v
            End If
            iloop = iloop + 1
            
            ' draw cap
            If (iloop >= 3) Then
               m_CapCallback gc, iloop, cap_loop, front_colorPtr, _
                            cut_vector, cut_vectorFlag, _
                            bis_vector, norm_loop, 0, face, cap_callback&
            End If
            
            ' reset cap counter
            iloop = 0
        End If
        icnt_prev = icnt_prev + 1
        icnt = icnt + 1
        icnt = icnt Mod ncp
   Loop

   ' now, finish up in the same way that we started.

   icnt = icnt - 1 ' decrement to make up for loop exit condititons
   icnt = icnt + ncp
   icnt = icnt Mod ncp
   If ((is_trimmed(icnt) = 0) And (iloop >= 2)) Then
   
      ' If the last point of the contour is visible, drop an edge
       '* to the bisecting plane, thus finishing the join.
       '* Note that doing this leads to bugs if done for closed
       '* contours ... do this only if contour is open.
       '
      If (gc.JoinStyle = gleCUT And _
            c_save_style <> gleCLOSED) Then
            V3Sumd tmp_vec, trimmed_loop(tlIndex + icnt).v, bis_vector
            INNERSECT sect, bis_origin, _
                       bis_vector, trimmed_loop(tlIndex + icnt).v, _
                       tmp_vec
            V3Copyd cap_loop(iloop).v, sect
            V3Copyd norm_loop(iloop).v, normals(nIndex + icnt).v
            iloop = iloop + 1
      End If

      ' if nothing was ever trimmed, then we want to draw the
      ' * cap the way the user asked for it -- closed or not closed.
      ' * Therefore, reset the closure flag to its original state.
      '
      If was_trimmed = 0 Then
         gc.ContourStyle = c_save_style
      End If
      ' draw cap
      m_CapCallback gc, iloop, _
                        cap_loop, _
                       front_colorPtr, _
                       cut_vector, cut_vectorFlag, _
                       bis_vector, _
                       norm_loop, 0, _
                       face, cap_callback
   End If

   ' rest to the saved style
   gc.ContourStyle = c_save_style
End Sub

'-------------------------------------------------------------------------==
' * This little routine draws the little idd-biddy fillet triangle with
' * the right  color, normal, etc.
' *
' * HACK ALERT -- there are two aspects to this routine/interface that
' * are "unfinished".
' * 1) the third point of the triangle should get a color thats
' *    interpolated beween the front and back color.  The interpolant
' *    is not currently being computed.  The error introduced by not
' *    doing this should be tiny and/or non-exitant in almost all
' *    expected uses of this code.
' *
' * 2) additional normal vectors should be supplied, and these should
' *    be interpolated to fit.  Currently, this is not being done.  As
' *    above, the expected error of not doing this should be tiny and/or
' *    non-existant in almost all expected uses of this code.
'
'Public Static Sub draw_fillet_triangle_n_norms()
'                          (gleDouble va(3),
'                           gleDouble vb(3),
'                           gleDouble vc(3),
'                           int face,
'                           float front_color(3),
'                           float back_color(3),
'                           double na(3),
'                           double nb(3))
'-------------------------------------------------------------------------==
Private Sub m_DrawFilletTriangleNNorms(gc As gleGC, va#(), _
                            vb#(), _
                            vc#(), _
                            face As Boolean, _
                            front_color&, _
                            back_color&, _
                           na#(), _
                           nb#())
    If gc.ncolors Then
        glColor3fv gc.color_array(front_color).v(0)
    End If
    BGNTMESH gc, -5, 0
    If gc.NormStyle And gleFACET Then
        N3F gc, na
        If face Then
            V3F gc, va, -1, tFILLET
            V3F gc, vb, -1, tFILLET
        Else
            V3F gc, vb, -1, tFILLET
            V3F gc, va, -1, tFILLET
        End If
        V3F gc, vc, -1, tFILLET
    Else
        If face Then
            N3F gc, na
            V3F gc, va, -1, tFILLET
            N3F gc, nb
            V3F gc, vb, -1, tFILLET
        Else
            N3F gc, nb
            V3F gc, vb, -1, tFILLET
            N3F gc, na
            V3F gc, va, -1, tFILLET
            N3F gc, nb
        End If
        V3F gc, vc, -1, tFILLET
    End If
    glEnd
End Sub


'-------------------------------------------------------------------------==
' * This little routine draws the little idd-biddy fillet triangle with
' * the right  color, normal, etc.
' *
' * HACK ALERT -- there are two aspects to this routine/interface that
' * are "unfinished".
' * 1) the third point of the triangle should get a color thats
' *    interpolated beween the front and back color.  The interpolant
' *    is not currently being computed.  The error introduced by not
' *    doing this should be tiny and/or non-exitant in almost all
' *    expected uses of this code.
' *
' * 2) additional normal vectors should be supplied, and these should
' *    be interpolated to fit.  Currently, this is not being done.  As
' *    above, the expected error of not doing this should be tiny and/or
' *    non-existant in almost all expected uses of this code.
'
'Public Sub draw_fillet_triangle_plain()
'                          (gleDouble va(3),
'                           gleDouble vb(3),
'                           gleDouble vc(3),
'                           int face,
'                           float front_color(3),
'                           float back_color(3))
'-------------------------------------------------------------------------==
Private Sub m_DrawFilletTrianglePlain(gc As gleGC, va#(), _
                           vb#(), _
                           vc#(), _
                           face As Boolean, _
                           front_color&, _
                           back_color&)
    If gc.ncolors Then
        glColor3fv gc.color_array(front_color).v(0)
    End If
    'glBegin GL_TRIANGLE_STRIP
    BGNTMESH gc, -5, 0
    If face Then
        V3F gc, va, -1, tFILLET
        V3F gc, vb, -1, tFILLET
    Else
        V3F gc, vb, -1, tFILLET
        V3F gc, va, -1, tFILLET
    End If
    V3F gc, vc, -1, tFILLET
    glEnd
End Sub


