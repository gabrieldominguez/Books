
#ifndef _ERRCODE_
#define _ERRCODE_

//Shared error codes
#define EC_OK	0

#endif //_ERRCODE_
