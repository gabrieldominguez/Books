class AwesomeSeqCond_IsWeaponMaxLevel extends SequenceCondition;

event Activated()
{
    local PlayerController PC;

    PC = GetWorldInfo().GetALocalPlayerController();

    if(PC != none && PC.Pawn != none && AwesomeWeapon(PC.Pawn.Weapon) != none && AwesomeWeapon(PC.Pawn.Weapon).CurrentWeaponLevel == class'AwesomeWeapon'.const.MAX_LEVEL)
        OutputLinks[0].bHasImpulse = true;
    else
        OutputLinks[1].bHasImpulse = true;
}

defaultproperties
{
    ObjName="Is Weapon Max Level"
    ObjCategory="Awesome Game"

    OutputLinks(0)=(LinkDesc="True")
    OutputLinks(1)=(LinkDesc="False")
}
