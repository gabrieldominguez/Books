Attribute VB_Name = "modEditMp3"
Option Explicit

' Constante de d�finition des genres
Public Const GENRE As String = "Blues|Classic Rock|Country|Dance|Disco|Funk|Grunge|" + _
    "Hip-Hop|Jazz|Metal|New Age|Oldies|Other|Pop|R&B|Rap|Reggae|Rock|Techno|" + _
    "Industrial|Alternative|Ska|Death Metal|Pranks|Soundtrack|Euro-Techno|" + _
    "Ambient|Trip Hop|Vocal|Jazz+Funk|Fusion|Trance|Classical|Instrumental|Acid|" + _
    "House|Game|Sound Clip|Gospel|Noise|Alt. Rock|Bass|Soul|Punk|Space|Meditative|" + _
    "Instrumental Pop|Instrumental Rock|Ethnic|Gothic|Darkwave|Techno-Industrial|Electronic|" + _
    "Pop-Folk|Eurodance|Dream|Southern Rock|Comedy|Cult|Gangsta Rap|Top 40|Christian Rap|" + _
    "Pop/Punk|Jungle|Native American|Cabaret|New Wave|Phychedelic|Rave|Showtunes|Trailer|" + _
    "Lo-Fi|Tribal|Acid Punk|Acid Jazz|Polka|Retro|Musical|Rock & Roll|Hard Rock|Folk|" + _
    "Folk/Rock|National Folk|Swing|Fast-Fusion|Bebob|Latin|Revival|Celtic|Blue Grass|" + _
    "Avantegarde|Gothic Rock|Progressive Rock|Psychedelic Rock|Symphonic Rock|Slow Rock|" + _
    "Big Band|Chorus|Easy Listening|Acoustic|Humour|Speech|Chanson|Opera|Chamber Music|" + _
    "Sonata|Symphony|Booty Bass|Primus|Porn Groove|Satire|Slow Jam|Club|Tango|Samba|Folklore|" + _
    "Ballad|power Ballad|Rhythmic Soul|Freestyle|Duet|Punk Rock|Drum Solo|A Capella|Euro-House|" + _
    "Dance Hall|Goa|Drum & Bass|Club-House|Hardcore|Terror|Indie|Brit Pop|Negerpunk|Polsk Punk|" + _
    "Beat|Christian Gangsta Rap|Heavy Metal|Black Metal|Crossover|Comteporary Christian|" + _
    "Christian Rock|Merengue|Salsa|Trash Metal|Anime|JPop|Synth Pop"
Private tabGenre() As String
Private lgNbGenre As Long

' Version 1.0 (Layer 3, 2, 1) - Version  2.0 ou 2.5 (Layer 3, 2, 1)
Private Const KBPS As String = "32,40,48, 56, 64, 80, 96,112,128,160,192,224,256,320," & _
                               "32,48,56, 64, 80, 96,112,128,160,192,224,256,320,384," & _
                               "32,64,96,128,160,192,224,256,288,320,352,384,416,448," & _
                               " 8,16,24, 32, 64, 80, 56, 64,128,160,112,128,256,320," & _
                               "32,48,56, 64, 80, 96,112,128,160,192,224,256,320,384," & _
                               "32,64,96,128,160,192,224,256,288,320,352,384,416,448"
Private tabKBPS() As String

Public Sub InitMp3()
' Initialisation des informations
tabKBPS = Split(KBPS, ",")
tabGenre = Split(GENRE, "|")
lgNbGenre = UBound(tabGenre)
End Sub

Public Sub EcrireTagID3v1(stFichier As String, stTitre As String, stArtiste As String, _
                stAlbum As String, stAnnee As String, btGenre As Byte, _
                stCommentaire As String, stPiste As String)
' Lecture des informations d'un fichier
Dim inFree As Integer
Dim stRead As String
If Not Deprotege(stFichier) Then Exit Sub
inFree = FreeFile
' Ouverture du fichier
Open stFichier For Binary Shared As #inFree
stRead = Space$(3)
Get #inFree, LOF(inFree) - 127, stRead
' V�rification de la pr�sence d'informations
If (stRead <> "TAG") Then
    ' Insertion de la balise TAG
    Seek #inFree, LOF(inFree)
    Put #inFree, , "TAG"
End If
' Mise en place des informations
Put #inFree, , PadR(stTitre, 30)
Put #inFree, , PadR(stArtiste, 30)
Put #inFree, , PadR(stAlbum, 30)
Put #inFree, , PadR(stAnnee, 4)
If (stPiste <> vbNullString) Then
    Put #inFree, , PadR(stCommentaire, 28)
    Put #inFree, , CByte(0)
    Put #inFree, , CByte(CLng(stPiste) Mod 256)
Else
    Put #inFree, , PadR(stCommentaire, 30)
End If
Put #inFree, , btGenre
' Fermeture du fichier
Close #inFree
End Sub

Public Sub LireTagID3v1(stFichier As String, stTitre As String, stArtiste As String, _
                        stAlbum As String, stAnnee As String, stGenre As String, _
                        stCommentaire As String, Optional lgGenreOut As Long, _
                        Optional stPiste As String, Optional stMin As String, _
                        Optional stSec As String, Optional stKBps As String, _
                        Optional stMode As String)
' Lecture des informations d'un fichier
Dim inFree As Integer
Dim stRead As String
Dim lgGenre As Long

Dim lgPos243 As Long, lgPos250 As Long, lgPos251 As Long
Dim lgFor As Long, lgInput As Long
Dim stFileHeader As String, stHeader As String
Dim blOk As Boolean
Dim lgDuree As Long

' Initialisation des variables
inFree = FreeFile
lgInput = 4096
stFileHeader = String$(lgInput, &H0)
stMin = vbNullString
stSec = vbNullString
stKBps = vbNullString
stMode = vbNullString
lgPos243 = 0
lgPos250 = 0
lgPos251 = 0
lgFor = lgInput

' Ouverture du fichier
Open stFichier For Binary Access Read Shared As #inFree
If (LOF(inFree) > 1024) Then
    ' Lecture et d�codage de l'ent�te.
    Do While Not EOF(inFree)
        ' R�cup�ration de l'ent�te du fichier
        Do While Not EOF(inFree) And (lgPos243 < 1) And _
                 (lgPos250 < 1) And (lgPos251 < 1)
            Get #inFree, , stFileHeader
            lgPos243 = InStr(1, stFileHeader, Chr$(255) & Chr$(243))
            lgPos250 = InStr(1, stFileHeader, Chr$(255) & Chr$(250))
            lgPos251 = InStr(1, stFileHeader, Chr$(255) & Chr$(251))
        Loop
        ' Recherche de la position de d�part du header
        If (lgPos243 > 0) Then lgFor = lgPos243
        If (lgPos250 > 0) Then If (lgFor > lgPos250) Then lgFor = lgPos250
        If (lgPos251 > 0) Then If (lgFor > lgPos251) Then lgFor = lgPos251
        ' D�coupage du header et analyse
        stHeader = Mid$(stFileHeader, lgFor, 4)
        Call AnalyseEntete(stHeader, blOk, stKBps, stMode, lgDuree)
        If blOk Then
            lgDuree = LOF(inFree) / (CLng(stKBps) * 125)
            ' Calcul de la dur�e en minutes
            stMin = Format$(lgDuree / 86400, "nn:ss")
            stSec = CStr(lgDuree)
            Exit Do
        Else
            lgPos243 = 0
            lgPos250 = 0
            lgPos251 = 0
        End If
    Loop
    
    stRead = Space$(3)
    Get #inFree, LOF(inFree) - 127, stRead
    ' V�rification de la pr�sence d'informations
    If (stRead = "TAG") Then
        stRead = Space$(124)
        Get #inFree, , stRead
        stTitre = Trim$(Left$(stRead, 30))
        stArtiste = Trim$(Mid$(stRead, 31, 30))
        stAlbum = Trim$(Mid$(stRead, 61, 30))
        stAnnee = Trim$(Mid$(stRead, 91, 4))
        stCommentaire = Trim$(Mid$(stRead, 95, 30))
        ' Compatibilit� ID3v1.x avec num�ro de piste.
        If (Asc(Mid$(stRead, 123, 1)) = 0) Then
            stPiste = Asc(Mid$(stRead, 124, 1))
            If (stPiste = "0") Then
                stPiste = vbNullString
            Else
                stCommentaire = Left$(stCommentaire, 28)
            End If
        End If
        Get #inFree, , lgGenre
        lgGenreOut = lgGenre
        If (lgGenre > lgNbGenre) Then
            stGenre = vbNullString
        Else
            stGenre = tabGenre(lgGenre)
        End If
    Else
        stTitre = vbNullString
        stArtiste = vbNullString
        stAlbum = vbNullString
        stAnnee = vbNullString
        stCommentaire = vbNullString
        stGenre = vbNullString
        stPiste = vbNullString
    End If
Else
    stTitre = vbNullString
    stArtiste = vbNullString
    stAlbum = vbNullString
    stAnnee = vbNullString
    stCommentaire = vbNullString
    stGenre = vbNullString
    stPiste = vbNullString
End If
' Fermeture du fichier
Close #inFree
End Sub

Private Sub AnalyseEntete(stEntete As String, blValid As Boolean, stRate As String, _
                          stMode As String, lgLong As Long)
Dim btTmp(3) As Byte
Dim lgPad As Long, lgSample As Long
Dim lgVer As Long, lgLay As Long
Dim lgFor As Long, lgTmp As Long

btTmp(1) = Asc(Mid$(stEntete, 2, 1))
btTmp(2) = Asc(Mid$(stEntete, 3, 1))
btTmp(3) = Asc(Mid$(stEntete, 4, 1))

blValid = True
lgTmp = 42
' Recherche de la version
If ((btTmp(1) And 24) = 24) Then
    lgVer = 1 ' 1.0
    lgTmp = 0
ElseIf ((btTmp(1) And 16) = 16) Then
    lgVer = 2 ' 2.0
ElseIf ((btTmp(1) And 8) = 8) Then
    blValid = False
    Exit Sub
Else
    lgVer = 4 ' 2.5
End If
' Recherche du Layer
If ((btTmp(1) And 6) = 6) Then
    lgLay = 1
    lgTmp = lgTmp + 28
ElseIf ((btTmp(1) And 4) = 4) Then
    lgLay = 2
    lgTmp = lgTmp + 14
ElseIf ((btTmp(1) And 2) = 2) Then
    lgLay = 3
Else
    blValid = False
    Exit Sub
End If

' Recherche de la qualit�
stRate = "???"
For lgFor = 224 To 16 Step -16
    If ((btTmp(2) And lgFor) = lgFor) Then
        stRate = Trim$(tabKBPS((lgFor / 16) + lgTmp - 1))
        Exit For
    End If
Next lgFor

' Recherche de l'�chantillonage
If ((btTmp(2) And 12) = 12) Then
    blValid = False
    Exit Sub
ElseIf ((btTmp(2) And 8) = 8) Then
    lgSample = 32000 / lgVer
ElseIf ((btTmp(2) And 4) = 4) Then
    lgSample = 48000 / lgVer
Else
    lgSample = 44100 / lgVer
End If
' Calcul de la qualit�
If ((btTmp(3) And 192) = 192) Then
    stMode = "Mono"
ElseIf ((btTmp(3) And 128) = 128) Then
    stMode = "Dual Channel"
ElseIf ((btTmp(3) And 64) = 64) Then
    stMode = "Joint Stereo"
Else
    stMode = "Stereo"
End If
' Calcul de la longueur du morceau
If (stRate = "???") Then
    blValid = False
Else
    If ((btTmp(2) And 2) = 2) Then lgPad = 1 Else lgPad = 0
    If (lgLay = 1) Then
        lgLong = (((CLng(stRate) * 12000) / lgSample) + lgPad) * 4
    Else
        lgLong = ((CLng(stRate) * 144000) / lgSample) + lgPad
    End If
End If
End Sub
