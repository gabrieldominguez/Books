VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frm3dFO 
   Caption         =   "3DFlyingObjects"
   ClientHeight    =   5025
   ClientLeft      =   885
   ClientTop       =   2235
   ClientWidth     =   5655
   LinkTopic       =   "Form1"
   ScaleHeight     =   5025
   ScaleWidth      =   5655
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3435
      Left            =   405
      TabIndex        =   0
      Top             =   225
      Width           =   3795
      _ExtentX        =   6694
      _ExtentY        =   6059
   End
End
Attribute VB_Name = "frm3dFO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_Init()
g3DFO.Init
End Sub

Private Sub glxCtl1_Draw()
g3DFO.Draw
End Sub

Private Sub glxCtl1_InitGL()
g3DFO.InitGL
End Sub


Private Sub glxCtl1_Resize(Width As Long, Height As Long, Default As Boolean)
Default = g3DFO.Reshape(Width, Height)
End Sub


