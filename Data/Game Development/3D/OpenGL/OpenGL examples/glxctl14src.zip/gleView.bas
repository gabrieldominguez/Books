Attribute VB_Name = "gleView"
Option Explicit

''
' * MODULE Name: view.c
' *
' * FUNCTION:
' * This module provides two different routines that compute and return
' * viewing matrices.  Both routines take a direction and an up vector,
' * and return a matrix that transforms the direction to the z-axis, and
' * the up-vector to the y-axis.
' *
' * HISTORY:
' * written by Linas Vepstas August 1991
' * Added double precision interface, March 1993, Linas
'
'-------------------------------------------------------------------------
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------==
' * The uviewdirection subroutine computes and returns a 4x4 rotation
' * matrix that puts the negative z axis along the direction v21 and
' * puts the y axis along the up vector.
' *
' * Note that this code is fairly tolerant of "weird" paramters.
' * It normalizes when necessary, it does nothing when vectors are of
' * zero length, or are co-linear.  This code shouldn't croak, no matter
' * what the user sends in as arguments.
'
'-------------------------------------------------------------------------==
'public sub uview_direction_d (double m(4)(4),     ' returned
'                        double v21(3),      ' input
'                        double up(3))       ' input
'-------------------------------------------------------------------------==
Public Sub uview_direction_d(m#(), v21#(), up#())
Dim amat#(0 To 15)
Dim bmat#(0 To 15)
Dim cmat#(0 To 15)
Dim v_hat_21#(0 To 2)
Dim v_xy#(0 To 2)
Dim sine#, cosine#
Dim lng#
Dim up_proj#(0 To 2)
Dim tmp#(0 To 2)

    ' find the unit vector that points in the v21 direction
    V3Copyd v_hat_21, v21
    V3Lengthd lng, v_hat_21
    If (lng <> 0) Then
        lng = 1 / lng
        V3Scaled v_hat_21, lng, v_hat_21
    
        ' rotate z in the xz-plane until same latitude
        sine = Sqr(1 - v_hat_21(2) * v_hat_21(2))
        ROTY_CS amat, -v_hat_21(2), -sine
    Else
        ' error condition: zero length vecotr passed in -- do nothing
        Debug.Assert 0
        MatIdentityd amat
    End If


    ' project v21 onto the xy plane
    v_xy(0) = v21(0)
    v_xy(1) = v21(1)
    v_xy(2) = 0
    V3Lengthd lng, v_xy

    ' rotate in the x-y plane until v21 lies on z axis ---
    ' * but of course, if its already there, do nothing
    If (lng <> 0) Then
        ' want xy projection to be unit vector, so that sines/cosines pop out
        lng = 1 / lng
        V3Scaled v_xy, lng, v_xy
        ' rotate the projection of v21 in the xy-plane over to the x axis
        ROTZ_CS bmat, v_xy(0), v_xy(1)
        ' concatenate these together
        MatMultiplyd cmat, amat, bmat
    Else
        ' no-op -- vector is already in correct position
        MatCopyd cmat, amat
    End If

    ' up vector really should be perpendicular to the x-form direction --
    ' Use up a couple of cycles, and make sure it is,
    ' just in case the user blew it.
    V3Perpd up_proj, up, v_hat_21
    V3Lengthd lng, up_proj
    If (lng <> 0) Then
        ' normalize the vector
        lng = 1 / lng
        V3Scaled up_proj, lng, up_proj
   
        ' compare the up-vector to the  y-axis to get the cosine of the angle
        tmp(0) = cmat(4) '(1, 0)
        tmp(1) = cmat(5) '(1, 1)
        tmp(2) = cmat(6) '(1, 2)
        V3Dotd cosine, tmp, up_proj
   
        ' compare the up-vector to the x-axis to get the sine of the angle
        tmp(0) = cmat(0) '(0, 0)
        tmp(1) = cmat(1) '(0, 1)
        tmp(2) = cmat(2) '(0, 2)
        V3Dotd sine, tmp, up_proj
   
        ' rotate to align the up vector with the y-axis
        ROTZ_CS amat, cosine, -sine
        
        ' This xform, although computed last, acts first
        MatMultiplyd m, amat, cmat

    Else
        ' error condition: up vector is indeterminate (zero length)
        ' -- do nothing
        Debug.Assert 0
        MatCopyd m, cmat
    End If
End Sub

'-------------------------------------------------------------------------==
' * The uviewpoint subroutine computes and returns a 4x4 matrix that
' * translates the origin to the point v1, puts the negative z axis
' * along the direction v21==v2-v1, and puts the y axis along the up
' * vector.
'-------------------------------------------------------------------------==
'public sub uviewpoint_d (m#(4)(4),      ' returned
'                   double v1(3),        ' input
'                   double v2(3),        ' input
'                   double up(3))        ' input
'-------------------------------------------------------------------------==
Public Sub uviewpoint_d(m#(), v1#(), v2#(), up#())
Dim v_hat_21#(0 To 2)
Dim trans_mat#(0 To 15) '(0 To 3, 0 To 3)
Dim rot_mat#(0 To 15) '(0 To 3, 0 To 3)
    ' find the vector that points in the v21 direction
    V3Subd v_hat_21, v2, v1
    ' compute rotation matrix that takes -z axis to the v21 axis,
    ' and y to the up direction
    uview_direction_d rot_mat, v_hat_21, up
    ' build matrix that translates the origin to v1
    MatIdentityd trans_mat
    '   trans_mat(3, 0) = v1(0)
    '   trans_mat(3, 1) = v1(1)
    '   trans_mat(3, 2) = v1(2)
    trans_mat(12) = v1(0)
    trans_mat(13) = v1(1)
    trans_mat(14) = v1(2)
    ' concatenate the matrices together
    MatMultiplyd m, rot_mat, trans_mat
End Sub
' ================== END OF FILE ============================

' * MODULE: urotate.c
' *
' * FUNCTION:
' * This module contains three different routines that compute rotation
' * matricies and return these to user.
' * Detailed description is provided below.
' *
' * HISTORY:
' * Developed & written, Linas Vepstas, Septmeber 1991
' * double precision port, March 1993
' *
' * DETAILED DESCRIPTION:
' * This module contains three routines:
' * --------------------------------------------------------------------
' *
' * void urot_about_axis (float m(4)(4),      --- returned
' *                       float angle,        --- input
' *                       float axis(3))      --- input
' * Computes a rotation matrix.
' * The rotation is around the the direction specified by the argument
' * argument axis(3).  User may specify vector which is not of unit
' * length.  The angle of rotation is specified in degrees, and is in the
' * right-handed direction.
' *
' * void rot_about_axis (float angle,        --- input
' *                      float axis(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
' *
' * void urot_axis (float m(4)(4),      --- returned
' *                 float omega,        --- input
' *                 float axis(3))      --- input
' * Same as urot_about_axis(), but angle specified in radians.
' * It is assumed that the argument axis(3) is a vector of unit length.
' * If it is not of unit length, the returned matrix will not be correct.
' *
' * void rot_axis (float omega,        --- input
' *                float axis(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
' *
' * void urot_omega (float m(4)(4),       --- returned
' *                  float omega(3))      --- input
' * same as urot_axis(), but the angle is taken as the length of the
' * vector omega(3)
' *
' * void rot_omega (float omega(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
'
   
'-------------------------------------------------------------------------
'public sub urot_axis_d (double m(4)(4),       ' returned
'                  double omega,         ' input
'                  double axis(3))       ' input
'-------------------------------------------------------------------------
'todo: change the matrix to 0-15
Public Sub urot_axis_d(m#(), omega#, Axis#())
Dim s#, c#, ssq#, csq#, cts#, tmp#
'    * The formula coded up below can be derived by using the
'    * homomorphism between SU(2) and O(3), namely, that the
'    * 3x3 rotation matrix R is given by
'    *      t.R.v = S(-1) t.v S
'    * where
'    * t are the Pauli matrices (similar to Quaternions, easier to use)
'    * v is an arbitrary 3-vector
'    * and S is a 2x2 hermitian matrix:
'    *     S = exp ( i omega t.axis / 2 )
'    *
'    * (Also, remember that computer graphics uses the transpose of R).
'    *
'    * The Pauli matrices are:
'    *
'    *  tx = (0 1)          ty = (0 -i)            tz = (1  0)
'    *       (1 0)               (i  0)                 (0 -1)
'    *
'    * Note that no error checking is done -- if the axis vector is not
'    * of unit length, you'll get strange results.
'
    tmp = omega / 2
    s = Sin(tmp)
    c = Cos(tmp)
    
    ssq = s * s
    csq = c * c
    
    m(0) = csq - ssq
    m(5) = csq - ssq
    m(10) = csq - ssq
    
    ssq = ssq * 2
    
    ' on-diagonal entries
    m(0) = m(0) + ssq * Axis(0) * Axis(0)
    m(5) = m(5) + ssq * Axis(1) * Axis(1)
    m(10) = m(10) + ssq * Axis(2) * Axis(2)
    
    ' off-diagonal entries
    m(1) = Axis(0) * Axis(1) * ssq
    m(4) = m(1)
    m(6) = Axis(1) * Axis(2) * ssq
    m(9) = m(6)
    m(8) = Axis(2) * Axis(0) * ssq
    m(2) = m(8)
    
    cts = 2 * c * s
    
    tmp = cts * Axis(2)
    m(1) = m(1) + tmp
    m(4) = m(4) - tmp
    
    tmp = cts * Axis(0)
    m(6) = m(6) + tmp
    m(9) = m(9) - tmp

    tmp = cts * Axis(1)
    m(8) = m(8) + tmp
    m(2) = m(2) - tmp
    
    ' homogeneous entries
    m(3) = 0
    m(7) = 0
    m(11) = 0
    m(14) = 0
    m(13) = 0
    m(12) = 0
    m(15) = 1
End Sub

'-------------------------------------------------------------------------
'public sub urot_about_axis_d (double m(4)(4),         ' returned
'                        double angle,       ' input
'                        double axis(3))     ' input
'-------------------------------------------------------------------------
Public Sub urot_about_axis_d(m#(), angle#, Axis#())
Dim lng#, ax#(0 To 2)
    angle = angle * M_PI / 180 ' convert to radians

    ' renormalize axis vector, if needed
    lng = Axis(0) * Axis(0) + Axis(1) * Axis(1) + Axis(2) * Axis(2)

    ' we can save some machine instructions by normalizing only
    ' if needed.  The compiler should be able to schedule in the
    ' if test "for free".
    If (lng <> 1) Then
        lng = 1 / Sqr(lng)
        ax(0) = Axis(0) * lng
        ax(1) = Axis(1) * lng
        ax(2) = Axis(2) * lng
        urot_axis_d m, angle, ax
    Else
        urot_axis_d m, angle, Axis
    End If
End Sub

'-------------------------------------------------------------------------
'public sub urot_omega_d (double m(4)(4),  ' returned
'                   double axis(3))      ' input
'-------------------------------------------------------------------------
Public Sub urot_omega_d(m#(), Axis#())
Dim lng#, ax#(0 To 2)
   ' normalize axis vector
   lng = Axis(0) * Axis(0) + Axis(1) * Axis(1) + Axis(2) * Axis(2)

   lng = 1 / Sqr(lng)
   ax(0) = Axis(0) * lng
   ax(1) = Axis(1) * lng
   ax(2) = Axis(2) * lng

   ' the amount of rotation is equal to the length, in radians
   urot_axis_d m, lng, ax
End Sub

' ======================= END OF FILE ==========================

' * rot.h
' *
' * FUNCTION:
' * rotation matrix utilities
' *
' * HISTORY:
' * Linas Vepstas Aug 1990
'
'-------------------------------------------------------------------------
'
' * The MACROS below generate and return more traditional rotation
' * matrices -- matrices for rotations about principal axes.
'-------------------------------------------------------------------------
Public Sub ROTX_CS(m#(), cosine#, sine#)
   ' rotation about the x-axis
   m(0) = 1
   m(1) = 0
   m(2) = 0
   m(3) = 0
             
   m(4) = 0
   m(5) = cosine
   m(6) = sine
   m(7) = 0
             
   m(8) = 0
   m(9) = -sine
   m(10) = cosine
   m(11) = 0
             
   m(12) = 0
   m(13) = 0
   m(14) = 0
   m(15) = 1
End Sub

'-------------------------------------------------------------------------
Public Sub ROTY_CS(m#(), cosine#, sine#)
   ' rotation about the y-axis   \
   m(0) = cosine
   m(1) = 0
   m(2) = -sine
   m(3) = 0
             
   m(4) = 0
   m(5) = 1
   m(6) = 0
   m(7) = 0
             
   m(8) = sine
   m(9) = 0
   m(10) = cosine
   m(11) = 0
             
   m(12) = 0
   m(13) = 0
   m(14) = 0
   m(15) = 1
End Sub

'-------------------------------------------------------------------------
Public Sub ROTZ_CS(m#(), cosine#, sine#)
    ' rotation about the z-axis   \
    m(0) = cosine
    m(1) = sine
    m(2) = 0
    m(3) = 0
              
    m(4) = -sine
    m(5) = cosine
    m(6) = 0
    m(7) = 0
              
    m(8) = 0
    m(9) = 0
    m(10) = 1
    m(11) = 0
              
    m(12) = 0
    m(13) = 0
    m(14) = 0
    m(15) = 1
End Sub

'rot_prince.c
'-------------------------------------------------------------------------
' * The routines below generate and return more traditional rotation
' * matrices -- matrices for rotations about principal axes.
'-------------------------------------------------------------------------
'public sub urotx_cs_d (double m(4)(4),        ' returned
'                 double cosine,     ' input
'                 double sine)       ' input
'-------------------------------------------------------------------------
Public Sub urotx_cs_d(m#(), cosine#, sine#)
    ' create matrix that represents rotation about the x-axis
    ROTX_CS m, cosine, sine
End Sub

'-------------------------------------------------------------------------
'public sub rotx_cs_d (double cosine,      ' input
'                double sine)        ' input
'-------------------------------------------------------------------------
Public Sub rotx_cs_d(cosine#, sine#)
Dim m#(0 To 15)
    ' create and load matrix that represents rotation about the x-axis
    urotx_cs_d m, cosine, sine
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub uroty_cs_d (double m(4)(4),        ' returned
'                 double cosine,     ' input
'                 double sine)       ' input
'-------------------------------------------------------------------------
Public Sub uroty_cs_d(m#(), cosine#, sine#)
    ' create matriy that represents rotation about the y-ayis
    ROTX_CS m, cosine, sine
End Sub

'-------------------------------------------------------------------------
'public sub roty_cs_d (double cosine,      ' input
'                double sine)        ' input
'-------------------------------------------------------------------------
Public Sub roty_cs_d(cosine#, sine#)
Dim m#(0 To 15)
    ' create and load matriy that represents rotation about the y-ayis
    uroty_cs_d m, cosine, sine
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub urotz_cs_d (double m(4)(4),        ' returned
'                 double cosine,     ' input
'                 double sine)       ' input
'-------------------------------------------------------------------------
Public Sub urotz_cs_d(m#(), cosine#, sine#)
    ' create matriz that represents rotation about the z-azis
    ROTX_CS m, cosine, sine
End Sub

'-------------------------------------------------------------------------
'public sub rotz_cs_d (double cosine,      ' input
'                double sine)        ' input
'-------------------------------------------------------------------------
Public Sub rotz_cs_d(cosine#, sine#)
Dim m#(0 To 15)
    ' create and load matriz that represents rotation about the z-azis
    urotz_cs_d m, cosine, sine
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub urot_cs_d (double m(4)(4),     ' returned
'                double cosine,      ' input
'                double sine,        ' input
'                char axis)      ' input
'-------------------------------------------------------------------------
Public Sub urot_cs_d(m#(), cosine#, sine#, Axis$)        ' input
    ' create matrix that represents rotation about a principle axis
    Select Case LCase(Axis)
    Case "x"
        urotx_cs_d m, cosine, sine
    Case "y"
        uroty_cs_d m, cosine, sine
    Case "z"
        urotz_cs_d m, cosine, sine
    End Select
End Sub

'-------------------------------------------------------------------------
'public sub rot_cs_d (double cosine,       ' input
'               double sine,     ' input
'               char axis)       ' input
'-------------------------------------------------------------------------
Public Sub rot_cs_d(cosine#, sine#, Axis$)
Dim m#(0 To 15)
    ' create and load matrix that represents rotation about the z-axis
    urot_cs_d m, cosine, sine, Axis
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub urot_prince_d (double m(4)(4), ' returned
'                    double theta,       ' input
'                    char axis)      ' input
'-------------------------------------------------------------------------
Public Sub urot_prince_d(m#(), theta#, Axis$)
'    * generate rotation matrix for rotation around principal axis;
'    * note that angle is measured in radians (divide by 180, multiply by
'    * PI to convert from degrees).
    urot_cs_d m, Cos(theta), Sin(theta), Axis
End Sub

'-------------------------------------------------------------------------
'public sub rot_prince_d (double theta,    ' input
'                   char axis)       ' input
Public Sub rot_prince_d(theta#, Axis$)
Dim m#(0 To 15)
'    * generate rotation matrix for rotation around principal axis;
'    * note that angle is measured in radians (divide by 180, multiply by
'    * PI to convert from degrees).
    urot_prince_d m, theta, Axis
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------

'
' * MODULE NAME: rotate.c
' *
' * FUNCTION:
' * This module contains three different routines that compute rotation
' * matricies and load them into GL.
' * Detailed description is provided below.
' *
' * DEPENDENCIES:
' * The routines call GL matrix routines.
' *
' * HISTORY:
' * Developed & written, Linas Vepstas, Septmeber 1991
' * Double precision port, March 1993
' *
' * DETAILED DESCRIPTION:
' * This module contains three routines:
' * --------------------------------------------------------------------
' *
' * void urot_about_axis (float m(4)(4),      --- returned
' *                       float angle,        --- input
' *                       float axis(3))      --- input
' * Computes a rotation matrix.
' * The rotation is around the the direction specified by the argument
' * argument axis(3).  User may specify vector which is not of unit
' * length.  The angle of rotation is specified in degrees, and is in the
' * right-handed direction.
' *
' * void rot_about_axis (float angle,        --- input
' *                      float axis(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
' *
' * void urot_axis (float m(4)(4),      --- returned
' *                 float omega,        --- input
' *                 float axis(3))      --- input
' * Same as urot_about_axis(), but angle specified in radians.
' * It is assumed that the argument axis(3) is a vector of unit length.
' * If it is not of unit length, the returned matrix will not be correct.
' *
' * void rot_axis (float omega,        --- input
' *                float axis(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
' *
' * void urot_omega (float m(4)(4),       --- returned
' *                  float omega(3))      --- input
' * same as urot_axis(), but the angle is taken as the length of the
' * vector omega(3)
' *
' * void rot_omega (float omega(3))      --- input
' * Same as above routine, except that the matrix is multiplied into the
' * GL matrix stack.
' *
' * --------------------------------------------------------------------
'

   
'-------------------------------------------------------------------------
'public sub rot_axis_d (double omega,      ' input
'               double axis(3))      ' input
Public Sub rot_axis_d(omega#, Axis#())
Dim m#(0 To 15)
    urot_axis_d m, omega, Axis
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub rot_about_axis_d (double angle,        ' input
'                       double axis(3))      ' input
Public Sub rot_about_axis_d(angle#, Axis#())
Dim m#(0 To 15)
    urot_about_axis_d m, angle, Axis
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------
'public sub rot_omega_d (double axis(3))       ' input
Public Sub rot_omega_d(Axis#())
Dim m#(0 To 15)
    urot_omega_d m, Axis
    glMultMatrixd m(0)
End Sub

'-------------------------------------------------------------------------



