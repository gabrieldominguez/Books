
Create a folder called fonts and move the *ftx files to it. 

Check on my site for a link to more fonts.

