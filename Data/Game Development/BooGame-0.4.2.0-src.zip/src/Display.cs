/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using System.IO;

using Tao.OpenGl;
using Tao.DevIl;
using Tao.FreeGlut;

namespace BooGame
{
    /// <summary>
    /// Module to control the display window and screen
    /// </summary>
    public sealed class Display
    {
        static Display()
        {
            Core.Initialize();

            Glut.glutReshapeFunc(new Glut.ReshapeCallback(ResizeCallback));
            Gl.glBlendFunc(Gl.GL_SRC_ALPHA, Gl.GL_ONE_MINUS_SRC_ALPHA);

            AlphaBending = true;
            ClearColor = Color.Navy;
            WindowCaption = "BooGame";
        }
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Display()
        {
        }

        internal static void Initialize()
        {
        }

        /// <summary>
        /// Takes a screenshot of the current display and saves it in the application directory.
        /// </summary>
        public static void TakeScreenShot()
        {
            System.IO.DirectoryInfo dir = new DirectoryInfo(".");
            FileInfo[] files = dir.GetFiles("screenshot-*.png");
            string filename = "screenshot-" + files.Length.ToString("000") + ".png";
            int image;
            Il.ilGenImages(1, out image);
            Il.ilBindImage(image);
            if (!Ilut.ilutGLScreen())
                throw new Exception("Error creating screenshot: " + Il.ilGetString(Il.ilGetError()));
            Il.ilEnable(Il.IL_FILE_OVERWRITE);
            if (!Il.ilSaveImage(filename))
                throw new Exception("Error saving screenshot: " + Il.ilGetString(Il.ilGetError()));
            Il.ilDeleteImages(1, ref image);
        }

        private static void ResizeCallback(int width, int height)
        {
            m_WindowSize.Width = width;
            m_WindowSize.Height = height;

            // Setup our screen
            Gl.glViewport(0, 0, width, height);
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();

            //Glu.gluOrtho2D(0, m_ScreenSize.Width, m_ScreenSize.Height, 0);
            Gl.glOrtho(0, m_ScreenSize.Width, m_ScreenSize.Height, 0, -100, 100);
            Gl.glMatrixMode(Gl.GL_MODELVIEW);
        }

        private static bool m_AlphaBlending = true;
        /// <summary>
        /// Enables and disables alpha blending
        /// </summary>
        public static bool AlphaBending
        {
            get
            {
                return m_AlphaBlending;
            }
            set
            {
                if (value)
                    Gl.glEnable(Gl.GL_BLEND);
                else
                    Gl.glDisable(Gl.GL_BLEND);
            }
        }

        /// <summary>
        /// Gets and sets the width of the screen.
        /// </summary>
        public static int Width
        {
            get
            {
                return m_ScreenSize.Width;
            }
            set
            {
                m_ScreenSize.Width = value;
            }
        }
        /// <summary>
        /// Gets and sets the height of the screen.
        /// </summary>
        public static int Height
        {
            get
            {
                return m_ScreenSize.Height;
            }
            set
            {
                m_ScreenSize.Height = value;
            }
        }

        private static string m_WindowCaption;
        /// <summary>
        /// Gets and sets the caption of the associated window.
        /// </summary>
        public static string WindowCaption
        {
            get
            {
                return m_WindowCaption;
            }
            set
            {
                if (m_WindowCaption != value)
                {
                    Glut.glutSetWindowTitle(value);
                    m_WindowCaption = value;
                }
            }
        }

        private static ColorF m_ClearColor;
        /// <summary>
        /// Gets and sets the color of which the screen should be cleared.
        /// </summary>
        public static ColorF ClearColor
        {
            get { return m_ClearColor; }
            set
            {
                Gl.glClearColor(value.R, value.G, value.B, value.A);
                m_ClearColor = value;
            }
        }


        private static Size m_WindowSize = new Size(640, 480);
        /// <summary>
        /// Sets and gets the current size of the output window.
        /// </summary>
        public static Size WindowSize
        {
            get { return m_WindowSize; }
            set
            {
                m_WindowSize = value;
                Glut.glutReshapeWindow(m_WindowSize.Width, m_WindowSize.Height);
            }
        }

        /// <summary>
        /// Gets a point representing the center of the screen.
        /// </summary>
        public static PointF Center
        {
            get
            {
                return new PointF(m_ScreenSize.Width / 2f, m_ScreenSize.Height / 2f);
            }
        }

        private static Size m_ScreenSize = m_WindowSize;
        /// <summary>
        /// Gets and sets the size of the screen in the window.
        /// </summary>
        public static Size ScreenSize
        {
            get { return m_ScreenSize; }
            set
            {
                m_ScreenSize = value;

                // Do the resizing to tell BooGame how big to render
                ResizeCallback(m_WindowSize.Width, m_WindowSize.Height);
            }
        }

        /// <summary>
        /// Clears the screen buffer.
        /// </summary>
        /// <remarks>This is called before every call to the Draw event.</remarks>
        public static void Clear()
        {
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT);
        }

        private static bool m_FullScreen = false;
        /// <summary>
        /// Gets and sets whether the application is rendering in fullscreen mode.
        /// </summary>
        public static bool FullScreen
        {
            get { return m_FullScreen; }
            set
            {
                if (value)
                {
                    if (!m_FullScreen)
                    {
                        Glut.glutFullScreen();
                        m_FullScreen = true;
                    }
                }
                else
                {
                    if (m_FullScreen)
                    {
                        Glut.glutPositionWindow(50, 50);
                        WindowSize = m_ScreenSize;
                        m_FullScreen = false;
                    }
                }
            }
        }
    }
}
