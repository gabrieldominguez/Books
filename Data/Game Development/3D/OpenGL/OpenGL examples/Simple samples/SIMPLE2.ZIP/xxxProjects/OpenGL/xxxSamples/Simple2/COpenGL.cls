VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "COpenGL"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: shows how to encapsulate OpenGL in a VB class
'   - shows the drawing of axes (a useful aid in debugging)
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY:
'/*************************************************************************
'Remember to set the Form's scale mode to 3!
Private m_fieldOfView As Double
Private m_NearPlane As Double
Private m_FarPlane As Double
Private m_AspectRatio As Double
Dim m_hGLRC&, m_hdc&, m_hwnd&
'
Dim WORLD_LIST& 'constant elements in the scene



Public Function Initialize(hwnd&, hdc&) As Boolean
Dim pfd As PIXELFORMATDESCRIPTOR
Dim R&, pos!(0 To 3)
m_hwnd = hwnd
m_hdc = hdc
'set standard parameters
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    R = ChoosePixelFormat(hdc, pfd)
    If R = 0 Then
        MsgBox "ChoosePixelFormat failed"
        Exit Function
    End If
    R = SetPixelFormat(hdc, R, pfd)
    'palette?
    '
    m_hGLRC = wglCreateContext(hdc)
    wglMakeCurrent hdc, m_hGLRC
    glClearColor 0.2, 0.2, 0.2, 1
    'depth
    glClearDepth 1
    glEnable GL_DEPTH_TEST
    'color
    glEnable glcColorMaterial
    glColorMaterial faceFront, GL_AMBIENT_AND_DIFFUSE
    'lighting
    glEnable GL_LIGHTING
    glEnable glcLight0
    'move light
    pos(0) = 10: pos(1) = 10: pos(2) = 10 ': pos(3) = 1
    glLightfv ltLight0, lpmPosition, pos(0)
    'viewport
    m_AspectRatio = 1
    m_FarPlane = 200
    m_NearPlane = 0.5
    m_fieldOfView = 45
    '
    DrawWorld
    Initialize = True
End Function


Public Sub Display()
Static Busy As Boolean
    If Busy Then Exit Sub
    Busy = True
    glClear clrColorBufferBit Or clrDepthBufferBit
    glPushMatrix
        gluLookAt -10, 10, 10, 0, 0, 0, 0, 1, 0
        glCallList WORLD_LIST
    glPopMatrix
    glFinish
    SwapBuffers m_hdc
    Busy = False
End Sub

'Adjusts the viewport to match the window size.
Public Sub OnSize(ByVal W&, ByVal H&)
If H = 0 Then H = 1
m_AspectRatio = W / H
glViewport 0, 0, W, H
SetViewPort
End Sub

Private Sub SetViewPort()
Dim W&, H&
Dim x#, y#, z#

glMatrixMode mmProjection
glLoadIdentity
gluPerspective m_fieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
glMatrixMode mmModelView
glLoadIdentity
End Sub

Private Sub Class_Terminate()
    If m_hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hGLRC
    End If
End Sub

Public Sub DrawWorld()
WORLD_LIST = glGenLists(1)
glPushMatrix
    glNewList WORLD_LIST, GL_COMPILE
    DrawAxes 100, 100, 100
    glEndList
glPopMatrix
End Sub

Public Sub DrawAxes(x&, y&, z&)
Dim obj&
glPushMatrix
    glNormal3f 0, 1, 0
    glBegin GL_LINES
        'x
        glColor3f 0, 0, 1
        glVertex3f -x, 0, 0
        glVertex3f x, 0, 0
       'y
        glColor3f 0, 1, 0
        glVertex3f 0, -y, 0
        glVertex3f 0, y, 0
        'z
        glColor3f 1, 0, 0
        glVertex3f 0, 0, -z
        glVertex3f 0, 0, z
    glEnd
    glColor3f 0.8, 0.8, 0.8
    obj = gluNewQuadric
    gluSphere obj, 0.2, 32, 32
glPopMatrix
End Sub
