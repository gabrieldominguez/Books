VERSION 5.00
Begin VB.Form frmSimple2 
   Caption         =   "Simple2"
   ClientHeight    =   5625
   ClientLeft      =   270
   ClientTop       =   2580
   ClientWidth     =   5970
   LinkTopic       =   "Form1"
   ScaleHeight     =   375
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   398
End
Attribute VB_Name = "frmSimple2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim GL As COpenGL

Private Sub Form_Initialize()
Set GL = New COpenGL
GL.Initialize hwnd, hdc
End Sub

Private Sub Form_Paint()
GL.Display
End Sub

Private Sub Form_Resize()
Static W&, H&
Dim w1&, h1&
    w1 = ScaleWidth
    h1 = ScaleHeight
    GL.OnSize w1, h1
    If w1 <= W And h1 <= H Then GL.Display 'force a repaint
    W = w1: H = h1
End Sub


