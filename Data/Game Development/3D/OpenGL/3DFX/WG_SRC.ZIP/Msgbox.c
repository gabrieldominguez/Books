
//Message box functions
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#include <windows.h>

CONST char ERROR_LOADING_WINGLIDE[] = "Error loading WinGlide";
CONST char APPNAME[] = "WinGlide";

int ErrorLoadingWinGlideMessageBox(HWND, LPCSTR);
int WinGlideErrorMessageBox(HWND, LPCSTR);

int ErrorLoadingWinGlideMessageBox(HWND hWnd, LPCSTR pMessage) {
	return MessageBox(hWnd, pMessage, ERROR_LOADING_WINGLIDE, MB_OK | MB_ICONERROR);
}

int WinGlideErrorMessageBox(HWND hWnd, LPCSTR pMessage) {
	return MessageBox(hWnd, pMessage, APPNAME, MB_OK | MB_ICONERROR);
}
