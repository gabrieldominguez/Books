using System;
using System.Drawing;
using System.Collections;

using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

using Tao.OpenGl;

namespace BooGame
{
    /// <summary>
    /// A sprite object represented by a collection of animations.
    /// </summary>
	[Serializable]
	public class Sprite : Entity
	{
        /// <summary>
        /// Create a Sprite object.
        /// </summary>
		public Sprite()
		{
		}

        /// <summary>
        /// Create a sprite object based off of a TileCollection making up the animation.
        /// </summary>
        /// <param name="tiles">The frames associated with the animation of the sprite.</param>
		public Sprite(TileCollection tiles)
		{
			m_Animations.Add(tiles);
		}

        /// <summary>
        /// Create a sprite based off of the given texture.
        /// </summary>
        /// <param name="filename">The texture to load.</param>
		public Sprite(string filename)
		{
			Name = filename;
			Animations.Add(filename);
		}

        /// <summary>
        /// Create a sprite based off of the given texture.
        /// </summary>
        /// <param name="texture">The texture to load.</param>
		public Sprite(Texture texture)
		{
			m_Animations.Add(new TileSet(texture));
		}

        /// <summary>
        /// Create a sprite based off of the given animation.
        /// </summary>
        /// <param name="animation">The animation to associate with the sprite.</param>
		public Sprite(Animation animation)
		{
			m_Animations.Add(animation);
		}

        /// <summary>
        /// Create a sprite based off of the given texture and tile sizes.
        /// </summary>
        /// <param name="filename">The texture file to load.</param>
        /// <param name="tileWidth">Each tiles' width.</param>
        /// <param name="tileHeight">Each tiles' height.</param>
		public Sprite(string filename, int tileWidth, int tileHeight)
		{
			Name = filename;
			m_Animations.Add(new TileSet(filename, tileWidth, tileHeight));
		}

        /// <summary>
        /// Create a sprite based off of a single tile.
        /// </summary>
        /// <param name="tile">The tile to represent the sprite.</param>
		public Sprite(Tile tile)
		{
			m_Animations.Add(tile);
		}

        /// <summary>
        /// Create a sprite based off of a tileset to make up the animation.
        /// </summary>
        /// <param name="tileset">The tile set to associate with the sprite.</param>
		public Sprite(TileSet tileset)
		{
			m_Animations.Add(tileset);
		}

        /// <summary>
        /// Create a sprite based off of a tileset's row to make up the animation.
        /// </summary>
        /// <param name="tileset">The tile set to associate with the sprite's animation.</param>
        /// <param name="row">The row of the tile set.</param>
		public Sprite(TileSet tileset, int row)
		{
			m_Animations.Add(new TileCollection(tileset, row));
		}
		
		private AnimationCollection m_Animations = new AnimationCollection();
        /// <summary>
        /// Gets the animations associated with the sprite.
        /// </summary>
		public AnimationCollection Animations
		{
			get{ return m_Animations; }
		}		

		private int m_CurrentAnimation = 0;
        /// <summary>
        /// Gets and sets the current animation's index.
        /// </summary>
		public int CurrentAnimation
		{
			get{ return m_CurrentAnimation; }
			set
            {
                m_CurrentAnimation = value;
                m_FrameProgression = 0f;
            }
		}
		
        /// <summary>
        /// Gets and sets the current animation associated with the sprite.
        /// </summary>
		public Animation Animation
		{
			get{ return m_Animations[m_CurrentAnimation]; }
			set
			{
                if (m_Animations.Contains(value))
                    CurrentAnimation = m_Animations.IndexOf(value);
                else
                    CurrentAnimation = m_Animations.Add(value);
			}
		}

		private float m_FrameProgression = 0f;
        /// <summary>
        /// Gets and sets the animation's frame progression.
        /// </summary>
		public float FrameProgression
		{
			get{ return m_FrameProgression; }
			set{ m_FrameProgression = value; }
		}

        /// <summary>
        /// Gets and sets the sprite's width.
        /// </summary>
		public override float Width
		{
			get
			{
				return m_Animations[m_CurrentAnimation][(int)m_FrameProgression].TileSet.TileWidth * Math.Abs(this.ScaleX);
			}
			set
			{
				this.ScaleX = value / m_Animations[m_CurrentAnimation][(int)m_FrameProgression].TileSet.TileWidth;
			}
		}

        /// <summary>
        /// Gets and sets the sprite's height.
        /// </summary>
		public override float Height
		{
			get
			{
				return m_Animations[m_CurrentAnimation][(int)m_FrameProgression].TileSet.TileHeight * Math.Abs(this.ScaleY);
			}
			set
			{
				this.ScaleY = value / m_Animations[m_CurrentAnimation][(int)m_FrameProgression].TileSet.TileHeight;
			}
		}

        /// <summary>
        /// Draws the sprite on the screen.
        /// </summary>
		public override void Draw()
		{
			if(Visible)
			{
                if (Alpha <= 0f)
                    return;

				Gl.glPushMatrix();

				if(IsWorldObject)
					Camera.ApplyMatrix();

				// Location
				Gl.glTranslatef(this.X, this.Y, 0f);

				// Rotation
				Gl.glRotatef(this.Rotation, 0f, 0f, 1f);

				// Stretch
				Gl.glScalef(this.ScaleX, this.ScaleY, 1f);

				// Hotspot
				Gl.glTranslatef(-this.HotSpot.X, -this.HotSpot.Y, 0f);

                // Alpha and diffuse
                Gl.glColor4f(Tint.R, Tint.G, Tint.B, Alpha);

                m_Animations[m_CurrentAnimation][(int)m_FrameProgression].QuickDraw();

				Gl.glPopMatrix();
			}
		}

        /// <summary>
        /// Updates the sprite's position and animation.
        /// </summary>
		public override void Update()
		{
			if(Enabled)
			{
				float animspeed = m_Animations[m_CurrentAnimation].Speed;
				if(animspeed != 0f)
				{

					m_FrameProgression += animspeed * Timer.DeltaSeconds;
					if(animspeed > 0)
					{
						if(m_FrameProgression >= m_Animations[m_CurrentAnimation].Frames.Count)
							m_FrameProgression = 0f;
					}
					else
					{
						if(m_FrameProgression < 0f)
							m_FrameProgression = (float)m_Animations[m_CurrentAnimation].Frames.Count;
					}
                }
                base.Update();
			}
		}
    }

    #region SpriteCollection
    /// <summary>
    /// A collection of sprites.
    /// </summary>
    [Serializable]
    public class SpriteCollection : CollectionBase, ICollection
    {
        public SpriteCollection()
            : base()
        {
        }

        public SpriteCollection(SpriteCollection sprites)
        {
            this.Add(sprites);
        }

        public SpriteCollection(string filename)
        {
            this.Add(filename);
        }

        public SpriteCollection(string filename, int spriteWidth, int spriteHeight)
        {
            this.Add(filename, spriteWidth, spriteHeight);
        }

        public SpriteCollection(Tile tile)
        {
            this.Add(tile);
        }

        public SpriteCollection(Texture texture)
        {
            this.Add(texture);
        }
        public SpriteCollection(TileSet tiles)
        {
            this.Add(tiles);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public Sprite this[int index]
        {
            get
            {
                return ((Sprite)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }
        public Sprite this[string name]
        {
            get
            {
                foreach (Sprite sprite in this)
                    if (sprite.Name == name)
                        return sprite;
                throw new NullReferenceException("Sprite '" + name + "' not found in collection.");
            }
            set
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (this[i].Name == name)
                    {
                        this[i] = value;
                        return;
                    }
                }
                value.Name = name;
                this.Add(value);
            }
        }
        public int Add(Tile tile)
        {
            return List.Add(new Sprite(tile));
        }
        public int Add(TileSet tiles)
        {
            return List.Add(new Sprite(tiles));
        }
        public int Add(string filename, int spriteWidth, int spriteHeight)
        {
            return List.Add(new Sprite(filename, spriteWidth, spriteHeight));
        }

        public int Add(Texture texture)
        {
            return (List.Add(new Sprite(texture)));
        }
        public int Add(Sprite sprite)
        {
            return (List.Add(sprite));
        }

        public int Add(string filename)
        {
            return (List.Add(new Sprite(filename)));
        }

        public int Add(SpriteCollection spriteCollection)
        {
            for (int i = 0; i < spriteCollection.Count; i++)
                this.Add(spriteCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Sprite sprite)
        {
            List.Insert(index, sprite);
        }

        public void Remove(Sprite sprite)
        {
            List.Remove(sprite);
        }

        public int IndexOf(Sprite sprite)
        {
            return (List.IndexOf(sprite));
        }

        public bool Contains(Sprite sprite)
        {
            return (List.Contains(sprite));
        }

        public virtual void CopyTo(Sprite[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }
    }
    #endregion
}
