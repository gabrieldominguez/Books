
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _B2WG_
#define _B2WG_

#include <windows.h>

extern BOOL B2WGInitialize(HWND, DWORD, DWORD);
extern VOID B2WGShutdown(VOID);
extern VOID B2WGCopy3DfxFrameBuffer(VOID);

#endif //_B2WG_
