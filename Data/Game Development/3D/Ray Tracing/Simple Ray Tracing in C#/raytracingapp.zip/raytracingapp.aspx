<%@ Page Language="c#" Debug="true" Explicit="True" %>

<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Data.OleDb" %>
<%@ Import Namespace="System.Drawing" %>
<%@ Import Namespace="System.Web.Mail" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="Microsoft.CSharp" %>
<%@ Import Namespace="System.Drawing.Imaging" %>
<%@ Import Namespace="System.CodeDom.Compiler" %>
<%@ Import Namespace="System.Reflection" %>
<%@ Import Namespace="System.Collections" %>

<script language="C#" runat="server">

    private void Page_Load(object sender, System.EventArgs e)
    {
        outputTxt.Text = "";

        Session["lpx"] = double.Parse(ltx.Text);
        Session["lpy"] = double.Parse(lty.Text);
        Session["lpz"] = double.Parse(ltz.Text);

        Session["lvx"] = double.Parse(lvx.Text);
        Session["lvy"] = double.Parse(lvy.Text);
        Session["lvz"] = double.Parse(lvz.Text);

        Session["eyex"] = double.Parse(eyex.Text);
        Session["eyey"] = double.Parse(eyey.Text);
        Session["eyez"] = double.Parse(eyez.Text);
        
    }

    protected void Plot_Click(object sender, EventArgs e)
    {
    }
    

</script>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Ray Tracing</title>
</head>
<!--#include file="~/scripts.aspx"-->
<body style="padding-right: 0px; padding-left: 0px; padding-bottom: 0px; margin: 0px;
    padding-top: 0px; text-align: center;">
    <form id="form1" runat="server">
        <!--#include file="~/template.aspx"-->
        <asp:Panel ID="emailPanel" runat="server" Font-Names="Verdana" Font-Size="12px" Height="285px"
            Width="376px" ForeColor="DarkSlateGray" ScrollBars="Vertical" BorderColor="Gray"
            BorderStyle="Solid" BorderWidth="1px">
            <table border="0" cellpadding="0" cellspacing="0" width="100%" id="TABLE1">
                <tr style="background-color: Silver">
                    <td colspan="4" rowspan="1" style="height: 16px" valign="top">
                        <strong>Simple Ray tracing sample</strong><strong></strong></td>
                </tr>
                <tr>
                    <td style="width: 20%; height: 18px;">
                        &nbsp;</td>
                    <td style="width: 1px; height: 18px;">
                    </td>
                    <td style="width: 273px; height: 18px;">
                        &nbsp;</td>
                    <td rowspan="1" style="width: 1%; height: 18px;" valign="top">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4" rowspan="4" style="height: 1px" valign="top">
                        &nbsp;
                        <asp:Image ID="imageFunction" runat="server" ImageUrl="./raytracing.aspx" /><br />
                        <table style="width: 100%">
                            <tr>
                                <td style="width: 100px">
                                    Eye Position (x,y,z)</td>
                                <td style="width: 202px">
                                    <asp:TextBox ID="eyex" runat="server" Font-Names="Verdana" Font-Size="12px" ForeColor="DarkGreen"
                                        Width="40px">0.0</asp:TextBox>
                                    <asp:TextBox ID="eyey" runat="server" Font-Names="Verdana" Font-Size="12px" ForeColor="DarkGreen"
                                        Width="40px">0.0</asp:TextBox>
                                    <asp:TextBox ID="eyez" runat="server" Font-Names="Verdana" Font-Size="12px" ForeColor="DarkGreen"
                                        Width="40px">500.0</asp:TextBox></td>
                                <td style="width: 100px">
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 100px">
                        Light Position (x,y,z)</td>
                                <td style="width: 202px">
                                    <asp:TextBox ID="ltx" runat="server" Width="40px" Font-Names="Verdana" Font-Size="12px"
                            ForeColor="DarkGreen">200.0</asp:TextBox>
                        <asp:TextBox ID="lty" runat="server" Width="40px" Font-Names="Verdana" Font-Size="12px"
                            ForeColor="DarkGreen">200.0</asp:TextBox>
                        <asp:TextBox ID="ltz" runat="server" Width="40px" Font-Names="Verdana" Font-Size="12px"
                            ForeColor="DarkGreen">200.0</asp:TextBox></td>
                                <td style="width: 100px">
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 100px">
                                    Light Direction(vx,vy,vz)</td>
                                <td style="width: 202px">
                        <asp:TextBox ID="lvx" runat="server" Font-Names="Verdana" Font-Size="12px" ForeColor="DarkGreen"
                            Width="40px">-1.0</asp:TextBox>
                        <asp:TextBox ID="lvy" runat="server" Font-Names="Verdana"
                                Font-Size="12px" ForeColor="DarkGreen" Width="40px">-1.0</asp:TextBox>
                        <asp:TextBox
                                    ID="lvz" runat="server" Font-Names="Verdana" Font-Size="12px" ForeColor="DarkGreen"
                                    Width="40px">-1.0</asp:TextBox></td>
                                <td style="width: 100px">
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 100px">
                                    <asp:Button ID="Anterior" runat="server" BackColor="White" Font-Names="Arial" OnClick="Plot_Click"
                                        Text="Plot" /></td>
                                <td style="width: 202px">
                                </td>
                                <td style="width: 100px">
                                </td>
                            </tr>
                        </table>
                        <asp:Label ID="outputTxt" runat="server" Font-Names="Arial" Font-Size="X-Small" ForeColor="MidnightBlue"
                            Height="28px" Text="Label" Width="100%"></asp:Label>
                        &nbsp;<br />
                        &nbsp;
                        <br />
                        <br />
                        &nbsp;</td>
                </tr>
                <tr>
                </tr>
                <tr>
                </tr>
                <tr>
                </tr>
            </table>
        </asp:Panel>
        <!--#include file="~/templatebottom.aspx"-->
    </form>
</body>
</html>
