class AwesomeActor extends Actor
    placeable;

var int NumberOfKittens;

function PostBeginPlay()
{
    NumberOfKittens = 5;
    `log("Number of kittens:" @ NumberOfKittens);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
