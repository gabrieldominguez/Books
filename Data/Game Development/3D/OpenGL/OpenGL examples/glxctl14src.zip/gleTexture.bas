Attribute VB_Name = "gleTexture"
Option Explicit

''
' * texgen.c
' *
' * FUNCTION:
' * texture mapping hack
' *
' * HISTORY:
' * Created by Linas Vepstas April 1994
' * general cleanup December 1995
' */
' ======================================================= */
'-------------------------------------------------------------------------
'FUNCTION:
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
' ====================================================== */
' These are used to convey info about topography to the
' * texture mapping routines */

Public Const tFRONT = 1
Public Const tBACK = 2
Public Const tFRONT_CAP = 3
Public Const tBACK_CAP = 4
Public Const tFILLET = 5

Dim m_SaveNX# ' = 0
Dim m_SaveNY# ' = 0
Dim m_SaveNZ# ' = 0

Public Sub BGNTMESH(gc As gleGC, i&, length#)
    If gc.TextureEnabled Then
        If gc.BgnGenTextureFunc = ZTexgen Then
            bgn_z_texgen gc, i, length
        ElseIf gc.BgnGenTextureFunc = SphereTexGen Then
            bgn_sphere_texgen gc, i, length
        End If
    End If
    glBegin GL_TRIANGLE_STRIP
End Sub

'Public Sub BGNPOLYGON(gc As gleGC)
'    if gc.BgnGenTextureFunc
'    if(_gle_gc -> bgn_gen_texture) (*(_gle_gc -> bgn_gen_texture))();
'    glBegin (GL_POLYGON);
'End Sub

Public Sub N3F(gc As gleGC, x#())
    If gc.N3dGenTextureFunc Then
        save_normal x
    End If
    glNormal3dv x(0)
End Sub

Public Sub V3F(gc As gleGC, x#(), j&, ID&)
    If gc.TextureEnabled Then
    Select Case gc.TextureMode
    Case GLE_TEXTURE_VERTEX_FLAT
       vertex_flat_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_FLAT
        normal_flat_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_VERTEX_CYL
        vertex_cylinder_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_CYL
        normal_cylinder_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_VERTEX_SPH
        vertex_sphere_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_SPH
        normal_sphere_texgen_v gc, x, j, ID
    Case GLE_TEXTURE_VERTEX_MODEL_FLAT
        vertex_flat_model_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_MODEL_FLAT
        normal_flat_model_v gc, x, j, ID
    Case GLE_TEXTURE_VERTEX_MODEL_CYL
        vertex_cylinder_model_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_MODEL_CYL
        normal_cylinder_model_v gc, x, j, ID
    Case GLE_TEXTURE_VERTEX_MODEL_SPH
        vertex_sphere_model_v gc, x, j, ID
    Case GLE_TEXTURE_NORMAL_MODEL_SPH
        normal_sphere_model_v gc, x, j, ID
    End Select
    End If
    glVertex3dv x(0)
End Sub

'Public Sub ENDTMESH(gc As gleGC)
'
'End Sub
'    if(_gle_gc -> end_gen_texture) (*(_gle_gc -> end_gen_texture))();
'    glEnd ();
'}
'
'Public Sub ENDPOLYGON(gc As gleGC)
'
'End Sub
'    if(_gle_gc -> end_gen_texture) (*(_gle_gc -> end_gen_texture))();
'    glEnd ();
'}

' ======================================================= */
Public Sub SetTextureMode(gc As gleGC)
With gc
    Select Case .TextureMode
    Case GLE_TEXTURE_VERTEX_FLAT:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_FLAT:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = SaveNormal
    Case GLE_TEXTURE_VERTEX_MODEL_FLAT:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_MODEL_FLAT:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_VERTEX_CYL:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_CYL:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = SaveNormal
    Case GLE_TEXTURE_VERTEX_MODEL_CYL:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_MODEL_CYL:
         .BgnGenTextureFunc = ZTexgen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_VERTEX_SPH:
         .BgnGenTextureFunc = SphereTexGen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_SPH:
         .BgnGenTextureFunc = SphereTexGen
         .N3dGenTextureFunc = SaveNormal
    Case GLE_TEXTURE_VERTEX_MODEL_SPH:
         .BgnGenTextureFunc = SphereTexGen
         .N3dGenTextureFunc = &H0
    Case GLE_TEXTURE_NORMAL_MODEL_SPH:
         .BgnGenTextureFunc = SphereTexGen
         .N3dGenTextureFunc = &H0
    Case Else: 'break
    End Select

    ' disable texturing, and save the mode */
'    If gleTextureEnabled = 0 Then
'        'SaveBgnGenTextureFunc = BgnGenTextureFunc
'        'SaveN3dGenTextureFunc = N3dGenTextureFunc
'        'SaveV3dGenTextureFunc = V3dGenTextureFunc
'        'SaveEndGenTextureFunc = EndGenTextureFunc
'
'        .BgnGenTextureFunc = &H0
'        N3dGenTextureFunc = &H0
'        V3dGenTextureFunc = &H0
'        EndGenTextureFunc = &H0
'    End If
End With
End Sub

' ======================================================= */
Public Sub save_normal(v#())
    m_SaveNX = v(0)
    m_SaveNY = v(1)
    m_SaveNZ = v(2)
End Sub

' ======================================================= */
Public Sub bgn_sphere_texgen(gc As gleGC, inext&, lng#)
    gc.segment_number = inext - 1
    gc.segment_length = lng
    gc.NumVertices = 0
End Sub

' ======================================================= */
' * this routine assumes that the vertex passed in has been normalized
' * (i.e. is of unit length)
' */
Public Sub sphere_texgen(gc As gleGC, x#, y#, z#, jcnt&, which_end&)
Dim theta#, phi#, n#

    ' let phi and theta range fro 0 to 1 */
    'todo: is this an atan2???
    phi = 0.5 * UC.Ex.Atan2(x, y) / M_PI
    phi = phi + 0.5
    theta = 1 - ArcCosd(z) / M_PI

    ' if first vertex, merely record the texture coords */
    If (gc.NumVertices = 0) Then
        gc.Prev_X = phi
        gc.Prev_Y = theta
        gc.NumVertices = gc.NumVertices + 1
    Else
        ' if texture coordinates changed radically, wrap them */
        If ((gc.Prev_Y - theta) > 0.6) Then
            theta = theta + 1
        ElseIf ((gc.Prev_Y - theta) < -0.6) Then
            theta = theta - 1
        End If  ' else no-op */
        gc.Prev_Y = theta
        
        ' if texture coordinates changed radically, wrap them */
        If ((gc.Prev_X - phi) > 0.6) Then
            phi = phi + 1
        ElseIf (gc.Prev_X - phi) < -0.6 Then
            phi = phi - 1
        End If ' else no-op */
        gc.Prev_X = phi
    End If
    
    glTexCoord2d phi, theta
End Sub

' ======================================================= */
' mappers */
Public Sub vertex_sphere_texgen_v(gc As gleGC, v#(), jcnt&, which_end&)

Dim x#
Dim y#
Dim z#
Dim r#
    x# = v(0)
    y# = v(1)
    z# = v(2)

    If x = 0 And y = 0 And z = 0 Then
        Debug.Assert 0
        r = 1
    Else
        r = 1 / Sqr(x * x + y * y + z * z)
    End If
   x = x * r
   y = y * r
   z = z * r
   sphere_texgen gc, x, y, z, jcnt, which_end
End Sub

'static
Public Sub normal_sphere_texgen_v(gc As gleGC, v, jcnt&, which_end&)
   sphere_texgen gc, m_SaveNX, m_SaveNY, m_SaveNZ, jcnt, which_end
End Sub

'static
Public Sub vertex_sphere_model_v(gc As gleGC, v#(), jcnt&, which_end&)
Dim x#
Dim y#
Dim z#
Dim r#
If jcnt <> -1 Then
    'Debug.Assert 0
    x# = gc.contour(jcnt).v(0)
    y# = gc.contour(jcnt).v(1)
Else
    x# = v(0)
    y# = v(1)
End If
    z# = v(2)

    If x = 0 And y = 0 And z = 0 Then
        Debug.Assert 0
        r = 1
    Else
        r = 1 / Sqr(x * x + y * y + z * z)
    End If
    x = x * r
    y = y * r
    z = r
   sphere_texgen gc, x, y, z, jcnt, which_end
End Sub

Public Sub normal_sphere_model_v(gc As gleGC, v#(), jcnt&, which_end&)
    If (gc.ncnormals = 0) Then
        Exit Sub
    End If
    sphere_texgen gc, gc.cont_normal(jcnt).v(0), _
                gc.cont_normal(jcnt).v(1), 0, jcnt, which_end
End Sub

' ======================================================= */
Public Sub bgn_z_texgen(gc As gleGC, inext&, lng#)
    ' accumulate the previous length */
    gc.accum_seg_lng = gc.accum_seg_lng + gc.segment_length
    
    ' save current values */
    gc.segment_number = inext - 1
    gc.segment_length = lng
    
    ' reset counter on first segment */
    If (1 >= gc.segment_number) Then gc.accum_seg_lng = 0
    
    gc.NumVertices = 0
End Sub

' ======================================================= */
Public Sub cylinder_texgen(gc As gleGC, x#, y#, z#, jcnt&, which_end&)
Dim phi#
   ' let phi and theta range fro 0 to 1 */
   phi = 0.5 * UC.Ex.Atan2(x, y) / M_PI
   phi = phi + 0.5

   ' if first vertex, merely record the texture coords */
   If (gc.NumVertices = 0) Then
      gc.Prev_X = phi
      gc.NumVertices = gc.NumVertices + 1
   Else
      ' if texture coordinates changed radically, wrap them */
      If ((gc.Prev_X - phi) > 0.6) Then
         phi = phi + 1
      ElseIf ((gc.Prev_X - phi) < -0.6) Then
         phi = phi - 1
      End If ' else no-op */
      gc.Prev_X = phi
   End If

   If (tFRONT = which_end) Then
      glTexCoord2d phi, gc.accum_seg_lng
   End If
   If tBACK = which_end Then
      glTexCoord2d phi, gc.accum_seg_lng + gc.segment_length
   End If
End Sub

' ======================================================= */
' mappers */
'static
Public Sub vertex_cylinder_texgen_v(gc As gleGC, v#(), jcnt&, which_end&)
Dim x#
Dim y#
Dim z#
Dim r#
 x# = v(0)
 y# = v(1)
 z# = v(2)

    If x = 0 And y = 0 Then
        Debug.Assert 0
        r = 1
    Else
        r = 1 / Sqr(x * x + y * y)
    End If
   x = x * r
   y = y * r
   cylinder_texgen gc, x, y, z, jcnt, which_end
End Sub

'static
Public Sub normal_cylinder_texgen_v(gc As gleGC, v#(), jcnt&, which_end&)
   cylinder_texgen gc, m_SaveNX, m_SaveNY, m_SaveNZ, jcnt, which_end
End Sub

'static
Public Sub vertex_cylinder_model_v(gc As gleGC, v#(), jcnt&, which_end&)
Dim x#
Dim y#
Dim z#
Dim r#
    '
    x# = gc.contour(jcnt).v(0)
    y# = gc.contour(jcnt).v(1)
    z# = v(2)
    '
    If x = 0 And y = 0 Then
        Debug.Assert 0
        r = 1
    Else
        r = 1 / Sqr(x * x + y * y)
    End If
    x = x * r
    y = y * r
   cylinder_texgen gc, x, y, z, jcnt, which_end
End Sub

Public Sub normal_cylinder_model_v(gc As gleGC, v#(), jcnt&, which_end&)
   If gc.ncnormals = 0 Then
        Exit Sub
    End If
   cylinder_texgen gc, gc.cont_normal(jcnt).v(0), _
                gc.cont_normal(jcnt).v(1), 0, jcnt, which_end
End Sub

' ======================================================= */
Public Sub flat_texgen(gc As gleGC, x#, y#, z#, jcnt&, which_end&)
   If (tFRONT = which_end) Then
      glTexCoord2d x, gc.accum_seg_lng
   End If
   If tBACK = which_end Then
      glTexCoord2d x, gc.accum_seg_lng + gc.segment_length
   End If
End Sub

' ======================================================= */


Public Sub vertex_flat_texgen_v(gc As gleGC, v#(), jcnt&, which_end&)
   flat_texgen gc, v(0), v(1), v(2), jcnt, which_end
End Sub

 Public Sub normal_flat_texgen_v(gc As gleGC, v#(), jcnt&, which_end&)
   flat_texgen gc, m_SaveNX, m_SaveNY, m_SaveNZ, jcnt, which_end
End Sub

Public Sub vertex_flat_model_v(gc As gleGC, v#(), jcnt&, which_end&)
    'todo
    If jcnt = -1 Then jcnt = 0
   flat_texgen gc, gc.contour(jcnt).v(0), _
                gc.contour(jcnt).v(1), v(2), jcnt, which_end
End Sub

Public Sub normal_flat_model_v(gc As gleGC, v#(), jcnt&, which_end&)
   If gc.ncnormals = 0 Then Exit Sub
   flat_texgen gc, gc.cont_normal(jcnt).v(0), _
                gc.cont_normal(jcnt).v(1), 0, jcnt, which_end
End Sub

' ================== END OF FILE ========================= */


