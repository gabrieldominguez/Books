class AwesomeActor extends Actor
    placeable;

var bool bIsItRaining;

function PostBeginPlay()
{
    bIsItRaining = true;
    `log("Is it raining?" @ bIsItRaining);
    bIsItRaining = false;
    `log("Is it raining?" @ bIsItRaining);
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
