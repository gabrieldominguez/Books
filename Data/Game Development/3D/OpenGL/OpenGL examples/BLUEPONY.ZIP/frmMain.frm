VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.1#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Blue Pony"
   ClientHeight    =   5190
   ClientLeft      =   1515
   ClientTop       =   2115
   ClientWidth     =   5625
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5190
   ScaleWidth      =   5625
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4290
      Left            =   270
      TabIndex        =   0
      Top             =   225
      Width           =   4740
      _ExtentX        =   8361
      _ExtentY        =   7567
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_Resize()
    glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Paint()
'comment the below if you use a timer to paint
gCtl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
CX.Pick items
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


