Attribute VB_Name = "basDolphin"
' Ported to Visual Basic by Patrice Scribe, 1997
' scribe@chez.com
' http://www.chez.com

'/**
' * (c) Copyright 1993, 1994, Silicon Graphics, Inc.
' * ALL RIGHTS RESERVED
' * Permission to use, copy, modify, and distribute this software for
' * any purpose and without fee is hereby granted, provided that the above
' * copyright notice appear in all copies and that both the copyright notice
' * and this permission notice appear in supporting documentation, and that
' * the name of Silicon Graphics, Inc. not be used in advertising
' * or publicity pertaining to distribution of the software without specific,
' * written prior permission.
' *
' * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
' * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
' * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
' * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
' * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
' * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
' * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
' * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
' * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
' * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
' * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
' * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
' *
' * US Government Users Restricted Rights
' * Use, duplication, or disclosure by the Government is subject to
' * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
' * (c)(1)(ii) of the Rights in Technical Data and Computer Software
' * clause at DFARS 252.227-7013 and/or in similar or successor
' * clauses in the FAR or the DOD or NASA FAR Supplement.
' * Unpublished-- rights reserved under the copyright laws of the
' * United States.  Contractor/manufacturer is Silicon Graphics,
' * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
' *
' * OpenGL(TM) is a trademark of Silicon Graphics, Inc.
' */

Option Explicit

Private N001(2) As Single
Private N002(2) As Single
Private N003(2) As Single
Private N005(2) As Single
Private N006(2) As Single
Private N007(2) As Single
Private N008(2) As Single
Private N012(2) As Single
Private N013(2) As Single
Private N014(2) As Single
Private N015(2) As Single
Private N016(2) As Single
Private N017(2) As Single
Private N018(2) As Single
Private N019(2) As Single
Private N020(2) As Single
Private N021(2) As Single
Private N022(2) As Single
Private N023(2) As Single
Private N024(2) As Single
Private N025(2) As Single
Private N026(2) As Single
Private N027(2) As Single
Private N028(2) As Single
Private N029(2) As Single
Private N030(2) As Single
Private N031(2) As Single
Private N032(2) As Single
Private N033(2) As Single
Private N034(2) As Single
Private N035(2) As Single
Private N036(2) As Single
Private N037(2) As Single
Private N038(2) As Single
Private N039(2) As Single
Private N040(2) As Single
Private N041(2) As Single
Private N042(2) As Single
Private N043(2) As Single
Private N044(2) As Single
Private N045(2) As Single
Private N046(2) As Single
Private N047(2) As Single
Private N048(2) As Single
Private N049(2) As Single
Private N050(2) As Single
Private N051(2) As Single
Private N052(2) As Single
Private N053(2) As Single
Private N054(2) As Single
Private N055(2) As Single
Private N056(2) As Single
Private N057(2) As Single
Private N058(2) As Single
Private N059(2) As Single
Private N060(2) As Single
Private N062(2) As Single
Private N063(2) As Single
Private N064(2) As Single
Private N065(2) As Single
Private N066(2) As Single
Private N067(2) As Single
Private N071(2) As Single
Private N077(2) As Single
Private N078(2) As Single
Private N079(2) As Single
Private N080(2) As Single
Private N081(2) As Single
Private N082(2) As Single
Private N083(2) As Single
Private N084(2) As Single
Private N085(2) As Single
Private N086(2) As Single
Private N087(2) As Single
Private N088(2) As Single
Private N089(2) As Single
Private N090(2) As Single
Private N091(2) As Single
Private N092(2) As Single
Private N093(2) As Single
Private N094(2) As Single
Private N095(2) As Single
Private N097(2) As Single
Private N098(2) As Single
Private N099(2) As Single
Private N100(2) As Single
Private N102(2) As Single
Private N110(2) As Single
Private N111(2) As Single
Private N112(2) As Single
Private N113(2) As Single
Private N114(2) As Single
Private N115(2) As Single
Private N116(2) As Single
Private N117(2) As Single
Private N118(2) As Single
Private N119(2) As Single
Private N120(2) As Single
Private N121(2) As Single
Private N122(2) As Single
Private P001(2) As Single
Private P002(2) As Single
Private P003(2) As Single
Private P005(2) As Single
Private P006(2) As Single
Private P007(2) As Single
Private P008(2) As Single
Private P009(2) As Single
Private P010(2) As Single
Private P011(2) As Single
Private P012(2) As Single
Private P013(2) As Single
Private P014(2) As Single
Private P015(2) As Single
Private P016(2) As Single
Private P017(2) As Single
Private P018(2) As Single
Private P019(2) As Single
Private P020(2) As Single
Private P021(2) As Single
Private P022(2) As Single
Private P023(2) As Single
Private P024(2) As Single
Private P025(2) As Single
Private P026(2) As Single
Private P027(2) As Single
Private P028(2) As Single
Private P029(2) As Single
Private P030(2) As Single
Private P031(2) As Single
Private P032(2) As Single
Private P033(2) As Single
Private P034(2) As Single
Private P035(2) As Single
Private P036(2) As Single
Private P037(2) As Single
Private P038(2) As Single
Private P039(2) As Single
Private P040(2) As Single
Private P041(2) As Single
Private P042(2) As Single
Private P043(2) As Single
Private P044(2) As Single
Private P045(2) As Single
Private P046(2) As Single
Private P047(2) As Single
Private P048(2) As Single
Private P049(2) As Single
Private P050(2) As Single
Private P051(2) As Single
Private iP001(2) As Single
Private iP009(2) As Single
Private iP010(2) As Single
Private iP011(2) As Single
Private iP012(2) As Single
Private iP013(2) As Single
Private iP014(2) As Single
Private iP015(2) As Single
Private iP016(2) As Single
Private iP017(2) As Single
Private iP018(2) As Single
Private iP019(2) As Single
Private iP020(2) As Single
Private iP021(2) As Single
Private iP022(2) As Single
Private iP023(2) As Single
Private iP024(2) As Single
Private iP025(2) As Single
Private iP026(2) As Single
Private iP027(2) As Single
Private iP028(2) As Single
Private iP029(2) As Single
Private iP030(2) As Single
Private iP031(2) As Single
Private iP032(2) As Single
Private iP033(2) As Single
Private iP034(2) As Single
Private iP035(2) As Single
Private iP036(2) As Single
Private iP037(2) As Single
Private iP038(2) As Single
Private iP039(2) As Single
Private iP040(2) As Single
Private iP041(2) As Single
Private iP042(2) As Single
Private iP043(2) As Single
Private iP044(2) As Single
Private iP045(2) As Single
Private iP046(2) As Single
Private iP047(2) As Single
Private iP048(2) As Single
Private iP049(2) As Single
Private iP050(2) As Single
Private iP051(2) As Single
Private P052(2) As Single
Private P053(2) As Single
Private P054(2) As Single
Private P055(2) As Single
Private P056(2) As Single
Private P057(2) As Single
Private P058(2) As Single
Private P059(2) As Single
Private P060(2) As Single
Private P062(2) As Single
Private P063(2) As Single
Private P064(2) As Single
Private P065(2) As Single
Private P066(2) As Single
Private P067(2) As Single
Private P068(2) As Single
Private P069(2) As Single
Private P070(2) As Single
Private P071(2) As Single
Private P072(2) As Single
Private P073(2) As Single
Private P074(2) As Single
Private P075(2) As Single
Private P076(2) As Single
Private iP068(2) As Single
Private iP069(2) As Single
Private iP070(2) As Single
Private iP071(2) As Single
Private iP072(2) As Single
Private iP073(2) As Single
Private iP074(2) As Single
Private iP075(2) As Single
Private iP076(2) As Single
Private P077(2) As Single
Private P078(2) As Single
Private P079(2) As Single
Private P080(2) As Single
Private P081(2) As Single
Private P082(2) As Single
Private P083(2) As Single
Private P084(2) As Single
Private P085(2) As Single
Private P086(2) As Single
Private P087(2) As Single
Private P088(2) As Single
Private P089(2) As Single
Private P090(2) As Single
Private P091(2) As Single
Private P092(2) As Single
Private P093(2) As Single
Private P094(2) As Single
Private P095(2) As Single
Private iP091(2) As Single
Private iP092(2) As Single
Private iP093(2) As Single
Private iP094(2) As Single
Private iP095(2) As Single
Private P097(2) As Single
Private P098(2) As Single
Private iP097(2) As Single
Private iP098(2) As Single
Private P099(2) As Single
Private P100(2) As Single
Private P102(2) As Single
Private iP102(2) As Single
Private P103(2) As Single
Private P105(2) As Single
Private P108(2) As Single
Private P110(2) As Single
Private iP110(2) As Single
Private P111(2) As Single
Private iP111(2) As Single
Private P112(2) As Single
Private P113(2) As Single
Private P114(2) As Single
Private P115(2) As Single
Private P116(2) As Single
Private P117(2) As Single
Private iP118(2) As Single
Private iP119(2) As Single
Private P118(2) As Single
Private P119(2) As Single
Private P120(2) As Single
Private P121(2) As Single
Private iP121(2) As Single
Private P122(2) As Single
Private iP122(2) As Single
Private P123(2) As Single
Private P124(2) As Single
Private P125(2) As Single
Private P126(2) As Single
Private P127(2) As Single
Private P128(2) As Single
Private P129(2) As Single
Private P130(2) As Single
Private P131(2) As Single
Private P132(2) As Single
Private P133(2) As Single
Private P134(2) As Single

Sub Dolphin_Init()
    FillArray N001, Array(-0.005937, -0.101998, -0.994767)
    FillArray N002, Array(0.93678, -0.200803, 0.286569)
    FillArray N003, Array(-0.233062, 0.972058, 0.028007)
    FillArray N005, Array(0.898117, 0.360171, 0.252315)
    FillArray N006, Array(-0.915437, 0.348456, 0.201378)
    FillArray N007, Array(0.602263, -0.777527, 0.18092)
    FillArray N008, Array(-0.906912, -0.412015, 0.088061)
    FillArray N012, Array(0.884408, -0.429417, -0.182821)
    FillArray N013, Array(0.921121, 0.311084, -0.234016)
    FillArray N014, Array(0.382635, 0.877882, -0.287948)
    FillArray N015, Array(-0.380046, 0.888166, -0.258316)
    FillArray N016, Array(-0.891515, 0.392238, -0.226607)
    FillArray N017, Array(-0.901419, -0.382002, -0.203763)
    FillArray N018, Array(-0.367225, -0.911091, -0.187243)
    FillArray N019, Array(0.339539, -0.924846, -0.171388)
    FillArray N020, Array(0.914706, -0.378617, -0.14129)
    FillArray N021, Array(0.950662, 0.262713, -0.164994)
    FillArray N022, Array(0.546359, 0.80146, -0.243218)
    FillArray N023, Array(-0.315796, 0.917068, -0.243431)
    FillArray N024, Array(-0.825687, 0.532277, -0.186875)
    FillArray N025, Array(-0.974763, -0.155232, -0.160435)
    FillArray N026, Array(-0.560596, -0.816658, -0.137119)
    FillArray N027, Array(0.38021, -0.910817, -0.160786)
    FillArray N028, Array(0.923772, -0.358322, -0.135093)
    FillArray N029, Array(0.951202, 0.275053, -0.139859)
    FillArray N030, Array(0.686099, 0.702548, -0.188932)
    FillArray N031, Array(-0.521865, 0.826719, -0.21022)
    FillArray N032, Array(-0.92382, 0.346739, -0.162258)
    FillArray N033, Array(-0.902095, -0.409995, -0.134646)
    FillArray N034, Array(-0.509115, -0.848498, -0.144404)
    FillArray N035, Array(0.456469, -0.880293, -0.129305)
    FillArray N036, Array(0.873401, -0.475489, -0.105266)
    FillArray N037, Array(0.970825, 0.179861, -0.158584)
    FillArray N038, Array(0.675609, 0.714187, -0.183004)
    FillArray N039, Array(-0.523574, 0.830212, -0.19136)
    FillArray N040, Array(-0.958895, 0.230808, -0.165071)
    FillArray N041, Array(-0.918285, -0.376803, -0.121542)
    FillArray N042, Array(-0.622467, -0.774167, -0.114888)
    FillArray N043, Array(0.404497, -0.908807, -0.102231)
    FillArray N044, Array(0.930538, -0.365155, -0.027588)
    FillArray N045, Array(0.92192, 0.374157, -0.100345)
    FillArray N046, Array(0.507346, 0.860739, 0.041562)
    FillArray N047, Array(-0.394646, 0.918815, -0.00573)
    FillArray N048, Array(-0.925411, 0.373024, -0.066837)
    FillArray N049, Array(-0.945337, -0.322309, -0.049551)
    FillArray N050, Array(-0.660437, -0.750557, -0.022072)
    FillArray N051, Array(0.488835, -0.87195, -0.027261)
    FillArray N052, Array(0.902599, -0.421397, 0.087969)
    FillArray N053, Array(0.938636, 0.322606, 0.12202)
    FillArray N054, Array(0.484605, 0.871078, 0.079878)
    FillArray N055, Array(-0.353607, 0.931559, 0.084619)
    FillArray N056, Array(-0.867759, 0.478564, 0.134054)
    FillArray N057, Array(-0.951583, -0.29603, 0.082794)
    FillArray N058, Array(-0.672355, -0.730209, 0.121384)
    FillArray N059, Array(0.528336, -0.842452, 0.105525)
    FillArray N060, Array(0.786913, -0.56476, 0.248627)
    FillArray N062, Array(0.622098, 0.76523, 0.165584)
    FillArray N063, Array(-0.631711, 0.767816, 0.106773)
    FillArray N064, Array(-0.687886, 0.606351, 0.398938)
    FillArray N065, Array(-0.946327, -0.281623, 0.158598)
    FillArray N066, Array(-0.509549, -0.860437, 0.002776)
    FillArray N067, Array(0.462594, -0.876692, 0.131977)
    FillArray N071, Array(0#, 1#, 0#)
    FillArray N077, Array(-0.88077, 0.461448, 0.106351)
    FillArray N078, Array(-0.88077, 0.461448, 0.106351)
    FillArray N079, Array(-0.88077, 0.461448, 0.106351)
    FillArray N080, Array(-0.88077, 0.461448, 0.106351)
    FillArray N081, Array(-0.571197, 0.816173, 0.087152)
    FillArray N082, Array(-0.88077, 0.461448, 0.106351)
    FillArray N083, Array(-0.571197, 0.816173, 0.087152)
    FillArray N084, Array(-0.571197, 0.816173, 0.087152)
    FillArray N085, Array(-0.88077, 0.461448, 0.106351)
    FillArray N086, Array(-0.571197, 0.816173, 0.087152)
    FillArray N087, Array(-0.88077, 0.461448, 0.106351)
    FillArray N088, Array(-0.88077, 0.461448, 0.106351)
    FillArray N089, Array(-0.88077, 0.461448, 0.106351)
    FillArray N090, Array(-0.88077, 0.461448, 0.106351)
    FillArray N091, Array(0#, 1#, 0#)
    FillArray N092, Array(0#, 1#, 0#)
    FillArray N093, Array(0#, 1#, 0#)
    FillArray N094, Array(1#, 0#, 0#)
    FillArray N095, Array(-1#, 0#, 0#)
    FillArray N097, Array(-0.697296, 0.702881, 0.140491)
    FillArray N098, Array(0.918864, 0.340821, 0.198819)
    FillArray N099, Array(-0.932737, 0.201195, 0.299202)
    FillArray N100, Array(0.029517, 0.981679, 0.188244)
    FillArray N102, Array(0.813521, -0.204936, 0.544229)
    FillArray N110, Array(-0.78148, -0.384779, 0.491155)
    FillArray N111, Array(-0.722243, 0.384927, 0.574627)
    FillArray N112, Array(-0.752278, 0.502679, 0.425901)
    FillArray N113, Array(0.547257, 0.36791, 0.751766)
    FillArray N114, Array(0.725949, -0.232568, 0.647233)
    FillArray N115, Array(-0.747182, -0.660786, 0.07128)
    FillArray N116, Array(0.931519, 0.200748, 0.30327)
    FillArray N117, Array(-0.828928, 0.313757, 0.463071)
    FillArray N118, Array(0.902554, -0.370967, 0.218587)
    FillArray N119, Array(-0.879257, -0.441851, 0.177973)
    FillArray N120, Array(0.642327, 0.611901, 0.461512)
    FillArray N121, Array(0.964817, -0.202322, 0.16791)
    FillArray N122, Array(0#, 1#, 0#)
    FillArray P001, Array(5.68, -300.95, 1324.7)
    FillArray P002, Array(338.69, -219.63, 9677.03)
    FillArray P003, Array(12.18, 474.59, 9138.14)
    FillArray P005, Array(487.51, 198.05, 9350.78)
    FillArray P006, Array(-457.61, 68.74, 9427.85)
    FillArray P007, Array(156.52, -266.72, 10311.68)
    FillArray P008, Array(-185.56, -266.51, 10310.47)
    FillArray P009, Array(124.39, -261.46, 1942.34)
    FillArray P010, Array(-130.05, -261.46, 1946.03)
    FillArray P011, Array(141.07, -320.11, 1239.38)
    FillArray P012, Array(156.48, -360.12, 2073.41)
    FillArray P013, Array(162#, -175.88, 2064.44)
    FillArray P014, Array(88.16, -87.72, 2064.02)
    FillArray P015, Array(-65.21, -96.13, 2064.02)
    FillArray P016, Array(-156.48, -180.96, 2064.44)
    FillArray P017, Array(-162#, -368.93, 2082.39)
    FillArray P018, Array(-88.16, -439.22, 2082.39)
    FillArray P019, Array(65.21, -440.32, 2083.39)
    FillArray P020, Array(246.87, -356.02, 2576.95)
    FillArray P021, Array(253.17, -111.15, 2567.15)
    FillArray P022, Array(132.34, 51.41, 2559.84)
    FillArray P023, Array(-97.88, 40.44, 2567.15)
    FillArray P024, Array(-222.97, -117.49, 2567.15)
    FillArray P025, Array(-252.22, -371.53, 2569.92)
    FillArray P026, Array(-108.44, -518.19, 2586.75)
    FillArray P027, Array(97.88, -524.79, 2586.75)
    FillArray P028, Array(370.03, -421.19, 3419.7)
    FillArray P029, Array(351.15, -16.98, 3423.17)
    FillArray P030, Array(200.66, 248.46, 3430.37)
    FillArray P031, Array(-148.42, 235.02, 3417.91)
    FillArray P032, Array(-360.21, -30.27, 3416.84)
    FillArray P033, Array(-357.9, -414.89, 3407.04)
    FillArray P034, Array(-148.88, -631.35, 3409.9)
    FillArray P035, Array(156.38, -632.59, 3419.7)
    FillArray P036, Array(462.61, -469.21, 4431.51)
    FillArray P037, Array(466.6, 102.25, 4434.98)
    FillArray P038, Array(243.05, 474.34, 4562.02)
    FillArray P039, Array(-191.23, 474.4, 4554.42)
    FillArray P040, Array(-476.12, 111.05, 4451.11)
    FillArray P041, Array(-473.36, -470.74, 4444.78)
    FillArray P042, Array(-266.95, -748.41, 4447.78)
    FillArray P043, Array(211.14, -749.91, 4429.73)
    FillArray P044, Array(680.57, -370.27, 5943.46)
    FillArray P045, Array(834.01, 363.09, 6360.63)
    FillArray P046, Array(371.29, 804.51, 6486.26)
    FillArray P047, Array(-291.43, 797.22, 6494.28)
    FillArray P048, Array(-784.13, 370.75, 6378.01)
    FillArray P049, Array(-743.29, -325.82, 5943.46)
    FillArray P050, Array(-383.24, -804.77, 5943.46)
    FillArray P051, Array(283.47, -846.09, 5943.46)
    FillArray iP001, Array(5.68, -300.95, 1324.7)
    FillArray iP009, Array(124.39, -261.46, 1942.34)
    FillArray iP010, Array(-130.05, -261.46, 1946.03)
    FillArray iP011, Array(141.07, -320.11, 1239.38)
    FillArray iP012, Array(156.48, -360.12, 2073.41)
    FillArray iP013, Array(162#, -175.88, 2064.44)
    FillArray iP014, Array(88.16, -87.72, 2064.02)
    FillArray iP015, Array(-65.21, -96.13, 2064.02)
    FillArray iP016, Array(-156.48, -180.96, 2064.44)
    FillArray iP017, Array(-162#, -368.93, 2082.39)
    FillArray iP018, Array(-88.16, -439.22, 2082.39)
    FillArray iP019, Array(65.21, -440.32, 2083.39)
    FillArray iP020, Array(246.87, -356.02, 2576.95)
    FillArray iP021, Array(253.17, -111.15, 2567.15)
    FillArray iP022, Array(132.34, 51.41, 2559.84)
    FillArray iP023, Array(-97.88, 40.44, 2567.15)
    FillArray iP024, Array(-222.97, -117.49, 2567.15)
    FillArray iP025, Array(-252.22, -371.53, 2569.92)
    FillArray iP026, Array(-108.44, -518.19, 2586.75)
    FillArray iP027, Array(97.88, -524.79, 2586.75)
    FillArray iP028, Array(370.03, -421.19, 3419.7)
    FillArray iP029, Array(351.15, -16.98, 3423.17)
    FillArray iP030, Array(200.66, 248.46, 3430.37)
    FillArray iP031, Array(-148.42, 235.02, 3417.91)
    FillArray iP032, Array(-360.21, -30.27, 3416.84)
    FillArray iP033, Array(-357.9, -414.89, 3407.04)
    FillArray iP034, Array(-148.88, -631.35, 3409.9)
    FillArray iP035, Array(156.38, -632.59, 3419.7)
    FillArray iP036, Array(462.61, -469.21, 4431.51)
    FillArray iP037, Array(466.6, 102.25, 4434.98)
    FillArray iP038, Array(243.05, 474.34, 4562.02)
    FillArray iP039, Array(-191.23, 474.4, 4554.42)
    FillArray iP040, Array(-476.12, 111.05, 4451.11)
    FillArray iP041, Array(-473.36, -470.74, 4444.78)
    FillArray iP042, Array(-266.95, -748.41, 4447.78)
    FillArray iP043, Array(211.14, -749.91, 4429.73)
    FillArray iP044, Array(680.57, -370.27, 5943.46)
    FillArray iP045, Array(834.01, 363.09, 6360.63)
    FillArray iP046, Array(371.29, 804.51, 6486.26)
    FillArray iP047, Array(-291.43, 797.22, 6494.28)
    FillArray iP048, Array(-784.13, 370.75, 6378.01)
    FillArray iP049, Array(-743.29, -325.82, 5943.46)
    FillArray iP050, Array(-383.24, -804.77, 5943.46)
    FillArray iP051, Array(283.47, -846.09, 5943.46)
    FillArray P052, Array(599.09, -300.15, 7894.03)
    FillArray P053, Array(735.48, 306.26, 7911.92)
    FillArray P054, Array(246.22, 558.53, 8460.5)
    FillArray P055, Array(-230.41, 559.84, 8473.23)
    FillArray P056, Array(-698.66, 320.83, 7902.59)
    FillArray P057, Array(-643.29, -299.16, 7902.59)
    FillArray P058, Array(-341.47, -719.3, 7902.59)
    FillArray P059, Array(252.57, -756.12, 7902.59)
    FillArray P060, Array(458.39, -265.31, 9355.44)
    FillArray P062, Array(224.04, 338.75, 9450.3)
    FillArray P063, Array(-165.71, 341.04, 9462.35)
    FillArray P064, Array(-298.11, 110.13, 10180.37)
    FillArray P065, Array(-473.99, -219.71, 9355.44)
    FillArray P066, Array(-211.97, -479.87, 9355.44)
    FillArray P067, Array(192.86, -491.45, 9348.73)
    FillArray P068, Array(-136.29, -319.84, 1228.73)
    FillArray P069, Array(1111.17, -314.14, 1314.19)
    FillArray P070, Array(-1167.34, -321.61, 1319.45)
    FillArray P071, Array(1404.86, -306.66, 1235.45)
    FillArray P072, Array(-1409.73, -314.14, 1247.66)
    FillArray P073, Array(1254.01, -296.87, 1544.58)
    FillArray P074, Array(-1262.09, -291.7, 1504.26)
    FillArray P075, Array(965.71, -269.26, 1742.65)
    FillArray P076, Array(-900.97, -276.74, 1726.07)
    FillArray iP068, Array(-136.29, -319.84, 1228.73)
    FillArray iP069, Array(1111.17, -314.14, 1314.19)
    FillArray iP070, Array(-1167.34, -321.61, 1319.45)
    FillArray iP071, Array(1404.86, -306.66, 1235.45)
    FillArray iP072, Array(-1409.73, -314.14, 1247.66)
    FillArray iP073, Array(1254.01, -296.87, 1544.58)
    FillArray iP074, Array(-1262.09, -291.7, 1504.26)
    FillArray iP075, Array(965.71, -269.26, 1742.65)
    FillArray iP076, Array(-900.97, -276.74, 1726.07)
    FillArray P077, Array(1058#, -448.81, 8194.66)
    FillArray P078, Array(-1016.51, -456.43, 8190.62)
    FillArray P079, Array(-1515.96, -676.45, 7754.93)
    FillArray P080, Array(1856.75, -830.34, 7296.56)
    FillArray P081, Array(1472.16, -497.38, 7399.68)
    FillArray P082, Array(-1775.26, -829.51, 7298.46)
    FillArray P083, Array(911.09, -252.51, 7510.99)
    FillArray P084, Array(-1451.94, -495.62, 7384.3)
    FillArray P085, Array(1598.75, -669.26, 7769.9)
    FillArray P086, Array(-836.53, -250.08, 7463.25)
    FillArray P087, Array(722.87, -158.18, 8006.41)
    FillArray P088, Array(-688.86, -162.28, 7993.89)
    FillArray P089, Array(-626.92, -185.3, 8364.98)
    FillArray P090, Array(647.72, -189.46, 8354.99)
    FillArray P091, Array(0#, 835.01, 5555.62)
    FillArray P092, Array(0#, 1350.18, 5220.86)
    FillArray P093, Array(0#, 1422.94, 5285.27)
    FillArray P094, Array(0#, 1296.75, 5650.19)
    FillArray P095, Array(0#, 795.63, 6493.88)
    FillArray iP091, Array(0#, 835.01, 5555.62)
    FillArray iP092, Array(0#, 1350.18, 5220.86)
    FillArray iP093, Array(0#, 1422.94, 5285.27)
    FillArray iP094, Array(0#, 1296.75, 5650.19)
    FillArray iP095, Array(0#, 795.63, 6493.88)
    FillArray P097, Array(-194.91, -357.14, 10313.32)
    FillArray P098, Array(135.35, -357.66, 10307.94)
    FillArray iP097, Array(-194.91, -357.14, 10313.32)
    FillArray iP098, Array(135.35, -357.66, 10307.94)
    FillArray P099, Array(-380.53, -221.14, 9677.98)
    FillArray P100, Array(0#, 412.99, 9629.33)
    FillArray P102, Array(59.51, -412.55, 10677.58)
    FillArray iP102, Array(59.51, -412.55, 10677.58)
    FillArray P103, Array(6.5, 484.74, 9009.94)
    FillArray P105, Array(-41.86, 476.51, 9078.17)
    FillArray P108, Array(49.2, 476.83, 9078.24)
    FillArray P110, Array(-187.62, -410.04, 10674.12)
    FillArray iP110, Array(-187.62, -410.04, 10674.12)
    FillArray P111, Array(-184.25, -318.7, 10723.88)
    FillArray iP111, Array(-184.25, -318.7, 10723.88)
    FillArray P112, Array(-179.61, -142.81, 10670.26)
    FillArray P113, Array(57.43, -147.94, 10675.26)
    FillArray P114, Array(54.06, -218.9, 10712.44)
    FillArray P115, Array(-186.35, -212.09, 10713.76)
    FillArray P116, Array(205.9, -84.61, 10275.97)
    FillArray P117, Array(-230.96, -83.26, 10280.09)
    FillArray iP118, Array(216.78, -509.17, 10098.94)
    FillArray iP119, Array(-313.21, -510.79, 10102.62)
    FillArray P118, Array(216.78, -509.17, 10098.94)
    FillArray P119, Array(-313.21, -510.79, 10102.62)
    FillArray P120, Array(217.95, 96.34, 10161.62)
    FillArray P121, Array(71.99, -319.74, 10717.7)
    FillArray iP121, Array(71.99, -319.74, 10717.7)
    FillArray P122, Array(0#, 602.74, 5375.84)
    FillArray iP122, Array(0#, 602.74, 5375.84)
    FillArray P123, Array(-448.94, -203.14, 9499.6)
    FillArray P124, Array(-442.64, -185.2, 9528.07)
    FillArray P125, Array(-441.07, -148.05, 9528.07)
    FillArray P126, Array(-443.43, -128.84, 9499.6)
    FillArray P127, Array(-456.87, -146.78, 9466.67)
    FillArray P128, Array(-453.68, -183.93, 9466.67)
    FillArray P129, Array(428.43, -124.08, 9503.03)
    FillArray P130, Array(419.73, -142.14, 9534.56)
    FillArray P131, Array(419.92, -179.96, 9534.56)
    FillArray P132, Array(431.2, -199.73, 9505.26)
    FillArray P133, Array(442.28, -181.67, 9475.96)
    FillArray P134, Array(442.08, -143.84, 9475.96)
End Sub

Sub Dolphin001()

    glNormal3fv N071(0)
    glBegin (GL_POLYGON)
    glVertex3fv P001(0)
    glVertex3fv P068(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P068(0)
    glVertex3fv P076(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P068(0)
    glVertex3fv P070(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P076(0)
    glVertex3fv P070(0)
    glVertex3fv P074(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P070(0)
    glVertex3fv P072(0)
    glVertex3fv P074(0)
    glEnd
    glNormal3fv N119(0)
    glBegin (GL_POLYGON)
    glVertex3fv P072(0)
    glVertex3fv P070(0)
    glVertex3fv P074(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P074(0)
    glVertex3fv P070(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P070(0)
    glVertex3fv P068(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P076(0)
    glVertex3fv P068(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P068(0)
    glVertex3fv P001(0)
    glVertex3fv P010(0)
    glEnd
End Sub

Sub Dolphin002()

    glNormal3fv N071(0)
    glBegin (GL_POLYGON)
    glVertex3fv P011(0)
    glVertex3fv P001(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P075(0)
    glVertex3fv P011(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P069(0)
    glVertex3fv P011(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P069(0)
    glVertex3fv P075(0)
    glVertex3fv P073(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P071(0)
    glVertex3fv P069(0)
    glVertex3fv P073(0)
    glEnd
    glNormal3fv N119(0)
    glBegin (GL_POLYGON)
    glVertex3fv P001(0)
    glVertex3fv P011(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P009(0)
    glVertex3fv P011(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P011(0)
    glVertex3fv P069(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P069(0)
    glVertex3fv P073(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P069(0)
    glVertex3fv P071(0)
    glVertex3fv P073(0)
    glEnd
End Sub

Sub Dolphin003()

    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glEnd
End Sub

Sub Dolphin004()

    glBegin (GL_POLYGON)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glEnd
End Sub

Sub Dolphin005()

    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glEnd
End Sub

Sub Dolphin006()

    glBegin (GL_POLYGON)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N093(0)
    glVertex3fv P093(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N093(0)
    glVertex3fv P093(0)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N122(0)
    glVertex3fv P122(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N122(0)
    glVertex3fv P122(0)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glEnd
End Sub

Sub Dolphin007()

    glBegin (GL_POLYGON)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glEnd
End Sub

Sub Dolphin008()

    glBegin (GL_POLYGON)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glEnd
End Sub

Sub Dolphin009()

    glBegin (GL_POLYGON)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
End Sub

Sub Dolphin010()

    glBegin (GL_POLYGON)
    glNormal3fv N080(0)
    glVertex3fv P080(0)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N090(0)
    glVertex3fv P090(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N080(0)
    glVertex3fv P080(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glNormal3fv N090(0)
    glVertex3fv P090(0)
    glEnd
End Sub

Sub Dolphin011()

    glBegin (GL_POLYGON)
    glNormal3fv N082(0)
    glVertex3fv P082(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N082(0)
    glVertex3fv P082(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
End Sub

Sub Dolphin012()

    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glEnd
End Sub

Sub Dolphin013()

    glBegin (GL_POLYGON)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glNormal3fv N117(0)
    glVertex3fv P117(0)
    glNormal3fv N112(0)
    glVertex3fv P112(0)
    glNormal3fv N113(0)
    glVertex3fv P113(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N114(0)
    glVertex3fv P114(0)
    glNormal3fv N113(0)
    glVertex3fv P113(0)
    glNormal3fv N112(0)
    glVertex3fv P112(0)
    glNormal3fv N115(0)
    glVertex3fv P115(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N114(0)
    glVertex3fv P114(0)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glNormal3fv N113(0)
    glVertex3fv P113(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N114(0)
    glVertex3fv P114(0)
    glNormal3fv N007(0)
    glVertex3fv P007(0)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N007(0)
    glVertex3fv P007(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P002(0)
    glVertex3fv P007(0)
    glVertex3fv P008(0)
    glVertex3fv P099(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P007(0)
    glVertex3fv P114(0)
    glVertex3fv P115(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N117(0)
    glVertex3fv P117(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N117(0)
    glVertex3fv P117(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N112(0)
    glVertex3fv P112(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N112(0)
    glVertex3fv P112(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N115(0)
    glVertex3fv P115(0)
    glEnd
End Sub

Sub Dolphin014()

    glBegin (GL_POLYGON)
    glNormal3fv N111(0)
    glVertex3fv P111(0)
    glNormal3fv N110(0)
    glVertex3fv P110(0)
    glNormal3fv N102(0)
    glVertex3fv P102(0)
    glNormal3fv N121(0)
    glVertex3fv P121(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N111(0)
    glVertex3fv P111(0)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glNormal3fv N110(0)
    glVertex3fv P110(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glNormal3fv N110(0)
    glVertex3fv P110(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P098(0)
    glVertex3fv P097(0)
    glVertex3fv P111(0)
    glVertex3fv P121(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P002(0)
    glVertex3fv P099(0)
    glVertex3fv P097(0)
    glVertex3fv P098(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N110(0)
    glVertex3fv P110(0)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glNormal3fv N118(0)
    glVertex3fv P118(0)
    glNormal3fv N102(0)
    glVertex3fv P102(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N119(0)
    glVertex3fv P119(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N118(0)
    glVertex3fv P118(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N118(0)
    glVertex3fv P118(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N118(0)
    glVertex3fv P118(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N098(0)
    glVertex3fv P098(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N118(0)
    glVertex3fv P118(0)
    glNormal3fv N098(0)
    glVertex3fv P098(0)
    glNormal3fv N102(0)
    glVertex3fv P102(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N102(0)
    glVertex3fv P102(0)
    glNormal3fv N098(0)
    glVertex3fv P098(0)
    glNormal3fv N121(0)
    glVertex3fv P121(0)
    glEnd
End Sub

Sub Dolphin015()

    glBegin (GL_POLYGON)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glNormal3fv N117(0)
    glVertex3fv P117(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glNormal3fv N117(0)
    glVertex3fv P117(0)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N120(0)
    glVertex3fv P120(0)
    glNormal3fv N116(0)
    glVertex3fv P116(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
End Sub

Sub Dolphin016()


    glDisable (GL_DEPTH_TEST)
    glBegin (GL_POLYGON)
    glVertex3fv P123(0)
    glVertex3fv P124(0)
    glVertex3fv P125(0)
    glVertex3fv P126(0)
    glVertex3fv P127(0)
    glVertex3fv P128(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P129(0)
    glVertex3fv P130(0)
    glVertex3fv P131(0)
    glVertex3fv P132(0)
    glVertex3fv P133(0)
    glVertex3fv P134(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P103(0)
    glVertex3fv P105(0)
    glVertex3fv P108(0)
    glEnd
    glEnable (GL_DEPTH_TEST)
End Sub

Sub DrawDolphin(Fish As fishRec)

    Dim seg0 As Double, seg1 As Double, seg2 As Double, seg3 As Double, seg4 As Double, seg5 As Double, seg6 As Double, seg7 As Double
    Dim pitch As Double, thrash As Double, chomp As Double

    Fish.htail = CInt(Fish.htail - CInt(10# * Fish.v)) Mod 360

    thrash = 70# * Fish.v

    seg0 = 1# * thrash * Sin((Fish.htail) * RRAD)
    seg3 = 1# * thrash * Sin((Fish.htail) * RRAD)
    seg1 = 2# * thrash * Sin((Fish.htail + 4#) * RRAD)
    seg2 = 3# * thrash * Sin((Fish.htail + 6#) * RRAD)
    seg4 = 4# * thrash * Sin((Fish.htail + 10#) * RRAD)
    seg5 = 4.5 * thrash * Sin((Fish.htail + 15#) * RRAD)
    seg6 = 5# * thrash * Sin((Fish.htail + 20#) * RRAD)
    seg7 = 6# * thrash * Sin((Fish.htail + 30#) * RRAD)

    pitch = Fish.v * Sin((Fish.htail + 180#) * RRAD)

    If (Fish.v > 2#) Then
        chomp = -(Fish.v - 2#) * 200#
    End If
    chomp = 100#

    P012(1) = iP012(1) + seg5
    P013(1) = iP013(1) + seg5
    P014(1) = iP014(1) + seg5
    P015(1) = iP015(1) + seg5
    P016(1) = iP016(1) + seg5
    P017(1) = iP017(1) + seg5
    P018(1) = iP018(1) + seg5
    P019(1) = iP019(1) + seg5

    P020(1) = iP020(1) + seg4
    P021(1) = iP021(1) + seg4
    P022(1) = iP022(1) + seg4
    P023(1) = iP023(1) + seg4
    P024(1) = iP024(1) + seg4
    P025(1) = iP025(1) + seg4
    P026(1) = iP026(1) + seg4
    P027(1) = iP027(1) + seg4

    P028(1) = iP028(1) + seg2
    P029(1) = iP029(1) + seg2
    P030(1) = iP030(1) + seg2
    P031(1) = iP031(1) + seg2
    P032(1) = iP032(1) + seg2
    P033(1) = iP033(1) + seg2
    P034(1) = iP034(1) + seg2
    P035(1) = iP035(1) + seg2

    P036(1) = iP036(1) + seg1
    P037(1) = iP037(1) + seg1
    P038(1) = iP038(1) + seg1
    P039(1) = iP039(1) + seg1
    P040(1) = iP040(1) + seg1
    P041(1) = iP041(1) + seg1
    P042(1) = iP042(1) + seg1
    P043(1) = iP043(1) + seg1

    P044(1) = iP044(1) + seg0
    P045(1) = iP045(1) + seg0
    P046(1) = iP046(1) + seg0
    P047(1) = iP047(1) + seg0
    P048(1) = iP048(1) + seg0
    P049(1) = iP049(1) + seg0
    P050(1) = iP050(1) + seg0
    P051(1) = iP051(1) + seg0

    P009(1) = iP009(1) + seg6
    P010(1) = iP010(1) + seg6
    P075(1) = iP075(1) + seg6
    P076(1) = iP076(1) + seg6

    P001(1) = iP001(1) + seg7
    P011(1) = iP011(1) + seg7
    P068(1) = iP068(1) + seg7
    P069(1) = iP069(1) + seg7
    P070(1) = iP070(1) + seg7
    P071(1) = iP071(1) + seg7
    P072(1) = iP072(1) + seg7
    P073(1) = iP073(1) + seg7
    P074(1) = iP074(1) + seg7

    P091(1) = iP091(1) + seg3
    P092(1) = iP092(1) + seg3
    P093(1) = iP093(1) + seg3
    P094(1) = iP094(1) + seg3
    P095(1) = iP095(1) + seg3
    P122(1) = iP122(1) + seg3 * 1.5

    P097(1) = iP097(1) + chomp
    P098(1) = iP098(1) + chomp
    P102(1) = iP102(1) + chomp
    P110(1) = iP110(1) + chomp
    P111(1) = iP111(1) + chomp
    P121(1) = iP121(1) + chomp
    P118(1) = iP118(1) + chomp
    P119(1) = iP119(1) + chomp

    glPushMatrix

    glRotatef pitch, 1#, 0#, 0#

    glTranslatef 0#, 0#, 7000#

    glRotatef 180#, 0#, 1#, 0#

    glEnable (GL_CULL_FACE)
    Dolphin014
    Dolphin010
    Dolphin009
    Dolphin012
    Dolphin013
    Dolphin006
    Dolphin002
    Dolphin001
    Dolphin003
    Dolphin015
    Dolphin004
    Dolphin005
    Dolphin007
    Dolphin008
    Dolphin011
    Dolphin016
    glDisable (GL_CULL_FACE)

    glPopMatrix
End Sub
