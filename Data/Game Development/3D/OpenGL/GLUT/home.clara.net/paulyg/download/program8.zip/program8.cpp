/*
 *              Program 8.
 *
 *    Another simple example;  This time, we use the alpha channel in an image
 *    to control transparency.
 *
 *              Press '1' and '2' on the keyboard to toggle the alpha test.
 *
 */

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include "tgaload.h"

/*      Some macros for naming the textures */
#define         MAX_TEXTURES    1
#define         TREE_IMAGE      0

float angle;

/* Start the program with the alpha test on.  */
bool alpha_test = true;

/* Vertex Array object description:
 * These arrays contain the vertex data, indices for the vertices, and colours
 * for each vertex.
 */

GLfloat vertices[] =  { -1.0,  1.0,  0.0,
                         1.0,  1.0,  0.0,
                         1.0, -1.0,  0.0,
                        -1.0, -1.0,  0.0 };

GLfloat tex_coords[] = { 0.0, 1.0,
                         1.0, 1.0,
                         1.0, 0.0,
                         0.0, 0.0 };

GLuint  indices[] = { 0, 1, 2, 3 };

/* Variables to hold our images and texture IDs   */
GLuint  tex_id[MAX_TEXTURES];


/*      Initialise:
 *      Enable the OpenGL arrays that contain our object data.
 */
void init( void )
{
   glEnable      ( GL_TEXTURE_2D );
   glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
   glGenTextures ( MAX_TEXTURES, tex_id );

   tex_id[TREE_IMAGE] = tgaLoadAndBind  ( "tree.tga", TGA_DEFAULT );

   glEnable ( GL_DEPTH_TEST );
   glEnableClientState ( GL_VERTEX_ARRAY );
   glEnableClientState ( GL_TEXTURE_COORD_ARRAY );
   glClearColor ( 0.0, 0.5, 1.0, 1.0 );

   glVertexPointer   ( 3, GL_FLOAT, 0, &vertices );
   glTexCoordPointer ( 2, GL_FLOAT, 0, &tex_coords );

   /*  Alpha test specifics  */
   glAlphaFunc ( GL_GREATER, 0.3 );
   glEnable    ( GL_ALPHA_TEST   );
}


/*      Standard display callback
 */
void display ( void )
{
   glClear    ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, -3.0 );
   glRotatef    ( angle, 0.0, 1.0, 0.0 );

   /*  Draw the quad, texture mapped with the tree image  */
   glBindTexture  ( GL_TEXTURE_2D, tex_id[TREE_IMAGE] );
   glDrawElements ( GL_QUADS, 4, GL_UNSIGNED_INT, indices );
   glPopMatrix     ( );
   glutSwapBuffers ( );
}


void reshape ( int w, int h )
{
   glViewport   ( 0, 0, ( GLint ) w, ( GLint ) h );
   glMatrixMode ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, ( GLdouble ) w, 1.0, 20.0 );
   else
      gluPerspective ( 45, ( GLdouble ) w / ( GLdouble ) h ,1.0, 20.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );
}


void idle_func ( void )
{
   angle = angle + 0.1;
   if ( angle == 360 )
      angle = 0;
   glutPostRedisplay ( );
}

#pragma argsused
void keyboard ( unsigned char key, int x, int y )
{
   int i;

   switch ( key ) {
      case 27:  /*  Escape key  */
         exit ( 0 );
         break;
      case 'l':
         for ( i = 0; i <= MAX_TEXTURES; i++ )
         {
            glBindTexture   ( GL_TEXTURE_2D, tex_id[i] );
            tgaSetTexParams ( GL_LINEAR, GL_LINEAR, GL_MODULATE );
         }
         break;
      case 'n':
         for ( i = 0; i <= MAX_TEXTURES; i ++ )
         {
            glBindTexture   ( GL_TEXTURE_2D, tex_id[i] );
            tgaSetTexParams ( GL_NEAREST, GL_NEAREST, GL_MODULATE );
         }
        break;
      case 'f':
        glutFullScreen ( );
        break;
      case 'w':
         glutReshapeWindow ( 500,500 );
         break;
      case '1':
         glDisable ( GL_ALPHA_TEST );
         break;
      case '2':
         glEnable  ( GL_ALPHA_TEST );
         break;
      default:
         break;
   }
}


/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
int main ( int argc, char** argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( argv[0] );
   
   glutReshapeFunc  ( reshape   );
   glutKeyboardFunc ( keyboard  );
   glutDisplayFunc  ( display   );
   glutIdleFunc     ( idle_func );

   init ( );

   glutMainLoop    ( );
   return 0;
}