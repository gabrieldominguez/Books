class AwesomePawn extends UTPawn;

simulated function PostBeginPlay()
{
    super.PostBeginPlay();
    `log("AwesomePawn spawned! =====");
    if(ArmsMesh[0] != none)
        ArmsMesh[0].SetHidden(true);
    if(ArmsMesh[1] != none)
        ArmsMesh[1].SetHidden(true);
}

defaultproperties
{
}
