Attribute VB_Name = "modCommonDialog"
Option Explicit
' D�claration de fonctions API
Public Declare Function GetSaveFileName Lib "comdlg32.dll" Alias "GetSaveFileNameA" ( _
                                        pOpenfilename As OPENFILENAME) As Long
Public Declare Function GetOpenFileName Lib "comdlg32.dll" Alias "GetOpenFileNameA" ( _
                                        pOpenfilename As OPENFILENAME) As Long
' D�claration de type
Public Type OPENFILENAME
    lStructSize As Long
    hwndOwner As Long
    hInstance As Long
    lpstrFilter As String
    lpstrCustomFilter As String
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As String
    nMaxFile As Long
    lpstrFileTitle As String
    nMaxFileTitle As Long
    lpstrInitialDir As String
    lpstrTitle As String
    flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As String
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As String
End Type
' D�claration de constantes
Public Enum esFlags
    OFN_ALLOWMULTISELECT = &H200
    OFN_CREATEPROMPT = &H2000
    OFN_ENABLEHOOK = &H20
    OFN_ENABLETEMPLATE = &H40
    OFN_ENABLETEMPLATEHANDLE = &H80
    OFN_EXPLORER = &H80000
    OFN_EXTENSIONDIFFERENT = &H400
    OFN_FILEMUSTEXIST = &H1000
    OFN_HIDEREADONLY = &H4
    OFN_LONGNAMES = &H200000
    OFN_NOCHANGEDIR = &H8
    OFN_NODEREFERENCELINKS = &H100000
    OFN_NOLONGNAMES = &H40000
    OFN_NONETWORKBUTTON = &H20000
    OFN_NOREADONLYRETURN = &H8000
    OFN_NOTESTFILECREATE = &H10000
    OFN_NOVALIDATE = &H100
    OFN_OVERWRITEPROMPT = &H2
    OFN_PATHMUSTEXIST = &H800
    OFN_READONLY = &H1
    OFN_SHAREAWARE = &H4000
    OFN_SHOWHELP = &H10
End Enum
' Variables de stockage des derni�res reponses
Public lgLastIdxFilter As Long

Public Function Save(lgHwnd As Long, stFiltre As String, lgIdxFiltre As Long, _
                     Optional lgFlags As esFlags = OFN_EXPLORER + OFN_LONGNAMES + _
                                        OFN_PATHMUSTEXIST + OFN_NOREADONLYRETURN, _
                     Optional stTitre As String = vbNullString, _
                     Optional stInitFile As String = vbNullString, _
                     Optional stInitDir As String = vbNullString, _
                     Optional stDefautExt As String = vbNullString) As String
' Fen�tre "Enregistrer un fichier"
Dim tyDialog As OPENFILENAME
Dim lgRep As Long
tyDialog.lStructSize = Len(tyDialog)
tyDialog.hwndOwner = lgHwnd                     ' Handle du propri�traire de la fen�tre
tyDialog.hInstance = App.hInstance
tyDialog.lpstrFilter = Replace(stFiltre, "|", vbNullChar) & vbNullChar & vbNullChar
tyDialog.lpstrCustomFilter = vbNullString       ' Filtre personnalis� (non g�r�)
tyDialog.nMaxCustFilter = 0                     ' Index de filtre personnalis� (non g�r�)
tyDialog.nFilterIndex = lgIdxFiltre             ' Index du filtre � utiliser par d�faut
' Nom de fichier affich� � l'initialisation de la fen�tre
tyDialog.lpstrFile = Left$(stInitFile & String$(1024, vbNullChar), 1024)
tyDialog.nMaxFile = Len(tyDialog.lpstrFile) - 1 ' Longueur du nom de fichier
tyDialog.lpstrFileTitle = tyDialog.lpstrFile    ' Nom et extension du fichier (sans chemin)
tyDialog.nMaxFileTitle = tyDialog.nMaxFile      ' Taille de la cha�ne pr�c�dente
tyDialog.lpstrInitialDir = stInitDir            ' R�pertoire initial
tyDialog.lpstrTitle = stTitre                   ' Titre de la fen�tre
tyDialog.flags = lgFlags                        ' Flags pour affichage de la fen�tre
'tyDialog.nFileOffset                           ' Position du nom du fichier dans la cha�ne
'tyDialog.nFileExtension                        ' Position de l'extension du fichier dans la cha�ne
' Extension par d�faut ajout�e automatiquement si l'utilisateur l'oublie
tyDialog.lpstrDefExt = stDefautExt
tyDialog.lCustData = 0
tyDialog.lpfnHook = 0
tyDialog.lpTemplateName = 0
' Affichage de la bo�te de dialogue
lgRep = GetSaveFileName(tyDialog)
' Retourne le nom long du fichier
lgLastIdxFilter = tyDialog.nFilterIndex
Save = Left$(tyDialog.lpstrFile, InStr(1, tyDialog.lpstrFile, vbNullChar) - 1)
End Function

Public Function OpenFile(lgHwnd As Long, stFiltre As String, lgIdxFiltre As Long, _
                Optional lgFlags As esFlags = OFN_EXPLORER + OFN_LONGNAMES + OFN_PATHMUSTEXIST, _
                Optional stTitre As String = vbNullString, _
                Optional stInitFile As String = vbNullString, _
                Optional stInitDir As String = vbNullString, _
                Optional stDefautExt As String = vbNullString) As String
' Fen�tre "Enregistrer un fichier"
Dim tyDialog As OPENFILENAME
Dim lgRep As Long
tyDialog.lStructSize = Len(tyDialog)
tyDialog.hwndOwner = lgHwnd                     ' Handle du propri�traire de la fen�tre
tyDialog.hInstance = App.hInstance
tyDialog.lpstrFilter = Replace(stFiltre, "|", vbNullChar) & vbNullChar & vbNullChar
tyDialog.lpstrCustomFilter = vbNullString       ' Filtre personnalis� (non g�r�)
tyDialog.nMaxCustFilter = 0                     ' Index de filtre personnalis� (non g�r�)
tyDialog.nFilterIndex = lgIdxFiltre             ' Index du filtre � utiliser par d�faut
' Nom de fichier affich� � l'initialisation de la fen�tre
tyDialog.lpstrFile = Left$(stInitFile & String$(1024, vbNullChar), 1024)
tyDialog.nMaxFile = Len(tyDialog.lpstrFile) - 1 ' Longueur du nom de fichier
tyDialog.lpstrFileTitle = tyDialog.lpstrFile    ' Nom et extension du fichier (sans chemin)
tyDialog.nMaxFileTitle = tyDialog.nMaxFile      ' Taille de la cha�ne pr�c�dente
tyDialog.lpstrInitialDir = stInitDir            ' R�pertoire initial
tyDialog.lpstrTitle = stTitre                   ' Titre de la fen�tre
tyDialog.flags = lgFlags                        ' Flags pour affichage de la fen�tre
'tyDialog.nFileOffset                           ' Position du nom du fichier dans la cha�ne
'tyDialog.nFileExtension                        ' Position de l'extension du fichier dans la cha�ne
' Extension par d�faut ajout�e automatiquement si l'utilisateur l'oublie
tyDialog.lpstrDefExt = stDefautExt
tyDialog.lCustData = 0
tyDialog.lpfnHook = 0
tyDialog.lpTemplateName = 0
' Affichage de la bo�te de dialogue
lgRep = GetOpenFileName(tyDialog)
' Retourne le nom long du fichier
lgLastIdxFilter = tyDialog.nFilterIndex
OpenFile = Left$(tyDialog.lpstrFile, InStr(1, tyDialog.lpstrFile, vbNullChar) - 1)
End Function
