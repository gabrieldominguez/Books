VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxCurve"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: helper class for glxMesh
'
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Private Type pt3f
    x As Single
    y As Single
    z As Single
End Type
'
Dim m_NumPoints&
Dim m_Pts() As pt3f

Public Sub Init(numPts&)
    m_NumPoints = numPts
    If numPts Then
        ReDim m_Pts(0 To numPts - 1)
    End If
End Sub

Public Property Get NumPoints&()
    NumPoints = m_NumPoints
End Property

Public Property Let NumPoints(ByVal n&)
    m_NumPoints = n
End Property

Public Property Get x!(ByVal Index&)
x = m_Pts(Index).x
End Property

Public Property Let x(ByVal Index&, ByVal NewValue!)
m_Pts(Index).x = NewValue
End Property

Public Property Get y!(ByVal Index&)
y = m_Pts(Index).y
End Property

Public Property Let y(ByVal Index&, ByVal NewValue!)
m_Pts(Index).y = NewValue
End Property

Public Property Get z!(ByVal Index&)
z = m_Pts(Index).z
End Property

Public Property Let z(ByVal Index&, ByVal NewValue!)
m_Pts(Index).z = NewValue
End Property


