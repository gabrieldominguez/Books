
#include <windows.h>
#include <stdio.h>
#include <GL/glut.h>

#include "mlkLoad.h"


// Angles here
float angle, angle2, cloud_rot;
float zoom = -25.50;

int enableTexturing = 1;

int moving, startx, starty;
mlkObject_t    *my_object;


GLfloat  ambient_light[] = {0.45, 0.4, 0.4, 1.0};
GLfloat   source_light[] = {0.7, 0.6, 0.6, 1.0};
GLfloat      light_pos[] = {20.0, 10.0, 0.0, 1.0};


void init ( void )
{
   glEnable    ( GL_DEPTH_TEST );
   glEnable    ( GL_CULL_FACE  );
   glFrontFace ( GL_CCW        );

   glShadeModel (GL_SMOOTH);

   glEnable ( GL_LIGHTING );
   glLightModelfv ( GL_LIGHT_MODEL_AMBIENT, ambient_light );
   glLightfv ( GL_LIGHT0, GL_DIFFUSE, source_light );
   glLightfv ( GL_LIGHT0, GL_POSITION, light_pos   );
   glEnable  ( GL_LIGHT0 );

    // Enable material properties for lighting
    glEnable ( GL_COLOR_MATERIAL );
    glColorMaterial( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );
    glEnable ( GL_TEXTURE_2D );

    glEnableClientState ( GL_VERTEX_ARRAY );
    glEnableClientState ( GL_NORMAL_ARRAY );
    glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

    glPolygonMode ( GL_FRONT_AND_BACK, GL_FILL );
    glClearColor  ( 0.0, 0.0, 0.0, 0.0);

   my_object = mlkLoad ( "enterprise.txt" );
}


void display ( void )
{
   glClear   ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
   glLightfv ( GL_LIGHT0, GL_POSITION, light_pos         );
   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, zoom );
   glRotatef ( angle2, 1.0, 0.0, 0.0 );
   glRotatef ( angle, 0.0, 1.0, 0.0  );

   // Draw the loaded mesh object
   mlkDrawObject ( my_object );

   glPopMatrix();
   glutSwapBuffers();
}

void reshape(int w, int h)
{
   glViewport(0, 0, (GLint) w, (GLint) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   if ( h==0 )
      gluPerspective(45, (GLdouble)w, 1.0, 2000.0);
   else
      gluPerspective(45, (GLdouble)w/ (GLdouble)h, 1.0, 2000.0);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void mouse ( int button, int state, int x, int y )
{
   if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
   {
      moving = 1;
      startx = x;
      starty = y;
   }
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      moving = 0;


   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
   {
      moving = 2;
      starty = y;
   }
   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_UP )
      moving = 0;
}


void motion ( int x, int y )
{
   if ( moving == 1 )
   {
      angle = angle   + ( x - startx );
      angle2 = angle2 + ( y - starty );
      startx = x;
      starty = y;
      glutPostRedisplay ( );
   }
   if ( moving == 2 )
   {
      zoom = zoom + ( y - starty );
      starty = y;
      glutPostRedisplay ( );
  }
}

void idle_func ( void )
{
   angle = angle + 0.1;
   if ( angle == 360 )
      angle = 0;
   glutPostRedisplay( );
}

#pragma argsused
void keyboard ( unsigned char key, int x, int y )
{
   switch ( key )
   {
      case 27:  /*  Escape key  */
         mlkFreeObject ( my_object );
         exit ( 0 );
         break;

      case '1':
         enableTexturing ^= 1;
         if ( enableTexturing )
            glEnable ( GL_TEXTURE_2D );
         else
            glDisable ( GL_TEXTURE_2D );
         break;
      case 'f':
         glutFullScreen ( );
         break;

      case 'w':
         glutReshapeWindow ( 250,250 );
         break;
         
      default:
         break;
   }
}


/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGBA display mode, and handle input events.
 */
#pragma argsused
int main(int argc, char** argv)
{
   glutInitDisplayMode ( GLUT_RGBA | GLUT_DOUBLE );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( "Milkshape Vertex-array loader" );

   init ( );

   glutReshapeFunc  ( reshape   );
   glutMouseFunc    ( mouse     );
   glutMotionFunc   ( motion    );
   glutKeyboardFunc ( keyboard  );
   glutDisplayFunc  ( display   );
   glutIdleFunc     ( idle_func );
   glutMainLoop ( );

   return 0;
}
