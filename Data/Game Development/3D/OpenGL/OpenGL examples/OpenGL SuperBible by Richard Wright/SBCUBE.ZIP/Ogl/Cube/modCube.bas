Attribute VB_Name = "mCube"
Public Sub RenderScene()

' Routine to draw I Section

    Dim Wd, Ln, Ht As GLfloat
    Dim Wd2, Ln2, Ht2 As GLfloat
    Dim V(2, 2) As Single
    Dim PtSize(1) As GLfloat
    Dim PtStep As GLfloat
    Dim PtSizeNew As GLfloat
    
    Wd = 50#
    Ht = 50#
    Ln = 100#
    
    Wd2 = Wd / 2#
    Ht2 = Ht / 2#
    Ln2 = Ln / 2#
    
    glGetFloatv glgPointSizeRange, PtSize(0)
    glGetFloatv glgPointSizeGranularity, PtStep
    PtSizeNew = (PtSize(0) + PtStep * 5)
    glPointSize PtSizeNew
    
    glClear clrColorBufferBit + clrDepthBufferBit
   
    ' Save matrix state and do the rotation
    glPushMatrix
    glRotatef xRot, 1#, 0#, 0#
    glRotatef yRot, 0#, 1#, 0#
     
    frmDisplay.Text1.Text = xRot
    frmDisplay.Text2.Text = yRot
    glFrontFace ffCCW
    
'C-----------------------------------------------------------
'C----Declaration 1
'C-----------------------------------------------------------
    
    glRGB 255, 0, 0

        V(0, 0) = Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = -Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 2
'C-----------------------------------------------------------
        
        V(0, 0) = -Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 3
'C-----------------------------------------------------------
    
    glRGB 0, 255, 0
        
        V(0, 0) = Wd2
        V(0, 1) = Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 4
'C-----------------------------------------------------------
        
        V(0, 0) = -Wd2
        V(0, 1) = Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)

'C-----------------------------------------------------------
'C----Declaration 5
'C-----------------------------------------------------------
    
    glRGB 0, 0, 255
        
        V(0, 0) = Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = -Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = Wd2
        V(2, 1) = Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 6
'C-----------------------------------------------------------
        
        V(0, 0) = Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = Wd2
        V(2, 1) = Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
    glFrontFace ffCW

'C-----------------------------------------------------------
'C----Declaration 7
'C-----------------------------------------------------------
    
    glRGB 255, 0, 0

        V(0, 0) = Wd2
        V(0, 1) = -Ht2
        V(0, 2) = -Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = -Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 8
'C-----------------------------------------------------------
        
        V(0, 0) = -Wd2
        V(0, 1) = -Ht2
        V(0, 2) = -Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 9
'C-----------------------------------------------------------
    
    glRGB 0, 255, 0
        
        V(0, 0) = Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = -Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = -Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 10
'C-----------------------------------------------------------
        
        V(0, 0) = -Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = Wd2
        V(1, 1) = -Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = -Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)

'C-----------------------------------------------------------
'C----Declaration 11
'C-----------------------------------------------------------
    
    glRGB 0, 0, 255
        
        V(0, 0) = -Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = -Wd2
        V(1, 1) = -Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = -Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----Declaration 12
'C-----------------------------------------------------------
        
        V(0, 0) = -Wd2
        V(0, 1) = -Ht2
        V(0, 2) = Ln2
        
        V(1, 0) = -Wd2
        V(1, 1) = Ht2
        V(1, 2) = -Ln2
        
        V(2, 0) = -Wd2
        V(2, 1) = Ht2
        V(2, 2) = Ln2
        
        Call TriAngle(V)
    
'C-----------------------------------------------------------
'C----
'C-----------------------------------------------------------
    
    ' Restore Transformations
     glPopMatrix
    
    SwapBuffers frmDisplay.hDC
    
    ' Flush drawing commands
    glFlush
    
End Sub
