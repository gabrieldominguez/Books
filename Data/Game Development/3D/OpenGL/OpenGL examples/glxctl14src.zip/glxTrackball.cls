VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxTrackball"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: Provides rotation with the mouse. Scene is rotated around its
'center.
'AUTHOR: ported by edx - edx@hk.super.net
'   from trackball.c in GLUT, by G.Bell.
'HISTORY: 3/99 - consolidated some code to the V3 and Quat routines
'-------------------------------------------------------------------------
' * Trackball code:
' * Implementation of a virtual trackball.
' * Implemented by Gavin Bell, lots of ideas from Thant Tessman and
' *   the August '88 issue of Siggraph's "Computer Graphics," pp. 121-129.
' * Vector manip code:
' * Original code from:
' * David M. Ciemiewicz, Mark Grossman, Henry Moreton, and Paul Haeberli
' * Much mucking with by:
' * Gavin Bell
'
' * This size should really be based on the distance from the center of
' * rotation to the point on the object underneath the mouse.  That
' * point would then track the mouse as closely as possible.  This is a
' * simple example, though, so that is left as an Exercise for the
' * Programmer.
'
Const TRACKBALLSIZE = (0.8)
Const RENORMCOUNT = 97
Dim lastquat!(0 To 3)
Dim curquat!(0 To 3)
Dim m_MouseX&, m_MouseY& 'current mouse coords
Dim m_Width&, m_Height&
Dim m_bSpinning As Boolean
Dim m_Button&
Dim m_Animate As Boolean

Private Sub Class_Initialize()
    m_Button = 2
    Trackball curquat, 0, 0, 0, 0
End Sub

'-------------------------------------------------------------------------
Public Property Let Animate(NewValue As Boolean)
    m_Animate = NewValue
End Property

Public Property Get Animate() As Boolean
    Animate = m_Animate
End Property

'-------------------------------------------------------------------------
Public Property Get Button() As Long
    Button = m_Button
End Property

Public Property Let Button(ByVal NewValue As Long)
    m_Button = NewValue
End Property

'-------------------------------------------------------------------------
Public Sub Reset()
    UC.Ex.FillArrayf curquat, 0, 0, 0, 0
    UC.Ex.FillArrayf lastquat, 0, 0, 0, 0
    Trackball curquat, 0, 0, 0, 0
    m_bSpinning = 0
End Sub

'-------------------------------------------------------------------------
Public Sub MouseDown(Button As Integer, shift As Integer, X As Single, Y As Single)
    m_MouseX = X
    m_MouseY = Y
    If Button = m_Button Then
        If Abs(m_MouseX - X) < 4 And Abs(m_MouseY - Y) - 4 Then
            m_bSpinning = False
        End If
    End If
End Sub

Public Sub MouseMove(Button As Integer, shift As Integer, X As Single, Y As Single)
On Error Resume Next
    If Button = m_Button Then
        If m_MouseX <> X Or m_MouseY <> Y Then
            Trackball lastquat, _
                (2 * m_MouseX - m_Width) / m_Width, _
                (m_Height - 2 * m_MouseY) / m_Height, _
                (2 * X - m_Width) / m_Width, _
                (m_Height - 2 * Y) / m_Height
            m_bSpinning = True
        Else
            m_bSpinning = 0
        End If
    End If
    m_MouseX = X
    m_MouseY = Y
End Sub

Public Sub MouseUp(Button As Integer, shift As Integer, X As Single, Y As Single)
    m_MouseX = X
    m_MouseY = Y
    If m_Animate = 0 Then m_bSpinning = 0
End Sub

'-------------------------------------------------------------------------
'the ocx uses this to notify the TB of the window size
'-------------------------------------------------------------------------
Public Sub Resize(Width&, Height&)
    'return 0 so ocx won't do anything
    m_Width = Width
    m_Height = Height
End Sub

'-------------------------------------------------------------------------
'Call this from your Draw routine
'-------------------------------------------------------------------------
Public Sub Update()
Dim m!(0 To 15)
    '
    If m_bSpinning Then
        add_quats lastquat, curquat, curquat
    End If
    '
    build_rotmatrix m, curquat
    glMultMatrixf m(0)
End Sub

'-------------------------------------------------------------------------
' * Ok, simulate a track-ball.  Project the points onto the virtual
' * trackball, then figure out the axis of rotation, which is the cross
' * product of P1 P2 and O P1 (O is the center of the ball, 0,0,0)
' * Note:  This is a deformed trackball-- is a trackball in the center,
' * but is deformed into a hyperbolic sheet of rotation away from the
' * center.  This particular function was chosen after trying out
' * several variations.
' *
' * It is assumed that the arguments to this routine are in the range
' * (-1.0 ... 1.0)
'-------------------------------------------------------------------------
Public Sub Trackball(q!(), p1x!, p1y!, p2x!, p2y!)
Dim A!(0 To 2) '  Axis of rotation
Dim phi! '   how much to rotate about axis
Dim p1!(0 To 2), p2!(0 To 2), d!(0 To 2)
Dim t!
On Error GoTo EH
    If (p1x = p2x And p1y = p2y) Then
        ' Zero rotation
        V3Zerof q
        q(3) = 1
        Exit Sub
    End If
    '
    ' * First, figure out z-coordinates for projection of P1 and P2 to
    ' * deformed sphere
    V3Makef p1, p1x, p1y, ProjectToSphere(TRACKBALLSIZE, p1x, p1y)
    V3Makef p2, p2x, p2y, ProjectToSphere(TRACKBALLSIZE, p2x, p2y)
    '
    ' *  Now, we want the cross product of P1 and P2
    V3Crossf A, p2, p1
    '
    ' *  Figure out how much to rotate around that axis.
    V3Subf d, p1, p2
    V3Lengthf t, d
    t = t / (2 * TRACKBALLSIZE)

    ' * Avoid problems with out-of-control values...
    If (t > 1) Then t = 1
    If (t < -1) Then t = -1
    phi = 2 * ArcSin(t)

    QuatFromAxisRad q, A, phi
    'Debug.Print phi
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
' * Given two rotations, e1 and e2, expressed as quaternion rotations,
' * figure out the equivalent single rotation and stuff it into dest.
' * This routine also normalizes the result every RENORMCOUNT times it is
' * called, to keep error from creeping in.
' * NOTE: This routine is written so that q1 or q2 may be the same
' * as dest (or each other).
'-------------------------------------------------------------------------
Public Sub add_quats(q1!(), q2!(), dest!())
Static count&
On Error GoTo EH
    QuatAdd dest, q1, q2
    count = count + 1
    If count > RENORMCOUNT Then
        count = 0
        QuatNormalize dest
    End If
    Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
' * Build a rotation matrix, given a quaternion rotation.
Public Sub build_rotmatrix(m!(), q!())
On Error GoTo EH
    m(0) = 1 - 2 * (q(1) * q(1) + q(2) * q(2))
    m(1) = 2 * (q(0) * q(1) - q(2) * q(3))
    m(2) = 2 * (q(2) * q(0) + q(1) * q(3))
    m(3) = 0

    m(4) = 2 * (q(0) * q(1) + q(2) * q(3))
    m(5) = 1 - 2 * (q(2) * q(2) + q(0) * q(0))
    m(6) = 2 * (q(1) * q(2) - q(0) * q(3))
    m(7) = 0

    m(8) = 2 * (q(2) * q(0) - q(1) * q(3))
    m(9) = 2 * (q(1) * q(2) + q(0) * q(3))
    m(10) = 1 - 2 * (q(1) * q(1) + q(0) * q(0))
    m(11) = 0

    m(12) = 0
    m(13) = 0
    m(14) = 0
    m(15) = 1
    Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
'UTILITY ROUTINES
'   SetPos... - allows you to set to TB orientation
'   GetCurrent... - returns the current values
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'relative to 0,0,1
'-------------------------------------------------------------------------
Public Sub SetPosPt(ByVal X!, ByVal Y!, ByVal z!)
Dim A!(0 To 2) '  Axis of rotation
Dim phi! '   how much to rotate about axis
Dim p1!(0 To 2), p2!(0 To 2), d!(0 To 2)
Dim t!
On Error GoTo EH
    Reset
    If X = 0 And Y = 0 Then Exit Sub
    p1(2) = 1
    p2(0) = X
    p2(1) = Y
    p2(2) = z
    V3Normalizef p2
    V3Scalef p1, TRACKBALLSIZE, p1
    V3Scalef p2, TRACKBALLSIZE, p2
'    ' *  Now, we want the cross product of P1 and P2
    V3Crossf A, p2, p1
    ' *  Figure out how much to rotate around that axis.
    V3Subf d, p1, p2
    V3Lengthf t, d
    t = t / (2 * TRACKBALLSIZE)
    ' * Avoid problems with out-of-control values...
    '
    If (t > 1) Then
        t = 1
    End If
    If (t < -1) Then
        t = -1
    End If
    phi = 2 * ArcSin(t)

    QuatFromAxisRad curquat, A, phi
    Update
    Exit Sub
EH:
    Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
Public Sub SetPosDeg(ByVal rotX!, ByVal rotY!)
    With UC
        SetPosRad .Ex.DegToRad(rotX), .Ex.DegToRad(rotY)
    End With
End Sub

'-------------------------------------------------------------------------
Public Sub SetPosRad(ByVal rotX!, ByVal rotY!)
Dim X!, Y!, z!, z2!
    'xrot on the pt 0,0,1
    If rotX = 0 And rotY = 0 Then
        Reset
        Exit Sub
    End If
    z = Cos(rotX)
    Y = -Sin(rotX)
    z2 = z * Cos(rotY) - X * Sin(rotY)
    X = z * Sin(rotY) + X * Cos(rotY)
    SetPosPt X, Y, z2
End Sub

'-------------------------------------------------------------------------
Public Sub GetCurrentQuat(q4!())
Dim i&
On Error GoTo EH
    For i = 0 To 3
        q4(i) = curquat(i)
    Next
    Exit Sub
EH:
Debug.Assert 0
End Sub

'-------------------------------------------------------------------------
Public Sub GetCurrentRotMatrix(m16!())
    build_rotmatrix m16, curquat
End Sub
