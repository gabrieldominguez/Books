/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;

namespace BooGame
{
    /// <summary>
    /// A tile which has an associated animation.
    /// </summary>
    [Serializable]
    public class AnimatedTile : Tile
    {
        /// <summary>
        /// Creates an animated tile with the given animation.
        /// </summary>
        /// <param name="anim"></param>
        public AnimatedTile(Animation anim) : base(anim[0])
        {
            m_Animation = anim;
        }
        private Animation m_Animation;
        /// <summary>
        /// Describes the animation associated with the tile.
        /// </summary>
        public Animation Animation
        {
            get { return m_Animation; }
            set { m_Animation = value; }
        }

        /// <summary>
        /// Gets and sets the TileX of the animation's current frame.
        /// </summary>
        public override int TileX
        {
            get { return m_Animation[m_FrameProgression].TileX; }
            set { m_Animation[m_FrameProgression].TileX = value; }
        }

        /// <summary>
        /// Gets and sets the TileY of the animation's current frame.
        /// </summary>
        public override int TileY
        {
            get { return m_Animation[m_FrameProgression].TileY; }
            set { m_Animation[m_FrameProgression].TileY = value; }
        }

        /// <summary>
        /// Gets and sets the TileSet of the animation's current frame.
        /// </summary>
        public override TileSet TileSet
        {
            get { return m_Animation[m_FrameProgression].TileSet; }
            set { m_Animation[m_FrameProgression].TileSet = value; }
        }


        private float m_FrameProgression = 0f;
        /// <summary>
        /// Gets and sets the current animation's frame progression.
        /// </summary>
        public float FrameProgression
        {
            get { return m_FrameProgression; }
            set { m_FrameProgression = value; }
        }


        private bool m_Enabled = true;
        /// <summary>
        /// Enables or disables whether the animation is in progression.
        /// </summary>
        public bool Enabled
        {
            get { return m_Enabled; }
            set { m_Enabled = value; }
        }

        /// <summary>
        /// Updates the animation for the tile.
        /// </summary>
        public override void Update()
        {
            if (Enabled)
            {
                float animspeed = m_Animation.Speed;
                if (animspeed != 0f)
                {
                    m_FrameProgression += animspeed * Timer.DeltaSeconds;
                    if (animspeed > 0)
                    {
                        if (m_FrameProgression >= m_Animation.Frames.Count)
                            m_FrameProgression = 0f;
                    }
                    else
                    {
                        if (m_FrameProgression < 0f)
                            m_FrameProgression = (float)m_Animation.Frames.Count;
                    }
                }
                base.Update();
            }
        }
    }
}
