VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CArea"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Description = "A spatial plane which displays text or images"
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'--------------------------------------------------------------------
'FUNCTION: This class handles the drawing of a single text area.
'All persistent data is kept in the AREAREC to simply reading and
'writing, but the I/O routines may have some bugs.
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY: -
'NOTES:
'--------------------------------------------------------------------
Public Enum n3dBkgStyles
    bkg_None = 0
    bkg_Color = 1
    bkg_Image = 2
End Enum
Public Enum n3dBorderStyles
    bdr_None = 0
    bdr_Solid = 1
    bdr_Dot = 2
    bdr_Dash = 3
End Enum
'record for all the properties which will be saved
Private Type AREAREC
    Name As String 'string name for user
    Text As String
    Image As String
    Font As String
    Visible As Boolean
    Width As Single
    Height As Single
    depth As Single
    X As Single
    Y As Single
    z As Single
    rX As Single
    rY As Single
    rZ As Single
    sx As Single
    sy As Single
    ra As Single
    fRed As Single
    fBlue As Single
    fGreen As Single  'font color
    bRed As Single
    bBlue As Single
    bGreen As Single  'bkg color
    bdRed As Single
    bdBlue As Single
    bdGreen As Single  'border color
    BorderStyle As Long
    BkgStyle As Long
End Type
Public ID& ' an ID for this area object, the pick name
Dim m As AREAREC
Dim m_Selected As Boolean
Dim m_ListID&, m_Dirty As Boolean 'flag for compiling
Private m_Image As CImage
Dim m_Font As CFontTexture

Private Sub Class_Initialize()
    m.Width = 5
    m.Height = 5
    m.Visible = True
    m.sx = 1: m.sy = 1
    m.rZ = 1
    Font = "Arial Black"
    m.fRed = 1: m.fBlue = 1: m.fGreen = 1
    m_ListID = glGenLists(1)
    m.bdRed = 1: m.bdBlue = 1: m.bdGreen = 1
    m_Dirty = True
End Sub

Private Sub Class_Terminate()
'
End Sub

'---------------------------------------------------------
'PROPERTIES
'---------------------------------------------------------

'---------------------------------------------------------
'font
'---------------------------------------------------------
Public Property Get FontColor&()
    FontColor = RGB(m.fRed * 255, m.fGreen * 255, m.fBlue * 255)
End Property

Public Property Let FontColor(ByVal col&)
    m.fBlue = GetRValue(col) / 255
    m.fRed = GetBValue(col) / 255
    m.fGreen = GetGValue(col) / 255
    m_Dirty = True
End Property

Public Property Get Font$()
    Font = m.Font
End Property

Public Property Let Font(ByVal NewValue$)
    m.Font = NewValue
    Set m_Font = Fonts.LoadFont(m.Font)
    m_Dirty = True
End Property

Public Property Get Name$()
    Name$ = m.Name
End Property

Public Property Let Name(ByVal NewValue$)
    m.Name = NewValue
    m_Dirty = True
End Property

'---------------------------------------------------------
'bkg
'---------------------------------------------------------
Public Property Get BkgColor&()
    BkgColor = RGB(m.bRed * 255, m.bGreen * 255, m.bBlue * 255)
End Property

Public Property Let BkgColor(ByVal col&)
    m.bBlue = GetRValue(col) / 255
    m.bGreen = GetGValue(col) / 255
    m.bRed = GetBValue(col) / 255
    m_Dirty = True
End Property

Public Property Get BkgStyle() As n3dBkgStyles
    BkgStyle = m.BkgStyle
End Property

Public Property Let BkgStyle(ByVal NewValue As n3dBkgStyles)
    m.BkgStyle = NewValue
    m_Dirty = True
End Property

'the full path to the image file
Public Property Get BkgImage$()
    BkgImage = m.Image
End Property

Public Property Let BkgImage(ByVal NewValue$)
    m.Image = NewValue
    Set m_Image = Images.LoadImage(NewValue)
    m_Dirty = True
End Property

'---------------------------------------------------------
'border
'---------------------------------------------------------
Public Property Get BorderColor&()
    BorderColor = RGB(m.bRed * 255, m.bBlue * 255, m.bGreen * 255)
End Property

Public Property Let BorderColor(ByVal col&)
    m.bdBlue = GetRValue(col) / 255
    m.bdRed = GetBValue(col) / 255
    m.bdGreen = GetGValue(col) / 255
    m_Dirty = True
End Property

Public Property Get BorderStyle() As n3dBorderStyles
    BorderStyle = m.BorderStyle
End Property

Public Property Let BorderStyle(ByVal NewValue As n3dBorderStyles)
    m.BorderStyle = NewValue
    m_Dirty = True
End Property

'---------------------------------------------------------
'scale
'---------------------------------------------------------
Public Sub GetFontScale(X!, Y!)
    X = m.sx
    Y = m.sy
End Sub

Public Sub SetFontScale(ByVal X!, ByVal Y!)
    m.sx = X
    m.sy = Y
    m_Dirty = True
End Sub

Public Property Let sy(ByVal NewValue!)
    m.sy = NewValue
    m_Dirty = True
End Property

Public Property Get sy!()
    sy = m.sy
End Property

Public Property Let sx(ByVal NewValue!)
    m.sx = NewValue
    m_Dirty = True
End Property

Public Property Get sx!()
    sx = m.sx
End Property


'---------------------------------------------------------
'rotation
'---------------------------------------------------------
Public Sub GetRotation(Angle!, X!, Y!, z!)
    X = m.rX
    Y = m.rY
    z = m.rZ
    Angle = m.ra
End Sub

Public Sub SetRotation(ByVal Angle!, ByVal X!, ByVal Y!, ByVal z!)
    m.rX = X
    m.rY = Y
    m.rZ = z
    m.ra = Angle
    m_Dirty = True
End Sub

Public Property Let rZ(ByVal NewValue!)
    m.rZ = NewValue
    m_Dirty = True
End Property

Public Property Get rZ!()
    rZ = m.rZ
End Property

Public Property Let rY(ByVal NewValue!)
    m.rY = NewValue
    m_Dirty = True
End Property


Public Property Get rY!()
    rY = m.rY
End Property

Public Property Let rX(ByVal NewValue!)
    m.rX = NewValue
    m_Dirty = True
End Property

Public Property Get rX!()
    rX = m.rX
End Property

Public Property Let ra(ByVal NewValue!)
    m.ra = NewValue
    m_Dirty = True
End Property

Public Property Get ra!()
    ra = m.ra
End Property

'---------------------------------------------------------
'translation
'---------------------------------------------------------
Public Sub GetTranslation(X!, Y!, z!)
    X = m.X
    Y = m.Y
    z = m.z
End Sub

Public Sub SetTranslation(ByVal X!, ByVal Y!, ByVal z!)
    m.X = X
    m.Y = Y
    m.z = z
    m_Dirty = True
End Sub

Public Property Let z(ByVal NewValue!)
    m.z = NewValue
    m_Dirty = True
End Property

Public Property Get z!()
    z = m.z
End Property

Public Property Let Y(ByVal NewValue!)
    m.Y = NewValue
    m_Dirty = True
End Property


Public Property Get Y!()
    Y = m.Y
End Property

Public Property Let X(ByVal NewValue!)
    m.X = NewValue
    m_Dirty = True
End Property

Public Property Get X!()
    X = m.X
End Property

'---------------------------------------------------------
'size
'---------------------------------------------------------

Public Property Let depth(ByVal NewValue!)
    m.depth = NewValue
    m_Dirty = True
End Property

Public Property Get depth!()
    depth = m.depth
End Property

Public Property Let Height(ByVal NewValue!)
    m.Height = NewValue
    If m.Height = 0 Then m.Height = 1
    m_Dirty = True
End Property

Public Property Get Height!()
        Height = m.Height
End Property

Public Property Let Width(ByVal NewValue!)
    m.Width = NewValue
    If m.Width = 0 Then m.Width = 1
    m_Dirty = True
End Property

Public Property Get Width!()
    Width = m.Width
End Property

'---------------------------------------------------------
'text
'---------------------------------------------------------
Public Property Let Text(ByVal NewValue As String)
    m.Text = NewValue
    m_Dirty = True
End Property

Public Property Get Text() As String
    Text = m.Text
End Property

'---------------------------------------------------------
'other properties
'---------------------------------------------------------
Public Property Let Visible(ByVal NewValue As Boolean)
    m.Visible = NewValue
End Property

Public Property Get Visible() As Boolean
    Visible = m.Visible
End Property

Public Property Get Selected() As Boolean
    Selected = m_Selected
End Property

Public Property Let Selected(ByVal NewValue As Boolean)
    m_Selected = NewValue
End Property

'---------------------------------------------------------
'METHODS
'---------------------------------------------------------
Public Sub Draw()
Dim l!, t!, r!, b!
    l = -Width / 2: b = -Height / 2
    t = -b: r = -l
    If m_Dirty Then
        Compile l, t, b, r
    Else
        glCallList m_ListID
    End If
    'draw border
    If m_Selected Then
        glLineWidth 3
        glColor3f 1, 1, 0
        glDisable glcLighting
        glPolygonMode faceFrontAndBack, pgmLine
        glBegin GL_QUADS
            glVertex2f l - 0.3, b - 0.3
            glVertex2f r + 0.3, b - 0.3
            glVertex2f r + 0.3, t + 0.3
            glVertex2f l - 0.3, t + 0.3
        glEnd
    ElseIf m.BorderStyle = bdr_None And Text = "" Then
        glColor3f 1, 1, 1
        glDisable glcLighting
        glPolygonMode faceFrontAndBack, pgmLine
        glBegin GL_QUADS
            glVertex2f l - 0.2, b - 0.2
            glVertex2f r + 0.2, b - 0.2
            glVertex2f r + 0.2, t + 0.2
            glVertex2f l - 0.2, t + 0.2
        glEnd
    End If
    '
    'If m_Selected Then
        'Manipulator.Draw
    'End If
    glPopMatrix 'push is in the list
    glPopAttrib 'ditto
End Sub

Public Sub Compile(l!, t!, b!, r!)
Dim s$
    glNewList m_ListID, lstCompileAndExecute
    glLoadName ID
    glPushAttrib amAllAttribBits
    glPushMatrix
        glTranslatef m.X, m.Y, m.z
        glRotatef m.ra, m.rX, m.rY, m.rZ
        '
        'draw the bkg image
        If m.BkgStyle Then
            glEnable GL_LIGHTING
            If m.BkgStyle = bkg_Image And Not m_Image Is Nothing Then
                gCtl.Materials.SetMaterialIndex BRIGHT_WHITE
                glEnable GL_TEXTURE_2D
                glBindTexture GL_TEXTURE_2D, m_Image.Tex.TexID
            Else
                glEnable GL_COLOR_MATERIAL
                glColor3f m.bRed, m.bGreen, m.bBlue
            End If
            glPolygonMode faceFrontAndBack, GL_FILL
            glNormal3f 0, 0, 1
'            glBegin GL_QUADS
'                glTexCoord2f 0, 0
'                glVertex3f l - 0.1, b - 0.1, -0.1
'                glTexCoord2f 1, 0
'                glVertex3f r + 0.1, b - 0.1, -0.1
'                glTexCoord2f 1, 1
'                glVertex3f r + 0.1, t + 0.1, -0.1
'                glTexCoord2f 0, 1
'                glVertex3f l - 0.1, t + 0.1, -0.1
'            glEnd
            TessPlane r - l + 0.2, t - b + 0.2, 4, 4
            If m.BkgStyle = bkg_Image Then
                glDisable GL_TEXTURE_2D
            End If
        End If
        glDisable glcLighting
        'draw the border
        If m.BorderStyle Then
            If m.BorderStyle = bdr_Dot Then
                glLineStipple 1, &HAAAA
                glEnable GL_LINE_STIPPLE
            ElseIf m.BorderStyle = bdr_Dash Then
                glLineStipple 4, &HAAAA
                glEnable GL_LINE_STIPPLE
            End If
            glColor3f m.bdRed, m.bdGreen, m.bdBlue
            glPolygonMode faceFrontAndBack, pgmLine
            glBegin GL_QUADS
                glVertex2f l - 0.2, b - 0.2
                glVertex2f r + 0.2, b - 0.2
                glVertex2f r + 0.2, t + 0.2
                glVertex2f l - 0.2, t + 0.2
            glEnd
            glDisable GL_LINE_STIPPLE
        End If
        'draw the text
        '
        glColor3f m.fRed, m.fGreen, m.fBlue
        glPushMatrix
            glTranslatef l, t, 0.1
            'only scale the text
            glScalef m.sx, m.sy, 1
            s = m.Text
            If s = "" And m.BkgStyle = 0 And m.BorderStyle = 0 Then
                s = m.Name
            End If
            m_Font.DrawText s, Width / m.sx, Height / m.sy
        glPopMatrix
    'note: PopMatrix and PopAttrib are done in draw
    'so a selection border can be drawn
    glEndList
    m_Dirty = False
End Sub

Public Function Save(fn&) As Boolean
Dim img$
On Error GoTo EH
    If optCopyImages Then
        m.Image = ExtractFileName(m.Image)
    End If
    Put #fn, , m
    Save = True
    Exit Function
EH:
    'do something
    Debug.Assert 0
End Function

Public Function Load(fn&, Path$)
Dim s$
    Get fn, , m
    If m.Image <> "" Then
        If InStr(m.Image, "\") = 0 Then
            s = Path & "\" & m.Image
        Else
            s = m.Image
        End If
        BkgImage = s
    End If
    Font = m.Font
End Function
