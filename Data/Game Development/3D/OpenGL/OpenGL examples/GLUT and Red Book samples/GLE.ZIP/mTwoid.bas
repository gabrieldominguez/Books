Attribute VB_Name = "mTwoid"
Option Explicit

''
' * twistoid.c
' *
' * FUNCTION:
' * Show extrusion of open contours. Also, show how torsion is applied.
' *
' * HISTORY:
' * -- linas Vepstas October 1991
' * -- heavily modified to draw corrugated surface, Feb 1993, Linas
' * -- modified to demo twistoid March 1993
' * -- port to glut Linas Vepstas March 1995
'

Public IDTwoid&
Public Twoid As gleTwistExtrusion
Const NUM_TOID1_PTS = 5
Const TSCALE = 6
Const SCALE2 = 0.6
Const NUM_TWIS_PTS = 20
Dim mx&, my '= 121;= 121;

' ===========================================================

Public Sub InitTwist()
Dim js&
Dim i&
Dim angle#, co#, si#
    Set Twoid = gCtl.NewTwist
'   gleTwistExtrusion (NUM_TWIS_PTS, contour, twist_normal,
'              NULL, NUM_TOID1_PTS, toid1_points, NULL, toid1_twists);
    With Twoid
        .JoinStyle = CX.JoinStyle
        .TextureMode = CX.TextureStyle
        .TextureEnabled = CX.TextureEnabled
        .NormStyle = CX.NormStyle
        'set the array sizes!
        .NumContourNormals = NUM_TWIS_PTS
        .NumContourPoints = NUM_TWIS_PTS
        .NumPoints = NUM_TOID1_PTS
        .NumtwistPts = NUM_TOID1_PTS
        .NUMCOLORS = NUM_TOID1_PTS
        
        'set the points
        .SetPt 0, TSCALE * -1.1, 0, 0
        .SetPt 1, TSCALE * -1, 0, 0
        .SetPt 2, 0, 0, 0
        .SetPt 3, TSCALE * 1, 0, 0
        .SetPt 4, TSCALE * 1.1, 0, 0

        'set colors
        .SetColor 0, 0.8, 0.8, 0.5
        .SetColor 1, 0.8, 0.4, 0.5
        .SetColor 2, 0.8, 0.8, 0.3
        .SetColor 3, 0.4, 0.4, 0.5
        .SetColor 4, 0.8, 0.8, 0.5

        ' outline of extrusion
        Set CurModel = Twoid
        .SetContourNormal 0, 0, 1
        ' a zig-zag corrugation
        CONTOUR2 0, 10, 0, SCALE2
        CONTOUR2 1, 9, 1, SCALE2
        CONTOUR2 2, 8, 0, SCALE2
        CONTOUR2 3, 7, 1, SCALE2
        CONTOUR2 4, 6, 0, SCALE2
        CONTOUR2 5, 5, 1, SCALE2
        CONTOUR2 6, 4, 0, SCALE2
        CONTOUR2 7, 3, 1, SCALE2
        CONTOUR2 8, 2, 0, SCALE2
        ' draw a semi-curcular "hump"
        For i = 9 To 19
            angle = M_PI * (i - 9) / 10
            co = Cos(angle)
            si = Sin(angle)
            CONTOUR2 i, (-11 + 3 * co), 1.8 * si, SCALE2
        Next
        

    End With
    IDTwoid = glGenLists(1)
    glNewList IDTwoid, lstCompile
        DrawTwoid
    glEndList
End Sub

' ===========================================================
Public Sub DrawTwoid()
Dim i&, my&
Dim w&, h&
    w = gCtl.ScaleWidth
    h = gCtl.ScaleHeight
    my = CX.MouseY
    Twoid.twist(2) = (CX.MouseX - (w \ 2)) / 8
    Twoid.SetPt 3, 1, -(my - h \ 2) / h, 0
    Twoid.SetPt 4, 1.1, -1.1 * ((my - h \ 2)) / h, 0
    glDisable glcCullFace
    glPushMatrix
'    gleTwistExtrusion (NUM_TWIS_PTS, twistation, twist_normal,
'               NULL, NUM_TOID1_PTS, toid1_points, NULL, toid1_twists);
    glRotated 43#, 1, 0, 0
    glRotated 43#, 0, 1, 0
    Twoid.Draw
    glPopMatrix
    glEnable glcCullFace
End Sub


'' ------------------ end of file --------------------

