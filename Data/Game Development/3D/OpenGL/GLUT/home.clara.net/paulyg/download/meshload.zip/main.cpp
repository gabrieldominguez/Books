
/*  Mesh loader test.
 *  Pressing "w" renders the object in wireframe.
 *  Pressing "f" renders the object filled.
*/


#include <windows.h>
#include <stdio.h>
#include <GL/glut.h>

#include "meshload.h"

// Angles for idle animation and mouse interaction here.
float x_angle, y_angle;
float zoom = -4.0;

int moving, startx, starty;

// This is the variable that holds our display list.
GLuint  my_obj;

void init ( void )
{
   glEnable     ( GL_DEPTH_TEST );
   glClearColor ( 0.0, 0.0, 0.0, 0.0);

   load_simple_mesh ( my_obj, "v.dat" );
}


void display ( void )
{
   glClear      ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) ;
   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, zoom );
   glRotatef ( y_angle, 1.0, 0.0, 0.0 );
   glRotatef ( x_angle, 0.0, 1.0, 0.0 );

   // Draw the loaded mesh object
   glCallList ( my_obj );

   glPopMatrix ( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{
   glViewport     ( 0, 0, (GLint) w, (GLint) h );
   glMatrixMode   ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, (GLdouble)w, 1.0, 100.0 );
   else
      gluPerspective ( 45, (GLdouble)w / (GLdouble) h,1.0, 100.0 );
   glMatrixMode      ( GL_MODELVIEW );
   glLoadIdentity    ( );
}

void idle_func ( void )
{
   x_angle = x_angle + 0.1;

   if ( x_angle >= 360 )
      x_angle = 0;
   glutPostRedisplay ( );
}

void mouse ( int button, int state, int x, int y )
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {
      moving = 1;
      startx = x;
      starty = y;
   }

   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      moving = 0;

   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN )
   {
      moving = 2;
      starty = y;
   }

   if ( button == GLUT_RIGHT_BUTTON && state == GLUT_UP )
      moving = 0;
}

void motion ( int x, int y )
{
   if ( moving == 1 )
   {
      x_angle += ( x - startx );
      y_angle += ( y - starty );
      startx = x;
      starty = y;
      glutPostRedisplay ( );
   }

   if ( moving == 2 )
   {
      zoom = ( zoom + ( ( y - starty ) * 0.1 ));
      starty = y;
      glutPostRedisplay ( );
   }
}


#pragma argsused
void keyboard ( unsigned char key, int x, int y )
{
   switch (key) {
      case 27:  /*  Escape key  */
         exit(0);
         break;
      case 'f':
        glPolygonMode ( GL_FRONT_AND_BACK, GL_FILL );
                        break;
      case 'w':
        glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE );
         break;
      default:
         break;
   }
}

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
int main ( int argc, char** argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ("Mesh load test" );
   init ( );
   glutReshapeFunc  ( reshape   );
   glutMouseFunc    ( mouse     );
   glutMotionFunc   ( motion    );
   glutKeyboardFunc ( keyboard  );
   glutDisplayFunc  ( display   );
   glutIdleFunc     ( idle_func );
   glutMainLoop ( );
   return 0;
}
