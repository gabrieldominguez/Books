
ProjectZ is a template project for the compiled glxCtl.ocx. You must have 
the ocx registered on your system. You can register it by clicking:
 ' Projects | Components ' and looking for glCtl in the list. 
If it's not there, click the 'Browse' button and point VB to it.

To use ProjectZ:

1. Copy these files to a new directory:
ProjectX.vbp
frmMain.frm
mConstants.bas
CXX.cls

2. Rename CXXX to whatever the main class will be named. You can leave 
the CX's, or change them too. Change the two CXXX references to the new 
class name.

3. Rename the project, and save the CXXX.cls and ProjectX.vbp under new 
names if you wish.

4. Now just run it. You should a blue ball in the center of the screen. 
This is the OpenGL window. To draw stuff, remove the code in the 'Draw' 
sub and replace it with your own.



