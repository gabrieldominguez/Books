class AwesomeSeqAct_SpawnerActivation extends SequenceAction;

var() int WaveSize;

event Activated()
{
    if(AwesomeGame(GetWorldInfo().Game) != none)
        AwesomeGame(GetWorldInfo().Game).StartWave(WaveSize);
}

defaultproperties
{
    WaveSize=10
    ObjName="Spawner Activation"
    ObjCategory="Awesome Game"
    VariableLinks.Empty
    VariableLinks(0)=(ExpectedType=class'SeqVar_Int',LinkDesc="Wave Size",PropertyName=WaveSize)
}
