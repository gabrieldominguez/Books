VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#2.1#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "PolyOffset"
   ClientHeight    =   5190
   ClientLeft      =   2655
   ClientTop       =   2610
   ClientWidth     =   5625
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5190
   ScaleWidth      =   5625
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4845
      Left            =   120
      TabIndex        =   0
      Top             =   105
      Width           =   5325
      _ExtentX        =   9393
      _ExtentY        =   8546
      BorderStyle     =   1
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_Resize()
    glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
    gCtl.Render
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

'if not using double-buffering, uncomment the below
Private Sub glxCtl1_Paint()
    'gCtl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
CX.Pick items
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, default As Boolean)
default = CX.Reshape(width, height)
End Sub


