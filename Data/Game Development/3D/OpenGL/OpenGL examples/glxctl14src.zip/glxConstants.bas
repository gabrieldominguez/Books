Attribute VB_Name = "glxConstants"
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: utility routines
'   - note that to provide an interface to VRML
'   - you can write wrapper functions which handle the
'   - VRML call and pass it to GLE, GLUT or other routines
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

Public UC As glxCtl
Public RaiseErrors As Boolean
Public gPFD As PIXELFORMATDESCRIPTOR
Public gbGLv1_1 As Boolean
'these two things are here so I have a default texture for
'testing. I don't use them so they'll probably get removed.
Public PicStars As StdPicture
Public PicBricks As StdPicture
'-------------------------------------------------------------------------
'GLOBAL CONSTANTS
'-------------------------------------------------------------------------
Public Const PI = 3.14159265358979
Public Const ONE_OVER_180 = 1 / 180
Public Const ONE_OVER_PI = (1 / PI)
Public Const ZERO_EPS = 0.00000001
Public Const FLOAT_MAX = 3.402823466E+38
Public Const FLOAT_MIN = 1.175494351E-38
'
'-------------------------------------
'API declarations
'-------------------------------------
Public Const BFT_BITMAP = &H4D42  ' 'BM' -- indicates structure is BITMAPFILEHEADER
Public Const len_BITMAPFILEHEADER = 14
Public Const OFFSET_bfType = 0
Public Const OFFSET_bfSize = 2
Public Const OFFSET_bfReserved1 = 6
Public Const OFFSET_bfReserved2 = 8
Public Const OFFSET_bfOffBits = 10
'
Public Const imagic = &H1DA
Public Const IMAGIC_SWAP = &HDA01
'
Public Const MAX_PATH& = 260
Public Const OFN_HIDEREADONLY% = &H4
Public Const OFN_FILEMUSTEXIST% = &H1000
Public Const OFN_CREATEPROMPT% = &H2000
Public Const OFN_OVERWRITEPROMPT% = &H2
Public Const OFN_PATHMUSTEXIST% = &H800

Type POINTAPI
        X As Long
        Y As Long
End Type

Type OPENFILENAME
    lStructSize As Long
    hwndOwner As Long
    hInstance As Long
    lpstrFilter As String
    lpstrCustomFilter As String
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As String
    nMaxFile As Long
    lpstrFileTitle As String
    nMaxFileTitle As Long
    lpstrInitialDir As String
    lpstrTitle As String
    flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As String
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As String
End Type
'
'the following must declared - typelib decs won't work
Type OUTLINETEXTMETRIC
    otmSize As Long
    otmTextMetrics As TEXTMETRIC
    otmFiller As Byte
    otmPanoseNumber As PANOSE
    otmfsSelection As Long
    otmfsType As Long
    otmsCharSlopeRise As Long
    otmsCharSlopeRun As Long
    otmItalicAngle As Long
    otmEMSquare As Long
    otmAscent As Long
    otmDescent As Long
    otmLineGap As Long
    otmsCapEmHeight As Long
    otmsXHeight As Long
    otmrcFontBox As RECT
    otmMacAscent As Long
    otmMacDescent As Long
    otmMacLineGap As Long
    otmusMinimumPPEM As Long
    otmptSubscriptSize As POINTAPI
    otmptSubscriptOffset As POINTAPI
    otmptSuperscriptSize As POINTAPI
    otmptSuperscriptOffset As POINTAPI
    otmsStrikeoutSize As Long
    otmsStrikeoutPosition As Long
    otmsUnderscorePosition As Long
    otmsUnderscoreSize As Long
    otmpFamilyName As String
    otmpFaceName As String
    otmpStyleName As String
    otmpFullName As String
End Type
Declare Function GetOutlineTextMetrics& Lib "gdi32" Alias "GetOutlineTextMetricsA" (ByVal hDC As Long, ByVal cbData As Long, lpotm As OUTLINETEXTMETRIC)

Declare Sub CopyToByteFromByte Lib "kernel32" Alias "RtlMoveMemory" (dest As Byte, Src As Byte, ByVal length&)
'Declare Sub CopyToStrFromInt Lib "kernel32" Alias "RtlMoveMemory" (ByVal dest$, Src%, ByVal length&)
'Declare Sub CopyToStrFromLong Lib "kernel32" Alias "RtlMoveMemory" (ByVal dest$, Src&, ByVal length&)
'Declare Sub CopyToIntFromStr Lib "kernel32" Alias "RtlMoveMemory" (Src%, ByVal dest$, ByVal Length&)
'Declare Sub CopyToLongFromStr Lib "kernel32" Alias "RtlMoveMemory" (Src&, ByVal dest$, ByVal Length&)
Declare Sub CopyToPtrFromPtr Lib "kernel32" Alias "RtlMoveMemory" (ByVal DestAddr&, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToByteFromPtr Lib "kernel32" Alias "RtlMoveMemory" (dest As Byte, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToLongFromPtr Lib "kernel32" Alias "RtlMoveMemory" (dest&, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToTypeFromPtr Lib "kernel32" Alias "RtlMoveMemory" (ByRef dest As Any, ByVal SrcAddr&, ByVal length&)
Declare Sub CopyToTypeFromType Lib "kernel32" Alias "RtlMoveMemory" (ByRef dest As Any, ByRef Src As Any, ByVal length&)
Declare Function GetOpenFileName& Lib "comdlg32.dll" Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME)
Declare Function CreateFileMappingDef& Lib "kernel32" Alias "CreateFileMappingA" (ByVal hFile&, ByVal lpFileMappingAttributes&, ByVal flProtect&, ByVal dwMaximumSizeHigh&, ByVal dwMaximumSizeLow&, ByVal lpName As String)
'Declare Function CreateDIBSection256& Lib "gdi32" (ByVal Hdc&, _
'            pBitmapInfo As BITMAPINFO256, ByVal iUsage&, lplpVoid&, _
'            ByVal hSection&, ByVal dwOffset&)
Declare Function CreateFile& Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwDesiredAccess As Long, ByVal dwShareMode As Long, ByVal lpSecurityAttributes As Long, ByVal dwCreationDisposition As Long, ByVal dwFlagsAndAttributes As Long, ByVal hTemplateFile As Long)
Declare Function SetDIBits& Lib "gdi32" (ByVal hDC As Long, ByVal hBitmap As Long, _
            ByVal nStartScan As Long, ByVal nNumScans As Long, _
            ByVal lpBits As Long, lpBI As BITMAPINFO, ByVal wUsage As Long)
Declare Function SetDIBits256& Lib "gdi32" (ByVal hDC As Long, ByVal hBitmap As Long, _
            ByVal nStartScan As Long, ByVal nNumScans As Long, _
            ByVal lpBits As Long, lpBI As BITMAPINFO256, ByVal wUsage As Long)
Declare Function SetDIBitsToDevice& Lib "gdi32" (ByVal hDC As Long, _
            ByVal X As Long, ByVal Y As Long, _
            ByVal dx As Long, ByVal dy As Long, _
            ByVal SrcX As Long, ByVal SrcY As Long, _
            ByVal Scan As Long, ByVal NumScans As Long, _
            bits As Any, BitsInfo As BITMAPINFO, ByVal wUsage As Long)
Declare Function SetDIBColorTable& Lib "gdi32" (ByVal hDC As Long, _
            ByVal un1 As Long, ByVal un2 As Long, pcRGBQuad As RGBQUAD)
Declare Function CreateDIBSection& Lib "gdi32" (ByVal hDC As Long, _
            pBitmapInfo As BITMAPINFO, ByVal iUsage As Long, ppvBits As Long, _
            ByVal FileHandle As Long, ByVal offset As Long)
' Define your custom errors here.  Be sure to use numbers
' greater than 512, to avoid conflicts with OLE error numbers.
Public Const MyObjectError1 = 1000
Public Const MyObjectError2 = 1010
Public Const MyObjectErrorN = 1234
Public Const MyUnhandledError = 9999

'------------------------------------------------------------------------------------
'UTILITY ROUTINES
'---------------------------------------------------------------------------------
Public Sub FillArray3f(A() As gleVector3f, ParamArray n())
Dim v, i&, j&
On Error Resume Next
    For Each v In n
        A(i).v(j) = v
        j = j + 1
        If j > 2 Then
            i = i + 1
            j = 0
        End If
    Next
End Sub

'------------------------------------------------------------------------------------
Public Sub FillArray3i(A() As gleVector3i, ParamArray n())
Dim v, i&, j&
On Error Resume Next
    For Each v In n
        A(i).v(j) = v
        j = j + 1
        If j > 2 Then
            i = i + 1
            j = 0
        End If
    Next
End Sub

'------------------------------------------------------------------------------------
Public Sub FillArray4i(A() As gleVector4i, ParamArray n())
Dim v, i&, j&
On Error Resume Next
    For Each v In n
        A(i).v(j) = v
        j = j + 1
        If j > 3 Then
            i = i + 1
            j = 0
        End If
    Next
End Sub

'---------------------------------------------------------------------------------
'DRAW THE GRID AND AXES
'---------------------------------------------------------------------------------
'creates the WORLD_LIST
Public Sub DrawWorld(nLIST&, GridStyle&)
Dim n&, gs&, X&, Y&, z&
On Error Resume Next
glPushMatrix
    If nLIST Then
        glDeleteLists nLIST, 1
        nLIST = 0
    End If
    If nLIST = 0 Then nLIST = glGenLists(1)
    glNewList nLIST, GL_COMPILE
    glPushAttrib GL_LIGHTING_BIT
    glDisable GL_LIGHTING
    '
    'the following call returns a different number
    'than the value of m_GridStyle on the UC (with multiple ocxs)
    If IsMissing(GridStyle) Then
        n = UC.Grid
    Else: n = GridStyle
    End If
    gs = UC.GridStep
    X = UC.SizeX
    Y = UC.SizeY
    z = UC.SizeZ
    If n And glxGridX Then DrawGrid 1, X \ 2, z \ 2, gs ', &H880000
    If n And glxGridY Then DrawGrid 2, Y \ 2, X \ 2, gs ', &H8800
    If n And glxGridZ Then DrawGrid 3, z \ 2, Y \ 2, gs ', &H88
    DrawAxes UC.Axis
    glPopAttrib
    glEndList
glPopMatrix
End Sub

'---------------------------------------------------------------------------------
Public Sub DrawGrid(ByVal Axis&, Size1&, Size2&, ByVal nStep&, Optional Color& = &HC0C0C0)
Dim X!, z!
Dim clr!(0 To 3)
glGetFloatv GL_CURRENT_COLOR, clr(0)
glPushMatrix
    If nStep = 0 Then nStep = 1
    'validate range
    If Size1 < nStep Then Size1 = nStep
    If Size2 < nStep Then Size2 = nStep
    ' Draw Grid in Grey
    UC.Ex.glColor32 Color
    glNormal3f 0, 1, 0
    'color axes R,G,B for X,Y,Z
    If Axis = 2 Then
        glRotatef 90, 1, 0, 0
    ElseIf Axis = 3 Then
        glRotatef 90, 0, 0, 1
    End If
    glBegin GL_LINES
        'Z lines going into z
        For X = -Size1 To Size1 Step nStep
            glVertex3f X, 0, -Size2
            glVertex3f X, 0, Size2
        Next
        'X lines parallel to x
        For z = -Size2 To Size2 Step nStep
            glVertex3f Size1, 0, z
            glVertex3f -Size1, 0, z
        Next
    glEnd
glPopMatrix
glColor4f clr(0), clr(1), clr(2), clr(3)
End Sub

'---------------------------------------------------------------------------------
Public Sub DrawAxes(style As AxisStyleConstants)
Dim nRange&
Dim clr!(0 To 3)
Dim X!, z!
If style = glxNone Then Exit Sub
glGetFloatv GL_CURRENT_COLOR, clr(0)
glPushMatrix
    'draw axes
    If style And glxXYZ Then
        glNormal3f 0, 1, 0
        glBegin GL_LINES
            'x
            glColor3f 1, 0, 0
            nRange = UC.SizeX
            glVertex3f -nRange, 0, 0
            glVertex3f nRange, 0, 0
           'y
            glColor3f 0, 1, 0
            nRange = UC.SizeY
            glVertex3f 0, -nRange, 0
            glVertex3f 0, nRange, 0
            'z
            glColor3f 0, 0, 1
            nRange = UC.SizeZ
            glVertex3f 0, 0, -nRange
            glVertex3f 0, 0, nRange
        glEnd
    End If
glPopMatrix
glColor4f clr(0), clr(1), clr(2), clr(3)
End Sub

