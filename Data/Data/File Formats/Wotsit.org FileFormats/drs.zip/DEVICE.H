#ifndef __device_h
#define __device_h

#include <stdio.h>
#include "globals.h"

typedef struct s_device {

/* common Methods */
  void (*init)  (struct s_device* this);
  void (*clear) (struct s_device* this);
  void (*exit)  (struct s_device* this);
  int  (*getch) (struct s_device* this);
  void (*line)  (struct s_device* this, int x1, int y1, int x2, int y2);
  void (*spline)(struct s_device* this,
		 int x1, int y1, int x2, int y2, 
		 int x3, int y3, int x4, int y4);

/* device specific variables */
  int width;
  int height;
  float xscale,yscale,zscale,rscale;
  FILE* fp;
} device;

void dev_init(device* this);
#endif;
