VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CCamera"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'-----------------------------------------------------------------
'FUNCTION: handles resize events and projection
'   - enable this module with UseCamera
'   - handles setting the aspect ratio
'   - to use, set the view parameters
'       -EyePos
'       -Target
'       -Near and FarPlane, FOV, or
'       -SetOrtho
'       then return true from the resize event
'   - 'View' toggles between Ortho and Perspective
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'   this is a trimmed down version of the glxCamera in
'   the ocx.
'-----------------------------------------------------------------
Private m_fieldOfView As Double
Private m_NearPlane As Double
Private m_FarPlane As Double
Private m_AspectRatio As Double
Private m_EyeX!, m_EyeY!, m_EyeZ!
Private m_OEyeX!, m_OEyeY!, m_OEyeZ!
Private m_TargetX!, m_TargetY!, m_TargetZ!
Dim m_OrthoLeft#, m_OrthoRight#, m_OrthoTop#, m_OrthoBottom#
Public Enum glxViewConstants
    glxPerspective = 0
    glxOrtho = 1
    glxTop = 2
    glxFront = 3
    glxBottom = 4
    glxLeft = 5
    glxBack = 6
    glxRight = 7
End Enum
Dim m_View As glxViewConstants
Dim m_Width&, m_Height&
Const DEG = 57.2958


'---------------------------------------------------------
'SETUP
'---------------------------------------------------------

Private Sub Class_Initialize()
m_AspectRatio = 1
m_FarPlane = 1000
m_NearPlane = 0.01
m_fieldOfView = 45
m_View = glxPerspective
m_OrthoLeft = -10
m_OrthoRight = 10
m_OrthoTop = 10
m_OrthoBottom = -10
End Sub

'Friend Sub Pick(X&, Y&)
'        m_SetViewPort
'End Sub

'---------------------------------------------------------
'VIEWPORT
'---------------------------------------------------------

'Adjusts the viewport to match the window size. Should be called for Resize events
Public Sub OnSize(ByVal W&, ByVal H&, Default As Boolean)
If H = 0 Then H = 1
m_AspectRatio = W / H
glViewport 0, 0, W, H
m_Width = W: m_Height = H
'Debug.Print UC.DebugID
'Debug.Print m_EyeZ
If Default <> 0 Then
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
    'glLoadIdentity
End If
End Sub

Friend Sub SetProjection()
Dim l#, r#, b#, t#
Dim W#, H#
If m_View = glxPerspective Then
    gluPerspective m_fieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
Else
    'glLoadIdentity
    W = m_Width: H = m_Height
    If W = 0 Then W = 1
    If H = 0 Then H = 1
    If W < H Then
        l = m_OrthoLeft
        r = m_OrthoRight
        t = m_OrthoTop * H / W
        b = m_OrthoBottom * H / W
    Else
        l = m_OrthoLeft * W / H
        r = m_OrthoRight * W / H
        t = m_OrthoTop
        b = m_OrthoBottom
    End If
    glOrtho l, r, b, t, m_NearPlane, m_FarPlane

End If
'Update
End Sub

'---------------------------------------------------------
'VIEWPORT PROPERTIES
'---------------------------------------------------------

'Returns the coordinates of the left, right, bottom, and top
'clipping planes.
Public Sub GetOrtho(Left#, Right#, Bottom#, Top#)
    Left = m_OrthoLeft
    Right = m_OrthoRight
    Bottom = m_OrthoBottom
    Top = m_OrthoTop
End Sub

'Sets the coordinates of the left, right, bottom, and top
'clipping planes.
Public Sub SetOrtho(ByVal Left#, ByVal Right#, ByVal Bottom#, ByVal Top#)
    m_OrthoLeft = Left
    m_OrthoRight = Right
    m_OrthoTop = Top
    m_OrthoBottom = Bottom
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End Sub

'---------------------------------------------------------
'Returns the current ratio of viewport w/h
Public Property Get AspectRatio() As Double
    AspectRatio = m_AspectRatio
End Property

'---------------------------------------------------------
'Returns/sets the far clipping plane
Public Property Let FarPlane(ByVal NewValue As Double)
    m_FarPlane = NewValue
End Property

Public Property Get FarPlane() As Double
    FarPlane = m_FarPlane
End Property

'---------------------------------------------------------
'Returns/sets the near clipping plane
Public Property Let NearPlane(ByVal NewValue As Double)
    m_NearPlane = NewValue
End Property

Public Property Get NearPlane() As Double
    NearPlane = m_NearPlane
End Property

'---------------------------------------------------------
'Returns/sets the field of view angle, in degrees, in the y-direction
Public Property Let FieldOfView(ByVal NewValue As Double)
    m_fieldOfView = NewValue
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
End Property

Public Property Get FieldOfView() As Double
    FieldOfView = m_fieldOfView
End Property

'---------------------------------------------------------
'Returns/sets the projection mode
Public Property Get View() As glxViewConstants
View = m_View
End Property

Public Property Let View(ByVal NewView As glxViewConstants)
m_View = NewView
    glMatrixMode mmProjection
    glLoadIdentity
        SetProjection
    glMatrixMode mmModelView
'UC.Trackball.Reset
End Property

'---------------------------------------------------------
'
Public Sub Update()
    Select Case m_View
    Case glxPerspective
        gluLookAt m_EyeX, m_EyeY, m_EyeZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 1, 0
    Case glxOrtho
        'glTranslatef -m_EyeX, m_EyeY * 2, -m_EyeZ
        'gluLookAt m_EyeX, m_EyeY, m_EyeZ, _
        '        m_TargetX, m_TargetY, m_TargetZ, _
        '        0, 1, 0
    Case glxTop
        'g = glxGridX
        gluLookAt m_TargetX, m_TargetY + m_OEyeY, m_TargetZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 0, -1
    Case glxBottom
    '    g = glxGridX
        gluLookAt m_TargetX, m_TargetY - m_OEyeY, m_TargetZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 0, 1
    Case glxFront
    '    g = glxGridY
        gluLookAt m_TargetX, m_TargetY, m_TargetZ + m_OEyeZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 1, 0
    Case glxBack
    '    g = glxGridY
        gluLookAt m_TargetX, m_TargetY, m_TargetZ - m_OEyeZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 1, 0
    Case glxLeft
    '    g = glxGridZ
        gluLookAt m_TargetX - m_OEyeX, m_TargetY, m_TargetZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 1, 0
    Case glxRight
    '    g = glxGridZ
        gluLookAt m_TargetX + m_OEyeX, m_TargetY, m_TargetZ, _
                m_TargetX, m_TargetY, m_TargetZ, _
                0, 1, 0
    End Select
End Sub

'---------------------------------------------------------
'returns the eye coordinates used in calls to gluLookAt
Public Sub GetEyePos(EyeX!, EyeY!, EyeZ!)
EyeX! = m_EyeX
EyeY! = m_EyeY
EyeZ! = m_EyeZ
End Sub

'---------------------------------------------------------
'Sets the eye coordinates used in calls to gluLookAt
Public Sub SetEyePos(ByVal EyeX!, ByVal EyeY!, ByVal EyeZ!)
m_EyeX! = EyeX
m_EyeY! = EyeY
m_EyeZ! = EyeZ
End Sub

'---------------------------------------------------------
'returns the target coordinates used in calls to gluLookAt
Public Sub GetTargetPos(TargetX!, TargetY!, TargetZ!)
TargetX! = m_TargetX
TargetY! = m_TargetY
TargetZ! = m_TargetZ
End Sub

'---------------------------------------------------------
'Sets the target coordinates used in calls to gluLookAt
Public Sub SetTargetPos(ByVal TargetX!, ByVal TargetY!, ByVal TargetZ!)
m_TargetX! = TargetX
m_TargetY! = TargetY
m_TargetZ! = TargetZ
End Sub

'---------------------------------------------------------
'returns the eye offsets from the target when using named ortho views
Public Sub GetOrthoEyePos(EyeX!, EyeY!, EyeZ!)
EyeX = m_OEyeX!
EyeY = m_OEyeY!
EyeZ = m_OEyeZ!
End Sub

'---------------------------------------------------------
'Sets the eye offsets from the target when using named ortho views
Public Sub SetOrthoEyePos(ByVal EyeX!, ByVal EyeY!, ByVal EyeZ!)
m_OEyeX! = EyeX
m_OEyeY! = EyeY
m_OEyeZ! = EyeZ
End Sub

'---------------------------------------------------------
Public Sub Pan(x!, y!)
    Select Case m_View
    Case glxPerspective
'        gluLookAt m_EyeX, m_EyeY, m_EyeZ, _
'                m_TargetX, m_TargetY, m_TargetZ, _
'                0, 1, 0
    Case glxOrtho
        'glTranslatef -m_EyeX, m_EyeY * 2, -m_EyeZ
        'gluLookAt m_EyeX, m_EyeY, m_EyeZ, _
        '        m_TargetX, m_TargetY, m_TargetZ, _
        '        0, 1, 0
    Case glxTop
        m_TargetX = m_TargetX + x
        m_OEyeX = m_OEyeX + x
        m_TargetZ = m_TargetZ - y
        m_OEyeZ = m_OEyeZ - y
    Case glxBottom
        m_TargetX = m_TargetX + x
        m_OEyeX = m_OEyeX + x
        m_TargetZ = m_TargetZ - y
        m_OEyeZ = m_OEyeZ - y
    Case glxFront
        m_TargetX = m_TargetX + x
        m_OEyeX = m_OEyeX + x
        m_TargetY = m_TargetY + y
        m_OEyeY = m_OEyeY + y
    Case glxBack
        m_TargetX = m_TargetX - x
        m_OEyeX = m_OEyeX - x
        m_TargetY = m_TargetY + y
        m_OEyeY = m_OEyeY + y
    Case glxLeft
        m_TargetZ = m_TargetZ - x
        m_OEyeZ = m_OEyeZ - x
        m_TargetY = m_TargetY + y
        m_OEyeY = m_OEyeY + y
    Case glxRight
        m_TargetZ = m_TargetZ + x
        m_OEyeZ = m_OEyeZ + x
        m_TargetY = m_TargetY + y
        m_OEyeY = m_OEyeY + y
    End Select
    Update
End Sub

