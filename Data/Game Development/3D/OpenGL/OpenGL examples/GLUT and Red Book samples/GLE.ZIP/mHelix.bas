Attribute VB_Name = "mHelix"
Option Explicit


''
' * helicoid (gernalized torus) demo
' *
' * FUNCTION:
' * This code provides a very simple example of the helicoid primitive.
' * Most of this code is required to set up OpenGL and GLUT, and very
' * very little to set up the helix drawer. Don't blink!
' *
' * HISTORY:
' * Written by Linas Vepstas, March 1995
' */

Public IDHelix1&
Public Helix1 As gleHelicoid

Public Sub InitHelix()
    Set Helix1 = gCtl.NewHelicoid
    With Helix1
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .CapStyle = gleCAPS
        .ToroidRadius = 1
        .startRadius = 2
        .drdTheta = 2
        .startZ = -3
        .dzdTheta = 4
        .sweepTheta = 1080
        .drdTheta = 2
    End With
    IDHelix1 = glGenLists(1)
    glNewList IDHelix1, lstCompile
        DrawHelix 1
    glEndList
End Sub


Public Sub DrawHelix(n&)
Select Case n
Case 1
    glPushMatrix
    glColor3f 0.6, 0.8, 0.3
    'gleHelicoid (1.0, 6.0, 2.0, -3.0, 4.0, 0x0, 0x0, 0.0, 1080.0);
    Helix1.Draw
    glPopMatrix
End Select
End Sub


'' ------------------------- end of file ----------------- */

