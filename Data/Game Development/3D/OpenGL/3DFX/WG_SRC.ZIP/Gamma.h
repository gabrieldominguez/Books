
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _GAMMA_
#define _GAMMA_

#include <windows.h>
#include <mmsystem.h>

extern BOOL AllocateGammaCorrectionTable(VOID);
extern VOID FreeGammaCorrectionTable(VOID);
extern DWORD *GetGammaCorrectionTablePointer(VOID);
extern BOOL CalculateGammaCorrectionTable(float, float, float);
extern BOOL CalculateColorConversionTable(FOURCC, float, float, float);
extern VOID GammaPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG, DWORD *);
extern VOID MMXGammaPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG, DWORD *);
extern VOID ColorConvertPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG, DWORD *);
extern VOID MMXColorConvertPitchCopy8(BYTE *, BYTE *, LONG, LONG, LONG, LONG, DWORD *);

#endif //_GAMMA_
