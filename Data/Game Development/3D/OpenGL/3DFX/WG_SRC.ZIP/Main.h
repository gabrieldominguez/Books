
#ifndef _MAIN_
#define _MAIN_

#include <windows.h>
#include <glide.h>

extern HANDLE ghDllInst;
extern DWORD gdwScreenWidth, gdwScreenHeight;
extern GrOriginLocation_t gOriginLocation;
extern DWORD gdwGlideScreenWidth, gdwGlideScreenHeight;

#endif //_MAIN_
