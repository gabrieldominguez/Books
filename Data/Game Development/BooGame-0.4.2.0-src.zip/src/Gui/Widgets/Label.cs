/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public class Label : Container
    {
        public Label() : base()
        {
            base.Focusable = false;
            this.Width = 200f;
        }

        public Label(Font font) : this()
        {
            m_Font = font;
        }

        private Font m_Font;
        /// <summary>
        /// Gets and sets the font associated with the widget.
        /// </summary>
        public Font Font
        {
            get { return m_Font; }
            set { m_Font = value; }
        }

        /// <summary>
        /// When overriden, draws the text associated with the widget.
        /// </summary>
        protected virtual void DrawText()
        {
            switch (m_Alignment)
            {
                case ContentAlignment.TopLeft:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX, this.AbsoluteY, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.TopCenter:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width / 2f, this.AbsoluteY, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.TopRight:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width, this.AbsoluteY, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.MiddleRight:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width, this.AbsoluteY + this.Height / 2f, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.MiddleCenter:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width / 2f, this.AbsoluteY + this.Height / 2f, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.MiddleLeft:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width / 2f, this.AbsoluteY, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.BottomRight:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width, this.AbsoluteY + this.Height, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.BottomCenter:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX + this.Width / 2f, this.AbsoluteY + this.Height, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
                case ContentAlignment.BottomLeft:
                    m_Font.Print(this.Text, this.Tint, this.AbsoluteX, this.AbsoluteY + this.Height, this.Alignment, this.Width, this.Height, this.Rotation, this.ScaleX, this.ScaleY, this.HotSpot);
                    break;
            }
        }

        public override void Draw()
        {
            if (Visible)
            {
                base.Draw();
                DrawText();
            }
        }

        private string m_Text = "Label";
        public virtual string Text
        {
            get { return m_Text; }
            set { m_Text = value; }
        }

        private ContentAlignment m_Alignment = ContentAlignment.TopLeft;
        /// <summary>
        /// Gets and sets where the text is displayed in proportion to where the entity is located.
        /// </summary>
        public ContentAlignment Alignment
        {
            get { return m_Alignment; }
            set { m_Alignment = value; }

        }
    }
}
