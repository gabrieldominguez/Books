/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.IO;

using Tao.PhysFs;

namespace BooGame
{
    /// <summary>
    /// Module for loading files through the file system.
    /// </summary>
    public sealed class FileSystem
    {
		static FileSystem()
		{
			Fs.PHYSFS_init("init");
            Fs.PHYSFS_addToSearchPath(".", 1);
		}
        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private FileSystem()
        {
        }

        /// <summary>
        /// An object to control the physfs lifetime.
        /// </summary>
        private static Lifetime m_FileSystemLifetime = new BooGame.FileSystem.Lifetime();

        /// <summary>
        /// Adds a search path to the file system.
        /// </summary>
        /// <param name="path">The path to add.</param>
        /// <example>FileSystem.AddSearchPath("data.zip");</example>
        public static void AddSearchPath(string path)
        {
            Fs.PHYSFS_addToSearchPath(path, 1);
        }

        /// <summary>
        /// Adds a number of search paths to the file system.
        /// </summary>
        /// <param name="paths">The paths to add to the file system.</param>
        public static void AddSearchPath(string[] paths)
        {
            foreach (string path in paths)
                AddSearchPath(path);
        }

        /// <summary>
        /// Removes a search path from the file system.
        /// </summary>
        /// <param name="path"></param>
        public static void RemoveSearchPath(string path)
        {
            Fs.PHYSFS_removeFromSearchPath(path);
        }

        /// <summary>
        /// Gets an array representing all search paths.
        /// </summary>
        public static string[] SearchPaths
        {
            get
            {
                return Fs.PHYSFS_getSearchPath();
            }
        }

        /// <summary>
        /// Returns a list of files in the given directory.
        /// </summary>
        /// <param name="directory">The virtual directory to read.</param>
        /// <returns></returns>
		public static string[] GetFiles(string directory)
		{
			string[] files = Fs.PHYSFS_enumerateFiles(directory);
			string[] pathfiles = new string[files.Length];
			for(int i = 0; i < pathfiles.Length; i++)
				pathfiles[i] = directory + @"/" + files[i];
			return pathfiles;
		}

        /// <summary>
        /// Loads the given filename as a byte array.
        /// </summary>
        /// <param name="filename">The file to load.</param>
        /// <returns>A byte array representing the bytes of the file.</returns>
        public static byte[] GetBytes(string filename)
        {
            if(Fs.PHYSFS_exists(filename) == 0)
                throw new System.IO.FileNotFoundException("The file (" + filename + ") wasn't found in the given search paths.", filename);
            IntPtr file = Fs.PHYSFS_openRead(filename);
            byte[] buffer;
            Fs.PHYSFS_read(file, out buffer, (uint)1, (uint)Fs.PHYSFS_fileLength(file));
            Fs.PHYSFS_close(file);
            return buffer;
        }

        /// <summary>
        /// Creates a stream from the given file.
        /// </summary>
        /// <param name="filename">The file to read in.</param>
        /// <returns>A stream reading from the given file.</returns>
		public static MemoryStream GetStream(string filename)
		{
			if(Fs.PHYSFS_exists(filename) == 0)
				throw new System.IO.FileNotFoundException("The file (" + filename + ") wasn't found in the given search paths.", filename);
			IntPtr file = Fs.PHYSFS_openRead(filename);
			byte[] buffer;
			Fs.PHYSFS_read(file, out buffer, (uint)1, (uint)Fs.PHYSFS_fileLength(file));
			Fs.PHYSFS_close(file);
			return new MemoryStream(buffer, 0, buffer.Length, false);
		}

        /// <summary>
        /// Get the whole contents of a file as a string.
        /// </summary>
        /// <param name="filename">The file to read in.</param>
        /// <returns>A string of the contents of the given file.</returns>
        public static string GetString(string filename)
        {
            if (Fs.PHYSFS_exists(filename) == 0)
                throw new System.IO.FileNotFoundException("The file (" + filename + ") wasn't found in the given search paths.", filename);
            IntPtr file = Fs.PHYSFS_openRead(filename);
            byte[] buffer;
            Fs.PHYSFS_read(file, out buffer, (uint)1, (uint)Fs.PHYSFS_fileLength(file));
            Fs.PHYSFS_close(file);
            return (new System.Text.ASCIIEncoding()).GetString(buffer);
        }

        /// <summary>
        /// Returns true if the given file exists.
        /// </summary>
        /// <param name="filename">The file to check exists.</param>
        /// <returns>True if the given file exists, false otherwise.</returns>
		public static bool Exists(string filename)
		{
			return Fs.PHYSFS_exists(filename) != 0;
		}

        /// <summary>
        /// Private class so that it calls deinit when the lifetime object is destroyed.
        /// </summary>
        private class Lifetime : IDisposable
        {
            private bool disposed = false;
            public void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    if (disposing)
                    {
                    }
                    Fs.PHYSFS_deinit();
                }
                disposed = true;
            }

            public void Dispose()
            {
                Dispose(true);
                System.GC.SuppressFinalize(this);
            }

            ~Lifetime()
            {
                Dispose(false);
            }
        }
    }
}
