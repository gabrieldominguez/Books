/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

namespace BooGame
{
    /// <summary>
    /// Represents an ARGB color in float values.
    /// </summary>
    /// <remarks>You can convert seemlessly from a System.Drawing.Color to a ColorF.
    /// <code>
    /// ColorF col = System.Drawing.Color.Blue;
    /// </code>
    /// </remarks>
    public class ColorF
    {
        #region Constructors

        public ColorF(float red, float green, float blue, float alpha)
        {
            m_R = red;
            m_G = green;
            m_B = blue;
            m_A = alpha;
        }
        public ColorF(float red, float green, float blue)
        {
            m_R = red;
            m_G = green;
            m_B = blue;
        }
        public ColorF()
        {
        }
        public ColorF(Color color)
        {
            m_R = ((float)color.R) / 255f;
            m_G = ((float)color.G) / 255f;
            m_B = ((float)color.B) / 255f;
            m_A = ((float)color.A) / 255f;
        }
        public ColorF(ColorF baseColor)
        {
            m_R = baseColor.R;
            m_G = baseColor.G;
            m_B = baseColor.B;
            m_A = baseColor.A;
        }

        #endregion Constructors

        #region Static Constructors

        public static ColorF FromArgb(float alpha, ColorF baseColor)
        {
            return new ColorF(baseColor.R, baseColor.G, baseColor.B, alpha);
        }
        public static ColorF FromArgb(float alpha, float red, float green, float blue)
        {
            return new ColorF(red, green, blue, alpha);
        }
        public static ColorF FromArgb(float red, float green, float blue)
        {
            return new ColorF(red, green, blue, 1f);
        }
        public static ColorF FromKnownColor(KnownColor color)
        {
            return Color.FromKnownColor(color);
        }
        public static ColorF FromName(string name)
        {
            return Color.FromName(name);
        }

        /// <summary>
        /// Specifies whether this color is defined.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return ToColor().IsEmpty;
            }
        }
        
        /// <summary>
        /// Gets whether this color is a known color.
        /// </summary>
        public bool IsKnownColor
        {
            get
            {
                return ToColor().IsKnownColor;
            }
        }

        /// <summary>
        /// Gets whether this color is a named color.
        /// </summary>
        public bool IsNamedColor
        {
            get
            {
                return ToColor().IsNamedColor;
            }
        }

        /// <summary>
        /// Gets whether this color is a system color.
        /// </summary>
        public bool IsSystemColor
        {
            get
            {
                return ToColor().IsSystemColor;
            }
        }

        /// <summary>
        /// Gets the name associated with this color.
        /// </summary>
        public string Name
        {
            get
            {
                return ToColor().Name;
            }
        }

        #endregion Static Constructors

        #region Properties

        private float m_R = 1f, m_G = 1f, m_B = 1f, m_A = 1f;
        /// <summary>
        /// Gets and sets the red component of the color (0.0f - 1.0f) .
        /// </summary>
        public float R
        {
            get { return m_R; }
            set
            {
                if (value <= 0f)
                    m_R = 0f;
                else if (value >= 1f)
                    m_R = 1f;
                else
                    m_R = value;
            }
        }

        /// <summary>
        /// Gets and sets the green component of the color (0.0f - 1.0f) .
        /// </summary>
        public float G
        {
            get { return m_G; }
            set
            {
                if (value <= 0f)
                    m_G = 0f;
                else if (value >= 1f)
                    m_G = 1f;
                else
                    m_G = value;
            }
        }

        /// <summary>
        /// Gets and sets the blue component of the color (0.0f - 1.0f) .
        /// </summary>
        public float B
        {
            get { return m_B; }
            set
            {
                if (value <= 0f)
                    m_B = 0f;
                else if (value >= 1f)
                    m_B = 1f;
                else
                    m_B = value;
            }
        }

        /// <summary>
        /// Gets and sets the alpha component of the color (0.0f - 1.0f) .
        /// </summary>
        public float A
        {
            get { return m_A; }
            set
            {
                if (value <= 0f)
                    m_A = 0f;
                else if (value >= 1f)
                    m_A = 1f;
                else
                    m_A = value;
            }
        }

        #endregion Properties

        #region Methods
        /// <summary>
        /// Converts the current ColorF to a System.Drawing.Color value.
        /// </summary>
        /// <returns></returns>
        public Color ToColor()
        {
            return Color.FromArgb((int)(m_A * 255f), (int)(m_R * 255f), (int)(m_G * 255f), (int)(m_B * 255f));
        }
        public KnownColor ToKnownColor()
        {
            return ToColor().ToKnownColor();
        }
        public float GetHue()
        {
            return ToColor().GetHue();
        }
        public float GetSaturation()
        {
            return ToColor().GetSaturation();
        }
        public float GetBrightness()
        {
            return ToColor().GetBrightness();
        }
        #endregion Methods

        #region Operators

        public override int GetHashCode()
        {
            return (int)(R * 255f) ^ (int)(G * 255f) ^ (int)(B * 255f) ^ (int)(A * 255f);
        }
        public static bool operator ==(ColorF col1, ColorF col2)
        {
            if (col1.R - col2.R <= 0.005f)
                if (col1.G - col2.G <= 0.005f)
                    if (col1.B - col2.B <= 0.005f)
                        if (col1.A - col2.A <= 0.005f)
                            return true;
            return false;
        }
        public static bool operator !=(ColorF col1, ColorF col2)
        {
            return !(col1 == col2);
        }
        public static implicit operator ColorF(Color col)
        {
            return new ColorF(((float)col.R) / 255f, ((float)col.G) / 255f, ((float)col.B) / 255f, ((float)col.A) / 255f);
        }
        public static implicit operator Color(ColorF col)
        {
            return col.ToColor();
        }
        public override string ToString()
        {
            return ToColor().ToString();
        }
        public override bool Equals(object o)
        {
            return this == (o as ColorF);
        } 

        #endregion Operators

        #region Static Properties
        /// <summary>
        /// Represents a color that is null.
        /// </summary>
        public static readonly ColorF Empty = Color.Empty;
        #endregion Static Properties
    }
}
