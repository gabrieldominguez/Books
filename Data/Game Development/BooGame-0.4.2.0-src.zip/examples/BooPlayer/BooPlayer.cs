/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.IO;
using System.Reflection;
using BooGame;

namespace BooPlayer
{
	/// <summary>
	/// A simple program to run a script when executed.
	/// </summary>
	public class BooPlayer
    {

		[STAThread]
		public static void Main(string[] args)
        {
            CommandLineCollection arguments = new CommandLineCollection(args);
            if (!arguments.WasPassed("nobanner"))
            {
                Version version = Assembly.GetEntryAssembly().GetName().Version;
                Console.WriteLine("BooPlayer v" + version);
                Console.WriteLine("Copyright (c) The BooGame Project");
                Console.WriteLine("See \"BooPlayer /help\" for usage notes");
                Console.WriteLine();
            }
            if (arguments.WasPassed("help"))
            {
                Console.WriteLine("Usage: BooPlayer.exe <script.boo> [/wait] [/help] [/nobanner]");
                Console.WriteLine();
                Console.WriteLine("\t<script.boo>  The script file to run."); 
                Console.WriteLine("\t/wait         Provide wait-time after execution on error.");
                Console.WriteLine("\t/help         Display BooGame help.");
                Console.WriteLine("\t/nobanner     Don't show the BooPlayer banner.");
                Console.WriteLine();
            }

            string file = arguments[0];
            if (file == null)
                file = "/";

            if (!file.StartsWith("/"))
            {
                try
                {
                    string code;
                    using (StreamReader reader = new StreamReader(file))
                        code = reader.ReadToEnd();
                    Script script = new Script();
                    script.AddCode("script", code);
                    script.Compile();
                    script.GetMethod("Main").Invoke(null, null);
                    Core.Run();
                }
                catch (Exception e)
                {
                    do
                    {
                        Console.WriteLine(e.Message);
                        e = e.InnerException;
                    }
                    while (e != null);
                    if (arguments.WasPassed("wait"))
                    {
                        Console.WriteLine("Press enter to continue...");
                        Console.ReadLine();
                    }
                }
            }
		}
	}
}