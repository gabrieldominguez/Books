VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - ported to VB, edx@hk.super.net, Feb 99
'HISTORY: -
'NOTES:
'*************************************************************************
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&

' * Lorenz Attractor Demo
' *
' * Adapted from code originally written for the 4D60GT by
' * Aaron T. Ferrucci (aaronf@cse.ucsc.edu), 7/3/92.
' *
' * Description:
' *
' * This program shows some particles stuck in a Lorenz attractor (the parameters
' * used are r=28, b=8/3, sigma=10). The eye is attracted to the red particle,
' * with a force directly proportionate to distance. A command line
' * puts the whole mess inside a box made of hexagons. I think this helps to
' * maintain the illusion of 3 dimensions, but it can slow things down.
' * Other options allow you to play with the redraw rate and the number of new
' * lines per redraw. So you can customize it to the speed of your machine.
' *
' * For general info on Lorenz attractors I recommend "An Introduction to
' * the Lorenz Equations", IEEE Transactions on Circuits and Systems, August '83.
' *
' * Bugs: hidden surface removal doesn't apply to hexagons, and
' * works poorly on lines when they are too close together.
' *
' * Notes on OpenGL port:
' *
' * The timer functions do not exist in OpenGL, so the drawing occurs in a
' * continuous loop, controlled by step, stop and go input from the keyboard.
' * Perhaps system function could be called to control timing.
' *
Dim asphere&

Const POINTMASK = 511
Const G = 0.002  ' eyept to red sphere gravity
Const LG = 0.3
Const CUBE_SIDE = 120
Const CUBE_SCALE = 23
Const CUBE_OFFX = -4
Const CUBE_OFFY = 0
Const CUBE_OFFZ = 57

' globals
Dim sigma!, r!, b!, dt!
Dim rp&, bp&, gp&, yp&, mp&
Dim xmax&, ymax&, zmax&, zmin&
Dim rv(0 To POINTMASK) As POINT3F        ' red points
Dim bv(0 To POINTMASK) As POINT3F     ' blue points
Dim gv(0 To POINTMASK) As POINT3F     ' green points
Dim yv(0 To POINTMASK) As POINT3F     ' yellow points
Dim mv(0 To POINTMASK) As POINT3F       ' magenta points

Dim lpf&      ' number of new lines per frame
Dim eyex!(0 To 2)  ' eye location
Dim eyev!(3)  ' eye velocity
Dim eyel!(3)  ' lookat point location
Dim dx!, dy!, dz!
Dim QuadObj&
Dim fovy& ' = 600;
Dim cubeoffx!, cubeoffy!, cubeoffz!
Dim farplane! ' = 80.;
Dim animate& ' = 1

' option flags
Dim hexflag As Boolean       ' hexagons?
Dim sflag As Boolean
Dim fflag As Boolean
Dim wflag As Boolean
Dim gflag As Boolean
Dim bdebug As Boolean

' option values
Dim hexbright&    ' brightness for hexagon color
Dim speed&      ' speed (number of new line segs per redraw)
Dim frame&         ' frame rate (actually noise value for TIMER0)
Dim a!
Dim da!            ' hexagon rotational velocity (.1 degree/redraw)
Dim gravity!
Dim hex_data(0 To 7) As POINT3F


Private Sub Class_Initialize()
    sigma = 10
    r = 28
    b = 8 / 3
    dt = 0.003
    fovy = 60
    cubeoffx = CUBE_OFFX
    cubeoffy = cubeoffy
    cubeoffz = cubeoffz
    farplane = 80
    animate = 1
    FillArrayf hex_data(0).p, 0#, 0#, 0#
    FillArrayf hex_data(1).p, 1.155, 0#, 0#
    FillArrayf hex_data(2).p, 0.577, 1#, 0#
    FillArrayf hex_data(3).p, -0.577, 1#, 0#
    FillArrayf hex_data(4).p, -1.155, 0#, 0#
    FillArrayf hex_data(5).p, -0.577, -1#, 0
    FillArrayf hex_data(6).p, 0.577, -1#, 0#
    FillArrayf hex_data(7).p, 1.155, 0#, 0#
    ' set up default values
    speed = 3
    frame = 2
    gravity = G
End Sub

Private Sub Class_Terminate()
    gluDeleteQuadric QuadObj
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    glDisable GL_LIGHTING
    With gCtl.Camera
        .farplane = 100
        .NearPlane = 0.1
        .FieldOfView = 90
        .SetEyePos 0, 0, 5
        .SetTargetPos 0, 0, 0
    End With
    '
    
    With gCtl
        .MouseRotate = True
        .Trackball.animate = False
        .Grid = glxGridX
        .axis = glxXYZ
        .Pick = True
        '.UseCamera = False
    End With
    m_Grids = True
    '
    init_3d
    init_graphics

    ' draw the first POINTMASK points in each color
    Do While rp < POINTMASK
        next_line rv, rp
        next_line bv, bp
        next_line gv, gp
        next_line yv, yp
        next_line mv, mp
    Loop

    eyel(0) = rv(rp).p(0)
    eyel(1) = rv(rp).p(1)
    eyel(2) = rv(rp).p(2)
    
    glPushMatrix
    move_eye
    redraw
    glPopMatrix

    
End Sub

Sub init_graphics()
    glEnable GL_CULL_FACE
    glCullFace GL_BACK
    QuadObj = gluNewQuadric
    gluQuadricNormals QuadObj, GLU_NONE
    asphere = glGenLists(1)
    glNewList asphere, GL_COMPILE
    gluSphere QuadObj, 0.3, 12, 8
    glEndList
End Sub

' initialize global 3-vectors
Sub init_3d()
    '(void)srand48((long)time((time_t*)NULL));

    ' initialize colored points
    rv(0).p(0) = Rnd() * 10
    rv(0).p(1) = Rnd() * 10
    rv(0).p(2) = Rnd() * 10# - 10

    bv(0).p(0) = rv(0).p(0) + Rnd() * 5
    bv(0).p(1) = rv(0).p(1) + Rnd() * 5
    bv(0).p(0) = rv(0).p(2) + Rnd() * 5

    gv(0).p(0) = rv(0).p(0) + Rnd() * 5
    gv(0).p(1) = rv(0).p(1) + Rnd() * 5
    gv(0).p(0) = rv(0).p(2) + Rnd() * 5

    yv(0).p(0) = rv(0).p(0) + Rnd() * 5
    yv(0).p(1) = rv(0).p(1) + Rnd() * 5
    yv(0).p(0) = rv(0).p(2) + Rnd() * 5

    mv(0).p(0) = rv(0).p(0) + Rnd() * 5
    mv(0).p(1) = rv(0).p(1) + Rnd() * 5
    mv(0).p(0) = rv(0).p(2) + Rnd() * 5

    ' initialize eye velocity
    'eyev(0) = eyev(1) = eyev(2) = 0
End Sub


Public Sub Draw()
Dim i&, j&
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With

    If animate Then
        i = speed
        Do While i
            next_line rv, rp
            next_line bv, bp
            next_line gv, gp
            next_line yv, yp
            next_line mv, mp
            i = i - 1
        Loop
        glPushMatrix
        move_eye
        redraw
        glPopMatrix
    End If
    CheckError
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
    'glViewport(0,0,width,height);
    'glClear GL_COLOR_BUFFER_BIT);
    xmax = width
    ymax = height
    'glViewport 0, 0, xmax, ymax
    'setPerspective fovy, xmax / ymax, 0.1, farplane
End Function

'Sub setPerspective(angle&, aspect!, zNear!, zFar!)
'    glPushAttrib GL_TRANSFORM_BIT
'    glMatrixMode GL_PROJECTION
'    gluPerspective angle * 0.1, aspect, zNear, zFar
'    glPopAttrib
'End Sub

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "g": animate = 1
    Case "s": animate = 0
    End Select
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If m_bMoving Then
        End If
    Else
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, Z#, z1!
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    'Z = 1.79769313486232E308
    Z = 10000000000# ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                Debug.Print " z1 = " & items(ptr)
                z1 = items(ptr)
                ptr = ptr + 1
            '3.z2
                Debug.Print " z2 = " & items(ptr)
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < Z Then
                        Z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub

' compute the next point on the path according to Lorenz' equations.
Private Sub next_line(v() As POINT3F, p&)
    dx = sigma * (v(p).p(1) - v(p).p(0)) * dt
    dy = (r * v(p).p(0) - v(p).p(1) + v(p).p(0) * v(p).p(2)) * dt
    dz = (v(p).p(0) * v(p).p(1) + b * v(p).p(2)) * dt
    
    v((p + 1) And POINTMASK).p(0) = v(p).p(0) + dx
    v((p + 1) And POINTMASK).p(1) = v(p).p(1) + dy
    v((p + 1) And POINTMASK).p(2) = v(p).p(2) - dz
    p = (p + 1) And POINTMASK
End Sub

Private Sub drawLines(index&, arr() As POINT3F)  'float array(POINTMASK)(3))
Const LINE_STEP = 4
Dim p&, i&
    p = (index + 1) And POINTMASK
    i = LINE_STEP - (p Mod LINE_STEP)
    If i = LINE_STEP Then i = 0
    glBegin GL_LINE_STRIP
    ' draw points in order from oldest to newest
    Do While (p <> index)
        If i = 0 Then
            glVertex3fv arr(p).p(0)
            i = LINE_STEP
        End If
        i = i - 1
        p = (p + 1) And POINTMASK
    Loop
    glVertex3fv arr(index).p(0)
    glEnd
End Sub


Sub redraw()
Dim p&
    glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
    If hexflag Then draw_hexcube

    glColor3f 1, 0, 0
    drawLines rp, rv
    sphdraw rv(rp).p

    glColor3f 0, 0, 1
    drawLines bp, bv
    sphdraw bv(bp).p
    
    glColor3f 0, 1, 0
    drawLines gp, gv
    sphdraw gv(gp).p

    glColor3f 1, 0, 1
    drawLines yp, yv
    sphdraw yv(yp).p

    glColor3f 0, 1, 1
    drawLines mp, mv
    sphdraw mv(mp).p
End Sub


Sub move_eye()
    ' first move the eye
    eyev(0) = eyev(0) + gravity * (rv(rp).p(0) - eyex(0))
    eyev(1) = eyev(1) + gravity * (rv(rp).p(1) - eyex(1))
    eyev(2) = eyev(2) + gravity * (rv(rp).p(2) - eyex(2))

    ' adjust position using new velocity
    eyex(0) = eyex(0) + eyev(0) * dt
    eyex(1) = eyex(1) + eyev(1) * dt
    eyex(2) = eyex(2) + eyev(2) * dt

    ' move the lookat point
    ' it catches up to the red point if it's moving slowly enough
    eyel(0) = eyel(0) + LG * (rv(rp).p(0) - eyel(0))
    eyel(1) = eyel(1) + LG * (rv(rp).p(1) - eyel(1))
    eyel(2) = eyel(2) + LG * (rv(rp).p(2) - eyel(2))

    ' change view
'    gluLookAt eyex(0), eyex(1), eyex(2), eyel(0), eyel(1), eyel(2), _
'          0, 1, 0
    With gCtl.Camera
        .SetEyePos eyex(0), eyex(1), eyex(2)
        .SetTargetPos eyel(0), eyel(1), eyel(2)
    End With
End Sub

Sub draw_hexcube()
    a = a + da
    If a >= 720 Then       ' depends on slowest rotation factor
        a = 0
    End If

    ' draw hexplanes, without changing z-values
    glDepthMask GL_FALSE
    glDisable GL_DEPTH_TEST

    ' x-y plane
    glColor3f 0.2, 0.2, 0.6
    glPushMatrix
    glTranslatef cubeoffx, cubeoffy, cubeoffz
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix

    ' x-y plane, translated
    glPushMatrix
    glTranslatef cubeoffx, cubeoffy, cubeoffz - 2 * CUBE_SIDE
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix

    glColor3f 0.6, 0.2, 0.2
    ' x-z plane, translate low
    glPushMatrix
    glRotatef 90, 1, 0, 0
    glTranslatef cubeoffx, cubeoffz - CUBE_SIDE, -cubeoffy + CUBE_SIDE
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix

    ' x-z plane, translate high
    glPushMatrix
    glRotatef 90, 1, 0, 0
    glTranslatef cubeoffx, cubeoffz - CUBE_SIDE, -cubeoffy - CUBE_SIDE
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix

    glColor3f 0.2, 0.6, 0.2
    ' y-z plane, translate low
    glPushMatrix
    glRotatef 90, 0, 1, 0
    glTranslatef -cubeoffz + CUBE_SIDE, cubeoffy, cubeoffx + CUBE_SIDE
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix
    
    ' y-z plane, translate high
    glPushMatrix
    glRotatef 90, 0, 1, 0
    glTranslatef -cubeoffz + CUBE_SIDE, cubeoffy, cubeoffx - CUBE_SIDE
    glScalef CUBE_SCALE, CUBE_SCALE, CUBE_SCALE
    draw_hexplane
    glPopMatrix

    glFlush
    glDepthMask GL_TRUE
    glEnable GL_DEPTH_TEST
End Sub

' draws a hexagon 2 units across, in the x-y plane,
' centered at <0, 0, 0>
Sub draw_hexagon()
    If wflag Then
        glPushMatrix
        glRotatef a, 0, 0, 1
    End If

    glBegin GL_TRIANGLE_FAN
        glVertex3fv hex_data(0).p(0)
        glVertex3fv hex_data(1).p(0)
        glVertex3fv hex_data(2).p(0)
        glVertex3fv hex_data(3).p(0)
        glVertex3fv hex_data(4).p(0)
        glVertex3fv hex_data(5).p(0)
        glVertex3fv hex_data(6).p(0)
        glVertex3fv hex_data(7).p(0)
    glEnd

    If wflag Then glPopMatrix
End Sub

Sub tmp_draw_hexplane()
    glRectf -2, -2, 2, 2
End Sub

' draw 7 hexagons
Sub draw_hexplane()
    If wflag Then
    glPushMatrix
    glRotatef -0.5 * a, 0, 0, 1
    End If

    ' center , <0, 0, 0>
    draw_hexagon

    ' 12 o'clock, <0, 4, 0>
    glTranslatef 0#, 4#, 0#
    draw_hexagon

    ' 10 o'clock, <-3.464, 2, 0>
    glTranslatef -3.464, -2, 0
    draw_hexagon

    ' 8 o'clock, <-3.464, -2, 0>
    glTranslatef 0#, -4#, 0#
    draw_hexagon

    ' 6 o'clock, <0, -4, 0>
    glTranslatef 3.464, -2#, 0#
    draw_hexagon

    ' 4 o'clock, <3.464, -2, 0>
    glTranslatef 3.464, 2#, 0#
    draw_hexagon

    ' 2 o'clock, <3.464, 2, 0>
    glTranslatef 0#, 4#, 0#
    draw_hexagon

    If wflag Then glPopMatrix
End Sub

Sub sphdraw(pt!()) '0 to 2
    glPushMatrix
    glTranslatef pt(0), pt(1), pt(2)
    glCallList asphere
    glPopMatrix
End Sub


'#ifndef WIN32
'extern char *optarg;
'extern int optind, opterr;
'#End If

'#define USAGE "usage message: this space for rent\n"
'sub parse_args(int argc, char **argv)
'{
'    int c;
'
'    hexflag = sflag = fflag = wflag = gflag = debug = FALSE;
'#ifndef WIN32
'    opterr = 0;
'#End If
'
'#ifdef WIN32
'    while (--argc) {
'    if (strcmp("-X", argv(argc)) == 0) {
'        debug = TRUE;
'    } else if (strcmp("-h", argv(argc)) == 0) {
'        print_usage(argv(0));
'        exit(1);
'    } else if (strcmp("-i", argv(argc)) == 0) {
'        print_info
'        exit(1);
'    } else if (strcmp("-x", argv(argc)) == 0) {
'        hexflag = TRUE;
'        farplane = 300.;
'    } else if (strcmp("-s", argv(argc)) == 0) {
'        sflag = TRUE;
'        if (argv(argc+1))
'        speed = atoi(argv(argc+1));
'        else {
'        printf "%s: -s option requires an argument.\n", argv(0));
'        exit(1);
'        }
'    } else if (strcmp("-f", argv(argc)) == 0) {
'        fflag = TRUE;
'        if (argv(argc+1))
'        frame = atoi(argv(argc+1));
'        else {
'        printf "%s: -f option requires an argument.\n", argv(0));
'        exit(1);
'        }
'        if frame < 0) {
'        fprintf stderr, "Try a small positive value for \n");
'        fprintf stderr, "'f'; this is the number of vertical ");
'        fprintf stderr, "retraces per redraw\n");
'        fprintf stderr, "Try %s -h for help\n", argv(0));
'        exit(1);
'        }
'    } else if (strcmp("-w", argv(argc)) == 0) {
'        wflag = TRUE;
'        if (argv(argc+1))
'        da = atof argv(argc+1));
'        else {
'        printf("%s: -w option requires an argument.\n", argv(0));
'        exit(1);
'        }
'        if(da > 10.) {
'        fprintf(stderr, "That's a large rotational velocity ('w')");
'        fprintf(stderr, " but you asked for it\n");
'        }
'        break;
'    } else if (strcmp("-g", argv(argc)) == 0) {
'        gflag = TRUE;
'        if (argv(argc+1))
'        gravity = atof(argv(argc+1));
'        else {
'        printf("%s: -g option requires an argument.\n", argv(0));
'        exit(1);
'        }
'        if(gravity <= 0) {
'        fprintf(stderr, "Gravity ('g') should be positive\n");
'        fprintf(stderr, "Try %s -h for help\n", argv(0));
'        }
'    } else if (strcmp("-?", argv(argc)) == 0) {
'        fprintf(stderr, USAGE);
'    }
'    }
'#Else
'    while( (c = getopt(argc, argv, "Xhixs:f:w:g:")) <> -1)
'    switch(c) {
'      case 'X':
'        debug = TRUE;
'        break;
'      case 'h':
'        print_usage(argv(0));
'        exit(1);
'      case 'i':
'        print_info
'        exit(1);
'      case 'x':
'        hexflag = TRUE;
'        farplane = 300.;
'        break;
'      case 's':
'        sflag = TRUE;
'        speed = atoi(optarg);
'        if(speed < 0) {
'        fprintf(stderr, "Use a small positive value for speed ('s').\n");
'        fprintf(stderr, "Try %s -h for help\n", argv(0));
'        exit(1);
'        }
'        break;
'      case 'f':
'        fflag = TRUE;
'        frame = atoi(optarg);
'        if(frame < 0) {
'        fprintf(stderr, "Try a small positive value for \n");
'        fprintf(stderr, "'f'; this is the number of vertical ");
'        fprintf(stderr, "retraces per redraw\n");
'        fprintf(stderr, "Try %s -h for help\n", argv(0));
'        exit(1);
'        }
'        break;
'      case 'w':
'        wflag = TRUE;
'        da = atof(optarg);
'        if(da > 10.) {
'        fprintf(stderr, "That's a large rotational velocity ('w')");
'        fprintf(stderr, " but you asked for it\n");
'        }
'        break;
'      case 'g':
'        gflag = TRUE;
'        gravity = atof(optarg);
'        if(gravity <= 0) {
'        fprintf(stderr, "Gravity ('g') should be positive\n");
'        fprintf(stderr, "Try %s -h for help\n", argv(0));
'        }
'        break;
'      case '?':
'        fprintf(stderr, USAGE);
'    }
'#End If
'
'    ' set up default values
'    if(!sflag)
'    speed = 3;
'    if(!fflag)
'    frame = 2;
'    if(!wflag)
'    da = 0.;
'    if(!gflag)
'    gravity = G;
'End Sub

'void print_usage(Char * program)
'{
'printf("\nUsage: %s (-h) (-i) (-x) (-s speed)", program);
'printf(" (-w rot_v) (-g gravity)\n\n");
'printf("-h              Print this message.\n");
'printf("-i              Print information about the demo.\n");
'printf("-x              Enclose the particles in a box made of hexagons.\n");
'printf("-s speed        Sets the number of new line segments per redraw \n");
'printf("                interval per line. Default value: 3.\n");
'
''** The X port does not currently include a timer, so this feature is disabled.
'printf("-f framenoise   Sets the number of vertical retraces per redraw\n");
'printf("                interval. Example: -f 2 specifies one redraw per\n");
'printf("                2 vertical retraces, or 30 frames per second.\n");
'printf("                Default value: 2.\n");
'***********
'
'printf("-w rot_v        Spins the hexagons on their centers, and the sides\n");
'printf("                of the box on their centers. Hexagons spin at the\n");
'printf("                rate rot_v degrees per redraw, and box sides spin\n");
'printf("                at -rot_v/2 degrees per redraw.\n");
'printf("-g gravity      Sets the strength of the attraction of the eye to\n");
'printf("                the red particle. Actually, it's not gravity since\n");
'printf("                the attraction is proportionate to distance.\n");
'printf("                Default value: 0.002. Try large values!\n");
'' input added for GLX port
'printf(" Executions control:  \n");
'printf("    <spacebar>  step through single frames\n");
'printf("    g       begin continuous frames\n");
'printf("    s       stop continuous frames\n");
'
'}
'
'void print_info(void)
'{
'printf("\nLORENZ ATTRACTOR DEMO\n\n");
'printf("This program shows some particles stuck in a Lorenz attractor (the \n");
'printf("parameters used are r=28, b=8/3, sigma=10). The eye is attracted to \n");
'printf("the red particle, with a force directly proportional to distance. \n");
'printf("A command line argument puts the particles inside a box made of hexagons, \n");
'printf("helping  to maintain the sense of 3 dimensions, but it can slow things down.\n");
'printf("Other options allow you to play with the redraw rate and gravity.\n\n");
'
'printf("Try lorenz -h for the usage message.\n");
'}
'



