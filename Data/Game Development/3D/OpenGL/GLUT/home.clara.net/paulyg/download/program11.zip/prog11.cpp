#include <windows.h>
#include <GL/glut.h>

#include <stdio.h>

   GLuint list[1];

   int wire_frame = 0;

   void make_shape ( void )
   {

      GLUtriangulatorObj    *tess;

      /* Just a square polygon for the outside profile */
      GLdouble outside [4][3] = {  { -0.9, -0.9, 0.0 },
         {  0.9, -0.9, 0.0 },
         {  0.9,  0.9, 0.0 },
         { -0.9,  0.9, 0.0 } };

      /* Small triangle for the inside */
      GLdouble inside [3][3] = {
         { 0.0,   0.3, 0.0 },
         { 0.3,  -0.3, 0.0 },
         { -0.3, -0.3, 0.0 } };

      list[0] = glGenLists ( 1 );
      tess    = gluNewTess ( );

      /* Nice casting here -- NOT!!
         Your compiler might have different requirements here - I'd like feedback
         if it does so we can tell other people :) */
      gluTessCallback ( tess, GLU_BEGIN,  ( void ( __stdcall *) ( void ))glBegin     );
      gluTessCallback ( tess, GLU_VERTEX, ( void ( __stdcall *) ( void ))glVertex3dv );

      /* 'glEnd' doesn't require the casting because it doesn't take any arguments like
         'glBegin' and 'glVertex3dv' do */
      gluTessCallback ( tess, GLU_END,    glEnd       );

      /* Compile the results from the tesselator into a display list so we don't
         have to invoke it every frame */
      glNewList ( list[0], GL_COMPILE );

      gluBeginPolygon ( tess );
      for ( int i = 0; i < 4; i++ )
         gluTessVertex ( tess, outside[i], outside[i] );

      gluNextContour ( tess, GLU_INTERIOR );
      for ( int i = 0; i < 3; i++ )
         gluTessVertex ( tess, inside[i], inside[i] );
      gluEndPolygon ( tess );

      glEndList ( );

      gluDeleteTess ( tess );
   }


   void init ( void )
   {
      glEnable ( GL_CULL_FACE );

      glClearColor ( 0.0, 0.0, 0.0, 0.0 );

      make_shape ( );
   }


   void display ( void )
   {
      glClear   ( GL_COLOR_BUFFER_BIT );

      glLoadIdentity ( );

      glColor3ub ( 255, 255, 255 );
      glCallList ( list[0] );

      glutSwapBuffers ( );
   }

   void reshape(int w, int h)
   {
      glViewport   ( 0, 0, (GLint) w, (GLint) h );
      glMatrixMode ( GL_PROJECTION );
      glLoadIdentity ( );

      if ( w <= h )
         glOrtho ( -1.0* w / h, 1.0 * w / h, -1.0, 1.0, 1.0, -1.0 );

      else
         glOrtho ( -1.0, 1.0, -1.0 * h / w, 1.0 * h / w, 1.0, -1.0 );

      glMatrixMode   ( GL_MODELVIEW );
      glLoadIdentity ( );
   }

   void idle_func ( void )
   {
      glutPostRedisplay ( );
   }

#pragma argsused
   void keyboard ( unsigned char key, int x, int y )
   {
      int i;

      switch (key) {
         case 27:  /*  Escape key  */
            exit(0);
            break;

         case 'w':
            wire_frame ^= 1;
            if ( wire_frame )
               glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE );
            else
               glPolygonMode ( GL_FRONT_AND_BACK, GL_FILL );
            break;

         default:
            break;
      }
   }

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
   int main ( int argc, char** argv )
   {
      glutInit ( &argc, argv );
      glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE );
      glutInitWindowSize ( 250, 250 );
      glutCreateWindow   ( argv[0]  );

      printf( "Extensions available: %s\n", glGetString ( GL_EXTENSIONS ));

      init ( );

      glutReshapeFunc  ( reshape   );
      glutKeyboardFunc ( keyboard  );
      glutDisplayFunc  ( display   );
      glutIdleFunc     ( idle_func );

      glutMainLoop ( );

      return 0;
   }
