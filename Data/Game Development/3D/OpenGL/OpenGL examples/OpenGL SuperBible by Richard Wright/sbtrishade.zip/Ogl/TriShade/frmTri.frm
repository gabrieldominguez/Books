VERSION 5.00
Begin VB.Form frmDisplay 
   Caption         =   "Form1"
   ClientHeight    =   6000
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   ScaleHeight     =   400
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   400
   StartUpPosition =   3  'Windows Default
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFile_Exit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEffects 
      Caption         =   "&Effects"
      Begin VB.Menu mnuFlat_Shading 
         Caption         =   "&Flat Shading"
      End
      Begin VB.Menu mnuSmooth_Shading 
         Caption         =   "&Smooth Shading"
      End
   End
End
Attribute VB_Name = "frmDisplay"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Paint()
        ReDraw
End Sub

Private Sub Form_Resize()

    Dim WinAW As GLfloat, WinAH As GLfloat
    Dim WinW As GLfloat, WinH As GLfloat
    
    glViewport 0#, 0#, frmDisplay.ScaleWidth, frmDisplay.ScaleHeight
    
    WinAW = frmDisplay.ScaleWidth
    WinAH = frmDisplay.ScaleHeight
    
    If WinAW <= WinAH Then
      WinH = 400# * WinAH / WinAW
      WinW = 400#
    Else
      WinW = 400# * WinAW / WinAH
      WinH = 400#
    End If
    
    glMatrixMode mmProjection
    glLoadIdentity
    glOrtho -WinW / 2#, WinW / 2#, -WinH / 2#, WinH / 2#, 150#, -150#
    glMatrixMode mmModelView
    glLoadIdentity
   
    Call RenderScene
        
End Sub

Private Sub Form_Unload(Cancel As Integer)
    bAppRunning = False
End Sub

Private Sub mnuFile_Exit_Click()
    bAppRunning = False
End Sub

Private Sub mnuFlat_Shading_Click()
  mnuFlat_Shading.Checked = True
  mnuSmooth_Shading.Checked = False
  iFlatSmooth = 1
  Call ReDraw
End Sub

Private Sub mnuSmooth_Shading_Click()
  mnuFlat_Shading.Checked = False
  mnuSmooth_Shading.Checked = True
  iFlatSmooth = 2
  Call ReDraw
End Sub
