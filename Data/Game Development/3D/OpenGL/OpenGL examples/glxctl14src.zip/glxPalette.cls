VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxPalette"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'Module Name: palette.hxx
'Copyright (c) 1996 Microsoft Corporation
'-------------------------------------------------------------------------
'FUNCTION: provides palette support for 256 color mode
'   - the 'use static' and 'take over' routines were
'   - culled.
'   - Note that palette support requires subclassing and
'   - since that is undesirable, the support must be enabled by
'   - defining the conditional 'DoSublass'
'   - The ocx always calls Hook and Unhook - if DoSublass is defined
'   - it will always needlessly subclass the window.
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to subclass the ocx, April 98
'KNOWN PROBLEMS:
'-------------------------------------------------------------------------
Const GAMMA_CORRECTION = 14 ' Gamma correction factor '10
Const MAX_COL_DIST& = &H30000 ' = (3 * 256 * 256)' Maximum color distance with 8-bit components
Const STATIC_COLORS = 20 ' Number of static colors
Const EXACT_MATCH = 1 ' Flags used when matching colors
Const COLOR_USED = 1
Private Declare Function GetPaletteEntriesCount& Lib "gdi32" Alias "GetPaletteEntries" (ByVal hPalette As Long, ByVal wStartIndex As Long, ByVal wNumEntries As Long, ByVal lpNull&)
Private Declare Function InvalidateRectBynum& Lib "user32" Alias "InvalidateRect" (ByVal hWnd As Long, ByVal lpRect As Long, ByVal bErase As Long)
'
' Fixed palette support.
Const MAX_STATIC_COLORS = (COLOR_INFOBK - COLOR_SCROLLBAR + 1)
' new B&W system static colors
Dim nEntries&    '  ' number of entries in palette
Dim abThreeToEight(0 To 7) As Byte
Dim abTwoToEight(0 To 3) As Byte
Dim abOneToEight(0 To 1) As Byte
Dim aiDefaultOverride%(0 To STATIC_COLORS - 1)
Dim apeDefaultPalEntry(0 To STATIC_COLORS - 1) As PALETTEENTRY
'
Dim m_hWnd& 'the user control
Dim m_OldProc& ''the use control's window proc
Dim m_bFlush As Boolean    '' if palette needs to be flushed
Dim m_hPal& 'current palette
Dim m_pPal As LOGPALETTE
Dim m_bForce As Boolean 'to force palette creation in 24bit mode
'
Dim m_Msgs&()

Private Sub Class_Initialize()
'm_bFlush = True
'If GAMMA_CORRECTION = 10 Then
'    ' These tables are corrected for a gamma of 1.0
'    abThreeToEight(0) = 0
'    abThreeToEight(1) = 111 \ 2
'    abThreeToEight(2) = 222 \ 2
'    abThreeToEight(3) = 333 \ 2
'    abThreeToEight(4) = 444 \ 2
'    abThreeToEight(5) = 555 \ 2
'    abThreeToEight(6) = 666 \ 2
'    abThreeToEight(7) = 377
'    '
'    abTwoToEight(0) = 0
'    abTwoToEight(1) = &H55
'    abTwoToEight(2) = &HAA
'    abTwoToEight(3) = &HFF
'    '
'    abOneToEight(0) = 0
'    abOneToEight(1) = 255
'Else
'    ' These tables are corrected for a gamma of 1.4
'    abThreeToEight(0) = 0
'    abThreeToEight(1) = 63
'    abThreeToEight(2) = 104
'    abThreeToEight(3) = 139
'    abThreeToEight(4) = 171
'    abThreeToEight(5) = 200
'    abThreeToEight(6) = 229
'    abThreeToEight(7) = 255
'    '
'    abTwoToEight(0) = 0
'    abTwoToEight(1) = 116
'    abTwoToEight(2) = 191
'    abTwoToEight(3) = 255
'    '
'    abOneToEight(0) = 0
'    abOneToEight(1) = 255
'End If
'
'' Table which indicates which colors in a 3-3-2 palette should be
'' replaced with the system default colors
'If GAMMA_CORRECTION = 10 Then
'    aiDefaultOverride(0) = 0
'    aiDefaultOverride(1) = 4
'    aiDefaultOverride(2) = 32
'    aiDefaultOverride(3) = 36
'    aiDefaultOverride(4) = 128
'    aiDefaultOverride(5) = 132
'    aiDefaultOverride(6) = 160
'    aiDefaultOverride(7) = 173
'    aiDefaultOverride(8) = 181
'    aiDefaultOverride(9) = 245
'    aiDefaultOverride(10) = 247
'    aiDefaultOverride(11) = 164
'    aiDefaultOverride(12) = 156
'    aiDefaultOverride(13) = 7
'    aiDefaultOverride(14) = 56
'    aiDefaultOverride(15) = 63
'    aiDefaultOverride(16) = 192
'    aiDefaultOverride(17) = 199
'    aiDefaultOverride(18) = 248
'    aiDefaultOverride(19) = 255
'Else
'    aiDefaultOverride(0) = 0
'    aiDefaultOverride(1) = 3
'    aiDefaultOverride(2) = 24
'    aiDefaultOverride(3) = 27
'    aiDefaultOverride(4) = 64
'    aiDefaultOverride(5) = 67
'    aiDefaultOverride(6) = 88
'    aiDefaultOverride(7) = 173
'    aiDefaultOverride(8) = 181
'    aiDefaultOverride(9) = 236
'    aiDefaultOverride(10) = 247
'    aiDefaultOverride(11) = 164
'    aiDefaultOverride(12) = 91
'    aiDefaultOverride(13) = 7
'    aiDefaultOverride(14) = 56
'    aiDefaultOverride(15) = 63
'    aiDefaultOverride(16) = 192
'    aiDefaultOverride(17) = 199
'    aiDefaultOverride(18) = 248
'    aiDefaultOverride(19) = 255
'End If
'' System default colors
'm_SetPEntry apeDefaultPalEntry(0), 0, 0, 0
'm_SetPEntry apeDefaultPalEntry(1), &H80, 0, 0
'm_SetPEntry apeDefaultPalEntry(2), 0, &H80, 0
'm_SetPEntry apeDefaultPalEntry(3), &H80, &H80, 0
'm_SetPEntry apeDefaultPalEntry(4), 0, 0, &H80
'm_SetPEntry apeDefaultPalEntry(5), &H80, 0, &H80
'm_SetPEntry apeDefaultPalEntry(6), 0, &H80, &H80
'm_SetPEntry apeDefaultPalEntry(7), &HC0, &HC0, &HC0
'm_SetPEntry apeDefaultPalEntry(8), 192, 220, 192
'm_SetPEntry apeDefaultPalEntry(9), 166, 202, 240
'm_SetPEntry apeDefaultPalEntry(10), 255, 251, 240
'm_SetPEntry apeDefaultPalEntry(11), 160, 160, 164
'm_SetPEntry apeDefaultPalEntry(12), &H80, &H80, &H80
'm_SetPEntry apeDefaultPalEntry(13), &HFF, 0, 0
'm_SetPEntry apeDefaultPalEntry(14), 0, &HFF, 0
'm_SetPEntry apeDefaultPalEntry(15), &HFF, &HFF, 0
'm_SetPEntry apeDefaultPalEntry(16), 0, 0, &HFF
'm_SetPEntry apeDefaultPalEntry(17), &HFF, 0, &HFF
'm_SetPEntry apeDefaultPalEntry(18), 0, &HFF, &HFF
'm_SetPEntry apeDefaultPalEntry(19), &HFF, &HFF, &HFF
End Sub

Private Sub Class_Terminate()
    ReleaseHook
    If m_hPal Then
        SelectPalette UC.hDC, GetStockObject(DEFAULT_PALETTE), True
        DeleteObject m_hPal
    End If
End Sub

'-------------------------------------------------------------------------
'Realize
'Select the given palette in background or foreground mode (as specified
'by the bForceBackground flag), and realize the palette.
'If static system color usage is set, the system colors are replaced.
'-------------------------------------------------------------------------
Friend Function Realize&() 'hwndArg&, hdcArg&) ', bForceBackground As Boolean)
    If (m_bFlush) Then
        m_Flush
        m_bFlush = False
    End If
    Realize = m_Realize() 'bForceBackground)
End Function

'-------------------------------------------------------------------------
'exposed to allow apps to set palette colors
'an alternative is to allow the app to create a palette
'and pass the hPal to the ocx and then select and realize it
'in this module, which seems to work.
'
'note these functions don't trigger a repaint, because the user
'can do it if needed, and sometimes it might not be desired
'-------------------------------------------------------------------------
Public Sub SetColor(ByVal Index&, ByVal Red As Byte, ByVal Green As Byte, ByVal Blue As Byte)
Dim pe As PALETTEENTRY
    If m_hPal = 0 Then Exit Sub
    pe.peRed = Red
    pe.peGreen = Green
    pe.peBlue = Blue
    SetPaletteEntries m_hPal, Index, 1, pe
    'm_bFlush = True
    If SelectPalette(UC.hDC, m_hPal, False) Then
        RealizePalette UC.hDC
    End If
End Sub

'-------------------------------------------------------------------------
'allows user to set a custom palette
'-------------------------------------------------------------------------
Public Function SetPalette(ByVal hPal&) As Boolean
Dim hPalTmp&
    If hPal = 0 Then Exit Function
    hPalTmp = m_hPal
    m_hPal = hPal
    'm_bFlush = True
    If SelectPalette(UC.hDC, m_hPal, False) Then
        RealizePalette UC.hDC
        If (hPalTmp) Then
            DeleteObject (hPalTmp)
        End If
    Else: m_hPal = hPalTmp
    End If
End Function

Public Function GetPalette&()
GetPalette = m_hPal&
End Function

Private Sub m_Init()
m_bFlush = True
If GAMMA_CORRECTION = 10 Then
    ' These tables are corrected for a gamma of 1.0
    abThreeToEight(0) = 0
    abThreeToEight(1) = 111 \ 2
    abThreeToEight(2) = 222 \ 2
    abThreeToEight(3) = 333 \ 2
    abThreeToEight(4) = 444 \ 2
    abThreeToEight(5) = 555 \ 2
    abThreeToEight(6) = 666 \ 2
    abThreeToEight(7) = 377
    '
    abTwoToEight(0) = 0
    abTwoToEight(1) = &H55
    abTwoToEight(2) = &HAA
    abTwoToEight(3) = &HFF
    '
    abOneToEight(0) = 0
    abOneToEight(1) = 255
Else
    ' These tables are corrected for a gamma of 1.4
    abThreeToEight(0) = 0
    abThreeToEight(1) = 63
    abThreeToEight(2) = 104
    abThreeToEight(3) = 139
    abThreeToEight(4) = 171
    abThreeToEight(5) = 200
    abThreeToEight(6) = 229
    abThreeToEight(7) = 255
    '
    abTwoToEight(0) = 0
    abTwoToEight(1) = 116
    abTwoToEight(2) = 191
    abTwoToEight(3) = 255
    '
    abOneToEight(0) = 0
    abOneToEight(1) = 255
End If

' Table which indicates which colors in a 3-3-2 palette should be
' replaced with the system default colors
If GAMMA_CORRECTION = 10 Then
    aiDefaultOverride(0) = 0
    aiDefaultOverride(1) = 4
    aiDefaultOverride(2) = 32
    aiDefaultOverride(3) = 36
    aiDefaultOverride(4) = 128
    aiDefaultOverride(5) = 132
    aiDefaultOverride(6) = 160
    aiDefaultOverride(7) = 173
    aiDefaultOverride(8) = 181
    aiDefaultOverride(9) = 245
    aiDefaultOverride(10) = 247
    aiDefaultOverride(11) = 164
    aiDefaultOverride(12) = 156
    aiDefaultOverride(13) = 7
    aiDefaultOverride(14) = 56
    aiDefaultOverride(15) = 63
    aiDefaultOverride(16) = 192
    aiDefaultOverride(17) = 199
    aiDefaultOverride(18) = 248
    aiDefaultOverride(19) = 255
Else
    aiDefaultOverride(0) = 0
    aiDefaultOverride(1) = 3
    aiDefaultOverride(2) = 24
    aiDefaultOverride(3) = 27
    aiDefaultOverride(4) = 64
    aiDefaultOverride(5) = 67
    aiDefaultOverride(6) = 88
    aiDefaultOverride(7) = 173
    aiDefaultOverride(8) = 181
    aiDefaultOverride(9) = 236
    aiDefaultOverride(10) = 247
    aiDefaultOverride(11) = 164
    aiDefaultOverride(12) = 91
    aiDefaultOverride(13) = 7
    aiDefaultOverride(14) = 56
    aiDefaultOverride(15) = 63
    aiDefaultOverride(16) = 192
    aiDefaultOverride(17) = 199
    aiDefaultOverride(18) = 248
    aiDefaultOverride(19) = 255
End If
' System default colors
m_SetPEntry apeDefaultPalEntry(0), 0, 0, 0
m_SetPEntry apeDefaultPalEntry(1), &H80, 0, 0
m_SetPEntry apeDefaultPalEntry(2), 0, &H80, 0
m_SetPEntry apeDefaultPalEntry(3), &H80, &H80, 0
m_SetPEntry apeDefaultPalEntry(4), 0, 0, &H80
m_SetPEntry apeDefaultPalEntry(5), &H80, 0, &H80
m_SetPEntry apeDefaultPalEntry(6), 0, &H80, &H80
m_SetPEntry apeDefaultPalEntry(7), &HC0, &HC0, &HC0
m_SetPEntry apeDefaultPalEntry(8), 192, 220, 192
m_SetPEntry apeDefaultPalEntry(9), 166, 202, 240
m_SetPEntry apeDefaultPalEntry(10), 255, 251, 240
m_SetPEntry apeDefaultPalEntry(11), 160, 160, 164
m_SetPEntry apeDefaultPalEntry(12), &H80, &H80, &H80
m_SetPEntry apeDefaultPalEntry(13), &HFF, 0, 0
m_SetPEntry apeDefaultPalEntry(14), 0, &HFF, 0
m_SetPEntry apeDefaultPalEntry(15), &HFF, &HFF, 0
m_SetPEntry apeDefaultPalEntry(16), 0, 0, &HFF
m_SetPEntry apeDefaultPalEntry(17), &HFF, 0, &HFF
m_SetPEntry apeDefaultPalEntry(18), 0, &HFF, &HFF
m_SetPEntry apeDefaultPalEntry(19), &HFF, &HFF, &HFF
End Sub

'---------------------------------------------------------------------------------
'called from the GL setup
'---------------------------------------------------------------------------------
Friend Sub Init(ByVal hDC As Long)
Dim PixelFormat As Long
    '
    m_Init
    'if someone calls the UC.Init() twice, we need to
    'restore the wndproc and destroy the palette
    ReleaseHook
    If m_hPal Then
        SelectPalette UC.hDC, GetStockObject(DEFAULT_PALETTE), True
        DeleteObject m_hPal
        m_hPal = 0
    End If
    '
    PixelFormat = GetPixelFormat(hDC)
    DescribePixelFormat hDC, PixelFormat, Len(gPFD), gPFD
    Debug.Print "dwFlags:" & Hex(gPFD.dwFlags)
    If gPFD.dwFlags And PFD_NEED_SYSTEM_PALETTE Then
        'not supported as of now
        Debug.Assert 0
    End If
    If (gPFD.dwFlags And PFD_NEED_PALETTE) = 0 Then
        If gPFD.iPixelType = PFD_TYPE_RGBA Then
            'we're in 24bit mode and using RGBA
            Exit Sub
        Else
            'we're in color index mode with 24bit display mode
            Debug.Print "Colorbits:" & gPFD.cColorBits
            If gPFD.cColorBits >= 24 Then
                m_bForce = True
            End If
        End If
    End If
    '
    'we subclass the window in 256 mode to get the WM_ palette msgs
    If gPFD.cColorBits = 8 Then
        SetHook
    End If
    
    m_hPal = m_MakeRGBPalette()
    If m_hPal <> 0 Then
        m_Flush
        If SelectPalette(hDC, m_hPal, False) Then
            RealizePalette hDC
        End If
    End If
End Sub

'-------------------------------------------------------------------------
' PaletteManage Procs
'-------------------------------------------------------------------------
'
'/* palette related msgs's:
'    - WM_ACTIVATE:
'        The WM_ACTIVATE message is sent when a window is being activated or
'        deactivated. This message is sent first to the window procedure of
'        the top-level window being deactivated; it is then sent to the
'        window procedure of the top-level window being activated.
'
'    - WM_QUERYNEWPALETTE:
'        The WM_QUERYNEWPALETTE message informs a window that it is about
'        to receive the keyboard focus, giving the window the opportunity
'        to realize its logical palette when it receives the focus.
'
'        If the window realizes its logical palette, it must return TRUE;
'        otherwise, it must return FALSE.
'
'    - WM_PALETTECHANGED:
'        The WM_PALETTECHANGED message is sent to all top-level and overlapped
'        windows after the window with the keyboard focus has realized its
'        logical palette, thereby changing the system palette. This message
'        enables a window that uses a color palette but does not have the
'        keyboard focus to realize its logical palette and update its client
'        area.
'
'        This message must be sent to all top-level and overlapped windows,
'        including the one that changed the system palette. If any child
'        windows use a color palette, this message must be passed on to them
'        as well.
'        To avoid creating an infinite loop, a window that receives this
'        message must not realize its palette, unless it determines that
'        wParam does not contain its own window handle.
'
'    - WM_SYSCOLORCHANGE:
'        The WM_SYSCOLORCHANGE message is sent to all top-level windows when
'        a change is made to a system color setting.
'
Friend Function PaletteProc(ByVal hWnd As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
Dim r&
    Debug.Assert m_hWnd = hWnd
    Select Case msg
    Case WM_QUERYNEWPALETTE
        If m_hPal Then
        If SelectPalette(UC.hDC, m_hPal, False) Then
            RealizePalette UC.hDC
            PaletteProc = 1
            'this could be a problem for a single buffer app
            InvalidateRectBynum UC.hWnd, 0, 0
        End If
        End If
    Case WM_PALETTECHANGED
        If m_hPal And wParam <> UC.hWnd Then
        If SelectPalette(UC.hDC, m_hPal, False) Then
            RealizePalette (UC.hDC)
            UpdateColors UC.hDC
        End If
        End If
        PaletteProc = 0 '
    Case WM_SYSCOLORCHANGE
        ReCreateRGBPalette
    Case Else
        PaletteProc = CallWindowProc(m_OldProc, hWnd, msg, wParam, ByVal lParam)
    End Select
End Function
'#End If

'-------------------------------------------------------------------------
'MakeRGBPalette
'Creates an HPALETTE with values required for a logical rgb palette.
'If bUseStatic is TRUE, the static system
'colors will be overridden.  Otherwise, the PALETTEENTRY array will be
'fixed up to contain the default static system colors.
'-------------------------------------------------------------------------
Private Function m_MakeRGBPalette&()
Dim pPal As LOGPALETTE
Dim hPal&, count&, i&
On Error GoTo EH
    If gPFD.cColorBits >= 24 Then
        i = 24
    Else
        count = 2 ^ gPFD.cColorBits
    End If
    '''''
    'using index mode on 24 bit
    If count > 256 Then count = 256
    '''''
    nEntries = count
    pPal.palVersion = &H300
    pPal.palNumEntries = count
    With gPFD
    'only 256 color palettes are supported, so these routines are essentially
    'the same
    If m_bForce Then
        For i = 0 To count - 1
            pPal.palPalEntry(i).peRed = m_ComponentFromIndex(i, 3, _
                                    .cRedShift)
            pPal.palPalEntry(i).peGreen = m_ComponentFromIndex(i, 3, _
                                    .cGreenShift)
            pPal.palPalEntry(i).peBlue = m_ComponentFromIndex(i, 2, _
                                    .cBlueShift)
            pPal.palPalEntry(i).peFlags = PC_NOCOLLAPSE
        Next
    Else
        For i = 0 To count - 1
            pPal.palPalEntry(i).peRed = m_ComponentFromIndex(i, .cRedBits, _
                                    .cRedShift)
            pPal.palPalEntry(i).peGreen = m_ComponentFromIndex(i, .cGreenBits, _
                                    .cGreenShift)
            pPal.palPalEntry(i).peBlue = m_ComponentFromIndex(i, .cBlueBits, _
                                    .cBlueShift)
            pPal.palPalEntry(i).peFlags = PC_NOCOLLAPSE
        Next
    End If
    If (count = 256) Then
        ' The defaultOverride array is computed assuming a 332
        ' palette where red has zero shift, etc.

            If ((3 = .cRedBits) And (0 = .cRedShift) And _
                 (3 = .cGreenBits) And (3 = .cGreenShift) And _
                 (2 = .cBlueBits) And (6 = .cBlueShift)) Then
                'pEntry = pPal.palPalEntry
                m_UpdateStaticMapping pPal.palPalEntry
                For i = 0 To STATIC_COLORS - 1
                    pPal.palPalEntry(aiDefaultOverride(i)) = apeDefaultPalEntry(i)
                Next
            End If
    End If
    End With
    hPal = CreatePalette(pPal)
    m_MakeRGBPalette = hPal
    Exit Function
EH:
    Debug.Assert 0
    
End Function

'-------------------------------------------------------------------------
' Conversion tables for n bits to eight bits
'-------------------------------------------------------------------------
Private Function m_ComponentFromIndex(i&, nbits As Byte, shift As Byte) As Byte
Dim val As Byte
    If Not (nbits >= 1 And nbits <= 3) Then
        Debug.Assert 0
        Exit Function
    End If
    val = i \ (2 ^ shift)
    Select Case (nbits)
    Case 1:
        m_ComponentFromIndex = abOneToEight(val And 1)
    Case 2:
        m_ComponentFromIndex = abTwoToEight(val And 3)
    Case 3:
        m_ComponentFromIndex = abThreeToEight(val And 7)
    End Select
End Function

'-------------------------------------------------------------------------
'm_UpdateStaticMapping
'Computes the best match between the current system static colors
'and a 3-3-2 palette
'History:
' Tue Aug 01 18:18:12 1995 -by-    Drew Bliss (drewb)
'-------------------------------------------------------------------------
Private Sub m_UpdateStaticMapping(pe332Palette() As PALETTEENTRY)
Dim hpalStock&, i&, j&, tmp&
Dim iMinDist&, iDist&, iDelta&
Dim iMinEntry&
    hpalStock = GetStockObject(DEFAULT_PALETTE)
    ' The system should always have one of these
    If hpalStock = 0 Then Debug.Assert 0
    ' Make sure there's the correct number of entries
    j = hpalStock
    i = GetPaletteEntriesCount(hpalStock, 0, STATIC_COLORS, 0&)
    If i <> STATIC_COLORS Then Debug.Assert 0
    'just reread it:
    hpalStock = GetStockObject(DEFAULT_PALETTE)
    ' Get the current static colors
    i = GetPaletteEntries(hpalStock, 0, 20, apeDefaultPalEntry(0))
    If i = 0 Then Debug.Assert 0
    ' Zero the flags in the static colors because they are used later
    For i = 0 To STATIC_COLORS - 1
        apeDefaultPalEntry(i).peFlags = 0
    Next
    ' Zero the flags in the incoming palette because they are used later
    For i = 0 To 255
        pe332Palette(i).peFlags = 0
    Next
    ' Try to match each static color exactly
    ' This saves time by avoiding the least-squares match for each
    ' exact match
    For i = 0 To STATIC_COLORS - 1
        For j = 0 To 255
            If (apeDefaultPalEntry(i).peRed = pe332Palette(j).peRed And _
                apeDefaultPalEntry(i).peGreen = pe332Palette(j).peGreen And _
                apeDefaultPalEntry(i).peBlue = pe332Palette(j).peBlue) Then
                    If (pe332Palette(j).peFlags = COLOR_USED) Then
                        Debug.Assert 0
                    End If
                    apeDefaultPalEntry(i).peFlags = EXACT_MATCH
                    pe332Palette(j).peFlags = COLOR_USED
                    aiDefaultOverride(i) = j
                    Exit For
            End If
        Next
    Next

    ' Match each static color as closely as possible to an entry
    ' in the 332 palette by minimized the square of the distance
    For i = 0 To STATIC_COLORS - 1
        ' Skip colors already matched exactly
        If (apeDefaultPalEntry(i).peFlags = EXACT_MATCH) Then
            GoTo icont
        End If
        iMinDist = MAX_COL_DIST + 1
        'If DBG Then
        iMinEntry = -1
        'End If
        For j = 0 To 255
            ' Skip colors already used
            If (pe332Palette(j).peFlags = COLOR_USED) Then
                GoTo jcont
            End If

            ' Compute Euclidean distance squared
            '!!!VB can't subtract 2 bytes without overflow!!!
            tmp = pe332Palette(j).peRed
            iDelta = tmp - apeDefaultPalEntry(i).peRed
            iDist = iDelta * iDelta
            tmp = pe332Palette(j).peGreen
            iDelta = tmp - apeDefaultPalEntry(i).peGreen
            iDist = iDist + iDelta * iDelta
            tmp = pe332Palette(j).peBlue
            iDelta = tmp - apeDefaultPalEntry(i).peBlue
            iDist = iDist + iDelta * iDelta

            If (iDist < iMinDist) Then
                iMinDist = iDist
                iMinEntry = j
            End If
jcont:
        Next

        If iMinEntry = -1 Then
            Debug.Assert 0
            iMinEntry = 0
        End If

        ' Remember the best match
        aiDefaultOverride(i) = iMinEntry
        pe332Palette(iMinEntry).peFlags = COLOR_USED
icont:
    Next

    ' Zero the flags in the static colors because they may have been
    ' set.  We want them to be zero so the colors can be remapped
    For i = 0 To STATIC_COLORS - 1
        apeDefaultPalEntry(i).peFlags = 0
    Next

    ' Reset the 332 flags because we may have set them
    For j = 0 To 255
        pe332Palette(j).peFlags = PC_NOCOLLAPSE
    Next
End Sub

'-------------------------------------------------------------------------
'FlushPalette
'Because of Win 3.1 compatibility, GDI palette mapping always starts
'at zero and stops at the first exact match.  So if there are duplicates,
'the higher colors aren't mapped to--which is often a problem if we
'are trying to make to any of the upper 10 static colors.  To work around
'this, we flush the palette to all black.
'-------------------------------------------------------------------------
Private Sub m_Flush()
Dim pPal As LOGPALETTE
Dim hpalBlack&, hpalOld&, i&
    If (nEntries = 256) Then
            pPal.palVersion = &H300
            pPal.palNumEntries = nEntries

            ' Mark everything PC_NOCOLLAPSE and PC_RESERVED to force every
            ' thing into the palette.  Colors are already black because
            ' we zero initialized during memory allocation.
            For i = 0 To nEntries - 1
                pPal.palPalEntry(i).peFlags = PC_NOCOLLAPSE Or PC_RESERVED
            Next
            hpalBlack = CreatePalette(pPal)

            hpalOld = SelectPalette(UC.hDC, hpalBlack, False)
            RealizePalette (UC.hDC)

            SelectPalette UC.hDC, hpalOld, False
            DeleteObject hpalBlack
    End If
End Sub

Private Function m_Realize&() 'bForceBackground As Boolean)
Dim Result&
Dim bHaveSysPal As Boolean
bHaveSysPal = True
Result& = -1
        If SelectPalette(UC.hDC, m_hPal, False) Then
            Result = RealizePalette(UC.hDC)
        End If
    m_Realize = Result
End Function


'-------------------------------------------------------------------------
'ReCreateRGBPalette
'-------------------------------------------------------------------------
Friend Sub ReCreateRGBPalette()
Dim hPalTmp&
'    If (bTakeOver) Then
'        Exit Sub
'    End If
    hPalTmp = m_hPal
    m_hPal = m_MakeRGBPalette()
    If (m_hPal) Then
        DeleteObject (hPalTmp)
        m_bFlush = True
    '???
    Else: m_hPal = hPalTmp
    End If
End Sub

Private Sub m_SetPEntry(pe As PALETTEENTRY, r, g, B, Optional A = 0)
pe.peRed = r
pe.peGreen = g
pe.peBlue = B
pe.peFlags = A
End Sub

Friend Sub SetHook()
Debug.Print "BEFORE SetHook", m_hWnd, m_OldProc
    ReleaseHook
    m_hWnd = UC.hWnd
    m_OldProc = SetWindowLong(m_hWnd, GWL_WNDPROC, AddressOf WndProc)
Debug.Print "SetHook hwnd=" & m_hWnd & " m_OldProc=" & m_OldProc
End Sub


Friend Sub ReleaseHook()
    If m_OldProc Then
        SetWindowLong m_hWnd, GWL_WNDPROC, m_OldProc
        m_OldProc = 0
    End If
End Sub


Friend Sub AddMsg(msg&)

End Sub

Friend Function RemoveMsg(Index&, msg&)

End Function


