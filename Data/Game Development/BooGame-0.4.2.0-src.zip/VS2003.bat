@rem Generates a solution (.sln) and a set of project files (.csproj) 
@rem for Microsoft Visual Studio .NET 2003
.\tools\Prebuild\Prebuild.exe /target vs2003 /file Prebuild.xml
