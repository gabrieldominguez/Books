VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3dAttrContext"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'FUNCTION:
'   has a bug in the motion
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'
'-----------------------------------------------------------------
Dim m_RotMinX! ' As POINT3F       ' min rotation amplitude
Dim m_RotMinY! '
Dim m_RotMinZ! '
Dim m_RotMaxX! ' As POINT3F          ' max rotation amplitude
Dim m_RotMaxY! '
Dim m_RotMaxZ! '
Dim m_RotLimitX! ' As POINT3F        ' current rotation amplitude
Dim m_RotLimitY!
Dim m_RotLimitZ! '
Dim m_CurRotX! ' As POINT3F      ' current rotation
Dim m_CurRotY! '
Dim m_CurRotZ! '
'internal attributes
Dim m_RotMinStep&   ' min rotation step
Dim m_RotMaxStep&   ' max rotation step
'
Dim m_RotStep&      ' rotation step from slider
Dim m_RotStepX& ' As POINT3I ' xyz rot step, for random rotation
Dim m_RotStepY& '
Dim m_RotStepZ& '
'
Dim m_RotiX& ' As POINT3I  ' current xyz rot step iteration
Dim m_RotiY& '
Dim m_RotiZ& '
'
Dim m_Trig(360) As POINTFLOAT   ' pre-calculated table of sines and cosines
Dim m_SawTooth(360) As POINTFLOAT  ' sawtooth table
Dim m_InvTrig(360) As POINTFLOAT   ' pseudo-inverse trig table
Dim m_TrigDif(360) As POINTAPI    ' table for converting trig.invtrig
Dim m_InvTrigDif(360) As POINTAPI    ' table for converting invtrig.trig
'
Dim m_bXMajor As Boolean                ' string either x-major or y-major
Dim m_RotationStyle As SSRotationStyles
'Dim m_NextRotationProc As NextRotationProcConstants


Private Sub Class_Initialize()
m_InitTrigTable
End Sub

Private Sub Class_Terminate()
'
End Sub

Public Property Get XMajor() As Boolean
XMajor = m_bXMajor
End Property

Public Property Let XMajor(ByVal NewValue As Boolean)
m_bXMajor = NewValue
End Property

Public Property Get RotationStyle() As SSRotationStyles
RotationStyle = m_RotationStyle
End Property

Public Property Get RotMaxX!()
RotMaxX = m_RotMaxX
End Property

Public Property Get RotMaxY!()
RotMaxY = m_RotMaxY
End Property

Public Property Get RotMaxZ!()
RotMaxZ = m_RotMaxZ
End Property

Public Property Let RotationStyle(ByVal NewValue As SSRotationStyles)
Dim StepRange&
Dim numRots&
    StepRange& = 2 ' default step range
    m_RotationStyle = NewValue
    ' Set the MAXIMUM rotation limits.  This is required initially, in
    ' * order to set the bounding box
    Select Case m_RotationStyle
        Case ROTSTYLE_NONE:
            'm_NextRotationProc = procNone
        Case ROTSTYLE_SEESAW:
            ' rotate minor axis
            If optDemoType = DEMO_VSTRING Then
                ' always rotate around y-axis
                'axis = Y_AXIS
                m_RotMinY = FMIN_SEESAW_ANGLE
                m_RotMaxY = FMAX_SEESAW_ANGLE
            Else
                'axis = IIf(.bXMajor, Y_AXIS, X_AXIS)
                If m_bXMajor Then
                    'axis = Y_AXIS
                    m_RotMinY = FMIN_SEESAW_ANGLE
                    m_RotMaxY = FMAX_SEESAW_ANGLE
                Else
                    'axis = X_AXIS
                    m_RotMinX = FMIN_SEESAW_ANGLE
                    m_RotMaxX = FMAX_SEESAW_ANGLE
                End If
            End If
        Case ROTSTYLE_WOBBLE:
            'm_NextRotationProc = procWobble
            If optDemoType = DEMO_VSTRING Then
                'axis = Y_AXIS
                m_RotMinY = FMIN_WOBBLE_ANGLE2
                m_RotMaxY = FMAX_WOBBLE_ANGLE2
            Else
                StepRange = 1
                'axis = IIf(.bXMajor, Y_AXIS, X_AXIS)
                If m_bXMajor Then
                    m_RotMinY = FMIN_WOBBLE_ANGLE2
                    m_RotMaxY = FMAX_WOBBLE_ANGLE2
                Else
                    m_RotMinX = FMIN_WOBBLE_ANGLE2
                    m_RotMaxX = FMAX_WOBBLE_ANGLE2
                End If
            End If
            m_RotMinZ = FMAX_WOBBLE_ANGLE
            m_RotMaxZ = FMAX_WOBBLE_ANGLE
        Case ROTSTYLE_RANDOM:
            ' adjust stepRange based on speed
            StepRange = MapValueI(CLng(optSpeed), _
                               MIN_SLIDER, (MAX_SLIDER - MIN_SLIDER) / 2, _
                               2, 6)  ' step range
            'For axis = X_AXIS To NUM_AXIS - 1
                m_RotMinX = FMIN_RANDOM_ANGLE
                m_RotMaxX = FMAX_RANDOM_ANGLE
                m_RotMinY = FMIN_RANDOM_ANGLE
                m_RotMaxY = FMAX_RANDOM_ANGLE
                m_RotMinZ = FMIN_RANDOM_ANGLE
                m_RotMaxZ = FMAX_RANDOM_ANGLE
            'Next
    End Select
    ' convert the slider speed values to rotation steps, with
    ' * a steeper slope at the beginning of the scale
    m_RotStep = MapValueI(CLng(optSpeed), _
                               MIN_SLIDER, MAX_SLIDER, _
                               MIN_ROT_STEP, MAX_ROT_STEP)  ' step range
    ' set min and max steps
    m_RotMinStep = IIf(m_RotStep >= (MIN_ROT_STEP + StepRange), _
              m_RotStep - StepRange, MIN_ROT_STEP)
    m_RotMaxStep = m_RotStep + StepRange ' don't limit upper end
    '
    m_RotStepX = IIf(m_RotMaxX <> 0, _
            gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep), 0)
    m_RotStepY = IIf(m_RotMaxY <> 0, _
            gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep), 0)
    m_RotStepZ = IIf(m_RotMaxZ <> 0, _
            gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep), 0)
    ' set the current rotation limits
    m_RotLimitX = m_RotMaxX
    m_RotLimitY = m_RotMaxY
    m_RotLimitZ = m_RotMaxZ
    ResetRotationLimits 1, 1, 1
    'For axis = X_AXIS To NUM_AXIS - 1
        If m_RotMaxX <> 0 Then
            numRots = numRots + 1
        End If
        If m_RotMaxY <> 0 Then
            numRots = numRots + 1
        End If
        If m_RotMaxZ <> 0 Then
            numRots = numRots + 1
        End If
    'Next
    ' set m_BoundingBoxProc dependent on which axis are being rotated
    If numRots <= 1 Then
        gBB.BoundingBoxProc = procCalcBoundingBox
    Else
        gBB.BoundingBoxProc = procCalcBoundingBoxGeneric
    End If
End Property


'*************************************************************************/
'* ResetRotationLimits
'* Reset the maximum axis rotations.  So there won't be too much of a 'jump'
'* when altering the rotation, this routine should only be called when the
'* rotation of the specified axis is at zero amplitude.
'* Also, change the rotation table if applicable.  This affects how the
'* rotation 'steps' around the axis.
'*************************************************************************/
Public Sub ResetRotationLimits(X&, Y&, Z&)
Static oldTrig As TrigTableToUse
Dim newTrig As TrigTableToUse
Dim i&
    'change rotation limits
        If (m_RotMaxX And X) Then
            m_RotLimitX = gCtl.Ex.RandomSng(m_RotMinX, m_RotMaxX)
            ' grossly modify amplitute sometimes for random
            If (optRotationStyle = ROTSTYLE_RANDOM) Then
                If (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitX = gCtl.Ex.RandomSng(0, 10)
                ElseIf (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitX = gCtl.Ex.RandomSng(90, 135)
                End If
            End If
        End If
        If (m_RotMaxY And Y) Then
            m_RotLimitY = gCtl.Ex.RandomSng(m_RotMinY, m_RotMaxY)
            ' grossly modify amplitute sometimes for random
            If (optRotationStyle = ROTSTYLE_RANDOM) Then
                If (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitY = gCtl.Ex.RandomSng(0, 10)
                ElseIf (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitY = gCtl.Ex.RandomSng(90, 135)
                End If
            End If
        End If
        If (m_RotMaxZ And Z) Then
            m_RotLimitZ = gCtl.Ex.RandomSng(m_RotMinZ, m_RotMaxZ)
            ' grossly modify amplitute sometimes for random
            If (optRotationStyle = ROTSTYLE_RANDOM) Then
                If (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitZ = gCtl.Ex.RandomSng(0, 10)
                ElseIf (gCtl.Ex.RandomInt(10) = 2) Then
                    m_RotLimitZ = gCtl.Ex.RandomSng(90, 135)
                End If
            End If
        End If
    '
    ' change rotation table
    ' use i to set a frequency for choosing m_InvTrig table
    i = 10
    'oldTrig = gAC.pTrig
    Select Case optRotationStyle
        Case ROTSTYLE_RANDOM:
            If optDemoType = DEMO_VSTRING Then
                i = 7
            ' fall thru...
                GoTo cont
            End If
        Case ROTSTYLE_SEESAW:
cont:
            ' Use InvTrig table every now and then
            If (gCtl.Ex.RandomInt(i) = 2) Then
                newTrig = trigInv
            Else
                newTrig = trigNormal
            End If
        Case Else: 'default:
            ' Always use regular trig table
            newTrig = trigNormal
    End Select
    ' if trig table changed, need to adjust steps of non-zero axis rotations
    ' (otherwise get 'twitch' in rotation)
    If newTrig <> oldTrig Then
        ' only deal with axis which didn't have amplitudes modified
        'For i = 0 To 2 'NUM_AXIS - 1
        '    reset(i) = Not reset(i)
        'Next
        X = IIf(X, 0, 1)
        Y = IIf(Y, 0, 1)
        Z = IIf(Z, 0, 1)
        m_AdjustRotationStep X, Y, Z, oldTrig
        oldTrig = newTrig
    End If
End Sub

'*************************************************************************\
'* AdjustRotationStep
'* If trig table is changed in ResetRotationLimits, then axis with non-zero
'* rotations will appear to jump.  This routine modifies the current step
'* so this will not be apparent.
'*************************************************************************/
Private Sub m_AdjustRotationStep(X&, Y&, Z&, oldTrig As TrigTableToUse)
    If optDemoType = DEMO_VSTRING Then
        ' for now doesn't matter, string is invisible at this point
        Exit Sub
    End If
    ' choose diff table to use for modifying step
    If oldTrig = trigNormal Then
        oldTrig = trigInv
    Else: oldTrig = trigNormal
    End If
    
    '
        If m_RotMaxX And X Then
            If oldTrig Then
                m_RotiX = m_RotiX + m_InvTrigDif(m_RotiX).X
            Else
                m_RotiX = m_RotiX + m_TrigDif(m_RotiX).X
            End If
            ' check for wrap or out of bounds
            If (m_RotiX >= 360) Or (m_RotiX < 0) Then
                m_RotiX = 0
            End If
        End If
        If m_RotMaxY And Y Then
            If oldTrig Then
                m_RotiY = m_RotiY + m_InvTrigDif(m_RotiY).X
            Else
                m_RotiY = m_RotiY + m_TrigDif(m_RotiY).X
            End If
            ' check for wrap or out of bounds
            If (m_RotiY >= 360) Or (m_RotiY < 0) Then
                m_RotiY = 0
            End If
        End If
        If m_RotMaxZ And Z Then
            If oldTrig Then
                m_RotiZ = m_RotiZ + m_InvTrigDif(m_RotiZ).Y
            Else
                m_RotiZ = m_RotiZ + m_TrigDif(m_RotiZ).Y
            End If
            ' check for wrap or out of bounds
            If (m_RotiZ >= 360) Or (m_RotiZ < 0) Then
                m_RotiZ = 0
            End If
        End If
End Sub

'*************************************************************************\
'* InitTrigTable
'* Initialize trig look-up tables
'*************************************************************************/
Private Sub m_InitTrigTable()
Dim i&, num&
Dim angle!, newStep&
Dim inc!
num = 360
inc = (2 * PI) / num ' 360 degree range
    ' calc standard trig table
    For i = 0 To num - 1
        m_Trig(i).X = Cos(angle)
        m_Trig(i).Y = Sin(angle)
        angle = angle + inc
    Next
    ' Calc sawtooth and pseudo-inverse trig table, as well as a diff
    ' table to convert between trig and invTrig.
    ' do y, or sin values first
    For i = 0 To 90
        m_SawTooth(i).Y = i / 90
        m_InvTrig(i).Y = 2 * m_SawTooth(i).Y - m_Trig(i).Y
    Next
    ' Create tables to convert trig steps to invTrig steps, and vice-versa
    For i = 0 To 90
        newStep = m_FindInvStep(i)
        m_TrigDif(i).Y = newStep - i
        newStep = m_FindStep(i)
        m_InvTrigDif(i).Y = newStep - i ' -
    Next
    ' reflect 0-90 to get 90-180
    For i = 1 To 90
        m_SawTooth(90 + i).Y = m_SawTooth(90 - i).Y
        m_InvTrig(90 + i).Y = m_InvTrig(90 - i).Y
        m_TrigDif(90 + i).Y = -m_TrigDif(90 - i).Y
        m_InvTrigDif(90 + i).Y = -m_InvTrigDif(90 - i).Y
    Next
    ' invert 0-180 to get 180-360
    For i = 1 To 180
        m_SawTooth(180 + i).Y = -m_SawTooth(i).Y
        m_InvTrig(180 + i).Y = -m_InvTrig(i).Y
        m_TrigDif(180 + i).Y = m_TrigDif(i).Y
        m_InvTrigDif(180 + i).Y = m_InvTrigDif(i).Y
    Next

    ' calc x, or cos, by phase-shifting y
    For i = 0 To 270 - 1
        m_SawTooth(i).X = m_SawTooth(i + 90).Y
        m_InvTrig(i).X = m_InvTrig(i + 90).Y
        m_TrigDif(i).X = m_TrigDif(i + 90).Y
        m_InvTrigDif(i).X = m_InvTrigDif(i + 90).Y
    Next
    For i = 0 To 90 - 1
        m_SawTooth(i + 270).X = m_SawTooth(i).Y
        m_InvTrig(i + 270).X = m_InvTrig(i).Y
        m_TrigDif(i + 270).X = m_TrigDif(i).Y
        m_InvTrigDif(i + 270).X = m_InvTrigDif(i).Y
    Next
End Sub

'*************************************************************************\
'* FindInvStep
'* Finds step in invTrig table with same value as trig table at i
'*************************************************************************
Private Function m_FindInvStep&(ByVal i&)
Dim v!, diff!, minDiff!
Dim invStep&
invStep = i
    v = m_Trig(i).Y
    invStep = i
    minDiff = v - m_InvTrig(i).Y
    Do
        i = i + 1
        If i > 90 Then Exit Do
        diff = v - m_InvTrig(i).Y
        If (Abs(diff) < minDiff) Then
            minDiff = Abs(diff)
            invStep = i
        End If
        If (diff < 0) Then
            Exit Do
        End If
    Loop
    m_FindInvStep = invStep
End Function

Public Sub Rotate()
Select Case m_RotationStyle
Case ROTSTYLE_SEESAW, ROTSTYLE_RANDOM: m_RotRandom
Case ROTSTYLE_WOBBLE: m_RotWobble
End Select
If (m_RotMaxZ <> 0) Then
    glRotatef m_CurRotZ, 0, 0, 1
End If
If (m_RotMaxY <> 0) Then
    glRotatef m_CurRotY, 0, 1, 0
End If
If (m_RotMaxX <> 0) Then
    glRotatef m_CurRotX, 1, 0, 0
End If
End Sub

'*************************************************************************\
'* GetNextRotWobble
'*   Calculate next rotation.
'*   - 'step' controls amount of rotation
'*   - rotation values are scaled from -1 to 1 (trig values), and  inscribe
'*     circle with r=1 in the zy plane for the ends of the string
'*   - steps for both minor and major rotation axis remain in sync
''*************************************************************************/
Private Sub m_RotWobble()
'Dim step&
'Dim rotStep&
Dim RotMaxX!, RotMaxY!, RotMaxZ!
Dim resetPoint&(0 To 2)
Dim resetX&, resetY&, resetZ& ' which axis to be reset
'
'step = .m_RotiX ' use step.x
'rotStep = .m_RotStepZ
RotMaxX! = m_RotMaxX
RotMaxY! = m_RotMaxY
RotMaxZ! = m_RotMaxZ
resetPoint(0) = 90: resetPoint(1) = 90: resetPoint(2) = 0 ' 0 amplitude points
    m_CurRotZ = m_RotLimitZ * m_Trig(m_RotiX).Y   ' sin
    m_CurRotY = m_RotLimitY * m_Trig(m_RotiX).X   ' cos
    m_CurRotX = m_RotLimitX * m_Trig(m_RotiX).X    ' cos
    ' check for 0 amplitude point for non-vstrings
    'For axis = X_AXIS To NUM_AXIS - 1
        If RotMaxX <> 0 Then
            If optDemoType <> DEMO_VSTRING And m_RotiX = resetPoint(0) Then
                resetX = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetX = 0
            End If
        End If
        If RotMaxY <> 0 Then
            If optDemoType <> DEMO_VSTRING And m_RotiX = resetPoint(1) Then
                resetY = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetY = 0
            End If
        End If
        If RotMaxZ <> 0 Then
            If optDemoType <> DEMO_VSTRING And m_RotiX = resetPoint(2) Then
                resetZ = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetZ = 0
            End If
        End If
   ' Next

    ' increment step
    m_RotiX = m_RotiX + m_RotStepZ
    If m_RotiX >= 360 Then
        ' make the step variable
        m_RotStepZ = gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep)
        ' start step at variable index
        m_RotiX = gCtl.Ex.RandomInt(m_RotStepZ)
    End If
End Sub

'*************************************************************************\
' GetNextRotRandom
'* Same as above, but steps for each axis are not kept in sync
'*************************************************************************/
Private Sub m_RotRandom()
Dim resetPoint&(0 To 2) ' 0 amplitude points
Dim resetX&, resetY&, resetZ& ' which axis to be reset
resetPoint(0) = 90: resetPoint(1) = 90: resetPoint(2) = 0 ' 0 amplitude points
    ' set new rotation
    m_CurRotZ = m_RotLimitZ * m_Trig(m_RotiZ).Y    ' sin
    m_CurRotY = m_RotLimitY * m_Trig(m_RotiY).X   ' cos
    m_CurRotX = m_RotLimitX * m_Trig(m_RotiX).X   ' cos

    ' for each rotation axis...
    'for( axis = X_AXIS; axis < NUM_AXIS; axis++ ) {
        If m_RotMaxX <> 0 Then
            ' check for 0 amplitude point for non-vstrings
            If optDemoType <> DEMO_VSTRING And (m_RotiX = resetPoint(0)) Then
                resetX = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetX = 0
            End If
            ' increment rotation step and check for end of cycle
            m_RotiX = m_RotiX + m_RotStepX
            If m_RotiX >= 360 Then
                ' make the step variable
                m_RotiX = gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep)
                ' start step at variable index
                m_RotiX = gCtl.Ex.RandomInt(m_RotiX)
            End If
        End If
        If m_RotMaxY <> 0 Then
            ' check for 0 amplitude point for non-vstrings
            If optDemoType <> DEMO_VSTRING And (m_RotiY = resetPoint(1)) Then
                resetY = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetY = 0
            End If
            ' increment rotation step and check for end of cycle
            m_RotiY = m_RotiY + m_RotStepY
            If m_RotiY >= 360 Then
                ' make the step variable
                m_RotiY = gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep)
                ' start step at variable index
                m_RotiY = gCtl.Ex.RandomInt(m_RotiY)
            End If
        End If
        If m_RotMaxZ <> 0 Then
            ' check for 0 amplitude point for non-vstrings
            If optDemoType <> DEMO_VSTRING And (m_RotiZ = resetPoint(2)) Then
                resetZ = 1
                ResetRotationLimits resetX, resetY, resetZ
                resetZ = 0
            End If
            ' increment rotation step and check for end of cycle
            m_RotiZ = m_RotiZ + m_RotStepZ
            If m_RotiZ >= 360 Then
                ' make the step variable
                m_RotiZ = gCtl.Ex.RandomIntInRange(m_RotMinStep, m_RotMaxStep)
                ' start step at variable index
                m_RotiZ = gCtl.Ex.RandomInt(m_RotiZ)
            End If
        End If
End Sub

'*************************************************************************\
'* FindStep
'* Finds step in trig table with same value as invTrig table at i
'called during initialization
'*************************************************************************/
Private Function m_FindStep&(ByVal i&)
Dim v!, diff!, minDiff!
Dim step&
    step = i
    v = m_InvTrig(i).Y
    minDiff = m_Trig(i).Y - v
    Do
        i = i - 1
        If i < 0 Then Exit Do
        diff = v - m_Trig(i).Y
        If (Abs(diff) < minDiff) Then
            minDiff = Abs(diff)
            step = i
        End If
        If (diff > 0) Then
            Exit Do
        End If
    Loop
    m_FindStep = step
End Function



