/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using Tao.FreeGlut;

namespace BooGame
{
    /// <summary>
    /// Module to control the joystick.
    /// </summary>
    /// <remarks>Joystick.Enabled has to be set to True before being able to use the joystick.</remarks>
    public class Joystick
    {
        static Joystick()
        {
            Core.Initialize();
        }

        internal static void Initialize()
        {
        }

        private static int m_ButtonMask = 0;
        private static int m_X = 0;
        private static int m_Y = 0;
        private static int m_Z = 0;
        private static bool m_Enabled = false;

        /// <summary>
        /// Gets the current state of the joystick's X axis.
        /// </summary>
        public static int X
        {
            get { return m_X; }
        }

        /// <summary>
        /// Gets the current state of the joystick's Y axis.
        /// </summary>
        public static int Y
        {
            get { return m_Y; }
        }

        /// <summary>
        /// Gets the current state of the joystick's Z axis.
        /// </summary>
        public static int Z
        {
            get { return m_Z; }
        }

        /// <summary>
        /// Gets or sets whether the joystick is to be polled.
        /// </summary>
        public static bool Enabled
        {
            get
            {
                return m_Enabled;
            }
            set
            {
                if (value)
                {
                    if (!m_Enabled)
                    {
                        Glut.glutJoystickFunc(new Glut.JoystickCallback(JoystickCallback), 15); // 15 is the poll interval in milliseconds
                        Update();
                        m_Enabled = true;
                    }
                }
                else
                {
                    if (m_Enabled)
                    {
                        Glut.glutJoystickFunc(null, -1);
                        m_Enabled = false;
                    }
                }
            }
        }

        /// <summary>
        /// Gets the current bit-wise button mask of all currently pushed joystick buttons.
        /// </summary>
        public static JoystickButtons ButtonMask
        {
            get
            {
                return (JoystickButtons)m_ButtonMask;
            }
        }

        /// <summary>
        /// Gets whether the given button is currently pushed down.
        /// </summary>
        /// <param name="button">The joystick button to check.</param>
        /// <returns>True if it's being pushed, false otherwise.</returns>
        public static bool IsButtonDown(JoystickButtons button)
        {
            return (m_ButtonMask & (int)button) != 0;
        }

        private static void JoystickCallback(int buttonMask, int x, int y, int z)
        {
            if (buttonMask != m_ButtonMask)
            {
                // Get which button states have been changed
                int buttonsChanged = buttonMask ^ m_ButtonMask;
                for (int i = 1; i <= 32768; i *= 2)
                {
                    if ((buttonsChanged & i) == i) // Check if there was a state change
                    {
                        if ((buttonMask & i) == i) // Check if the button was pressed or un-pressed
                        {
                            JoystickEventArgs args = new JoystickEventArgs(i, m_X, m_Y, m_Z, true);
                            Core.Game.JoystickButtonDown(args);
                            Core.Game.Gui.OnJoystickButtonDown(args);
                            if (ButtonDown != null)
                                ButtonDown(null, args);
                        }
                        else
                        {
                            JoystickEventArgs args = new JoystickEventArgs(i, m_X, m_Y, m_Z, false);
                            Core.Game.JoystickButtonUp(args);
                            Core.Game.Gui.OnJoystickButtonUp(args);
                            if (ButtonUp != null)
                                ButtonUp(null, args);
                        }
                    }
                }
                m_ButtonMask = buttonMask;
            }

            // Check for axis change
            bool changed = false;
            if (m_X != x)
            {
                m_X = x;
                changed = true;
            }
            if (m_Y != y)
            {
                m_Y = y;
                changed = true;
            }
            if (m_Z != z)
            {
                m_Z = z;
                changed = true;
            }
            if (changed)
            {
                JoystickEventArgs args = new JoystickEventArgs(m_ButtonMask, m_X, m_Y, m_Z, false);
                Core.Game.JoystickAxisMovement(args);
                Core.Game.Gui.OnJoystickAxisMovement(args);
                if (AxisMovement != null)
                    AxisMovement(null, args);
            }
        }

        /// <summary>
        /// Called when the axis states of the joystick change location.
        /// </summary>
        public static event JoystickEventHandler AxisMovement;
        /// <summary>
        /// Called when a button is pushed on the joystick.
        /// </summary>
        public static event JoystickEventHandler ButtonDown;
        /// <summary>
        /// Called when a button is released on the joystick.
        /// </summary>
        public static event JoystickEventHandler ButtonUp;

        /// <summary>
        /// Forces a Joystick update.
        /// </summary>
        /// <remarks>Note that you don't need to call this as BooGame manages it for you.</remarks>
        public static void Update()
        {
            Glut.glutForceJoystickFunc();
        }

        /// <summary>
        /// Gets whether or not a joystick device exists.
        /// </summary>
        public static bool Exists
        {
            get
            {
                return Glut.glutDeviceGet(Glut.GLUT_HAS_JOYSTICK) != 0;
            }
        }
    }

    /// <summary>
    /// Used to describe a joystick event.
    /// </summary>
    /// <param name="sender">The object that sent the event.</param>
    /// <param name="args">The arguments associated with the joystick.</param>
    public delegate void JoystickEventHandler(object sender, JoystickEventArgs args);

    /// <summary>
    /// These event arguments are passed when a joystick event occurs.
    /// </summary>
    public class JoystickEventArgs : EventArgs
    {
        /// <summary>
        /// Creates the joystick event arguments.
        /// </summary>
        public JoystickEventArgs()
        {
        }
        public JoystickEventArgs(int buttonMask, int x, int y, int z, bool pressed)
        {
            m_ButtonMask = buttonMask;
            m_X = x;
            m_Y = y;
            m_Z = z;
            m_Pressed = pressed;
        }
        public JoystickEventArgs(int buttonMask, int x, int y, int z)
        {
            m_ButtonMask = buttonMask;
            m_X = x;
            m_Y = y;
            m_Z = z;
        }
        public JoystickEventArgs(int buttonMask)
        {
            m_ButtonMask = buttonMask;
        }

        private int m_X;
        /// <summary>
        /// Gets the joystick's X axis at the time this event was passed.
        /// </summary>
        public int X
        {
            get { return m_X; }
        }
        private int m_Y;
        /// <summary>
        /// Gets the joystick's Y axis at the time this event was passed.
        /// </summary>
        public int Y
        {
            get { return m_Y; }
        }
        private int m_Z;
        /// <summary>
        /// Gets the joystick's Z axis at the time this event was passed.
        /// </summary>
        public int Z
        {
            get { return m_Z; }
        }

        private int m_ButtonMask = 0;
        /// <summary>
        /// Gets the button that this event is associated with.
        /// </summary>
        public JoystickButtons Button
        {
            get
            {
                return (JoystickButtons)m_ButtonMask;
            }
        }

        private bool m_Pressed = false;
        /// <summary>
        /// Gets whether the button was pressed or released.
        /// </summary>
        public bool Pressed
        {
            get { return m_Pressed; }
        }


    }

    /// <summary>
    /// Encapsulates a number of available joystick buttons.
    /// </summary>
    public enum JoystickButtons
    {
        /// <summary>
        /// No button is being pressed.
        /// </summary>
        None = 0x0000,
        /// <summary>
        /// The first button on the joystick.
        /// </summary>
        Button1 = 0x0001,
        /// <summary>
        /// The second button on the joystick.
        /// </summary>
        Button2 = 0x0002,
        /// <summary>
        /// The third button on the joystick.
        /// </summary>
        Button3 = 0x0004,
        /// <summary>
        /// The fourth button on the joystick.
        /// </summary>
        Button4 = 0x0008,
        /// <summary>
        /// The fifth button on the joystick.
        /// </summary>
        Button5 = 0x0010,
        /// <summary>
        /// The sixth button on the joystick.
        /// </summary>
        Button6 = 0x0020,
        /// <summary>
        /// The seventh button on the joystick.
        /// </summary>
        Button7 = 0x0040,
        Button8 = 0x0080,
        Button9 = 0x0100,
        Button10 = 0x0200,
        Button11 = 0x0400,
        Button12 = 0x0800,
        Button13 = 0x1000,
        Button14 = 0x2000,
        Button15 = 0x4000,
        Button16 = 0x8000,
        /// <summary>
        /// Indicates the last button in the button enumeration.
        /// </summary>
        Last = Button16
    }
}
