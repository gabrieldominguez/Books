VERSION 5.00
Begin VB.Form frmCulling 
   Caption         =   "Culling Effect"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4350
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4350
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2280
      TabIndex        =   5
      Top             =   2640
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Height          =   375
      Left            =   840
      TabIndex        =   4
      Top             =   2640
      Width           =   855
   End
   Begin VB.Frame Frame1 
      Caption         =   "Culling Type"
      Height          =   1575
      Left            =   360
      TabIndex        =   1
      Top             =   840
      Width           =   3495
      Begin VB.OptionButton optWrong 
         Caption         =   "Wrong Culling"
         Height          =   375
         Left            =   480
         TabIndex        =   3
         Top             =   480
         Value           =   -1  'True
         Width           =   1815
      End
      Begin VB.OptionButton optCorrect 
         Caption         =   "Currect Culling"
         Height          =   375
         Left            =   480
         TabIndex        =   2
         Top             =   960
         Width           =   2295
      End
   End
   Begin VB.CheckBox chkCulling 
      Caption         =   "Check here to activate Culling Effect"
      Height          =   375
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   3495
   End
End
Attribute VB_Name = "frmCulling"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub chkCulling_Click()
  If chkCulling.Value = 1 Then
    Frame1.Enabled = True
  Else
    Frame1.Enabled = False
  End If
End Sub

Private Sub Command1_Click()
  If chkCulling.Value = 0 Then
    bCull = False
  Else
    bCull = True
    If optWrong.Value = True Then
      bWrongCulling = True
    Else
      bWrongCulling = False
    End If
  End If
  frmCulling.Hide
  Unload frmCulling
End Sub

Private Sub Command2_Click()
  frmCulling.Hide
  Unload frmCulling
End Sub

Private Sub Form_Load()
    If bCull = True Then
      chkCulling.Value = 1
      Frame1.Enabled = True
    Else
      chkCulling.Value = 0
      Frame1.Enabled = False
    End If
End Sub
