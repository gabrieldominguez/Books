#ifndef MODEL_H
#define MODEL_H

// Model.h
// James Ward 02/10/01 (espresso@crema.co.uk)
//
// Simple class for loading and drawing 3D models in ASE format (very basic)
//

//-----------------------------------------------------------------------------

class Model {
public:
    Model();
    virtual ~Model();

    void Draw() const;
    void DrawWire() const;
    bool Load(const char *name);
    void Free();

protected:
    void Reset();

    bool LoadASE(const char *name);

private:
    float *_vert;
    float *_norm;
    int   *_face;
    long   _nfaces;
    long   _nverts;
	mutable GLuint _list[2];
};

//-----------------------------------------------------------------------------

#endif//MODEL_H
