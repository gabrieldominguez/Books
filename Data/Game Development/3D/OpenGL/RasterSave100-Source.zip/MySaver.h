#ifndef MySaver_H
#define MySaver_H

// MySaver.h
// James Ward 02/10/01 (espresso@crema.co.uk)
//
// Screen Saver Implementation
//

#include <string>
using namespace std;

#include "Saver.h"
#include "Model.h"

//-----------------------------------------------------------------------------

class MySaver : public Saver {
public:
	MySaver();
	virtual ~MySaver();

	void OnCreate();
	void OnDestroy();
	void OnPaint();
	void OnTimer();
	void OnResize(int width, int height);

private: // initialisation & saver scenes
	void SetupModels();
	void SetupTextures();

	bool Scene1 (float Time, int Width, int Height);
	bool Scene2 (float Time, int Width, int Height);
	bool Scene3 (float Time, int Width, int Height);

private: // various drawing functions
	void DrawKana (float x, float y, float h, int kana=0);
	void DrawCode (float x, float y, float w, float h, float scroll=0);
	void DrawBars(float x, float y, float w, float h, int num);

	void DrawSnow(
		float Time, float x, float y, int Width, int Height,
		bool loseSync=true, int Image=0
	);

	void DrawTimecode(int Width, int Height);
	void DrawRasters(float Time, int Width, int Height);

private: // private member variables
	Model  _MBuild[4];	// building model
	string _Path;		// resource path
	bool   _bRasters;	// draw rasters?
	bool   _bSnow;		// draw snowy CRTs?
};

//-----------------------------------------------------------------------------

// Create instance of our custom saver class to handle screen saver events
static MySaver theSaver;

//-----------------------------------------------------------------------------

#endif//MySaver_H
