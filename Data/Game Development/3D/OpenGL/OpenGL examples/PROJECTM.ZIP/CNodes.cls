VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CNodes"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "SavedWithClassBuilder6" ,"Yes"
Attribute VB_Ext_KEY = "Collection" ,"CNode"
Attribute VB_Ext_KEY = "Member0" ,"CNode"
Attribute VB_Ext_KEY = "Top_Level" ,"Yes"
Option Explicit
'----------------------------------------------------------------
'FUNCTION: Collection of top-level nodes.
'AUTHOR: edx - edx@hk.super.net, Feb 99 - all rights reserved
'HISTORY: -
'NOTES:
'----------------------------------------------------------------
Private mCol As Collection
Dim m_SelectedNode As CNode

Private Sub Class_Initialize()
    Set mCol = New Collection
End Sub

Private Sub Class_Terminate()
    Set mCol = Nothing
End Sub

Public Sub Clear()
Dim i&
    For i = 1 To mCol.Count
        mCol.Remove 1
    Next
End Sub

Public Sub Compile()
Dim i&
    For i = 1 To mCol.Count
        mCol(i).Compile
    Next
End Sub

Public Sub Draw()
Dim i&
    glPushMatrix
    For i = 1 To mCol.Count
        mCol(i).Draw
    Next
    glPopMatrix
End Sub

'-------------------------------------------------------------------------------------
'Returns true if a Node was picked
Public Function OnPick(ID&) As Boolean
Dim i&
    For i = 1 To mCol.Count
        If mCol(i).OnPick Then
            OnPick = True
            Exit Function
        End If
    Next
End Function

'-------------------------------------------------------------------------------------
Public Function Add(Name As String, Parent As CNode) As CNode
Dim Obj As CNode
    'create a new object
    Set Obj = New CNode
    Obj.Name = Name
    If Not Parent Is Nothing Then
        Parent.AddChild Obj
    Else
        mCol.Add Obj, CStr(Obj.NameID)
    End If
    'return the object created
    Set Add = Obj
    Set Obj = Nothing
End Function

Public Property Get Item(vntIndexKey As Variant) As CNode
Attribute Item.VB_UserMemId = 0
    Set Item = mCol(vntIndexKey)
End Property

Public Property Get Count() As Long
    Count = mCol.Count
End Property

Public Sub Remove(vntIndexKey As Variant)
    mCol.Remove vntIndexKey
End Sub

Public Property Get NewEnum() As IUnknown
Attribute NewEnum.VB_UserMemId = -4
Attribute NewEnum.VB_MemberFlags = "40"
    Set NewEnum = mCol.[_NewEnum]
End Property


Public Property Get SelectedNode() As CNode
    Set SelectedNode = m_SelectedNode
End Property

Public Property Let SelectedNode(ByVal NewValue As CNode)
    If Not m_SelectedNode Is Nothing Then
        m_SelectedNode.Selected = False
    End If
    Set m_SelectedNode = NewValue
    If Not m_SelectedNode Is Nothing Then
        m_SelectedNode.Selected = True
    End If
End Property
