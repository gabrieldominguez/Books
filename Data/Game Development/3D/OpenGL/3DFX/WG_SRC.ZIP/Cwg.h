
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _CWG_
#define _CWG_

#include <windows.h>
#include <glide.h>

extern BOOL CWGInitialize(HWND, DWORD, DWORD);
extern VOID CWGShutdown(VOID);
extern VOID CWGCopy3DfxFrameBuffer(VOID);
extern FxBool CWGControl(FxU32);

#endif //_CWG_
