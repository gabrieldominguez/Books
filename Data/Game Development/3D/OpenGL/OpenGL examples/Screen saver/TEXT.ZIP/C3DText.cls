VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3DText"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'*************************************************************************\
'FUNCTION: Main class of the app.
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'KNOWN PROBLEMS:
'   - the class which cycles messages does repeat, only cycles once
'   - the motion when cycling text is jerky
'   sorry, no time to fix it now
'*************************************************************************\
Dim Lists As C3dLists 'collection of strings to display
Dim m_NextString& 'counter for cycling strings
Dim m_pMat As glxMaterial     ' ptr to current material
Dim m_bTexture As Boolean
Dim m_Texture As glxTexture
Dim m_Time$
Dim m_fMinCycleTime! ' = 10
Dim m_TransMatInc As glxMaterial
Dim m_TransMat As glxMaterial
Dim m_NewMat As glxMaterial
'
Dim m_TextExtentX! ' As POINTFLOAT
Dim m_TextExtentY! '
Dim m_TextOriginX!  ' As POINTFLOAT ' upper left corner of extents
Dim m_TextOriginY! '
'
Dim m_ZTrans!       ' translation in z
'
Dim m_ChordalDeviation As Single 'wgl
Dim m_Extrusion As Single   'wgl
Dim m_Type As Long        ' WGL_FONT_LINES or WGL_FONT_POLYGONS
Dim Glyphs As glxGlyphs 'collection to hold individual characters
Dim m_TextList%() 'array of command lists representing the string
Dim m_StrLength& 'length of text string
Dim m_hFont&

Private Sub Class_Initialize()
    m_fMinCycleTime = 10
    Set Lists = New C3dLists
End Sub

Private Sub Class_Terminate()
    Set m_pMat = Nothing
    Set m_Texture = Nothing
    Set m_TransMatInc = Nothing
    Set Lists = Nothing
    Set gAC = Nothing
    Set Glyphs = Nothing
    Set g3D = Nothing
    Set gBB = Nothing
    If m_hFont Then
        DeleteObject m_hFont
    End If
End Sub

Public Property Let CycleTime(ByVal NewValue!)
m_fMinCycleTime = NewValue
End Property

'extrusion
Public Property Get StringDepth!()
    StringDepth = m_Extrusion
End Property

Public Property Get TextExtentX!()
TextExtentX = m_TextExtentX
End Property

Public Property Get TextExtentY!()
TextExtentY = m_TextExtentY
End Property

'*****************************Public*Routine******************************\
'* Init
'* Called BEFORE gl is initialized!
'* Just do basic stuff here, like set up callbacks, verify dialog stuff, etc.
''*************************************************************************/
Public Sub Init()
    GetIniSettings
End Sub

'*****************************Public*Routine******************************\
'* text3d_Init
'* Initializes OpenGL state for text3d screen saver
''*************************************************************************/
Public Sub InitGL()
Dim hdc&
    hdc = gCtl.hdc
    glDepthFunc GL_LEQUAL
    glClearColor 0.1, 0.1, 0.1, 0
    glColor3f 0.8, 0.5, 0.5
    '
    glCullFace GL_BACK
    glEnable GL_CULL_FACE
    'Lighting
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 0.7, 0.7, 0.7
        .SetPosition 0, 50, 150
        .Enabled = True
    End With
    With gCtl.Lights.Item(liLight1)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.7, 0.7, 0.7
        .SetPosition 25, 150, 50
        .Enabled = True
    End With
    With gCtl.Lights
        .TwoSide = False
        .SetAmbient 1, 1, 1, 1
    End With
    '
    m_hFont = gCtl.Font.CreateFont(hdc, optFontName, 0, optBold, optItalic)
    If m_hFont = 0 Then
        Debug.Assert 0
    End If
    Set Glyphs = gCtl.Font.CreateGlyphSet(optFontName$)
    ' Set extrusion, chordal deviation, and font type
    m_ChordalDeviation = CalcChordalDeviation(hdc)
    Glyphs.ChordalDeviation = m_ChordalDeviation
    m_Extrusion = gCtl.Ex.RandomSng(FMIN_DEPTH, FMAX_DEPTH)
    Glyphs.Extrusion = m_Extrusion
    Glyphs.hFont = m_hFont
    If (optSurfaceStyle = SURFSTYLE_WIREFRAME) Then
        m_Type = WGL_FONT_LINES
    Else
        m_Type = WGL_FONT_POLYGONS
    End If
    Glyphs.PolygonMode = m_Type
    '
    Reset
End Sub

Public Sub Reset()
Dim X!, Y!, w!, h!
    ' intialize the text that will be displayed
    If optDemoType = DEMO_CLOCK Then
        m_UpdateTime False     ' sets gac.textXXX params as well
    Else 'If optDemoType = DEMO_STRING Then
        If Lists.IsaKeyString = False Then
            'optText is a simple string
            m_StrLength = Len(optText)
            Glyphs.ConvertStringToList optText, optBold, optItalic, m_TextList
            Glyphs.GetStringExtent optText, w, h, X, Y, optBold, optItalic
            m_TextExtentX = w
            m_TextExtentY = h
            m_TextOriginX = X
            m_TextOriginY = Y
        End If
    End If
    'View
    With gCtl.Camera
        .FieldOfView = gCtl.Ex.RandomSng(FMIN_VIEW_ANGLE, FMAX_VIEW_ANGLE)
        .SetEyePos 0, 0, 3
    End With
    With gAC
        ' text is either xmajor or ymajor
        .XMajor = IIf(m_TextExtentX >= m_TextExtentY, True, False)
        ' At this point, the initial string extents will have been
        '  calculated, and we can use this to determine rotational
        '  characteristics
        .RotationStyle = optRotationStyle
        ' set view angle
        gBB.CalcBoundingBox
    End With
    m_InitTexture
    If m_bTexture Then
        Set m_pMat = gCtl.Materials.RandomTexMaterial(True)
    Else
        Set m_pMat = gCtl.Materials.RandomTeaMaterial(True)
    End If
End Sub

'*************************************************************************\
'* InitTexture
''*************************************************************************/
Private Sub m_InitTexture()
Dim r&
With gAC
    If optSurfaceStyle <> SURFSTYLE_TEX Then
        Exit Sub
    End If
    ' No choice for texture quality in dialog - set to HIGH
    optTexQuality = TEXQUAL_HIGH
    ' Try to load the texture file or default texture resource
    'If (ss_LoadTextureFile(gAC.optTextureFile, gAC.texture) Or _
        ss_LoadTextureResource(gTexRes, gAC.texture)) Then
    Set m_Texture = gCtl.NewTexture
    r = m_Texture.LoadTextureFile(optTextureFile)  '.texture)
    If r = 0 Then
        r = m_Texture.LoadTextureResource(0)
    End If
    If r Then
        m_bTexture = True
        glEnable GL_TEXTURE_2D
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
        glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE

        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
        m_Texture.SetTexture
        ' set auto texture coord generation
        m_Texture.InitAutoTexture 0, 0
    Else   ' couldn't open .bmp file
        m_bTexture = 0
    End If
    End With
End Sub

'*************************************************************************\
'* text3d_Reshape - called on resize
''*************************************************************************/
Public Function Reshape(Width&, Height&) As Boolean
    m_CalcViewParams
    Reshape = True
End Function

'*************************************************************************\
'* text3d_Draw
'* Draw a frame. called by the timer and paint events
''*************************************************************************/
Public Sub Draw()
Static bCalibrated As Boolean
Static nCycle& ' cycle count
Static frameCount&, maxCount&, matTransCount&, matTransCount2&
Static zTrans!, zTransInc!
Static baseTime#
Static bInit As Boolean
    If bSuspended Then Exit Sub
    If bInit = False Then   ' Do first time init stuff
        Randomize
        Set m_TransMatInc = gCtl.NewMaterial
        ' Start the calibration timer
        baseTime = Now
        ' set default transition points, until calibration done
        maxCount = 60
        m_SetTransitionPoints maxCount, matTransCount, _
                             matTransCount2, zTrans
        bInit = True
    End If
    ' take action based on frameCount
    If frameCount >= matTransCount Then
        ' we are in the transition zone
        If frameCount = matTransCount Then
            ' first transition point...
            ' select new material
            Set m_NewMat = Nothing
            If m_bTexture Then
                Set m_NewMat = gCtl.Materials.RandomTexMaterial(False)
            Else
                Set m_NewMat = gCtl.Materials.RandomTeaMaterial(False)
            End If
            ' set material transition, zTrans transition
            If optDemoType = DEMO_VSTRING Then
                ' transition current material to black
                m_TransMatInc.CreateMaterialGradient m_TransMatInc, _
                                          m_pMat, _
                                          gCtl.Materials.ss_BlackMat, _
                                          matTransCount2 - matTransCount
                zTransInc = ((FMAX_ZOOM - 1) * m_ZTrans) / _
                                        (matTransCount2 - matTransCount)
            Else
                m_TransMatInc.CreateMaterialGradient m_TransMatInc, _
                                           m_pMat, _
                                           m_NewMat, _
                                           maxCount - matTransCount
            End If
            ' initialize transition values to current settings
            zTrans = m_ZTrans
            Set m_TransMat = m_pMat
            ' begin transition on NEXT frame.
        Else ' past first transition...
            If matTransCount2 And (frameCount = (matTransCount2 + 1)) Then
                ' optional second transition point...(only for vstrings)
                ' transition from black to new material
                m_TransMatInc.CreateMaterialGradient m_TransMatInc, _
                                           gCtl.Materials.ss_BlackMat, _
                                           m_NewMat, _
                                           maxCount - matTransCount2
                ' init transition material to black
                Set m_TransMat = gCtl.Materials.ss_BlackMat
                ' At this point, screen is black, so we can change strings
                ' * and resize the floater without any problems.
                If optDemoType = DEMO_VSTRING Then
                    UpdateString True   ' can cause resize
                End If
                ' set zTrans to furthest distance
                zTrans = FMAX_ZOOM * m_ZTrans
                zTransInc = (m_ZTrans - zTrans) / _
                                            (maxCount - matTransCount2)
                ' change this while string invisible
                gAC.ResetRotationLimits 0, 1, 1
            End If
            ' set the transition material (updates m_TransMat each time)
            m_TransMat.TransitionMaterial m_TransMat, m_TransMatInc
            zTrans = zTrans + zTransInc
            If (frameCount >= maxCount) Then
                ' End of cycle
                nCycle = nCycle + 1 ' 1-based

                ' Calibrate on MAX_CALIBRATE cycles
                If bCalibrated = False And nCycle >= MAX_CALIBRATE Then
                    maxCount = m_FrameCalibration(baseTime, maxCount, nCycle)
                    m_SetTransitionPoints maxCount, matTransCount, _
                                         matTransCount2, zTrans
                    bCalibrated = True
                End If

                ' set, reset stuff
                Set m_pMat = m_NewMat
                m_NewMat.SetMaterial
                zTrans = m_ZTrans
                frameCount = 0
            End If
        End If
    End If

    If optDemoType = DEMO_CLOCK Then
        ' have to update the draw string with current time
        m_UpdateTime True
    End If
    'glMatrixMode GL_MODELVIEW
    'glLoadIdentity
    glPushMatrix
        ' ok, the string's setup - draw it
        If optDemoType = DEMO_VSTRING Then
            ' use zooming zTrans
            glTranslatef 0, 0, zTrans
        Else
            ' use fixed zTrans
            glTranslatef 0, 0, m_ZTrans
        End If
        '
        ' * Rotate provides sinusoidal rotations
        gAC.Rotate   ' sets gac.p3dRot, or rot
    
        glTranslatef -m_TextOriginX - m_TextExtentX / 2, _
                      -m_TextOriginY + m_TextExtentY / 2, _
                      m_Extrusion / 2
        
        glCallLists m_StrLength, GL_UNSIGNED_SHORT, m_TextList(0)
        glFlush
        frameCount = frameCount + 1
    glPopMatrix
End Sub

'*************************************************************************\
'* FrameCalibration
'* Adjusts the number of frames in a cycle to conform to desired cycle time
'*************************************************************************/
Private Function m_FrameCalibration&(pBaseTime#, _
            framesPerCycle&, nCycle&)

Dim thisTime#
Dim CycleTime!
    'Stop
    thisTime = Now
    CycleTime = (thisTime - pBaseTime) * 10000 ' +(thisTime.millitm - pBaseTime.millitm)/1000;
    Debug.Print Format$(CycleTime, "Standard")
    Debug.Print CycleTime
    CycleTime = CycleTime / nCycle
    If (CycleTime < m_fMinCycleTime) Then
        ' need to add more frames to cycle
        If (CycleTime = 0) Then ' very unlikely
            framesPerCycle = 800
        Else
            framesPerCycle = (framesPerCycle * (m_fMinCycleTime / CycleTime))
        End If
    Else
        ' for vstrings, subtract frames from cycle
        If optDemoType = DEMO_VSTRING Then
            framesPerCycle = (framesPerCycle * (m_fMinCycleTime / CycleTime))
        End If
    End If
    ' make sure it's not too small
    If (framesPerCycle < MIN_FRAMES) Then
        framesPerCycle = MIN_FRAMES
    End If
    m_FrameCalibration = framesPerCycle
End Function

'*************************************************************************\
'* SetTransitionPoints
'* Calculate draw transition points, as frame count values.
'* If doing variable string (VSTRING), first transition point is where we
'* start fading to black, and 2nd is from black to next material.  Also
'* transition the z translation distance (zTrans).
'* Note that trans2 indicates the frame number where the image should be
'* black.  The actual transitioning may occur at trans2+1 (see text3d_draw
'* above).
'* For all other cases, set one transition point for fade to next material.
''*************************************************************************/
Private Sub m_SetTransitionPoints(framesPerCycle&, trans1&, _
                     trans2&, zTrans!)
    trans1 = 0.5 * framesPerCycle + 0.5
    If optDemoType = DEMO_VSTRING Then
        trans2 = trans1 + _
                   (0.5 * (framesPerCycle - trans1) + 0.5)
        zTrans = m_ZTrans
    End If
End Sub

'*************************************************************************\
'* text3d_UpdateString
'* Select new string to display.
'* If bCheckBounds, calculate new bounds as well.
''*************************************************************************/
Public Sub UpdateString(bCheckBounds As Boolean)
Dim Index&
Dim X!, w!, Y!, h!
    ' get next string to display
    If Lists.count = 0 Then
        Lists.CreateRandomList
    End If
    m_NextString = m_NextString + 1
    optText = Lists(m_NextString).pszStr
    Glyphs.ConvertStringToList optText, optBold, optItalic, m_TextList
    If m_NextString >= Lists.count Then m_NextString = 0
    ' get new extents
    Glyphs.GetStringExtent optText, w, h, X, Y, optBold, optItalic
    m_TextExtentX = w
    m_TextExtentY = h
    m_TextOriginX = X
    m_TextOriginY = Y
    If bCheckBounds = False Then
        Exit Sub
    End If
    ' calculate bounding box
    gBB.CalcBoundingBox
    m_CalcViewParams
End Sub

'*************************************************************************\
'* text3d_UpdateTime
'* Put new time string into the attribute context
''*************************************************************************/
Private Sub m_UpdateTime(bCheckBounds As Boolean)
Dim oldLen&
Dim TextExtentX!, TextExtentY! ' As POINTFLOAT
Dim textOriginX!, textOriginY! 'As POINTFLOAT
Dim textLowerRightX!, textLowerRightY! ' As POINTFLOAT
Dim currentLowerRightX!, currentLowerRightY! ' As POINTFLOAT
Static pszLastTime$
Dim szNewTime$
    szNewTime = Time
    ' Compare new time string with last one
    If StrComp(pszLastTime, szNewTime) = 0 Then
        ' time string has not changed, return
        Exit Sub
    End If
    ' translate the new time string into display lists in gac.usText
    Glyphs.ConvertStringToList szNewTime, optBold, optItalic, m_TextList
    optText = szNewTime
    ' Check extents of new string
    ' save current values
    oldLen = m_StrLength
    m_StrLength = Len(optText)
    TextExtentX = m_TextExtentX
    TextExtentY = m_TextExtentY
    
    textOriginX = m_TextOriginX
    textOriginY = m_TextOriginY
    Glyphs.GetStringExtent optText, TextExtentX, TextExtentY, textOriginX, textOriginY, optBold, optItalic

    If bCheckBounds = False Then
        ' just set new extents and return
        m_TextExtentX = TextExtentX
        m_TextExtentY = TextExtentY
        m_TextOriginX = textOriginX
        m_TextOriginY = textOriginY
        Exit Sub
    End If
    ' only update bounding box if new extents are larger, or the number
    ' * of chars changes
    bCheckBounds = False
    If (m_StrLength <> oldLen) Then
        ' recalculate everything
        bCheckBounds = True
        m_TextExtentX = TextExtentX
        m_TextExtentY = TextExtentY
        m_TextOriginX = textOriginX
        m_TextOriginY = textOriginY
    Else
        ' accumulate maximum bounding box in pac
        ' calc current lower right limits
        textLowerRightX = textOriginX + TextExtentX
        textLowerRightY = textOriginY - TextExtentY
        currentLowerRightX = m_TextOriginX + m_TextExtentX
        currentLowerRightY = m_TextOriginY - m_TextExtentY
        ' if new text extents extend beyond current, update
        If (textOriginX < m_TextOriginX) Then
            m_TextOriginX = textOriginX
            bCheckBounds = True
        End If
        If (textOriginY > m_TextOriginY) Then
            m_TextOriginY = textOriginY
            bCheckBounds = True
        End If
        If (textLowerRightX > currentLowerRightX) Then
            m_TextExtentX = textLowerRightX - m_TextOriginX
            bCheckBounds = True
        End If
        If (textLowerRightY < currentLowerRightY) Then
            m_TextExtentY = m_TextOriginY - textLowerRightY
            bCheckBounds = True
        End If
    End If
    If (bCheckBounds) Then
        ' string size has changed - recalc box and view params
        'todo
        gBB.CalcBoundingBox
        m_CalcViewParams
    End If
End Sub




'*************************************************************************\
'* CalcViewParams
'*   Calculate viewing parameters, based on window size, bounding box, etc.
'*************************************************************************/
Private Sub m_CalcViewParams()
Dim zNear#, zFar#
Dim aspectBound!, viewDist!
Dim vHeight!, FovY!
With gCtl.Camera
    ' calculate viewing distance so that front of bounding box within view
    aspectBound = gBB.AspectRatio
    ' this is distance to FRONT of bounding box:
    viewDist = gBB.Y / _
               (Tan(gCtl.Ex.DegToRad(.FieldOfView / 2)))
    ' NOTE: these are half-widths and heights
    If (aspectBound <= .AspectRatio) Then
        ' we are bound by the window's height
        FovY = .FieldOfView
    Else
        ' we are bound by window's width
        ' adjust fovy, so fovx remains the same
        vHeight = gBB.X / .AspectRatio
        FovY = gCtl.Ex.RadToDeg(2 * Atn(vHeight / viewDist))
    End If
    ' Could just use rotation sphere dimensions here, but for now
    ' * set clipping planes 10% beyond bounding box.
    zNear = 0.9 * viewDist
    zFar = 1.1 * (viewDist + 2 * gBB.Z)
    If optDemoType = DEMO_VSTRING Then
        zFar = zFar * FMAX_ZOOM
    End If
    .FieldOfView = FovY
    .NearPlane = zNear
    .FarPlane = zFar
    ' set viewing distance so that front of bounding box within view
    viewDist = viewDist * 1.01 ' pull back 1% further to be sure not off by a pixel..
    m_ZTrans = -(viewDist + gBB.Z)
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glTranslatef 0, 0, m_ZTrans
End With
End Sub






