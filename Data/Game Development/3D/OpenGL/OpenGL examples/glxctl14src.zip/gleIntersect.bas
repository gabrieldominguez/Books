Attribute VB_Name = "gleIntersections"
Option Explicit

'
' * FUNCTION:
' * This file contains a number of utilities useful to 3D graphics in
' * general, and to the generation of tubing and extrusions in particular
' *
' * HISTORY:
' * Written by Linas Vepstas, August 1991
' * Updated to correctly handle degenerate cases, Linas,  February 1993
' */
'-------------------------------------------------------------------------
'FUNCTION:
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------


'------------------------------------------------------------------------- */
'
' * the Degenerate_Tolerance token represents the greatest amount by
' * which different scales in a graphics environment can differ before
' * they should be considered "degenerate".   That is, when one vector is
' * a million times longer than another, changces are that the second will
' * be less than a pixel long, and therefore was probably meant to be
' * degenerate (by the CAD package, etc.)  But what should this tolerance
' * be?  At least 1 in one thousand (since screen sizes are 1K pixels), but
' * less than 1 in 4 million (since this is the limit of single-precision
' * floating point accuracy).  Of course, if double precision were used,
' * then the tolerance could be increased.
' *
' * Potentially, this naive assumption could cause problems if the CAD
' * package attempts to zoom in on small details, and turns out, certain
' * points should not have been degenerate.  The problem presented here
' * is that the tolerance could run out before single-precision ran
' * out, and so the CAD packages would perceive this as a "bug".
' * One alternative is to fiddle around & try to tighten the tolerance.
' * However, the right alternative is to code the graphics pipeline in
' * double-precision (and tighten the tolerance).
' *
' * By the way, note that Degernate Tolerance is a "dimensionless"
' * quantitiy -- it has no units -- it does not measure feet, inches,
' * millimeters or pixels.  It is used only in the computations of ratios
' * and relative lengths.
' */

'
' * Right now, the tolerance is set to 2 parts in a million, which
' * corresponds to a 19-bit distinction of mantissas. Note that
' * single-precsion numbers have 24 bit mantissas.
' */
'
'#define DEGENERATE_TOLERANCE   (0)
Public Const DEGENERATE_TOLERANCE = 0.000002
Public Const BACKWARDS_INTERSECT = 2

'------------------------------------------------------------------------- */
'
' * The macro and subroutine INTERSECT are designed to compute the
' * intersection of a line (defined by the points v1 and v2) and a plane
' * (defined as plane which is normal to the vector n, and contains the
' * point p).  Both return the point sect, which is the point of
' * interesection.
' *
' * This MACRO attemps to be fairly robust by checking for a divide by
' * zero.
' */

'------------------------------------------------------------------------- */
'
' * HACK ALERT
' * The intersection parameter t has the nice property that if t>1,
' * then the intersection is "in front of" p1, and if t<0, then the
' * intersection is "behind" p2. Unfortunately, as the intersecting plane
' * and the line become parallel, t wraps through infinity -- i.e. t can
' * become so large that t becomes "greater than infinity" and comes back
' * as a negative number (i.e. winding number hopped by one unit).  We
' * have no way of detecting this situation without adding gazzillions
' * of lines of code of topological algebra to detect the winding number;
' * and this would be incredibly difficult, and ruin performance.
' *
' * Thus, we've installed a cheap hack for use by the "cut style" drawing
' * routines. If t proves to be a large negative number (more negative
' * than -5), then we assume that t was positive and wound through
' * infinity.  This makes most cuts look good, without introducing bogus
' * cuts at infinity.
' */
'------------------------------------------------------------------------- */
Public Sub INTERSECT(valid&, sect#(), p#(), n#(), v1#(), v2#())
Dim deno#, numer#, t#, omt#

   deno = (v1(0) - v2(0)) * n(0)
   deno = deno + (v1(1) - v2(1)) * n(1)
   deno = deno + (v1(2) - v2(2)) * n(2)

   If (deno = 0) Then
      valid = False
      V3Copyd n, v1
      ' debug.? ("Intersect: Warning: line is coplanar with plane n"); */
   Else

      valid = True
      numer = (p(0) - v2(0)) * n(0)
      numer = numer + (p(1) - v2(1)) * n(1)
      numer = numer + (p(2) - v2(2)) * n(2)

      t = numer / deno
      omt = 1 - t

      ' if (t < -5) valid = 2; HACK ALERT See above */

      ' if t is HUGE, then plane and line are almost co-planar */
      If ((1 < t * DEGENERATE_TOLERANCE) Or _
         (-1 > t * DEGENERATE_TOLERANCE)) Then
            valid = False
        End If

      sect(0) = t * v1(0) + omt * v2(0)
      sect(1) = t * v1(1) + omt * v2(1)
      sect(2) = t * v1(2) + omt * v2(2)
   End If
End Sub

'Public Sub INTERSECT2(valid&, sect#(), p#(), n#(), v1#(), v1Index&, v2#(), v2Index&)
'Dim deno#, numer#, t#, omt#
''
'Dim tv1#(0 To 2), tv2#(0 To 2)
'
'    V3Copyd tv1, 0, v1, v1Index
'    V3Copyd tv2, 0, v2, v2Index
'
'    deno = (tv1(0) - tv2(0)) * n(0)
'    deno = deno + (tv1(1) - tv2(1)) * n(1)
'    deno = deno + (tv1(2) - tv2(2)) * n(2)
'
'    If (deno = 0) Then
'        valid = False
'        V3Copyd n, 0, tv1, 0
'        ' debug.? ("Intersect: Warning: line is coplanar with plane n"); */
'    Else
'
'        valid = True
'        numer = (p(0) - tv2(0)) * n(0)
'        numer = numer + (p(1) - tv2(1)) * n(1)
'        numer = numer + (p(2) - tv2(2)) * n(2)
'
'        t = numer / deno
'        omt = 1 - t
'
'        ' if (t < -5) valid = 2; HACK ALERT See above */
'
'        ' if t is HUGE, then plane and line are almost co-planar */
'        If ((1 < t * DEGENERATE_TOLERANCE) Or _
'            (-1 > t * DEGENERATE_TOLERANCE)) Then
'            valid = False
'        End If
'
'        sect(0) = t * tv1(0) + omt * tv2(0)
'        sect(1) = t * tv1(1) + omt * tv2(1)
'        sect(2) = t * tv1(2) + omt * tv2(2)
'    End If
'End Sub
'
'#define INNERSECT(sect,p,n,v1,v2) { int retval; INTERSECT(retval,sect,p,n,v1,v2); }
Public Function INNERSECT(sect#(), p#(), n#(), v1#(), v2#())
Dim retval&
INTERSECT retval, sect, p, n, v1, v2
INNERSECT = retval
End Function

'Public Function INNERSECT2(sect#(), p#(), n#(), v1#(), v1Index&, v2#(), v2Index&)
'Dim retval&
'INTERSECT2 retval, sect, p, n, v1, v1Index, v2, v2Index
'INNERSECT2 = retval
'End Function

'------------------------------------------------------------------------- */
'
' * The macro and subroutine BISECTING_PLANE compute a normal vecotr that
' * describes the bisecting plane between three points (v1, v2 and v3).
' * This bisecting plane has the following properties:
' * 1) it contains the point v2
' * 2) the angle it makes with v21 == v2 - v1 is equal to the angle it
' *    makes with v32 == v3 - v2
' * 3) it is perpendicular to the plane defined by v1, v2, v3.
' *
' * Having input v1, v2, and v3, it returns a vector n.
' * Note that n is NOT normalized (is NOT of unit length).
' *
' * The subroutine returns a value indicating if the specified inputs
' * represented a degenerate case. Valid is TRUE if the computed
' * intersection is valid, else it is FALSE.
' */

'int bisecting_plane (gleDouble n(3),    ' returned */
'                      gleDouble v1(3),  ' input */
'                      gleDouble v2(3),  ' input */
'                      gleDouble v3(3))  ' input */
Public Function BISECTING_PLANE3v(n#(), v1#(), _
                        v2#(), _
                        v3#())
Dim valid&
    BISECTING_PLANE valid, n, v1, v2, v3
    BISECTING_PLANE3v = valid
End Function
'
'------------------------------------------------------------------------- */
'Public Function bisecting_planec&(n#(), v#(), ndx1&, ndx2&, ndx3&)
'Dim valid&
''Dim v1#(0 To 2)
''Dim v2#(0 To 2)
''Dim v3#(0 To 2)
''    v1(0) = v(ndx1, 0)
''    v1(1) = v(ndx1, 1)
'   BISECTING_PLANE valid, n, v, ndx1&, v, ndx2&, v, ndx3&
'   bisecting_planec = valid
'End Function
'


'------------------------------------------------------------------------- */
'
' * The macro and subroutine BISECTING_PLANE compute a normal vector that
' * describes the bisecting plane between three points (v1, v2 and v3).
' * This bisecting plane has the following properties:
' * 1) it contains the point v2
' * 2) the angle it makes with v21 == v2 - v1 is equal to the angle it
' *    makes with v32 == v3 - v2
' * 3) it is perpendicular to the plane defined by v1, v2, v3.
' *
' * Having input v1, v2, and v3, it returns a unit vector n.
' *
' * In some cases, the user may specify degenerate points, and still
' * expect "reasonable" or "obvious" behaviour.  The "expected"
' * behaviour for these degenerate cases is:
' *
' * 1) if v1 == v2 == v3, then return n=0
' * 2) if v1 == v2, then return v32 (normalized).
' * 3) if v2 == v3, then return v21 (normalized).
' * 4) if v1, v2 and v3 co-linear, then return v21 (normalized).
' *
' * Mathematically, these special cases "make sense" -- we just have to
' * code around potential divide-by-zero's in the code below.
' */

'------------------------------------------------------------------------- */

Public Sub BISECTING_PLANE(valid&, n#(), _
            v1#(), _
            v2#(), _
            v3#())
Dim v21#(0 To 2), v32#(0 To 2)
Dim len21#, len32#, dot#

   V3Subd v21, v2, v1
   V3Subd v32, v3, v2

   V3Lengthd len21, v21
   V3Lengthd len32, v32

   If (len21 <= DEGENERATE_TOLERANCE * len32) Then

      If (len32 = 0) Then
         ' all three points lie ontop of one-another */
         V3Zerod n
         valid = False
      Else
         ' return a normalized copy of v32 as bisector */
         len32 = 1 / len32
         V3Scaled n, len32, v32
         valid = True
      End If

   Else

      valid = True

      If (len32 <= DEGENERATE_TOLERANCE * len21) Then
         ' return a normalized copy of v21 as bisector */
         len21 = 1 / len21
         V3Scaled n, len21, v21

      Else

         ' normalize v21 to be of unit length */
         len21 = 1 / len21
         V3Scaled v21, len21, v21

         ' normalize v32 to be of unit length */
         len32 = 1 / len32
         V3Scaled v32, len32, v32

         V3Dotd dot, v32, v21

         ' if dot == 1 or -1, then points are colinear */
         If ((dot >= (1 - DEGENERATE_TOLERANCE)) Or _
             (dot <= (-1 + DEGENERATE_TOLERANCE))) Then
            V3Copyd n, v21
         Else

            ' go do the full computation */
            n(0) = dot * (v32(0) + v21(0)) - v32(0) - v21(0)
            n(1) = dot * (v32(1) + v21(1)) - v32(1) - v21(1)
            n(2) = dot * (v32(2) + v21(2)) - v32(2) - v21(2)

            ' if above if-test's passed,
            ' * n should NEVER be of zero length */
            V3Normalized n
         End If
      End If
   End If
End Sub
'

' prototype for those who don't use the #define directly */
'int bisecting_plane (gleDouble n(3),    ' returned */
'                     gleDouble v1(3),   ' input */
'                     gleDouble v2(3),   ' input */
'                     gleDouble v3(3));  ' input */

'------------------------------------------------------------------------- */
'
' * The block of code below is ifdef'd out, and is here for reference
' * purposes only.  It performs the "mathematically right thing" for
' * computing a bisecting plane, but is, unfortunately, subject ot noise
' * in the presence of near degenerate points.  Since computer graphics,
' * due to sloppy coding, laziness, or correctness, is filled with
' * degenerate points, we can't really use this version.  The code above
' * is far more appropriate for graphics.
' */

'#If MATHEMATICALLY_EXACT_GRAPHICALLY_A_KILLER Then
'Public Sub bisecting_plane(n, v1, v2, v3)
'Dim v21#(0 To 2), v32#(0 To 2)
'Dim len21#, len32#, dot#
'
'   V3Subd v21, v2, v1
'   V3Subd v32, v3, v2
'
'   V3Lengthd len21, v21
'   V3Lengthd len32, v32
'
'   If (len21 = 0) Then
'
'      If (len32 = 0) Then
'         ' all three points lie ontop of one-another */
'         V3Zerod n
'         valid = False
'      Else
'         ' return a normalized copy of v32 as bisector */
'         len32 = 1 / len32
'         V3Scaled n, len32, v32
'      End If
'
'   Else
'
'      ' normalize v21 to be of unit length */
'      len21 = 1 / len21
'      V3Scaled v21, len21, v21
'
'      If (len32 = 0) Then
'         ' return a normalized copy of v21 as bisector */
'         V3Copyd n, v21
'      Else
'
'         ' normalize v32 to be of unit length */
'         len32 = 1 / len32
'         V3Scaled v32, len32, v32
'
'         V3Dotd dot, v32, v21
'
'         ' if dot == 1 or -1, then points are colinear */
'         If ((dot = 1) Or (dot = -1)) Then
'            V3Copyd n, v21
'         Else
'
'            ' go do the full computation */
'            n(0) = dot * (v32(0) + v21(0)) - v32(0) - v21(0)
'            n(1) = dot * (v32(1) + v21(1)) - v32(1) - v21(1)
'            n(2) = dot * (v32(2) + v21(2)) - v32(2) - v21(2)
'
'            ' if above if-test's passed,
'            ' * n should NEVER be of zero length */
'            V3Normalized n
'         End If
'      }
'   }
'}
'#End If

'------------------------------------------------------------------------- */
'
' * This macro computes the plane perpendicular to the the plane
' * defined by three points, and whose normal vector is given as the
' * difference between the two vectors ...
' *
' * (See way below for the "math" model if you want to understand this.
' * The comments about relative errors above apply here.)
' */

'Public Sub CUTTING_PLANE(valid&, n#(), _
'                        v1#(), _
'                        v2#(), _
'                        v3#())
'Dim v21#(0 To 2), v32#(0 To 2)
'Dim len21#, len32#, lendiff#
'
'   V3Subd v21, v2, v1
'   V3Subd v32, v3, v2
'
'   V3Lengthd len21, v21
'   V3Lengthd len32, v32
'
'   If (len21 <= DEGENERATE_TOLERANCE * len32) Then
'
'      If (len32 = 0) Then
'         ' all three points lie ontop of one-another */
'         V3Zerod n
'         valid = False
'      Else
'         ' return a normalized copy of v32 as cut-vector */
'         len32 = 1 / len32
'         V3Scaled n, len32, v32
'         valid = True
'      End If
'
'   Else
'
'      valid = True
'
'      If (len32 <= DEGENERATE_TOLERANCE * len21) Then
'         ' return a normalized copy of v21 as cut vector */
'         len21 = 1 / len21
'         V3Scaled n, len21, v21
'      Else
'
'         ' normalize v21 to be of unit length */
'         len21 = 1 / len21
'         V3Scaled v21, len21, v21
'
'         ' normalize v32 to be of unit length */
'         len32 = 1 / len32
'         V3Scaled v32, len32, v32
'
'         V3Subd n, v21, v32
'         V3Lengthd lendiff, n
'
'         ' if the perp vector is very small, then the two
'         ' * vectors are darn near collinear, and the cut
'         ' * vector is probably poorly defined. */
'         If (lendiff < DEGENERATE_TOLERANCE) Then
'            V3Zerod n
'            valid = False
'         Else
'            lendiff = 1 / lendiff
'            V3Scaled n, lendiff, n
'         End If
'      End If
'   End If
'End Sub

'------------------------------------------------------------------------- */

'#If MATHEMATICALLY_EXACT_GRAPHICALLY_A_KILLER Then
Public Sub CUTTING_PLANE(valid&, n#(), v1#(), v2#(), v3#())
Dim v21#(0 To 2), v32#(0 To 2)

   V3Subd v21, v2, v1
   V3Subd v32, v3, v2

   V3Normalized v21
   V3Normalized v32

   V3Subd n, v21, v32
   V3Normalized n
   valid = -1
End Sub
'#End If


'------------------------------------------------------------------------- */
' sets "colin" to true if the three points are colinear,
' * else false.  Note that if any two points are degenerate,
' * then they are colinear.
' * We are careful to make sure that the comparison
' * is unit-less, i.e. that the lengths of the individual
' * segments is normalized.  By re-arrangement, avoid overhead of
' * two square roots and two divides. */
Public Sub COLINEAR(colin, v1#(), v2#(), v3#())
Dim v21#(0 To 2), v32#(0 To 2)
Dim len21#, len32#, dot#

   V3Subd v21, v2, v1
   V3Subd v32, v3, v2

   V3Dotd len21, v21, v21
   V3Dotd len32, v32, v32
   colin = (len32 <= (DEGENERATE_TOLERANCE * len21))
   colin = colin Or (len21 <= (DEGENERATE_TOLERANCE * len32))
   V3Dotd dot, v21, v32
   colin = colin Or ((len21 * len32 - dot * dot) <= _
    (len21 * len32 * DEGENERATE_TOLERANCE * DEGENERATE_TOLERANCE))
End Sub

'------------------------------------------------------------------------- */
' sets "degen" to true if the two points are degenerate,
' * else false.  We are careful to make sure that the comparison
' * is unit-less, i.e. that the lengths of the individual
' * segments is normalized.  By re-arrangement, avoid overhead of
' * two square roots and two divides. */

'Public Sub DEGENERATE(degen, v1#(), v1Index&, v2#(), v2Index&)
'Dim diff#(0 To 2), summa#(0 To 2)
'Dim dlen#, slen#
'
'   V3Subd diff, v2, v2Index&, v1, v1Index&
'   V3Dotd dlen, diff, 0, diff, 0
'   V3Sumd summa, v1, v1Index&, v2, v2Index&
'   V3Dotd slen, summa, 0, summa, 0
'   degen = (dlen <= _
'      (DEGENERATE_TOLERANCE * DEGENERATE_TOLERANCE * slen))
'End Sub

'-------------------------------------------------------------------------== */
' This macro is used in several places to cycle through a series of
' * points to find the next non-degenerate point in a series */
Public Sub FIND_NON_DEGENERATE_POINT(inext&, npoints&, _
                lng#, diff#(), point_array() As gleVector)
Dim slen# ' gleDouble ;
Dim summa#(0 To 2) '   gleDouble summa(3);
   Do
      ' get distance to next point */
      V3Subd diff, point_array(inext + 1).v, point_array(inext).v
      V3Lengthd lng, diff
      V3Sumd summa, point_array(inext + 1).v, point_array(inext).v
      V3Lengthd slen, summa
      slen = slen * DEGENERATE_TOLERANCE
      inext = inext + 1
   Loop While ((lng <= slen) And (inext < npoints - 1))
End Sub

'------------------------------------------------------------------------- */
'
' * FUNCTION:
' * This file contains a number of utilities useful to 3D graphics in
' * general, and to the generation of tubing and extrusions in particular
' *
' * HISTORY:
' * Written by Linas Vepstas, August 1991
' */

'------------------------------------------------------------------------- */
'
' * The macro and subroutine INTERSECT are designed to compute the
' * intersection of a line (defined by the points v1 and v2) and a plane
' * (defined as plane which is normal to the vector n, and contains the
' * point p).  Both sect the array "sect", which is the point of
' * interesection.
' *
' * The subroutine returns a value indicating if the specified inputs
' * represented a degenerate case. Valid is TRUE if the computed
' * intersection is valid, else it is FALSE.
' */


'------------------------------------------------------------------------- */

'public function Intersectb& (gleDouble sect(3),   ' returned */
'                gleDouble p(3), ' input */
'                gleDouble n(3), ' input */
'                gleDouble v1(3),    ' input */
'                gleDouble v2(3))    ' input */
'Public Function Intersectb&(sect#(), p#(), n#(), v1#(), v2#())
'Dim valid&
'   INTERSECT valid, sect, p, n, v1, v2
'   Intersectb& = valid
'
'End Function

