//--------------------------------------------------------------
// Animaci�n efecto resorte
// con OpenGL.
// Daniel Beber - Diego Milone - Computaci�n II - 07/Junio/2002
//--------------------------------------------------------------

#include <stdio.h>
#include <GL/glut.h>
#include <vector>

float angle, angle2;	// Angulos
int moving, startx, starty;
float zoom_z;  // para trasladar en z y hacer efecto zoom.
int velocidad;
unsigned i, k;
int cambiar=-1;

GLfloat  ambient_light[] = {0.3, 0.3, 0.45, 1.0};
GLfloat   source_light[] = {0.1, 0.4, 0.8, 1.0};
GLfloat      light_pos[] = {0.0, 0.5, 0.0, 0.0};

vector <GLfloat> objeto;  // da las posiciones de cada cuadrado

void nuevas_coordenadas(unsigned paso)
{
   if (paso<=2)
    objeto[0] += 0.33;

   if ( (paso>=2) && (paso<=4) ){
       objeto[0] -= 0.33;
       objeto[1] +=0.33;
     }

   if ( (paso>=5) && (paso<=7) ){
       objeto[1] -= 0.33;
       objeto[2] +=0.33;
     }

   if ( (paso>=8) && (paso<=10) )
       objeto[2] -= 0.33;

   // retroceso ----------------

   if ( (paso>=11) && (paso<=13) )
       objeto[2] -= 0.33;

   if ( (paso>=14) && (paso<=16) ){
       objeto[2] += 0.33;
       objeto[1] -=0.33;
     }

   if ( (paso>=17) && (paso<=19) ){
       objeto[1] += 0.33;
       objeto[0] -=0.33;
     }

   if ( (paso>=20) && (paso<=22) )
       objeto[0] += 0.33;

    if ( paso==23 ){   // por los redondeos no vuelve al mismo lugar
	objeto[0] = -2;
	objeto[1] = 0;
	objeto[2] = 2;
    }
}

void init( void )
{
  // Configuraci�n de un modelo simple de luz
  glEnable	 ( GL_LIGHTING );
  glLightModelfv ( GL_LIGHT_MODEL_AMBIENT,ambient_light );
  glLightfv	 ( GL_LIGHT0,GL_DIFFUSE,source_light );
  glLightfv	 ( GL_LIGHT0,GL_POSITION,light_pos );

  glEnable	 ( GL_LIGHT0 ); //activar fuente de luz

  // Enable de las propiedades del material para iluminacion
  glEnable	  ( GL_COLOR_MATERIAL );
  glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );

  // Cull de caras ocultas
  glEnable     ( GL_CULL_FACE );
  glClearColor ( 0.0, 0.0, 0.0, 0.0 );

  objeto.push_back(-2);  // posicion cuadrado 0
  objeto.push_back(0);	 // posicion cuadrado 1
  objeto.push_back(+2);  // posicion cuadrado 2

  zoom_z = -5;
  velocidad = 100;
}

void draw_earth(GLfloat color_r,GLfloat color_g,GLfloat color_b,GLfloat pos_x,GLfloat pos_y,GLfloat pos_z )
{  glPushMatrix ( );
   glRotatef ( 90.0, 1.0, 0.0, 0.0 );

   glTranslatef ( pos_x, pos_y, pos_z );
   glColor3f ( color_r, color_g, color_b);

   GLUquadricObj*  q = gluNewQuadric ( );
   gluQuadricDrawStyle ( q, GLU_FILL );
   gluQuadricNormals   ( q, GLU_SMOOTH );

    gluSphere ( q, 0.7, 20, 20 );  // dibujar esferas
   //glutSolidCube(0.8);		 // par�metro: tama�o del cubo

   gluDeleteQuadric ( q );
   glPopMatrix ( );
}

void display ( void )
{  glClear   ( GL_COLOR_BUFFER_BIT );
   glLightfv ( GL_LIGHT0,GL_POSITION,light_pos );

   glPushMatrix   ( );

   glTranslatef ( 0.0, 0.0, zoom_z );
   glRotatef  ( angle2, 1.0, 0.0, 0.0 );
   glRotatef  ( angle, 0.0, 1.0, 0.0  );

   cambiar++;
   if (cambiar==24) cambiar=-1;
   nuevas_coordenadas(cambiar);

   // los cuadrados van de izquierda a derecha
   draw_earth ( 2.0, 0.0, 0.0, objeto[0], 0.0, 0.0 );  // 3 colores, 3 coordenadas
   draw_earth ( 0.0, 2.0, 0.0, objeto[1], 0.0, 0.0);
   draw_earth ( 0.0, 0.0, 2.0, objeto[2], 0.0, 0.0);

   glPopMatrix	( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{  glViewport	  ( 0, 0, w, h );
   glMatrixMode   ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 80, ( float ) w, 1.0, 5000.0 );
   else
      gluPerspective ( 80, ( float ) w / ( float ) h, 1.0, 5000.0 );
   glMatrixMode   ( GL_MODELVIEW );

   glLoadIdentity ( );
}

void mouse ( int button, int state, int x, int y )
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {  moving = 1;
      startx = x;
      starty = y;
   }

   if ( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
      moving = 0;
}

void motion ( int x, int y )
{  if ( moving )
   {  angle  = angle + (x - startx);
      angle2 = angle2 + (y - starty);
      startx = x;
      starty = y;
      glutPostRedisplay();
   }
}

void idle_func ( void )
{  angle = angle + 0.1;
   if (angle == 360) angle = 0;
     glutPostRedisplay ( );
}

void keyboard ( unsigned char key, int x, int y )
{  switch ( key ) {
      case 27:	/*  Escape*/
	 exit ( 0 );
	 break;
      case 'f':
	 glutFullScreen ( );
	 break;
      case 'w':
	 glutReshapeWindow ( 250,250 );
	 break;
      case 'z':
	 zoom_z +=0.2;	// nos acercamos. Aumenta la imagen
	 break;
      case 'Z':
	 zoom_z -=0.2;
	 break;
      case 'v':
	 velocidad -=20;  // m�s velocidad
	 break;
      case 'V':
	 velocidad +=20;
	 break;
      default:
	 break;
   }
}

void FuncionTimer(int value)
{ // Establece con qu� velocidad (en tiempo) se redibuja la pantalla
  glutPostRedisplay();			 // Redibujar la ventana
  glutTimerFunc(velocidad, FuncionTimer, 0);	// Setup el pr�ximo timer
}


int main ( int argc, char** argv )
{  glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE );
   glutInitWindowSize  ( 300, 250 );
   glutCreateWindow    ("Hacer drag con el mouse");
   init ( );
   glutReshapeFunc  ( reshape	);
   glutMouseFunc    ( mouse	);
   glutMotionFunc   ( motion	);
   glutKeyboardFunc ( keyboard	);
   glutDisplayFunc  ( display	);

   // contantemente se llama la funci�n que esta como parametro
   // glutIdleFunc     ( idle_func );

   glutTimerFunc(velocidad, FuncionTimer, 0); // velocidad (en tiempo) para mostrar

   glutMainLoop ( );
   return 0;
}




//  // EFECTO RESORTE =======================================
//  for (i=1;i<3;i++) {
//    objeto[0] += 1;
//    glutPostRedisplay();
//  }
//
//  for(k=0;k<(objeto.size()-2);k++)
//    for (i=1;i<3;i++) {
//	objeto[k] -= 1;
//	objeto[k+1] +=1;
//	glutPostRedisplay();
//    }
//
//  for (i=1;i<3;i++) {
//    objeto[objeto.size()] -= 1;
//    glutPostRedisplay();
//  }
//
//  for (i=1;i<3;i++) {
//    objeto[objeto.size()] -= 1;
//    glutPostRedisplay();
//  }
//
//  for(k=objeto.size();k>0;k--)
//    for (i=1;i<3;i++) {
//	objeto[k] += 1;
//	objeto[k-1] -=1;
//	glutPostRedisplay();
//    }
//
//  for (i=1;i<3;i++) {
//    objeto[0] += 1;
//    glutPostRedisplay();
//  }
// // ================================================



