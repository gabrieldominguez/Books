class AwesomeComponentActor extends Actor
    placeable;

defaultproperties
{
    Begin Object Class=SpriteComponent Name=MySprite
        Sprite=Texture2D'EditorResources.S_Keypoint'
        HiddenGame=true
    End Object
    Components.Add(MySprite)

    Begin Object Class=DynamicLightEnvironmentComponent Name=AwesomeLightEnvironment
    End Object
    Components.Add(AwesomeLightEnvironment)

    Begin Object Class=SkeletalMeshComponent Name=AwesomeMesh
        SkeletalMesh=SkeletalMesh'CH_IronGuard_Male.Mesh.SK_CH_IronGuard_MaleA'
        LightEnvironment=AwesomeLightEnvironment
    End Object
    Components.Add(AwesomeMesh)
}
