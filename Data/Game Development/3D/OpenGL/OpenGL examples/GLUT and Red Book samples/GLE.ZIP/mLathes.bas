Attribute VB_Name = "mLathes"
Option Explicit

Public Sub InitLathes()

End Sub

Public Sub DrawLathes()

End Sub



