#include <stdio.h>
#include "device.h"
#include "globals.h"

/*#define SIMPLE*/

float WIDTH=0.001;
float HEIGHT=0.001;
float DEPTH=0.001;
float RADIUS=0.06;

void
pov_init(device* this)
{
  fprintf(this->fp,"object {\n");
  fprintf(this->fp," union {\n");
}

void
pov_clear(device* this)
{
}

void
pov_exit(device* this)
{
  fprintf(this->fp," }\n");
  fprintf(this->fp,"}\n");
}

int
pov_getch(device* this)
{
  return 0;
}

void
pov_sphere(device* this, int x, int y, int z)
{
  fprintf(this->fp,
	  " sphere {"
	  " <%f,%f,%f>,"
	  " %f "
	  "}\n",
	  (float)x*WIDTH *this->xscale,
	  (float)y*HEIGHT*this->yscale,
	  (float)z*DEPTH *this->zscale,
	  (float)RADIUS  *this->rscale);
}

void
pov_tube(device* this, int x1, int y1, int z1, int x2, int y2, int z2)
{
  /* this can happen due to roundoff in splines */
  /* PoVRay makes a problem out of it, and I undersatnd why */
  /* besides, it makes the output smaller */
  if ((x1==x2)&&(y1==y2)&&(z1==z2))
  {
    return;
  }
  fprintf(this->fp,
	  " cylinder {"
	  " <%f,%f,%f>,"
	  " <%f,%f,%f>,"
	  " %f "
	  " open "
	  "}\n",
	  (float)x1*WIDTH *this->xscale,
	  (float)y1*HEIGHT*this->yscale,
	  (float)z1*DEPTH *this->zscale,
	  (float)x2*WIDTH *this->xscale,
	  (float)y2*HEIGHT*this->yscale,
	  (float)z2*DEPTH *this->zscale,
	  (float)RADIUS   *this->rscale);
}

void
pov_line(device* this, int x1, int y1, int x2, int y2)
{
  pov_sphere(this,x1,y1,0);
  pov_tube  (this,x1,y1,0,x2,y2,0);
  pov_sphere(this,x2,y2,0);
}

void
pov_spline(device* this,
	   int x1, int y1, int x2, int y2, 
	   int x3, int y3, int x4, int y4)
{
  int x,y;
  int xo,yo;
  float t;

  if ((x1==x2)&&(x2==x3)&&(x3==x4)&&(y1==y2)&&(y2==y3)&&(y3==y4))
  {
    fprintf(stderr,"empty spline\n");
    return;
  }
#ifdef SIMPLE
  pov_sphere(this,x1,y1,0);
  pov_tube  (this,x1,y1,0,x2,y2,0);
  pov_sphere(this,x2,y2,0);
  pov_tube  (this,x2,y2,0,x3,y3,0);
  pov_sphere(this,x3,y3,0);
  pov_tube  (this,x3,y3,0,x4,y4,0);
  pov_sphere(this,x4,y4,0);
#else
  xo=x1;
  yo=y1;
  pov_sphere(this,x1,y1,0);
  for(t=0.2;t<0.95;t+=0.2)
  {
    x=(int)((((x4-3*x3+3*x2-x1)*t+3*(x3-2*x2+x1))*t+3*(x2-x1))*t+x1);
    y=(int)((((y4-3*y3+3*y2-y1)*t+3*(y3-2*y2+y1))*t+3*(y2-y1))*t+y1);
    pov_tube(this,xo,yo,0,x,y,0);
    pov_sphere(this,x,y,0);
    xo=x;
    yo=y;
  }
  pov_tube(this,xo,yo,0,x4,y4,0);
  pov_sphere(this,x4,y4,0);
#endif

}

device dev_pov=
{
  pov_init,
  pov_clear,
  pov_exit,
  pov_getch,
  pov_line,
  pov_spline
};

