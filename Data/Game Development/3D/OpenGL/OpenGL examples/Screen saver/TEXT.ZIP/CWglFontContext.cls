VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CWglFontContext"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'*************************************************************************\
'FUNCTION:
'This class handles the creation of the font display list.
'It is extensively modified from the original SDK sample.
'The original sample supports Unicode, this does not.
'It also used a lookup table, which is here
'replaced by a Collection of ListEntry objects.
'The class manages font creation and the conversion of a string into a
'display list. It then calls
'gl with that list when the string needs to be drawn.
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'*************************************************************************\
'-----------------------------------------------------------------

'Dim m_hDC As Long
'Dim m_ChordalDeviation As Single 'wgl
'Dim m_Extrusion As Single   'wgl
'Dim m_Type As Long        ' WGL_FONT_LINES or WGL_FONT_POLYGONS
'Dim LUT As C3DListEntries 'collection to hold individual characters
'Dim m_TextList%() 'array of command lists representing the string
'Dim m_StrLength& 'length of text string
'Dim m_hFont&
'

'Private Sub Class_Initialize()
'    Set LUT = New C3DListEntries
'End Sub

'Private Sub Class_Terminate()
'    Set LUT = Nothing
'    If m_hFont Then
'        DeleteObject m_hFont
'    End If
'End Sub

'/******************************Public*Routine******************************\
'* CreateWglFontContext
'* Create a WglFontContext.
'* Initializes the look-up-table memory for characters.
'* The first half of this table is a direct look-up, using the char value.
'* The second half is used for unicode chars that are >256, and must be
'* searched sequentially.
'\**************************************************************************/
'Public Function Init(hDC&) As Boolean
'    m_hDC = hDC
'    m_ChordalDeviation = m_CalcChordalDeviation(hDC)
'    m_hFont = gCtl.Font.CreateFont(m_hDC, optFontName, 0, optBold, optItalic)
'    If m_hFont = 0 Then Exit Function
'    ' We have a valid font
'    SelectObject m_hDC, m_hFont
'    ' Set extrusion, chordal deviation, and font type
'    m_Extrusion = gCtl.Ex.RandomSng(FMIN_DEPTH, FMAX_DEPTH)
'    ' calculate m_ChordalDeviation from input attribute optTessFactor
'    If (optSurfaceStyle = SURFSTYLE_WIREFRAME) Then
'        m_Type = WGL_FONT_LINES
'    Else
'        m_Type = WGL_FONT_POLYGONS
'    End If
'    Init = True
'End Function

'size in space
'Public Property Get StringLength() As Long
'    StringLength = m_StrLength
'End Property
'
''extrusion
'Public Property Get StringDepth!()
'    StringDepth = m_Extrusion
'End Property
'
'/******************************Public*Routine******************************\
'* DrawString
'* Draws string by calling cmd list for each char.
'\**************************************************************************/
'Public Sub DrawString()
'    glCallLists m_StrLength, GL_UNSIGNED_SHORT, m_TextList(0)
'End Sub



'/******************************Public*Routine******************************\
'* UpdateReducedFontList
'* Calls wglUseFontOutlines() to create a command list for the supplied
'* character.
'* Allocates memory for the characters glyphmetrics as well
'\**************************************************************************/
'Private Function CreateCharList(c$) As C3DListEntry
'Dim ple As C3DListEntry
'    Set ple = New C3DListEntry
'    ' get next list # for this glyph.
'    ple.Glyph = c
'    If ple.listNum = 0 Then
'        MsgBox "glGenLists failed"
'        Exit Function
'    End If
'    If ple.CreateList(m_hDC, c, m_ChordalDeviation, m_Extrusion, _
'               m_Type) = 0 Then
'        MsgBox "wglUseFontOutlines failed"
'        Exit Function
'    End If
'    Set CreateCharList = ple
'End Function

''/**************************************************************************\
''* ConvertStringToList
''* - Translate the string into display list numbers
''* - If no entry in the list table, update the table
''\**************************************************************************/
'Public Sub ConvertStringToList(pszSrc$)
'Dim strLen&, ple As C3DListEntry
'Dim c$, cIndex%, i&
'Dim roomLeft& ' spaces left in extended lut table
''    /* Go thru the string, making sure every char has a display list
''     * Copy the display list # into usDst
'    strLen = Len(pszSrc)
''    /* Check for possible overflow with the extended LUT section, and
''     * invalidate the extended LUT if so
'    If LUT.count Then
'        roomLeft = SIZE_LIST_LUT - LUT.count '(LUTIndex + MAX_DIRECT_LUT + 1)
'        If (roomLeft < strLen) Then
'            ' If none of the characters in this string have entries in the
'            ' table, we'll run out of room.  Assume the worst, invalidate
'            ' the whole table, and start over again.
'            'DeleteExtendedLUTTableEntries
'            LUT.Clear
'        End If
'    End If
'    ReDim m_TextList(0 To strLen)
'    For i = 1 To strLen '; strLen--, pszSrc++ ) {
'        c = Mid$(pszSrc, i, 1) 'pszSrc;
'        cIndex = Asc(c)
'        ' see if char already has cmd list entry - if not, create it
'        Set ple = LUT(c)
'        If ple Is Nothing Then
'            Set ple = CreateCharList(c)
'            LUT.Add ple
'        End If
'        m_TextList(i - 1) = ple.listNum
'    Next
'    ' zero terminate
'    m_TextList(strLen) = 0
'End Sub
'
'*************************************************************************\
'* TestFont
'* Test that GetOutlineTextMetrics works.  If not, wglUseFontOutlines will fail.
'* If the font tests bad, delete it and select in the previous one.
'*************************************************************************/
'Private Function m_TestFont(hFont&) As Boolean
'Dim otm As OUTLINETEXTMETRIC
'Dim hfontOld&, hdc&
'    hdc = wglGetCurrentDC
'    hfontOld = SelectObject(hdc, hFont)
'    otm.otmSize = Len(otm)
'    If GetOutlineTextMetrics(hdc, Len(otm), otm) <= 0 Then
'        Debug.Print "sstext3d Init: GetOutlineTextMetrics failure\n"
'        SelectObject hdc, hfontOld
'        DeleteObject hFont
'        Exit Function
'    End If
'    m_TestFont = True
'End Function


