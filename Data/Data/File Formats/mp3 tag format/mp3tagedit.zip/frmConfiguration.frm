VERSION 5.00
Begin VB.Form frmConfiguration 
   Caption         =   "Configuration"
   ClientHeight    =   1875
   ClientLeft      =   3045
   ClientTop       =   2175
   ClientWidth     =   6645
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmConfiguration.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   1875
   ScaleWidth      =   6645
   Begin VB.CommandButton cmdAnnuler 
      Cancel          =   -1  'True
      Caption         =   "&Annuler"
      Height          =   375
      Left            =   3465
      TabIndex        =   2
      Top             =   1410
      Width           =   1455
   End
   Begin VB.CommandButton cmdValider 
      Caption         =   "&Valider"
      Height          =   375
      Left            =   5025
      TabIndex        =   1
      Top             =   1410
      Width           =   1455
   End
   Begin VB.Frame fraTmp 
      ClipControls    =   0   'False
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1305
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   6465
      Begin VB.ComboBox cboLangue 
         Height          =   315
         ItemData        =   "frmConfiguration.frx":000C
         Left            =   2100
         List            =   "frmConfiguration.frx":0016
         Style           =   2  'Dropdown List
         TabIndex        =   5
         Top             =   240
         Width           =   1815
      End
      Begin VB.CheckBox chkUpdate 
         Caption         =   "&V�rifier si une version plus r�cente existe au d�marrage de l'application."
         Height          =   195
         Left            =   120
         TabIndex        =   3
         Top             =   840
         Width           =   6225
      End
      Begin VB.Label lblTmp 
         AutoSize        =   -1  'True
         Caption         =   "S�lection de la langue :"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   4
         Top             =   300
         Width           =   1665
      End
   End
End
Attribute VB_Name = "frmConfiguration"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cboLangue_Click()
' Changement de la langue
intLOffset = cboLangue.ListIndex * 150
Call initLocalization
Call initMe
End Sub

Private Sub cmdAnnuler_Click()
' Fermeture de la fen�tre sans sauvegarde de la configuration
Unload Me
End Sub

Private Sub cmdValider_Click()
' Fermeture de la fen�tre avec sauvegarde de la configuration
intLOffset = cboLangue.ListIndex * 150
blUpdate = (chkUpdate.Value = 1)
SaveSetting "MP3TagEdit", "Localization", "Language", intLOffset
SaveSetting "MP3TagEdit", "Configuration", "Update", blUpdate
Unload Me
End Sub

Private Sub Form_Load()
' Initialisation des zones
cboLangue.ListIndex = (intLOffset / 150)
chkUpdate.Value = IIf(blUpdate, 1, 0)
' Centrage de la fen�tre
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2
End Sub

Private Sub initMe()
' Initialisation de la langue d'affichage pour la fen�tre
lblTmp(0).Caption = LoadResString(intLOffset + 147)
chkUpdate.Caption = LoadResString(intLOffset + 153)
cmdValider.Caption = LoadResString(intLOffset + 162)
cmdAnnuler.Caption = LoadResString(intLOffset + 163)
End Sub
