VERSION 5.00
Begin VB.Form frmLanguage 
   Caption         =   "MP3 Tag Editor - Language Selection"
   ClientHeight    =   2790
   ClientLeft      =   6495
   ClientTop       =   3315
   ClientWidth     =   4560
   Icon            =   "frmLanguage.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   2790
   ScaleWidth      =   4560
   Begin VB.Frame frmLanguage 
      Caption         =   " Select A Language "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1065
      Left            =   525
      TabIndex        =   0
      Top             =   1575
      Width           =   3420
      Begin VB.CommandButton cmdEnglish 
         Caption         =   "&English"
         Height          =   420
         Left            =   1920
         TabIndex        =   4
         Top             =   360
         Width           =   1170
      End
      Begin VB.CommandButton cmdFrench 
         Caption         =   "&French"
         Height          =   420
         Left            =   360
         TabIndex        =   3
         Top             =   360
         Width           =   1170
      End
   End
   Begin VB.Label lblCaption 
      Alignment       =   2  'Center
      Caption         =   "MP3 Tag Editor"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Left            =   585
      TabIndex        =   2
      Top             =   45
      Width           =   3300
   End
   Begin VB.Label Label1 
      Caption         =   $"frmLanguage.frx":000C
      Height          =   960
      Left            =   600
      TabIndex        =   1
      Top             =   480
      Width           =   3525
   End
End
Attribute VB_Name = "frmLanguage"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdEnglish_Click()
' Offset position for English
intLOffset = 0
Unload Me
End Sub

Private Sub cmdFrench_Click()
' Offset position for French
intLOffset = 50
Unload Me
End Sub

Private Sub form_unload(Cancel As Integer)
SaveSetting "MP3TagEdit", "Localization", "Language", intLOffset
Call initLocalization
End Sub
