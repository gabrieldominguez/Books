VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Object = "{05589FA0-C356-11CE-BF01-00AA0055595A}#2.0#0"; "amovie.ocx"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Wav2MP3 Wizard - v1.3 (Rev 49)"
   ClientHeight    =   7170
   ClientLeft      =   2745
   ClientTop       =   735
   ClientWidth     =   6585
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   7170
   ScaleWidth      =   6585
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdDecode 
      Caption         =   "Decode (mp3 > wav)"
      Height          =   390
      Left            =   2325
      TabIndex        =   27
      ToolTipText     =   "Convert your MP3 files back to WAV. Any options made on this screen have no effect"
      Top             =   6375
      Width           =   2115
   End
   Begin VB.CommandButton cmdPreview 
      Caption         =   "Preview (last encoded)"
      Enabled         =   0   'False
      Height          =   375
      Left            =   4575
      TabIndex        =   25
      ToolTipText     =   "Plays the file you've last encoded in order to check quickly if it was encoded the way you like."
      Top             =   6375
      Width           =   1815
   End
   Begin VB.CommandButton cmdIDshow 
      Caption         =   "Show IDv3 Settings >>"
      Height          =   375
      Left            =   120
      TabIndex        =   5
      ToolTipText     =   "Use this to show or hide the ID3Tag options"
      Top             =   3000
      Width           =   2055
   End
   Begin VB.Frame Frame4 
      Caption         =   "ID3 Tag Information:"
      Height          =   2295
      Left            =   120
      TabIndex        =   19
      Top             =   3480
      Visible         =   0   'False
      Width           =   6255
      Begin VB.ComboBox cmbGenre 
         Height          =   315
         Left            =   1080
         TabIndex        =   9
         Text            =   "Select a genre"
         ToolTipText     =   "Select a gencre from the list"
         Top             =   1800
         Width           =   1815
      End
      Begin VB.TextBox txtArtist 
         Height          =   375
         Left            =   1080
         MaxLength       =   30
         TabIndex        =   6
         ToolTipText     =   "Enter the song's artist here"
         Top             =   360
         Width           =   5055
      End
      Begin VB.TextBox txtSong 
         Height          =   375
         Left            =   1080
         MaxLength       =   30
         TabIndex        =   7
         ToolTipText     =   "Enter the title of the song here"
         Top             =   825
         Width           =   5055
      End
      Begin VB.TextBox txtAlbum 
         Height          =   375
         Left            =   1080
         MaxLength       =   30
         TabIndex        =   8
         ToolTipText     =   "Enter the name of the album (if any) that contains the song"
         Top             =   1320
         Width           =   5055
      End
      Begin VB.TextBox txtYear 
         Height          =   375
         Left            =   4680
         MaxLength       =   4
         TabIndex        =   10
         ToolTipText     =   "Enter the year that the song was published"
         Top             =   1800
         Width           =   1455
      End
      Begin VB.Label Label5 
         BackStyle       =   0  'Transparent
         Caption         =   "Artist:"
         Height          =   255
         Left            =   120
         TabIndex        =   24
         Top             =   450
         Width           =   975
      End
      Begin VB.Label Label6 
         BackStyle       =   0  'Transparent
         Caption         =   "Song Title:"
         Height          =   255
         Left            =   120
         TabIndex        =   23
         Top             =   900
         Width           =   975
      End
      Begin VB.Label Label7 
         BackStyle       =   0  'Transparent
         Caption         =   "Album:"
         Height          =   255
         Left            =   120
         TabIndex        =   22
         Top             =   1350
         Width           =   975
      End
      Begin VB.Label Label8 
         BackStyle       =   0  'Transparent
         Caption         =   "Genre:"
         Height          =   255
         Left            =   120
         TabIndex        =   21
         Top             =   1800
         Width           =   975
      End
      Begin VB.Label Label9 
         BackStyle       =   0  'Transparent
         Caption         =   "Year:"
         Height          =   255
         Left            =   3600
         TabIndex        =   20
         Top             =   1860
         Width           =   975
      End
   End
   Begin MSComDlg.CommonDialog dlgMain 
      Left            =   4800
      Top             =   5880
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      Filter          =   "Wave Files *.wav| *.wav|MP3 Files *.mp3|*.mp3|"
   End
   Begin VB.CommandButton cmdBrowse 
      Caption         =   "&Browse for File"
      Height          =   375
      Left            =   150
      TabIndex        =   11
      ToolTipText     =   "Click here to browse your disk for the file you want to encode; no need to select the same file twice in case of re-encoding"
      Top             =   5880
      Width           =   2055
   End
   Begin VB.Frame Frame3 
      Caption         =   "Speed vs. Quality"
      Height          =   1335
      Left            =   3240
      TabIndex        =   14
      Top             =   120
      Width           =   3135
      Begin ComctlLib.Slider sldQual 
         Height          =   435
         Left            =   120
         TabIndex        =   3
         ToolTipText     =   "<< Faster encoding, lower quality --- Slower encoding, higher quality >>"
         Top             =   360
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   767
         _Version        =   327682
         LargeChange     =   1
         Min             =   1
         Max             =   3
         SelStart        =   2
         Value           =   2
      End
      Begin VB.Label lblQVS 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Normal (good quality, average speed)"
         Height          =   255
         Left            =   240
         TabIndex        =   15
         Top             =   960
         Width           =   2655
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Compression Type"
      Height          =   1335
      Left            =   120
      TabIndex        =   13
      Top             =   120
      Width           =   3015
      Begin VB.OptionButton optAB 
         Caption         =   "Average Bitrate (recommended)"
         Height          =   375
         Left            =   150
         TabIndex        =   1
         ToolTipText     =   "Provides higher quality by encoding each part of the file in a higher or lower bitrate if needed"
         Top             =   300
         Width           =   2415
      End
      Begin VB.OptionButton optCBR 
         Caption         =   "Constant Bitrate"
         Height          =   255
         Left            =   150
         TabIndex        =   2
         ToolTipText     =   "Encodes the whole file with the same bitrate; note that quality may be lower"
         Top             =   825
         Value           =   -1  'True
         Width           =   2535
      End
   End
   Begin VB.CommandButton cmdEncode 
      Caption         =   "&Encode (wav > mp3)"
      Height          =   375
      Left            =   150
      TabIndex        =   12
      ToolTipText     =   "Starts the encoding process; make sure you follow the on-screen instructions"
      Top             =   6360
      Width           =   2055
   End
   Begin VB.Frame Frame1 
      Caption         =   "Bitrate"
      Height          =   1335
      Left            =   120
      TabIndex        =   0
      Top             =   1560
      Width           =   6255
      Begin ComctlLib.Slider sldBitrate 
         Height          =   495
         Left            =   120
         TabIndex        =   4
         ToolTipText     =   "<<  Lower quality, smaller file --- Higher quality, bigger file >>"
         Top             =   240
         Width           =   6015
         _ExtentX        =   10610
         _ExtentY        =   873
         _Version        =   327682
         LargeChange     =   1
         Min             =   1
         Max             =   8
         SelStart        =   5
         Value           =   5
      End
      Begin VB.Label lblBitrate 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "128kbps (quite high - recommended)"
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   840
         Width           =   5895
      End
   End
   Begin AMovieCtl.ActiveMovie ActPlayer 
      Height          =   750
      Left            =   2325
      TabIndex        =   26
      Top             =   2625
      Visible         =   0   'False
      Width           =   3990
      _ExtentX        =   7038
      _ExtentY        =   1323
      ShowDisplay     =   0   'False
      ShowControls    =   0   'False
      AllowChangeDisplayMode=   0   'False
   End
   Begin VB.Label lblFile 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "No File Selected!"
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   2280
      TabIndex        =   18
      ToolTipText     =   "No File Selected!"
      Top             =   6000
      Width           =   4095
      WordWrap        =   -1  'True
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Uses L.A.M.E. Encoder --- www.mp3dev.org"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   161
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   270
      Left            =   150
      TabIndex        =   17
      Top             =   6825
      Width           =   6255
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Index           =   0
      Begin VB.Menu nmnBrowse 
         Caption         =   "&Browse for File..."
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuDash987 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuConvert 
      Caption         =   "&Convert"
      Begin VB.Menu nmnEncode 
         Caption         =   "Encode"
         Enabled         =   0   'False
         Shortcut        =   ^E
      End
      Begin VB.Menu nmnDecode 
         Caption         =   "Decode"
         Enabled         =   0   'False
         Shortcut        =   ^D
      End
      Begin VB.Menu mnuDash223 
         Caption         =   "-"
      End
      Begin VB.Menu nmnPreview 
         Caption         =   "Preview (last encoded)"
         Enabled         =   0   'False
         Shortcut        =   ^P
      End
   End
   Begin VB.Menu mnuProfiles 
      Caption         =   "&Profiles"
      Begin VB.Menu mnuLabel1 
         Caption         =   "Low Quality Profiles"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuDash102 
         Caption         =   "-"
      End
      Begin VB.Menu p1Low 
         Caption         =   "Lowest Qualtiy (Smallest File)"
      End
      Begin VB.Menu p2Email 
         Caption         =   "E-Mail Attachment"
      End
      Begin VB.Menu p3Radio 
         Caption         =   "Radio Quality"
      End
      Begin VB.Menu mnuDash101 
         Caption         =   "-"
      End
      Begin VB.Menu mnuLabel2 
         Caption         =   "Good Quality Profiles"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuDash8 
         Caption         =   "-"
      End
      Begin VB.Menu p4Equal 
         Caption         =   "Quality and Size"
      End
      Begin VB.Menu p5Default 
         Caption         =   "Default Settings"
      End
      Begin VB.Menu p6Recommended 
         Caption         =   "Recommended Settings"
      End
      Begin VB.Menu mnuDash215 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCDQ 
         Caption         =   "CD Quality Profiles"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuDash132 
         Caption         =   "-"
      End
      Begin VB.Menu p7CDQuality 
         Caption         =   "CD Quality"
      End
      Begin VB.Menu p8BCD 
         Caption         =   "Better than CD Quality"
      End
      Begin VB.Menu mnuDash125 
         Caption         =   "-"
      End
      Begin VB.Menu mnuBQ 
         Caption         =   "Best Quality Profiles"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuDash255 
         Caption         =   "-"
      End
      Begin VB.Menu p9Studio 
         Caption         =   "Studio Quality"
      End
      Begin VB.Menu p10Best 
         Caption         =   "Best Possible Quality"
      End
      Begin VB.Menu mnuDash222 
         Caption         =   "-"
      End
      Begin VB.Menu mnuUser 
         Caption         =   "User Profiles"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuDash356 
         Caption         =   "-"
      End
      Begin VB.Menu pMyProfile 
         Caption         =   "My Profile"
         Shortcut        =   ^M
      End
      Begin VB.Menu mnuSaveP 
         Caption         =   "Save Current Settings as My Profile"
         Shortcut        =   ^S
      End
   End
   Begin VB.Menu mnuAdvanced 
      Caption         =   "&Advanced"
      Begin VB.Menu mnuOpenF 
         Caption         =   "Open Fo&lder of File"
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuDash3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuDeleteWAV 
         Caption         =   "&Delete WAV File"
         Shortcut        =   +{DEL}
      End
   End
   Begin VB.Menu mnuhelp 
      Caption         =   "&Help"
      Index           =   1
      Begin VB.Menu mnuSubhelp 
         Caption         =   "Hel&p"
      End
      Begin VB.Menu mnuDash2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuVisitWeb 
         Caption         =   "&Visit W2M Website"
      End
      Begin VB.Menu mnuAbout 
         Caption         =   "Abou&t"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'This program is free software; you can redistribute it and/or
'modify it under the terms of the GNU General Public License as
'published by the Free Software Foundation; either version 2 of
'the License, or (at your option) any later version.

Dim string2save As String
Dim Bitrate As Integer
Dim QVS As String
Dim CType As String
Dim Artist As String, Album As String, song As String, Genre As String, YearI As String
Dim LeftVal As Integer
Dim RetVal As String
Dim GuidFile As String
Dim NewFile As String
Dim closer As Integer
Dim toggle As Integer
Dim index(1 To 255) As Integer
Dim genrename As String
Dim counter As Integer
Dim CTypeInput
Dim BitrateV, QualV
Dim KillQues As VbMsgBoxResult
Const quot = """"
Dim ID
Dim MyMsg


Private Sub cmbGenre_Click()
    counter = (cmbGenre.ListIndex + 1)
End Sub

Private Sub cmdDecode_Click()

On Error GoTo ErrorCatcher
cmdPreview.Enabled = False
nmnPreview.Enabled = False

NewFile = ""

    If lblFile.Caption = "No File Selected!" Then
        MsgBox "You haven't selected a file! Click on Browse for File to choose one."
        Exit Sub
    End If
    
Dim RightExt
RightExt = Right(dlgMain.FileName, 3)

If RightExt <> "mp3" Then
MsgBox "You haven't selected a MP3 file!"
Exit Sub
End If

Dim StartProc
StartProc = MsgBox("When you click OK, the file will be copied to a temporary location, this may take a few moments. Click OK to continue.", vbOKCancel, "Wav2MP3 Wizard")
If StartProc = vbOK Then
Else
Exit Sub
End If

LeftVal = Len(dlgMain.FileName) - 3

FileCopy dlgMain.FileName, "c:\temp.mp3"
string2save = App.Path & "\lame.exe --decode c:\temp.mp3"
RetVal = Shell(string2save, vbNormalFocus)

MsgBox "Please wait for the opened Command Line (DOS) window to close, then press OK."

NewFile = Left(dlgMain.FileName, LeftVal) & "wav"

FileCopy "c:\temp.mp3.wav", NewFile
KillFile "c:\temp.mp3"
KillFile "c:\temp.mp3.wav"

MsgBox "Decoding Done!"

Exit Sub

ErrorCatcher:
    MsgBox "There was an error in the Encoding process."
    KillFile "c:\temp.mp3"
    KillFile "c:\temp.mp3.wav"
End Sub

Private Sub cmdEncode_Click()
    RetVal = ""
'   Commented out for testing purposes. IMPORTANT! Uncomment this for final!
    On Error GoTo ErrorCatcher
    
    cmdPreview.Enabled = False
    nmnPreview.Enabled = False
    NewFile = ""

    If lblFile.Caption = "No File Selected!" Then
        MsgBox "You haven't selected a file! Click on Browse for File to choose one."
        Exit Sub
    End If



    'Compression Type Set
    If optCBR.Value = True Then
        CType = " -b "
    ElseIf optAB.Value = True Then
        CType = " --abr "
    End If

    'Quality vs. Speed Set
    If sldQual.Value = 1 Then
        QVS = " -f"
    ElseIf sldQual.Value = 2 Then
        QVS = ""
    ElseIf sldQual.Value = 3 Then
        QVS = " -h"
    End If

    'Bitrate Set
    If sldBitrate.Value = 1 Then
        Bitrate = "32"
    ElseIf sldBitrate.Value = 2 Then
        Bitrate = "56"
    ElseIf sldBitrate.Value = 3 Then
        Bitrate = "80"
    ElseIf sldBitrate.Value = 4 Then
        Bitrate = "96"
    ElseIf sldBitrate.Value = 5 Then
        Bitrate = "128"
    ElseIf sldBitrate.Value = 6 Then
        Bitrate = "160"
    ElseIf sldBitrate.Value = 7 Then
        Bitrate = "192"
    ElseIf sldBitrate.Value = 8 Then
        Bitrate = "256"
    End If
    


    'Artist
    If txtArtist.Text = "" Then
        Artist = ""
    Else
        Artist = " --ta " & quot & txtArtist.Text & quot
    End If

    'Song
    If txtSong.Text = "" Then
        song = ""
    Else
        song = " --tt " & quot & txtSong.Text & quot
    End If

    'Album
    If txtAlbum.Text = "" Then
        Album = ""
    Else
        Album = " --tl " & quot & txtAlbum.Text & quot
    End If

'    Genre
    If cmbGenre.ListIndex = -1 Then
        Genre = ""
    Else
        Genre = " --tg " & quot & cmbGenre.List(cmbGenre.ListIndex) & quot
    End If
    
    'Year
    If txtYear.Text = "" Then
        YearI = ""
    Else
            YearI = " --ty " & txtYear.Text
    End If

    LeftVal = Len(dlgMain.FileName) - 3
    string2save = App.Path & "\lame.exe" & QVS & CType & Bitrate & Artist & song & Album & Genre & YearI & " " & "c:\temp.wav"
    
    'Testing purposes only! Please comment for retail!
    'MsgBox string2save
    
    'Converting Process
    Dim StartProc
StartProc = MsgBox("When you click OK, the file will be copied to a temporary location, this may take a few moments. Click OK to continue.", vbOKCancel, "Wav2MP3 Wizard")
    If StartProc = vbOK Then
    Else
    Exit Sub
    End If
    
    FileCopy dlgMain.FileName, "c:\temp.wav"
    RetVal = Shell(string2save, vbNormalFocus)
    
    NewFile = Left(dlgMain.FileName, LeftVal) & "mp3"

    MsgBox "Please wait for the opened Command Line (DOS) window to close, then press OK."

    ActPlayer.FileName = ""
    FileCopy "c:\temp.wav.mp3", NewFile
    KillFile "c:\temp.wav"
    KillFile "c:\temp.wav.mp3"
    MsgBox "Encoding Done!"
    cmdPreview.Enabled = True
    nmnPreview.Enabled = True
    ActPlayer.FileName = NewFile
    ActPlayer.Visible = False
    cmdPreview.ToolTipText = NewFile
    Exit Sub

ErrorCatcher:
    MsgBox "There was an error in the Encoding process."
    KillFile "c:\temp.wav"
    KillFile "c:\temp.wav.mp3"

End Sub
Private Sub KillFile(FileName As String)
    On Error Resume Next
    Kill FileName
End Sub
Private Sub cmdBrowse_Click()
On Error GoTo errhandler
    dlgMain.ShowOpen
    lblFile.Caption = dlgMain.FileTitle
errhandler:
End Sub


Private Sub cmdIDshow_Click()
    If toggle = 1 Then
        frmMain.Height = 7950
        cmdBrowse.Top = 5880
        cmdEncode.Top = 6360
        cmdDecode.Top = cmdEncode.Top
        cmdPreview.Top = cmdEncode.Top
        lblFile.Top = 5955
        Label1.Top = 6825
        Frame4.Visible = True
        ActPlayer.Visible = False
        toggle = 0
        cmdIDshow.Caption = "Hide IDv3 Settings <<"
    Else
        cmdIDshow.Caption = "Show IDv3 Settings >>"
        frmMain.Height = 5570
        cmdBrowse.Top = 3480
        cmdEncode.Top = 3960
        cmdDecode.Top = cmdEncode.Top
        cmdPreview.Top = cmdEncode.Top
        lblFile.Top = 3550
        Label1.Top = 4445
        ActPlayer.Visible = False
        Frame4.Visible = False
        toggle = 1
    End If
    End Sub

Private Sub cmdPreview_Click()
On Error GoTo ActPlayerBug

If cmdPreview.Caption = "Preview (last encoded)" Then
ActPlayer.Run
cmdPreview.Caption = "Stop"
cmdEncode.Enabled = False
cmdBrowse.Enabled = False
ElseIf cmdPreview.Caption = "Stop" Then
ActPlayer.Stop
cmdPreview.Caption = "Preview (last encoded)"
cmdEncode.Enabled = True
cmdBrowse.Enabled = True
End If
Exit Sub

ActPlayerBug:
ActPlayer.FileName = NewFile
ActPlayer.Run
cmdPreview.Caption = "Stop"
cmdEncode.Enabled = False
cmdBrowse.Enabled = False
End Sub

Private Sub Form_Load()

On Error GoTo CLError

    If App.PrevInstance Then
        MsgBox "There is another instance of " & quot & App.Title & quot & " running."
        End
    End If
    counter = 1
    toggle = 1
    cmdIDshow.Caption = "Show IDv3 Settings >>"
    frmMain.Height = 5570
    cmdBrowse.Top = 3480
    cmdEncode.Top = 3960
    cmdDecode.Top = cmdEncode.Top
    cmdPreview.Top = cmdEncode.Top
    lblFile.Top = 3550
    Label1.Top = 4445
    Frame4.Visible = False
    
    cmdEncode.Enabled = False
    cmdDecode.Enabled = False
        
    'Create genre list
    Open App.Path & "\genre.inf" For Input As #1

    Do While Not EOF(1)
        Input #1, index(counter), genrename
        cmbGenre.AddItem genrename
        counter = counter + 1
    Loop
    Close #1
    
    MPLoad
    
    Exit Sub
    
CLError:

MyMsg = MsgBox("The loading process of the Wav2MP3 Wizard could not be completed. Some files may be corrupted. Please re-install and if the problem persists contact one of the project members", vbCritical + vbOKOnly, "Wav2MP3 Wizard - Critical Error")
End

End Sub

Private Sub Form_Unload(Cancel As Integer)
    closer = MsgBox("Are you sure you want to exit Wav2MP3?", vbYesNo)
    
    If closer = 6 Then
        Cancel = 0
        End
    Else
        Cancel = 1
    End If
    
End Sub

Private Sub Label1_Click()
ID = Shell("c:\Program Files\Internet Explorer\iexplore.exe http://www.mp3dev.org", vbNormalFocus)
End Sub

Private Sub lblFile_Change()
    lblFile.ToolTipText = dlgMain.FileName
    
    Dim RightExt
RightExt = Right(dlgMain.FileName, 3)

If RightExt = "mp3" Then
cmdEncode.Enabled = False
cmdDecode.Enabled = True
nmnEncode.Enabled = False
nmnDecode.Enabled = True
ElseIf RightExt = "wav" Then
cmdEncode.Enabled = True
cmdDecode.Enabled = False
nmnEncode.Enabled = True
nmnDecode.Enabled = False
End If
End Sub

Private Sub mnuAbout_Click()
    frmMain.Enabled = False
    frmAbout.Show
End Sub


Private Sub mnuDeleteWAV_Click()
If lblFile.Caption = "No File Selected!" Then
Exit Sub
Else
KillQues = MsgBox("Are you sure you want to delete " & lblFile.Caption & "?", vbYesNo, "Wav2MP3 Wizard")
    If KillQues = vbYes Then
    Kill lblFile.Caption
    Else
    End If
End If
lblFile.Caption = "No File Selected!"
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuOpenF_Click()
Dim CurrentFolder
Dim Characters
Characters = Len(dlgMain.FileName) - Len(dlgMain.FileTitle)
CurrentFolder = Left(dlgMain.FileName, Characters)
ID = Shell("c:\windows\explorer.exe " & CurrentFolder, vbNormalFocus)
End Sub

Private Sub mnuSaveP_Click()

Dim CTypeOutput


If optCBR.Value = True Then
CTypeOutput = "Constant Bitrate)"
Else
CTypeOutput = "Average Bitrate)"
End If

Open App.Path & "\MyProfile.profile" For Output As #1
Write #1, sldBitrate.Value, sldQual.Value, CTypeOutput
Close #1

pMyProfile.Enabled = True

MPLoad
End Sub

Private Sub mnusubhelp_Click()
    MsgBox ("Hit F1 for help at any time.")
End Sub

Private Sub mnuVisitWeb_Click()
ID = Shell("C:\Program Files\Internet Explorer\iexplore.exe http://sourceforge.net/projects/wav2mp3lame", vbNormalFocus)
If ID = 0 Then
MsgBox "Microsoft Internet Explorer could not be found. You can still visit our site by using your favorite browser and going to: http://sourceforge.net/projects/wav2mp3lame"
End If
End Sub

Private Sub nmnBrowse_Click()
cmdBrowse_Click
End Sub

Private Sub nmnDecode_Click()
cmdDecode_Click
End Sub

Private Sub nmnEncode_Click()
cmdEncode_Click
End Sub


Private Sub nmnPreview_Click()
cmdPreview_Click
End Sub


Private Sub p10Best_Click()
sldBitrate.Value = 8
sldQual.Value = 3
optAB.Value = True
End Sub

Private Sub p1Low_Click()
sldBitrate.Value = 1
sldQual.Value = 1
optCBR.Value = True
End Sub

Private Sub p2Email_Click()
sldBitrate.Value = 2
sldQual.Value = 2
optCBR.Value = True
End Sub

Private Sub p3Radio_Click()
sldBitrate.Value = 3
sldQual.Value = 2
optCBR.Value = True
End Sub

Private Sub p4Equal_Click()
sldBitrate.Value = 4
sldQual.Value = 2
optAB.Value = True
End Sub

Private Sub p5Default_Click()
sldBitrate.Value = 5
sldQual.Value = 2
optCBR.Value = True
End Sub

Private Sub p6Recommended_Click()
sldBitrate.Value = 5
sldQual.Value = 2
optAB.Value = True
End Sub

Private Sub p7CDQuality_Click()
sldBitrate.Value = 6
sldQual.Value = 2
optCBR.Value = True
End Sub

Private Sub p8BCD_Click()
sldBitrate.Value = 7
sldQual.Value = 3
optAB.Value = True
End Sub

Private Sub p9Studio_Click()
sldBitrate.Value = 8
sldQual.Value = 2
optCBR.Value = True
End Sub

Private Sub pMyProfile_Click()

Dim BitrateV, QualV

On Error GoTo NotExist

Open App.Path & "\MyProfile.profile" For Input As #1
Input #1, BitrateV, QualV, CTypeInput
Close #1
sldBitrate.Value = BitrateV
sldQual.Value = QualV
If CTypeInput = "Constant Bitrate)" Then
optCBR.Value = True
Else
optAB.Value = True
End If
Exit Sub

NotExist:
End Sub

Private Sub sldBitrate_Change()

    Select Case sldBitrate.Value
        Case 1
            lblBitrate.Caption = "32kbps (lowest)"
        Case 2
            lblBitrate.Caption = "56kbps (low)"
        Case 3
            lblBitrate.Caption = "80kbps (below medium)"
        Case 4
            lblBitrate.Caption = "96kbps (medium)"
        Case 5
            lblBitrate.Caption = "128kbps (quite high - recommended)"
        Case 6
            lblBitrate.Caption = "160kbps (high)"
        Case 7
            lblBitrate.Caption = "192kbps (higher)"
        Case 8
            lblBitrate.Caption = "256kbps (highest)"
    End Select

End Sub

Private Sub sldBitrate_Scroll()
Select Case sldBitrate.Value
        Case 1
            lblBitrate.Caption = "32kbps (lowest)"
        Case 2
            lblBitrate.Caption = "56kbps (low)"
        Case 3
            lblBitrate.Caption = "80kbps (below medium)"
        Case 4
            lblBitrate.Caption = "96kbps (medium)"
        Case 5
            lblBitrate.Caption = "128kbps (quite high - recommended)"
        Case 6
            lblBitrate.Caption = "160kbps (high)"
        Case 7
            lblBitrate.Caption = "192kbps (higher)"
        Case 8
            lblBitrate.Caption = "256kbps (highest)"
    End Select
    
End Sub


Private Sub sldQual_Change()

Select Case sldQual.Value
    Case 1
        lblQVS.Caption = "Speed (lower quality, fastest)"
    Case 2
        lblQVS.Caption = "Normal (good quality, average speed)"
    Case 3
        lblQVS.Caption = "Quality (higher quality, slowest)"
    End Select

End Sub

Private Sub sldQual_Scroll()
    Select Case sldQual.Value
        Case 1
            lblQVS.Caption = "Speed (lower quality, fastest)"
        Case 2
            lblQVS.Caption = "Normal (good quality, average speed)"
        Case 3
            lblQVS.Caption = "Quality (higher quality, slowest)"
    End Select
End Sub

Private Sub txtYear_KeyPress(KeyAscii As Integer)
    Dim strNum As String
    strNum = "0123456789" & Chr(8)
    If InStr(strNum, Chr(KeyAscii)) = 0 Then
        KeyAscii = 0
    End If
End Sub





Public Sub MPLoad()
    On Error GoTo NotExist
    'Search for MyProfile
    Open App.Path & "\MyProfile.profile" For Input As #1
    Input #1, BitrateV, QualV, CTypeInput
    Close #1
    
    Select Case BitrateV
    Case 1
    BitrateV = "32kbps, "
    Case 2
    BitrateV = "56kbps, "
    Case 3
    BitrateV = "80kbps, "
    Case 4
    BitrateV = "96kbps, "
    Case 5
    BitrateV = "128kbps, "
    Case 6
    BitrateV = "160kbps, "
    Case 7
    BitrateV = "192kbps, "
    Case 8
    BitrateV = "256kbps, "
    End Select
    
    Select Case QualV
    Case 1
    QualV = "Speed, "
    Case 2
    QualV = "Normal, "
    Case 3
    QualV = "Quality, "
    End Select
    
  
    pMyProfile.Caption = "My Profile (" & BitrateV & QualV & CTypeInput
    
    Exit Sub
    
NotExist:
pMyProfile.Enabled = False

End Sub

Private Sub WebBrowser1_StatusTextChange(ByVal Text As String)

End Sub


