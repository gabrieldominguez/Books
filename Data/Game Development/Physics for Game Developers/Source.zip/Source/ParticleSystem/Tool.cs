using System;
using System.Collections;
using Microsoft.DirectX;

namespace ParticleSystems
{
	namespace Verlet
	{
		namespace Tools
		{
            /// <summary>
            /// Tools contains a lot of help functions intended to make it 
            /// easier for the experimenting developer.
            /// </summary>
			public class Tools
			{
				static private Random mRandom = new Random();

				private Tools()
				{
				}

				/// <summary>
				/// Generates a random number that lies within a limit
				/// </summary>
				/// <param name="min">The lower limit</param>
				/// <param name="max">The upper limit</param>
				/// <returns>A random number</returns>
				public static float GetRandomNumber(float min, float max)
				{
					return (max - min) * (float)mRandom.NextDouble() + min;
				}

				/// <summary>
				/// Generates a random number between -1 and 1
				/// </summary>
				/// <returns>A random number</returns>
				public static float GetNormalizedRandomNumber()
				{
					return GetRandomNumber(-1.0f, 1.0f);
				}

				/// <summary>
				/// Generates a normalized random vector;
				/// </summary>
				/// <returns>A normalized random vector</returns>
				public static Vector3 GetNormalizedRandomVector()
				{
					Vector3 lVector = new Vector3(
						GetNormalizedRandomNumber(), 
						GetNormalizedRandomNumber(), 
						GetNormalizedRandomNumber());
					lVector.Normalize();
					return lVector;
				}

				/// <summary>
				/// Generates a random vector of a specified length
				/// </summary>
				/// <param name="length">Length of random vector</param>
				/// <returns>A random vector of specified length</returns>
				public static Vector3 RandomVector(float length)
				{
					Vector3 lVector = GetNormalizedRandomVector();
					lVector.Multiply(length);
					return lVector;
				}

				/// <summary>
				/// Gives each particle in a particle system a random increase 
				/// of velocity in a random direction
				/// </summary>
				/// <param name="maxVelocity">Maximum speed increase</param>
				/// <param name="ps">A particle system</param>
				public static void Shake(
					float maxVelocity, 
					ParticleSystem ps)
				{
					float lTimeDelta = ps.TimeDelta;
					Particle[] lParticles = ps.Particles;

					foreach(Particle lParticle in lParticles)
					{
						lParticle.IncreaseVelocity(
							lTimeDelta, 
							RandomVector(
								maxVelocity * GetNormalizedRandomNumber()));
					}
				}

				/// <summary>
				/// ITwoParticleConstraintFactory is used by some of the 
				/// algorithms in Tools to give a developer the possibilty
				/// of controlling what constraints should be created by the 
				/// algorithm
				/// </summary>
				public interface ITwoParticleConstraintFactory
				{

                    /// <summary>
                    /// Creates a constraint between two particles and append
                    /// it too the particle system using the transaction
                    /// </summary>
                    /// <param name="transaction">A transaction</param>
                    /// <param name="particle1">A particle</param>
                    /// <param name="particle2">A particle</param>
                    void CreateConstraint(
                        ParticleSystem.Transaction transaction,
						Particle particle1, 
						Particle particle2);
				}

				/// <summary>
				/// StickConstraintFactory is an implementation of 
				/// ITwoParticleConstraintFactory that creates stick constraints
				/// </summary>
				public class StickConstraintFactory : ITwoParticleConstraintFactory
				{
					/// <summary>
					/// Constructor
					/// </summary>
					public StickConstraintFactory()
					{
					}

                    /// <summary>
                    /// Creates a constraint between two particles and append
                    /// it too the particle system using the transaction
                    /// </summary>
                    /// <param name="transaction">A transaction</param>
                    /// <param name="particle1">A particle</param>
                    /// <param name="particle2">A particle</param>
                    public void CreateConstraint(
                        ParticleSystem.Transaction transaction,
                        Particle particle1, 
                        Particle particle2)
                    {
                        transaction.AddConstraint(
                            new Constraints.Stick(particle1, particle2));
					}

				}

				/// <summary>
				/// RopeConstraintFactory is an implementation of 
				/// ITwoParticleConstraintFactory that creates rope constraints.
				/// </summary>
				public class RopeConstraintFactory : ITwoParticleConstraintFactory
				{
					/// <summary>
					/// Constructor
					/// </summary>
					public RopeConstraintFactory()
					{
						mScale = 1.0f;
					}

					/// <summary>
					/// Constructor for a RopeConstraintFactory that create
					/// Rope constraints that are enlonged by scale parameter
					/// </summary>
					/// <param name="scale">scale must be larger or equal to 1.0f</param>
					public RopeConstraintFactory(float scale)
					{
						mScale = scale;
					}

                    /// <summary>
                    /// Creates a constraint between two particles and append
                    /// it too the particle system using the transaction
                    /// </summary>
                    /// <param name="transaction">A transaction</param>
                    /// <param name="particle1">A particle</param>
                    /// <param name="particle2">A particle</param>
                    public void CreateConstraint(
                        ParticleSystem.Transaction transaction,
                        Particle particle1, 
                        Particle particle2)
                    {
                        transaction.AddConstraint(
                            new Constraints.Rope(mScale, particle1, particle2));
                    }

					private float mScale;

				}

                /// <summary>
                /// SoftStickConstraintFactory is an implementation of 
                /// ITwoParticleConstraintFactory that creates soft stick 
                /// constraints.
                /// </summary>
                public class SoftStickConstraintFactory : ITwoParticleConstraintFactory
                {
                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="stiffness">Must be be between 0.0f and 1.0f</param>
                    public SoftStickConstraintFactory(float stiffness)
                    {
                        mStiffness = stiffness;
                    }

                    /// <summary>
                    /// Creates a constraint between two particles and append
                    /// it too the particle system using the transaction
                    /// </summary>
                    /// <param name="transaction">A transaction</param>
                    /// <param name="particle1">A particle</param>
                    /// <param name="particle2">A particle</param>
                    public void CreateConstraint(
                        ParticleSystem.Transaction transaction,
                        Particle particle1, 
                        Particle particle2)
                    {
                        Constraints.SoftStick lSoftStick = 
                            new Constraints.SoftStick(mStiffness, particle1, particle2);
                        transaction.AddConstraint(lSoftStick);
                        transaction.AddEffect(lSoftStick);
                    }

                    private float mStiffness;

                }

                private static void AddParticlesToTransaction(
					ArrayList particles,
					ParticleSystem.Transaction transaction)
				{
                    foreach(Particle lParticle in particles)
                    {
                        transaction.AddParticle(lParticle);
                    }
				}


				private static Particle[] ConvertArrayListToParticleList(
					ArrayList particles)
				{
					Particle[] lParticles = new Particle[particles.Count];

					particles.CopyTo(lParticles);

					return lParticles;
				}

				/// <summary>
				/// Creates a chain of particles and constraints between two
				/// particles
				/// </summary>
				/// <param name="particle1">A particle</param>
				/// <param name="particle2">A particle</param>
				/// <param name="mass">The mass of the chain</param>
				/// <param name="links">How many links in chain</param>
				/// <param name="constraintFactory">A constraint factory</param>
				/// <param name="transaction">A transaction</param>
				/// <returns></returns>
				public static Particle[] CreateChain(
					Particle particle1,
					Particle particle2,
					float mass,
					int links,
					ITwoParticleConstraintFactory constraintFactory,
					ParticleSystem.Transaction transaction)
				{
					if( !(mass > float.Epsilon) )
					{
						throw new Exception("mass parameter must be greater than 0");
					}
					if( links < 1 )
					{
						throw new Exception("links parameter must be greater than 0");
					}

					ArrayList lCreatedParticles = new ArrayList();

					float lMass = mass / links;

					Particle lPreviousParticle = particle1;
					Vector3 lStep = (particle2.Position - particle1.Position);
					lStep.Scale(1.0f / (float)links);

					for( int lIter = 0; lIter < links - 1; ++lIter )
					{
						Vector3 lNext = lPreviousParticle.Position + lStep;

						Particle lNextParticle = new Particle(
							lMass, 
							lNext);

						lCreatedParticles.Add(lNextParticle);
						constraintFactory.CreateConstraint(
                            transaction,
							lPreviousParticle, 
							lNextParticle);

						lPreviousParticle = lNextParticle;
					}

                    constraintFactory.CreateConstraint(
                        transaction,
						lPreviousParticle, 
						particle2);

                    AddParticlesToTransaction(lCreatedParticles, transaction);
                    return ConvertArrayListToParticleList(lCreatedParticles);
				}

				/// <summary>
				/// Enables a developer to modify particles created by some
				/// algorithms in Tools before constraints are created. 
				/// Originally I thought a transform matrix would be enough
				/// but I later realized I wanted to do non-linear transforms
				/// </summary>
				public interface IParticlePreProcessor
				{
                    /// <summary>
                    /// Applies the preproccessor on a set of particles
                    /// </summary>
                    /// <param name="particles">A set of particles</param>
					void Apply(ArrayList particles);
				}

				/// <summary>
				/// Base class for particle pre processors that shall be 
				/// chainable
				/// </summary>
				public abstract class ChainableParticlePreProcessor : IParticlePreProcessor
				{
					/// <summary>
					/// Constructor
					/// </summary>
					public ChainableParticlePreProcessor()
					{
						mNextPreProcessor = null;
					}

					/// <summary>
					/// Constructor
					/// </summary>
					/// <param name="nextPreProcessor">next preprocessor in the chain</param>
					public ChainableParticlePreProcessor(IParticlePreProcessor nextPreProcessor)
					{
						mNextPreProcessor = nextPreProcessor;
					}


                    /// <summary>
                    /// Applies the preproccessor on a set of particles
                    /// </summary>
                    /// <param name="particles">A set of particles</param>
                    public void Apply(ArrayList particles)
					{
						ApplyThisPreProcessor(particles);
						if( mNextPreProcessor != null )
						{
							mNextPreProcessor.Apply(particles);
						}
					}

					/// <summary>
					/// Abstract method. Inheritors should implement this to
					/// apply their preprocessing step
					/// </summary>
					/// <param name="particles"></param>
					protected abstract void ApplyThisPreProcessor(ArrayList particles);

					private IParticlePreProcessor mNextPreProcessor;
				}

				/// <summary>
				/// Does a null transform
				/// </summary>
				public class NullParticlePreProcessor : ChainableParticlePreProcessor
				{
                    /// <summary>
                    /// Constructor
                    /// </summary>
					public NullParticlePreProcessor()
					{
					}

                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="nextPreprocessor">A IParticlePreProcessor</param>
					public NullParticlePreProcessor(IParticlePreProcessor nextPreprocessor)
						:	base(nextPreprocessor)
					{
					}

                    /// <summary>
                    /// Abstract method. Inheritors should implement this to
                    /// apply their preprocessing step
                    /// </summary>
                    /// <param name="particles">A set of particles</param>
                    override protected void ApplyThisPreProcessor(ArrayList particles)
					{
					}
				}

				/// <summary>
				/// Applies a transform matrix to all particles that should be
				/// preprocessed
				/// </summary>
				public class MatrixTransformParticlePreProcessor : ChainableParticlePreProcessor
				{
                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="transform">A transform matrix</param>
					public MatrixTransformParticlePreProcessor(Matrix transform)
					{
						mTransform = transform;
					}

                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="transform">A transform matrix</param>
                    /// <param name="nextPreprocessor">A IParticlePreProcessor </param>
					public MatrixTransformParticlePreProcessor(
						Matrix transform,
						IParticlePreProcessor nextPreprocessor)
						:	base(nextPreprocessor)
					{
						mTransform = transform;
					}

                    /// <summary>
                    /// Abstract method. Inheritors should implement this to
                    /// apply their preprocessing step
                    /// </summary>
                    /// <param name="particles">A set of particles</param>
                    override protected void ApplyThisPreProcessor(ArrayList particles)
					{
						foreach(Particle lParticle in particles)
						{
							lParticle.Transform(mTransform);
						}
					}

					private Matrix mTransform;
				}

                /// <summary>
                /// An example of a non-linear particle preprocessor. 
                /// SqueezeParticlePreProcessor "squeezes" particles towards
                /// or from origo depending of the particle's distance to a 
                /// plane and a squeeze ratio
                /// </summary>
                public class SqueezeParticlePreProcessor : Tools.ChainableParticlePreProcessor
                {
                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="planeNormal">Plane normal</param>
                    /// <param name="planeTranslation">Plane translation</param>
                    /// <param name="squeezeRatio">Squeeze ratio</param>
                    public SqueezeParticlePreProcessor(
                        Vector3 planeNormal, 
                        float planeTranslation,
                        Vector3 squeezeRatio)
                    {
                        mPlaneNormal = planeNormal;
                        mPlaneTranslation = planeTranslation;
                        mSqueezeRatio = squeezeRatio;
                    }

                    /// <summary>
                    /// Constructor
                    /// </summary>
                    /// <param name="planeNormal">Plane normal</param>
                    /// <param name="planeTranslation">Plane translation</param>
                    /// <param name="squeezeRatio">Squeeze ratio</param>
                    /// <param name="nextPreprocessor">Next preprocessor in the chain</param>
                    public SqueezeParticlePreProcessor(
                        Vector3 planeNormal, 
                        float planeTranslation,
                        Vector3 squeezeRatio,
                        IParticlePreProcessor nextPreprocessor)
                        :	base(nextPreprocessor)
                    {
                        mPlaneNormal = planeNormal;
                        mPlaneTranslation = planeTranslation;
                        mSqueezeRatio = squeezeRatio;
                    }

                    private Vector3 SqueezeVector(Vector3 v)
                    {
                        Vector3 lCopy = v;

                        float lFactor = 
                            Vector3.Dot(mPlaneNormal, lCopy) + mPlaneTranslation;

                        Vector3 lSqueezeRatio = lFactor * mSqueezeRatio;

                        lCopy.X += lCopy.X * lSqueezeRatio.X;
                        lCopy.Y += lCopy.Y * lSqueezeRatio.Y;
                        lCopy.Z += lCopy.Z * lSqueezeRatio.Z;
			
                        return lCopy;
                    }

                    /// <summary>
                    /// Applies a transform matrix to all particles that should be
                    /// preprocessed
                    /// </summary>
                    override protected void ApplyThisPreProcessor(ArrayList particles)
                    {
                        foreach(Particle lParticle in particles)
                        {
                            lParticle.Position = SqueezeVector(lParticle.Position);
                            lParticle.PreviousPosition = SqueezeVector(lParticle.PreviousPosition);
                        }
                    }

                    private Vector3 mPlaneNormal;
                    private float mPlaneTranslation;
                    private Vector3 mSqueezeRatio;
                }

                /// <summary>
				/// Creates an octahedron
				/// </summary>
				/// <param name="centerPosition">Center position of octahedron</param>
				/// <param name="mass">Mass of octahedron</param>
				/// <param name="sideLength">Side lenght of octahedron</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
				public static Particle[] CreateOctahedron(
					Vector3 centerPosition,
					float mass,
					float sideLength,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(sideLength > float.Epsilon) )
					{
						throw new Exception("sideLength parameter must be greater than 0");
					}

					Matrix lScaleMatrix = 
						Matrix.Scaling(sideLength, sideLength, sideLength);
					Matrix lTranslationMatrix = 
						Matrix.Translation(centerPosition);

					return CreateOctahedron(
						mass,
						lScaleMatrix * lTranslationMatrix,
						constraintFactory,
						transaction);
				}

				/// <summary>
				/// Creates an octahedron
				/// </summary>
				/// <param name="mass">Mass of octahedron</param>
				/// <param name="transformMatrix">Matrix used to transform particles positions</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
				public static Particle[] CreateOctahedron(
					float mass,
					Matrix transformMatrix,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					return CreateOctahedron(
						mass, 
						new MatrixTransformParticlePreProcessor(transformMatrix),
						constraintFactory,
						transaction);
				}

				/// <summary>
				/// Creates an octahedron
				/// </summary>
				/// <param name="mass">Mass of octahedron</param>
				/// <param name="preprocessor">Preprocessor applied to all created particles</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
				public static Particle[] CreateOctahedron(
					float mass,
					IParticlePreProcessor preprocessor,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(mass > float.Epsilon) )
					{
						throw new Exception("mass parameter must be greater than 0");
					}

					float lHalfSideLength = 0.5f;
					float lHalfHeight = 1.0f / (float)Math.Sqrt(2);

					Particle lTopParticle = new Particle(mass / 6.0f, new Vector3(
						0.0f, 
						+ lHalfHeight,
						0.0f));

					Particle lMiddle00Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						0.0f,
						- lHalfSideLength));

					Particle lMiddle01Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						0.0f,
						+ lHalfSideLength));

					Particle lMiddle11Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						0.0f,
						+ lHalfSideLength));

					Particle lMiddle10Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						0.0f,
						- lHalfSideLength));

					Particle lBottomParticle = new Particle(mass / 6.0f, new Vector3(
						0.0f, 
						 - lHalfHeight,
						0.0f));

					ArrayList lCreatedParticles = new ArrayList();

					lCreatedParticles.Add(lTopParticle);
					lCreatedParticles.Add(lMiddle00Particle);
					lCreatedParticles.Add(lMiddle01Particle);
					lCreatedParticles.Add(lMiddle11Particle);
					lCreatedParticles.Add(lMiddle10Particle);
					lCreatedParticles.Add(lBottomParticle);
					preprocessor.Apply(lCreatedParticles);

	                constraintFactory.CreateConstraint(transaction, lTopParticle, lMiddle00Particle);
					constraintFactory.CreateConstraint(transaction, lTopParticle, lMiddle01Particle);
					constraintFactory.CreateConstraint(transaction, lTopParticle, lMiddle11Particle);
					constraintFactory.CreateConstraint(transaction, lTopParticle, lMiddle10Particle);

					constraintFactory.CreateConstraint(transaction, lMiddle00Particle, lMiddle01Particle);
					constraintFactory.CreateConstraint(transaction, lMiddle01Particle, lMiddle11Particle);
					constraintFactory.CreateConstraint(transaction, lMiddle11Particle, lMiddle10Particle);
					constraintFactory.CreateConstraint(transaction, lMiddle10Particle, lMiddle00Particle);

					constraintFactory.CreateConstraint(transaction, lBottomParticle, lMiddle00Particle);
					constraintFactory.CreateConstraint(transaction, lBottomParticle, lMiddle01Particle);
					constraintFactory.CreateConstraint(transaction, lBottomParticle, lMiddle11Particle);
					constraintFactory.CreateConstraint(transaction, lBottomParticle, lMiddle10Particle);

                    AddParticlesToTransaction(lCreatedParticles, transaction);
                    return ConvertArrayListToParticleList(lCreatedParticles);
                }

				/// <summary>
				/// Creates a "wobbly" box. The box is actually stiff but due
				/// to its design its hard for the particle system to relax
				/// the constraints effeciently which gives the illusion of 
				/// box made out jelly. Especially on low numbers of relax
				/// iterations
				/// </summary>
				/// <param name="centerPosition">Center position of box</param>
				/// <param name="mass">Mass of box</param>
				/// <param name="sideLength">Sidelength of box</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
				public static Particle[] CreateWobblyBox(
					Vector3 centerPosition,
					float mass,
					float sideLength,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(sideLength > float.Epsilon) )
					{
						throw new Exception("sideLength parameter must be greater than 0");
					}

					Matrix lScaleMatrix = 
						Matrix.Scaling(sideLength, sideLength, sideLength);
					Matrix lTranslationMatrix = 
						Matrix.Translation(centerPosition);

					return CreateWobblyBox(
						mass,
						lScaleMatrix * lTranslationMatrix, 
						constraintFactory,
						transaction);
				}

                /// <summary>
                /// Creates a "wobbly" box. The box is actually stiff but due
                /// to its design its hard for the particle system to relax
                /// the constraints effeciently which gives the illusion of 
                /// box made out jelly. Especially on low numbers of relax
                /// iterations
                /// </summary>
                /// <param name="mass">Mass of box</param>
                /// <param name="transformMatrix">Matrix used to transform particles positions</param>
                /// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
                public static Particle[] CreateWobblyBox(
					float mass,
					Matrix transformMatrix,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					return CreateWobblyBox(
						mass,
						new MatrixTransformParticlePreProcessor(transformMatrix),
						constraintFactory,
						transaction);
				}

                /// <summary>
                /// Creates a "wobbly" box. The box is actually stiff but due
                /// to its design its hard for the particle system to relax
                /// the constraints effeciently which gives the illusion of 
                /// box made out jelly. Especially on low numbers of relax
                /// iterations
                /// </summary>
                /// <param name="mass">Mass of box</param>
                /// <param name="preprocessor">Preprocessor applied to all created particles</param>
                /// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
                public static Particle[] CreateWobblyBox(
					float mass,
					IParticlePreProcessor preprocessor,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(mass > float.Epsilon) )
					{
						throw new Exception("mass parameter must be greater than 0");
					}

					float lHalfSideLength = 0.5f;

					Particle l000Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						- lHalfSideLength,
						- lHalfSideLength));

					Particle l001Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						- lHalfSideLength,
						+ lHalfSideLength));

					Particle l010Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						+ lHalfSideLength,
						- lHalfSideLength));

					Particle l011Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						+ lHalfSideLength,
						+ lHalfSideLength));

					Particle l100Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						- lHalfSideLength,
						- lHalfSideLength));

					Particle l101Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						- lHalfSideLength,
						+ lHalfSideLength));

					Particle l110Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						+ lHalfSideLength,
						- lHalfSideLength));

					Particle l111Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						+ lHalfSideLength,
						+ lHalfSideLength));

					ArrayList lCreatedParticles = new ArrayList();

					lCreatedParticles.Add(l000Particle);
					lCreatedParticles.Add(l001Particle);
					lCreatedParticles.Add(l010Particle);
					lCreatedParticles.Add(l011Particle);
					lCreatedParticles.Add(l100Particle);
					lCreatedParticles.Add(l101Particle);
					lCreatedParticles.Add(l110Particle);
					lCreatedParticles.Add(l111Particle);
					preprocessor.Apply(lCreatedParticles);

					constraintFactory.CreateConstraint(transaction, l000Particle, l001Particle);
					constraintFactory.CreateConstraint(transaction, l001Particle, l011Particle);
					constraintFactory.CreateConstraint(transaction, l011Particle, l010Particle);
					constraintFactory.CreateConstraint(transaction, l010Particle, l000Particle);

					constraintFactory.CreateConstraint(transaction, l100Particle, l101Particle);
					constraintFactory.CreateConstraint(transaction, l101Particle, l111Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l110Particle);
					constraintFactory.CreateConstraint(transaction, l110Particle, l100Particle);

					constraintFactory.CreateConstraint(transaction, l100Particle, l000Particle);
					constraintFactory.CreateConstraint(transaction, l101Particle, l001Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l011Particle);
					constraintFactory.CreateConstraint(transaction, l110Particle, l010Particle);

					constraintFactory.CreateConstraint(transaction, l000Particle, l111Particle);
					constraintFactory.CreateConstraint(transaction, l001Particle, l110Particle);
					constraintFactory.CreateConstraint(transaction, l010Particle, l101Particle);
					constraintFactory.CreateConstraint(transaction, l011Particle, l100Particle);

                    AddParticlesToTransaction(lCreatedParticles, transaction);
                    return ConvertArrayListToParticleList(lCreatedParticles);
                }

				/// <summary>
				/// Creates a stiff box. In contrast to the "wobbly" box this
				/// box constraints are chosen so that its easier for the 
				/// particle system to relax its constraints
				/// </summary>
				/// <param name="centerPosition">Center position of box</param>
				/// <param name="mass">Mass of box</param>
				/// <param name="sideLength">Sidelength of box</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
				public static Particle[] CreateBox(
					Vector3 centerPosition,
					float mass,
					float sideLength,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(sideLength > float.Epsilon) )
					{
						throw new Exception("sideLength parameter must be greater than 0");
					}

					Matrix lScaleMatrix = 
						Matrix.Scaling(sideLength, sideLength, sideLength);
					Matrix lTranslationMatrix = 
						Matrix.Translation(centerPosition);

					return CreateBox(
						mass,
						lScaleMatrix * lTranslationMatrix, 
						constraintFactory,
						transaction);
				}

                /// <summary>
                /// Creates a stiff box. In contrast to the "wobbly" box this
                /// box constraints are chosen so that its easier for the 
                /// particle system to relax its constraints
                /// </summary>
                /// <param name="mass">Mass of box</param>
                /// <param name="transformMatrix">Matrix used to transform particles positions</param>
                /// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
                public static Particle[] CreateBox(
					float mass,
					Matrix transformMatrix,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					return CreateBox(
						mass,
						new MatrixTransformParticlePreProcessor(transformMatrix),
						constraintFactory,
						transaction);
				}

                /// <summary>
                /// Creates a stiff box. In contrast to the "wobbly" box this
                /// box constraints are chosen so that its easier for the 
                /// particle system to relax its constraints
                /// </summary>
                /// <param name="mass">Mass of box</param>
                /// <param name="preprocessor">Preprocessor applied to all created particles</param>
                /// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns>An array of particles that was created</returns>
                public static Particle[] CreateBox(
					float mass,
					IParticlePreProcessor preprocessor,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(mass > float.Epsilon) )
					{
						throw new Exception("mass parameter must be greater than 0");
					}

					float lHalfSideLength = 0.5f;

					Particle l000Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						- lHalfSideLength,
						- lHalfSideLength));

					Particle l001Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						- lHalfSideLength,
						+ lHalfSideLength));

					Particle l010Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						+ lHalfSideLength,
						- lHalfSideLength));

					Particle l011Particle = new Particle(mass / 6.0f, new Vector3(
						- lHalfSideLength, 
						+ lHalfSideLength,
						+ lHalfSideLength));

					Particle l100Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						- lHalfSideLength,
						- lHalfSideLength));

					Particle l101Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						- lHalfSideLength,
						+ lHalfSideLength));

					Particle l110Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						+ lHalfSideLength,
						- lHalfSideLength));

					Particle l111Particle = new Particle(mass / 6.0f, new Vector3(
						+ lHalfSideLength, 
						+ lHalfSideLength,
						+ lHalfSideLength));

					ArrayList lCreatedParticles = new ArrayList();

					lCreatedParticles.Add(l000Particle);
					lCreatedParticles.Add(l001Particle);
					lCreatedParticles.Add(l010Particle);
					lCreatedParticles.Add(l011Particle);
					lCreatedParticles.Add(l100Particle);
					lCreatedParticles.Add(l101Particle);
					lCreatedParticles.Add(l110Particle);
					lCreatedParticles.Add(l111Particle);
					preprocessor.Apply(lCreatedParticles);

					constraintFactory.CreateConstraint(transaction, l000Particle, l001Particle);
					constraintFactory.CreateConstraint(transaction, l001Particle, l011Particle);
					constraintFactory.CreateConstraint(transaction, l011Particle, l010Particle);
					constraintFactory.CreateConstraint(transaction, l010Particle, l000Particle);

					constraintFactory.CreateConstraint(transaction, l100Particle, l101Particle);
					constraintFactory.CreateConstraint(transaction, l101Particle, l111Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l110Particle);
					constraintFactory.CreateConstraint(transaction, l110Particle, l100Particle);

					constraintFactory.CreateConstraint(transaction, l100Particle, l000Particle);
					constraintFactory.CreateConstraint(transaction, l101Particle, l001Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l011Particle);
					constraintFactory.CreateConstraint(transaction, l110Particle, l010Particle);

					constraintFactory.CreateConstraint(transaction, l000Particle, l011Particle);
					constraintFactory.CreateConstraint(transaction, l000Particle, l110Particle);
					constraintFactory.CreateConstraint(transaction, l000Particle, l101Particle);

					constraintFactory.CreateConstraint(transaction, l111Particle, l001Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l010Particle);
					constraintFactory.CreateConstraint(transaction, l111Particle, l100Particle);

                    AddParticlesToTransaction(lCreatedParticles, transaction);
                    return ConvertArrayListToParticleList(lCreatedParticles);
                }

				private static void ConnectVerticalParticles(
					ArrayList particles,
					int numberOfParticlesAlongYAxis,
					ITwoParticleConstraintFactory constraintFactory,
					ParticleSystem.Transaction transaction)
				{
					int lCurrentParticle = 0;
					Particle lPreviousParticle = null;
					foreach(Particle lParticle in particles)
					{
						if( lCurrentParticle % numberOfParticlesAlongYAxis != 0 )
						{
							constraintFactory.CreateConstraint(
                                transaction, 
								lPreviousParticle, 
								lParticle);
						}

						lPreviousParticle = lParticle;
						++lCurrentParticle;
					}
				}

				private static void ConnectHorizontalParticles(
					ArrayList particles,
					int numberOfParticlesAlongXAxis,
					int numberOfParticlesAlongYAxis,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					for(int lXIndex = 1; lXIndex < numberOfParticlesAlongXAxis; ++lXIndex)
					{
						for(int lYIndex = 0; lYIndex < numberOfParticlesAlongYAxis; ++lYIndex)
						{
							Particle lPreviousParticle = 
								(Particle)particles[lYIndex + (lXIndex - 1)* numberOfParticlesAlongYAxis];
							Particle lParticle = 
								(Particle)particles[lYIndex + lXIndex * numberOfParticlesAlongYAxis];

							constraintFactory.CreateConstraint(
                                transaction, 
								lPreviousParticle, 
								lParticle);
						}
					}
				}

				/// <summary>
				/// Creates a mesh of particles that can be used a sails and
				/// trampolines for instance. The mesh is oriented in the X-Y
				/// plane
				/// </summary>
				/// <param name="mass">Mass of mesh</param>
				/// <param name="numberOfParticlesAlongXAxis">Number of particles along the mesh X-axis</param>
				/// <param name="numberOfParticlesAlongYAxis">Number of particles along the mesh Y-axis</param>
				/// <param name="transformMatrix">Matrix to transform the mesh particles with</param>
				/// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns></returns>
				public static Particle[] CreateMesh(
					float mass,
					int numberOfParticlesAlongXAxis,
					int numberOfParticlesAlongYAxis,
					Matrix transformMatrix,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					return CreateMesh(
						mass,
						numberOfParticlesAlongXAxis,
						numberOfParticlesAlongYAxis,
						new MatrixTransformParticlePreProcessor(transformMatrix),
						constraintFactory,
						transaction);
				}

                /// <summary>
                /// Creates a mesh of particles that can be used a sails and
                /// trampolines for instance. The mesh is oriented in the X-Y
                /// plane
                /// </summary>
                /// <param name="mass">Mass of mesh</param>
                /// <param name="numberOfParticlesAlongXAxis">Number of particles along the mesh X-axis</param>
                /// <param name="numberOfParticlesAlongYAxis">Number of particles along the mesh Y-axis</param>
                /// <param name="preprocessor">Preprocessor applied to all created particles</param>
                /// <param name="constraintFactory">A constraint factory</param>
                /// <param name="transaction">A transaction</param>
                /// <returns></returns>
                public static Particle[] CreateMesh(
					float mass,
					int numberOfParticlesAlongXAxis,
					int numberOfParticlesAlongYAxis,
					IParticlePreProcessor preprocessor,
					ITwoParticleConstraintFactory constraintFactory,
                    ParticleSystem.Transaction transaction)
                {
					if( !(mass > float.Epsilon) )
					{
						throw new Exception("mass parameter must be greater than 0");
					}
					if( numberOfParticlesAlongXAxis < 2 )
					{
						throw new Exception("links parameter must be greater than 1");
					}
					if( numberOfParticlesAlongYAxis < 2 )
					{
						throw new Exception("links parameter must be greater than 1");
					}

					float lMassPerParticle = mass / 
						(numberOfParticlesAlongXAxis * numberOfParticlesAlongYAxis);

					Vector3 lXStep = new Vector3(1.0f / (numberOfParticlesAlongXAxis - 1), 0.0f, 0.0f);
					Vector3 lYStep = new Vector3(0.0f, 1.0f / (numberOfParticlesAlongYAxis - 1), 0.0f);
					Vector3 lBorderPosition = new Vector3(-0.5f, -0.5f, 0.0f);

					ArrayList lCreatedParticles = new ArrayList();
					for( int lX = 0; lX < numberOfParticlesAlongXAxis; ++lX )
					{
						Vector3 lIterationPosition = lBorderPosition;
						for( int lY = 0; lY < numberOfParticlesAlongYAxis; ++lY )
						{
							lCreatedParticles.Add(
								new Particle(
									lMassPerParticle,
									lIterationPosition));

							lIterationPosition.Add(lYStep);
						}
						lBorderPosition.Add(lXStep);
					}
					preprocessor.Apply(lCreatedParticles);

					ConnectVerticalParticles(
						lCreatedParticles,
						numberOfParticlesAlongYAxis,
						constraintFactory,
						transaction);
					ConnectHorizontalParticles(
						lCreatedParticles,
						numberOfParticlesAlongXAxis,
						numberOfParticlesAlongYAxis,
						constraintFactory,
						transaction);

                    AddParticlesToTransaction(lCreatedParticles, transaction);
                    return ConvertArrayListToParticleList(lCreatedParticles);
                }
			}
		}
	}
}
