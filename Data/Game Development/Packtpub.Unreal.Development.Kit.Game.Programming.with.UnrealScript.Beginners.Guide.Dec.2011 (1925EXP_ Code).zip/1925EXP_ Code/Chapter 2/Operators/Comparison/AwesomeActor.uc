class AwesomeActor extends Actor
    placeable;

var int Int1, Int2;
var float Float1, Float2;
var string String1, String2;

function PostBeginPlay()
{
    `log("Int1 == Int2" @ Int1 == Int2);
    `log("Int1 != Int2" @ Int1 != Int2);
    `log("Int1 < Int2" @ Int1 < Int2);
    `log("Int1 > Int2" @ Int1 > Int2);
    `log("Int1 <= Int2" @ Int1 <= Int2);
    `log("Int1 >= Int2" @ Int1 >= Int2);
    `log("Float1 ~= Float2" @ Float1 ~= Float2);
    `log("String1 ~= String2" @ String1 ~= String2);
}

defaultproperties
{
    Int1=3
    Int2=5

    Float1=1.0
    Float2=1.000001

    String1="STRING TEST"
    String2="string test"

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
