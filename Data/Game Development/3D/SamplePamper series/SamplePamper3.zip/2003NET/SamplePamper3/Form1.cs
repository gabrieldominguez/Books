//This code is meant for learning only and is not made "code right".
//It is only made so that you can see what it does easier.
//In this sample code you're going to see the Normal vector,
//reflection vector and the light vector which is following the mouse movements.
//How to draw a 3D polygon and lines, and the use of a z buffer to see which object is in from of another.
//If you want to read more about this, you can turn to where this article came from on The Code Project author is Windmiller.

//You may use this code only for learning and not for commercial use,
//because these algorithms are mine to carry so if you want to use it by some reason,
//give me a reply on the article site and I will see what I can do.
//Leave this text in the code/project, don't cut me away!

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SamplePamper3
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		struct Poinx3D
		{
			public int X;
			public int Y;
			public int Z;
		};

		//Constants.
		const int SCREEN_WIDTH = 600;
		const int SCREEN_HEIGHT = 500;

		//Constants, where the object will be placed in screen coordinates.
		const int objPlaceX = 200;
		const int objPlaceY = 200;
		const int objPlaceZ = 100;

		static Bitmap bm = new Bitmap(SCREEN_WIDTH,SCREEN_HEIGHT);

		//Rotation numbers.
		private double temp = 0.0;
		private double temp2 = 0.0;
		private int _xmouse = 0;
		private int _ymouse = 0;

		//Create coordinates for the polygon surface.
		//Begin with the first point
		private double xx= -40.00;
		private double yy= 40.00;
		private double zz= 0.00;

		//Sec point
		private double xx2= -40.00;
		private double yy2= -40.00;
		private double zz2= 0.00;

		//Third point
		private double xx3= 40.00;
		private double yy3= -40.00;
		private double zz3= 0.00;

		//Fourth point
		private double xx4= 40.00;
		private double yy4= 40.00;
		private double zz4= 0.00;

		//Wall2
		//Create coordinates for the polygon surface.
		//Begin with the first point
		private double xx12= -40.00;
		private double yy12= 40.00;
		private double zz12= -40.00;

		//Sec point
		private double xx22= -40.00;
		private double yy22= -40.00;
		private double zz22= -40.00;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(32, 488);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(464, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "label1";
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 30;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Black;
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(512, 480);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 518);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			//Calculate sin and cos for rotation.
			temp = temp + 1.0 /60;
			temp2 = temp2 + 1.0 /280;
			double coX = Math.Cos(temp);
			double siX = Math.Sin(temp);
			double coY = Math.Cos(temp2);
			double siY = Math.Sin(temp2);

			//And the following matrix.
			//As we already have calculated.
			double lRot00 = coY;
			double lRot01 = 0;
			double lRot02 = -siY;
			//double lRot03 = 0;

			double lRot10 = siX*siY;
			double lRot11 = coX;
			double lRot12 = siX*coY;
			//double lRot13 = 0;

			double lRot20 = siY*coX;
			double lRot21 = -siX;
			double lRot22 = coX * coY;
			//double lRot23 = 0;

			//double lRot30 = 0;
			//double lRot31 = 0;
			//double lRot32 = 0;
			//double lRot33 = 1;

			//Calculate new position of point 1
			double ob1posX	= (xx*lRot00)+(yy*lRot10)+(zz*lRot20);
			double ob1posY	= (xx*lRot01)+(yy*lRot11)+(zz*lRot21);
			double ob1posZ	= (xx*lRot02)+(yy*lRot12)+(zz*lRot22);

			//Point 2
			double ob1posX2= (xx2*lRot00)+(yy2*lRot10)+(zz2*lRot20);
			double ob1posY2= (xx2*lRot01)+(yy2*lRot11)+(zz2*lRot21);
			double ob1posZ2= (xx2*lRot02)+(yy2*lRot12)+(zz2*lRot22);

			//Point 3
			double ob1posX3= (xx3*lRot00)+(yy3*lRot10)+(zz3*lRot20);
			double ob1posY3= (xx3*lRot01)+(yy3*lRot11)+(zz3*lRot21);
			double ob1posZ3= (xx3*lRot02)+(yy3*lRot12)+(zz3*lRot22);

			//Point 4
			double ob1posX4= (xx4*lRot00)+(yy4*lRot10)+(zz4*lRot20);
			double ob1posY4= (xx4*lRot01)+(yy4*lRot11)+(zz4*lRot21);
			double ob1posZ4= (xx4*lRot02)+(yy4*lRot12)+(zz4*lRot22);

			//Calculate the other wall.
			//Calculate new position of point 1
			double ob1posX12= (xx12*lRot00)+(yy12*lRot10)+(zz12*lRot20);
			double ob1posY12= (xx12*lRot01)+(yy12*lRot11)+(zz12*lRot21);
			double ob1posZ12= (xx12*lRot02)+(yy12*lRot12)+(zz12*lRot22);

			//Point 2
			double ob1posX22= (xx22*lRot00)+(yy22*lRot10)+(zz22*lRot20);
			double ob1posY22= (xx22*lRot01)+(yy22*lRot11)+(zz22*lRot21);
			double ob1posZ22= (xx22*lRot02)+(yy22*lRot12)+(zz22*lRot22);

			/////////////////
			//Time to calculate Noraml vector and the ligth
			double nx, ny, nz;
			double nx2, ny2, nz2;
			double LoN, LoN2, skr, skr2, LoL, xxx, xxx2, yyy, yyy2;
			double l1x, l1y, l1z, l2x, l2y, l2z;
			double c1x, c1y, c1z, c2x, c2y, c2z;
			double LSLx, LSLy, LSLz, LoC;
			double LSCx, LSCy, LSCz, cx;
			double su, du;

			//Calculate for wall 1
			//Calculate line segment one in the surface.
			double LS1x = (ob1posX - ob1posX2);
			double LS1y = (ob1posY - ob1posY2);
			double LS1z = (ob1posZ - ob1posZ2);

			//Calculate line segment two in the surface.
			double LS2x = (ob1posX3 - ob1posX2);
			double LS2y = (ob1posY3 - ob1posY2);
			double LS2z = (ob1posZ3 - ob1posZ2);

			//Calculattion for wall2
			//Calculate line segment one in the surface.
			double LS1x2 = (ob1posX - ob1posX22);
			double LS1y2 = (ob1posY - ob1posY22);
			double LS1z2 = (ob1posZ - ob1posZ22);

			//Calculate line segment two in the surface.
			double LS2x2 = (ob1posX12 - ob1posX22);
			double LS2y2 = (ob1posY12 - ob1posY22);
			double LS2z2 = (ob1posZ12 - ob1posZ22);

			//Calculation for wall 1
			//Cross product by two vector segments from the polygon
			//gives us the Normal-vector.
			nx =((LS1y * LS2z) - (LS1z * LS2y));
			ny = ((LS1z * LS2x) - (LS1x * LS2z));
			nz = ((LS1x * LS2y) - (LS1y * LS2x));

			//Wall 2
			//Cross product by two vector segments from the polygon
			//gives us the Normal-vector.
			nx2 =((LS1y2 * LS2z2) - (LS1z2 * LS2y2));
			ny2 = ((LS1z2 * LS2x2) - (LS1x2 * LS2z2));
			nz2 = ((LS1x2 * LS2y2) - (LS1y2 * LS2x2));

			//Wall 1
			//Length of the Normal vector (Hyp)
			LoN = Math.Sqrt(Math.Abs((nx * nx) + (ny * ny) + (nz * nz)));

			//Wall 2
			//Length of the Normal vector (Hyp)
			LoN2 = Math.Sqrt(Math.Abs((nx2 * nx2) + (ny2 * ny2) + (nz2 * nz2)));

			//Wall1
			//Normalizeing the Normal vector.
			nx=nx/Math.Abs(LoN);
			ny=ny/Math.Abs(LoN);
			nz=nz/Math.Abs(LoN);

			//Wall2
			//Normalizeing the Normal vector.
			nx2=nx2/Math.Abs(LoN2);
			ny2=ny2/Math.Abs(LoN2);
			nz2=nz2/Math.Abs(LoN2);

			//Camerans position.
			c2x = objPlaceX; c2y = objPlaceY; c2z = 400;
			//Camera is pointing to this point
			c1x = objPlaceX; c1y = objPlaceY; c1z = 0;

			//Let the light follow the mouse coordinates.
			su = _ymouse-objPlaceX;
			du = _xmouse-objPlaceY;

			//Ligth vector..
			l2x = du; l2y = su; l2z = 400;	//Ligth source
			l1x = 0; l1y = 0; l1z = 0; //Target of the light

			//Light or ligth?? vector
			LSLx = l1x - l2x;
			LSLy = l1y - l2y;
			LSLz = l1z - l2z;

			//Camera segment vector.
			LSCx = c1x - c2x;
			LSCy = c1y - c2y;
			LSCz = c1z - c2z;

			//Length of light and camera vector/segment
			LoL = Math.Sqrt(Math.Abs((LSLx * LSLx) + (LSLy * LSLy) + (LSLz * LSLz)));
			LoC = Math.Sqrt(Math.Abs((LSCx * LSCx) + (LSCy * LSCy) + (LSCz * LSCz)));

			//Silly this is.
			double ob1posXN = nx;
			double ob1posYN = ny;
			double ob1posZN = nz;

			//wall 2 silly thing!
			double ob1posXN2 = nx2;
			double ob1posYN2 = ny2;
			double ob1posZN2 = nz2;

			//Light
			//Save 'em!
			double saveLSLx = LSLx;
			double saveLSLy = LSLy;
			double saveLSLz = LSLz;

			//Normalize
			LSLx=LSLx/LoL;
			LSLy=LSLy/LoL;
			LSLz=LSLz/LoL;

			//Camera
			//Normalize
			LSCx=LSCx/LoC;
			LSCy=LSCy/LoC;
			LSCz=LSCz/LoC;

			//To calculate the angle between the Normal and the Ligth vector,
			//we are using the Dot product to accomplish this.
			//N . LSL = |N| * |LSL| * sin
			//Nx * LSLx + Ny * LSLy + Nz * LSLz = |N| * |LSL| * sin .. h�r �r |N| o |LSL|
			//Gives us..
			//(Nx * LSLx + Ny * LSLy + Nz * LSLz)/(|N| * |LSL|) = sin()
			xxx = ((nx * LSLx) + (ny * LSLy) + (nz*LSLz) ); //Wall 1
			xxx2 = ((nx2 * LSLx) + (ny2 * LSLy) + (nz2*LSLz) ); //Wall2
			cx = ((nx * LSCx) + (ny * LSCy) + (nz * LSCz));

			//Wall1
			//The angle is?
			yyy = Math.Asin(xxx);

			//Wall2
			yyy2 = Math.Asin(xxx2);

			//Wall 1
			//Convert from rad to degrees
			skr = (yyy* (180/Math.PI));

			//Wall 2
			//Convert from rad to degrees
			skr2 = (yyy2* (180/Math.PI));

			//Let light vector and camera vector work together to
			//make the light hitting the back-surface not showing on the frontside from the viewer.
			if ((xxx<=0&&cx>=0)||(xxx>0&&cx<0)){xxx=0;} //Wall1
			//if ((xxx2<=0&&cx>=0)||(xxx2>0&&cx<0)){xxx2=0;} //Wall2

			//Time to create the reflection vector!
			double Rx = 0.0; //Reflection vector.
			double Ry = 0.0; //..
			double Rz = 0.0; //..

			//Use the saved vector.
			double LnN = ((-saveLSLx)*nx)+((-saveLSLy)*ny)+((-saveLSLz)*nz); //Reflection special Dot.

			Rx = 2*LnN*nx+saveLSLx;
			Ry = 2*LnN*ny+saveLSLy;
			Rz = 2*LnN*nz+saveLSLz;

			//If surface not filled with light,
			//There will not be a reflection either!
			if (xxx==0) {Rx=0;Ry=0;Rz=0;}


			//Wall1
			Poinx3D p1,p2,p3,p4;
			p3 = new Poinx3D();
			p4 = new Poinx3D();
			p1.X = (int)ob1posX+objPlaceX;
			p1.Y = (int)ob1posY+objPlaceY;
			p1.Z = (int)ob1posZ+objPlaceZ;

			p2.X = (int)ob1posX2+objPlaceX;
			p2.Y = (int)ob1posY2+objPlaceY;
			p2.Z = (int)ob1posZ2+objPlaceZ;

			p3.X = (int)ob1posX3+objPlaceX;
			p3.Y = (int)ob1posY3+objPlaceY;
			p3.Z = (int)ob1posZ3+objPlaceZ;

			p4.X = (int)ob1posX4+objPlaceX;
			p4.Y = (int)ob1posY4+objPlaceY;
			p4.Z = (int)ob1posZ4+objPlaceZ;

			//Wall2
			Poinx3D p12,p22;
			p12.X = (int)ob1posX12+objPlaceX;
			p12.Y = (int)ob1posY12+objPlaceY;
			p12.Z = (int)ob1posZ12+objPlaceZ;

			p22.X = (int)ob1posX22+objPlaceX;
			p22.Y = (int)ob1posY22+objPlaceY;
			p22.Z = (int)ob1posZ22+objPlaceZ;

			//Clear screen
			Graphics g = Graphics.FromImage(bm);
			g.Clear(Color.Black);

			//Create a z buffer
			//This to store information about objects z order.
			uint[][] zbuffer;
			zbuffer = new uint[SCREEN_WIDTH][];
			for(int t=0;t<SCREEN_WIDTH;t++)
			{
				zbuffer[t] = new uint[SCREEN_HEIGHT];
			}
			
			//Wall 1
			//Paint our famous polygon in 3D
			Polygon3D(ref zbuffer, p1,p2,p3, Math.Abs(xxx), 255,50,50);
			Polygon3D(ref zbuffer, p1,p3,p4, Math.Abs(xxx), 255,50,50);

			//Wall2
			Polygon3D(ref zbuffer, p12,p1,p22, Math.Abs(xxx2), 147,246,124);
			Polygon3D(ref zbuffer, p1,p2,p22, Math.Abs(xxx2), 250,181,3);

			//Normal vector.
			Poinx3D norm1,norm2;
			norm1 = new Poinx3D();
			norm2 = new Poinx3D();
			norm1.X = (int)ob1posX3+objPlaceX;
			norm1.Y = (int)ob1posY3+objPlaceY;
			norm1.Z = (int)ob1posZ3+objPlaceZ;
			norm2.X = (int)(ob1posX3+ob1posXN*20)+objPlaceX;
			norm2.Y = (int)(ob1posY3+ob1posYN*20)+objPlaceY;
			norm2.Z = (int)(ob1posZ3+ob1posZN*20)+objPlaceZ;
			SpeedLine3DOP(bm,zbuffer,norm1,norm2,255,255,255);

			//Reflection vector.
			Poinx3D refl1,refl2;
			refl1 = new Poinx3D();
			refl2 = new Poinx3D();
			refl1.X = (int)l1x+objPlaceX;
			refl1.Y = (int)l1y+objPlaceY;
			refl1.Z = (int)l1z+objPlaceZ;
			refl2.X = (int)(Rx)+objPlaceX;
			refl2.Y = (int)(Ry)+objPlaceY;
			refl2.Z = (int)(Rz)+objPlaceZ;
			SpeedLine3DOP(bm,zbuffer,refl1,refl2,255,100,100);
			
			//Light vector.
			Poinx3D lig1,lig2;
			lig1 = new Poinx3D();
			lig2 = new Poinx3D();
			lig1.X = (int)l1x+objPlaceX;
			lig1.Y = (int)l1y+objPlaceY;
			lig1.Z = (int)l1z+objPlaceZ;
			lig2.X = _xmouse;
			lig2.Y = _ymouse;
			lig2.Z = (int)l2z+objPlaceZ;
			SpeedLine3DOP(bm,zbuffer,lig1,lig2,255,255,255);
			
			this.pictureBox1.Image = bm;
		
			//Just showing you some coordinates on screen.
			this.label1.Text = xxx2.ToString() + " : " + cx.ToString() + " : " + Rz.ToString();
		}

		private void Polygon3D(ref uint[][] zbuffer, Poinx3D p1, Poinx3D p2, Poinx3D p3, double intencity, int red, int green, int blue)
		{
			//Just paint something to test the z buffer
//			for(int re=170;re<190;re++)
//			{
//				Poinx3D pp1;
//				pp1.X = 100;
//				pp1.Y = re;
//				pp1.Z = 50;
//				Poinx3D ppp;
//				ppp.X = 300;
//				ppp.Y = re;
//				ppp.Z = 200;
//
//				HorizontalLine3D(bm,zbuffer,pp1,ppp,1, 0,0,255);
//			}

			//Kalla p�n d�!
			CalculatePolygon(zbuffer,p1,p2,p3, intencity, red,green,blue);
		}

		private void CalculatePolygon(uint[][] zbuffer, Poinx3D p1, Poinx3D p2, Poinx3D p3, double intencity, int red, int green, int blue)
		{
			//Used to temporary store the coordinates.
			int tempX,tempY,tempZ;

			//Change points so that the order will end up in p1<p2<p3.
			if (p1.Y > p2.Y){tempY = p1.Y; p1.Y = p2.Y; p2.Y = tempY; tempX = p1.X; p1.X = p2.X; p2.X = tempX; tempZ = p1.Z; p1.Z = p2.Z; p2.Z = tempZ;}
			if (p2.Y > p3.Y){tempY = p2.Y; p2.Y = p3.Y; p3.Y = tempY; tempX = p2.X; p2.X = p3.X; p3.X = tempX; tempZ = p2.Z; p2.Z = p3.Z; p3.Z = tempZ;}
			if (p1.Y > p2.Y){tempY = p1.Y; p1.Y = p2.Y; p2.Y = tempY; tempX = p1.X; p1.X = p2.X; p2.X = tempX; tempZ = p1.Z; p1.Z = p2.Z; p2.Z = tempZ;}

			ArrayList aR1 = new ArrayList();
			ArrayList aR2 = new ArrayList();
			ArrayList aR3 = new ArrayList();

			//Calculate the rest
			//       p1
			//       /|
			//   LS1/ |LS3
			//   p2/  |
			//      \ |
			//    LS2\|p3  
			int LS1x = p2.X-p1.X;
			int LS1y = p2.Y-p1.Y;
			int LS1z = p2.Z-p1.Z;
			int LS2x = p3.X-p2.X;
			int LS2y = p3.Y-p2.Y;
			int LS2z = p3.Z-p2.Z;
			int LS3x = p3.X-p1.X;
			int LS3y = p3.Y-p1.Y;
			int LS3z = p3.Z-p1.Z;

			int remLS1x = LS1x;
			int remLS1y = LS1y;
			int remLS1z = LS1z;
			int remLS2x = LS2x;
			int remLS2y = LS2y;
			int remLS2z = LS2z;
			int remLS3x = LS3x;
			int remLS3y = LS3y;
			int remLS3z = LS3z;

			int step_LS1x = 0;
			int step_LS1y = 1;
			int step_LS1z = 0;
			int step_LS2x = 0;
			int step_LS2y = 1;
			int step_LS2z = 0;
			int step_LS3x = 0;
			int step_LS3y = 1;
			int step_LS3z = 0;

			//Make directions.
			if(LS1x>=0)
				step_LS1x = 1;
			else
			{
				step_LS1x = -1;
				LS1x = -LS1x;
			}
			if(LS1z>=0)
				step_LS1z = 1;
			else
			{
				step_LS1z = -1;
				LS1z = -LS1z;
			}
			if(LS2x>=0)
				step_LS2x = 1;
			else
			{
				step_LS2x = -1;
				LS2x = -LS2x;
			}
			if(LS2z>=0)
				step_LS2z = 1;
			else
			{
				step_LS2z = -1;
				LS2z = -LS2z;
			}
			if(LS3x>=0)
				step_LS3x = 1;
			else
			{
				step_LS3x = -1;
				LS3x = -LS3x;
			}
			if(LS3z>=0)
				step_LS3z = 1;
			else
			{
				step_LS3z = -1;
				LS3z = -LS3z;
			}

			//Never divide with integers,
			//Better double it up by 2.
			//For the error term.
			int L2S1x = LS1x*2;
			int L2S1y = LS1y*2;
			int L2S1z = LS1z*2;
			int L2S2x = LS2x*2;
			int L2S2y = LS2y*2;
			int L2S2z = LS2z*2;
			int L2S3x = LS3x*2;
			int L2S3y = LS3y*2;
			int L2S3z = LS3z*2;

			int err_LS1x = 0;
			int err_LS1y = 0;
			int err_LS1z = 0;
			int err_LS2x = 0;
			int err_LS2y = 0;
			int err_LS2z = 0;
			int err_LS3x = 0;
			int err_LS3z = 0;
			int err_LS3y = 0;

			int x1=0,y1=0,z1=0;
			int x2=0,y2=0,z2=0;
			int x3=0,y3=0,z3=0;

			//Init error terms for the three lines
			//If linesegment 3 is x dominate?
			if(LS3x>=LS3y&&LS3x>=LS3z)
			{
				//Init err term for x,y and z.
				//From the LS3x value.
				err_LS3x = L2S3x-LS3x;
				err_LS3y = L2S3y-LS3x;
				err_LS3z = L2S3z-LS3x;
			}
			else if(LS3y>LS3x&&LS3y>LS3z)
			{
				//Else it's y dominate.
				//Init err term for x,y and z.
				err_LS3x = L2S3x-LS3y;
				err_LS3y = L2S3y-LS3y;
				err_LS3z = L2S3z-LS3y;
			}
			else //Z dominant movement.
			{
				err_LS3x = L2S3x-LS3z;
				err_LS3y = L2S3y-LS3z;
				err_LS3z = L2S3z-LS3z;
			}

			//Same for all of the rest..
			if(LS2x>=LS2y&&LS2x>=LS2z)
			{
				err_LS2x = L2S2x-LS2x;
				err_LS2y = L2S2y-LS2x;
				err_LS2z = L2S2z-LS2x;
			}
			else if(LS2y>LS2x&&LS2y>LS2z)
			{
				err_LS2x = L2S2x-LS2y;
				err_LS2y = L2S2y-LS2y;
				err_LS2z = L2S2z-LS2y;
			}
			else //Z dominant movement.
			{
				err_LS2x = L2S2x-LS2z;
				err_LS2y = L2S2y-LS2z;
				err_LS2z = L2S2z-LS2z;
			}

			if(LS1x>=LS1y&&LS1x>=LS1z)
			{
				err_LS1x = L2S1x-LS1x;
				err_LS1y = L2S1y-LS1x;
				err_LS1z = L2S1z-LS1x;
			}
			else if(LS1y>LS1x&&LS1y>LS1z)
			{
				err_LS1x = L2S1x-LS1y;
				err_LS1y = L2S1y-LS1y;
				err_LS1z = L2S1z-LS1y;
			}
			else //Z dominant movement.
			{
				err_LS1x = L2S1x-LS1z;
				err_LS1y = L2S1y-LS1z;
				err_LS1z = L2S1z-LS1z;
			}

			//Hm.. to step the tallest of 'em all.
			int storZ = ((LS3z>LS2z?LS3z:LS2z)>(LS1z)?(LS3z>LS2z?LS3z:LS2z):LS1z);
			int storXY = ((LS3x>LS2x?LS3x:LS2x)>(LS3y>LS2y?LS3y:LS2y)?(LS3x>LS2x?LS3x:LS2x):(LS3y>LS2y?LS3y:LS2y));
			storXY = ((storXY>LS1x?storXY:LS1x)>LS1y?(storXY>LS1x?storXY:LS1x):LS1y);

			//Step it through
			for(int i=0;i<(storXY>storZ?storXY:storZ);i++)
			{
				//Line segment 1 -----------------------------------------------------------------

				//If segment 1 is x dominate,
				//and it's time to step up or down?
				if(err_LS1y>=0&&i<=LS1x&&LS1x>=LS1y&&LS1x>=LS1z)
				{
					err_LS1y -= L2S1x; //We take away L2S1x from the err term.
					y1 += step_LS1y; //Step up or down.
					Poinx3D pp1 = new Poinx3D();
					pp1.X = x1+p1.X;
					pp1.Y = y1+p1.Y;
					pp1.Z = z1+p1.Z;
					aR1.Add(pp1);
				}
				//We also need to find next x step.
				//If segment 1 is still x dominate,
				//and it's time to step left or right?
				if(err_LS1x>=0&&i<=LS1x&&LS1x>=LS1y&&LS1x>=LS1z)
				{
					err_LS1x -= L2S1x; //Still the same, x dominate.
					x1 += step_LS1x; //Left or right?
				}
				//And now we want the next z in the x dominate.
				if(err_LS1z>=0&&LS1x>=LS1y&&LS1x>=LS1z&&(z1>=0?z1:-z1)<LS1z)
				{
					err_LS1z -= L2S1x; //Still x dominate.
					z1 += step_LS1z; //In or out?
				}
				//Now same thing for the y dominate.
				//If segment 1 is y dominate,
				//and it's time to step right or left?
				if(err_LS1x>=0&&i<LS1y&&LS1y>LS1x&&LS1y>LS1z)
				{
					err_LS1x -= L2S1y;
					x1 += step_LS1x;
				}
				//And we also need the next y step
				//in the y dominate movement (LS1y>LS1x).
				//Time to move up or down?
				if(err_LS1y>=0&&i<=LS1y&&LS1y>LS1x&&LS1y>LS1z)
				{
					err_LS1y -= L2S1y;
					y1 += step_LS1y;
					Poinx3D pp1 = new Poinx3D();
					pp1.X = x1+p1.X;
					pp1.Y = y1+p1.Y;
					pp1.Z = z1+p1.Z;
					aR1.Add(pp1);
				}
				//And in the y dominate, the z step.
				if(err_LS1z>=0&&LS1y>LS1x&&LS1y>LS1z&&(z1>=0?z1:-z1)<LS1z)
				{
					err_LS1z -= L2S1y;
					z1 += step_LS1z;
				}
				//If segment 1 is z dominate,
				//and it's time to step up or down?
				if(err_LS1y>=0&&i<=LS1z&&LS1z>LS1x&&LS1z>=LS1y)
				{
					err_LS1y -= L2S1z;
					y1 += step_LS1y;
					Poinx3D pp1;
					pp1.X = x1+p1.X;
					pp1.Y = y1+p1.Y;
					pp1.Z = z1+p1.Z;
					aR1.Add(pp1);
				}
				//We also need to find next x step.
				//If segment 1 is still z dominate,
				//and it's time to step left or right?
				if(err_LS1x>=0&&i<=LS1z&&LS1z>LS1x&&LS1z>=LS1y)
				{
					err_LS1x -= L2S1z;
					x1 += step_LS1x;
				}
				//And now we want the next z in the z dominate.
				if(err_LS1z>=0&&LS1z>LS1x&&LS1z>=LS1y&&(z1>=0?z1:-z1)<LS1z)
				{
					err_LS1z -= L2S1z;
					z1 += step_LS1z;
				}

				//Line segment 2 -----------------------------------------------------------------

				//If segment 2 is x dominate,
				//and it's time to step up or down?
				if(err_LS2y>=0&&i<=LS2x&&LS2x>=LS2y&&LS2x>=LS2z)
				{
					err_LS2y -= L2S2x; //We take away L2S2x from the err term.
					y2 += step_LS2y; //Step up or down.
					Poinx3D pp2 = new Poinx3D();
					pp2.X = x2+p2.X;
					pp2.Y = y2+p2.Y;
					pp2.Z = z2+p2.Z;
					aR2.Add(pp2);
				}
				//We also need to find next x step.
				//If segment 2 is still x dominate,
				//and it's time to step left or right?
				if(err_LS2x>=0&&i<=LS2x&&LS2x>=LS2y&&LS2x>=LS2z)
				{
					err_LS2x -= L2S2x; //Still the same, x dominate.
					x2 += step_LS2x; //Left or right?
				}
				//And now we want the next z in the x dominate.
				if(err_LS2z>=0&&LS2x>=LS2y&&LS2x>=LS2z&&(z2>=0?z2:-z2)<LS2z)
				{
					err_LS2z -= L2S2x; //Still x dominate.
					z2 += step_LS2z; //In or out?
				}
				//Now same thing for the y dominate.
				//If segment 2 is y dominate,
				//and it's time to step right or left?
				if(err_LS2x>=0&&i<LS2y&&LS2y>LS2x&&LS2y>LS2z)
				{
					err_LS2x -= L2S2y;
					x2 += step_LS2x;
				}
				//And we also need the next y step
				//in the y dominate movement (LS2y>LS2x).
				//Time to move up or down?
				if(err_LS2y>=0&&i<=LS2y&&LS2y>LS2x&&LS2y>LS2z)
				{
					err_LS2y -= L2S2y;
					y2 += step_LS2y;
					Poinx3D pp2 = new Poinx3D();
					pp2.X = x2+p2.X;
					pp2.Y = y2+p2.Y;
					pp2.Z = z2+p2.Z;
					aR2.Add(pp2);
				}
				//And in the y dominate, the z step.
				if(err_LS2z>=0&&LS2y>LS2x&&LS2y>LS2z&&(z2>=0?z2:-z2)<LS2z)
				{
					err_LS2z -= L2S2y;
					z2 += step_LS2z;
				}
				//If segment 2 is z dominate,
				//and it's time to step up or down?
				if(err_LS2y>=0&&i<=LS2z&&LS2z>LS2x&&LS2z>=LS2y)
				{
					err_LS2y -= L2S2z;
					y2 += step_LS2y;
					Poinx3D pp2 = new Poinx3D();
					pp2.X = x2+p2.X;
					pp2.Y = y2+p2.Y;
					pp2.Z = z2+p2.Z;
					aR2.Add(pp2);
				}
				//We also need to find next x step.
				//If segment 2 is still z dominate,
				//and it's time to step left or right?
				if(err_LS2x>=0&&i<=LS2z&&LS2z>LS2x&&LS2z>=LS2y)
				{
					err_LS2x -= L2S2z;
					x2 += step_LS2x;
				}
				//And now we want the next z in the z dominate.
				if(err_LS2z>=0&&LS2z>LS2x&&LS2z>=LS2y&&(z2>=0?z2:-z2)<LS2z)
				{
					err_LS2z -= L2S2z;
					z2 += step_LS2z;
				}

				//Line segment 3 -----------------------------------------------------------------

				//If segment 3 is x dominate,
				//and it's time to step up or down?
				if(err_LS3y>=0&&i<=LS3x&&LS3x>=LS3y&&LS3x>=LS3z)
				{
					err_LS3y -= L2S3x; //We take away L2S3x from the err term.
					y3 += step_LS3y; //Step up or down.
					Poinx3D pp3 = new Poinx3D();
					pp3.X = x3+p1.X;
					pp3.Y = y3+p1.Y;
					pp3.Z = z3+p1.Z;
					aR3.Add(pp3);
				}
				//We also need to find next x step.
				//If segment 3 is still x dominate,
				//and it's time to step left or right?
				if(err_LS3x>=0&&i<=LS3x&&LS3x>=LS3y&&LS3x>=LS3z)
				{
					err_LS3x -= L2S3x; //Still the same, x dominate.
					x3 += step_LS3x; //Left or right?
				}
				//And now we want the next z in the x dominate.
				if(err_LS3z>=0&&LS3x>=LS3y&&LS3x>=LS3z&&(z3>=0?z3:-z3)<LS3z)
				{
					err_LS3z -= L2S3x; //Still x dominate.
					z3 += step_LS3z; //In or out?
				}
				//Now same thing for the y dominate.
				//If segment 3 is y dominate,
				//and it's time to step right or left?
				if(err_LS3x>=0&&i<LS3y&&LS3y>LS3x&&LS3y>LS3z)
				{
					err_LS3x -= L2S3y;
					x3 += step_LS3x;
				}
				//And we also need the next y step
				//in the y dominate movement (LS3y>LS3x).
				//Time to move up or down?
				if(err_LS3y>=0&&i<=LS3y&&LS3y>LS3x&&LS3y>LS3z)
				{
					err_LS3y -= L2S3y;
					y3 += step_LS3y;
					Poinx3D pp3 = new Poinx3D();
					pp3.X = x3+p1.X;
					pp3.Y = y3+p1.Y;
					pp3.Z = z3+p1.Z;
					aR3.Add(pp3);
				}
				//And in the y dominate, the z step.
				if(err_LS3z>=0&&LS3y>LS3x&&LS3y>LS3z&&(z3>=0?z3:-z3)<LS3z)
				{
					err_LS3z -= L2S3y;
					z3 += step_LS3z;
				}
				//If segment 3 is z dominate,
				//and it's time to step up or down?
				if(err_LS3y>=0&&i<=LS3z&&LS3z>LS3x&&LS3z>=LS3y)
				{
					err_LS3y -= L2S3z;
					y3 += step_LS3y;
					Poinx3D pp3 = new Poinx3D();
					pp3.X = x3+p1.X;
					pp3.Y = y3+p1.Y;
					pp3.Z = z3+p1.Z;
					aR3.Add(pp3);
				}
				//We also need to find next x step.
				//If segment 3 is still z dominate,
				//and it's time to step left or right?
				if(err_LS3x>=0&&i<=LS3z&&LS3z>LS3x&&LS3z>=LS3y)
				{
					err_LS3x -= L2S3z;
					x3 += step_LS3x;
				}
				//And now we want the next z in the z dominate.
				if(err_LS3z>=0&&LS3z>LS3x&&LS3z>=LS3y&&(z3>=0?z3:-z3)<LS3z)
				{
					err_LS3z -= L2S3z;
					z3 += step_LS3z;
				}

				//Add by them selves.. to get there.
				err_LS1x += L2S1x;
				err_LS1y += L2S1y;
				err_LS1z += L2S1z;

				err_LS2x += L2S2x;
				err_LS2y += L2S2y;
				err_LS2z += L2S2z;
				
				err_LS3x += L2S3x;
				err_LS3y += L2S3y;
				err_LS3z += L2S3z;
			}
			PolyPainter(zbuffer, aR1, aR2, aR3, intencity, red, green, blue);
		}

		private void PolyPainter(uint[][] zbuffer, ArrayList aR1, ArrayList aR2, ArrayList aR3, double intencity, int red, int green, int blue)
		{
			for(int pp=0;pp<(aR1.Count<aR3.Count?aR1.Count:aR3.Count);pp++)
			{
				Poinx3D pp1;
				pp1.X = ((Poinx3D)aR1[pp]).X;
				pp1.Y = ((Poinx3D)aR1[pp]).Y;
				pp1.Z = ((Poinx3D)aR1[pp]).Z;

				Poinx3D pp3 = new Poinx3D();
				pp3.X = ((Poinx3D)aR3[pp]).X;
				pp3.Y = ((Poinx3D)aR3[pp]).Y;
				pp3.Z = ((Poinx3D)aR3[pp]).Z;

				HorizontalLine3D(bm, zbuffer, pp1, pp3, intencity, red,green,blue);
			}
			for(int p=0;p<aR2.Count-1;p++)
			{
				Poinx3D pp2;
				pp2.X = ((Poinx3D)aR2[p]).X;
				pp2.Y = ((Poinx3D)aR2[p]).Y;
				pp2.Z = ((Poinx3D)aR2[p]).Z;

				Poinx3D pp3;

				int nr = p+aR1.Count-1;
				if(nr>=0)
				{
					pp3.X = ((Poinx3D)aR3[p+aR1.Count-1]).X;
					pp3.Y = ((Poinx3D)aR3[p+aR1.Count-1]).Y;
					pp3.Z = ((Poinx3D)aR3[p+aR1.Count-1]).Z;
					HorizontalLine3D(bm,zbuffer,pp2,pp3, intencity, red,green,blue);
				}
			}
			aR1.Clear();
			aR2.Clear();
			aR3.Clear();
		}
		private void pictureBox1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			_xmouse = e.X;
			_ymouse = e.Y;
		}

		//3D horizontal line
		private Bitmap HorizontalLine3D(Bitmap bm, uint[][] zbuffer, Poinx3D p1, Poinx3D p2, double intencity, int red, int green, int blue)
		{
			//Delta lengths
			int dx = (p2.X-p1.X);
			int dz = (p2.Z-p1.Z);
			
			//Direction pointers.
			int step_x = 0;
			int step_z = 0;

			//Moving right step +1 else -1
			if(dx>=0)
				step_x = 1;
			else
			{
				step_x = -1;
				dx = -dx;
			}
			if(dz>=0)
				step_z = 1;
			else
			{
				step_z = -1;
				dz = -dz;
			}
			
			//You need this to make the err_term work.
			//Because we are using integers we must multiply with 2
			//otherwise we would just start with error 0.5
			int dx2 = dx*2; //delta X * 2 instead of 0.5
			int dz2 = dz*2; //delta Z * 2 ..

			int err_termXZ = 0;
		
			//Unified things.
			int uni1D = 0, uni2D2 = 0;
			int inc11 = 0, inc12 = 0, inc2 = 0;
			int step1D2 = 0, step2D = 0;
			int loopTo = 0, direction = 0;

			if(dx>=dz)
			{
				err_termXZ = dz2 - dx;
				direction = 0;
				loopTo = dx;
				uni1D = dx2;
				inc11 = p1.Y;
				step1D2 = step_z;
				inc12 = p1.Z;
				uni2D2 = dz2;
				inc2 = p1.X;
				step2D = step_x;
			}
			else if(dz>dx)
			{
				err_termXZ = dx2 - dz;
				direction = 2;
				loopTo = dz;
				uni1D = dz2;
				inc11 = p1.Y;
				inc12 = p1.X;
				step1D2 = step_x;
				uni2D2 = dx2;
				inc2 = p1.Z;
				step2D = step_z;
			}
			
			//Step x direction by one until the end of width.
			for(int i=0;i<=loopTo;i++)
			{
				Color cl = Color.FromArgb(red,green,blue);
				
				if(direction==0)
				{
					if(inc12>zbuffer[inc2][inc11])
					{
						//Ugly casting is going on here but we don't care so mutch in this learning code.
						cl = Color.FromArgb((int)Math.Abs(((double)red*((double)inc12*intencity/((double)(255)+(double)objPlaceZ)))),(int)Math.Abs(((double)green*((double)inc12*intencity/((double)(255)+(double)objPlaceZ)))),(int)Math.Abs(((double)blue*((double)inc12*intencity/((double)(255)+(double)objPlaceZ)))));
						bm.SetPixel(inc2,inc11,cl);
						zbuffer[inc2][inc11] = Convert.ToUInt32(inc12);
					}
				}
				if(direction==2)
				{
					if(inc2>zbuffer[inc12][inc11])
					{
						//Ugly.. ugly.. ugly casting is going on here but we don't care so mutch in this learning snippet.
						cl = Color.FromArgb((int)Math.Abs(((double)red*((double)inc2*intencity/((double)(255)+(double)objPlaceZ)))),(int)Math.Abs(((double)green*((double)inc2*intencity/((double)(255)+(double)objPlaceZ)))),(int)Math.Abs(((double)blue*((double)inc2*intencity/((double)(255)+(double)objPlaceZ)))));
						bm.SetPixel(inc12,inc11,cl);
						zbuffer[inc12][inc11]=Convert.ToUInt32(inc2);
					}
				}

				//Adjust error_term
				//This if it's time to do so.
				if(err_termXZ>=0)
				{
					err_termXZ -= uni1D;
					inc12 += step1D2;
				}
				err_termXZ += uni2D2;

				inc2 += step2D;
			}
			return bm;
		}
		//3D speeeeed line optimized!
		//This one is a x,y and z line.. we are using this one to display light, reflection and the normal vector.
		private Bitmap SpeedLine3DOP(Bitmap bm, uint[][] zbuffer, Poinx3D p1, Poinx3D p2, int red, int green, int blue)
		{
			//Delta lengths
			int dx = (p2.X-p1.X);
			int dy = (p2.Y-p1.Y);
			int dz = (p2.Z-p1.Z);
			
			//Direction pointers.
			int step_x = 0;
			int step_y = 0;
			int step_z = 0;

			//Moving right step +1 else -1
			if(dx>=0)
				step_x = 1;
			else
			{
				step_x = -1;
				dx = -dx;
			}
			if(dy>=0)
				step_y = 1;
			else
			{
				step_y = -1;
				dy = -dy;
			}
			if(dz>=0)
				step_z = 1;
			else
			{
				step_z = -1;
				dz = -dz;
			}
			
			//You need this to make the err_term work.
			//Because we are using integers we must multiply with 2
			//otherwise we would just start with error 0.5
			int dx2 = dx*2; //delta X * 2 instead of 0.5
			int dy2 = dy*2; //delta Y * 2 ..
			int dz2 = dz*2; //delta Z * 2 ..

			int err_termXY = 0;
			int err_termXZ = 0;
		
			//Unified things.
			int uni1D = 0, uni2D1 = 0, uni2D2 = 0;
			int inc11 = 0, inc12 = 0, inc2 = 0;
			int step1D1 = 0, step1D2 = 0, step2D = 0;
			int loopTo = 0, direction = 0;

			if(dx>=dy&&dx>=dz)
			{
				err_termXY = dy2 - dx;
				err_termXZ = dz2 - dx;
				direction = 0;
				loopTo = dx;
				uni1D = dx2;
				inc11 = p1.Y;
				step1D1 = step_y;
				step1D2 = step_z;
				inc12 = p1.Z;
				uni2D1 = dy2;
				uni2D2 = dz2;
				inc2 = p1.X;
				step2D = step_x;
			}
			else if(dy>dx&&dy>dz)
			{
				err_termXY = dx2 - dy;
				err_termXZ = dz2 - dy;
				direction = 1;
				loopTo = dy;
				uni1D = dy2;
				inc11 = p1.X;
				step1D1 = step_x;
				inc12 = p1.Z;
				step1D2 = step_z;
				uni2D1 = dx2;
				uni2D2 = dz2;
				inc2 = p1.Y;
				step2D = step_y;
			}
			else if(dz>dy&&dz>dx)
			{
				err_termXY = dy2 - dz;
				err_termXZ = dx2 - dz;
				direction = 2;
				loopTo = dz;
				uni1D = dz2;
				inc11 = p1.Y;
				step1D1 = step_y;
				inc12 = p1.X;
				step1D2 = step_x;
				uni2D1 = dy2;
				uni2D2 = dx2;
				inc2 = p1.Z;
				step2D = step_z;
			}
			
			//Step x direction by one until the end of width.
			for(int i=0;i<=loopTo;i++)
			{
				Color cl = Color.White;
				cl = Color.FromArgb(red,green,blue);
				
				if(direction==0)
				{
					if(inc2>=0&&inc2<SCREEN_WIDTH&&inc11>=0&&inc11<SCREEN_HEIGHT&&inc12>zbuffer[inc2][inc11])
					{
						bm.SetPixel(inc2,inc11,cl);
						zbuffer[inc2][inc11] = Convert.ToUInt32(inc12);
					}
				}
				if(direction==1)
				{
					if(inc11>=0&&inc11<SCREEN_WIDTH&&inc2>=0&&inc2<SCREEN_HEIGHT&&inc12>zbuffer[inc11][inc2])
					{
						bm.SetPixel(inc11,inc2,cl);
						zbuffer[inc11][inc2] = Convert.ToUInt32(inc12);
					}
				}
				if(direction==2)
				{
					if(inc12>=0&&inc12<SCREEN_WIDTH&&inc11>=0&&inc11<SCREEN_HEIGHT&&inc2>zbuffer[inc12][inc11])
					{
						bm.SetPixel(inc12,inc11,cl);
						zbuffer[inc12][inc11] = Convert.ToUInt32(inc2);
					}
				}

				//Adjust error_term
				//This if it's time to do so.
				if(err_termXY>=0)
				{
					err_termXY -= uni1D;
					inc11 += step1D1;
				}
				if(err_termXZ>=0)
				{
					err_termXZ -= uni1D;
					inc12 += step1D2;
				}
				err_termXY += uni2D1;
				err_termXZ += uni2D2;

				inc2 += step2D;
			}
			return bm;
		}
	}
}
