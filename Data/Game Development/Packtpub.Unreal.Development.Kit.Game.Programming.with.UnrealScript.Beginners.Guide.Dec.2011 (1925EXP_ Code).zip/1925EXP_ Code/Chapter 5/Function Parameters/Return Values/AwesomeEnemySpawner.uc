class AwesomeEnemySpawner extends AwesomeActor
    placeable;

var TestEnemy MySpawnedEnemy;
var int NumberOfCheeseburgers;

function PostBeginPlay()
{
    super.PostBeginPlay();

    `log(CanHasCheeseburger());
    `log(HowManyCheeseburgers());
}

function bool CanHasCheeseburger()
{
    return NumberOfCheeseburgers > 0;
}

function int HowManyCheeseburgers()
{
    return NumberOfCheeseburgers;
}

function SpawnEnemy()
{
    MySpawnedEnemy = spawn(class'TestEnemy', self,, Location);
}

function EnemyDied()
{
    SpawnEnemy();
}

function FreezeEnemy()
{
    if(MySpawnedEnemy != none)
        MySpawnedEnemy.Freeze();
}

defaultproperties
{
    NumberOfCheeseburgers=4
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}