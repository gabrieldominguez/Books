VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxGlyph"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'---------------------------------------------------------------------------------
'FUNCTION:
'This class holds the information for a single character.
'AUTHOR:  edx - edx@hk.super.net, Feb 98
'   - derived from 3dText SDK sample
'HISTORY: - modified to use updated glxCtl, April 98
'   - moved into OCX, May 98
'---------------------------------------------------------------------------------
Public Enum glxFontFormat
    glxLINES = 0
    glxPOLYGONS = 1
End Enum
Public listNum&       ' display list number
Public sKey$
'Dim m_Glyph$  '  glyph value (the character)
'The lpgmf parameter returns a GLYPHMETRICSFLOAT structure that contains
'information about the placement and orientation of each glyph
'in a character cell.
'returned by wglUseFontOutlines
Dim lpgmf(1 To 1) As GLYPHMETRICSFLOAT      ' ptr to glyphmetrics

Private Sub Class_Initialize()
'
End Sub

Private Sub Class_Terminate()
If listNum Then
    glDeleteLists listNum, 1
End If
End Sub

'Public Property Get glyph() As String
'glyph = m_Glyph
'End Property

'Public Property Let Glyph(ByVal char As String)
'm_Glyph = char
'End Property

Public Property Get gmBlackBoxX() As Single
gmBlackBoxX = lpgmf(1).gmfBlackBoxX
End Property

Public Property Get gmBlackBoxY() As Single
gmBlackBoxY = lpgmf(1).gmfBlackBoxY
End Property

Public Property Get gmptGlyphOriginX() As Single
gmptGlyphOriginX = lpgmf(1).gmfptGlyphOrigin.x
End Property

Public Property Get gmptGlyphOriginY() As Single
gmptGlyphOriginY = lpgmf(1).gmfptGlyphOrigin.y
End Property

Public Property Get gmCellIncX() As Single
gmCellIncX = lpgmf(1).gmfCellIncX
End Property


Public Property Get gmCellIncY() As Single
gmCellIncY = lpgmf(1).gmfCellIncY
End Property


'/******************************Public*Routine******************************\
'* Calls wglUseFontOutlines() to create a command list for the supplied
'* character.
'* Allocates memory for the characters glyphmetrics as well
'-------------------------------------------------------------------------
Public Function Create(ByVal c$, Optional nFormat As glxFontFormat = glxPOLYGONS, _
            Optional Extrusion! = 0.1, _
            Optional ChordalDeviation! = 0) As Boolean
    c = Left$(c, 1)
    If listNum Then
        glDeleteLists listNum, 1
    End If
    listNum = glGenLists(1)
    Create = wglUseFontOutlines(UC.hDC, Asc(c), 1, listNum, _
               ChordalDeviation, _
               Extrusion, _
                nFormat, lpgmf(1))
End Function

'similar to above, uses precreated font
Public Function CreateFromFont(ByVal c$, ByVal hFont&, _
            Optional nFormat As glxFontFormat = glxPOLYGONS, _
            Optional Extrusion! = 0.1, _
            Optional ChordalDeviation! = 0) As Boolean
Dim hOld&
    With UC
    hOld = SelectObject(.hDC, hFont)
    Create c, nFormat, Extrusion, ChordalDeviation
    SelectObject .hDC, hOld
    End With
End Function

'similar to above, creates font
Public Function CreateFromFacename(ByVal c$, Facename$, ByVal PointSize&, _
            ByVal Bold As Boolean, _
            ByVal Italic As Boolean, _
            Optional nFormat As glxFontFormat = glxPOLYGONS, _
            Optional Extrusion! = 0.1, _
            Optional ChordalDeviation! = 0) As Boolean
Dim hOld&, hFont&
    With UC
    hFont = .Font.CreateFont(.hDC, Facename, PointSize, Bold, Italic)
    If hFont = 0 Then Exit Function
    hOld = SelectObject(.hDC, hFont)
    Create c, nFormat, Extrusion, ChordalDeviation
    SelectObject .hDC, hOld
    DeleteObject hFont
    End With
End Function






