#include <windows.h>
#include <scrnsave.h>
#include "Saver.h"


// Saver.cpp
// James Ward 02/10/01 (espresso@crema.co.uk)
//
// Generic Screen Saver Manager
//

//-----------------------------------------------------------------------------

// Automatically link required libraries
#ifdef  _MSC_VER
#pragma comment (lib, "opengl32")
#pragma comment (lib, "glu32")
#pragma comment (lib, "scrnsave")
#pragma comment (lib, "winmm")
#endif//_MSC_VER

//-----------------------------------------------------------------------------

const int _timeout = 1000/60;	// timer period (ms)

static Saver *_instance = NULL;	// single instance of screensaver

static HDC   _hdc    = 0;	// device context   (GL child)
static HGLRC _hrc	 = 0;	// resource context (GL child)
static HWND  _hMain  = 0;	// main window handle
static HWND  _hChild = 0;	// GL child window handle
static UINT  _timer  = 0;	// timer ID
static int   _width  = 0;	// width  (pixels)
static int   _height = 0;	// height (pixels)
static DWORD _tstart = 0;	// start time (ms)

static HPALETTE _hPalette = 0;	// palette

// Used to trigger an event if handler is installed
#define Trigger if (_instance) _instance

//-----------------------------------------------------------------------------

Saver::Saver() {
	if (!_instance) _instance = this;
}

/*virtual*/ Saver::~Saver() {
	if (this == _instance) _instance=NULL;
}

//-- Stub methods -------------------------------------------------------------

/*virtual*/ void Saver::OnCreate()  {}
/*virtual*/ void Saver::OnDestroy() {}

/*virtual*/ void Saver::OnPaint() {
	glClear(GL_COLOR_BUFFER_BIT);
	SwapBuffers();
}

/*virtual*/ void Saver::OnTimer()   {}

/*virtual*/ void Saver::OnResize(int width, int height) {
	glViewport(0,0,width,height);
}

//-----------------------------------------------------------------------------

/**
 * Force repaint to occur
 */
void Saver::Repaint() {
	if (_hChild) InvalidateRect(_hChild, NULL, FALSE);
}

/**
 * Swap display buffers
 */
void Saver::SwapBuffers() {
	if (_hdc) ::SwapBuffers(_hdc);
}

/**
 * Set timer period (milliseconds)
 */
void Saver::SetTimerInterval(int ms) {
	// destroy existing timer
	if (_timer && _hMain) KillTimer(_hMain,_timer);
	// create new timer with specified rate
	if (ms && _hMain) _timer = SetTimer(_hMain,1, ms, NULL);
}

/**
 * Returns elapsed time (ms)
 */
DWORD Saver::Ticks() const {
	return timeGetTime()-_tstart;
}

int Saver::Width() const {
	return _width;
}

int Saver::Height() const {
	return _height;
}

//-----------------------------------------------------------------------------

void CreateChild (HWND hParent);
void DestroyChild();
void SetupPalette(HDC hDC);

LRESULT WINAPI ScreenSaverProc(
	HWND	hWnd,
	UINT	message,
	WPARAM  wParam,
	LPARAM  lParam
) {
	switch (message) {
    case WM_CREATE:
		_hMain = hWnd;
		CreateChild(hWnd);
		Trigger->OnCreate();
		timeBeginPeriod(1);	// request 1ms timer resolution
		_tstart = timeGetTime();
		break;

    case WM_DESTROY:
		DestroyChild();
        PostQuitMessage(0);
		timeEndPeriod(1);	// finished with timer
        break;

	case WM_TIMER: {
		Trigger->OnTimer();
		// yield a little
		Sleep(1);
		for (MSG m; PeekMessage(&m,_hMain,WM_TIMER,WM_TIMER,PM_REMOVE););
	} break;

    default:
        return DefScreenSaverProc(hWnd, message, wParam, lParam);
	}

	return 0;
}//ScreenSaverChildProc

//-----------------------------------------------------------------------------

static LRESULT WINAPI ScreenSaverChildProc(
	HWND	hWnd,
	UINT	message,
	WPARAM  wParam,
	LPARAM  lParam
) {
	switch (message) {
	case WM_DESTROY:
		// make current in case user wishes to delete lists (for example)
		wglMakeCurrent(_hdc,_hrc);
			Trigger->OnDestroy();
		wglMakeCurrent(NULL,NULL);
        PostQuitMessage(0);
        break;

	case WM_ERASEBKGND:
		return TRUE;

	case WM_SIZE:
		_width  = LOWORD(lParam);
		_height = HIWORD(lParam);
		if ( wglMakeCurrent(_hdc,_hrc) ) {
			Trigger->OnResize(_width,_height);
			//wglMakeCurrent(NULL,NULL); // hang on to it
		}
		break;

    case WM_PAINT: {
		PAINTSTRUCT ps;
        BeginPaint(hWnd, &ps);
		// Call users OpenGL drawing code (they are responsible
		// for buffer swap, for flexibility)
		
		// Make rendering context current
		if ( wglMakeCurrent(_hdc,_hrc) ) {
			Trigger->OnPaint();
			//wglMakeCurrent(NULL,NULL); // hang on to it
		}
        EndPaint(hWnd, &ps);
	} break;

	case WM_ACTIVATE:
    case WM_ACTIVATEAPP:
    case WM_KEYDOWN:
    case WM_LBUTTONDOWN:
    case WM_MBUTTONDOWN: 
    case WM_MOUSEMOVE:
    case WM_NCACTIVATE:
    case WM_RBUTTONDOWN:
    case WM_SETCURSOR:
    case WM_SYSCOMMAND:
    case WM_SYSKEYDOWN: {
		LRESULT result;
		result = DefScreenSaverProc(hWnd, message, wParam, lParam);
        DefScreenSaverProc(_hMain, message, wParam, lParam);
        return result;
	}

    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}//ScreenSaverChildProc

//-----------------------------------------------------------------------------

BOOL WINAPI ScreenSaverConfigureDialog(
    HWND hDlg,
    UINT message,
    WPARAM wParam,
    LPARAM lParam
) {
	switch (message) {
	case WM_INITDIALOG:
		return TRUE;

    case WM_COMMAND:
		if (LOWORD(wParam) == IDOK) EndDialog(hDlg, TRUE);
		return TRUE;
	}
    
	return FALSE;
}//ScreenSaverConfigureDialog

//-----------------------------------------------------------------------------

BOOL WINAPI RegisterDialogClasses(
    HANDLE hInst
) {
	return TRUE;
}//RegisterDialogClasses

//-----------------------------------------------------------------------------

static void CreateChild(HWND hParent) {
	// Window class structure
	WNDCLASS wc;
	memset(&wc,0,sizeof(wc));
	wc.style = CS_VREDRAW | CS_HREDRAW | CS_OWNDC;
	wc.lpfnWndProc = (WNDPROC)ScreenSaverChildProc;
	wc.hInstance = hMainInstance;
	wc.lpszClassName = "SCRCLASS";

	// Register the window class
	RegisterClass(&wc);

	// Get window size from desktop
	int width, height;
	{
		RECT rect;
		GetClientRect(hParent,&rect);
		HDC hdc = GetDC(hParent);
		width  = rect.right;
		height = rect.bottom;
		ReleaseDC(hParent,hdc);
	}

	// Create the OpenGL child
	_hChild = CreateWindow(
		wc.lpszClassName,
		"GLSave",
		WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
		0, 0, width, height,	// Fill entirity of parent rect
		hParent,
		NULL,
		hMainInstance,
		NULL
	);

	// Setup pixel format descriptor
	PIXELFORMATDESCRIPTOR pfd;
	memset(&pfd, 0, sizeof(pfd));
	pfd.nSize = sizeof(pfd);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 32;
	pfd.iLayerType = PFD_MAIN_PLANE;

	// Select closest pixel format
	_hdc = GetDC(_hChild);
	int glPixForm = ChoosePixelFormat(_hdc, &pfd);
	SetPixelFormat(_hdc, glPixForm, &pfd);

	// Install palette if required
	SetupPalette(_hdc);

	// Create rendering context
	_hrc = wglCreateContext(_hdc);

	// Make rendering context current
	wglMakeCurrent(_hdc,_hrc);

	// Install timer after creating context
	_timer = SetTimer(_hMain,1, _timeout, NULL);
}//CreateChild

//-----------------------------------------------------------------------------

static void DestroyChild() {
	KillTimer(_hMain,_timer);

	wglMakeCurrent(_hdc, NULL);
	wglDeleteContext(_hrc);
	ReleaseDC(_hChild,_hdc);
}//DestroyChild

//-----------------------------------------------------------------------------

// Creates a palette. Why do we bother? Only a fool would use
// a paletted display mode :)
//
static void SetupPalette(HDC hDC) {
	// Get pixel format descriptor
	PIXELFORMATDESCRIPTOR pfd;
	DescribePixelFormat(hDC, GetPixelFormat(hDC), sizeof(pfd), &pfd);

	// Any need for a palette?
	if (!(pfd.dwFlags & PFD_NEED_PALETTE)) return;

	// Calculate number of colours from color bits
	int nColours = 1<<pfd.cColorBits;

	// Allocate memory for palette
	int size = sizeof(LOGPALETTE) + nColours*sizeof(PALETTEENTRY);
	LOGPALETTE *pPal = (LOGPALETTE*)new char[size];

	// Set up header
	pPal->palVersion    = 0x300;
	pPal->palNumEntries = nColours;

	// Bit masks for RGB components
	BYTE
		rMask = (1 << pfd.cRedBits  )-1,
		gMask = (1 << pfd.cGreenBits)-1,
		bMask = (1 << pfd.cBlueBits )-1;

	// Loop through all the palette entries
	for (int i=0; i<nColours; i++) {
		pPal->palPalEntry[i].peRed   =
			(BYTE)(255.0 * ((i>>pfd.cRedShift  ) & rMask) / (float)rMask +.5);
		pPal->palPalEntry[i].peGreen =
			(BYTE)(255.0 * ((i>>pfd.cGreenShift) & gMask) / (float)gMask +.5);
		pPal->palPalEntry[i].peBlue  =
			(BYTE)(255.0 * ((i>>pfd.cBlueShift ) & bMask) / (float)bMask +.5);
		pPal->palPalEntry[i].peFlags = 0;
	}

	// Create and install the palette
	_hPalette = CreatePalette(pPal);
	SelectPalette (hDC,_hPalette,FALSE);
	RealizePalette(hDC);

	// Free palette storage
	delete [] pPal;
}//SetupPalette

//-----------------------------------------------------------------------------
