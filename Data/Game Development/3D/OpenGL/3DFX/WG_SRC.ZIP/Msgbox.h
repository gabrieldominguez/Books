
//Message box functions
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _MSGBOX_
#define _MSGBOX_

#include <windows.h>

extern int ErrorLoadingWinGlideMessageBox(HWND, LPCSTR);
extern int WinGlideErrorMessageBox(HWND, LPCSTR);

#endif //_MSGBOX_
