Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CMain
'
Public Const PI = 3.141592654
Public xRotation!, yRotation!, zTranslation!
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Type COLOR3B
    c(0 To 2) As Byte
End Type

Type QUADVERTICES
    v(0 To 3) As Long
End Type
'names for stuff start at 100
Public Const NAME_XAXIS = 1
Public Const NAME_YAXIS = 2
Public Const NAME_ZAXIS = 3
Public Const NAME_XBOX = 4
Public Const NAME_YBOX = 5
Public Const NAME_ZBOX = 6
Public Const NAME_CENTERBOX = 7

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub




Public Sub Main()
Set gCtl = frmMain.glxCtl1
Set CX = New CMain
gCtl.Init
frmMain.Show
gCtl.Animate = True
End Sub
