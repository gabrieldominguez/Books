VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: edx - edx@hk.super.net, Feb 98
'HISTORY: - updated Oct 98
'NOTES: based on:
' *  billboard.c
' *  David Blythe, 1997
' *  An example of billboarding.  A billboard is an object that always
' *  faces toward the eye.
'   I modified this sample to be a true billboard which never changes position.
'   The original code creates a billboard around the y axis.
'*************************************************************************
Dim QID&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
'Dim deltax! ' = -.03;
'Dim deltay! ' = 2.;
Dim m_Billboard As Boolean
Dim m_Texture As Boolean
Dim m_Alpha As Boolean
Dim m_Blend As Boolean
Dim m_Scale!
Dim transx!, transy!, rotx!, roty!
Dim mot&

Private Sub Class_Initialize()
'    deltax! = -0.03
'    deltay! = 2
    m_Billboard = True
    m_Texture = True
    m_Scale = 1
    transx = 1
End Sub

Public Sub init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
Dim i&, j&, image&()
Dim Components&, width&, height&, w2&, h2&
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 3, 3, 10
        .Enabled = True
    End With
    With gCtl.Lights
        .SetAmbient 1, 1, 1
    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 0, 0, 5
        .SetTargetPos 0, 0, 0
    End With
    '
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
    '
    Components = 4
    width = 256
    height = 256
    w2 = width / 2
    h2 = height / 2
    ReDim image(0 To width * height - 1)
    For j = 0 To 255
        For i = 0 To 255
            If ((i And 32) Xor (j And 32)) Then
'                image(4 * (i + j * width) + 0) = &HFF
'                image(4 * (i + j * width) + 1) = &HFF
'                image(4 * (i + j * width) + 2) = &HFF''''
                '64 * 64
                '300 * 300
                If ((i - w2) * (i - w2) + (j - h2) * (j - h2) > 4096 And _
                    (i - w2) * (i - w2) + (j - h2) * (j - h2) < 90000) Then
                    image((i + j * width)) = &HFFFFFFFF
                Else
                    image((i + j * width)) = &HFFFFFF
                End If
            Else
'                image(4 * (i + j * width) + 0) = &H0
'                image(4 * (i + j * width) + 1) = &H0
'                image(4 * (i + j * width) + 2) = &H0
                If ((i - w2) * (i - w2) + (j - h2) * (j - h2) > 4096 And _
                    (i - w2) * (i - w2) + (j - h2) * (j - h2) < 90000) Then
                    image((i + j * width)) = &HFF000000
                Else
                    image((i + j * width)) = &H0
                End If
            End If
        Next
    Next
    glPixelStorei GL_UNPACK_ALIGNMENT, 1
    glTexEnvf GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
    glTexImage2D GL_TEXTURE_2D, 0, Components, width, height, 0, _
         GL_RGBA, GL_UNSIGNED_BYTE, image(0)
End Sub

Public Sub Draw()
Dim q!(0 To 3), i&, Angle!, X!, Y!, Z!
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    glPushAttrib GL_ALL_ATTRIB_BITS
        glDisable GL_LIGHTING
            glColor4f 0.2, 1, 0.2, 1
            glBegin GL_POLYGON
                glVertex3f -2#, -1#, -2#
                glVertex3f 2#, -1#, -2#
                glVertex3f 2#, -1#, 2#
                glVertex3f -2#, -1#, 2#
            glEnd
        glEnable GL_LIGHTING
        
        glPushMatrix
            If m_Billboard Then ' CalcMatrix
                gCtl.Trackball.GetCurrentQuat q
                Qt_ToAxis q, Angle!, X!, Y!, Z!
                glRotatef -Angle, -X, -Y, -Z
            End If
            glScalef m_Scale, m_Scale, 1
            If m_Texture Then glEnable GL_TEXTURE_2D
            glColor4f 1, 1, 1, 1
            glBegin GL_POLYGON
                glTexCoord2f 0, 0
                glVertex2f -1, -1
                glTexCoord2f 1, 0
                glVertex2f 1, -1
                glTexCoord2f 1, 1
                glVertex2f 1, 1
                glTexCoord2f 0, 1
                glVertex2f -1, 1
            glEnd
        glPopMatrix
        glDisable GL_TEXTURE_2D
    glPopAttrib
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp: ScaleUp
    Case vbKeyDown: Scaledown
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub


Public Sub MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    ' Rotate the scene with the left mouse button.
    If Button = 1 Then
        m_bMoving = True
        m_StartX = X
        m_StartY = Y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        'Pan x - m_MouseX, y - m_MouseY
    ElseIf Button = 2 Then
    End If
    m_MouseX = X
    m_MouseY = Y
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, Z#, z1!
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    'fucking VB. How do you write this?
    'Z = 1.79769313486232E308
    Z = 10000000000# ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                Debug.Print " z1 = " & items(ptr)
                z1 = items(ptr)
                ptr = ptr + 1
            '3.z2
                Debug.Print " z2 = " & items(ptr)
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < Z Then
                        Z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'don't do this, it interrupts the painting!
        'MsgBox "You picked " & Picked
        'gCtl.Render
    End If
End Sub

Public Property Let Alpha(ByVal NewValue As Boolean)
    m_Alpha = NewValue
    If m_Alpha Then
        glAlphaFunc GL_GREATER, 0.01
        glEnable GL_ALPHA_TEST
    Else
        glDisable GL_ALPHA_TEST
    End If
End Property


Public Property Let Blend(ByVal NewValue As Boolean)  'bfunc()
    m_Blend = NewValue
    If m_Blend Then
        glBlendFunc GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
        glEnable GL_BLEND
    Else
        glDisable GL_BLEND
    End If
End Property

Public Property Get Billboarding() As Boolean
Billboarding = m_Billboard
End Property

Public Property Let Billboarding(ByVal NewValue As Boolean)
m_Billboard = NewValue
End Property


Public Property Get Texturing() As Boolean
Texturing = m_Texture
End Property

Public Property Let Texturing(ByVal NewValue As Boolean)
m_Texture = NewValue
End Property

Public Sub ScaleUp()
    m_Scale = m_Scale + 0.1
End Sub

Public Sub Scaledown()
    m_Scale = m_Scale - 0.1
End Sub


'------------------------------------------------------------
Public Sub CalcMatrix()
Dim mat!(0 To 15), i&
    'this is the original sample code.
    'it looks like it just wants to work around the y-axis.
    'I don't know what the equations are or what the intent was.
    'Also, I couldn't get the inverse transform to work using
    'glMultMatrixf. Anyone gets it to work, let me know please.
        'glGetFloatv GL_MODELVIEW_MATRIX, mat(0)
        'buildRot -180 * gCtl.Ex.atan2(CDbl(mat(8)), CDbl(mat(10)) / PI), 0, 1, 0, mat
        'glMultMatrixf mat(0)
    gCtl.Trackball.GetCurrentRotMatrix mat
    'do something to get the inverse transform
    glMultMatrixf mat(0)
End Sub

Public Sub buildRot(theta!, X!, Y!, Z!, m!())
Dim d!, ct!, st!
    d = X * X + Y * Y + Z * Z
    ct = Cos(RAD(theta))
    st = Sin(RAD(theta))

    ' normalize '
    If d > 0 Then
        d = 1 / d
        X = X * d
        Y = Y * d
        Z = Z * d
    End If

    m(0) = 1: m(1) = 0: m(2) = 0: m(3) = 0
    m(4) = 0: m(5) = 1: m(6) = 0: m(7) = 0
    m(8) = 0: m(9) = 0: m(10) = 1: m(11) = 0
    m(12) = 0: m(13) = 0: m(14) = 0: m(15) = 1

    ' R = uu' + cos(theta)*(I-uu') + sin(theta)*S
    '
    ' S =  0  -z   y    u' = (x, y, z)
    '      z   0  -x
    '     -y   x   0
    '

     m(0) = X * X + ct * (1 - X * X) + st * 0
     m(4) = X * Y + ct * (0 - X * Y) + st * -Z
     m(8) = X * Z + ct * (0 - X * Z) + st * Y

     m(1) = Y * X + ct * (0 - Y * X) + st * Z
     m(5) = Y * Y + ct * (1 - Y * Y) + st * 0
     m(9) = Y * Z + ct * (0 - Y * Z) + st * -X

     m(2) = Z * X + ct * (0 - Z * X) + st * -Y
     m(6) = Z * Y + ct * (0 - Z * Y) + st * X
     m(10) = Z * Z + ct * (1 - Z * Z) + st * 0
End Sub


