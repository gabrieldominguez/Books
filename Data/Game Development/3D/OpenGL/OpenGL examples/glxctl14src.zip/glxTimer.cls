VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxTimer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: simple elapsed time class
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY: March 99 - Changed to use QueryPerformance
'-------------------------------------------------------------------------
Private Type LARGE_INTEGER
    LowPart As Long
    HighPart As Long
End Type
Private Declare Function QueryPerformanceCounter Lib "kernel32" (lpPerformanceCount As LARGE_INTEGER) As Long
Private Declare Function QueryPerformanceFrequency Lib "kernel32" (lpFrequency As LARGE_INTEGER) As Long
'
Dim m_HiRes As Boolean
'hires
Dim m_StartTime As LARGE_INTEGER
Dim m_StopTime As LARGE_INTEGER
Dim m_Frequency As Currency 'the frequency of the high-resolution performance counter
'
Dim m_StartTimeVBA As Double
Dim m_ElapsedTime As Double
Dim m_Seconds As Double

'-------------------------------------------------------------------------
'lpFrequency: Pointer to a variable that the function sets, in counts per second,
'to the current performance-counter frequency. If the installed hardware does not
'support a high-resolution performance counter, this parameter can be to zero.
'In this case use VBA Timer()
'-------------------------------------------------------------------------
Private Sub Class_Initialize()
Dim lpFrequency As LARGE_INTEGER
Dim r&
    r = QueryPerformanceFrequency(lpFrequency)
    If r Then
        m_HiRes = True
        m_Frequency = m_LargeToCur(lpFrequency)
        r = QueryPerformanceCounter(m_StartTime)
    Else 'use VBA timer
        m_StartTimeVBA = Timer
    End If
End Sub

'-------------------------------------------------------------------------
'retrieves the current value of the high-resolution performance counter
'-------------------------------------------------------------------------
Public Sub Start()
Dim r&
    If m_HiRes Then
        r = QueryPerformanceCounter(m_StartTime)
    Else
        m_StartTimeVBA = Timer
    End If
End Sub

'-------------------------------------------------------------------------
'retrieves the current value of the high-resolution performance counter and
'returns time since Start
'-------------------------------------------------------------------------
Public Function TimerStop#()
Dim r&, e#
Dim cStart As Currency
Dim cStop As Currency
    If m_HiRes Then
        r = QueryPerformanceCounter(m_StopTime)
        cStart = m_LargeToCur(m_StartTime)
        cStop = m_LargeToCur(m_StopTime)
        m_ElapsedTime = ((cStop - cStart) / m_Frequency) * 1000#
    Else
        e = Timer
        m_ElapsedTime = e - m_StartTimeVBA
        TimerStop = m_ElapsedTime
    End If
End Function

'-------------------------------------------------------------------------
'same as above
'-------------------------------------------------------------------------
Public Function ElapsedTime#()
    ElapsedTime = TimerStop
End Function

'-------------------------------------------------------------------------
'clears the elapsed time value
'-------------------------------------------------------------------------
Public Sub Reset()
    m_ElapsedTime = 0
End Sub

'-------------------------------------------------------------------------
Private Function m_LargeToCur(largeInt As LARGE_INTEGER) As Currency
    If (largeInt.LowPart) > 0& Then
        m_LargeToCur = largeInt.LowPart
    Else
        m_LargeToCur = CCur(2 ^ 31) + CCur(largeInt.LowPart And &H7FFFFFFF)
    End If
    m_LargeToCur = m_LargeToCur + largeInt.HighPart * CCur(2 ^ 32)
End Function


  
