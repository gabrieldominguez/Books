//--------------------------------------------------------------------------
// Programa Principal
// Ejemplo para Graficaci�n de Funciones
// Computaci�n II
// 20010330
//--------------------------------------------------------------------------
#include "funcion.h"   // clase TFuncionGL
//--------------------------------------------------------------------------
int main(int argc, char** argv) 
{ TFuncionGL FuncionGL;

  FuncionGL.CrearVentana(argc,argv);
  FuncionGL.Mostrar();

  return(0);
}
//--------------------------------------------------------------------------
