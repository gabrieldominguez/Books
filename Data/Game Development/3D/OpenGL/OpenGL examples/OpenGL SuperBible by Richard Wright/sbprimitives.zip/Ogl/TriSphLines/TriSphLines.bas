Attribute VB_Name = "mAtom"
Public Sub RenderScene()
    
    Dim red As GLubyte
    Dim green As GLubyte
    Dim blue As GLubyte

    Dim LineSize(1) As GLfloat
    Dim LineStep As GLfloat
    Dim LineSizeNew As GLfloat


    glClear clrColorBufferBit + clrDepthBufferBit
    glMatrixMode mmModelView
    glLoadIdentity
    
    'Enable shading
    If iFlatSmooth = 1 Then
      glShadeModel smFlat
    Else
      glShadeModel smSmooth
    End If
    
    glGetFloatv glgLineWidthRange, LineSize(0)
    glGetFloatv glgLineWidthGranularity, LineStep
    LineSizeNew = LineStep * 20
    glLineWidth LineSizeNew
    
    glPushMatrix
      glRotatef xRot, 1#, 0#, 0#
      glRotatef yRot, 0#, 1#, 0#

      'Draw the triangle
      glBegin bmTriangles
        'Red Apex
        red = 255
        green = 0
        blue = 0
        glColor3ub red, green, blue
        glVertex3f 0#, 100#, 0#
        
        'Green on the right bottom corner
        red = 0
        green = 255
        blue = 0
        glColor3ub red, green, blue
        glVertex3f 100#, -70#, 0#
        
        'Blue on the left bottom corner
        red = 0
        green = 0
        blue = 255
        glColor3ub red, green, blue
        glVertex3f -100#, -70#, 0#
    
      glEnd 'End of Triangle
      
      
      ' Red Sphere
      glTranslatef 0#, 100#, 0#
      red = 255
      green = 0
      blue = 0
      glColor3ub red, green, blue
      gluSphere quadSphere, dBallRadius, 40, 16
      
      ' Green Sphere
      glTranslatef 100#, -170#, 0#
      red = 0
      green = 255
      blue = 0
      glColor3ub red, green, blue
      gluSphere quadSphere, dBallRadius, 40, 16
        
      ' Blue Sphere
      glTranslatef -200#, 0#, 0#
      red = 0
      green = 0
      blue = 255
      glColor3ub red, green, blue
      gluSphere quadSphere, dBallRadius, 40, 16
        
    glPopMatrix

    ' White Lines
    glPushMatrix
        glShadeModel smSmooth
        glRotatef xRot, 1#, 0#, 0#
        glRotatef yRot, 0#, 1#, 0#
        red = 255
        green = 255
        blue = 255
        glColor3ub red, green, blue
        glBegin bmLineLoop
          glVertex3f 0#, 100#, 0#
          glVertex3f 100#, -70#, 0#
          glVertex3f -100#, -70#, 0#
        glEnd
    glPopMatrix

    SwapBuffers frmDisplay.hDC
    ' Flush drawing commands
    glFlush

    
    
End Sub
