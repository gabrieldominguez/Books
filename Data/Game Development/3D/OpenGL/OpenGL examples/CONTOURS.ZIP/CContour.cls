VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CContour"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Dim pts() As VERTEX
Dim ptcount&
Dim tessed As Boolean
Dim closed As Boolean
Dim list&
Const CombineListSize = 1000
Dim CombineList() As VERTEX
Dim CombineNext&

Private Sub Class_Initialize()
    ReDim pts(1 To 20)
End Sub

Private Sub Class_Terminate()
'
End Sub

Public Sub Add(x#, y#, z#)
Dim r&
    ptcount = ptcount + 1
    If ptcount > UBound(pts) Then
        ReDim Preserve pts(1 To ptcount + 20)
    End If
    pts(ptcount).Pt(0) = x
    pts(ptcount).Pt(1) = y
    pts(ptcount).Pt(2) = z
    'If z <> 0 Then Debug.Assert 0
    If ptcount > 3 Then
        If Abs(x - pts(1).Pt(0)) < 1 And _
            Abs(y - pts(1).Pt(1)) < 1 And _
            Abs(z - pts(1).Pt(2)) < 1 Then
            r = MsgBox("Close this contour?", vbYesNo)
        End If
        If r = vbYes Then
            CX.Done
        End If
    End If
End Sub

Public Sub Done()
    closed = True
End Sub

Public Sub Draw(mode&) ' As mode_type)
Dim i&
    If tessed Then
        If optLights Then glEnable GL_LIGHTING
        glCallList list
        If optLights Then glDisable GL_LIGHTING
    Else
        glColor3f 0.7, 0.7, 0
        glBegin GL_POINTS
            For i = 1 To ptcount
                glVertex3dv pts(i).Pt(0)
            Next
        glEnd
        glColor3f 1, 1, 1
        For i = 2 To ptcount
            glBegin GL_LINES
                glVertex3dv pts(i - 1).Pt(0)
                glVertex3dv pts(i).Pt(0)
            glEnd
        Next
        If closed Then
            glBegin GL_LINES
                glVertex3dv pts(ptcount).Pt(0)
                glVertex3dv pts(1).Pt(0)
            glEnd
        End If
    End If
End Sub


Public Sub Tess(winding&)
Dim tobj&
Dim i&, j&, point_cnt&
    ReDim CombineList(1 To CombineListSize)
    CombineNext = 0
    tobj = gluNewTess
    gluTessCallback tobj, GLU_TESS_BEGIN, AddressOf glBeginCB
    gluTessCallback tobj, GLU_TESS_END, AddressOf glEndCB
    gluTessCallback tobj, GLU_TESS_ERROR, AddressOf glErrorCB
    gluTessCallback tobj, GLU_TESS_VERTEX, AddressOf glVertex3dvCB
    gluTessCallback tobj, GLU_TESS_COMBINE, AddressOf CombineCB
    If list Then
        glDeleteLists list, 1
    End If
    list = glGenLists(1)
    glNewList list, lstCompile
    gluTessBeginPolygon tobj, 0&
        gluTessBeginContour tobj
        For i = 1 To ptcount
            gluTessVertex tobj, pts(i).Pt(0), pts(i).Pt(0)
        Next
        gluTessEndContour tobj
    gluTessEndPolygon tobj
    glEndList
    tessed = True
End Sub

Function AddCombinePt&(x#, y#, z#)
Dim coords#(0 To 2)
    CombineNext = CombineNext + 1
    If CombineNext > CombineListSize Then
        Debug.Assert 0
    End If
    'coords
    CombineList(CombineNext).Pt(0) = x
    CombineList(CombineNext).Pt(1) = y
    CombineList(CombineNext).Pt(2) = z
    AddCombinePt = VarPtr(CombineList(CombineNext).Pt(0))
End Function

