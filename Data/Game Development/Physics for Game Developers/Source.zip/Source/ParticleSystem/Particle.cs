using System;
using System.Diagnostics;
using Microsoft.DirectX;


namespace ParticleSystems
{
    namespace Verlet
    {
        /// <summary>
        /// Holds mass, position, previous and if the particle is immoveable.
        /// For performance reasons it holds the inverted mass in constrast
        /// to the normal mass (also the infinite mass is more easily 
        /// represented when using inverted mass)
        /// </summary>
        public class Particle
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="mass">Mass of particle</param>
            /// <param name="position">Initial position of particle</param>
            public Particle(float mass, Vector3 position)
            {
                mImmoveable = false;
                Mass = mass;	// the mass property performs sanity check of mass
                mCurrentPosition = position;
                mPreviousPosition = position;

            }

            /// <summary>
            /// Mass of particle
            /// </summary>
            public float Mass
            {
                get
                {
                    if( !mImmoveable )
                    {
                        return 1.0f/mInvertedMass;
                    }
                    else
                    {
                        return float.MaxValue;
                    }
                }

                set
                {
                    // This catches negative masses as well as zero mass. 
                    // Possible it should throw when setting a negative mass
                    float l_value = Math.Max(float.Epsilon, value);
                    mInvertedMass = 1.0f / l_value;
                }
            }

            /// <summary>
            /// Inverted mass of particle
            /// </summary>
            public float InvertedMass
            {
                get
                {
                    if( !mImmoveable )
                    {
                        return mInvertedMass;
                    }
                    else
                    {
                        return 0.0f;
                    }
                }
            }

            /// <summary>
            /// Position of particle
            /// </summary>
            public Vector3 Position
            {
                get
                {
                    return mCurrentPosition;
                }
                set 
                {
                    mCurrentPosition = value;
                }
            }

            /// <summary>
            /// Previous position of particle
            /// </summary>
            public Vector3 PreviousPosition
            {
                get
                {
                    return mPreviousPosition;
                }
                set 
                {
                    mPreviousPosition = value;
                }
            }

            /// <summary>
            /// True means that the particle's mass is infinitly large and that
            /// it's not affected by gravity. This essentially means that 
            /// particle will an immoveable point where one might attach chains
            /// and other constraints to 
            /// </summary>
            public bool Immoveable
            {
                get 
                {
                    return mImmoveable;
                }
                set 
                {
                    mImmoveable = value;
                }
            }

            /// <summary>
            /// Returns the velocity of a particle. As Particle represent the
            /// velocity of a particle in terms of the previous position the
            /// time delta must be specified when calculating the particle 
            /// velocity
            /// </summary>
            /// <param name="timeDelta">The current time delta</param>
            /// <returns>The velocity vector of the particle</returns>
            public Vector3 GetVelocity(float timeDelta)
            {
                Vector3 lTmpVector = mCurrentPosition - mPreviousPosition;
                lTmpVector.Multiply(1.0f / timeDelta);
                return lTmpVector;
            }

            /// <summary>
            /// Sets the velocity of a particle. As Particle represent the
            /// velocity of a particle in terms of the previous position the
            /// time delta must be specified when setting the particle 
            /// velocity
            /// </summary>
            /// <param name="timeDelta">The current time delta</param>
            /// <param name="velocity">The new velocity vectory of the particle</param>
            public void SetVelocity(float timeDelta, Vector3 velocity)
            {
                Vector3 lTmpVector = velocity;
                lTmpVector.Multiply(timeDelta);
                mPreviousPosition = mCurrentPosition - lTmpVector;
            }

            /// <summary>
            /// Increases the velocity of a particle by a velocity vector. 
            /// As Particle represent the velocity of a particle in terms of 
            /// the previous position the time delta must be specified when 
            /// setting the particle velocity
            /// </summary>
            /// <param name="timeDelta">The current time delta</param>
            /// <param name="velocity">The velocity vectory to be added to the particle's current velocity</param>
            public void IncreaseVelocity(float timeDelta, Vector3 velocity)
            {
                Vector3 lTmpVector = velocity;
                lTmpVector.Multiply(timeDelta);
                mPreviousPosition -= lTmpVector;
            }

            /// <summary>
            /// Transforms the particles position and previous position 
            /// (its velocity) using a transform matrix
            /// </summary>
            /// <param name="transformMatrix">The transform matrix</param>
            public void Transform(Matrix transformMatrix)
            {
                mCurrentPosition.TransformCoordinate(transformMatrix);
                mPreviousPosition.TransformCoordinate(transformMatrix);
            }

            // These are modified by particle system during the verlet integration step
            // It's possible that I use the properties defined instead, however I'm unsure
            // of the runtime penalty of using properties.
            // (premature optimization is a sin, I know, I know)
            internal float mInvertedMass;
            internal bool mImmoveable;
            internal Vector3 mCurrentPosition;
            internal Vector3 mPreviousPosition;

        }
    }
}