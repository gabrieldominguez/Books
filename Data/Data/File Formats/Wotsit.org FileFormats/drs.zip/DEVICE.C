#include <stdio.h>

#include "device.h"

void
dev_init(device*this)
{
  this->xscale=1.0;
  this->yscale=1.0;
  this->zscale=1.0;
  this->rscale=1.0;
  this->fp=stdout;
}
