VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "gleToroid"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim gc As gleGC
Dim m_ToroidRadius#
Dim m_StartRadius#
Dim m_drdTheta#
Dim m_StartZ#
Dim m_dzdTheta#
Dim m_StartTheta#
Dim m_SweepTheta#
Dim m_dXformdTheta() As gleAffine
Dim m_StartXForm() As gleAffine

Private Sub Class_Initialize()
    ReDim gc.up(0 To 2)
    gc.up(1) = 1
    gc.JoinStyle = gleANGLE
    gc.CapStyle = gleCAPS
    gc.NormStyle = gleFACET
    gc.ContourStyle = gleOPEN
End Sub

Private Sub Class_Terminate()
'
End Sub

'-------------------------------------------------------------------------== */
' * Toroid primitive
' * Uses a helical coordinate system dislocation to take a circular
' * contour along a helical path.
'public sub gleToroid (gleDouble rToroid,
'             gleDouble startRadius,
'             gleDouble drdTheta,        ' change in radius per revolution */
'             gleDouble startZ,
'             gleDouble dzdTheta,        ' change in Z per revolution */
'             gleDouble startXform(2)(3),
'             gleDouble dXformdTheta(2)(3), ' tangent change xform per revol */
'             gleDouble startTheta,        ' start angle, in degrees */
'             gleDouble sweepTheta)        ' sweep angle, in degrees */
'-------------------------------------------------------------------------== */
Public Sub Draw()
'   super_helix (rToroid,
'             startRadius,
'             drdTheta,        ' change in radius per revolution */
'             startZ,
'             dzdTheta,        ' change in Z per revolution */
'             startXform,
'             dXformdTheta, ' tangent change xform per revolution */
'             startTheta,          ' start angle, in degrees */
'             sweepTheta,       ' sweep angle, in degrees */
'             gleLathe);
   SuperHelix gc, m_ToroidRadius, m_StartRadius, m_drdTheta, m_StartZ, _
             m_dzdTheta, m_StartXForm, m_dXformdTheta, _
             m_StartTheta, m_SweepTheta, hc_gleLathe
End Sub



'-------------------------------------------------------------------------
'PUBLIC PROPERTIES
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'rToroid
'-------------------------------------------------------------------------
Public Property Get ToroidRadius() As Double
ToroidRadius = m_ToroidRadius
End Property

Public Property Let ToroidRadius(ByVal NewValue As Double)
m_ToroidRadius = NewValue
End Property

'-------------------------------------------------------------------------
'StartRadius
'-------------------------------------------------------------------------
Public Property Get startRadius() As Double
startRadius = m_StartRadius
End Property

Public Property Let startRadius(ByVal NewValue As Double)
m_StartRadius = NewValue
End Property

'-------------------------------------------------------------------------
'drdTheta
'-------------------------------------------------------------------------
Public Property Get drdTheta() As Double
drdTheta = m_drdTheta
End Property

Public Property Let drdTheta(ByVal NewValue As Double)
m_drdTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartZ
'-------------------------------------------------------------------------
Public Property Get startZ() As Double
startZ = m_StartZ
End Property

Public Property Let startZ(ByVal NewValue As Double)
m_StartZ = NewValue
End Property


'-------------------------------------------------------------------------
'dzdTheta
'-------------------------------------------------------------------------
Public Property Get dzdTheta() As Double
dzdTheta = m_dzdTheta
End Property

Public Property Let dzdTheta(ByVal NewValue As Double)
m_dzdTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartTheta
'-------------------------------------------------------------------------
Public Property Get startTheta() As Double
startTheta = m_StartTheta
End Property

Public Property Let startTheta(ByVal NewValue As Double)
m_StartTheta = NewValue
End Property

'-------------------------------------------------------------------------
'SweepTheta
'-------------------------------------------------------------------------
Public Property Get sweepTheta() As Double
sweepTheta = m_SweepTheta
End Property

Public Property Let sweepTheta(ByVal NewValue As Double)
m_SweepTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartXForm
'-------------------------------------------------------------------------
Public Sub GetStartXForm(ByVal Index&, x1#, y1#, z1#, _
             x2#, y2#, z2#)
On Error GoTo eh
    With gc
        x1 = m_StartXForm(0).v0(0)
        y1 = m_StartXForm(0).v0(1)
        z1 = m_StartXForm(0).v0(2)
        x2 = m_StartXForm(0).v1(0)
        y2 = m_StartXForm(0).v1(1)
        z2 = m_StartXForm(0).v1(2)
    End With
Exit Sub

eh: gEH 1
End Sub

Public Sub SetStartXForm(ByVal Index&, ByVal x1#, ByVal y1#, ByVal z1#, _
            ByVal x2#, ByVal y2#, ByVal z2#)
On Error GoTo eh
    ReDim m_StartXForm(0 To 0)
    With gc
        m_StartXForm(0).v0(0) = x1
        m_StartXForm(0).v0(1) = y1
        m_StartXForm(0).v0(2) = z1
        m_StartXForm(0).v1(0) = x2
        m_StartXForm(0).v1(1) = y2
        m_StartXForm(0).v1(2) = z2
    End With
Exit Sub

eh: gEH 1
End Sub

'-------------------------------------------------------------------------
'dXformdTheta
'-------------------------------------------------------------------------
Public Sub GetdXFormdTheta(x1#, y1#, z1#, _
             x2#, y2#, z2#)
On Error GoTo eh
        x1 = m_dXformdTheta(0).v0(0)
        y1 = m_dXformdTheta(0).v0(1)
        z1 = m_dXformdTheta(0).v0(2)
        x2 = m_dXformdTheta(0).v1(0)
        y2 = m_dXformdTheta(0).v1(1)
        z2 = m_dXformdTheta(0).v1(2)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetdXformdTheta(ByVal x1#, ByVal y1#, ByVal z1#, _
            ByVal x2#, ByVal y2#, ByVal z2#)
    ReDim m_dXformdTheta(0 To 0)
        m_dXformdTheta(0).v0(0) = x1
        m_dXformdTheta(0).v0(1) = y1
        m_dXformdTheta(0).v0(2) = z1
        m_dXformdTheta(0).v1(0) = x2
        m_dXformdTheta(0).v1(1) = y2
        m_dXformdTheta(0).v1(2) = z2
End Sub


' ======================================================= */
Public Property Get TextureEnabled() As Boolean
TextureEnabled = gc.TextureEnabled
End Property

Public Property Let TextureEnabled(ByVal NewValue As Boolean)
If NewValue Then
    gc.TextureEnabled = True
Else
    gc.TextureEnabled = False
End If
End Property

' ======================================================= */
Public Property Get TextureMode() As gleTextureModes
TextureMode = gc.TextureMode
End Property

Public Property Let TextureMode(ByVal mode As gleTextureModes)
gc.TextureMode = mode
SetTextureMode gc
End Property

' ======================================================= */
Public Property Get JoinStyle() As gleJoinStyles
JoinStyle = gc.JoinStyle
End Property

Public Property Let JoinStyle(ByVal NewValue As gleJoinStyles)
gc.JoinStyle = NewValue
End Property

' ======================================================= */
Public Property Get NormStyle() As gleNormStyles
NormStyle = gc.NormStyle
End Property

Public Property Let NormStyle(ByVal NewValue As gleNormStyles)
gc.NormStyle = NewValue
End Property

' ======================================================= */
Public Property Get ContourStyle() As gleContourStyles
ContourStyle = gc.ContourStyle
End Property

Public Property Let ContourStyle(ByVal NewValue As gleContourStyles)
gc.ContourStyle = NewValue
End Property

' ======================================================= */
Public Property Get CapStyle() As gleCapStyles
CapStyle = gc.CapStyle
End Property

Public Property Let CapStyle(ByVal NewValue As gleCapStyles)
gc.CapStyle = NewValue
End Property




