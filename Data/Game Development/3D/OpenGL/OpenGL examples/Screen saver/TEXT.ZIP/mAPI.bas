Attribute VB_Name = "mAPI"
Option Explicit

' Define your custom errors here.  Be sure to use numbers
' greater than 512, to avoid conflicts with OLE error numbers.
Public Const MyObjectError1 = 1000
Public Const MyUnhandledError = 9999

Public Const MAX_PATH = 260
Type POINTAPI
        x As Long
        y As Long
End Type

'the following must declared - typelib decs won't work
Type OUTLINETEXTMETRIC
    otmSize As Long
    otmTextMetrics As TEXTMETRIC
    otmFiller As Byte
    otmPanoseNumber As PANOSE
    otmfsSelection As Long
    otmfsType As Long
    otmsCharSlopeRise As Long
    otmsCharSlopeRun As Long
    otmItalicAngle As Long
    otmEMSquare As Long
    otmAscent As Long
    otmDescent As Long
    otmLineGap As Long
    otmsCapEmHeight As Long
    otmsXHeight As Long
    otmrcFontBox As RECT
    otmMacAscent As Long
    otmMacDescent As Long
    otmMacLineGap As Long
    otmusMinimumPPEM As Long
    otmptSubscriptSize As POINTAPI
    otmptSubscriptOffset As POINTAPI
    otmptSuperscriptSize As POINTAPI
    otmptSuperscriptOffset As POINTAPI
    otmsStrikeoutSize As Long
    otmsStrikeoutPosition As Long
    otmsUnderscorePosition As Long
    otmsUnderscoreSize As Long
    otmpFamilyName As String
    otmpFaceName As String
    otmpStyleName As String
    otmpFullName As String
End Type
Declare Function GetOutlineTextMetrics& Lib "gdi32" Alias "GetOutlineTextMetricsA" (ByVal hdc As Long, ByVal cbData As Long, lpotm As OUTLINETEXTMETRIC)
Dim DbgTotal&
Dim lClassDebugID&

Public Sub ReleaseID()
    DbgTotal = DbgTotal - 1
    Debug.Print "3DText Debug total = " & DbgTotal
End Sub

Function GetNextClassDebugID() As Long
    'class ID generator
    lClassDebugID = lClassDebugID + 1
    DbgTotal = DbgTotal + 1
    GetNextClassDebugID = lClassDebugID
End Function


Private Function GetErrorTextFromResource$(ErrorNum As Long)
Dim strMsg As String
      ' this function will retrieve an error description from a resource
      ' file (.RES).  The ErrorNum is the index of the string
      ' in the resource file.  Called by RaiseError
      On Error GoTo GetErrorTextFromResourceError
      ' get the string from a resource file
      GetErrorTextFromResource = LoadResString(ErrorNum)
      Exit Function
GetErrorTextFromResourceError:
      If Err.Number <> 0 Then
            GetErrorTextFromResource = "An unknown error has occurred!"
      End If
End Function

Public Sub RaiseError(ErrorNumber As Long, Source As String)
      Dim strErrorText As String
      'there are a number of methods for retrieving the error
      'message.  The following method uses a resource file to
      'retrieve strings indexed by the error number you are
      'raising.
      strErrorText = GetErrorTextFromResource(ErrorNumber)
      'raise an error back to the client
      Err.Raise vbObjectError + ErrorNumber, Source, strErrorText
End Sub



