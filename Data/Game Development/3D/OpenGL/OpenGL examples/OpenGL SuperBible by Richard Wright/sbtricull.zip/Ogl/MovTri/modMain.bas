Attribute VB_Name = "mMain"
Public Sub main()

' Main subroutine to show effect of culling

'****************************************************************
' Author - Sameer Deshmukh, Zentech Inc.
' Contact - sameer@zentech-usa.com
'****************************************************************

    ' Intialize variables
    bCull = False
    bDepth = False
    bOutLine = False
    
    ' Show the current window
    Load frmDisplay
    StartOpenGL frmDisplay.hDC
    frmDisplay.Show
    
    ' Event Processing Loop
    bAppRunning = True
    While bAppRunning = True
        ReDraw
        DoEvents
    Wend
    
    StopOpenGL
    
    Unload frmDisplay
    Set frmDisplay = Nothing
    
End Sub

