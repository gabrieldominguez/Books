VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CIndex"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: test of color index mode and palette creation
'   in 24bit mode
'   Adapted from OpenGL SuperBible, chapter 8
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'/*************************************************************************
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_StartX&, m_StartY&
Dim m_MouseX&, m_MouseY&


Private Sub Class_Initialize()
'
End Sub

Public Sub Init()
    '
    gCtl.pfPixelType = PFD_TYPE_COLORINDEX
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.7, 0.7, 0.7
        .SetPosition 0, 90, 150
        '.Enabled = 0 ' True
    End With
    With gCtl.Lights
        '.SetAmbient 1, 1, 1
        '.TwoSide = True
    End With
    glDisable GL_LIGHTING
    With gCtl.Camera
        .FarPlane = 200
        .NearPlane = -1
        '.FieldOfView = 45
        '.SetEyePos 2, 2, 100
        '.SetTargetPos 0, 0, 0
        .SetOrtho -150, 150, -150, 150
        .View = glxOrtho
    End With
    '
'    Set m_Mat = gCtl.NewMaterial
'    With m_Mat
'        .Face = faceFront
'        .SetDiffuse 0.5, 0.28, 0.38
'        .SetSpecular 0.2, 0.2, 0.2
'        .SpecExp = 30
'    End With

    'QuadObj = gluNewQuadric
    'gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    glShadeModel GL_SMOOTH
    MakePalette

End Sub

Public Sub Draw()

    '' Set clear color to first entry in palette (black)
    glClearIndex 0

    ' Clear the window with current clearing color
    'glClear (GL_COLOR_BUFFER_BIT)

    ' Draw the triangle
    glBegin GL_TRIANGLES
        ' Darkest Red Apex (black)
        glIndexi 0
        glVertex3f 0, 100, 0

        ' Brightest red bottom corners
        glIndexi 255
        glVertex3f -100, -70, 0
        glVertex3f 100, -70, 0
    glEnd

End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    ' start of view position functions */
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case vbKeyPageUp:
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii%)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "X":  '  zRotation = zRotation + 5
    Case "x":  '  zRotation = zRotation - 5
    End Select
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If (m_bMoving) Then
        End If
    Else
    End If
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    ' Rotate the scene with the left mouse button. */
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub


Public Function MakePalette&()
Dim pPal As LOGPALETTE
Dim hPal&, Count&, i&
    Count = 256 '2 ^ gPFD.cColorBits
    pPal.palVersion = &H300
    pPal.palNumEntries = Count
    For i = 0 To Count - 1
        pPal.palPalEntry(i).peRed = i
        pPal.palPalEntry(i).peGreen = 0
        pPal.palPalEntry(i).peBlue = 0
        pPal.palPalEntry(i).peFlags = PC_NOCOLLAPSE
    Next
    hPal = CreatePalette(pPal)
    gCtl.Palette.SetPalette hPal
End Function



