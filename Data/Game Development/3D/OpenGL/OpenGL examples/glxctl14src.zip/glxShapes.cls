VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxShapes"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: port of the GLUT shape routines.
'   - utility routines to draw geometric primitives
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'NOTES - Use these for quick tests and demos.
'-------------------------------------------------------------------------
'Copyright (c) Mark J. Kilgard, 1994, 1997. */
'*(c) Copyright 1993, Silicon Graphics, Inc.
'ALL RIGHTS RESERVED
'Permission to use, copy, modify, and distribute this software
'for any purpose and without fee is hereby granted, provided
'that the above copyright notice appear in all copies and that
'both the copyright notice and this permission notice appear in
'supporting documentation, and that the name of Silicon
'Graphics, Inc. not be used in advertising or publicity
'pertaining to distribution of the software without specific,
'written prior permission.
'
'THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU
'"AS-IS" AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR
'OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
'MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO
'EVENT SHALL SILICON GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE
'ELSE FOR ANY DIRECT, SPECIAL, INCIDENTAL, INDIRECT OR
'CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER,
'INCLUDING WITHOUT LIMITATION, LOSS OF PROFIT, LOSS OF USE,
'SAVINGS OR REVENUE, OR THE CLAIMS OF THIRD PARTIES, WHETHER OR
'NOT SILICON GRAPHICS, INC.  HAS BEEN ADVISED OF THE POSSIBILITY
'OF SUCH LOSS, HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
'ARISING OUT OF OR IN CONNECTION WITH THE POSSESSION, USE OR
'PERFORMANCE OF THIS SOFTWARE.
'
'US Government Users Restricted Rights
'
'Use, duplication, or disclosure by the Government is subject to
'restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
'(c)(1)(ii) of the Rights in Technical Data and Computer
'Software clause at DFARS 252.227-7013 and/or in similar or
'successor clauses in the FAR or the DOD or NASA FAR
'Supplement.  Unpublished-- rights reserved under the copyright
'laws of the United States.  Contractor/manufacturer is Silicon
'Graphics, Inc., 2011 N.  Shoreline Blvd., Mountain View, CA
'94039-7311.
'
'OpenGL(TM) is a trademark of Silicon Graphics, Inc.
'*/
Dim quadObj&
Dim dodec(0 To 19) As gleVector3f
'tetrahedron data:
Const t = 1.73205080756888

Dim tdata(0 To 3) As gleVector3f
Dim tndex(0 To 3) As gleVector3i

'icosahedron data: These numbers are rigged to make an
' icosahedron of radius 1.0 */

Const m_iX = 0.525731112119134
Const m_iZ = 0.85065080835204

Dim idata(0 To 11) As gleVector3f
Dim Index(0 To 19) As gleVector3i

'octahedron data: The octahedron produced is centered at the
'   origin and has radius 1.0 */
Dim odata(0 To 5) As gleVector3f
Dim ondex(0 To 7) As gleVector3i

'
Dim n(0 To 5) As gleVector3f
Dim faces(0 To 5) As gleVector4i

Private Sub Class_Initialize()
    quadObj = gluNewQuadric
FillArray3f tdata, _
    t, t, t, _
    t, -t, -t, _
    -t, t, -t, _
    -t, -t, t
FillArray3i tndex, _
    0, 1, 3, _
    2, 1, 0, _
    3, 2, 0, _
    1, 2, 3
FillArray3f idata, _
    -m_iX, 0, m_iZ, _
    m_iX, 0, m_iZ, _
    -m_iX, 0, -m_iZ, _
    m_iX, 0, -m_iZ, _
    0, m_iZ, m_iX, _
    0, m_iZ, -m_iX, _
    0, -m_iZ, m_iX, _
    0, -m_iZ, -m_iX, _
    m_iZ, m_iX, 0, _
    -m_iZ, m_iX, 0, _
    m_iZ, -m_iX, 0, _
    -m_iZ, -m_iX, 0
FillArray3i Index, _
    0, 4, 1, 0, 9, 4, 9, 5, 4, 4, 5, 8, 4, 8, 1, 8, 10, 1, _
    8, 3, 10, 5, 3, 8, 5, 2, 3, 2, 7, 3, 7, 10, 3, 7, 6, 10, _
    7, 11, 6, 11, 0, 6, 0, 1, 6, 6, 1, 10, 9, 0, 11, 9, 11, 2, _
    9, 2, 5, 7, 2, 11
FillArray3f odata, _
    1, 0, 0, -1, 0, 0, 0, 1, 0, _
    0, -1, 0, 0, 0, 1, 0, 0, -1
FillArray3i ondex, _
    0, 4, 2, 1, 2, 4, 0, 3, 4, _
    1, 4, 3, 0, 2, 5, 1, 5, 2, _
    0, 5, 3, 1, 3, 5
FillArray3f n, _
    -1, 0, 0, 0, 1, 0, 1, 0, 0, _
    0, -1, 0, 0, 0, 1, 0, 0, -1
FillArray4i faces, _
      0, 1, 2, 3, 3, 2, 6, 7, 7, 6, 5, 4, _
    4, 5, 1, 0, 5, 6, 2, 1, 7, 4, 0, 3
m_InitDodecahedron
End Sub

Private Sub Class_Terminate()
    gluDeleteQuadric quadObj
End Sub

Public Sub WireSphere(ByVal radius#, ByVal Slices&, ByVal Stacks&)
    gluQuadricDrawStyle quadObj, GLU_LINE
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    'with gluQuadricTexture and/or gluQuadricOrientation. */
    gluSphere quadObj, radius, Slices, Stacks
End Sub

Public Sub SolidSphere(ByVal radius#, ByVal Slices&, ByVal Stacks&)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    ' with gluQuadricTexture and/or gluQuadricOrientation. */
    gluSphere quadObj, radius, Slices, Stacks
End Sub

Public Sub WireCone(ByVal base#, ByVal Height#, ByVal Slices&, ByVal Stacks&)
    gluQuadricDrawStyle quadObj, GLU_LINE
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    'with gluQuadricTexture and/or gluQuadricOrientation. */
    gluCylinder quadObj, base, 0#, Height, Slices, Stacks
End Sub

Public Sub SolidCone(ByVal base#, ByVal Height#, ByVal Slices&, ByVal Stacks&)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    'with gluQuadricTexture and/or gluQuadricOrientation. */
    gluCylinder quadObj, base, 0#, Height, Slices, Stacks
End Sub


Private Sub m_DrawBox(ByVal nSize#, ByVal nType&)
Dim v(0 To 7) As gleVector3f
Dim i&
    v(0).v(0) = -nSize / 2
    v(1).v(0) = -nSize / 2
    v(2).v(0) = -nSize / 2
    v(3).v(0) = -nSize / 2
    v(4).v(0) = nSize / 2
    v(5).v(0) = nSize / 2
    v(6).v(0) = nSize / 2
    v(7).v(0) = nSize / 2
    v(0).v(1) = -nSize / 2
    v(1).v(1) = -nSize / 2
    v(4).v(1) = -nSize / 2
    v(5).v(1) = -nSize / 2
    v(2).v(1) = nSize / 2
    v(3).v(1) = nSize / 2
    v(6).v(1) = nSize / 2
    v(7).v(1) = nSize / 2
    v(0).v(2) = -nSize / 2
    v(3).v(2) = -nSize / 2
    v(4).v(2) = -nSize / 2
    v(7).v(2) = -nSize / 2
    v(1).v(2) = nSize / 2
    v(2).v(2) = nSize / 2
    v(5).v(2) = nSize / 2
    v(6).v(2) = nSize / 2

    For i = 5 To 0 Step -1
        glBegin nType
        glNormal3fv n(i).v(0)
        glVertex3fv v(faces(i).v(0)).v(0)
        glVertex3fv v(faces(i).v(1)).v(0)
        glVertex3fv v(faces(i).v(2)).v(0)
        glVertex3fv v(faces(i).v(3)).v(0)
        glEnd
    Next
End Sub

'CENTRY */
Public Sub WireCube(ByVal nSize#)
  m_DrawBox nSize, GL_LINE_LOOP
End Sub

Public Sub SolidCube(ByVal nSize#)
  m_DrawBox nSize, GL_QUADS
End Sub

Private Sub m_Doughnut(ByVal rad#, ByVal r#, ByVal nsides&, ByVal rings&)
Dim i&, j&
Dim theta!, phi!, theta1!
Dim cosTheta!, sinTheta!
Dim cosTheta1!, sinTheta1!
Dim ringDelta!, sideDelta!
Dim cosPhi!, sinPhi!, dist!
  
    ringDelta = 2 * M_PI / rings
    sideDelta = 2 * M_PI / nsides
    
    theta = 0
    cosTheta = 1
    sinTheta = 0
    For i = rings - 1 To 0 Step -1
        theta1 = theta + ringDelta
        cosTheta1 = Cos(theta1)
        sinTheta1 = Sin(theta1)
        glBegin GL_QUAD_STRIP
        phi = 0
        For j = nsides To 0 Step -1
            
            phi = phi + sideDelta
            cosPhi = Cos(phi)
            sinPhi = Sin(phi)
            dist = r + rad * cosPhi
            
            glNormal3f cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi
            glVertex3f cosTheta1 * dist, -sinTheta1 * dist, rad * sinPhi
            glNormal3f cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi
            glVertex3f cosTheta * dist, -sinTheta * dist, rad * sinPhi
        Next
        glEnd
    theta = theta1
    cosTheta = cosTheta1
    sinTheta = sinTheta1
    Next
End Sub

Public Sub WireTorus(ByVal InnerRadius#, ByVal OuterRadius#, ByVal nsides&, ByVal rings&)
    glPushAttrib GL_POLYGON_BIT
    glPolygonMode GL_FRONT_AND_BACK, GL_LINE
    m_Doughnut InnerRadius, OuterRadius, nsides, rings
    glPopAttrib
End Sub

Public Sub SolidTorus(ByVal InnerRadius#, ByVal OuterRadius#, ByVal nsides&, ByVal rings&)
    m_Doughnut InnerRadius, OuterRadius, nsides, rings
End Sub



Private Sub m_InitDodecahedron()
Dim alpha!, beta!

  alpha = Sqr(2# / (3# + Sqr(5#)))
  beta = 1# + Sqr(6# / (3# + Sqr(5#)) - _
    2# + 2# * Sqr(2# / (3# + Sqr(5#))))
  '*INDENT-OFF* */
  dodec(0).v(0) = -alpha: dodec(0).v(1) = 0: dodec(0).v(2) = beta:
  dodec(1).v(0) = alpha: dodec(1).v(1) = 0: dodec(1).v(2) = beta:
  dodec(2).v(0) = -1: dodec(2).v(1) = -1: dodec(2).v(2) = -1:
  dodec(3).v(0) = -1: dodec(3).v(1) = -1: dodec(3).v(2) = 1:
  dodec(4).v(0) = -1: dodec(4).v(1) = 1: dodec(4).v(2) = -1:
  dodec(5).v(0) = -1: dodec(5).v(1) = 1: dodec(5).v(2) = 1:
  dodec(6).v(0) = 1: dodec(6).v(1) = -1: dodec(6).v(2) = -1:
  dodec(7).v(0) = 1: dodec(7).v(1) = -1: dodec(7).v(2) = 1:
  dodec(8).v(0) = 1: dodec(8).v(1) = 1: dodec(8).v(2) = -1:
  dodec(9).v(0) = 1: dodec(9).v(1) = 1: dodec(9).v(2) = 1:
  dodec(10).v(0) = beta: dodec(10).v(1) = alpha: dodec(10).v(2) = 0:
  dodec(11).v(0) = beta: dodec(11).v(1) = -alpha: dodec(11).v(2) = 0:
  dodec(12).v(0) = -beta: dodec(12).v(1) = alpha: dodec(12).v(2) = 0:
  dodec(13).v(0) = -beta: dodec(13).v(1) = -alpha: dodec(13).v(2) = 0:
  dodec(14).v(0) = -alpha: dodec(14).v(1) = 0: dodec(14).v(2) = -beta:
  dodec(15).v(0) = alpha: dodec(15).v(1) = 0: dodec(15).v(2) = -beta:
  dodec(16).v(0) = 0: dodec(16).v(1) = beta: dodec(16).v(2) = alpha:
  dodec(17).v(0) = 0: dodec(17).v(1) = beta: dodec(17).v(2) = -alpha:
  dodec(18).v(0) = 0: dodec(18).v(1) = -beta: dodec(18).v(2) = alpha:
  dodec(19).v(0) = 0: dodec(19).v(1) = -beta: dodec(19).v(2) = -alpha:
End Sub

Private Sub m_DIFF3(A!(), B!(), c!())
    c(0) = A(0) - B(0)
    c(1) = A(1) - B(1)
    c(2) = A(2) - B(2)
End Sub

Private Sub m_CrossProd(v1!(), v2!(), prod!())
Dim p!(0 To 2)   'in case prod == v1 or v2 */
    p(0) = v1(1) * v2(2) - v2(1) * v1(2)
    p(1) = v1(2) * v2(0) - v2(2) * v1(0)
    p(2) = v1(0) * v2(1) - v2(0) * v1(1)
    prod(0) = p(0)
    prod(1) = p(1)
    prod(2) = p(2)
End Sub

Private Sub m_Normalize(v!())
Dim d!
    d = Sqr(v(0) * v(0) + v(1) * v(1) + v(2) * v(2))
    If d = 0 Then
        '__glutWarning("normalize: zero length vector");
        v(0) = 1
        d = 1
    End If
    d = 1 / d
    v(0) = v(0) * d
    v(1) = v(1) * d
    v(2) = v(2) * d
End Sub

Private Sub m_Pentagon(ByVal A&, ByVal B&, ByVal c&, ByVal d&, ByVal e&, ByVal ShadeType&)
Dim n0!(0 To 2), d1!(0 To 2), d2!(0 To 2)
  m_DIFF3 dodec(A).v, dodec(B).v, d1
  m_DIFF3 dodec(B).v, dodec(c).v, d2
  m_CrossProd d1, d2, n0
  m_Normalize n0

  glBegin ShadeType
  glNormal3fv n0(0)
  glVertex3fv dodec(A).v(0)
  glVertex3fv dodec(B).v(0)
  glVertex3fv dodec(c).v(0)
  glVertex3fv dodec(d).v(0)
  glVertex3fv dodec(e).v(0)
  glEnd
End Sub

Private Sub m_Dodecahedron(ByVal nType&)
    m_Pentagon 0, 1, 9, 16, 5, nType
    m_Pentagon 1, 0, 3, 18, 7, nType
    m_Pentagon 1, 7, 11, 10, 9, nType
    m_Pentagon 11, 7, 18, 19, 6, nType
    m_Pentagon 8, 17, 16, 9, 10, nType
    m_Pentagon 2, 14, 15, 6, 19, nType
    m_Pentagon 2, 13, 12, 4, 14, nType
    m_Pentagon 2, 19, 18, 3, 13, nType
    m_Pentagon 3, 0, 5, 12, 13, nType
    m_Pentagon 6, 15, 8, 10, 11, nType
    m_Pentagon 4, 17, 8, 15, 14, nType
    m_Pentagon 4, 12, 5, 16, 17, nType
End Sub

'CENTRY */
Public Sub WireDodecahedron()
    m_Dodecahedron GL_LINE_LOOP
End Sub

Public Sub SolidDodecahedron()
    m_Dodecahedron GL_TRIANGLE_FAN
End Sub

'ENDCENTRY */

'public sub recorditem(GLfloat * n1, GLfloat * n2, GLfloat * n3,
Private Sub m_RecordItem(n1!(), n2!(), n3!(), ByVal ShadeType&)
Dim q0!(0 To 2), q1!(0 To 2)
    m_DIFF3 n1, n2, q0
    m_DIFF3 n2, n3, q1
    m_CrossProd q0, q1, q1
    m_Normalize q1
    
    glBegin ShadeType
    glNormal3fv q1(0)
    glVertex3fv n1(0)
    glVertex3fv n2(0)
    glVertex3fv n3(0)
    glEnd
End Sub

'public sub subdivide(GLfloat * v0, GLfloat * v1, GLfloat * v2,  GLenum shadeType)
Public Sub m_Subdivide(v0!(), v1!(), v2!(), ByVal ShadeType&)
Dim Depth&
Dim w0!(0 To 2), w1!(0 To 2), w2!(0 To 2)
Dim l!
Dim i&, j&, k&, n&
    Depth = 1
    For i = 0 To Depth - 1
    For j = 0 To Depth - i - 1
        k = Depth - i - j
        For n = 0 To 2
            w0(n) = (i * v0(n) + j * v1(n) + k * v2(n)) / Depth
            w1(n) = ((i + 1) * v0(n) + j * v1(n) + (k - 1) * v2(n)) / Depth
            w2(n) = (i * v0(n) + (j + 1) * v1(n) + (k - 1) * v2(n)) / Depth
        Next
        l = Sqr(w0(0) * w0(0) + w0(1) * w0(1) + w0(2) * w0(2))
        w0(0) = w0(0) / l
        w0(1) = w0(1) / l
        w0(2) = w0(2) / l
        l = Sqr(w1(0) * w1(0) + w1(1) * w1(1) + w1(2) * w1(2))
        w1(0) = w1(0) / l
        w1(1) = w1(1) / l
        w1(2) = w1(2) / l
        l = Sqr(w2(0) * w2(0) + w2(1) * w2(1) + w2(2) * w2(2))
        w2(0) = w2(0) / l
        w2(1) = w2(1) / l
        w2(2) = w2(2) / l
        m_RecordItem w1, w0, w2, ShadeType
    Next
    Next
End Sub


Private Sub m_Drawtriangle(ByVal i&, Data() As gleVector3f, _
            ndx() As gleVector3i, ShadeType&)
Dim x0!, x1!, x2!
    m_Subdivide Data(ndx(i).v(0)).v, Data(ndx(i).v(1)).v, Data(ndx(i).v(2)).v, ShadeType
End Sub


Private Sub m_Octahedron(ByVal ShadeType&)
Dim i&
    For i = 7 To 0 Step -1
        m_Drawtriangle i, odata, ondex, ShadeType
    Next
End Sub

'CENTRY */
Public Sub WireOctahedron()
    m_Octahedron GL_LINE_LOOP
End Sub

Public Sub SolidOctahedron()
  m_Octahedron GL_TRIANGLES
End Sub

Private Sub m_Icosahedron(ByVal ShadeType&)
Dim i&
    For i = 19 To 0 Step -1
        m_Drawtriangle i, idata, Index, ShadeType
    Next
End Sub

Public Sub WireIcosahedron()
    m_Icosahedron GL_LINE_LOOP
End Sub

Public Sub SolidIcosahedron()
    m_Icosahedron GL_TRIANGLES
End Sub

Private Sub m_Tetrahedron(ByVal ShadeType&)
Dim i&
    For i = 3 To 0 Step -1
        m_Drawtriangle i, tdata, tndex, ShadeType
    Next
End Sub

Public Sub WireTetrahedron()
    m_Tetrahedron GL_LINE_LOOP
End Sub


Public Sub SolidTetrahedron()
    m_Tetrahedron GL_TRIANGLES
End Sub

'-------------------------------------------------------------------------
'more
'-------------------------------------------------------------------------
Public Sub SolidCylinder(ByVal BaseRadius!, ByVal TopRadius!, ByVal Height!, Optional Slices& = 16, Optional Stacks& = 16)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    'with gluQuadricTexture and/or gluQuadricOrientation. */
    gluCylinder quadObj, BaseRadius, TopRadius, Height, Slices, Stacks
End Sub

Public Sub WireCylinder(ByVal BaseRadius!, ByVal TopRadius!, ByVal Height!, Optional Slices& = 16, Optional Stacks& = 16)
    gluQuadricDrawStyle quadObj, GLU_LINE
    gluQuadricNormals quadObj, GLU_SMOOTH
    'If we ever changed/used the texture or orientation state
    'of quadObj, we 'd need to change it to the defaults here
    'with gluQuadricTexture and/or gluQuadricOrientation. */
    gluCylinder quadObj, BaseRadius, TopRadius, Height, Slices, Stacks
End Sub


'-------------------------------------------------------------------------
'OTHER COMMON ROUTINES
'-------------------------------------------------------------------------
'VRML syntax
Public Sub Box(ByVal Width!, ByVal Height!, ByVal Depth!)
    m_DrawBox2 Width, Height, Depth
End Sub

'right, left, top, bottom, front, back
Private Sub m_DrawBox2(W!, H!, d!) 'CCW
Dim v(0 To 7) As gleVector3f
Dim i&
    v(0).v(0) = -W / 2 'x
    v(0).v(1) = -H / 2 'y
    v(0).v(2) = -d / 2 'z
    v(1).v(0) = -W / 2
    v(1).v(1) = -H / 2
    v(1).v(2) = d / 2
    v(2).v(0) = -W / 2
    v(2).v(1) = H / 2
    v(2).v(2) = d / 2
    v(3).v(0) = -W / 2
    v(3).v(1) = H / 2
    v(3).v(2) = -d / 2
    v(4).v(0) = W / 2
    v(4).v(1) = -H / 2
    v(4).v(2) = -d / 2
    v(5).v(0) = W / 2
    v(5).v(1) = -H / 2
    v(5).v(2) = d / 2
    v(6).v(0) = W / 2
    v(6).v(1) = H / 2
    v(6).v(2) = d / 2
    v(7).v(0) = W / 2
    v(7).v(1) = H / 2
    v(7).v(2) = -d / 2
    For i = 5 To 0 Step -1
        glBegin GL_QUADS
        glNormal3fv n(i).v(0)
        glVertex3fv v(faces(i).v(0)).v(0)
        glVertex3fv v(faces(i).v(1)).v(0)
        glVertex3fv v(faces(i).v(2)).v(0)
        glVertex3fv v(faces(i).v(3)).v(0)
        glEnd
    Next
'    glBegin GL_QUADS 'front
'        glNormal3f 0, 0, 1
'        glVertex3f x1, y1, z1
'        glVertex3f x1, y2, z1
'        glVertex3f x2, y2, z1
'        glVertex3f x2, y1, z1
'    glEnd
'
'    glBegin GL_QUADS 'back
'        glNormal3f 0, 0, -1
'        glVertex3f x2, y1, z2
'        glVertex3f x2, y2, z2
'        glVertex3f x1, y2, z2
'        glVertex3f x1, y1, z2
'    glEnd
'
'    glBegin GL_QUADS 'right
'        glNormal3f 1, 0, 0
'        glVertex3f x1, y1, z2
'        glVertex3f x1, y2, z2
'        glVertex3f x1, y2, z1
'        glVertex3f x1, y1, z1
'    glEnd
'
'    glBegin GL_QUADS 'left
'        glNormal3f -1, 0, 0
'        glVertex3f x2, y1, z1
'        glVertex3f x2, y2, z1
'        glVertex3f x2, y2, z2
'        glVertex3f x2, y1, z2
'    glEnd
'
'    glBegin GL_QUADS 'top
'        glNormal3f 0, 1, 0
'        glVertex3f x1, y1, z2
'        glVertex3f x1, y1, z1
'        glVertex3f x2, y1, z1
'        glVertex3f x2, y1, z2
'    glEnd
'
'    glBegin GL_QUADS 'bottom
'        glNormal3f 0, -1, 0
'        glVertex3f x1, y2, z1
'        glVertex3f x1, y2, z2
'        glVertex3f x2, y2, z2
'        glVertex3f x2, y2, z1
'    glEnd

End Sub

'
Public Sub Cone(ByVal BaseRadius!, ByVal TopRadius!, ByVal Height!, Optional Bottom As Boolean = True, Optional Slices& = 16, Optional Stacks& = 16)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    gluCylinder quadObj, BaseRadius, TopRadius, Height, Slices, Stacks
    If Bottom Then
    glPushMatrix
        glRotatef 180, 1, 0, 0
        Disk 0, BaseRadius
    glPopMatrix
    End If
End Sub

Public Sub Cylinder(ByVal BaseRadius!, ByVal TopRadius!, ByVal Height!, Optional Top = True, Optional Bottom = True, Optional Slices& = 16, _
    Optional Stacks& = 16)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    gluCylinder quadObj, BaseRadius, TopRadius, Height, Slices, Stacks
    If Top Then
    glPushMatrix
        glRotatef 180, 1, 0, 0
        Disk 0, BaseRadius
    glPopMatrix
    End If
    If Bottom Then
    glPushMatrix
        glTranslatef 0, 0, Height
        Disk 0, BaseRadius
    glPopMatrix
    End If
End Sub

'-------------------------------------------------------------------------
Public Sub Sphere(ByVal radius!, Optional Slices& = 16, Optional Stacks& = 16)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    gluSphere quadObj, radius, Slices, Stacks
End Sub

Public Sub Disk(ByVal InnerRadius!, ByVal OuterRadius!, Optional Slices& = 16, Optional Loops& = 6)
    gluQuadricDrawStyle quadObj, GLU_FILL
    gluQuadricNormals quadObj, GLU_SMOOTH
    gluDisk quadObj, InnerRadius, OuterRadius, Slices, Loops
End Sub

