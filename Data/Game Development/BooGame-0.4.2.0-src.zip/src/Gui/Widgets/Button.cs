/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public delegate void ButtonEventHandler(object sender, ButtonEventArgs args);

    public class Button : Label
    {
        public Button() : base()
        {
            base.Alignment = System.Drawing.ContentAlignment.MiddleCenter;
            base.Text = "Button";
            base.Focusable = true;
            base.BackgroundColor = Color.Red;
            this.HoverColor = Color.DarkRed;
            base.BorderColor = Color.Black;
            base.Tint = Color.White;
        }
        public Button(Font font) : this()
        {
            base.Font = font;
        }
        public event ButtonEventHandler Pressed;
        public override void OnKeyDown(KeyboardEventArgs e)
        {
            if (e.Key == Keys.Return)
                Press();
        }
        public override void OnMouseButtonDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                Press();
        }
        private ColorF m_HoverColor = Color.Transparent;
        public ColorF HoverColor
        {
            get { return m_HoverColor; }
            set { m_HoverColor = value; }
        }
        protected override void DrawBackground()
        {
            if (Mouse.IntersectsWith(this.AbsoluteRectangle) && !Mouse.IsButtonDown(MouseButtons.Left))
                Paint.FilledRectangle(this.AbsoluteRectangle, m_HoverColor);
            else
                Paint.FilledRectangle(this.AbsoluteRectangle, base.BackgroundColor);
            Paint.Rectangle(this.AbsoluteRectangle, base.BorderColor);
        }
        public virtual void Press()
        {
            if (Pressed != null)
                Pressed(this, new ButtonEventArgs());
        }
    }

    public class ButtonEventArgs : System.EventArgs
    {
    }


}
