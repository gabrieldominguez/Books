Attribute VB_Name = "mDialog"
Option Explicit

'/******************************Module*Header*******************************\
'* Module Name: dialog.c
'* Dialog box functions for the OpenGL-based 3D Text screen saver.
'* Copyright (c) 1994 Microsoft Corporation
'\**************************************************************************/

'/**************************************************************************\
'* InitAttrContext
'* Initialize some of the values in the attribute context
'\**************************************************************************/
Private Sub m_Init()
    ' set some default values
    optDemoType = DEMO_STRING
    optSurfaceStyle = SURFSTYLE_SOLID
    optTessFactor = 1
    optSize = 50
    optSpeed = 50
    optTextureFile = ""
    optRotationStyle = ROTSTYLE_RANDOM
    optFontName = "Arial"
    optBold = 0
    optItalic = 0
    optCharSet = 0
    optText = "OpenGL"
    optTextureFile = ""
End Sub


'/******************************Public*Routine******************************\
'* getIniSettings
'* Get the screen saver configuration options from .INI file/registry.
'\**************************************************************************/
Public Sub GetIniSettings()
Dim Settings, i&
'Dim szDefaultBitmap As String * MAX_PATH
Dim iPos&
' Initialize the global AttrContext
m_Init
Settings = GetAllSettings(regAppName, regSection)
If Not IsEmpty(Settings) Then
For i = LBound(Settings, 1) To UBound(Settings, 1)
    Select Case Settings(i, 0)
    Case regDemoType '
        optDemoType = Settings(i, 1)
        gCtl.Ex.ClampToRange2 optDemoType, 0, MAX_DEMO
    Case regRotStyle
        optRotationStyle = Settings(i, 1)
        gCtl.Ex.ClampToRange2 optRotationStyle, 0, NUM_ROTSTYLES - 1
    Case regTessFactor
        iPos = Settings(i, 1)
        gCtl.Ex.ClampToRange2 iPos, MIN_SLIDER, MAX_SLIDER
        optTessFactor = iPos / 100
    Case regSize
        optSize = Settings(i, 1)
        gCtl.Ex.ClampToRange2 optSize, MIN_SLIDER, MAX_SLIDER
    Case regSpeed
        optSpeed = Settings(i, 1)
        gCtl.Ex.ClampToRange2 optSpeed, MIN_SLIDER, MAX_SLIDER
    Case regSurfStyle
        optSurfaceStyle = Settings(i, 1)
        gCtl.Ex.ClampToRange2 optSurfaceStyle, 0, SURFSTYLE_TEX
    Case regFont
        optFontName = Settings(i, 1)
    Case regBold
        optBold = Settings(i, 1)
    Case regItalic
        optItalic = Settings(i, 1)
    Case regCharSet
        optCharSet = Settings(i, 1)
    Case regText
        optText = Settings(i, 1)
    Case regTexture
        optTextureFile = Settings(i, 1)
    Case regTextFile
        optTextFile = Settings(i, 1)
    End Select
Next
End If
End Sub


'/******************************Public*Routine******************************\
'* saveIniSettings
'* Save the screen saver configuration option to the .INI file/registry.
'\**************************************************************************/
Public Sub SaveIniSettings()
    SaveSetting regAppName, regSection, regText, optText
    SaveSetting regAppName, regSection, regDemoType, optDemoType
    SaveSetting regAppName, regSection, regRotStyle, optRotationStyle
    SaveSetting regAppName, regSection, regTessFactor, optTessFactor
    SaveSetting regAppName, regSection, regSize, optSize
    SaveSetting regAppName, regSection, regSpeed, optSpeed
    SaveSetting regAppName, regSection, regSurfStyle, optSurfaceStyle
    SaveSetting regAppName, regSection, regFont, optFontName
    SaveSetting regAppName, regSection, regBold, optBold
    SaveSetting regAppName, regSection, regItalic, optItalic
    SaveSetting regAppName, regSection, regCharSet, optCharSet
    SaveSetting regAppName, regSection, regTexture, optTextureFile
    SaveSetting regAppName, regSection, regTextFile, optTextFile
End Sub

'/******************************Public*Routine******************************\
'* getFont
'* Calls ChooseFont dialog
'\**************************************************************************/
Public Sub GetFont(Font$, Bold As Boolean, Italic As Boolean)
'    ' Create and select a font.
    With dlgConfig
        .CD.FontName = Font
        .CD.FontBold = Bold
        .CD.FontItalic = Italic
        .CD.flags = cdlCFScreenFonts + cdlCFForceFontExist
        .CD.ShowFont
        If Err = cdlCancel Then Exit Sub
        Font = .CD.FontName
        Bold = .CD.FontBold
        Italic = .CD.FontItalic
    End With
End Sub

Public Function GetTextureFile$()
    On Error Resume Next
    With dlgConfig
        .CD.Filter = "Image files|*.bmp;*.jpg;*.jpeg;*.gif;*.dib|All files|*.*"
        .CD.FilterIndex = 1
        .CD.flags = cdlOFNFileMustExist
        .CD.ShowOpen
        If Err = cdlCancel Then Exit Function
        GetTextureFile$ = .CD.filename
    End With
End Function

Public Sub DoConfigure()
    dlgConfig.Show vbModal
End Sub

Public Function GetFile$()
    On Error Resume Next
    With dlgConfig
        .CD.Filter = "Text files|*.txt|All files|*.*"
        .CD.FilterIndex = 1
        .CD.flags = cdlOFNFileMustExist
        .CD.ShowOpen
        If Err = cdlCancel Then Exit Function
        GetFile$ = .CD.filename
    End With
End Function
