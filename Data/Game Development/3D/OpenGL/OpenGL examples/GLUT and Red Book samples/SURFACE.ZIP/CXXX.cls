VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'******************************Module*Header******************************
'FUNCTION: main class which responds to the ocx
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: -
'NOTES: GLUT sample
'*************************************************************************
Dim m_Mat As glxMaterial
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
'/**
' *  surface.c
' *  This program draws a NURBS surface in the shape of a
' *  symmetrical hill.
' */

Dim ctlpoints(0 To 4 * 4 - 1) As POINT3F
Dim showPoints&
Dim theNurb As GLUnurbsObj
Dim knots!(0 To 7)
Dim ID&

Private Sub Class_Initialize()
'/*
' *  Initializes the control points of the surface to a small hill.
' *  The control points range from -3 to +3 in x, y, and z
' */
Dim u&, v&
    For u = 0 To 3
    For v = 0 To 3
        ctlpoints(u * 4 + v).p(0) = 2 * (u - 1.5)
        ctlpoints(u * 4 + v).p(1) = 2 * (v - 1.5)
        If (u = 1 Or u = 2) And (v = 1 Or v = 2) Then
            ctlpoints(u * 4 + v).p(2) = 3 '7'top 4
        Else
            ctlpoints(u * 4 + v).p(2) = -3 'bottom 12
        End If
    Next: Next
    '
    FillArrayf knots, 0, 0, 0, 0, 1, 1, 1, 1
    '
    showPoints = True
End Sub

            
Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 1, 1, 1
        .SetSpecular 1, 1, 1
        .SetPosition 0, 10, 15
        .Enabled = True
    End With
    With gCtl.Lights
        .TwoSide = True
    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.1
        .FieldOfView = 45
        .SetEyePos 0, 0, 15
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFrontAndBack
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.7, 1, 1
        .SetSpecular 0.6, 0.8, 0.8
        .Shininess = 100
        .SpecExp = 120
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .axis = glxXYZ
        .Pick = True
    End With
    m_Grids = True
    'QuadObj = gluNewQuadric
    'QID = 1 'name for the ball
    'gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    glDepthFunc GL_LESS
    glEnable GL_DEPTH_TEST
    glEnable GL_AUTO_NORMAL
    glEnable GL_NORMALIZE
    theNurb = gluNewNurbsRenderer
    gluNurbsProperty theNurb, GLU_SAMPLING_TOLERANCE, 25
    gluNurbsProperty theNurb, GLU_DISPLAY_MODE, GLU_FILL

    'compile the surface into a display list
    display
End Sub

Sub display()
    If ID Then
        glDeleteLists ID, 1
    End If
    ID = glGenLists(1)
    glNewList ID, GL_COMPILE
        gluBeginSurface theNurb
        gluNurbsSurface theNurb, _
            8, knots(0), 8, knots(0), _
            4 * 3, _
            3, _
            ctlpoints(0).p(0), _
            4, 4, _
            GL_MAP2_VERTEX_3
        gluEndSurface theNurb
    glEndList
End Sub

Public Sub Draw()
Dim i&, j&
    With gCtl.Lights.Item(liLight0)
        .SetPosition 0, 0, 10
    End With
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    m_Mat.SetMaterial
    glRotatef -90, 1, 0, 0
    'glScalef 0.5, 0.5, 0.5
    glCallList ID
    If showPoints Then
        glPointSize 5
        glDisable GL_LIGHTING
        glColor3f 1, 1, 0
        glBegin GL_POINTS
        For i = 0 To 3
          For j = 0 To 3
            glVertex3f ctlpoints(i * 4 + j).p(0), ctlpoints(i * 4 + j).p(1), ctlpoints(i * 4 + j).p(2)
          Next
        Next
        glEnd
        glEnable GL_LIGHTING
    End If
    CheckError
End Sub


Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Static mode As Boolean
'Dim s$
'    s = Chr$(KeyAscii)
'    Select Case (s)
'    End Select
    mode = Not mode
    If mode Then
        gluNurbsProperty theNurb, GLU_DISPLAY_MODE, GLU_OUTLINE_POLYGON
    Else
        gluNurbsProperty theNurb, GLU_DISPLAY_MODE, GLU_FILL
    End If
    display
    gCtl.Render
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 2 Then
        gCtl.Render
    Else
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, Z#, z1!
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    'Z = 1.79769313486232E308
    Z = 10000000000# ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                Debug.Print " z1 = " & items(ptr)
                z1 = items(ptr)
                ptr = ptr + 1
            '3.z2
                Debug.Print " z2 = " & items(ptr)
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < Z Then
                        Z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub

