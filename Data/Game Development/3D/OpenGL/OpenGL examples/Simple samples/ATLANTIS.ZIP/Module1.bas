Attribute VB_Name = "Module1"
Option Explicit

'note: this sample was ported by Patrice Scribe
'for his type library.
'The original file is at:
'http://www.chez.com/scribe/vb_us.htm along with his
'type library.
'
'slightly modified by edx   edx@netvigator.com
Global Const RAD = 57.295
Global Const RRAD = 0.01745

Global Const NUM_SHARKS = 4
Global Const SHARKSIZE = 6000
Global Const SHARKSPEED = 100

Global Const WHALESPEED = 250

Type fishRec
    X As Single
    Y As Single
    Z As Single
    phi As Single
    theta As Single
    psi As Single
    v As Single
    xt As Single
    yt As Single
    zt As Single
    htail As Single
    vtail As Single
    dtheta As Single
    spurt As Long
    attack As Long
End Type

Public sharks(NUM_SHARKS) As fishRec
Public MomWhale As fishRec
Public BabyWhale As fishRec
Public Dolph As fishRec
' Ends of atlantis.h
Public moving As Boolean 'glBoolean

'
Const WORLD_LIST = 1000000
Private m_fieldOfView As Double
Private m_NearPlane As Double
Private m_FarPlane As Double
Private m_AspectRatio As Double
Dim m_hGLRC&, hdc&, hwnd&

Public Function Initialize(F As Form) As Boolean
Dim pfd As PIXELFORMATDESCRIPTOR
Dim R&, pos!(0 To 2)
hwnd = F.hwnd
hdc = F.hdc
'set standard parameters
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    R = ChoosePixelFormat(hdc, pfd)
    If R = 0 Then
        MsgBox "ChoosePixelFormat failed"
        Exit Function
    End If
    R = SetPixelFormat(hdc, R, pfd)
    'palette?
    '    'SetupPalette hDC
    m_hGLRC = wglCreateContext(hdc)
    wglMakeCurrent hdc, m_hGLRC
    'viewport
    m_AspectRatio = 2 '1
    m_FarPlane = 400000 '200
    m_NearPlane = 10000 '0.5
    m_fieldOfView = 400 '45
    'lighting
'    glEnable GL_LIGHTING
'    glEnable glcLight0
'    Initialize = True
    'objects
    DrawWorld
Init
End Function

Public Sub DrawWorld()
Dim obj&
Whale_Init
Shark_Init
Dolphin_Init
End Sub

'Adjusts the viewport to match the window size.
Public Sub OnSize(ByVal W&, ByVal H&)
If H = 0 Then H = 1
m_AspectRatio = W / H
glViewport 0, 0, W, H
SetViewPort
End Sub

Private Sub SetViewPort()
Dim W&, H&
Dim X#, Y#, Z#

glMatrixMode mmProjection
glLoadIdentity
gluPerspective m_fieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
glMatrixMode mmModelView
glLoadIdentity
End Sub

Public Sub Display()
Dim i As Long
Static Busy As Boolean
    If Busy Then Exit Sub
    Busy = True
    glClear clrColorBufferBit Or clrDepthBufferBit
    For i = 0 To NUM_SHARKS - 1
        glPushMatrix
            FishTransform sharks(i)
            DrawShark sharks(i)
        glPopMatrix
    Next

    glPushMatrix
        FishTransform Dolph
        DrawDolphin Dolph
    glPopMatrix

    glPushMatrix
        FishTransform MomWhale
        DrawWhale MomWhale
    glPopMatrix

    glPushMatrix
        FishTransform BabyWhale
        glScalef 0.45, 0.45, 0.3
        DrawWhale BabyWhale
    glPopMatrix
    
    glFinish
    SwapBuffers hdc
    Busy = False
End Sub

Public Sub Terminate()
    If m_hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext m_hGLRC
    End If
End Sub

Public Sub Animate()
    Dim i As Long
        For i = 0 To NUM_SHARKS - 1
            SharkPilot sharks(i)
            SharkMiss (i)
        Next
        WhalePilot Dolph
        Dolph.phi = Dolph.phi + 1
        WhalePilot MomWhale
        MomWhale.phi = MomWhale.phi + 1
        WhalePilot BabyWhale
        BabyWhale.phi = BabyWhale.phi + 1

End Sub
