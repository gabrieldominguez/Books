VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'----------------------------------------------------------------
'test object
Const bodyNPoints = 8
Const bodyNFaces = 7
Const theBodyRadius! = 3
'----------------------------------------------------------------
Dim thePoints(0 To 7) As POINT4F '!
Dim theFaceNormals(0 To 7) As POINT4F '!
Dim theFaceVertices(0 To 7) As QUADVERTICES
Dim theFaceColors(0 To 7) As COLOR3B
'----------------------------------------------------------------
Const BALL_RADIUS = 0.75
'class variables
Dim m_Mat As glxMaterial
Dim QuadObj&
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&
Dim m_Width&, m_Height&
Dim WithEvents Ball As CArcBall
Attribute Ball.VB_VarHelpID = -1

Private Sub Ball_OnAxisChanged(Axis As Long) 'AxisConstants)
Select Case Axis
    Case 3 'AllAxes
    frmMain.sts.Panels(3) = "AllAxes"
    Case 0 'XAxis
    frmMain.sts.Panels(3) = "X axis"
    Case 1 'YAxis
    frmMain.sts.Panels(3) = "Y axis"
    Case 2 'ZAxis
    frmMain.sts.Panels(3) = "Z axis"
    Case Else 'not active
    frmMain.sts.Panels(3) = ""
End Select
End Sub

Private Sub Ball_OnAxisSetChanged(Axis As AxisSets)
Select Case Axis
    Case NoAxes
    frmMain.sts.Panels(1) = "NoAxes"
    Case CameraAxes
    frmMain.sts.Panels(1) = "CameraAxes"
    Case BodyAxes
    frmMain.sts.Panels(1) = "BodyAxes"
    Case OtherAxes
    frmMain.sts.Panels(1) = "OtherAxes"
End Select
End Sub

Private Sub Class_Initialize()
'
FillArrayf thePoints(0).p, 3, 0, 0, 1
    FillArrayf thePoints(1).p, -1, 1, 0, 1
    FillArrayf thePoints(2).p, -1, -1, 0, 1
    FillArrayf thePoints(3).p, -0.75, 0, -0.25, 1
    FillArrayf thePoints(4).p, 1, 0, 0, 1
    FillArrayf thePoints(5).p, -0.75, 0, 0.75, 1
    FillArrayf thePoints(6).p, -0.5, -0.125, 0, 1
    FillArrayf thePoints(7).p, -0.5, 0.125, 0, 1
    '
    FillArrayi theFaceVertices(0).v, 3, 0, 1, 2
    FillArrayi theFaceVertices(1).v, 3, 4, 5, 6
    FillArrayi theFaceVertices(2).v, 3, 4, 7, 5
    FillArrayi theFaceVertices(3).v, 3, 5, 7, 6
    FillArrayi theFaceVertices(4).v, 3, 0, 2, 3
    FillArrayi theFaceVertices(5).v, 3, 0, 3, 1
    FillArrayi theFaceVertices(6).v, 3, 1, 3, 2
    '
    FillArrayf theFaceNormals(0).p, 0, 0, 1, 0
    FillArrayf theFaceNormals(1).p, 8.15289637797966E-02, -0.978347565357559, 0.190234248819525, 0
    FillArrayf theFaceNormals(2).p, 8.15289637797966E-02, 0.978347565357559, 0.190234248819525, 0
    FillArrayf theFaceNormals(3).p, -0.948683298050514, 0, -0.316227766016838, 0
    FillArrayf theFaceNormals(4).p, 6.42824346533225E-02, -0.25712973861329, -0.964236519799837, 0
    FillArrayf theFaceNormals(5).p, 6.42824346533225E-02, 0.25712973861329, -0.964236519799837, 0
    FillArrayf theFaceNormals(6).p, -0.707106781186548, 0, -0.707106781186548, 0
    '
    FillArrayb theFaceColors(0).c, 102, 204, 255
    FillArrayb theFaceColors(0).c, 0, 153, 204
    FillArrayb theFaceColors(0).c, 0, 153, 204
    FillArrayb theFaceColors(0).c, 204, 51, 157
    FillArrayb theFaceColors(0).c, 51, 102, 157
    FillArrayb theFaceColors(0).c, 51, 102, 157
    FillArrayb theFaceColors(0).c, 102, 102, 172
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 90, 90, 150
        .Enabled = True
    End With
'    With gCtl.Lights
'        .SetAmbient 1, 1, 1
'        .TwoSide = True
'    End With
    glDisable GL_LIGHTING
    glPolygonMode faceFrontAndBack, pgmLine
    With gCtl.Camera
        .FarPlane = 100000
        .NearPlane = -100
        '.FieldOfView = 45
        '.SetEyePos 0, 0, 10
        .SetTargetPos 0, 0, 0
        .SetOrthoEyePos 0, 0, -3
        .SetOrtho -1, 1, -1, 1
        .View = glxOrtho
    End With
    With gCtl
        .Grid = glxGridNone
        .Axis = glxXYZ
        .GridStep = 0.1
        .MouseRotate = True
        .Trackball.Animate = False
        .Pick = True
    End With
    'gCtl.UseCamera = False
    '
'    Set m_Mat = gCtl.NewMaterial
'    With m_Mat
'        .Face = faceFront
'        .SetDiffuse 0.5, 0.28, 0.38
'        .SetSpecular 0.2, 0.2, 0.2
'        .SpecExp = 30
'    End With

    QuadObj = gluNewQuadric
    gluQuadricCallback QuadObj, GLU_TESS_ERROR, AddressOf ErrorHandler
    '
    'init arcball
    Set Ball = New CArcBall
    Ball.Radius = BALL_RADIUS
    Ball.SetCenter 0, 0, 0
    Ball.AxisSet = NoAxes
    frmMain.sts.Panels(2) = "False"
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
    With gCtl
        m_Width = .ScaleWidth
        m_Height = .ScaleHeight
    End With
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyF1: Ball.AxisSet = NoAxes
    Case vbKeyF2: Ball.AxisSet = CameraAxes
    Case vbKeyF3: Ball.AxisSet = BodyAxes
    Case vbKeyF4: Ball.AxisSet = OtherAxes
    Case vbKeyF5:
        Ball.ShowResult = Not Ball.ShowResult
        With frmMain
        .sts.Panels(2) = CStr(Ball.ShowResult)
        .m_ShowResult.Checked = Ball.ShowResult
        End With
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    End Select
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        If (m_bMoving) Then Ball.MouseUp
    End If
    m_bMoving = False
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim dx!, dy!
    m_MouseX = x
    m_MouseY = y
    If Button = 1 Then
        If (m_bMoving) Then
            dx = 2 * m_MouseX / m_Width - 1
            dy = 2 * (m_Height - m_MouseY) / m_Height - 1
            Ball.MouseMove dx, dy
        End If
    Else
    End If
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim dx!, dy!
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
        dx = 2 * m_MouseX / m_Width - 1
        dy = 2 * (m_Height - m_MouseY) / m_Height - 1
        Ball.MouseDown dx, dy
    Else
    End If
End Sub

Public Sub Draw()
    glTranslatef 0, 0, -3
    With gCtl
        .Trackball.Update
        .DrawGrids
    End With
    DrawBody
End Sub

Public Sub DrawBody()
Dim mNow!(0 To 15), Radius!
    Ball.GetValue mNow
    Radius = Ball.Radius
    glPushMatrix
        glMultMatrixf mNow(0)
        glScalef Radius, Radius, Radius
        m_DrawBody mNow
        Ball.Draw
    glPopMatrix
End Sub

'----------------------------------------------------------------
' Transform body normals, draw front
Private Sub m_DrawBody(v16!())
Dim bodyScale#, i&, j&, k&, n&, dot#
Dim shadedColor(0 To 2) As GLbyte
    bodyScale = 1 / theBodyRadius
    glPushMatrix
    glScalef bodyScale, bodyScale, bodyScale
    For j = 0 To bodyNFaces - 1
        dot = v16(2) * theFaceNormals(j).p(0) _
                + v16(6) * theFaceNormals(j).p(1) _
                + v16(10) * theFaceNormals(j).p(2)
        If (dot > 0) Then   ' Front-facing polygon, so draw it
            dot = dot + 0.4
            If (dot > 1) Then dot = 1
            shadedColor(0) = dot * theFaceColors(j).c(0)
            shadedColor(1) = dot * theFaceColors(j).c(1)
            shadedColor(2) = dot * theFaceColors(j).c(2)
            n = theFaceVertices(j).v(0)
            glColor3bv shadedColor(0)   ', shadedColor(1), shadedColor(2)
            glBegin GL_POLYGON
            For k = 1 To n
                i = theFaceVertices(j).v(k)
                'v4f (thePoints(i))
                glVertex3fv thePoints(i).p(0)
            Next
            glEnd 'polygon();
        End If
    Next
    glPopMatrix
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&
    cnt = gCtl.hits
    'Picking = False
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                'Debug.Print " z1 = " & Items(ptr)
                ptr = ptr + 1
            '3.z2
                'Debug.Print " z2 = " & Items(ptr)
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                'Debug.Print "    name " & (j) & " = " & Items(ptr)
                Picked = items(ptr)
                ptr = ptr + 1
            Next
        Next
    Else
    End If
    Debug.Print "Selected: " & Picked
    '
    If Picked > 0 Then
        If Picked > 100 Then
            'geometry
        ElseIf Picked >= NAME_XAXIS And Picked <= NAME_CENTERBOX Then
            'arcball controller
            Ball.Axis = Picked
        End If
    Else
    End If
    'gCtl.Render
End Sub







