Attribute VB_Name = "gleGCx"
Option Explicit


   ' public methods */
'Public Property Get BgnGenTextureFunc() As BgnGenTextureConstants
'BgnGenTextureFunc = m_BgnGenTextureFunc
'End Property
'
'Public Property Let BgnGenTextureFunc(ByVal NewValue As BgnGenTextureConstants)
'm_BgnGenTextureFunc = NewValue
'End Property
'
''   void (*n3d_gen_texture) (double *);
'Public Property Get N3dGenTextureFunc() As N3DGenTextureConstants
'N3dGenTextureFunc = m_N3dGenTextureFunc
'End Property
'
'Public Property Let N3dGenTextureFunc(ByVal NewValue As N3DGenTextureConstants)
'm_N3dGenTextureFunc = NewValue
'End Property
'
''   void (*v3d_gen_texture) (double *, int, int);
'Public Property Get V3dGenTextureFunc() As V3DGenTextureConstants
'V3dGenTextureFunc = m_V3dGenTextureFunc
'End Property
'
'Public Property Let V3dGenTextureFunc(ByVal NewValue As V3DGenTextureConstants)
'm_V3dGenTextureFunc = NewValue
'End Property
'
''   void (*end_gen_texture) ();
'Public Property Get EndGenTextureFunc&()
'EndGenTextureFunc = m_EndGenTextureFunc
'End Property
'
'Public Property Let EndGenTextureFunc(ByVal NewValue&)
'm_EndGenTextureFunc = NewValue
'End Property
'

''   void (*save_bgn_gen_texture) (int, double);
'Public Property Get SaveBgnGenTextureFunc() As BgnGenTextureConstants
'SaveBgnGenTextureFunc = m_SaveBgnGenTextureFunc
'End Property
'
'Public Property Let SaveBgnGenTextureFunc(ByVal NewValue As BgnGenTextureConstants)
'm_SaveBgnGenTextureFunc = NewValue
'End Property
'
''   void (*save_n3f_gen_texture) (float *);
'Public Property Get SaveN3fGenTextureFunc() As N3DGenTextureConstants
'SaveN3fGenTextureFunc = m_SaveN3fGenTextureFunc
'End Property
'
'Public Property Let SaveN3fGenTextureFunc(ByVal NewValue As N3DGenTextureConstants)
'm_SaveN3fGenTextureFunc = NewValue
'End Property
''   void (*save_n3d_gen_texture) (double *);
'Public Property Get SaveN3dGenTextureFunc() As N3DGenTextureConstants
'SaveN3dGenTextureFunc = m_SaveN3dGenTextureFunc
'End Property
'
'Public Property Let SaveN3dGenTextureFunc(ByVal NewValue As N3DGenTextureConstants)
'm_SaveN3dGenTextureFunc = NewValue
'End Property
''   void (*save_v3f_gen_texture) (float *, int, int);
'Public Property Get SaveV3fGenTextureFunc() As V3DGenTextureConstants
'SaveV3fGenTextureFunc = m_SaveV3fGenTextureFunc
'End Property
'
'Public Property Let SaveV3fGenTextureFunc(ByVal NewValue As V3DGenTextureConstants)
'm_SaveV3fGenTextureFunc = NewValue
'End Property
'
''   void (*save_v3d_gen_texture) (double *, int, int);
'Public Property Get SaveV3dGenTextureFunc() As V3DGenTextureConstants
'SaveV3dGenTextureFunc = m_SaveV3dGenTextureFunc
'End Property
'
'Public Property Let SaveV3dGenTextureFunc(ByVal NewValue As V3DGenTextureConstants)
'm_SaveV3dGenTextureFunc = NewValue
'End Property
'
''   void (*save_end_gen_texture) ();
'Public Property Get SaveEndGenTextureFunc() As Long
'SaveEndGenTextureFunc = m_EndGenTextureFunc
'End Property
'
'Public Property Let SaveEndGenTextureFunc(ByVal NewValue&)
'm_SaveEndGenTextureFunc = NewValue
'End Property
''
'Public Property Get NumVertices&()
'NumVertices = m_NumVertices
'End Property
'
'Public Property Let NumVertices(ByVal NewValue&)
'm_NumVertices = NewValue
'End Property
'

