VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.1#0"; "glxCtl.ocx"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmMain 
   Caption         =   "3dNotepad"
   ClientHeight    =   5925
   ClientLeft      =   1260
   ClientTop       =   2490
   ClientWidth     =   7035
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5925
   ScaleWidth      =   7035
   Begin MSComDlg.CommonDialog CD 
      Left            =   5850
      Top             =   1770
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      CancelError     =   -1  'True
      Flags           =   4100
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   420
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   7035
      _ExtentX        =   12409
      _ExtentY        =   741
      ButtonWidth     =   609
      ButtonHeight    =   582
      Appearance      =   1
      ImageList       =   "imlToolbarIcons"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   15
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Open"
            Object.ToolTipText     =   "Open"
            ImageKey        =   "Open"
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Save"
            Object.ToolTipText     =   "Save"
            ImageKey        =   "Save"
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "NewArea"
            ImageIndex      =   15
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Properties"
            ImageIndex      =   23
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Text"
            ImageIndex      =   24
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Select"
            ImageIndex      =   16
            Style           =   2
            Value           =   1
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Move"
            ImageIndex      =   20
            Style           =   2
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Rotate"
            ImageIndex      =   21
            Style           =   2
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Scale"
            ImageIndex      =   22
            Style           =   2
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Zoom"
            ImageIndex      =   17
            Style           =   2
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "ArcRotate"
            ImageIndex      =   19
            Style           =   2
            Value           =   1
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Pan"
            ImageIndex      =   18
            Style           =   2
         EndProperty
      EndProperty
   End
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3795
      Left            =   30
      TabIndex        =   0
      Top             =   450
      Width           =   3705
      _ExtentX        =   6535
      _ExtentY        =   6694
      BorderStyle     =   1
   End
   Begin MSComctlLib.ImageList imlToolbarIcons 
      Left            =   5040
      Top             =   1710
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   24
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0000
            Key             =   "Open"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0112
            Key             =   "Save"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0224
            Key             =   "Drawing"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0336
            Key             =   "Rectangle"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0448
            Key             =   "Ellipse"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":055A
            Key             =   "Freeform"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":066C
            Key             =   "Line"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":077E
            Key             =   "Arc"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0890
            Key             =   "Bold"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":09A2
            Key             =   "Italic"
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0AB4
            Key             =   "Underline"
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0BC6
            Key             =   "Center"
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0CD8
            Key             =   "Align Left"
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0DEA
            Key             =   "Align Right"
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0EFC
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":100E
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1120
            Key             =   ""
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1232
            Key             =   ""
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1344
            Key             =   ""
         EndProperty
         BeginProperty ListImage20 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1456
            Key             =   ""
         EndProperty
         BeginProperty ListImage21 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1568
            Key             =   ""
         EndProperty
         BeginProperty ListImage22 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":167A
            Key             =   ""
         EndProperty
         BeginProperty ListImage23 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":178C
            Key             =   ""
         EndProperty
         BeginProperty ListImage24 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":189E
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Image CursorArcRotate 
      Height          =   480
      Left            =   6540
      Picture         =   "frmMain.frx":19B0
      Top             =   735
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorScale 
      Height          =   480
      Left            =   6000
      Picture         =   "frmMain.frx":1CBA
      Top             =   735
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorRotate 
      Height          =   480
      Left            =   5460
      Picture         =   "frmMain.frx":1FC4
      Top             =   690
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorZoom 
      Height          =   480
      Left            =   4950
      Picture         =   "frmMain.frx":22CE
      Top             =   750
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Image CursorPan 
      Height          =   480
      Left            =   7170
      Picture         =   "frmMain.frx":25D8
      Top             =   735
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileNew 
         Caption         =   "&New"
      End
      Begin VB.Menu mnuFileOpen 
         Caption         =   "&Open"
      End
      Begin VB.Menu mnuFileSave 
         Caption         =   "&Save"
      End
      Begin VB.Menu mnuFileSaveAs 
         Caption         =   "Save &as..."
      End
      Begin VB.Menu mnuFileSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileSaveBMP 
         Caption         =   "Save as &bmp"
      End
      Begin VB.Menu mnuFileSep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "&Edit"
      Begin VB.Menu mnuEditNewArea 
         Caption         =   "&New area"
      End
      Begin VB.Menu mnuEditDeleteArea 
         Caption         =   "&Delete area"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuEditSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditText 
         Caption         =   "&Text"
         Enabled         =   0   'False
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuEditProp 
         Caption         =   "&Properties"
         Enabled         =   0   'False
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuSep3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditBkg 
         Caption         =   "&Background"
         Begin VB.Menu mnuEditBkgNone 
            Caption         =   "None"
         End
         Begin VB.Menu mnuEditBkgSphere 
            Caption         =   "Sphere"
         End
         Begin VB.Menu mnuEditBkgPan 
            Caption         =   "Panorama"
         End
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "&View"
      Begin VB.Menu mnuViewGrid 
         Caption         =   "&Grid"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewReset 
         Caption         =   "&Reset"
         Shortcut        =   {F2}
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public Loading As Boolean
Dim Filename$, FileTitle$
Public Dirty As Boolean
Dim SaveDir$

Private Sub Form_Load()
    mnuViewGrid.Checked = CX.Grids
    dlgPropX = Left + 300
    dlgPropY = Top + 300
    dlgTextX = Left + 300
    dlgTextY = Top + 300
    SaveDir = App.Path
    Caption = "3dNotepad - Untitled"
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If Not QuerySave Then Cancel = 1
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload dlgText
    Unload dlgProperties
    Set CX = Nothing
End Sub

Private Sub mnuEditBkgNone_Click()
    Panorama.SetBkgMode n3dBkgNone, ""
    gCtl.Render
    Dirty = True
End Sub

Private Sub mnuEditBkgPan_Click()
On Error Resume Next
    'CD.flags = cdlOFNFileMustExist + cdlOFNHideReadOnly
    CD.Filter = "Image files (*.jpg,*.gif,*.bmp)|*.jpg;*.gif;*.bmp|All files (*.*)|*.*"
    CD.FilterIndex = 1
    CD.ShowOpen
    If Error Then Exit Sub
    If CD.Filename = "" Then Exit Sub
    Screen.MousePointer = 11
    If Panorama.SetBkg(CD.Filename) Then
        Dirty = True
    End If
    Screen.MousePointer = 0
    gCtl.Render
End Sub

Private Sub mnuEditBkgSphere_Click()
    'CD.flags = cdlOFNFileMustExist + cdlOFNHideReadOnly
    CD.Filter = "Image files (*.jpg,*.gif,*.bmp)|*.jpg;*.gif;*.bmp|All files (*.*)|*.*"
    CD.FilterIndex = 1
    CD.ShowOpen
    If Error Then Exit Sub
    If CD.Filename = "" Then Exit Sub
    Screen.MousePointer = 11
    Panorama.SetBkgMode n3dBkgSphere, CD.Filename
    Screen.MousePointer = 0
    gCtl.Render
    Dirty = True
End Sub

Private Sub mnuEditDeleteArea_Click()
    If Areas.Delete Then Dirty = True
End Sub

Private Sub mnuEditNewArea_Click()
    Areas.AddNew
    Dirty = True
End Sub

Private Sub mnuEditProp_Click()
    dlgProperties.Show
End Sub

Private Sub mnuEditText_Click()
    dlgText.Move dlgTextX, dlgTextY
    dlgText.Show 1
    gCtl.Render
End Sub

Private Sub mnuFileNew_Click()
    If QuerySave Then
        CX.OnNewDoc
        Dirty = False
    End If
End Sub

Private Sub mnuFileOpen_Click()
Dim fn&, s$, Path$
On Error Resume Next
    ChDir SaveDir
    CD.Filter = "Notepad3d files (*.n3d)|*.n3d|All files (*.*)|*.*"
    CD.FilterIndex = 1
    CD.ShowOpen
    If Error Then Exit Sub
    If CD.Filename = "" Then Exit Sub
On Error GoTo EH
    Filename = CD.Filename
    FileTitle = CD.FileTitle
    Path = ExtractPath(Filename)
    fn = FreeFile
    Open Filename For Binary As fn
        CX.Load fn, Path
    Close #fn
    gCtl.Render
    Caption = "3dNotepad - " & FileTitle
    Dirty = False
    Exit Sub
EH:
    Debug.Assert 0
    MsgBox "Error opening file." & vbCrLf & Err.Description
    Exit Sub
    Resume Next
End Sub

Private Sub mnuFileSave_Click()
    If Len(Filename) = 0 Then
        mnuFileSaveAs_Click
    Else
        Save
    End If
End Sub

Private Sub mnuFileSaveAs_Click()
On Error Resume Next
    ChDir SaveDir
    If FileTitle = "" Then
        CD.Filename = "untitled.n3d"
    Else: CD.Filename = FileTitle
    End If
    CD.Filter = "Notepad3d files (*.n3d)|*.n3d|All files (*.*)|*.*"
    CD.FilterIndex = 1
    CD.ShowSave
    If Error Then Exit Sub
    If CD.Filename = "" Then Exit Sub
    'prevent the gctl from picking up a stray mousedown
    Enabled = False
    Filename = CD.Filename
    FileTitle = CD.FileTitle
    Caption = "3dNotepad - " & FileTitle
    Save
    Enabled = True
End Sub

Private Sub mnuViewGrid_Click()
    mnuViewGrid.Checked = Not mnuViewGrid.Checked
    CX.Grids = mnuViewGrid.Checked
    gCtl.Render
End Sub

Private Sub mnuViewReset_Click()
    CX.ResetView
End Sub


Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
    On Error Resume Next
    Select Case Button.Key
        Case "Open": mnuFileOpen_Click
        Case "Save": mnuFileSave_Click
        Case "NewArea": mnuEditNewArea_Click
        Case "Properties": mnuEditProp_Click
        Case "Text": mnuEditText_Click
        Case "Select": CX.EditMode = n3dSelect
        Case "Move": CX.EditMode = n3dTranslate
        Case "Rotate": CX.EditMode = n3dRotate
        Case "Scale": CX.EditMode = n3dScale
        Case "Zoom": CX.ViewMode = n3dZoom
        Case "ArcRotate": CX.ViewMode = n3dArcRotate
        Case "Pan": CX.ViewMode = n3dPan
        Case Else: Debug.Assert 0
    End Select
End Sub

Private Sub Form_Resize()
    glxCtl1.Move 0, Toolbar1.Top, ScaleWidth, ScaleHeight  ' - Toolbar1.Height
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub

Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseDown Button, Shift, X, Y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseMove Button, Shift, X, Y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseUp Button, Shift, X, Y
End Sub

Private Sub glxCtl1_Paint()
gCtl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
CX.Pick items
End Sub

Private Sub glxCtl1_Resize(Width As Long, Height As Long, Default As Boolean)
Default = CX.Reshape(Width, Height)
End Sub

'return True for yes or no, 0 for cancel
Public Function QuerySave() As Boolean
Dim r&
    If Dirty Then
        r = MsgBox("Save changes?", vbYesNoCancel)
        If r = vbYes Then
            mnuFileSave_Click
        ElseIf r = vbCancel Then
            Exit Function
        End If
    End If
    QuerySave = True
End Function

Public Sub Save()
Dim fn&, s$, r&, r2&
On Error GoTo EH
    If Len(Filename) = 0 Then
        Debug.Assert 0
        Exit Sub
    End If
    s = Dir(Filename)
    If Len(s) Then
        Kill Filename
    End If
    fn = FreeFile
    Open Filename For Binary As fn
        s = ExtractPath(Filename)
        If Not CX.Save(fn, s) Then GoTo EH
    Close #fn
    r2 = 1
    Do
        r = InStr(r2, Filename, "\")
        If r = 0 Then Exit Do
        r2 = r + 1
    Loop
    If r2 > 1 Then
        SaveDir = Left$(Filename, r2 - 1)
    End If
    Dirty = False
    Exit Sub
EH:
    Close #fn
    Debug.Assert 0
    Debug.Print Err.Description
    MsgBox "Error saving file." & vbCrLf & Err.Description
    Exit Sub
    Resume Next
End Sub

Public Sub UpdateEditMenu(OK As Boolean)
    mnuEditDeleteArea.Enabled = OK
    mnuEditProp.Enabled = OK
    mnuEditText.Enabled = OK
    Toolbar1.Buttons("Properties").Enabled = OK
    Toolbar1.Buttons("Text").Enabled = OK
    
End Sub
