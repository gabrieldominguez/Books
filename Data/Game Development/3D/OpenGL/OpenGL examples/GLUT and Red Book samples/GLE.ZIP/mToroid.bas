Attribute VB_Name = "mToroid"
Option Explicit

Public IDToroid&
Public Toroid As gleToroid
'Const NPTS = 6
'
' * Initialize a bent shape with three segments.
' * The data format is a polyline.
' *
' * NOTE that neither the first, nor the last segment are drawn.
' * The first & last segment serve only to determine that angle
' * at which the endcaps are drawn.
' */
Public Sub InitToroid()
    Set Toroid = gCtl.NewToroid
    ' initialize the join style here */
    With Toroid
        .ToroidRadius = 2
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .startRadius = 6
        .sweepTheta = 360
        .dzdTheta = -0.015 * 150
        .SetStartXForm 0, 1, 0, 0, 0, 1, 0
        .SetdXformdTheta 0, 0, 0, 0, 0, 0
        
    
        IDToroid = glGenLists(1)
        glNewList IDToroid, lstCompile
        DrawToroid
        glEndList
    End With
End Sub


' draw the Toroid shape */
Public Sub DrawToroid()
   ' Phew. FINALLY, Draw the Toroid  -- */
    glPushMatrix
    Toroid.Draw
    glPopMatrix
End Sub

