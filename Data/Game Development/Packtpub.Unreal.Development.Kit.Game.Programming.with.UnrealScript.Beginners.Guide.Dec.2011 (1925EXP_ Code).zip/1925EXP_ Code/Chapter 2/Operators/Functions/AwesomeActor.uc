class AwesomeActor extends Actor
    placeable;

var int IntA, IntB, IntV;

var float FloatA, FloatB, FloatV;

var string StringS, StringT, StringV, Match, With;
var int i, j;

var vector VectA, VectV;
var float VectSize;

var rotator RotA;

function PostBeginPlay()
{
    IntV = Rand(10);
    IntV = Min(IntA, IntB);
    IntV = Max(IntA, IntB);
    Clamp(IntV, IntA, IntB);

    FloatV = FRand();
    FloatV = FMin(FloatA, FloatB);
    FloatV = FMax(FloatA, FloatB);
    FClamp(FloatV, FloatA, FloatB);

    i = Len(StringS);
    i = InStr(StringS, StringT);
    StringV = Left(StringS, i);
    StringV = Right(StringS, i);
    StringV = Mid(StringS, i, j);
    StringV = Caps(StringS);
    StringV = Locs(StringS);
    StringV = Repl(StringS, Match, With, true);

    VectSize = VSize(VectA);
    VectV = Normal(VectA);
    VectV = VRand();

    RotA = RotRand();
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
