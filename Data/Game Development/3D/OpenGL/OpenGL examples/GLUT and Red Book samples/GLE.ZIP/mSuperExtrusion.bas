Attribute VB_Name = "mSuperExtrusion"
Option Explicit

''
' * taper.c
' *
' * FUNCTION:
' * Draws a tapered screw shape.
' *
' * HISTORY:
' * -- created by Linas Vepstas October 1991
' * -- heavily modified to draw more texas shapes, Feb 1993, Linas
' * -- converted to use GLUT -- December 1995, Linas
' *
' */
'' =========================================================== */
Public IDSuper&
Public Super As gleSuperExtrusion
Const SCALEz = 1 '3.33333
Const NUM_PTS = 20
Const PSIZE = 40
Dim twist#(0 To PSIZE - 1)
Dim taper#(0 To PSIZE - 1)

'' =========================================================== */
Public Sub InitSuper()
    Set Super = gCtl.NewSuperExtrusion
    ' configure the pipeline */
    With Super
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .ContourStyle = gleCLOSED
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .NumContourPoints = NUM_PTS
        .NumPoints = PSIZE
        .NumContourNormals = NUM_PTS
    End With
    init_contour
    init_taper
    IDSuper = glGenLists(1)
    glNewList IDSuper, lstCompile
        DrawSuper
    glEndList
End Sub

'' =========================================================== */
Public Sub DrawSuper()
Dim j&, ang#, dang#, z#, deltaz#, ponent#
Dim zz#, zzz#
    glPushMatrix
    glColor3f 0.5, 0.9, 0.6
    '
    'gleTaper 20, contour, norms, Null, 40, path, Null, taper, twist
    'glTranslatef 0, 0, -50
    glScalef 0.5, 0.5, 0.5
    Super.DrawTaper taper, twist
    glPopMatrix
End Sub

Public Sub init_contour()
   ' outline of extrusion
   'defines the '+' shape
   Set CurModel = Super
   Super.SetContourNormal 0, 1, 0
   CONTOUR2 0, 1, 1, SCALEz
   CONTOUR2 1, 1, 2.9, SCALEz
   CONTOUR2 2, 0.9, 3, SCALEz
   CONTOUR2 3, -0.9, 3, SCALEz
   CONTOUR2 4, -1, 2.9, SCALEz

   CONTOUR2 5, -1, 1, SCALEz
   CONTOUR2 6, -2.9, 1, SCALEz
   CONTOUR2 7, -3, 0.9, SCALEz
   CONTOUR2 8, -3, -0.9, SCALEz
   CONTOUR2 9, -2.9, -1, SCALEz

   CONTOUR2 10, -1, -1, SCALEz
   CONTOUR2 11, -1, -2.9, SCALEz
   CONTOUR2 12, -0.9, -3, SCALEz
   CONTOUR2 13, 0.9, -3, SCALEz
   CONTOUR2 14, 1, -2.9, SCALEz

   CONTOUR2 15, 1, -1, SCALEz
   CONTOUR2 16, 2.9, -1, SCALEz
   CONTOUR2 17, 3, -0.9, SCALEz
   CONTOUR2 18, 3, 0.9, SCALEz
   CONTOUR2 19, 2.9, 1, SCALEz
End Sub
   
' =========================================================== */
Public Sub init_taper()
Dim j&, z#, deltaz#, ang#, dang#
Dim zzz#
    z = -20
    zzz = -10
    deltaz = 0.5 '1.999 / 38
    ang = 0 'starting angle
    dang = 10
    With Super
    For j = 0 To 39
        .SetPt j, 0, 0, z
        twist(j) = ang
        taper(j) = 0.1 * Sqr(Abs(9.51 * 9.51 - zzz * zzz))
        z = z + deltaz
        zzz = zzz + 0.4
        ang = ang + dang
    Next
    End With
    taper(0) = taper(1)
    taper(39) = taper(38)
End Sub



'' ===================== END OF FILE ================== */

