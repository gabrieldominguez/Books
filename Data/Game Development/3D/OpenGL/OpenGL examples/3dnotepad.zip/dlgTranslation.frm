VERSION 5.00
Begin VB.Form dlgTranslation 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Position"
   ClientHeight    =   1605
   ClientLeft      =   8880
   ClientTop       =   2430
   ClientWidth     =   4395
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1605
   ScaleWidth      =   4395
   ShowInTaskbar   =   0   'False
   Begin VB.TextBox txtWidth 
      Height          =   315
      Left            =   990
      TabIndex        =   11
      Top             =   1080
      Width           =   855
   End
   Begin VB.TextBox txtHeight 
      Height          =   315
      Left            =   2520
      TabIndex        =   10
      Top             =   1080
      Width           =   855
   End
   Begin VB.TextBox txtRot 
      Height          =   315
      Index           =   3
      Left            =   2790
      TabIndex        =   9
      Top             =   690
      Width           =   555
   End
   Begin VB.TextBox txtRot 
      Height          =   315
      Index           =   2
      Left            =   2190
      TabIndex        =   8
      Top             =   690
      Width           =   555
   End
   Begin VB.TextBox txtRot 
      Height          =   315
      Index           =   1
      Left            =   1590
      TabIndex        =   7
      Top             =   690
      Width           =   555
   End
   Begin VB.TextBox txtRot 
      Height          =   315
      Index           =   0
      Left            =   990
      TabIndex        =   6
      Top             =   690
      Width           =   555
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   3390
      TabIndex        =   3
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtPos 
      Height          =   315
      Index           =   0
      Left            =   990
      TabIndex        =   0
      Top             =   300
      Width           =   555
   End
   Begin VB.TextBox txtPos 
      Height          =   315
      Index           =   1
      Left            =   1590
      TabIndex        =   1
      Top             =   300
      Width           =   555
   End
   Begin VB.TextBox txtPos 
      Height          =   315
      Index           =   2
      Left            =   2190
      TabIndex        =   2
      Top             =   300
      Width           =   555
   End
   Begin VB.Label lblWidth 
      Caption         =   "Width:"
      Height          =   285
      Left            =   420
      TabIndex        =   13
      Top             =   1140
      Width           =   555
   End
   Begin VB.Label lblHeight 
      Caption         =   "Height:"
      Height          =   285
      Left            =   1950
      TabIndex        =   12
      Top             =   1140
      Width           =   555
   End
   Begin VB.Label Label1 
      Caption         =   "Rotation:"
      Height          =   285
      Index           =   1
      Left            =   210
      TabIndex        =   5
      Top             =   780
      Width           =   705
   End
   Begin VB.Label Label1 
      Caption         =   "Translation:"
      Height          =   285
      Index           =   0
      Left            =   60
      TabIndex        =   4
      Top             =   360
      Width           =   915
   End
End
Attribute VB_Name = "dlgTranslation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim Loading As Boolean
Dim a As CArea

Private Sub Command1_Click()
    dlgPosX = Left
    dlgPosY = Top
    Unload Me
End Sub

Private Sub txtHeight_Change()
    If Not Loading Then
        a.Height = Val(txtHeight.Text)
        gCtl.Render
    End If
End Sub

Private Sub txtRot_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.rX = Val(txtRot(0).Text)
        Case 1:  a.rY = Val(txtRot(1).Text)
        Case 2:  a.rZ = Val(txtRot(2).Text)
        Case 3:  a.ra = Val(txtRot(3).Text)
        End Select
        gCtl.Render
    End If
End Sub

Private Sub txtPos_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.X = Val(txtPos(0).Text)
        Case 1: a.Y = Val(txtPos(1).Text)
        Case 2: a.z = Val(txtPos(2).Text)
        End Select
        gCtl.Render
    End If
End Sub

Private Sub txtWidth_Change()
    If Not Loading Then
        a.Width = Val(txtWidth.Text)
        gCtl.Render
    End If
End Sub

Public Property Let Area(ByVal Selection As CArea)
Dim X!, Y!, z!, ra!
    Loading = True
    Set a = Selection
    a.GetTranslation X, Y, z
    txtPos(0) = X
    txtPos(1) = Y
    txtPos(2) = z
    a.GetRotation ra, X, Y, z
    txtRot(0) = X
    txtRot(1) = Y
    txtRot(2) = z
    txtRot(3) = ra
    txtWidth = a.Width
    txtHeight = a.Height
    Loading = False
End Property
