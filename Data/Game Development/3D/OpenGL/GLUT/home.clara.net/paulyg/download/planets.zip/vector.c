
#define DISTANCE(x,y,z) sqrt((x)*(x)+(y)*(y)+(z)*(z))

const float radian_correction = 3.14159265358979323846f / 180.0f;

void polar_to_cartesian (float azimuth, float length,
								float altitude,
								float &x, float &y, float &z) {

	// do x-z calculation

	float theta    = (90 - azimuth) * radian_correction;
	float tantheta = (float) tan (theta);

	x = (float) sqrt ( (length * length) / (tantheta * tantheta + 1));
	z = tantheta * x;

	x = -x;

	if (((azimuth >= 180.0) && (azimuth <= 360.0)) || (azimuth == 0.0f)){
		x = -x;
		z = -z;
	}

	float radian_alt = altitude * radian_correction;
	

		// calculate y, and adjust x and z
	y = (float) (sqrt (z*z + x*x) * sin (radian_alt));

	if (length < 0) {
		x = -x;
		z = -z;
		y = -y;
	}
	float cospsi = (float) cos (radian_alt);
	x = x * cospsi;
	z = z * cospsi;
}


/* Rotates (rx,ry,rz) point about the (ax,ay,az) axis 'angle' radians,
   'borrowed' from Mesa (the OpenGL replacement www.mesa3d.org */
void rotation( double angle, double ax, double ay, double az,
                         double *rx, double *ry, double *rz)
{
   double mag, s, c;
   double x,y,z,xx, yy, zz, xy, yz, zx, xs, ys, zs, one_c;

   s = sin(angle);
   c = cos(angle);

   mag = DISTANCE(ax,ay,az);

   if (mag == 0.0) return;

   x = ax/mag;
   y = ay/mag;
   z = az/mag;

   xx = x * x;
   yy = y * y;
   zz = z * z;
   xy = x * y;
   yz = y * z;
   zx = z * x;
   xs = x * s;
   ys = y * s;
   zs = z * s;
   one_c = 1.0 - c;

   x = *rx*((one_c * xx) + c);
   y = *rx*((one_c * xy) - zs);
   z = *rx*((one_c * zx) + ys);

   x += *ry*((one_c * xy) + zs);
   y += *ry*((one_c * yy) + c);
   z += *ry*((one_c * yz) - xs);

   x += *rz*((one_c * zx) - ys);
   y += *rz*((one_c * yz) + xs);
   z += *rz*((one_c * zz) + c);
   
   *rx=x; *ry=y; *rz=z;
}




