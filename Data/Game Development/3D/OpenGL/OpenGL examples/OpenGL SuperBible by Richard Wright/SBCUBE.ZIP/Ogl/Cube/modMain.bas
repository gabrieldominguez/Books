Attribute VB_Name = "mMain"
Public Sub main()

' Main subroutine to show lighting effect on jet

'****************************************************************
' Author - Sameer Deshmukh, Zentech Inc.
' Contact - sameer@zentech-usa.com
'****************************************************************

    ' Intialize variables
    bLight = False
    frmDisplay.mnuEffects_Lights.Checked = False
    frmDisplay.mnuEffects_Specular.Checked = False
    frmDisplay.mnuEffects_Specular.Enabled = False
    frmDisplay.mnuEffects_Shine.Checked = False
    frmDisplay.mnuEffects_Shine.Enabled = False
    xRot = 0#
    yRot = 0#
    
    ' Show the current window
    Load frmDisplay
    StartOpenGL frmDisplay.hDC
    frmDisplay.Show
    Call SetupRC
    Call RenderScene
    Load frmMessage
    frmMessage.Show modal, frmDisplay
    'Unload frmMessage
    'frmDisplay.SetFocus
    
    ' Event Processing Loop
    bAppRunning = True
    While bAppRunning = True
        Call RenderScene
        DoEvents
    Wend
    
    StopOpenGL
    
    Unload frmDisplay
    Set frmDisplay = Nothing
    
End Sub

