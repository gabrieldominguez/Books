/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public class TextBox : Label
    {
        /// <summary>
        /// Create a textbox.
        /// </summary>
        public TextBox() : base()
        {
            base.BorderColor = Color.Black;
            base.BackgroundColor = Color.White;
            base.Alignment = ContentAlignment.TopLeft;
            base.Tint = Color.Black;
            base.Focusable = true;
        }
        /// <summary>
        /// Create a textbox with a specified font for drawing.
        /// </summary>
        /// <param name="font">The font to use for writing text.</param>
        public TextBox(Font font) : this()
        {
            base.Font = font;
        }

        private bool m_MultiLine = false;
        /// <summary>
        /// Gets and sets whether the textbox is allowed to be multi-lined.
        /// </summary>
        public bool MultiLine
        {
            get { return m_MultiLine; }
            set { m_MultiLine = value; }
        }

        /// <summary>
        /// When a key is pushed while the textbox has focus.
        /// </summary>
        /// <param name="e">Keyboard arugments</param>
        public override void OnKeyDown(KeyboardEventArgs e)
        {
            if (m_CaretShown)
            {
                this.Text = this.Text.Substring(0, this.Text.Length - 1);
                m_CaretShown = false;
                m_CaretTimer.Restart();
            } 
            switch(e.Key)
            {
                case Keys.Return:
                    if (m_MultiLine)
                        this.Text += "\n";
                    break;
                case Keys.Backspace:
                    if(this.Text.Length > 0)
                        this.Text = this.Text.Substring(0, this.Text.Length - 1);
                    break;
                default:
                    if(e.IsSpecialKey == false)
                        this.Text += e.Char;
                    break;
            }
            
        }

        private Timer m_CaretTimer = new Timer(333);
        private bool m_CaretShown = false;

        /// <summary>
        /// Updates the properties of the textbox.
        /// </summary>
        public override void Update()
        {
            base.Update();

            if (Enabled)
            {
                if (this.HasFocus)
                {
                    if (m_CaretTimer.CheckTime())
                    {
                        if (m_CaretShown)
                        {
                            this.Text = this.Text.Substring(0, this.Text.Length - 1);
                            m_CaretShown = false;
                        }
                        else
                        {
                            this.Text += "|";
                            m_CaretShown = true;
                        }
                    }
                }
                else
                {
                    if (m_CaretShown)
                    {
                        this.Text = this.Text.Substring(0, this.Text.Length - 1);
                        m_CaretShown = false;
                        m_CaretTimer.Restart();
                    }
                }
            }
        }
    }
}
