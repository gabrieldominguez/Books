#include <vga.h>
#include "device.h"
#include "globals.h"
#if 1
#  define COLOR_SPLINES
#endif
#if 0
#  define SIMPLE
#endif

/* Graphics Scaling */
#define GRAPH_SCALE 24
#define GSX(x) (int)((((x)*this->xscale)+(GRAPH_SCALE/2))/GRAPH_SCALE)
#define GSY(y) (int)((this->height-((y)*this->yscale)-(GRAPH_SCALE/2))/GRAPH_SCALE)

void
graph_init(device* this)
{
  int mode;
  vga_init();
  mode=vga_getdefaultmode(); 
  if (!vga_hasmode(mode))
    mode=G640x480x256;
  vga_setmode(mode);
  this->width=vga_getxdim()*GRAPH_SCALE;
  this->height=vga_getydim()*GRAPH_SCALE;
}

void
graph_clear(device* this)
{
  vga_clear();
}

void
graph_exit(device* this)
{
  vga_setmode(TEXT);
}

int
graph_getch(device* this)
{
  return vga_getch();
}

void
graph_line(device* this,int x1, int y1, int x2, int y2)
{
  vga_drawline(GSX(x1), GSY(y1), GSX(x2), GSY(y2));
}

void
graph_spline(device* this,
	     int x1, int y1, int x2, int y2, 
	     int x3, int y3, int x4, int y4)
{
  int x,y;
  int xo,yo;
  float t;
#ifdef COLOR_SPLINES
  vga_setcolor(2);
#endif
#ifdef SIMPLE
  graph_line(this,x1,y1,x2,y2);
  graph_line(this,x2,y2,x3,y3);
  graph_line(this,x3,y3,x4,y4);
#else
  xo=x1;
  yo=y1;
  for(t=0.1;t<.99;t+=0.1)
  {
    x=(int)((((x4-3*x3+3*x2-x1)*t+3*(x3-2*x2+x1))*t+3*(x2-x1))*t+x1);
    y=(int)((((y4-3*y3+3*y2-y1)*t+3*(y3-2*y2+y1))*t+3*(y2-y1))*t+y1);
    graph_line(this,xo,yo,x,y);
    xo=x;
    yo=y;
  }
  graph_line(this,xo,yo,x4,y4);
#endif
#ifdef COLOR_SPLINES
  vga_setcolor(vga_white());
#endif
}

device dev_graphic=
{
  graph_init,
  graph_clear,
  graph_exit,
  graph_getch,
  graph_line,
  graph_spline
};
