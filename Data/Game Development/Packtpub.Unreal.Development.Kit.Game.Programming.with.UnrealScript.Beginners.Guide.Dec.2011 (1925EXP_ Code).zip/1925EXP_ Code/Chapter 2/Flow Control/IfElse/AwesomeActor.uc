class AwesomeActor extends Actor
    placeable;

var int Int1, Int2;

function PostBeginPlay()
{
    if(Int1 > Int2)
        `log("Int1 is greater than Int2");
    else if(Int1 == Int2)
        `log("Int1 is equal to Int2");
    else
        `log("Int1 is less than Int2");
}

defaultproperties
{
    Int1=5
    Int2=2

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
