VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "gleScrew"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim gc As gleGC
Dim m_StartZ#
Dim m_EndZ#
Dim m_Twist#

Private Sub Class_Initialize()
    ReDim gc.up(0 To 2)
    gc.up(1) = 1
    gc.JoinStyle = gleANGLE
    gc.CapStyle = gleCAPS
    gc.NormStyle = gleFACET
    gc.ContourStyle = gleOPEN
End Sub

Private Sub Class_Terminate()
'
End Sub

'-------------------------------------------------------------------------== */
'public sub gleScrew (ncp&,
'               gleDouble contour()(2),
'               gleDouble cont_normal()(2),
'               gleDouble up(3),
'               gleDouble startz,
'               gleDouble endz,
'               gleDouble twist)
'-------------------------------------------------------------------------== */
Public Sub Draw()
Dim i&
'Dim path#() ' As gleVector   '* ;
Dim twist_array#() ' as  gleDouble *;
Dim currz#, delta#
Dim currang#, delang#
Dim dummy_color!()
'
'same as GenScrew
With gc
    ' no segment should rotate more than 18 degrees */
    'numsegs = (int) fabs (twist / 18) + 4;
    .npoints = Abs(twist / 18) + 4
    
    ' malloc the extrusion array and the twist array */
    '   path = (gleVector *) malloc (.npoints * sizeof (gleVector));
    '   twist_array = (gleDouble *) malloc (.npoints * sizeof (gleDouble));
    ReDim .point_array(0 To .npoints - 1)
    ReDim twist_array(0 To .npoints - 1)
    ' fill in the extrusion array and the twist array uniformly */
    delta = (endz - startZ) / (.npoints - 3)
    currz = startZ - delta
    delang = twist / (.npoints - 3)
    currang = -delang
    For i = 0 To .npoints - 1
       .point_array(i).v(0) = 0
       .point_array(i).v(1) = 0
       .point_array(i).v(2) = currz
        currz = currz + delta
        twist_array(i) = currang
        currang = currang + delang
    Next
    Erase gc.color_array
    'gleTwistExtrusion ncp, contour, cont_normal, up, numsegs, path, dummy_color, twist_array
    GenTwistExtrusion gc, twist_array
End With
End Sub

'-------------------------------------------------------------------------
'PUBLIC PROPERTIES
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'ncp
'-------------------------------------------------------------------------
Public Property Get NumContourPoints() As Long
NumContourPoints = gc.ncp
End Property

Public Property Let NumContourPoints(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncp = 0
    Erase gc.contour
Else
    gc.ncp = NewValue
    ReDim Preserve gc.contour(0 To gc.ncp - 1)
End If
End Property

'-------------------------------------------------------------------------
'contour
'-------------------------------------------------------------------------
Public Sub GetContourPt(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.contour(Index).v(0)
    y = gc.contour(Index).v(1)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetContourPt(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.contour(Index).v(0) = x
    gc.contour(Index).v(1) = y
Exit Sub

eh: gEH 1
End Sub

Public Property Get CPtX(ByVal Index&) As Double
On Error GoTo eh
    CPtX = gc.contour(Index).v(0)
Exit Property
eh: gEH 1
End Property

Public Property Let CPtX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.contour(Index).v(0) = NewX
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CPtY(ByVal Index&) As Double
On Error GoTo eh
    CPtY = gc.contour(Index).v(1)
Exit Property
eh: gEH 1
End Property

Public Property Let CPtY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.contour(Index).v(1) = NewY
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
'ncnormals
'-------------------------------------------------------------------------
Public Property Get NumContourNormals() As Long
NumContourNormals = gc.ncnormals
End Property

Public Property Let NumContourNormals(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncnormals = 0
    Erase gc.cont_normal
Else
    gc.ncnormals = NewValue
    ReDim Preserve gc.cont_normal(0 To gc.ncnormals - 1)
End If
End Property

'-------------------------------------------------------------------------
'cont_normal
'-------------------------------------------------------------------------
Public Sub GetContourNormal(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.cont_normal(Index).v(0)
    y = gc.cont_normal(Index).v(1)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetContourNormal(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = x
    gc.cont_normal(Index).v(1) = y
Exit Sub

eh: gEH 1
End Sub

Public Property Get CNX(ByVal Index&) As Double
On Error GoTo eh
    CNX = gc.cont_normal(Index).v(0)
Exit Property
eh: gEH 1
End Property

Public Property Let CNX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = NewX
Exit Property
eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CNY(ByVal Index&) As Double
On Error GoTo eh
    CNY = gc.cont_normal(Index).v(1)
Exit Property
eh: gEH 1
End Property

Public Property Let CNY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(1) = NewY
Exit Property
eh: gEH 1
End Property


'-------------------------------------------------------------------------
'up
'-------------------------------------------------------------------------
Public Sub GetUp(x#, y#, z#)
On Error GoTo eh
    x = gc.up(0)
    y = gc.up(1)
    z = gc.up(2)
Exit Sub

eh: gEH 1
End Sub

Public Sub SetUp(ByVal x#, ByVal y#, ByVal z#)
On Error GoTo eh
    gc.up(0) = x
    gc.up(1) = y
    gc.up(2) = z
Exit Sub

eh: gEH 1
End Sub

'-------------------------------------------------------------------------
'StartZ
'-------------------------------------------------------------------------
Public Property Get startZ() As Double
startZ = m_StartZ
End Property

Public Property Let startZ(ByVal NewValue As Double)
m_StartZ = NewValue
End Property

'-------------------------------------------------------------------------
'EndZ
'-------------------------------------------------------------------------
Public Property Get endz() As Double
endz = m_EndZ
End Property

Public Property Let endz(ByVal NewValue As Double)
m_EndZ = NewValue
End Property

'-------------------------------------------------------------------------
'StartZ
'-------------------------------------------------------------------------
Public Property Get twist() As Double
twist = m_Twist
End Property

Public Property Let twist(ByVal NewValue As Double)
m_Twist = NewValue
End Property

' ======================================================= */
Public Property Get TextureEnabled() As Boolean
TextureEnabled = gc.TextureEnabled
End Property

Public Property Let TextureEnabled(ByVal NewValue As Boolean)
If NewValue Then
    gc.TextureEnabled = True
Else
    gc.TextureEnabled = False
End If
End Property

' ======================================================= */
Public Property Get TextureMode() As gleTextureModes
TextureMode = gc.TextureMode
End Property

Public Property Let TextureMode(ByVal mode As gleTextureModes)
gc.TextureMode = mode
SetTextureMode gc
End Property

' ======================================================= */
Public Property Get JoinStyle() As gleJoinStyles
JoinStyle = gc.JoinStyle
End Property

Public Property Let JoinStyle(ByVal NewValue As gleJoinStyles)
gc.JoinStyle = NewValue
End Property

' ======================================================= */
Public Property Get NormStyle() As gleNormStyles
NormStyle = gc.NormStyle
End Property

Public Property Let NormStyle(ByVal NewValue As gleNormStyles)
gc.NormStyle = NewValue
End Property

' ======================================================= */
Public Property Get ContourStyle() As gleContourStyles
ContourStyle = gc.ContourStyle
End Property

Public Property Let ContourStyle(ByVal NewValue As gleContourStyles)
gc.ContourStyle = NewValue
End Property

' ======================================================= */
Public Property Get CapStyle() As gleCapStyles
CapStyle = gc.CapStyle
End Property

Public Property Let CapStyle(ByVal NewValue As gleCapStyles)
gc.CapStyle = NewValue
End Property




