VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CDrop"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
#Const DebugMode = 0 '1
'/******************************Module*Header******************************
'* Module Name: gendrop.c
'FUNCTION:
'* The Splash style of the 3D Flying Objects screen saver.
'* Simulation of a drop of water falling into a pool of water.
'* Copyright (c) 1994 Microsoft Corporation
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************
Const FLOAT_SMALL = 0.000001
Const DROPPREC = 10
Const myrotInc = 0.1
Const mzrotInc = 0
' Remember from pre-calc:
'      x = r cos th
'      y = r sin th
' to convert from polar to rect, and that
'      x = x' cos th - y' sin th
'      y = x' sin th + y' cos th
' to rotate axes.
'
' Also, note that the equation for a lemniscate is:
'      r = sqrt(sin 2*th)
'
Dim m_Prec&
Dim m_fRadiusFact!
Dim m_Circle!()
Dim m_Drop!()
Dim m_Curves() As glxCurve
Dim m_Drops() As glxMesh
Dim m_DropList&(0 To DROPPREC - 1)
Dim m_WaterMesh As glxMesh
Dim m_WaterInMesh As glxMesh
Dim m_WaterOutMesh As glxMesh
Dim m_WaterBorderMesh As glxMesh
'
Dim m_ZrotInc#
Dim m_YrotInc#
Dim m_YPos#
Dim m_Radius#
Dim m_Damp#
Dim m_W#
Dim m_Freq#
Dim m_PosInc#
Dim m_Minr#, m_Mag#
'
Dim m_ZRot#, m_YRot#
'dim m_MXRrot#
Dim m_MYRot#
'dim m_MZRot#
'Dim m_MXRotInc#
Dim m_DropNum&
Dim m_Dist#, m_HSV&, m_ThetaInc#


Private Sub Class_Initialize()
m_fRadiusFact = 0.35
m_ZrotInc = 3
m_YrotInc = 1.5
m_YPos = 1
m_Radius = 0.3
m_Damp = 1
m_W = 1
m_Freq = 1
End Sub

Private Sub Class_Terminate()
    Set m_WaterMesh = Nothing
    Set m_WaterInMesh = Nothing
    Set m_WaterOutMesh = Nothing
    Set m_WaterBorderMesh = Nothing
End Sub

Public Sub InitDropScene()
Dim i&, id&
With gCtl
    m_Prec = optTesselFact * 10.5
    If m_Prec < 4 Then m_Prec = 4
    If optTesselFact > m_fRadiusFact Then m_fRadiusFact = optTesselFact
    m_PosInc = 1 / m_Prec
    m_ThetaInc = (2 * PI) / m_Prec

    ReDim m_Circle(0 To m_Prec - 1, 0 To 2)
    ReDim m_Drop(0 To m_Prec - 1, 0 To 2)
    ReDim m_Curves(0 To DROPPREC - 1)
    For i = 0 To DROPPREC - 1
        Set m_Curves(i) = .NewCurve
        m_Curves(i).Init m_Prec
    Next
    ReDim m_Drops(0 To DROPPREC - 1)
    
    Set m_WaterInMesh = .NewMesh
    m_WaterInMesh.Init m_Prec * m_Prec, m_Prec * m_Prec + m_Prec
    Set m_WaterOutMesh = .NewMesh
    m_WaterOutMesh.Init m_Prec * m_Prec, m_Prec * m_Prec + m_Prec
    Set m_WaterMesh = .NewMesh
    m_WaterMesh.Init m_Prec * m_Prec, m_Prec * m_Prec + m_Prec
    Set m_WaterBorderMesh = .NewMesh
    m_WaterBorderMesh.Init m_Prec, 2 * m_Prec
    
#If DebugMode Then
    glDisable GL_CULL_FACE
#End If
    'this sample uses the Camera in the ocx to control the
    'view. This allows the ocx to do aspect ratio corrections.
    'The original SDK samples are drawn into fixed-size floating windows
    'and do not consider this issue.
    With gCtl.Camera
        'for perspective view, set the following
        'note: a translation will also be needed before drawing, and
        'the rendering displays errors which I haven't investigated
        '.fieldOfView = 45
        '.NearPlane = 0
        '.FarPlane = 10
        '
        'use ortho projection
        .SetOrtho -1.5, 1.5, -1.5, 1.5
        .View = glxOrtho
    End With
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glTranslatef 0, 0, -1.5

    'generate the drops and compile them into display lists
    m_GenCurves
    For i = 0 To DROPPREC - 1
        Set m_Drops(i) = .NewMesh
        m_Drops(i).Init m_Prec * m_Prec, 4 * m_Prec * m_Prec
        m_Drops(i).RevolveSurface2 m_Curves(i), m_Prec
    Next
    For i = 0 To DROPPREC - 1
        id = &H10 + i
        m_DropList(i) = id
        m_Drops(i).MakeList id
    Next

    'release the data used to build the drop list
    Erase m_Circle
    Erase m_Drop
    For i = 0 To DROPPREC - 1
        Set m_Curves(i) = Nothing
    Next
    For i = 0 To DROPPREC - 1
        Set m_Drops(i) = Nothing
    Next
    Erase m_Curves
    Erase m_Drops
    '
    m_GenWaterInit
    With gCtl.Lights(liLight0)
        .SetAmbient 0.2, 0.2, 0.2
        .SetDiffuse 0.5, 0.5, 0.5
        .SetSpecular 0.5, 0.5, 0.5
        .SetPosition 0, 10, 10
    End With
End With
End Sub


Public Sub UpdateDropScene(flags&)
Dim Color!(0 To 3)
    glPushMatrix
        m_UpdateRotation
        m_GenWater m_Freq, m_Damp, m_Mag, m_W, m_Minr
        glRotatef m_ZRot, 0, 0, 1
        glRotatef 30, 1, 0, 0
        'if using perspective, use the second line
        glTranslatef 0, 0, -1
        'glTranslatef 0, -1, -3
    
        glPushMatrix
            glTranslatef 0, -0.5, 0
            glRotatef m_MYRot * (180 / PI), 0, 1, 0
            If optColorCycle Then
                gCtl.Ex.HSVtoRGB CSng(m_HSV), 1, 1, Color
                glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, Color(0)
                m_HSV = m_HSV + 1
                m_HSV = m_HSV Mod 360
            Else
                glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, Material(6).Diffuse(0)
            End If
            m_WaterMesh.UpdateObject optSmoothShading

            If optSmoothShading Then
                glShadeModel GL_FLAT
            End If
            If optColorCycle = False Then
                glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, Material(2).Diffuse(0)
            End If
            m_WaterBorderMesh.updateObject2 False
        glPopMatrix

        If optSmoothShading Then
            glShadeModel GL_SMOOTH
        End If
        If m_Dist > -m_Radius Then
            If optColorCycle = False Then
                glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, Material(6).Diffuse(0)
            End If
            glTranslatef 0, m_YPos, 0
            glScalef m_Radius, m_Radius, m_Radius
            glRotatef 180, 1, 0, 0
            glEnable GL_NORMALIZE
            glCallList m_DropList(m_DropNum)
            glDisable GL_NORMALIZE
        End If
        m_MYRot = m_MYRot + myrotInc
        m_YPos = m_YPos - 0.08
        m_DropNum = (DROPPREC - 1) - m_YPos * (DROPPREC - 1)
        If m_DropNum > (DROPPREC - 1) Then
            m_DropNum = DROPPREC - 1
        End If
    glPopMatrix
End Sub

Private Sub m_GenCurves()
Dim i&, angle#, j&
Dim step#
Dim start#
Dim rotSin#
Dim rotCos#
Dim aFract#
Dim bFract#
Dim fractInc#
Dim X#, Y#, r#
Dim xrot#, yrot#
Dim sinVal#
step = -PI / (m_Prec - 1)
start = PI / 2
rotSin = Sin(PI / 4)
rotCos = Cos(PI / 4)
bFract = 1
fractInc = 1 / (m_Prec - 1)
    angle = start
    'generate circles
    For i = 0 To m_Prec - 1 '; i++, ) {
        m_Circle(i, 0) = (0.5 * Cos(angle)) 'x
        m_Circle(i, 1) = (0.5 * Sin(angle)) 'y
        angle = angle + step
    Next
    'drop
    step = (-PI / 4) / (m_Prec - 1)
    start = PI / 4
    angle = start
    For i = 0 To m_Prec - 1
        sinVal = Sin(2 * angle)
        If sinVal < 0 Then
            sinVal = -sinVal
        End If
        r = 1.5 * Sqr(sinVal)
        X = r * Cos(angle)
        Y = r * Sin(angle)
        xrot = X * rotCos - Y * rotSin
        yrot = X * rotSin + Y * rotCos - 1
        m_Drop(i, 0) = xrot
        m_Drop(i, 1) = yrot
        angle = angle + step
    Next
    'curves
    For i = 0 To DROPPREC - 1
        For j = 0 To m_Prec - 1 '; j++, pt++) {
            m_Curves(i).X(j) = (aFract * m_Circle(j, 0) + bFract * m_Drop(j, 0))
            m_Curves(i).Y(j) = (aFract * m_Circle(j, 1) + bFract * m_Drop(j, 1))
            m_Curves(i).Z(j) = 0
        Next
        aFract = aFract + fractInc
        bFract = bFract - fractInc
    Next
End Sub

'one time initialization of the vertex array
'sets x and z values for the mesh
Private Sub m_GenWaterInit()
Dim i&, j& ', r#
Dim theta#
Dim X!, Z!, dx!, dz!, rr!
Dim xCenter#, zCenter#
    For i = 0 To m_Prec - 1 ' i++, r += posInc) {
        theta = 0
        For j = 0 To m_Prec - 1 '; j++, theta += thetaInc) {
            X = Cos(theta)
            Z = Sin(theta)
            dx = X - xCenter
            dz = Z - zCenter
            rr = Sqr((dx * dx) + (dz * dz))
            dx = dx / rr
            dz = dz / rr
            dx = dx * (i / (m_Prec - 1))
            dz = dz * (i / (m_Prec - 1))
            m_WaterMesh.VertexX(i * m_Prec + j) = dx + xCenter
            m_WaterMesh.VertexZ(i * m_Prec + j) = dz + zCenter
            m_WaterInMesh.VertexY(i * m_Prec + j) = 0
            m_WaterOutMesh.VertexY(i * m_Prec + j) = 0
            theta = theta + m_ThetaInc
        Next
        'r = r + m_PosInc
    Next
End Sub

Private Sub m_GenWater(Freq#, Damp#, Mag#, w#, Minr#)
Dim i&, j&
Dim norm!(0 To 2)
Dim a!, b!, c!
    '
    'generate wave vertexes
    m_GenWaterInOutMesh Freq#, Damp#, Mag#, w#, Minr#
    '
    m_WaterMesh.NumFaces = 0
    m_WaterBorderMesh.NumFaces = 0
    m_WaterMesh.ClearNorms
    '
    For i = 0 To m_Prec - 1
        For j = 0 To m_Prec - 1
            'set water y
            m_WaterMesh.VertexY(i * m_Prec + j) = _
                m_WaterOutMesh.VertexY(i * m_Prec + j) + _
                m_WaterInMesh.VertexY(i * m_Prec + j)
            'set edge to zero
            If i = (m_Prec - 1) Then
                m_WaterMesh.VertexY(i * m_Prec + j) = 0
                m_WaterMesh.GetVertex i * m_Prec + j, a, b, c
                m_WaterBorderMesh.SetVertex j, a, b, c
                m_WaterBorderMesh.SetVertex m_Prec + j, a, -0.5, c
            End If
        Next
    Next
    '
    m_WaterBorderMesh.ClearNorms
    '
    'calculate normals and set face data for the meshes which are drawn
    m_GenWaterMesh
    m_GenWaterBorderMesh
End Sub

Private Sub m_GenWaterInOutMesh(Freq#, Damp#, Mag#, w#, Minr#)
Dim i&, j&, r#, v!
Dim norm!(0 To 2)
    'calculate OutMesh Y
    r = 1
    For i = (m_Prec - 1) To 0 Step -1 ' r -= posInc) {
        If i = 0 Then
            If Minr <> 0 Then
                v = -Mag * Cos(w + (r * Freq)) * Exp((-Damp * r) / 2)
            Else
                v = m_WaterInMesh.VertexY(0) * 0.95
            End If
        Else
            v = m_WaterOutMesh.VertexY((i - 1) * m_Prec) * 0.95
        End If
        '
        For j = 0 To m_Prec - 1
            m_WaterOutMesh.VertexY(i * m_Prec + j) = v
        Next
        r = r - m_PosInc
    Next
    
    'calculate InMesh Y
    r = 0
    For i = 0 To m_Prec - 1 ' r += posInc) {
        For j = 0 To m_Prec - 1
            If (i = m_Prec - 1) Then
                m_WaterInMesh.VertexY(i * m_Prec + j) = _
                    -(m_WaterOutMesh.VertexY(i * m_Prec + j))
            Else
                m_WaterInMesh.VertexY(i * m_Prec + j) = _
                    m_WaterInMesh.VertexY((i + 1) * m_Prec + j) * 0.95
            End If
        Next
        r = r + m_PosInc
    Next
End Sub

Private Sub m_GenWaterMesh()
Dim i&, j&, l&, facecount&
Dim norm!(0 To 2)
    For i = 0 To (m_Prec - 2)
        For j = 0 To m_Prec - 1
            If j = (m_Prec - 1) Then
                l = 0
            Else
                l = j + 1
            End If
            'calculate face normal
            m_WaterMesh.CalcNormal norm, (i + 1) * m_Prec + j, _
                                    i * m_Prec + j, _
                                    i * m_Prec + l
            If norm(0) > -FLOAT_SMALL And norm(0) < FLOAT_SMALL And _
                norm(1) > -FLOAT_SMALL And norm(1) < FLOAT_SMALL And _
                norm(2) > -FLOAT_SMALL And norm(2) < FLOAT_SMALL Then
                m_WaterMesh.CalcNormal norm, i * m_Prec + l, _
                                    (i + 1) * m_Prec + l, _
                                    (i + 1) * m_Prec + j
            End If
            m_WaterMesh.FaceMaterial(facecount) = 0
            m_WaterMesh.SetFaceNormal facecount, norm
            m_WaterMesh.IncrementNormal i * m_Prec + j, norm
            m_WaterMesh.IncrementNormal (i + 1) * m_Prec + j, norm
            m_WaterMesh.IncrementNormal i * m_Prec + l, norm
            m_WaterMesh.IncrementNormal (i + 1) * m_Prec + l, norm
            'set the face's vertices
            m_WaterMesh.pA(facecount) = (i + 1) * m_Prec + j
            m_WaterMesh.pB(facecount) = i * m_Prec + j
            m_WaterMesh.pC(facecount) = (i + 1) * m_Prec + l
            m_WaterMesh.pD(facecount) = i * m_Prec + l
            m_WaterMesh.NumFaces = m_WaterMesh.NumFaces + 1
            facecount = facecount + 1
        Next
    Next
    m_WaterMesh.NumPoints = m_Prec * m_Prec
    m_WaterMesh.NormalizeNorms
End Sub

Private Sub m_GenWaterBorderMesh()
Dim i&, j&
Dim norm!(0 To 2)
    For i = 0 To m_Prec - 1
        If i = (m_Prec - 1) Then
            j = 0
        Else
            j = i + 1
        End If
        m_WaterBorderMesh.CalcNormal norm, m_Prec + i, i, j
        m_WaterBorderMesh.FaceMaterial(i) = 0
        m_WaterBorderMesh.SetFaceNormal i, norm
        '###
        m_WaterBorderMesh.SetNormal m_Prec + i, norm(0), norm(1), norm(2)
        If i Then
            m_WaterBorderMesh.SetNormal m_Prec + i - 1, norm(0), norm(1), norm(2)
        End If
        m_WaterBorderMesh.SetNormal m_Prec + i, norm(0), norm(1), norm(2)
        m_WaterBorderMesh.SetNormal j, norm(0), norm(1), norm(2)
        
        m_WaterBorderMesh.pA(i) = m_Prec + i
        m_WaterBorderMesh.pB(i) = i
        m_WaterBorderMesh.pC(i) = m_Prec + j
        m_WaterBorderMesh.pD(i) = j
        m_WaterBorderMesh.NumFaces = m_WaterBorderMesh.NumFaces + 1
    Next
    m_WaterBorderMesh.NumPoints = 2 * m_Prec
    m_WaterBorderMesh.NormalizeNorms
End Sub

Private Sub m_UpdateRotation()
    m_ZRot = m_ZRot + m_ZrotInc
    If m_ZRot >= 45 Then
        m_ZRot = 45
        m_ZrotInc = -(2 + (Rnd()) * 3)
    ElseIf m_ZRot <= -45 Then
        m_ZRot = -45
        m_ZrotInc = 2 + (Rnd()) * 3
    End If

    m_YRot = m_YRot + m_YrotInc
    If m_YRot >= 10 Then
        m_YRot = 10
        m_YrotInc = -(1 + (Rnd()) * 2)
    ElseIf (m_ZRot <= -10) Then
        m_YRot = -10
        m_YrotInc = 1 + (Rnd()) * 2
    End If

    If (m_YPos + 0.5 < -m_Radius) And (m_Mag < 0.05) Then
        m_Radius = Rnd() / 6 + 0.1
        m_YPos = 1
        m_DropNum = 0
    End If
    m_Dist = m_YPos + 0.5
    '
    If (m_Dist > -m_Radius / 2) And (m_Dist < m_Radius / 2) Then
        If m_Dist <= 0 Then
            m_Dist = m_Radius / 2
        Else
            m_Dist = m_Radius / 2 - m_Dist
        End If
        m_Freq = (0.25 * PI) / m_Dist
        If m_Freq < 0.2 Then m_Freq = 0.2
        m_Minr = m_Radius
        m_Damp = 20
        m_Mag = 0.35 / m_fRadiusFact + 0.2 * m_Dist
        m_W = 0
    Else
        m_Minr = m_Minr - 0.05
        If m_Minr < 0 Then m_Minr = 0
        m_Mag = m_Mag * 0.95
        If m_Minr = 0 Then
            m_W = m_W - PI / 6
            m_Mag = m_Mag * 0.75
        End If
        If m_Damp > 0 Then m_Damp = m_Damp - 1
    End If

End Sub


