VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CTexFlag"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'* Module Name: gentex.c
'FUNCTION:
'* The Textured Flag style of the 3D Flying Objects screen saver.
'* Texture maps .BMP files onto a simulation of a flag waving in the breeze.
'* Copyright (c) 1994 Microsoft Corporation
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'/*************************************************************************

Const MAX_FRAMES = 20
' IPREC is the number of faces in the mesh that models the flag.
Const iPrec = 15
Private Enum FlagColors
    txWhite = 0
    txRed = 1
End Enum

Dim winTotalwidth!
Dim winTotalheight!
Dim Frames&
Dim winMesh(0 To MAX_FRAMES - 1) As glxMesh
Dim sinAngle!
Dim xTrans!
Dim curMatl As FlagColors
' Material properties.
Dim m_MatWhite As glxMaterial
Dim m_MatRed As glxMaterial
'
Dim mxrot#, myrot#, mzrot#, mxrotInc#, myrotInc#, mzrotInc#
Dim h&, frameNum&
Dim tex As glxTexture


Private Sub Class_Initialize()
winTotalwidth = 0.75
winTotalheight = 0.75 * 0.75
Frames = 10
mxrot = 23
myrot = 23
mzrot = 5.7
'mxrotInc = 1
myrotInc = 3
'mzrotInc = 3
curMatl = txRed
End Sub

Private Sub Class_Terminate()
Dim i&
    For i = 0 To Frames - 1
        Set winMesh(i) = Nothing
    Next
    Set tex = Nothing
End Sub

'/******************************Public*Routine*****************************
'* getZpos
'* Get the z-position (depth) of the "wavy" flag component at the given x.
'* The function used to model the wave is:
'*        1/2
'*   z = x    * sin((2*PI*x + sinAngle) / 4)
'* The shape of the wave varies from frame to frame by changing the
'* phase, sinAngle.
'\*************************************************************************
Private Function m_GetZpos!(X!)
Dim xAbs!, angle!
    xAbs = X - xTrans
    angle = sinAngle + ((2 * PI) * (xAbs / winTotalwidth))
    xAbs = winTotalwidth - xAbs
    m_GetZpos = ((Sin(angle) / 4) * Sqr((xAbs / winTotalwidth)))
End Function

'/******************************Public*Routine*****************************
'* initTexScene
'* Initialize the screen saver.
'\*************************************************************************
Public Sub InitTexScene()
Dim i&, angleDelta!, aspectRatio!, r&
    ' Initialize the transform.
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glOrtho -0.25, 1, -0.25, 1, 0, 3
    glTranslatef 0, 0, -1.5
    glDisable GL_DEPTH_TEST
    With gCtl.Lights(liLight0)
        .SetPosition 25, 5, 20
        .SetAmbient 0.4, 0.4, 0.4
        .SetSpecular 1, 1, 1
        .SetDiffuse 0.5, 0.5, 0.5
        .Enabled = True
    End With
    With gCtl.Lights(liLight1)
        .SetPosition -25, 5, 0
        .SetAmbient 0, 0, 0
        .SetDiffuse 0.4, 0.4, 0.4
        .SetSpecular 0, 0, 0
        .Enabled = True
    End With
        
    Set m_MatWhite = gCtl.NewMaterial
    Set m_MatRed = gCtl.NewMaterial
    m_MatWhite.SetDiffuse 0.8, 0.8, 0.8
    m_MatWhite.SetAmbient 0.8, 0.8, 0.8
    m_MatWhite.SetSpecular 1, 1, 1
    m_MatRed.SetAmbient 0.94, 0.37, 0.13
    m_MatRed.SetDiffuse 0.94, 0.37, 0.13
    
    ' Leave OpenGL in a state ready to accept the model view transform (we
    ' are going to have the flag vary its orientation from frame to frame).
    glMatrixMode GL_MODELVIEW
    ' Define orientation of polygon faces.
    glFrontFace GL_CW
    glDisable GL_CULL_FACE
    Frames = ((MAX_FRAMES / 2) * optTesselFact)
    ' Load user texture - if that fails load default texture resource
    glPixelStorei GL_UNPACK_ALIGNMENT, 1
    Set tex = gCtl.NewTexture
    If optTextureFile = "" Then
        optTextureFile = App.Path & "\tex.jpg" '  "\winnt.bmp" '
    End If
    r = tex.LoadTextureFile(optTextureFile)
    If r = 0 Then
        r = tex.LoadTextureResource(0)
    End If
    If r Then
        glEnable GL_TEXTURE_2D
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
        glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST
        glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST
        tex.SetTexture
        ' Correct aspect ratio of flag to match image.
        '
        ' The 1.4 is a correction factor to account for the length of the
        ' curve that models the surface ripple of the waving flag.  This
        ' factor is the length of the curve at zero phase.  It would be
        ' more accurate to determine the length of the curve at each phase,
        ' but this is a sufficient approximation for our purposes.

        aspectRatio = (tex.Image.Height / tex.Image.Width) * 1.4

        If (aspectRatio < 1) Then
            winTotalwidth = 0.75
            winTotalheight = winTotalwidth * aspectRatio
        Else
            winTotalheight = 0.75
            winTotalwidth = winTotalheight / aspectRatio
        End If
    End If

    If (Frames < 5) Then Frames = 5
    If (Frames > MAX_FRAMES) Then Frames = MAX_FRAMES
    ' Generate the geometry data (stored in the array of mesh structures),
    ' for each frame of the animation.  The shape of the flag is varied by
    ' changing the global variable sinAngle.
    angleDelta = (2 * PI) / Frames
    sinAngle = 0
    With gCtl
    For i = 0 To Frames - 1
        Set winMesh(i) = .NewMesh
        m_GenTex i
        sinAngle = sinAngle + angleDelta
    Next
    End With
End Sub

'/******************************Public*Routine*****************************
'* updateTexScene
'* Generate a scene by taking one of the meshes and rendering it with
'* OpenGL.
'* This function is exported to the main module in ss3dfo.c.
'\*************************************************************************
Public Sub UpdateTexScene(flags&)
Dim mesh As glxMesh, r&
Dim i&, lastC&, lastD&
Dim a&, b&, s!, ds!
    ' In addition to having the flag wave (an effect acheived by switching
    ' meshes from frame to frame), the flag changes its orientation from
    ' frame to frame.  This is done by applying a model view transform.
    glLoadIdentity
    glRotatef mxrot, 1, 0, 0
    glRotatef myrot, 0, 1, 0
    glRotatef mzrot, 0, 0, 1
    ' Divide the texture into IPREC slices.  ds is the texture coordinate
    ' delta we apply as we move along the x-axis.
    ds = 1 / iPrec
    ' Setup the material property of the flag.  The material property, light
    ' properties, and polygon orientation will interact with the texture.
    If curMatl = txRed Then
        m_MatRed.SetMaterial
    ElseIf curMatl = txWhite Then
        m_MatWhite.SetMaterial
    End If

    ' Pick the mesh for the current frame.
    Set mesh = winMesh(frameNum)
    ' Take the geometry data is the mesh and convert it to a single OpenGL
    ' quad strip.  If smooth shading is required, use the vertex normals stored
    ' in the mesh.  Otherwise, use the face normals.
    ' As we define each vertex, we also define a corresponding vertex and
    ' texture coordinate.
    glBegin GL_QUAD_STRIP
    lastC = mesh.pA(0)
    lastD = mesh.pB(0)
    For i = 0 To mesh.NumFaces - 1 '; i++, faces++) {
        a = mesh.pA(i)
        b = mesh.pB(i)
        If mesh.FaceMaterial(i) <> curMatl Then
            Debug.Assert 0
            curMatl = mesh.FaceMaterial(i)
            If curMatl = txWhite Then
                m_MatWhite.SetMaterial
            Else
                m_MatRed.SetMaterial
            End If
        End If
        If optSmoothShading = False Then
            mesh.glNormalv i
            glTexCoord2f s, 0
            mesh.glVertexv a
            glTexCoord2f s, 1
            mesh.glVertexv b
        Else
            glTexCoord2f s, 0
            mesh.glNormalv a
            mesh.glVertexv a
            glTexCoord2f s, 1
            mesh.glNormalv b
            mesh.glVertexv b
        End If
        s = s + ds
        lastC = mesh.pC(i)
        lastD = mesh.pD(i)
    Next

    If optSmoothShading = False Then
        mesh.glNormalv i - 1
        glTexCoord2f s, 0
        mesh.glVertexv lastC
        glTexCoord2f s, 1
        mesh.glVertexv lastD
    Else
        glTexCoord2f s, 0
        mesh.glNormalv lastC
        mesh.glVertexv lastC
        glTexCoord2f s, 1
        mesh.glNormalv lastD
        mesh.glVertexv lastD
    End If

    glEnd
    ' Transfer the image to the floating OpenGL window.
    ' Determine the flag orientation for the next frame.
    ' What we are doing is an oscillating rotation about the y-axis
    ' (mxrotInc and mzrotInc are currently 0).
    mxrot = mxrot + mxrotInc
    myrot = myrot + myrotInc
    mzrot = mzrot + mzrotInc
    If ((myrot < -65) Or (myrot > 25)) Then
        myrotInc = -myrotInc
    End If
    '
    frameNum = frameNum + 1
    If frameNum >= Frames Then frameNum = 0
End Sub

'/******************************Public*Routine*****************************
'* genTex
'* Generate a mesh representing a frame of the flag.  The phase, sinAngle,
'* is a global variable.
'\*************************************************************************
Private Sub m_GenTex(Index&)
Dim pos!(0 To 2)
Dim ptA!(0 To 2)
Dim ptB!(0 To 2)
Dim ptC!(0 To 2)
Dim ptD!(0 To 2)
Dim w!, h!, i&, facecount&
Dim mesh As glxMesh
    Set mesh = winMesh(Index)
    mesh.Init iPrec * iPrec, iPrec * iPrec
    ' Width and height of each face
    w = (winTotalwidth) / (iPrec + 1)
    h = winTotalheight
    ' Generate the mesh data.  At equally spaced intervals along the x-axis,
    ' we compute the z-position of the flag surface.
    pos(1) = 0
    pos(2) = 0
    pos(0) = xTrans
    For i = 0 To iPrec - 1
        facecount = mesh.NumFaces
        If facecount <> i Then Debug.Assert 0
        ptA(0) = pos(0)
        ptA(1) = 0 'pos(1)
        ptA(2) = m_GetZpos(pos(0))

        ptB(0) = ptA(0) 'pos(0)
        ptB(1) = h 'pos(1) + h
        ptB(2) = ptA(2) 'm_GetZpos(pos(0))

        ptC(0) = pos(0) + w
        ptC(1) = 0 'pos(1)
        ptC(2) = m_GetZpos(pos(0) + w)

        ptD(0) = ptC(0) 'pos(0) + w
        ptD(1) = h 'pos(1) + h
        ptD(2) = ptC(2) 'm_GetZpos(pos(0) + w)
        ' Compute the face normal.
        m_CalcMeshNorm mesh, facecount, ptC, ptB, ptA
        ' Add the face to the mesh.
        mesh.FaceMaterial(facecount) = curMatl
        mesh.pA(facecount) = iPtInList(mesh, 0, ptA, facecount, True)
        mesh.pB(facecount) = iPtInList(mesh, 0, ptB, facecount, True)
        mesh.pC(facecount) = iPtInList(mesh, 0, ptC, facecount, True)
        mesh.pD(facecount) = iPtInList(mesh, 0, ptD, facecount, True)
        mesh.NumFaces = mesh.NumFaces + 1
    pos(0) = pos(0) + w
    Next
' Normalize the vertex normals in the mesh.
    mesh.NormalizeNorms
End Sub

'/******************************Public*Routine*****************************
'* iPtInList
'* Add a vertex and its normal to the mesh.  If the vertex already exists,
'* add in the normal to the existing normal (we to accumulate the average
'* normal at each vertex).  Normalization of the normals is the
'* responsibility of the caller.
'*
'\*************************************************************************
Private Function iPtInList&(mesh As glxMesh, start&, P!(), facecount&, blend As Boolean)
Dim i&, ndx&
Dim norm!(0 To 2)
    ndx = start
    mesh.GetNormalv facecount, norm
    If blend Then
        For i = start To mesh.NumPoints - 1 '; i++, pts++) {
            If mesh.VertexX(i) = P(0) And _
                mesh.VertexY(i) = P(1) And mesh.VertexZ(i) = P(2) Then
                mesh.IncrementNormal i, norm
                iPtInList = i
                Exit Function
            End If
        Next
    End If
    i = mesh.NumPoints
    mesh.SetVertexv i, P
    mesh.SetNormalv i, norm
    mesh.NumPoints = mesh.NumPoints + 1
    iPtInList = i
End Function

Private Sub m_CalcMeshNorm(mesh As glxMesh, faceIndex&, p1!(), p2!(), p3!())
Dim crossX!, crossY!, crossZ!
Dim abX!, abY!, abZ!
Dim acX!, acY!, acZ!
Dim sqrLength!
Dim invLength!

    abX = p2(0) - p1(0)   '      ' calculate p2 - p1
    abY = p2(1) - p1(1)
    abZ = p2(2) - p1(2)

    acX = p3(0) - p1(0)   '      ' calculate p3 - p1
    acY = p3(1) - p1(1)
    acZ = p3(2) - p1(2)

    crossX = (abY * acZ) - (abZ * acY) '   ' get cross product
    crossY = (abZ * acX) - (abX * acZ) '   ' (p2 - p1) X (p3 - p1)
    crossZ = (abX * acY) - (abY * acX)

    sqrLength = (crossX * crossX) + (crossY * crossY) + _
                 (crossZ * crossZ)

    If (sqrLength > ZERO_EPS) Then
        invLength = (1 / Sqr(sqrLength))
    Else
        invLength = 1
    End If

    mesh.SetNormal faceIndex, crossX * invLength, crossY * invLength, crossZ * invLength
End Sub


