VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.1#0"; "COMDLG32.OCX"
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.2#0"; "COMCTL32.OCX"
Begin VB.Form dlgConfig 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "3D Flying Objects Configuration"
   ClientHeight    =   5220
   ClientLeft      =   945
   ClientTop       =   3255
   ClientWidth     =   6705
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5220
   ScaleWidth      =   6705
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Frame1 
      Caption         =   "Spin style"
      Height          =   1275
      Left            =   3420
      TabIndex        =   21
      Top             =   3195
      Width           =   3120
      Begin VB.ComboBox cmbRotStyle 
         Height          =   315
         ItemData        =   "dlgConfig.frx":0000
         Left            =   315
         List            =   "dlgConfig.frx":0002
         TabIndex        =   0
         Text            =   "Combo1"
         Top             =   540
         Width           =   2535
      End
   End
   Begin VB.Frame Frame 
      Caption         =   "Display"
      Height          =   1545
      Index           =   0
      Left            =   135
      TabIndex        =   17
      Top             =   135
      Width           =   3120
      Begin VB.CommandButton btnFile 
         Caption         =   "File..."
         Enabled         =   0   'False
         Height          =   375
         Left            =   1665
         TabIndex        =   27
         Top             =   1035
         Width           =   1230
      End
      Begin VB.OptionButton optTxt 
         Caption         =   "Variable"
         Height          =   240
         Index           =   2
         Left            =   270
         TabIndex        =   26
         Top             =   1125
         Width           =   1185
      End
      Begin VB.OptionButton optTxt 
         Caption         =   "Text:"
         Height          =   240
         Index           =   0
         Left            =   270
         TabIndex        =   20
         Top             =   315
         Value           =   -1  'True
         Width           =   735
      End
      Begin VB.OptionButton optTxt 
         Caption         =   "Time"
         Height          =   240
         Index           =   1
         Left            =   270
         TabIndex        =   19
         Top             =   720
         Width           =   1185
      End
      Begin VB.TextBox txtText 
         Height          =   330
         Left            =   1080
         TabIndex        =   18
         Text            =   "OpenGL"
         Top             =   270
         Width           =   1860
      End
   End
   Begin VB.Frame Frame 
      Caption         =   "Surface style"
      Height          =   1545
      Index           =   1
      Left            =   3420
      TabIndex        =   13
      Top             =   135
      Width           =   3120
      Begin VB.OptionButton optSurfStyle 
         Caption         =   "Wireframe"
         Height          =   240
         Index           =   1
         Left            =   270
         TabIndex        =   25
         Top             =   720
         Width           =   1185
      End
      Begin VB.OptionButton optSurfStyle 
         Caption         =   "Solid color"
         Height          =   240
         Index           =   0
         Left            =   270
         TabIndex        =   16
         Top             =   315
         Value           =   -1  'True
         Width           =   1185
      End
      Begin VB.OptionButton optSurfStyle 
         Caption         =   "Textured"
         Height          =   240
         Index           =   2
         Left            =   270
         TabIndex        =   15
         Top             =   1125
         Width           =   1050
      End
      Begin VB.CommandButton btnTexture 
         Caption         =   "Texture..."
         Enabled         =   0   'False
         Height          =   375
         Left            =   1665
         TabIndex        =   14
         Top             =   1035
         Width           =   1230
      End
   End
   Begin VB.Frame Frame 
      Caption         =   "Size"
      Height          =   1275
      Index           =   2
      Left            =   135
      TabIndex        =   10
      Top             =   1800
      Width           =   3120
      Begin ComctlLib.Slider slSize 
         Height          =   375
         Left            =   270
         TabIndex        =   22
         Top             =   765
         Width           =   2580
         _ExtentX        =   4551
         _ExtentY        =   661
         _Version        =   327682
         LargeChange     =   10
         SmallChange     =   5
         Max             =   100
         TickStyle       =   3
      End
      Begin VB.Label Label1 
         Caption         =   "Small"
         Height          =   240
         Left            =   270
         TabIndex        =   12
         Top             =   405
         Width           =   1005
      End
      Begin VB.Label Label2 
         Alignment       =   1  'Right Justify
         Caption         =   "Large"
         Height          =   285
         Left            =   1800
         TabIndex        =   11
         Top             =   405
         Width           =   1050
      End
   End
   Begin VB.Frame Frame 
      Caption         =   "Speed"
      Height          =   1275
      Index           =   3
      Left            =   3420
      TabIndex        =   7
      Top             =   1800
      Width           =   3120
      Begin ComctlLib.Slider slSpeed 
         Height          =   375
         Left            =   270
         TabIndex        =   23
         Top             =   720
         Width           =   2580
         _ExtentX        =   4551
         _ExtentY        =   661
         _Version        =   327682
         LargeChange     =   10
         SmallChange     =   5
         Max             =   100
         TickStyle       =   3
      End
      Begin VB.Label Label3 
         Alignment       =   1  'Right Justify
         Caption         =   "Fast"
         Height          =   285
         Left            =   1800
         TabIndex        =   9
         Top             =   405
         Width           =   1050
      End
      Begin VB.Label Label4 
         Caption         =   "Slow"
         Height          =   240
         Left            =   270
         TabIndex        =   8
         Top             =   405
         Width           =   1005
      End
   End
   Begin VB.Frame Frame 
      Caption         =   "Resolution"
      Height          =   1275
      Index           =   4
      Left            =   135
      TabIndex        =   4
      Top             =   3195
      Width           =   3120
      Begin ComctlLib.Slider slResolution 
         Height          =   375
         Left            =   270
         TabIndex        =   24
         Top             =   720
         Width           =   2580
         _ExtentX        =   4551
         _ExtentY        =   661
         _Version        =   327682
         LargeChange     =   10
         SmallChange     =   5
         Max             =   100
         TickStyle       =   3
      End
      Begin VB.Label Label5 
         Alignment       =   1  'Right Justify
         Caption         =   "Max"
         Height          =   285
         Left            =   1800
         TabIndex        =   6
         Top             =   405
         Width           =   1050
      End
      Begin VB.Label Label6 
         Caption         =   "Min"
         Height          =   240
         Left            =   270
         TabIndex        =   5
         Top             =   405
         Width           =   1005
      End
   End
   Begin VB.CommandButton btnFont 
      Caption         =   "Choose Font..."
      Height          =   375
      Left            =   180
      TabIndex        =   3
      Top             =   4680
      Width           =   1680
   End
   Begin VB.CommandButton btnOK 
      Caption         =   "OK"
      Height          =   375
      Left            =   4860
      TabIndex        =   2
      Top             =   4680
      Width           =   1680
   End
   Begin VB.CommandButton btnCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3060
      TabIndex        =   1
      Top             =   4680
      Width           =   1680
   End
   Begin MSComDlg.CommonDialog CD 
      Left            =   6795
      Top             =   90
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   327681
      CancelError     =   -1  'True
   End
End
Attribute VB_Name = "dlgConfig"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim m_Texture$
Dim m_Font$
Dim m_Bold As Boolean
Dim m_Italic As Boolean
'Dim m_charset As Byte
Dim m_File$

Private Sub btnCancel_Click()
Unload Me
End Sub

Private Sub btnFile_Click()
m_File = GetFile
End Sub

Private Sub btnFont_Click()
GetFont m_Font, m_Bold, m_Italic
End Sub

Private Sub btnOK_Click()
optText = txtText.Text
'
If optTxt(0).Value Then
    optDemoType = DEMO_STRING
ElseIf optTxt(1).Value Then
    optDemoType = DEMO_CLOCK
Else: optDemoType = DEMO_VSTRING
End If
'
If optSurfStyle(0).Value Then
    optSurfaceStyle = SURFSTYLE_SOLID
ElseIf optSurfStyle(1).Value Then
    optSurfaceStyle = SURFSTYLE_WIREFRAME
Else: optSurfaceStyle = SURFSTYLE_TEX
End If
optTextureFile = m_Texture
optSize = slSize.Value
optSpeed = slSpeed.Value
optTessFactor = slResolution.Value
optRotationStyle = cmbRotStyle.ListIndex
optFontName = m_Font
optBold = IIf(m_Bold, True, 0)
optItalic = IIf(m_Italic, True, 0)
optTextFile = m_File
SaveIniSettings
g3D.Reset
Unload Me
End Sub

Private Sub btnTexture_Click()
m_Texture = GetTextureFile
End Sub

Private Sub Form_Load()
txtText = optText
'
If optDemoType = DEMO_STRING Then
    optTxt(0).Value = 1
ElseIf optDemoType = DEMO_CLOCK Then
    optTxt(1).Value = 1
Else: optTxt(2).Value = 1
End If
'
If optSurfaceStyle = SURFSTYLE_SOLID Then
    optSurfStyle(0).Value = 1
ElseIf optSurfaceStyle = SURFSTYLE_WIREFRAME Then
    optSurfStyle(1).Value = 1
Else: optSurfStyle(2).Value = 1
End If
'
m_Texture = optTextureFile
m_File = optTextFile
slSize.Value = optSize
slSpeed.Value = optSpeed
slResolution.Value = optTessFactor
With cmbRotStyle
    .AddItem "None"
    .AddItem "Seesaw"
    .AddItem "Wobble"
    .AddItem "Random"
End With
cmbRotStyle.ListIndex = optRotationStyle
m_Font = optFontName
m_Bold = IIf(optBold, True, 0)
m_Italic = IIf(optItalic, True, 0)
End Sub

Private Sub optSurfStyle_Click(Index As Integer)
btnTexture.Enabled = (Index = 2)
End Sub

Private Sub optTxt_Click(Index As Integer)
txtText.Enabled = (Index = 0)
btnFile.Enabled = (Index = 2)
End Sub
