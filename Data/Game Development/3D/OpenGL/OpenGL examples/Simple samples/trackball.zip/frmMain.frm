VERSION 5.00
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Trackball Cube"
   ClientHeight    =   4500
   ClientLeft      =   480
   ClientTop       =   1050
   ClientWidth     =   4500
   Icon            =   "frmMain.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   300
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   300
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Trackball Cube - combination of trackball.c port
' and simple cube - Left mause button rotates the cube
' Shift + mouse + left mouse zoom's in+out
' ported by Michal Husak husakm@vscht.cz


Option Explicit



Dim hPalette As Long
Dim hGLRC As Long
Dim doubleBuffer As GLboolean
Dim displayListInited As GLboolean


' Trakkball declarations

Dim spinning As Boolean, moving As Boolean
Dim beginx As Integer, beginy As Integer
Dim W As Integer, H As Integer
Dim curquat(3) As GLfloat
Dim lastquat(3) As GLfloat
Dim newModel As Boolean
Dim scaling As Boolean
Dim scalefactor As Single
Dim anim As Boolean
Dim StopFlag As Boolean
' End of trackball declarations

'Stisknute tlacitko na mysi
Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error Resume Next
        If Button = vbLeftButton Then
            spinning = False
            anim = False
            moving = True
            beginx = X
            beginy = Y
            If Shift = 1 Then
                scaling = True
                Else
                scaling = False
            End If
        End If
End Sub
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = vbLeftButton Then
        moving = False
        scaling = False
    End If
End Sub

'Pohyb mysi
Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)

    H = frmMain.ScaleHeight
    W = frmMain.ScaleWidth
    
    
    If scaling Then
        scalefactor = scalefactor * (1 + ((beginy - Y) / H))
        beginx = X
        beginy = Y
        newModel = True
        Form_Paint
        spinning = True
        GoTo konec
    End If
     
    If moving Then
        trackball lastquat, ((2 * beginx - W) / W), ((H - 2 * beginy) / H), _
                ((2 * X - W) / W), ((H - 2 * Y) / H)
        'lastquat(2) = -lastquat(2)
   
        beginx = X
        beginy = Y
        spinning = True
        anim = True
    End If
konec:
End Sub

Private Sub recalcModelView()
    'Dim m(3, 3) As GLfloat
    Dim m(0 To 15) As GLfloat
    
    glPopMatrix
    glPushMatrix
    build_rotmatrix m, curquat
    glMultMatrixf m(0)
    If scalefactor = 1 Then
            glDisable GL_NORMALIZE
        Else
            glEnable GL_NORMALIZE
    End If
    
    glScalef scalefactor, scalefactor, scalefactor
    newModel = False

End Sub
' animace ve volnem case trackbalu
Private Sub animate()
Dim i As Integer

'Caution, in original c code this routine was
' containing the add_quats lastquat,curquat,curquat comand
' but it does not work in VB i do not fuly understend why
' and why the folowing sequence work Michal
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            add_quats lastquat, curquat, curquat
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            newModel = True
            Form_Paint
            'otoc
End Sub

Private Sub Form_Load()
 
    'Setting the variables for trackball
    spinning = False
    moving = False
    anim = False
    H = frmMain.ScaleHeight
    W = frmMain.ScaleWidth
    newModel = True
    scaling = False
    scalefactor = 1
    trackball curquat, 0, 0, 0, 0
    
   ' End of setings for trackball
   
   
     Dim hGLRC As Long
    doubleBuffer = GL_TRUE
    displayListInited = GL_FALSE
   
    SetupPixelFormat hDC
    hGLRC = wglCreateContext(hDC) '?????
    ' win=XCreateWindow(dpy,RootWindow(dpy, vi->screen),0,0,300,300,0,
   
    ' bind the randering context to the window
    wglMakeCurrent hDC, hGLRC
   
    
    ' ---------------------------------------------
    ' configure the OpenGL context for randering
    '----------------------------------------------
    
    glEnable GL_DEPTH_TEST

    glDepthFunc GL_LESS ' pedantic defolt
    glClearDepth 1 'pedantic defolt
    ' frame buffer clears should be to black
    glClearColor 0, 0, 0, 0 '
    ' set up projection transform
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glFrustum -1, 1, -1, 1, 1, 10
    ' ppedanticdefault
    glViewport 0, 0, frmMain.ScaleWidth, frmMain.ScaleHeight
    
    gluPerspective 40, frmMain.ScaleWidth / frmMain.ScaleHeight, 1, 40
    
    displayListInited = GL_FALSE
   
    ZapniGLfunkce 'Swith on nesssesery Glfunctions
   
  
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    gluLookAt 0, 0, 5, 0, 0, 0, 0, 1, 0
    
    Osvetli ' in Czech Language ShowLights
        
   
    
    Show
    
    
        
    Do
            'reaction on mouse and oter event enable
            DoEvents
            
           
            If anim Then animate
            If StopFlag Then Exit Do
            
    Loop

End Sub

Private Sub Form_Paint()

' +-------------------------------------------------------------------
' | If a display list has been created, use it.  Otherwise, create it.
' +-------------------------------------------------------------------
    
    ' adition for trackball
    If newModel Then
        recalcModelView
    End If
    ' end of adition for trackball
    If displayListInited = GL_TRUE Then
            glCallList 1
    Else
            glNewList 1, GL_COMPILE_AND_EXECUTE
                glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
                glColor3f 0.7, 0.7, 0.7
                glTranslatef -0.5, -0.5, -0.5
                Krychle 1 'Cube in Czech Language
                glTranslatef 0.5, 0.5, 0.5
                glEnd
            glEndList
            displayListInited = GL_TRUE
            
    End If
        SwapBuffers hDC
    
End Sub
Private Sub Form_Resize()

     H = frmMain.ScaleHeight
    W = frmMain.ScaleWidth
' awoid colisions with math overflow
    If H = 0 Then H = 1
    If W = 0 Then W = 1
    
    glViewport 0, 0, W, H
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    
    gluPerspective 40, W / H, 1, 40
  
     gluLookAt 0, 0, 5, 0, 0, 0, 0, 1, 0
  
    glMatrixMode GL_MODELVIEW
   
    Form_Paint

    End Sub

Private Sub Form_Unload(Cancel As Integer)

'Nessery to avoid unfinite Do Loop
    anim = False
    StopFlag = True
' +-------------------------------------------------------------------
' | Release OpenGL if we decide to quit.
' +-------------------------------------------------------------------
    
    If hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext hGLRC
    End If
    
    If hPalette <> 0 Then
        DeleteObject hPalette
    End If

End Sub

