Attribute VB_Name = "basShark"
'/**
' * (c) Copyright 1993, 1994, Silicon Graphics, Inc.
' * ALL RIGHTS RESERVED
' * Permission to use, copy, modify, and distribute this software for
' * any purpose and without fee is hereby granted, provided that the above
' * copyright notice appear in all copies and that both the copyright notice
' * and this permission notice appear in supporting documentation, and that
' * the name of Silicon Graphics, Inc. not be used in advertising
' * or publicity pertaining to distribution of the software without specific,
' * written prior permission.
' *
' * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
' * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
' * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
' * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
' * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
' * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
' * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
' * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
' * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
' * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
' * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
' * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
' *
' * US Government Users Restricted Rights
' * Use, duplication, or disclosure by the Government is subject to
' * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
' * (c)(1)(ii) of the Rights in Technical Data and Computer Software
' * clause at DFARS 252.227-7013 and/or in similar or successor
' * clauses in the FAR or the DOD or NASA FAR Supplement.
' * Unpublished-- rights reserved under the copyright laws of the
' * United States.  Contractor/manufacturer is Silicon Graphics,
' * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
' *
' * OpenGL(TM) is a trademark of Silicon Graphics, Inc.
' */
'include <GL/glut.h>
'include <math.h>
'include "atlantis.h"
'/* *INDENT-OFF* */
'Private N002(3) As Double

Option Explicit

Private N002(3) As Single
Private N003(3) As Single
Private N004(3) As Single
Private N005(3) As Single
Private N006(3) As Single
Private N007(3) As Single
Private N008(3) As Single
Private N009(3) As Single
Private N010(3) As Single
Private N011(3) As Single
Private N012(3) As Single
Private N013(3) As Single
Private N014(3) As Single
Private N015(3) As Single
Private N016(3) As Single
Private N017(3) As Single
Private N018(3) As Single
Private N019(3) As Single
Private N020(3) As Single
Private N021(3) As Single
Private N022(3) As Single
Private N023(3) As Single
Private N024(3) As Single
Private N025(3) As Single
Private N026(3) As Single
Private N027(3) As Single
Private N028(3) As Single
Private N029(3) As Single
Private N030(3) As Single
Private N031(3) As Single
Private N032(3) As Single
Private N033(3) As Single
Private N034(3) As Single
Private N035(3) As Single
Private N036(3) As Single
Private N037(3) As Single
Private N038(3) As Single
Private N039(3) As Single
Private N040(3) As Single
Private N041(3) As Single
Private N042(3) As Single
Private N043(3) As Single
Private N044(3) As Single
Private N045(3) As Single
Private N046(3) As Single
Private N047(3) As Single
Private N048(3) As Single
Private N049(3) As Single
Private N050(3) As Single
Private N051(3) As Single
Private N052(3) As Single
Private N058(3) As Single
Private N059(3) As Single
Private N060(3) As Single
Private N061(3) As Single
Private N062(3) As Single
Private N063(3) As Single
Private N064(3) As Single
Private N065(3) As Single
Private N066(3) As Single
Private N069(3) As Single
Private N070(3) As Single
Private P002(3) As Single
Private P003(3) As Single
Private P004(3) As Single
Private P005(3) As Single
Private P006(3) As Single
Private P007(3) As Single
Private P008(3) As Single
Private P009(3) As Single
Private P010(3) As Single
Private P011(3) As Single
Private P012(3) As Single
Private P013(3) As Single
Private P014(3) As Single
Private P015(3) As Single
Private P016(3) As Single
Private P017(3) As Single
Private P018(3) As Single
Private P019(3) As Single
Private P020(3) As Single
Private P021(3) As Single
Private P022(3) As Single
Private P023(3) As Single
Private P024(3) As Single
Private P025(3) As Single
Private P026(3) As Single
Private P027(3) As Single
Private P028(3) As Single
Private P029(3) As Single
Private P030(3) As Single
Private P031(3) As Single
Private P032(3) As Single
Private P033(3) As Single
Private P034(3) As Single
Private P035(3) As Single
Private P036(3) As Single
Private P037(3) As Single
Private P038(3) As Single
Private P039(3) As Single
Private P040(3) As Single
Private P041(3) As Single
Private P042(3) As Single
Private P043(3) As Single
Private P044(3) As Single
Private P045(3) As Single
Private P046(3) As Single
Private P047(3) As Single
Private P048(3) As Single
Private P049(3) As Single
Private P050(3) As Single
Private P051(3) As Single
Private P052(3) As Single
Private P058(3) As Single
Private P059(3) As Single
Private P060(3) As Single
Private P061(3) As Single
Private P062(3) As Single
Private P063(3) As Single
Private P064(3) As Single
Private P065(3) As Single
Private P066(3) As Single
Private P069(3) As Single
Private P070(3) As Single
Private P071(3) As Single
Private P072(3) As Single
Private P073(3) As Single
Private P074(3) As Single
Private P075(3) As Single
Private P076(3) As Single
Private P077(3) As Single
Private P078(3) As Single
Private P079(3) As Single
Private P080(3) As Single
Private P081(3) As Single
Private P082(3) As Single
Private iP002(3) As Single
Private iP004(3) As Single
Private iP007(3) As Single
Private iP010(3) As Single
Private iP011(3) As Single
Private iP023(3) As Single
Private iP024(3) As Single
Private iP025(3) As Single
Private iP026(3) As Single
Private iP027(3) As Single
Private iP028(3) As Single
Private iP029(3) As Single
Private iP030(3) As Single
Private iP031(3) As Single
Private iP032(3) As Single
Private iP033(3) As Single
Private iP034(3) As Single
Private iP035(3) As Single
Private iP036(3) As Single
Private iP037(3) As Single
Private iP038(3) As Single
Private iP039(3) As Single
Private iP040(3) As Single
Private iP041(3) As Single
Private iP042(3) As Single
Private iP043(3) As Single
Private iP044(3) As Single
Private iP045(3) As Single
Private iP046(3) As Single
Private iP047(3) As Single
Private iP048(3) As Single
Private iP049(3) As Single
Private iP050(3) As Single
Private iP051(3) As Single
Private iP052(3) As Single
Private iP061(3) As Single
Private iP069(3) As Single
Private iP070(3) As Single

' Added to the original stuff for array initializing
Sub FillArray(data() As Single, ar As Variant)
    Dim i As Long
    For i = 0 To UBound(ar)
        data(i) = ar(i)
    Next
End Sub


Sub Shark_Init()


    FillArray N002, Array(0.000077, -0.020611, 0.999788)
    FillArray N003, Array(0.961425, 0.258729, -0.09339)
    FillArray N004, Array(0.510811, -0.769633, -0.383063)
    FillArray N005, Array(0.400123, 0.855734, -0.328055)
    FillArray N006, Array(-0.770715, 0.610204, -0.18344)
    FillArray N007, Array(-0.915597, -0.373345, -0.149316)
    FillArray N008, Array(-0.972788, 0.208921, -0.100179)
    FillArray N009, Array(-0.939713, -0.312268, -0.139383)
    FillArray N010, Array(-0.624138, -0.741047, -0.247589)
    FillArray N011, Array(0.591434, -0.768401, -0.244471)
    FillArray N012, Array(0.935152, -0.328495, -0.132598)
    FillArray N013, Array(0.997102, 0.074243, -0.016593)
    FillArray N014, Array(0.969995, 0.241712, -0.026186)
    FillArray N015, Array(0.844539, 0.502628, -0.184714)
    FillArray N016, Array(-0.906608, 0.386308, -0.169787)
    FillArray N017, Array(-0.970016, 0.241698, -0.025516)
    FillArray N018, Array(-0.998652, 0.050493, -0.012045)
    FillArray N019, Array(-0.942685, -0.333051, -0.020556)
    FillArray N020, Array(-0.660944, -0.750276, 0.01548)
    FillArray N021, Array(0.503549, -0.862908, -0.042749)
    FillArray N022, Array(0.953202, -0.302092, -0.012089)
    FillArray N023, Array(0.998738, 0.023574, 0.044344)
    FillArray N024, Array(0.979297, 0.193272, 0.060202)
    FillArray N025, Array(0.7983, 0.464885, 0.382883)
    FillArray N026, Array(-0.75659, 0.452403, 0.472126)
    FillArray N027, Array(-0.953855, 0.293003, 0.065651)
    FillArray N028, Array(-0.998033, 0.040292, 0.048028)
    FillArray N029, Array(-0.977079, -0.204288, 0.059858)
    FillArray N030, Array(-0.729117, -0.675304, 0.11114)
    FillArray N031, Array(0.598361, -0.792753, 0.116221)
    FillArray N032, Array(0.965192, -0.252991, 0.066332)
    FillArray N033, Array(0.998201, -0.00279, 0.059892)
    FillArray N034, Array(0.978657, 0.193135, 0.070207)
    FillArray N035, Array(0.718815, 0.680392, 0.142733)
    FillArray N036, Array(-0.383096, 0.906212, 0.178936)
    FillArray N037, Array(-0.952831, 0.29259, 0.080647)
    FillArray N038, Array(-0.99768, 0.032417, 0.059861)
    FillArray N039, Array(-0.982629, -0.169881, 0.0747)
    FillArray N040, Array(-0.695424, -0.703466, 0.1467)
    FillArray N041, Array(0.359323, -0.915531, 0.180805)
    FillArray N042, Array(0.943356, -0.319387, 0.089842)
    FillArray N043, Array(0.998272, -0.032435, 0.048993)
    FillArray N044, Array(0.978997, 0.193205, 0.065084)
    FillArray N045, Array(0.872144, 0.470094, -0.135565)
    FillArray N046, Array(-0.664282, 0.737945, -0.119027)
    FillArray N047, Array(-0.954508, 0.28857, 0.075107)
    FillArray N048, Array(-0.998273, 0.032406, 0.048993)
    FillArray N049, Array(-0.979908, -0.193579, 0.048038)
    FillArray N050, Array(-0.858736, -0.507202, -0.072938)
    FillArray N051, Array(0.643545, -0.763887, -0.048237)
    FillArray N052, Array(0.95558, -0.288954, 0.058068)
    FillArray N058, Array(0.00005, 0.793007, -0.609213)
    FillArray N059, Array(0.91351, 0.235418, -0.331779)
    FillArray N060, Array(-0.80797, 0.495, -0.319625)
    FillArray N061, Array(0, 0.784687, -0.619892)
    FillArray N062, Array(0, -1, 0)
    FillArray N063, Array(0, 1, 0)
    FillArray N064, Array(0, 1, 0)
    FillArray N065, Array(0, 1, 0)
    FillArray N066, Array(-0.055784, 0.257059, 0.964784)
    FillArray N069, Array(-0.000505, -0.929775, -0.368127)
    FillArray N070, Array(0, 1, 0)
   FillArray P002, Array(0, -36.59, 5687.72)
   FillArray P003, Array(90, 114.73, 724.38)
   FillArray P004, Array(58.24, -146.84, 262.35)
   FillArray P005, Array(27.81, 231.52, 510.43)
   FillArray P006, Array(-27.81, 230.43, 509.76)
   FillArray P007, Array(-46.09, -146.83, 265.84)
   FillArray P008, Array(-90, 103.84, 718.53)
   FillArray P009, Array(-131.1, -165.92, 834.85)
   FillArray P010, Array(-27.81, -285.31, 500)
   FillArray P011, Array(27.81, -285.32, 500)
   FillArray P012, Array(147.96, -170.89, 845.5)
   FillArray P013, Array(180, 0, 2000)
   FillArray P014, Array(145.62, 352.67, 2000)
   FillArray P015, Array(55.62, 570.63, 2000)
   FillArray P016, Array(-55.62, 570.64, 2000)
   FillArray P017, Array(-145.62, 352.68, 2000)
   FillArray P018, Array(-180, 0.01, 2000)
   FillArray P019, Array(-178.2, -352.66, 2001.61)
   FillArray P020, Array(-55.63, -570.63, 2000)
   FillArray P021, Array(55.62, -570.64, 2000)
   FillArray P022, Array(179.91, -352.69, 1998.39)
   FillArray P023, Array(150, 0, 3000)
   FillArray P024, Array(121.35, 293.89, 3000)
   FillArray P025, Array(46.35, 502.93, 2883.09)
   FillArray P026, Array(-46.35, 497.45, 2877.24)
   FillArray P027, Array(-121.35, 293.9, 3000)
   FillArray P028, Array(-150, 0, 3000)
   FillArray P029, Array(-152.21, -304.84, 2858.68)
   FillArray P030, Array(-46.36, -475.52, 3000)
   FillArray P031, Array(46.35, -475.53, 3000)
   FillArray P032, Array(155.64, -304.87, 2863.5)
   FillArray P033, Array(90, 0, 4000)
   FillArray P034, Array(72.81, 176.33, 4000)
   FillArray P035, Array(27.81, 285.32, 4000)
   FillArray P036, Array(-27.81, 285.32, 4000)
   FillArray P037, Array(-72.81, 176.34, 4000)
   FillArray P038, Array(-90, 0, 4000)
   FillArray P039, Array(-72.81, -176.33, 4000)
   FillArray P040, Array(-27.81, -285.31, 4000)
   FillArray P041, Array(27.81, -285.32, 4000)
   FillArray P042, Array(72.81, -176.34, 4000)
   FillArray P043, Array(30, 0, 5000)
   FillArray P044, Array(24.27, 58.78, 5000)
   FillArray P045, Array(9.27, 95.11, 5000)
   FillArray P046, Array(-9.27, 95.11, 5000)
   FillArray P047, Array(-24.27, 58.78, 5000)
   FillArray P048, Array(-30, 0, 5000)
   FillArray P049, Array(-24.27, -58.78, 5000)
   FillArray P050, Array(-9.27, -95.1, 5000)
   FillArray P051, Array(9.27, -95.11, 5000)
   FillArray P052, Array(24.27, -58.78, 5000)
   FillArray P058, Array(0, 1212.72, 2703.08)
   FillArray P059, Array(50.36, 0, 108.14)
   FillArray P060, Array(-22.18, 0, 108.14)
   FillArray P061, Array(0, 1181.61, 6344.65)
   FillArray P062, Array(516.45, -887.08, 2535.45)
   FillArray P063, Array(-545.69, -879.31, 2555.63)
   FillArray P064, Array(618.89, -1005.64, 2988.32)
   FillArray P065, Array(-635.37, -1014.79, 2938.68)
   FillArray P066, Array(0, 1374.43, 3064.18)
   FillArray P069, Array(0, -418.25, 5765.04)
   FillArray P070, Array(0, 1266.91, 6629.6)
   FillArray P071, Array(-139.12, -124.96, 997.98)
   FillArray P072, Array(-139.24, -110.18, 1020.68)
   FillArray P073, Array(-137.33, -94.52, 1022.63)
   FillArray P074, Array(-137.03, -79.91, 996.89)
   FillArray P075, Array(-135.21, -91.48, 969.14)
   FillArray P076, Array(-135.39, -110.87, 968.76)
   FillArray P077, Array(150.23, -78.44, 995.53)
   FillArray P078, Array(152.79, -92.76, 1018.46)
   FillArray P079, Array(154.19, -110.2, 1020.55)
   FillArray P080, Array(151.33, -124.15, 993.77)
   FillArray P081, Array(150.49, -111.19, 969.86)
   FillArray P082, Array(150.79, -92.41, 969.7)
    FillArray iP002, Array(0, -36.59, 5687.72)
    FillArray iP004, Array(58.24, -146.84, 262.35)
    FillArray iP007, Array(-46.09, -146.83, 265.84)
    FillArray iP010, Array(-27.81, -285.31, 500)
    FillArray iP011, Array(27.81, -285.32, 500)
    FillArray iP023, Array(150, 0, 3000)
    FillArray iP024, Array(121.35, 293.89, 3000)
    FillArray iP025, Array(46.35, 502.93, 2883.09)
    FillArray iP026, Array(-46.35, 497.45, 2877.24)
    FillArray iP027, Array(-121.35, 293.9, 3000)
    FillArray iP028, Array(-150, 0, 3000)
    FillArray iP029, Array(-121.35, -304.84, 2853.86)
    FillArray iP030, Array(-46.36, -475.52, 3000)
    FillArray iP031, Array(46.35, -475.53, 3000)
    FillArray iP032, Array(121.35, -304.87, 2853.86)
    FillArray iP033, Array(90, 0, 4000)
    FillArray iP034, Array(72.81, 176.33, 4000)
    FillArray iP035, Array(27.81, 285.32, 4000)
    FillArray iP036, Array(-27.81, 285.32, 4000)
    FillArray iP037, Array(-72.81, 176.34, 4000)
    FillArray iP038, Array(-90, 0, 4000)
    FillArray iP039, Array(-72.81, -176.33, 4000)
    FillArray iP040, Array(-27.81, -285.31, 4000)
    FillArray iP041, Array(27.81, -285.32, 4000)
    FillArray iP042, Array(72.81, -176.34, 4000)
    FillArray iP043, Array(30, 0, 5000)
    FillArray iP044, Array(24.27, 58.78, 5000)
    FillArray iP045, Array(9.27, 95.11, 5000)
    FillArray iP046, Array(-9.27, 95.11, 5000)
    FillArray iP047, Array(-24.27, 58.78, 5000)
    FillArray iP048, Array(-30, 0, 5000)
    FillArray iP049, Array(-24.27, -58.78, 5000)
    FillArray iP050, Array(-9.27, -95.1, 5000)
    FillArray iP051, Array(9.27, -95.11, 5000)
    FillArray iP052, Array(24.27, -58.78, 5000)
    FillArray iP061, Array(0, 1181.61, 6344.65)
    FillArray iP069, Array(0, -418.25, 5765.04)
    FillArray iP070, Array(0, 1266.91, 6629.6)
'/* *INDENT-ON* */
End Sub

Sub Fish001()

    glBegin (GL_POLYGON)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N007(0)
    glVertex3fv P007(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N004(0)
    glVertex3fv P004(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glNormal3fv N007(0)
    glVertex3fv P007(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N004(0)
    glVertex3fv P004(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P071(0)
    glVertex3fv P072(0)
    glVertex3fv P073(0)
    glVertex3fv P074(0)
    glVertex3fv P075(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P077(0)
    glVertex3fv P078(0)
    glVertex3fv P079(0)
    glVertex3fv P080(0)
    glVertex3fv P081(0)
    glVertex3fv P082(0)
    glEnd
End Sub

Sub Fish002()
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
End Sub

Sub Fish003()
    glBegin (GL_POLYGON)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glEnd
End Sub

Sub Fish004()
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N061(0)
    glVertex3fv P061(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N061(0)
    glVertex3fv P061(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N061(0)
    glVertex3fv P061(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N061(0)
    glVertex3fv P061(0)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N061(0)
    glVertex3fv P061(0)
    glEnd
End Sub

Sub Fish005()
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
End Sub

Sub Fish006()

    glBegin (GL_POLYGON)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glEnd
End Sub

Sub Fish007()

    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N064(0)
    glVertex3fv P064(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
End Sub

Sub Fish008()
    glBegin (GL_POLYGON)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
End Sub

Sub Fish009()
    glBegin (GL_POLYGON)
    glVertex3fv P059(0)
    glVertex3fv P012(0)
    glVertex3fv P009(0)
    glVertex3fv P060(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P012(0)
    glVertex3fv P004(0)
    glVertex3fv P007(0)
    glVertex3fv P009(0)
    glEnd
End Sub

Sub Fish_1()

    Fish004
    Fish005
    Fish003
    Fish007
    Fish006
    Fish002
    Fish008
    Fish009
    Fish001
End Sub

Sub Fish_2()

    Fish005
    Fish004
    Fish003
    Fish008
    Fish006
    Fish002
    Fish007
    Fish009
    Fish001
End Sub

Sub Fish_3()

    Fish005
    Fish004
    Fish007
    Fish003
    Fish002
    Fish008
    Fish009
    Fish001
    Fish006
End Sub

Sub Fish_4()

    Fish005
    Fish004
    Fish008
    Fish003
    Fish002
    Fish007
    Fish009
    Fish001
    Fish006
End Sub

Sub Fish_5()

    Fish009
    Fish006
    Fish007
    Fish001
    Fish002
    Fish003
    Fish008
    Fish004
    Fish005
End Sub

Sub Fish_6()

    Fish009
    Fish006
    Fish008
    Fish001
    Fish002
    Fish007
    Fish003
    Fish004
    Fish005
End Sub

Sub Fish_7()

    Fish009
    Fish001
    Fish007
    Fish005
    Fish002
    Fish008
    Fish003
    Fish004
    Fish006
End Sub

Sub Fish_8()

    Fish009
    Fish008
    Fish001
    Fish002
    Fish007
    Fish003
    Fish005
    Fish004
    Fish006
End Sub

Sub DrawShark(Fish As fishRec)
    Dim mat(3, 3) As Single
    'float mat[4][4]
    Dim n As Long 'int n
    Dim seg1 As Double, seg2 As Double, seg3 As Double, seg4 As Double, segup As Double
    Dim thrash As Double, chomp As Double

    Fish.htail = CInt((Fish.htail - CInt(5 * Fish.v))) Mod 360

    thrash = 50 * Fish.v

    seg1 = 0.6 * thrash * Sin(Fish.htail * RRAD)
    seg2 = 1.8 * thrash * Sin((Fish.htail + 45) * RRAD)
    seg3 = 3 * thrash * Sin((Fish.htail + 90) * RRAD)
    seg4 = 4 * thrash * Sin((Fish.htail + 110) * RRAD)

    chomp = 0
    If (Fish.v > 2) Then
        chomp = -(Fish.v - 2) * 200
    End If
    P004(1) = iP004(1) + chomp
    P007(1) = iP007(1) + chomp
    P010(1) = iP010(1) + chomp
    P011(1) = iP011(1) + chomp

    P023(0) = iP023(0) + seg1
    P024(0) = iP024(0) + seg1
    P025(0) = iP025(0) + seg1
    P026(0) = iP026(0) + seg1
    P027(0) = iP027(0) + seg1
    P028(0) = iP028(0) + seg1
    P029(0) = iP029(0) + seg1
    P030(0) = iP030(0) + seg1
    P031(0) = iP031(0) + seg1
    P032(0) = iP032(0) + seg1
    P033(0) = iP033(0) + seg2
    P034(0) = iP034(0) + seg2
    P035(0) = iP035(0) + seg2
    P036(0) = iP036(0) + seg2
    P037(0) = iP037(0) + seg2
    P038(0) = iP038(0) + seg2
    P039(0) = iP039(0) + seg2
    P040(0) = iP040(0) + seg2
    P041(0) = iP041(0) + seg2
    P042(0) = iP042(0) + seg2
    P043(0) = iP043(0) + seg3
    P044(0) = iP044(0) + seg3
    P045(0) = iP045(0) + seg3
    P046(0) = iP046(0) + seg3
    P047(0) = iP047(0) + seg3
    P048(0) = iP048(0) + seg3
    P049(0) = iP049(0) + seg3
    P050(0) = iP050(0) + seg3
    P051(0) = iP051(0) + seg3
    P052(0) = iP052(0) + seg3
    P002(0) = iP002(0) + seg4
    P061(0) = iP061(0) + seg4
    P069(0) = iP069(0) + seg4
    P070(0) = iP070(0) + seg4

    Fish.vtail = Fish.vtail + ((Fish.dtheta - Fish.vtail) * 0.1)

    If (Fish.vtail > 0.5) Then
        Fish.vtail = 0.5
    ElseIf (Fish.vtail < -0.5) Then
        Fish.vtail = -0.5
    End If
    segup = thrash * Fish.vtail

    P023(1) = iP023(1) + segup
    P024(1) = iP024(1) + segup
    P025(1) = iP025(1) + segup
    P026(1) = iP026(1) + segup
    P027(1) = iP027(1) + segup
    P028(1) = iP028(1) + segup
    P029(1) = iP029(1) + segup
    P030(1) = iP030(1) + segup
    P031(1) = iP031(1) + segup
    P032(1) = iP032(1) + segup
    P033(1) = iP033(1) + segup * 5
    P034(1) = iP034(1) + segup * 5
    P035(1) = iP035(1) + segup * 5
    P036(1) = iP036(1) + segup * 5
    P037(1) = iP037(1) + segup * 5
    P038(1) = iP038(1) + segup * 5
    P039(1) = iP039(1) + segup * 5
    P040(1) = iP040(1) + segup * 5
    P041(1) = iP041(1) + segup * 5
    P042(1) = iP042(1) + segup * 5
    P043(1) = iP043(1) + segup * 12
    P044(1) = iP044(1) + segup * 12
    P045(1) = iP045(1) + segup * 12
    P046(1) = iP046(1) + segup * 12
    P047(1) = iP047(1) + segup * 12
    P048(1) = iP048(1) + segup * 12
    P049(1) = iP049(1) + segup * 12
    P050(1) = iP050(1) + segup * 12
    P051(1) = iP051(1) + segup * 12
    P052(1) = iP052(1) + segup * 12
    P002(1) = iP002(1) + segup * 17
    P061(1) = iP061(1) + segup * 17
    P069(1) = iP069(1) + segup * 17
    P070(1) = iP070(1) + segup * 17

    glPushMatrix

    glTranslatef 0, 0, -3000

    glGetFloatv GL_MODELVIEW_MATRIX, mat(0, 0)
    n = 0
    If (mat(2, 0) >= 0) Then
        n = n + 1
    End If
    If (mat(2, 1) >= 0) Then
        n = n + 2
    End If
    If (mat(2, 2) >= 0) Then
        n = n + 4
    End If
    glScalef 2, 1, 1

    glEnable (GL_CULL_FACE)
    Select Case n
    Case 0:
        Fish_1
        
    Case 1:
        Fish_2
        
    Case 2:
        Fish_3
        
    Case 3:
        Fish_4
        
    Case 4:
        Fish_5
        
    Case 5:
        Fish_6
        
    Case 6:
        Fish_7
        
    Case 7:
        Fish_8
        
    End Select
    glDisable (GL_CULL_FACE)

    glPopMatrix
End Sub
