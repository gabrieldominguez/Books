VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Billboard"
   ClientHeight    =   5190
   ClientLeft      =   1935
   ClientTop       =   2955
   ClientWidth     =   5625
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5190
   ScaleWidth      =   5625
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4425
      Left            =   180
      TabIndex        =   0
      Top             =   135
      Width           =   5145
      _ExtentX        =   9075
      _ExtentY        =   7805
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "Options"
      Begin VB.Menu mnuBillboard 
         Caption         =   "Billboard"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuAlpha 
         Caption         =   "Alpha test"
      End
      Begin VB.Menu mnuBlend 
         Caption         =   "Blend"
      End
      Begin VB.Menu mnuTexture 
         Caption         =   "Texturing"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuScaleUp 
         Caption         =   "Scale up"
      End
      Begin VB.Menu mnuScaleDown 
         Caption         =   "Scale down"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub


Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.init
End Sub

Private Sub glxCtl1_KeyPress(KeyAscii As Integer)
CX.KeyPress KeyAscii
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseDown Button, Shift, X, Y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseMove Button, Shift, X, Y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
CX.MouseUp Button, Shift, X, Y
End Sub

'if not using double-buffering, uncomment the below
Private Sub glxCtl1_Paint()
'gctl.Render
End Sub

Private Sub glxCtl1_Pick(items() As Long)
CX.Pick items
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, default As Boolean)
default = CX.Reshape(width, height)
End Sub


Private Sub mnuAlpha_Click()
    mnuAlpha.Checked = Not mnuAlpha.Checked
    
End Sub

Private Sub mnuBillboard_Click()
    mnuBillboard.Checked = Not mnuBillboard.Checked
    CX.Billboarding = mnuBillboard.Checked
End Sub

Private Sub mnuBlend_Click()
    mnuBlend.Checked = Not mnuBlend.Checked
    CX.Blend = mnuBlend.Checked
End Sub

Private Sub mnuTexture_Click()
mnuTexture.Checked = Not mnuTexture.Checked
CX.Texturing = mnuTexture.Checked
End Sub
