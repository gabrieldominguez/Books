
This project uses 2 VB ocx's.
Common Controls:
	Toolbar
	Statusbar
	ImageList
	MSCOMCTL.OCX - Microsoft Windows Common Controls 6.0
Common Dialog:
	MSCOMDLG32.OCX - Microsoft Common Dialog Control 6.0

If you have an older version of VB, you'll have to modify the
project to use the ocx on your system. The easiest way to do this
is to delete the controls from the form, then draw a toolbar, a statusbar,
an imagelist and and a common dialog. The common dialog is named 'CD',
the others have default names.

Enclosed are some bitmaps for the toolbar. Create about 14 or so buttons,
then add all images to the imagelist and link it to the toolbar. Look in the
toolbar click event to see the keys for the buttons.
The imagelist has magenta for the mask color.
The statusbar has only one panel.
The commondialog has 'CancelError' set to true.

If you don't have these ocxs at all, well, then you just don't. The
menu commands should still work.