VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxFont"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: creates a font in a typeface
'   - see the 3dText SDK sample for an alternate method
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY: derived from Ron Fosner's MSJ samples and from OpenGL SuperBible
'-------------------------------------------------------------------------
Private Declare Function MulDiv& Lib "kernel32" (ByVal nNumber As Long, ByVal nNumerator As Long, ByVal nDenominator As Long)
Const MAX_STRING = 1024
Dim m_Glyphs As Collection

Private Sub Class_Initialize()
    Set m_Glyphs = New Collection
End Sub

Private Sub Class_Terminate()
    Set m_Glyphs = Nothing
End Sub

'---------------------------------------------------------------------------------
'* TestFont
'* Test that GetOutlineTextMetrics works.  If not, wglUseFontOutlines will fail.
'* If the font tests bad, delete it and select in the previous one.
'---------------------------------------------------------------------------------
Private Function m_TestFont(hDC&, hFont&) As Boolean
Dim otm As OUTLINETEXTMETRIC
Dim hfontOld&
    hfontOld = SelectObject(hDC, hFont)
    otm.otmSize = Len(otm)
    If GetOutlineTextMetrics(hDC, Len(otm), otm) <= 0 Then
        Debug.Print "glxFont:m_TestFont: GetOutlineTextMetrics failure\n"
        SelectObject hDC, hfontOld
        DeleteObject hFont
        Exit Function
    End If
    m_TestFont = True
End Function

' creates a font in a typeface
Public Function Create3DFont(ByVal hDC&, ID&, ByVal Typeface$, _
    ByVal Bold As Boolean, ByVal Italic As Boolean, _
    Optional Extrusion! = 0.3, Optional Color) As Boolean
Dim hFont&, r&, hOldFont& ', base&
Dim agmf(256) As GLYPHMETRICSFLOAT 'agmf[256] ' Throw away
Dim nColor&, bColMat(0) As GLboolean, OldColor!(0 To 3)
Dim OldWind&(0), OldCull(0) As GLboolean
    '
    hFont = CreateFont(hDC, Typeface$, 0, Bold, Italic)
    If hFont = 0 Then Exit Function
    '
    If Not IsMissing(Color) Then
        glGetBooleanv glgColorMaterial, bColMat(0)
        glGetFloatv GL_CURRENT_COLOR, OldColor(0)
        glEnable glcColorMaterial
        UC.Ex.glColor32 CLng(Color)
    End If
    'docs suggest doing this
    glGetBooleanv GL_CULL_FACE, OldCull(0)
    glGetIntegerv GL_FRONT_FACE, OldWind(0)
    glCullFace GL_BACK
    glEnable GL_CULL_FACE
    glPushMatrix
    'this doesn't work
    'glScalef PointSize, PointSize, PointSize
        'can do the test here
        hOldFont = SelectObject(hDC, hFont)
        'create display lists for glyphs 32 through 127
        ' and default deviation.
        ID = glGenLists(96)
        If ID = 0 Then
            Debug.Print "Unable to create font"
            Debug.Assert 0
        Else
            r = wglUseFontOutlines(hDC, 32, 96, ID, 0#, Extrusion, _
                        WGL_FONT_POLYGONS, agmf(0))
            If r = 0 Then
                Debug.Print "Unable to create font"
                Debug.Assert 0
                glDeleteLists ID, 96
            Else
                Create3DFont = True
            End If
        End If
        SelectObject hDC, hOldFont
        DeleteObject hFont
    glPopMatrix
    'rest original color and colormaterial if changed
    If Not IsMissing(Color) Then
        If bColMat(0) = 0 Then
            glDisable glcColorMaterial
        End If
        glColor4fv OldColor(0)
    End If
    'reset culling
    If OldCull(0) = 0 Then
        glDisable GL_CULL_FACE
    End If
    'reset winding
    glFrontFace OldWind(0)
End Function

Public Function CreateBitmapFont(ByVal hDC&, ID&, ByVal Typeface$, _
    ByVal Bold As Boolean, ByVal Italic As Boolean, ByVal PointSize&) As Boolean
Dim hFont&, hOldFont&
    hFont = CreateFont(hDC, Typeface, PointSize&, Bold, Italic)
    If hFont = 0 Then Exit Function
    ID = glGenLists(96)
    If ID Then
        hOldFont = SelectObject(hDC, hFont)
        wglUseFontBitmaps hDC, 32, 96, ID
        CreateBitmapFont = True
    End If
    SelectObject hDC, hOldFont
    DeleteObject hFont
End Function

'-------------------------------------------------------------------------
'PointSize: appears to have no effect
'For the MM_TEXT mapping mode, you can use the following formula to specify
'a height for a font with a specified point size:
'nHeight = -MulDiv(PointSize, GetDeviceCaps(hDC, LOGPIXELSY), 72);
'The MulDiv function multiplies two 32-bit values and then divides the
'64-bit result by a third 32-bit value. The return value is rounded up or
'down to the nearest integer.
'int MulDiv(
'  int nNumber,       // 32-bit signed multiplicand
'  int nNumerator,    // 32-bit signed multiplier
'  int nDenominator   // 32-bit signed divisor
Public Function CreateFont&(ByVal hDC&, ByVal Typeface$, _
    ByVal PointSize&, ByVal Bold As Boolean, ByVal Italic As Boolean)
Dim hFont&, nHeight&
Dim lf As LOGFONT
    'doesn't appear that height has any effect on the gl font produced
    If PointSize Then
        nHeight = -MulDiv(PointSize, GetDeviceCaps(hDC, LOGPIXELSY), 72)
    Else
        nHeight = -10
    End If
    lf.lfHeight = nHeight
    lf.lfWidth = 0
    lf.lfEscapement = 0
    lf.lfOrientation = 0
    lf.lfWeight = IIf(Bold = 0, FW_NORMAL, FW_BOLD) 'FW_BOLD
    lf.lfItalic = IIf(Italic = 0, 0, 1) 'FALSE
    lf.lfUnderline = False
    lf.lfStrikeOut = False
    lf.lfCharSet = ANSI_CHARSET
    lf.lfOutPrecision = OUT_DEFAULT_PRECIS
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS
    lf.lfQuality = DEFAULT_QUALITY
    lf.lfPitchAndFamily = DEFAULT_PITCH
    UC.Ex.StringToByteArray lf.lfFaceName, Typeface
    '
    hFont = CreateFontIndirect(lf)
    If hFont = 0 Then
        ' The requested font cannot be loaded.  Try to get the system to
        ' load any TrueType font
        hFont = GDI.CreateFont(100, 100, 0, 0, FW_NORMAL, 0, _
                             0, 0, 0, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, _
                             DEFAULT_QUALITY, DEFAULT_PITCH, 0&)
        ' If hfont is still null, nothing will be displayed.
        If hFont = 0 Then
            Debug.Assert 0
            Exit Function
        End If
    End If
    CreateFont = hFont
End Function


'assumes the list is ASC char starting at 32 of Outline font
Public Sub DrawText3D(ByVal FontID&, s$, ByVal x!, ByVal y!, ByVal z!, Optional nScale, Optional Color)
Dim r As glErrorConstants, i&
Dim a() As Byte
Dim OldWind&(0), OldCull(0) As GLboolean, oldCM(0) As GLboolean
    r = glGetError()
'    glGetBooleanv GL_CULL_FACE, OldCull(0)
'    glGetIntegerv GL_FRONT_FACE, OldWind(0)
    'glPushAttrib amListBit
    glPushAttrib amAllAttribBits
    glPushMatrix
        'set font
        glListBase FontID - 32
        glTranslatef x, y, z
        'set font size
        If Not IsMissing(nScale) Then
            glScalef nScale, nScale, nScale
        End If
        'set forecolor
        If Not IsMissing(Color) Then
            glGetBooleanv glgColorMaterial, oldCM(0)
            glEnable glcColorMaterial
            UC.Ex.glColor32 CLng(Color)
        End If
        ReDim a(0 To Len(s) + 1)
        UC.Ex.StringToByteArray a, s
        glCallLists Len(s), GL_BYTE, a(0) 'ByVal s
    glPopMatrix
    glPopAttrib
    'reset culling
'    If OldCull(0) = 0 Then
'        glDisable GL_CULL_FACE
'    Else
'        glEnable GL_CULL_FACE
'    End If
'    'reset winding
'    glFrontFace OldWind(0)
'    'reset cm
    If Not IsMissing(Color) Then
        If oldCM(0) = 0 Then
            glDisable glcColorMaterial
        Else
            glEnable glcColorMaterial
        End If
    End If
    r = glGetError()
    If r <> glerrNoError Then
        Debug.Assert 0
        Debug.Print r
    End If
End Sub

'assumes the list is ASC char starting at 32 of bmp font
Public Sub DrawTextBMP(ByVal FontID&, s$, ByVal x!, ByVal y!, ByVal z!, Optional Color)
Dim r As glErrorConstants, i&
Dim a() As Byte, lit(0) As GLboolean
    r = glGetError()
    'set forecolor
    If Not IsMissing(Color) Then
        UC.Ex.glColor32 CLng(Color)
    End If
    glPushAttrib amListBit
    glGetBooleanv GL_LIGHTING, lit(0)
    glDisable GL_LIGHTING
    glPushMatrix
        'not too sure about this stuff:
        'set font size
        glTranslatef x, y, z
        glRasterPos3f x, y, z
        'set font
        glListBase FontID - 32
        ReDim a(0 To Len(s) + 1)
        UC.Ex.StringToByteArray a, s
        glCallLists Len(s), GL_BYTE, a(0) 'ByVal s
    glPopMatrix
    If lit(0) Then
        glEnable GL_LIGHTING
    End If
    r = glGetError()
    If r <> glerrNoError Then
        Debug.Assert 0
        Debug.Print r
    End If
    glPopAttrib
End Sub

Public Function CreateGlyphSet(ByVal Typeface$) As glxGlyphs
Dim g As glxGlyphs
    If m_Glyphs.count Then
        Set g = m_Glyphs.Item(Typeface$)
    End If
    If g Is Nothing Then
        Set g = New glxGlyphs
        If g Is Nothing Then
            Debug.Assert 0
        End If
        g.face = Typeface
    End If
    Set CreateGlyphSet = g
End Function


