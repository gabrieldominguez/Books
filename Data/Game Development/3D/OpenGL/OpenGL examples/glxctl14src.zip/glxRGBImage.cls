VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxRGBImage"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: tk stuff
'   - a temporary class created by glxImage to load an rgb or bw file
'   - don't create instances of it outside the ocx
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'Oct 98
'   - added la support, modified it to return RGBA always
'-------------------------------------------------------------------------
'for reading SGI image files
Private Type RawImageRec
    imagic As Integer
    nType As Integer
    Dim As Integer
    SizeX As Integer
    SizeY As Integer
    SizeZ As Integer
    Min As Long
    Max As Long
    wasteBytes As Long
    Name As String * 80
    colorMap As Long
    File As Long
    rleEnd  As Long
    ' !!! Hack to stick in a pointer to the resource data - shouldn't be
    ' a problem, since rgb files always have 512 byte header
    Data As Long 'unsigned char *data
End Type

Dim m_Data() As Byte  'ptr to the DIB data
Dim m_DataSize&
Dim m_IMAGIC%
Public m_nType%
Public m_Dimension%
Dim m_SizeX As Integer
Dim m_SizeY As Integer
Public m_SizeZ As Integer
Dim m_ColorMap As Long
Dim m_rleEnd&
Dim Raw_tmp() As Byte
Dim Raw_tmpR() As Byte
Dim Raw_tmpG() As Byte
Dim Raw_tmpB() As Byte
Dim Raw_tmpA() As Byte
Dim Raw_rowStart() As Long
Dim Raw_rowSize() As Long

'-------------------------------------------------------------------------
Public Property Get Data() As Long
Data = VarPtr(m_Data(0))
End Property

Public Property Get DataSize&()
    DataSize = m_DataSize
End Property

'---------------------------------------------------------
Public Property Get SizeX&()
SizeX = m_SizeX
End Property

Public Property Get SizeY&()
SizeY = m_SizeY
End Property

'---------------------------------------------------------
Public Function RGBImageLoad(pv&) As Boolean
Dim r&, n&
On Error GoTo errorhandler
    UC.GetErr n
    r = m_RawImageOpen(pv)
    If r = 0 Then Exit Function
    m_RawImageGetData pv
    m_RawImageClose
    RGBImageLoad = True
'---------------------------------------------------------
Exit Function
errorhandler:
    Debug.Assert 0
    'Resume Next
    Exit Function
End Function


'---------------------------------------------------------
' Hacked form of tk_RGBImageLoad(), for reading a .rgb file from a resource
'---------------------------------------------------------
Private Function m_RawImageOpen(pv&) As Boolean
Dim RawRec As RawImageRec
Dim ulTmp&, x&
Dim dwBytesRead&, i&
Dim siz&
On Error GoTo errorhandler
    ' Make a copy of the resource header, since we may be doing some byte
    ' swapping, and resources are read-only
    'raw = pv
    CopyToPtrFromPtr VarPtr(RawRec), pv, Len(RawRec)
    m_IMAGIC = RawRec.imagic
    If (m_IMAGIC = IMAGIC_SWAP) Then
        m_nType = SWAP_SHORT_BYTES(RawRec.nType)
        m_Dimension = SWAP_SHORT_BYTES(RawRec.Dim)
        m_SizeX = SWAP_SHORT_BYTES(RawRec.SizeX)
        m_SizeY = SWAP_SHORT_BYTES(RawRec.SizeY)
        m_SizeZ = SWAP_SHORT_BYTES(RawRec.SizeZ)
    Else
        m_nType = (RawRec.nType)
        m_Dimension = (RawRec.Dim)
        m_SizeX = (RawRec.SizeX)
        m_SizeY = (RawRec.SizeY)
        m_SizeZ = (RawRec.SizeZ)
    End If
    '
    siz = m_SizeX
    siz = siz * 256 - 1
    ReDim Raw_tmp(0 To siz)
    ReDim Raw_tmpR(0 To siz)
    ReDim Raw_tmpG(0 To siz)
    ReDim Raw_tmpB(0 To siz)
    ReDim Raw_tmpA(0 To siz)

    If ((m_nType And &HFF00) = &H100) Then
        x = m_SizeY * m_SizeZ * 4 'sizeof(long)
        ReDim Raw_rowStart(0 To x - 1)
        ReDim Raw_rowSize(0 To x - 1)
        m_rleEnd = 512 + (2 * x)
        'm_ptrData = pv '(unsigned char *)
        CopyToLongFromPtr Raw_rowStart(0), pv + 512, x
        CopyToLongFromPtr Raw_rowSize(0), pv + 512 + x, x

        If m_IMAGIC = IMAGIC_SWAP Then
            x = x / 4 ' sizeof(long)
            Do While x
                x = x - 1
                ulTmp = Raw_rowStart(i)
                Raw_rowStart(i) = SWAP_LONG_BYTES(ulTmp)
'                '
                ulTmp = Raw_rowSize(i)
                Raw_rowSize(i) = SWAP_LONG_BYTES(ulTmp)
                '
                i = i + 1
            Loop
        End If
    End If
    m_RawImageOpen = True
Exit Function
errorhandler:
    Debug.Assert 0
    'Resume Next
    Exit Function
End Function


'---------------------------------------------------------
Private Sub m_RawImageGetData(pv&)
Dim ptr& '  unsigned CHAR *
Dim y&, x&
On Error GoTo errorhandler
    'ptex.data = (unsigned char *)malloc((raw.sizeX+1)*(raw.sizeY+1)*4)
    x = m_SizeX + 1
    y = m_SizeY + 1
    m_DataSize = x * y * 4
    ReDim m_Data(0 To m_DataSize)
    For y = 0 To m_SizeY - 1
    Select Case m_SizeZ
        Case 2
            'Debug.Assert 0
            m_RawImageGetRow pv&, Raw_tmpR, y, 0
            m_RawImageGetRow pv&, Raw_tmpA, y, 1
            For x = 0 To m_SizeX - 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpA(x)
                ptr = ptr + 1
            Next
        Case 3
            m_RawImageGetRow pv&, Raw_tmpR, y, 0
            m_RawImageGetRow pv&, Raw_tmpG, y, 1
            m_RawImageGetRow pv&, Raw_tmpB, y, 2
            For x = 0 To m_SizeX - 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpG(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpB(x)
                ptr = ptr + 1
                m_Data(ptr) = &HFF
                ptr = ptr + 1
            Next
        Case Is >= 4
            'Debug.Assert 0
            m_RawImageGetRow pv&, Raw_tmpR, y, 0
            m_RawImageGetRow pv&, Raw_tmpG, y, 1
            m_RawImageGetRow pv&, Raw_tmpB, y, 2
            m_RawImageGetRow pv&, Raw_tmpA, y, 3
            For x = 0 To m_SizeX - 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpG(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpB(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpA(x)
                ptr = ptr + 1
            Next
        Case Else
            m_RawImageGetRow pv&, Raw_tmpR, y, 0
            For x = 0 To m_SizeX - 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = Raw_tmpR(x)
                ptr = ptr + 1
                m_Data(ptr) = &HFF
                ptr = ptr + 1
            Next
    End Select
    Next
'---------------------------------------------------------
Exit Sub
errorhandler:
    Debug.Assert 0
    'Resume Next
    Exit Sub
End Sub

'---------------------------------------------------------
Private Sub m_RawImageClose()
    Erase Raw_tmp
    Erase Raw_tmpR
    Erase Raw_tmpG
    Erase Raw_tmpB
    Erase Raw_tmpA
    Erase Raw_rowStart
    Erase Raw_rowSize
End Sub

'---------------------------------------------------------
Private Sub m_RawImageGetRow(pv&, buf() As Byte, y&, z&)
Dim iPtr&, oPtr&
Dim pixel As Byte, ptr&, lng&
Dim count&, dwBytesRead&
On Error GoTo errorhandler
    If (m_nType And &HFF00) = &H100 Then
        ptr = pv + Raw_rowStart(y + z * m_SizeY)
        lng = Raw_rowSize(y + z * m_SizeY)
        CopyToByteFromPtr Raw_tmp(0), ptr, lng

        iPtr = 0
        oPtr = 0
        Do
            pixel = Raw_tmp(iPtr)
            iPtr = iPtr + 1
            count = pixel And &H7F
            If count = 0 Then
                Exit Sub
            End If
            If pixel And &H80 Then
                Do While count
                    count = count - 1
                    buf(oPtr) = Raw_tmp(iPtr)
                    oPtr = oPtr + 1
                    iPtr = iPtr + 1
                Loop
            Else
                pixel = Raw_tmp(iPtr)
                iPtr = iPtr + 1
                Do While count
                    count = count - 1
                    buf(oPtr) = pixel
                    oPtr = oPtr + 1
                Loop
            End If
        Loop
    Else
        ptr = pv + 512 + (y * m_SizeX) + (z * m_SizeX * m_SizeY)
        CopyToByteFromPtr buf(0), ptr, m_SizeX
    End If
'---------------------------------------------------------
Exit Sub
errorhandler:
    Debug.Assert 0
    Exit Sub
    Resume Next
End Sub




'Public Sub ConvertShort(a%(), length&)
'Dim b1&, b2&
'Dim ptr&
'    'ptr = (unsigned char *)array;
'    Do While length
'        length = length - 1
'        b1 = a(ptr): ptr = ptr + 1
'        b2 = a(ptr): ptr = ptr + 1
'        *array++ = (b1 << 8) | (b2);
'    Loop
'End Sub
'
'Public Sub ConvertLong(a&(), length&)
'    unsigned long b1, b2, b3, b4;
'    unsigned char *ptr;
'
'    ptr = (unsigned char *)array;
'    while (length--) {
'    b1 = *ptr++;
'    b2 = *ptr++;
'    b3 = *ptr++;
'    b4 = *ptr++;
'    *array++ = (b1 << 24) | (b2 << 16) | (b3 << 8) | (b4);
'    }
'End Sub

'''public const SWAP_SHORT_BYTES(x) ((((x) and 0xff) << 8) | (((x) and 0xff00) >> 8))
'''public const SWAP_LONG_BYTES(x) (((((x) and 0xff) << 24) | (((x) and 0xff00) << 8)) | \
'''                            ((((x) and 0xff0000) >> 8) | (((x) and 0xff000000) >> 24)))
Private Function SWAP_SHORT_BYTES%(ByVal x%)
Dim n%
'Stop
'Debug.Print Hex(x)
'copy high byte
CopyToPtrFromPtr VarPtr(n) + 1, VarPtr(x), 1
'Debug.Print Hex(n)
CopyToPtrFromPtr VarPtr(n), VarPtr(x) + 1, 1
'Debug.Print Hex(n)
SWAP_SHORT_BYTES = n 'n 'n1 Or n2
End Function

Private Function SWAP_LONG_BYTES&(ByVal x&)
'(((((x) and &Hff) << 24) | (((x) and &Hff00) << 8)) | \
'                            ((((x) and &Hff0000) >> 8) | (((x) and &Hff000000) >> 24)))
Dim n1 As Byte, n2 As Byte, n3 As Byte, n4 As Byte
Dim r&
CopyToPtrFromPtr VarPtr(n1), VarPtr(x), 1
CopyToPtrFromPtr VarPtr(n2), VarPtr(x) + 1, 1
CopyToPtrFromPtr VarPtr(n3), VarPtr(x) + 2, 1
CopyToPtrFromPtr VarPtr(n4), VarPtr(x) + 3, 1
'
CopyToPtrFromPtr VarPtr(r), VarPtr(n4), 1
CopyToPtrFromPtr VarPtr(r) + 1, VarPtr(n3), 1 '???
CopyToPtrFromPtr VarPtr(r) + 2, VarPtr(n2), 1 '???
CopyToPtrFromPtr VarPtr(r) + 3, VarPtr(n1), 1
'
SWAP_LONG_BYTES = r
End Function


