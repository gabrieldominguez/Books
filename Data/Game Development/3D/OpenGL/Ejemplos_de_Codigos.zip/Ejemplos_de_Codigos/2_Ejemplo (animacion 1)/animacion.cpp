//--------------------------------------------------------------
// Simple Animaci�n en OpenGL
// Basado en el ejemplo "Animation" de Roman Podobedov
// Objetivo: Mostrar la animaci�n de objetos.
// Daniel Beber - Computaci�n II - 15/Setiembe/2001
//--------------------------------------------------------------

#include <stdio.h>
#include <GL/glut.h>

int WindW, WindH;
int i;
int angulo;

void RefrescarPantalla(int width, int height)
{ glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(-1, 1, -1, 1);    // Coordenada del "Mundo Gr�fico"
  glMatrixMode(GL_MODELVIEW);

  WindW = width;
  WindH = height;
}

void Dibujar(void)
{ glClear(GL_COLOR_BUFFER_BIT);

  glLineWidth(3);                      // ancho de la l�nea
  glColor3f(0.0f, 0.6f, 0.9f);         // color para lo que vendr� ...

  glPushMatrix();

  glRotatef(angulo, 0.0f, 0.0f, 1.0f); // rotaci�n del "modelo" cuyo eje es "z"
  angulo += 4;
  if (angulo > 359) angulo = 0;

  glBegin(GL_LINES);                   // el modelo es siempre el mismo!
    glVertex2f(-0.5f, 0.5f);
    glVertex2f(0.5f, -0.5f);
  glEnd();

  glPopMatrix();
  glFlush();
  glutSwapBuffers();
}

void FuncionTimer(int value)
{ // Establece con qu� velocidad (en tiempo) se redibuja la pantalla
  glutPostRedisplay();                   // Redibujar la ventana
  glutTimerFunc(40, FuncionTimer, 0);    // Setup el pr�ximo timer
}

int main(int argc, char *argv[])
{ WindW = 400;
  WindH = 300;
  angulo = 0;

  // Inicializaci�n de la ventana gr�fica
  glutInit(&argc, argv);
  glutInitWindowSize(WindW, WindH);
  glutInitWindowPosition(100, 100);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  (void)glutCreateWindow("Simple Animaci�n - Computaci�n II");

  // Indica a que funci�n llamar cuando:
  glutReshapeFunc(RefrescarPantalla); // se cambia tama�o ventana
  glutDisplayFunc(Dibujar);           // lo que hay que dibujar
  glutTimerFunc(40, FuncionTimer, 0); // velocidad (en tiempo) para mostrar
  glClearColor(0, 0, 0, 0);           // color para "borrar"

  glutMainLoop();                     // inicio de la representaci�n
  return 0;
}

/*  MAKEFILE =============================================================
CXX=g++
OPCIONES=-g -Wall -I../util -I/usr/include/GL -I/bin -I/usr/include/w32api
DIRECTORIOS=
BIBLIOTECAS=-L/lib -lglut32 -lglu32 -lopengl32  -lm
all:
	${CXX} ${OPCIONES} animacion.cpp -o animacion ${DIRECTORIOS} ${BIBLIOTECAS}
*/
