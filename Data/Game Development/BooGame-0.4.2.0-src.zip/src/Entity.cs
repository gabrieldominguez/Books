/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using Tao.OpenGl;
using System.Collections;

namespace BooGame
{
	/// <summary>
	/// An object in the game world that can be viewed and updated.
	/// </summary>
    [Serializable]
	public abstract class Entity : IComparable
	{
		private string m_Name = "Unknown";
        /// <summary>
        /// Gets and sets the name of the entity.
        /// </summary>
		public string Name
		{
			get{ return m_Name; }
			set{ m_Name = value; }
		}
		private float m_X = 0f;
		private float m_Y = 0f;
		
        /// <summary>
        /// Gets and sets the current X coordinate of the entity.
        /// </summary>
		public float X
		{
			get{ return m_X; }
			set{ m_X = value; }
        }

        /// <summary>
        /// Gets and sets the current Y coordinate of the entity.
        /// </summary>
		public float Y
		{
			get{ return m_Y; }
			set{ m_Y = value; }
		}
		private float m_Rotation = 0f;
        /// <summary>
        /// Gets and sets the current rotation of the entity.
        /// </summary>
		public float Rotation
		{
			get{ return m_Rotation; }
			set{ m_Rotation = value; }
		}
        /// <summary>
        /// Gets and sets the width of the entity.
        /// </summary>
		public virtual float Width
		{
			get
			{
				return m_ScaleX;
			}
			set
			{
				m_ScaleX = value;
			}
		}
        /// <summary>
        /// Gets and sets the height of the entity.
        /// </summary>
		public virtual float Height
		{
			get
			{
				return m_ScaleY;
			}
			set
			{
				m_ScaleY = value;
			}
		}

        /// <summary>
        /// Gets and sets the scale of the entity.
        /// </summary>
		public float Scale
		{
			get
			{
				return (m_ScaleX + m_ScaleY) / 2f;
			}
			set
			{
				m_ScaleX = value;
				m_ScaleY = value;
			}
		}
		private float m_ScaleX = 1f;
		private float m_ScaleY = 1f;
        /// <summary>
        /// Gets and sets the horizonal scale.
        /// </summary>
		public float ScaleX
		{
			get{ return m_ScaleX; }
			set{ m_ScaleX = value; }
		}
        /// <summary>
        /// Gets and sets the vertical scale.
        /// </summary>
		public float ScaleY
		{
			get{ return m_ScaleY; }
			set{ m_ScaleY = value; }
		}
		
		private float m_Alpha = 1f;
        /// <summary>
        /// Gets and sets the alpha blending value (0-1).
        /// </summary>
		public float Alpha
		{
			get
			{
				return m_Alpha;
			}
			set
			{
                if (value <= 0f)
                    m_Alpha = 0f;
                else if (value >= 1f)
                    m_Alpha = 1f;
                else
                    m_Alpha = value;
			}
		}

		private ColorF m_Tint = Color.White;
        /// <summary>
        /// Gets and sets the tinting colour of the entity.
        /// </summary>
		public ColorF Tint
		{
			get{ return m_Tint; }
			set{ m_Tint = value; }
		}

        /// <summary>
        /// When overriden by a inheriting class, draws the entity on the screen.
        /// </summary>
		public virtual void Draw()
        {
            if(OnDraw != null)
                OnDraw(this, new DrawEventArgs());
		}

        /// <summary>
        /// Update the properties of the entity based on change in time.
        /// </summary>
		public virtual void Update()
		{
			if(m_Enabled)
			{
				if(!m_Velocity.IsEmpty)
				{
					m_X += m_Velocity.X * Timer.DeltaSeconds;
					m_Y += m_Velocity.Y * Timer.DeltaSeconds;
				}
				m_Rotation += m_RotationSpeed * Timer.DeltaSeconds;

                if(OnUpdate != null)
                    OnUpdate(this, new UpdateEventArgs());
			}
		}
		
        /// <summary>
        /// Gets and sets the size of the entity.
        /// </summary>
		public SizeF Size
		{
			get
			{
				return new SizeF(this.Width, this.Height);
			}
			set
			{
				this.Width = value.Width;
				this.Height = value.Height;
			}
		}

        /// <summary>
        /// Gets and sets the location of the entity.
        /// </summary>
		public PointF Location
		{
			get
			{
				return new PointF(m_X, m_Y);
			}
			set
			{
				m_X = value.X;
				m_Y = value.Y;
			}
		}

        /// <summary>
        /// Gets and sets the x coordinate of the entity's left edge.
        /// </summary>
		public virtual float Left
		{
			get
			{
                return this.X - m_HotSpot.X * Math.Abs(m_ScaleX);
			}
			set
			{
                this.X = value + m_HotSpot.X * Math.Abs(m_ScaleX);
			}
        }

        /// <summary>
        /// Gets and sets the x coordinate of the entity's right edge.
        /// </summary>
        public virtual float Right
		{
			get
			{
				return this.Left + this.Width;
			}
			set
			{
				this.Left = value - this.Width;
			}
		}

        /// <summary>
        /// Gets and sets the y coordinate of the entity's top edge.
        /// </summary>
        public virtual float Top
		{
			get
			{
                return this.Y - m_HotSpot.Y * Math.Abs(m_ScaleY);
			}
			set
			{
                this.Y = value + m_HotSpot.Y * Math.Abs(m_ScaleY);
			}
		}

        /// <summary>
        /// Gets and sets the y coordinate of the entity's bottom edge.
        /// </summary>
        public virtual float Bottom
		{
			get
			{
				return this.Top + this.Height;
			}
			set
			{
				this.Top = value - this.Height;
			}
		}

        /// <summary>
        /// Gets and sets a rectangle representant of the entities location.
        /// </summary>
		public RectangleF Rectangle
		{
			get
			{
				return new RectangleF(Left, Top, Width, Height);
			}
			set
			{
				Left = value.X;
				Top = value.Y;
				Width = value.Width;
				Height = value.Height;
			}
		}

		private PointF m_HotSpot = new PointF(0f,0f);
        /// <summary>
        /// Gets and sets the spot where the entities associates its X and Y coordinates.
        /// </summary>
		public PointF HotSpot
		{
			get{ return m_HotSpot; }
			set{ m_HotSpot = value; }
		}

		private bool m_IsWorldObject = true;
        /// <summary>
        /// Gets and sets whether the entity is affected by the camera.
        /// </summary>
		public bool IsWorldObject
		{
			get{ return m_IsWorldObject; }
			set{ m_IsWorldObject = value; }
		}

		private bool m_Visible = true;
        /// <summary>
        /// Gets and sets whether the entity is visible.
        /// </summary>
		public bool Visible
		{
			get{ return m_Visible; }
			set{ m_Visible = value; }
		}
		private bool m_Enabled = true;
        /// <summary>
        /// Gets and sets whether the entity is currently visible.
        /// </summary>
		public bool Enabled
		{
			get{ return m_Enabled; }
			set{ m_Enabled = value; }
		}
        /// <summary>
        /// Returns the name of the entity.
        /// </summary>
        /// <returns>The name of the entity.</returns>
		public override string ToString()
		{
			return m_Name;
		}

		private Vector m_Velocity = new Vector(0,0);
        /// <summary>
        /// Gets and sets the current speed of the entity.
        /// </summary>
		public Vector Velocity
		{
			get{ return m_Velocity; }
			set{ m_Velocity = value; }
		}
		private float m_RotationSpeed = 0f;
        /// <summary>
        /// Gets and sets how fast the entity is rotating.
        /// </summary>
		public float RotationSpeed
		{
			get{ return m_RotationSpeed; }
			set{ m_RotationSpeed = value; }
		}

        /// <summary>
        /// Checked whether the entity is currently colliding with another entity.
        /// </summary>
        /// <param name="entity">The other entity to check with.</param>
        /// <returns>True if they are colliding, false otherwise.</returns>
        public bool IntersectsWith(Entity entity)
        {
            if (Bottom < entity.Top) return false;
            if (Top > entity.Bottom) return false;

            if (Right < entity.Left) return false;
            if (Left > entity.Right) return false;
            return true;
        }
        public bool IntersectsWith(PointF point)
        {
            if (Bottom < point.Y) return false;
            if (Top > point.Y) return false;

            if (Right < point.X) return false;
            if (Left > point.X) return false;
            return true;
        }
        public bool IntersectsWith(float x, float y)
        {
            if (Bottom < y) return false;
            if (Top > y) return false;

            if (Right < x) return false;
            if (Left > x) return false;
            return true;
        }

        /// <summary>
        /// Gets and sets a point representing the center point of the entity.
        /// </summary>
        public PointF Center
        {
            get
            {
                return new PointF(Left + Width / 2f, Top + Height / 2f);
            }
            set
            {
                Left = value.X - Width / 2f;
                Top = value.Y - Height / 2f;
            }
        }
        public virtual bool IntersectsWith(RectangleF rectangle)
        {
            if (Bottom < rectangle.Top) return false;
            if (Top > rectangle.Bottom) return false;

            if (Right < rectangle.Left) return false;
            if (Left > rectangle.Right) return false;
            return true;
        }

        public bool IntersectsWithRadius(Entity entity, float radius, float radiusOther, float tolerance)
        {
            PointF center1 = this.Center;
            PointF center2 = entity.Center;
            float xdiff = center2.X - center1.X;
            float ydiff = center2.Y - center1.Y;
            float dcentre_sq = (ydiff * ydiff) + (xdiff * xdiff);
            float r_sum_sq = radius + radiusOther;
            r_sum_sq *= r_sum_sq;
            return dcentre_sq - r_sum_sq <= (tolerance * tolerance);
        }

        public virtual bool IntersectsWithRadius(Entity entity, float radius, float radiusOther)
        {
            return IntersectsWithRadius(entity, radius, radiusOther, 0);
        }

        public virtual bool IntersectsWithRadius(Entity entity, float radius)
        {
            return IntersectsWithRadius(entity, radius, radius, 0);
        }

        public virtual bool IntersectsWithRadius(Entity entity)
        {
            return IntersectsWithRadius(entity, (this.Width + this.Height) / 4f, (entity.Width + entity.Height ) / 4f, 0);
        }

        private int m_ZOrder = 0;
        /// <summary>
        /// Gets and sets the ZOrder of the entity.
        /// </summary>
        /// <remarks>The ZOrder represents what order the entities should be drawn.</remarks>
        public int ZOrder
        {
            get { return m_ZOrder; }
            set { m_ZOrder = value; }
        }

        /// <summary>
        /// Compares the entity to another entity's ZOrder.
        /// </summary>
        /// <param name="obj">The other object to compare to.</param>
        /// <returns>-1 if its ZOrder is less, 0 if it's equal, 1 if it's greater.</returns>
        public virtual int CompareTo(object obj)
        {
            return this.ZOrder.CompareTo(((Entity)obj).ZOrder);
        }

        #region Events
        public event DrawEventHandler OnDraw;
        public event UpdateEventHandler OnUpdate;
        #endregion Events
    }

    #region EntityCollection
    /// <summary>
    ///  A collection of entity objects.
    /// </summary>
    [Serializable]
    public class EntityCollection : CollectionBase, ICollection
    {
        public EntityCollection()
            : base()
        {
        }

        public EntityCollection(EntityCollection entities)
        {
            this.Add(entities);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public EntityCollection(Entity entity)
        {
            this.Add(entity);
        }

        public Entity this[int index]
        {
            get
            {
                return ((Entity)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }

        public int Add(Entity entity)
        {
            return (List.Add(entity));
        }

        public int Add(EntityCollection entityCollection)
        {
            for (int i = 0; i < entityCollection.Count; i++)
                this.List.Add(entityCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Entity entity)
        {
            List.Insert(index, entity);
        }

        public void Remove(Entity entity)
        {
            if (entity != null)
                List.Remove(entity);
        }

        public int IndexOf(Entity entity)
        {
            return (List.IndexOf(entity));
        }

        public bool Contains(Entity entity)
        {
            return (List.Contains(entity));
        }

        public virtual void CopyTo(Entity[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public Entity GetEntityAtLocation(PointF location)
        {
            for (int i = this.Count - 1; i >= 0; i--)
                if (this[i].Rectangle.Contains(location))
                    return this[i];
            return null;
        }

        /// <summary>
        /// Sorts the entity collection.
        /// </summary>
        /// <remarks>This is good for organizing the collection based on the ZOrder.</remarks>
        public void Sort()
        {
            Entity[] entities = new Entity[this.Count];
            int index = 0;
            foreach (Entity entity in this)
                entities[index++] = entity;
            Array.Sort(entities);
            List.Clear();
            foreach (Entity entity in entities)
                this.Add(entity);
        }
    }
    #endregion EntityCollection

    #region EntityDictionary
    /// <summary>
    /// A dictionary describing a number of entities.
    /// </summary>
    [Serializable]
    public class EntityDictionary : DictionaryBase
    {
        public EntityDictionary()
            : base()
        {
        }
        public EntityDictionary(Entity entity)
        {
            this.Add(entity);
        }
        public EntityDictionary(string key, Entity entity)
        {
            this.Add(key, entity);
        }

        public Entity this[string key]
        {
            get
            {
                return (Entity)Dictionary[key];
            }
            set
            {
                if (Dictionary.Contains(key))
                    Dictionary[key] = value;
                else
                    Dictionary.Add(key, value);
            }
        }

        public ICollection Keys
        {
            get
            {
                return Dictionary.Keys;
            }
        }

        public ICollection Values
        {
            get
            {
                return Dictionary.Values;
            }
        }

        public void Add(string key, Entity entity)
        {
            entity.Name = key;
            Dictionary.Add(key, entity);
        }
        public void Add(Entity entity)
        {
            this.Add(entity.Name, entity);
        }

        public bool Contains(string key)
        {
            return Dictionary.Contains(key);
        }

        public void Remove(string key)
        {
            Dictionary.Remove(key);
        }
    }
    #endregion EntityDictionary
}
