//This is just for learning stuff, and is not programmed right.
//This to show everything in the one and same function,
//to not mess up in the head when reading it.
//Soo there is no interfaces and objects or matrices, e.t.c.

//This example comes from Windmiller on The Code Project
//If you want to read more about it or see the Legals, go there!
//Play around with this example.

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SamplePamper
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		//Rotation numbers.
		private double temp = 0.0;
		private double temp2 = 0.0;
		private int _xmouse = 0;
		private int _ymouse = 0;

		//Create coordinates for the polygon surface.
		//Begin with the first point
		private double xx= 0.00;
		private double yy= 0.00;
		private double zz= 0.00;

		//Sec point
		private double xx2= 0.00;
		private double yy2= 100.00;
		private double zz2= 0.00;

		//Third point
		private double xx3= 100.00;
		private double yy3= 100.00;
		private double zz3= 0.00;

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label label1;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(496, 416);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 25;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 432);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(464, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "label1";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(496, 470);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		//The timer function.
		//This will rotate and display everything with light.
		private void timer1_Tick(object sender, System.EventArgs e)
		{
			//Calculate sin and cos for rotation.
			temp = temp + 1.0 /60;
			temp2 = temp2 + 1.0 /380;
			double coX = Math.Cos(temp);
			double siX = Math.Sin(temp);
			double coY = Math.Cos(temp2);
			double siY = Math.Sin(temp2);

			//And the following matrix.
			//As we already have calculated.
			double lRot00 = coY;
			double lRot01 = 0;
			double lRot02 = -siY;
			//double lRot03 = 0;

			double lRot10 = siX*siY;
			double lRot11 = coX;
			double lRot12 = siX*coY;
			//double lRot13 = 0;

			double lRot20 = siY*coX;
			double lRot21 = -siX;
			double lRot22 = coX * coY;
			//double lRot23 = 0;

			//double lRot30 = 0;
			//double lRot31 = 0;
			//double lRot32 = 0;
			//double lRot33 = 1;

			//Calculate new position of point 1
			double ob1posX	= (xx*lRot00)+(yy*lRot10)+(zz*lRot20);
			double ob1posY	= (xx*lRot01)+(yy*lRot11)+(zz*lRot21);
			double ob1posZ	= (xx*lRot02)+(yy*lRot12)+(zz*lRot22);

			//Point 2
			double ob1posX2= (xx2*lRot00)+(yy2*lRot10)+(zz2*lRot20);
			double ob1posY2= (xx2*lRot01)+(yy2*lRot11)+(zz2*lRot21);
			double ob1posZ2= (xx2*lRot02)+(yy2*lRot12)+(zz2*lRot22);

			//Point 3
			double ob1posX3= (xx3*lRot00)+(yy3*lRot10)+(zz3*lRot20);
			double ob1posY3= (xx3*lRot01)+(yy3*lRot11)+(zz3*lRot21);
			double ob1posZ3= (xx3*lRot02)+(yy3*lRot12)+(zz3*lRot22);

			/////////////////
			//Time to calculate Noraml vector and the ligth
			double nx, ny, nz;
			double LoN, skr, LoL, xxx, yyy;
			double l1x, l1y, l1z, l2x, l2y, l2z;
			double c1x, c1y, c1z, c2x, c2y, c2z;
			double LSLx, LSLy, LSLz, LoC;
			double LSCx, LSCy, LSCz, cx;
			double su, du;

			//Calculate line segment one in the surface.
			double LS1x = (ob1posX2 - ob1posX);
			double LS1y = (ob1posY2 - ob1posY);
			double LS1z = (ob1posZ2 - ob1posZ);

			//Calculate line segment two in the surface.
			double LS2x = (ob1posX2 - ob1posX3);
			double LS2y = (ob1posY2 - ob1posY3);
			double LS2z = (ob1posZ2 - ob1posZ3);

			//Cross product by two vector segments from the polygon
			//gives us the Normal-vector.
			nx =((LS1y * LS2z) - (LS1z * LS2y));
			ny = ((LS1z * LS2x) - (LS1x * LS2z));
			nz = ((LS1x * LS2y) - (LS1y * LS2x));

			//Length of the Normal vector (Hyp)
			LoN = Math.Sqrt(Math.Abs((nx * nx) + (ny * ny) + (nz * nz)));

			//Normalizeing the Normal vector.
			nx=nx/Math.Abs(LoN);
			ny=ny/Math.Abs(LoN);
			nz=nz/Math.Abs(LoN);

			//Camerans position.
			c2x = 0; c2y = 0; c2z = 200;
			//Camera is pointing to this point
			c1x = 0; c1y = 0; c1z = 0;

			//Let the light follow the mouse coordinates.
			su = _ymouse;
			du = _xmouse;

			//Ligth vector..
			l2x = du-200; l2y = su-200; l2z = 200;	//Ligth source
			l1x = 0; l1y = 0; l1z = 0; //Target of the light

			//Ligth vector
			LSLx = l2x - l1x;
			LSLy = l2y - l1y;
			LSLz = l2z - l1z;

			//Camera segment vector.
			LSCx = c2x - c1x;
			LSCy = c2y - c1y;
			LSCz = c2z - c1z;

			//Length of light and camera vector/segment
			LoL = Math.Sqrt(Math.Abs((LSLx * LSLx) + (LSLy * LSLy) + (LSLz * LSLz)));
			LoC = Math.Sqrt(Math.Abs((LSCx * LSCx) + (LSCy * LSCy) + (LSCz * LSCz)));

			//Silly this is.
			double ob1posXN = nx;
			double ob1posYN = ny;
			double ob1posZN = nz;

			//Normalize
			LSLx=LSLx/LoL;
			LSLy=LSLy/LoL;
			LSLz=LSLz/LoL;

			//Normalize
			LSCx=LSCx/LoC;
			LSCy=LSCy/LoC;
			LSCz=LSCz/LoC;

			//To calculate the angle between the Normal and the Ligth vector,
			//we are using the Dot product to accomplish this.
			//N . LSL = |N| * |LSL| * sin
			//Nx * LSLx + Ny * LSLy + Nz * LSLz = |N| * |LSL| * sin .. h�r �r |N| o |LSL|
			//Gives us..
			//(Nx * LSLx + Ny * LSLy + Nz * LSLz)/(|N| * |LSL|) = sin()
			xxx = ((nx * LSLx) + (ny * LSLy) + (nz*LSLz) );
			cx = ((nx * LSCx) + (ny * LSCy) + (nz * LSCz));

			//The angle is?
			yyy = Math.Asin(xxx);

			//Convert from rad to degrees
			skr = (yy* (180/Math.PI));

			//Let light vector and camera vector work together to
			//make the light hitting the back-surface not showing on the frontside from the viewer.
			if (xxx<=0&&cx>=0){xxx=0;}

			//////////////////
			System.Drawing.Bitmap bitm = new Bitmap(496, 416);
			Graphics gr = Graphics.FromImage(bitm);
			gr.FillRectangle(Brushes.Black,0,0,bitm.Width,bitm.Height);
			Point[] poi = new Point[3];
			poi[0].X = (int)ob1posX + 200;
			poi[0].Y = (int)ob1posY + 200;
			poi[1].X = (int)ob1posX2+ 200;
			poi[1].Y = (int)ob1posY2+ 200;
			poi[2].X = (int)ob1posX3 + 200;
			poi[2].Y = (int)ob1posY3+200;
	
			Color cl = Color.FromArgb(0,0,Convert.ToInt32(255*Math.Abs(xxx)));
			SolidBrush sb = new SolidBrush(cl);
			gr.FillPolygon(sb,poi);

			gr.DrawLine(new Pen(Color.Red),(float)ob1posX2+200,(float)ob1posY2+200,(float)(ob1posX2+ob1posXN*20)+200,(float)(ob1posY2+ob1posYN*20)+200);
			
			this.pictureBox1.Image = bitm;

			
			//Just showing you some coordinates on screen.
			this.label1.Text = "xxx:"+xxx.ToString()+"\tdegrees:"+yyy.ToString();

		}

		private void pictureBox1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			_xmouse = e.X;
			_ymouse = e.Y;
		}
	}
}
