/*
                Program 6.

      A *VERY* simple example of how to set up and use vertex arrays.
      This question pops up quite often, so I thought a working program
      was in order :)

      Important!
      Be sure to 'glEnableClientState' your vertex arrays AFTER glut has created
      your OpenGL context (it does this with glutInitDisplayMode).  Just call
      your Init function after this and you'll be fine.
*/

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>

PFNGLLOCKARRAYSEXTPROC      glLockArraysEXT   = NULL;
PFNGLUNLOCKARRAYSEXTPROC    glUnlockArraysEXT = NULL;

float angle;

/* Vertex Array object description:
   These arrays contain the vertex data, indices for the vertices, and colours
   for each vertex.  */

GLfloat vertices[] = { -1.0,  1.0,  0.0,
                        1.0,  1.0,  0.0,
                        1.0, -1.0,  0.0,
                       -1.0, -1.0,  0.0 };

GLubyte colours[] = { 255, 255, 255,
                      0,   255, 0,
                      0,   0,   255,
                      255, 0,   0 };

GLuint  indices[] = { 0, 1, 2, 3 };


/* Get Compiled Vertex Array Extension functions.
 * We don't check to see if they are supported - so this WILL cause a crash if
 * if your OpenGL implementation doesn't support it.
 */
void get_CVA_ext(void)
{
   glLockArraysEXT   =  ( PFNGLLOCKARRAYSEXTPROC )
    wglGetProcAddress ( "glLockArraysEXT" );
   glUnlockArraysEXT =  ( PFNGLUNLOCKARRAYSEXTPROC )
    wglGetProcAddress ( "glUnlockArraysEXT" );

   if (( glLockArraysEXT == NULL ) || ( glUnlockArraysEXT == NULL ))
      printf ("Error: get_CVA_ext ( );   -   Could not get Compiled Vertex Array Extension\n");
}

/*      Initialise:
 *      Enable the OpenGL arrays that contain our object data.
 */
void init ( void )
{
   get_CVA_ext ( );

   glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE );

   glEnable ( GL_DEPTH_TEST );
   glEnableClientState ( GL_VERTEX_ARRAY );
   glEnableClientState ( GL_COLOR_ARRAY );
   glClearColor ( 0.0, 0.0, 0.0, 0.0 );
}


/*  Draw Object
 *  Set the current vertex and colour arrays to the ones we have specified above,
 * (obviously, if you had more than one object could use different array names
 * here).
 * Then call glDrawElements with our array indices to draw the object.
 */
void draw_object ( void )
{
   if ( glUnlockArraysEXT != NULL )
      glUnlockArraysEXT ( );

   glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
   glColorPointer  ( 3, GL_UNSIGNED_BYTE, 0, &colours );

   /* Compile current geometry so shared or reused vertices don't need
      re-transforming  */
   if ( glLockArraysEXT != NULL )
      glLockArraysEXT ( 0, ( GLsizei ) 4 );


   // Draw the object
   glDrawElements ( GL_POLYGON, 4, GL_UNSIGNED_INT, indices );
}

/* Standard display callback
 */
void display ( void )
{
   glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
   glPushMatrix ( );
   glTranslatef ( 0.0, 0.0, -3.0 );
   glRotatef    ( angle, 1.0, 1.0, 0.0 );
   draw_object  ( );
   glPopMatrix  ( );
   glutSwapBuffers ( );
}

void reshape ( int w, int h )
{
   glViewport   ( 0, 0, ( GLint ) w, ( GLint ) h );
   glMatrixMode ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, ( GLdouble ) w, 1.0, 2000.0 );
   else
      gluPerspective ( 45, ( GLdouble) w / ( GLdouble ) h, 1.0, 2000.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );
}

void idle_func ( void )
{
   angle = angle + 0.1;
   if ( angle == 360 )
      angle = 0;
   glutPostRedisplay ( );
}

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
int main ( void )
{
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
   glutInitWindowSize  ( 250, 250);
   glutCreateWindow    ( "Vertex Array Test" );
   glutReshapeFunc ( reshape );
   glutDisplayFunc ( display );
   glutIdleFunc    ( idle_func );

   init ( );

   glutMainLoop    ( );
   return 0;
}
