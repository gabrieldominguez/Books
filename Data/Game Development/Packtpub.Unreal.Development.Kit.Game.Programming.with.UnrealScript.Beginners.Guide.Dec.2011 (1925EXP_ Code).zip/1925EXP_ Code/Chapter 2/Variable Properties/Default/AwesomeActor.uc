class AwesomeActor extends Actor
    placeable;

var string MyName;
var int NumberOfKittens;
var float DistanceToGo;

var int MyArray[2];

struct Basket
{
    var string BasketColor;
    var int NumberOfKittens, BallsOfString;
    var float BasketSize;

    structdefaultproperties
    {
        BasketColor="Blue"
        NumberOfKittens=3
        BasketSize=12.0
    }
};

var vector MyVector;

function PostBeginPlay()
{
    `log("MyName:" @ MyName);
    `log("NumberOfKittens:" @ NumberOfKittens);
    `log("DistanceToGo:" @ DistanceToGo);
}

defaultproperties
{
    MyName="Rachel"
    NumberOfKittens=3
    DistanceToGo=120.0

    MyArray(0)=3
    MyArray(1)=2

    MyVector=(X=1.0,Y=5.3,Z=2.1)

    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
