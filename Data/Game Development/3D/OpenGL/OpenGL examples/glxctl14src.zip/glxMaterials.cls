VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxMaterials"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: creates a collection of 28 stock materials
'
'AUTHOR: ported by edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------

''******* materials ********************************/
'' 24 tea materials (from teapots app)
Const NUM_TEX_MATERIALS = 4
Const NUM_TEA_MATERIALS = 24
Const NUM_GOOD_MATERIALS = 16
'Public NUM_TEA_MATERIALS&
'Public FMAT_GRAD_FUDGE!
'Public NUM_TEX_MATERIALS& 'white' materials, for texturing
'Public NUM_GOOD_MATERIALS& ' 'good' ones among the 24 tea materials
Public Enum ssMaterialTypes
    EMERALD = 0
    JADE = 1
    OBSIDIAN = 2
    PEARL = 3
    RUBY = 4
    TURQUOISE = 5
    BRASS = 6
    BRONZE = 7
    CHROME = 8
    COPPER = 9
    GOLD = 10
    SILVER = 11
    BLACK_PLASTIC = 12
    CYAN_PLASTIC = 13
    GREEN_PLASTIC = 14
    RED_PLASTIC = 15
    WHITE_PLASTIC = 16
    YELLOW_PLASTIC = 17
    BLACK_RUBBER = 18
    CYAN_RUBBER = 19
    GREEN_RUBBER = 20
    RED_RUBBER = 21
    WHITE_RUBBER = 22
    YELLOW_RUBBER = 23
    BRIGHT_WHITE = 24
    LESS_BRIGHT_WHITE = 25
    WARM_WHITE = 26
    COOL_WHITE = 27
End Enum

''*****************************Module*Header*******************************\
'* Module Name: COMMON/material.c
'* Material selection functions.
'* Copyright (c) 1994 Microsoft Corporation
'-------------------------------------------------------------------------
'Dim goodMaterials&(0 To NUM_GOOD_MATERIALS - 1)
'Dim teaMaterialData!(0 To NUM_TEA_MATERIALS - 1, 0 To 9)
Dim m_Material(0 To NUM_TEA_MATERIALS + NUM_TEX_MATERIALS - 1) As glxMaterial
Public ss_BlackMat As New glxMaterial

Private Sub Class_Initialize()
Dim i&
    For i = 0 To UBound(m_Material)
        Set m_Material(i) = New glxMaterial
    Next
    m_InitMaterials m_Material
End Sub

Private Sub Class_Terminate()
Dim i&
    For i = 0 To UBound(m_Material)
        Set m_Material(i) = Nothing
    Next
End Sub


Private Sub m_InitAMaterial(m As glxMaterial, ar!, ag!, ab!, _
                        dr!, dg!, db!, _
                        sr!, sg!, sb!, shin!)
m.Ambient(0) = ar
m.Ambient(1) = ag
m.Ambient(2) = ab
m.Ambient(3) = 1 '0.5
m.Diffuse(0) = dr
m.Diffuse(1) = dg
m.Diffuse(2) = db
m.Diffuse(3) = 1 '0.5
m.Specular(0) = sr
m.Specular(1) = sg
m.Specular(2) = sb
m.Specular(3) = 1 '0.5
m.SpecExp = shin
End Sub

''---------------------------------------------------------------------------------
'* m_InitMaterials
'* Initialize MATERIAL structures with data
'* - Set alpha to 0.5 for all materials
'-------------------------------------------------------------------------
Private Sub m_InitMaterials(pm() As glxMaterial) ', pd!, count&)
Dim i&
'goodMaterials[NUM_GOOD_MATERIALS] = {
'        EMERALD, JADE, PEARL, RUBY, TURQUOISE, BRASS, BRONZE,
'        COPPER, GOLD, SILVER, CYAN_PLASTIC, WHITE_PLASTIC, YELLOW_PLASTIC,
'        CYAN_RUBBER, GREEN_RUBBER, WHITE_RUBBER }
'
''  materials:  emerald, jade, obsidian, pearl, ruby, turquoise
' *              brass, bronze, chrome, copper, gold, silver
' *              black, cyan, green, red, white, yellow plastic
' *              black, cyan, green, red, white, yellow rubber
'description:     ambient (RGB), diffuse(RGB), specular(RGB), shininess
'*
'*/
' 'tea' materials, from aux teapots program
m_InitAMaterial pm(0), _
    0.0215, 0.1745, 0.0215, _
    0.07568, 0.61424, 0.07568, _
    0.633, 0.727811, 0.633, 0.6
m_InitAMaterial pm(1), _
     0.135, 0.2225, 0.1575, _
        0.54, 0.89, 0.63, _
        0.316228, 0.316228, 0.316228, 0.1
m_InitAMaterial pm(2), _
     0.05375, 0.05, 0.06625, _
        0.18275, 0.17, 0.22525, _
        0.332741, 0.328634, 0.346435, 0.3
m_InitAMaterial pm(3), _
     0.25, 0.20725, 0.20725, _
        1, 0.829, 0.829, _
        0.296648, 0.296648, 0.296648, 0.088
m_InitAMaterial pm(4), _
     0.1745, 0.01175, 0.01175, _
        0.61424, 0.04136, 0.04136, _
        0.727811, 0.626959, 0.626959, 0.6
m_InitAMaterial pm(5), _
     0.1, 0.18725, 0.1745, _
        0.396, 0.74151, 0.69102, _
        0.297254, 0.30829, 0.306678, 0.1
m_InitAMaterial pm(6), _
     0.329412, 0.223529, 0.027451, _
        0.780392, 0.568627, 0.113725, _
        0.992157, 0.941176, 0.807843, 0.21794872
m_InitAMaterial pm(7), _
     0.2125, 0.1275, 0.054, _
        0.714, 0.4284, 0.18144, _
        0.393548, 0.271906, 0.166721, 0.2
m_InitAMaterial pm(8), _
     0.25, 0.25, 0.25, _
        0.4, 0.4, 0.4, _
        0.774597, 0.774597, 0.774597, 0.6
m_InitAMaterial pm(9), _
     0.19125, 0.0735, 0.0225, _
        0.7038, 0.27048, 0.0828, _
        0.256777, 0.137622, 0.086014, 0.1
m_InitAMaterial pm(10), _
     0.24725, 0.1995, 0.0745, _
        0.75164, 0.60648, 0.22648, _
        0.628281, 0.555802, 0.366065, 0.4
m_InitAMaterial pm(11), _
     0.19225, 0.19225, 0.19225, _
        0.50754, 0.50754, 0.50754, _
        0.508273, 0.508273, 0.508273, 0.4
m_InitAMaterial pm(12), _
     0, 0, 0, _
     0.01, 0.01, 0.01, _
        0.5, 0.5, 0.5, 0.25
m_InitAMaterial pm(13), _
     0, 0.1, 0.06, _
     0, 0.50980392, 0.50980392, _
        0.50196078, 0.50196078, 0.50196078, 0.25
m_InitAMaterial pm(14), _
     0, 0, 0, _
        0.1, 0.35, 0.1, _
        0.45, 0.55, 0.45, 0.25
m_InitAMaterial pm(15), _
     0, 0, 0, _
     0.5, 0, 0, _
        0.7, 0.6, 0.6, 0.25
m_InitAMaterial pm(16), _
     0, 0, 0, _
     0.55, 0.55, 0.55, _
        0.7, 0.7, 0.7, 0.25
m_InitAMaterial pm(17), _
     0, 0, 0, _
     0.5, 0.5, 0, _
        0.6, 0.6, 0.5, 0.25
m_InitAMaterial pm(18), _
     0.02, 0.02, 0.02, _
     0.01, 0.01, 0.01, _
        0.4, 0.4, 0.4, 0.078125
m_InitAMaterial pm(19), _
     0, 0.05, 0.05, _
     0.4, 0.5, 0.5, _
        0.04, 0.7, 0.7, 0.078125
m_InitAMaterial pm(20), _
     0, 0.05, 0, _
     0.4, 0.5, 0.4, _
        0.04, 0.7, 0.04, 0.078125
m_InitAMaterial pm(21), _
     0.05, 0, 0, _
     0.5, 0.4, 0.4, _
        0.7, 0.04, 0.04, 0.078125
m_InitAMaterial pm(22), _
     0.05, 0.05, 0.05, _
     0.5, 0.5, 0.5, _
        0.7, 0.7, 0.7, 0.078125
m_InitAMaterial pm(23), _
     0.05, 0.05, 0, _
     0.5, 0.5, 0.4, _
        0.7, 0.7, 0.04, 0.078125
' generally white materials for texturing
'static GLfloat texMaterialData[NUM_TEX_MATERIALS][10] = {
' bright white
m_InitAMaterial pm(24), _
     0.2, 0.2, 0.2, _
        1, 1, 1, 1, 1, 1, 0.5
' less bright white
m_InitAMaterial pm(25), _
     0.2, 0.2, 0.2, _
        0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.5
' warmish white
m_InitAMaterial pm(26), _
     0.3, 0.2, 0.2, _
        1, 0.9, 0.8, 1, 0.9, 0.8, 0.5
' coolish white
m_InitAMaterial pm(27), _
     0.2, 0.2, 0.3, _
        0.8, 0.9, 1, 0.8, 0.9, 1, 0.5
End Sub


''---------------------------------------------------------------------------------
'SetMaterialIndex
'* Set material using its index name
'-------------------------------------------------------------------------
Public Sub SetMaterialIndex(ByVal Index As ssMaterialTypes)
    If ((Index < 0) Or (Index >= (NUM_TEA_MATERIALS + NUM_TEX_MATERIALS))) Then
        Exit Sub
    End If
    m_Material(Index).SetMaterial
End Sub

''---------------------------------------------------------------------------------
'* GetMaterialIndex
'* returns a reference to a predefined material
'-------------------------------------------------------------------------
Public Function GetMaterialIndex(ByVal Index As ssMaterialTypes) As glxMaterial
    If ((Index < 0) Or (Index >= (NUM_TEA_MATERIALS + NUM_TEX_MATERIALS))) Then
        Index = BRIGHT_WHITE
    End If
    Set GetMaterialIndex = m_Material(Index)
End Function

''---------------------------------------------------------------------------------
'RandomTeaMaterial
'* Select a random TeaMaterial
'* Return ptr to material
'-------------------------------------------------------------------------
Public Function RandomTeaMaterial(ByVal bSet As Boolean) As glxMaterial
Dim Index&
Dim pMat As glxMaterial
    'Index = goodMaterials(UC.RandomInt(NUM_GOOD_MATERIALS - 1))
    Index = UC.Ex.RandomInt(NUM_GOOD_MATERIALS - 1)
    Set pMat = m_Material(Index)
    If (bSet) Then
        pMat.SetMaterial
    End If
    Set RandomTeaMaterial = pMat
End Function

''---------------------------------------------------------------------------------
'RandomTeaMaterialIndex
'* Select a random TeaMaterial
'* Return material index
'-------------------------------------------------------------------------
Public Function RandomTeaMaterialIndex&(ByVal bSet As Boolean)
Dim Index&
    'Index = goodMaterials(UC.RandomInt(NUM_GOOD_MATERIALS))
    Index = UC.Ex.RandomInt(NUM_GOOD_MATERIALS)
    If (bSet) Then
        m_Material(Index).SetMaterial
    End If
    RandomTeaMaterialIndex = Index
End Function

''---------------------------------------------------------------------------------
'RandomTexMaterial
'* Select a random TexMaterial
'* Return ptr to material
'-------------------------------------------------------------------------
Public Function RandomTexMaterial(ByVal bSet As Boolean) As glxMaterial
Dim Index&
Dim pMat As glxMaterial
    Index = NUM_TEA_MATERIALS + UC.Ex.RandomInt(NUM_TEX_MATERIALS) - 1
    Set pMat = m_Material(Index)
    If bSet Then
        pMat.SetMaterial
    End If
    Set RandomTexMaterial = pMat
End Function

''---------------------------------------------------------------------------------
'RandomTexMaterialIndex
'* Select a random TexMaterial
'-------------------------------------------------------------------------
Public Function RandomTexMaterialIndex&(ByVal bSet As Boolean)
Dim Index&
    Index = NUM_TEA_MATERIALS + UC.Ex.RandomInt(NUM_TEX_MATERIALS)
    If bSet Then
        m_Material(Index).SetMaterial
    End If
    RandomTexMaterialIndex = Index
End Function



