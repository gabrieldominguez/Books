Attribute VB_Name = "mTransport"
Option Explicit
''
' * transport.c
' *
' * FUNCTION:
' * Illustrate principle of shearing vs. parallel transport.
' *
' * HISTORY:
' * -- created by Linas Vepstas October 1991
' * -- C++ and OO playing around Linas Vepstas June 1993
' * -- converted to use GLUT -- December 1995, Linas
' *
' */
' =========================================================== */
Public Arrow As gleSpiral
Public IDArrow&
Dim MatArrow As glxMaterial
Const NUMCTRPTS = 7
Const SCALEz = 1.8

' =========================================================== */
Public Sub InitSpiral()
    Set Arrow = gCtl.NewSpiral
    With Arrow
        .startRadius = 7.3
        .sweepTheta = 90
        ' define contour up vector */
        .SetUp 0, 0, 1
        .NumContourPoints = NUMCTRPTS
        .NumContourNormals = NUMCTRPTS
        .sweepTheta = 180# ' + 0.13* lastx;
        .dzdTheta = 0.03 * 100 '(lasty+10.0);
    End With
    Set MatArrow = gCtl.NewMaterial
    ' define color of arrow */
    With MatArrow
        .SetAmbient 0.15, 0.15, 0.15
        .SetDiffuse 0.15, 0.55, 0.55
        .SetSpecular 0.4, 0.4, 0.4
        .Shininess = 2
    End With
    ' define arrow contour */
    With Arrow
        Set CurModel = Arrow
        CONTOUR2 0, 1, -2, SCALEz
        CONTOUR2 1, 1, 0, SCALEz
        CONTOUR2 2, 2, 0, SCALEz
        CONTOUR2 3, 0, 2, SCALEz
        CONTOUR2 4, -2, 0, SCALEz
        CONTOUR2 5, -1, 0, SCALEz
        CONTOUR2 6, -1, -2, SCALEz
        ' set the initial join style */
        .CapStyle = gleCAPS
        .JoinStyle = CX.JoinStyle
        .NormStyle = CX.NormStyle
        .TextureEnabled = CX.TextureEnabled
        .TextureMode = CX.TextureStyle
        .ContourStyle = gleCLOSED
    End With
    IDArrow = glGenLists(1)
    glNewList IDArrow, lstCompile
        DrawSpiral
    glEndList
End Sub

' =========================================================== */
Public Sub DrawSpiral()

   ' set up some matrices so that the object spins with the mouse */
    glPushMatrix
'   glTranslatef (0.0, 0.0, -80.0);
'   glRotated (-75.0, 1.0, 0.0, 0.0);
'   glRotated (-10.0, 0.0, 0.0, 1.0);

   ' first, draw with the routine that uses a local coordinate
   ' * system with torsion */
    'glTranslated -0.5, -0.5, 4.2

'   gleLathe (arrow->contour->numContourPoints,
'           arrow->contour->pts,
'           arrow->contour->norms,
'           arrow->contour->up,
'           arrow->startRadius,    ' donut radius */
'           arrow->drdTheta,   ' change in donut radius per revolution */
'           arrow->startZ,    ' start z value */
'           arrow->dzdTheta,     ' change in Z per revolution */
'           NULL,
'           NULL,
'           arrow->startTheta,     ' start angle */
'           arrow->sweepTheta);     ' sweep angle */

   ' next, draw with a routine that uses parallel transport */
    glTranslated 0, 0, -8.4
    Arrow.Draw
'   gleSpiral (arrow->contour->numContourPoints,
'           arrow->contour->pts,
'           arrow->contour->norms,
'           arrow->contour->up,
'           arrow->startRadius,    ' donut radius */
'           arrow->drdTheta,   ' change in donut radius per revolution */
'           arrow->startZ,    ' start z value */
'           arrow->dzdTheta,     ' change in Z per revolution */
'           NULL,
'           NULL,
'           arrow->startTheta,     ' start angle */
'           arrow->sweepTheta);     ' sweep angle */
    glPopMatrix
End Sub

' =========================================================== */
'Private Sub FACET(i&)
'Dim x1#, x2#, y1#, y2#
'Dim dx#, dy#, w#
'With Arrow
'    .GetContourPt i, x1, y1
'    .GetContourPt i + 1, x2, y2
'    dx = x2 - x1
'    dy = y2 - y1
'    w = 1 / Sqr(dx * dx + dy * dy)
'    dx = dx * w
'    dy = dy * w
'    .SetContourNormal i, -dy, dx
'End With
'End Sub


