Attribute VB_Name = "mConstants"
Option Explicit

Public Const DROT = 10
Public Const PI = 3.14159265358979
Public Const WIDTH = 512
Public Const HEIGHT = 512

Type TVertex
    pt(0 To 2) As Single
    n(0 To 2) As Single
    Color(0 To 2) As Single
End Type

Type TTriangle
    iv1 As Long
    iV2 As Long
    iV3 As Long
End Type

Type TSphere
    r(0 To 2) As Single
    dr(0 To 2) As Single
End Type


