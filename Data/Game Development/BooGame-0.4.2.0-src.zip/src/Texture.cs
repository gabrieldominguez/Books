/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;

using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;

using Tao.DevIl;
using Tao.OpenGl;

namespace BooGame
{
    /// <summary>
    /// Represents a single texture.
    /// </summary>
	[Serializable]
    public class Texture : IDisposable, ISerializable
    {
        #region Disposing
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                }
				try
				{
					if(m_TextureID != -1)
                        Gl.glDeleteTextures(1, ref m_TextureID);
				}
				catch
				{
					// already disposed?
					// TODO: Find out why
					// Should be NullReferenceException in .NET 1.1 and AccessViolationException in .NET 2.0
				}
            }
            disposed = true;
        }
        ~Texture()
        {
            Dispose(false);
        }
        #endregion Disposing

        static Texture()
        {
			Core.Initialize();

            Il.ilInit();
            Ilu.iluInit();
            Ilut.ilutInit();

            Ilu.iluImageParameter(Ilu.ILU_PLACEMENT, Ilu.ILU_UPPER_LEFT);
        }

		internal static void Initialize()
		{
		}

        private int m_TextureID = -1;

        public void Draw(RectangleF dest)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, 0, 0, m_Width, m_Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(RectangleF dest, Rectangle source)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, source.X, source.Y, source.Width, source.Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(PointF dest)
        {
            Draw(dest.X, dest.Y, m_Width, m_Height, 0, 0, m_Width, m_Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw()
        {
            Draw(0f, 0f);
        }
        public void Draw(SizeF size)
        {
            Draw(0f, 0f, size.Width, size.Height, 0, 0, m_Width, m_Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(float x, float y)
        {
            Draw(x, y, m_Width, m_Height, 0, 0, m_Width, m_Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(float x, float y, float width, float height)
        {
            Draw(x, y, width, height, 0, 0, m_Width, m_Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(float x, float y, float width, float height, Rectangle source)
        {
            Draw(x, y, width, height, source.X, source.Y, source.Width, source.Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }
        
        public void Draw(PointF dest, Rectangle source)
        {
            Draw(dest.X, dest.Y, m_Width, m_Height, source.X, source.Y, source.Width, source.Height, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(RectangleF dest, Rectangle source, PointF hotspot, float rotation, float scaleX, float scaleY, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, source.X, source.Y, source.Width, source.Height, hotspot.X, hotspot.Y, rotation, scaleX, scaleY, tint);
        }

        public void Draw(PointF dest, Rectangle source, PointF hotspot, float rotation, float scaleX, float scaleY, ColorF tint)
        {
            Draw(dest.X, dest.Y, m_Width, m_Height, source.X, source.Y, source.Width, source.Height, hotspot.X, hotspot.Y, rotation, scaleX, scaleY, tint);
        }

        public void Draw(PointF dest, Rectangle source, PointF hotspot, float rotation, ColorF tint)
        {
            Draw(dest.X, dest.Y, m_Width, m_Height, source.X, source.Y, source.Width, source.Height, hotspot.X, hotspot.Y, rotation, 1f, 1f, tint);
        }

        public void Draw(RectangleF dest, Rectangle source, PointF hotspot, float rotation, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, source.X, source.Y, source.Width, source.Height, hotspot.X, hotspot.Y, rotation, 1f, 1f, tint);
        }
        public void Draw(float x, float y, float width, float height, int sourceX, int sourceY, int sourceWidth, int sourceHeight, float hotspotX, float hotspotY, float rotation, ColorF tint)
        {
            Draw(x, y, width, height, sourceX, sourceY, sourceWidth, sourceHeight, hotspotX, hotspotY, rotation, 1f, 1f, tint);
        }

        public void Draw(float x, float y, float width, float height, int sourceX, int sourceY, int sourceWidth, int sourceHeight, float rotation, ColorF tint)
        {
            Draw(x, y, width, height, sourceX, sourceY, sourceWidth, sourceHeight, 0f, 0f, rotation, 1f, 1f, tint);
        }

        public void Draw(float x, float y, float width, float height, int sourceX, int sourceY, int sourceWidth, int sourceHeight, ColorF tint)
        {
            Draw(x, y, width, height, sourceX, sourceY, sourceWidth, sourceHeight, 0f, 0f, 0f, 1f, 1f, tint);
        }

        public void Draw(RectangleF dest, Rectangle source, ColorF tint)
        {
            Draw(dest.X, dest.Y, dest.Width, dest.Height, source.X, source.Y, source.Width, source.Height, 0f, 0f, 0f, 1f, 1f, tint);
        }

        public void Draw(PointF dest, Rectangle source, ColorF tint)
        {
            Draw(dest.X, dest.Y, m_Width, m_Height, source.X, source.Y, source.Width, source.Height, 0f, 0f, 0f, 1f, 1f, tint);
        }

        public void Draw(float x, float y, float width, float height, int sourceX, int sourceY, int sourceWidth, int sourceHeight)
        {
            Draw(x, y, width, height, sourceX, sourceY, sourceWidth, sourceHeight, 0f, 0f, 0f, 1f, 1f, Color.White);
        }

        public void Draw(float x, float y, float width, float height, int sourceX, int sourceY, int sourceWidth, int sourceHeight, float hotspotX, float hotspotY, float rotation, float scaleX, float scaleY, ColorF tint)
        {
            if (tint.A <= 0)
                return;
            Bind();
            Gl.glPushMatrix();
            Camera.ApplyMatrix();
            Gl.glTranslatef(x, y, 0f);
            Gl.glRotatef(rotation, 0f, 0f, 1f);
            Gl.glScalef(scaleX, scaleY, 0f);
            Gl.glTranslatef(-hotspotX, -hotspotY, 0f);
            Gl.glColor4f(tint.R, tint.G, tint.B, tint.A);

            x = (float)sourceX / (float)m_TextureWidth;
            y = (float)sourceY / (float)m_TextureHeight;
            float twidth = (float)sourceWidth / (float)m_TextureWidth;
            float theight = (float)sourceHeight / (float)m_TextureHeight;

            Gl.glBegin(Gl.GL_QUADS);
            {
                Gl.glTexCoord2f(x, 1f - y);
                Gl.glVertex2f(0f, 0f);

                Gl.glTexCoord2f(x + twidth, 1f - y);
                Gl.glVertex2f(width, 0f);

                Gl.glTexCoord2f(x + twidth, 1f - y - theight);
                Gl.glVertex2f(width, height);

                Gl.glTexCoord2f(x, 1f - y - theight);
                Gl.glVertex2f(0f, height);
            }
            Gl.glEnd();
            Gl.glPopMatrix();
        }

        /// <summary>
        /// Deny access to default constructor.
        /// </summary>
		protected Texture()
		{
		}

        /// <summary>
        /// Loads a texture from a file.
        /// </summary>
        /// <param name="filename">The file to be loaded through the file system.</param>
        public Texture(string filename)
        {
            Load(filename);
        }

        /// <summary>
        /// Loads a texture from a byte array.
        /// </summary>
        /// <param name="name">The name to refer to the image as.</param>
        /// <param name="data">The byte data to load.</param>
        /// <remarks>It is set as protected as to allow serialization.</remarks>
        protected Texture(byte[] data)
        {
            Load(data);
        }

        /// <summary>
        /// Loads a texture from a stream.
        /// </summary>
        /// <param name="stream">The stream to load.</param>
        /// <remarks>It is set as protected as to allow serialization.</remarks>
        protected Texture(Stream stream)
        {
            Load(stream);
        }

        /// <summary>
        /// Loads a texture from an image.
        /// </summary>
        /// <param name="image">The image to load.</param>
        /// <remarks>It is set as protected as to allow serialization.</remarks>
        protected Texture(Image image)
        {
            Load(image);
        }

        /// <summary>
        /// Loads the texture from a file.
        /// </summary>
        /// <param name="filename">The file to load.</param>
        /// <remarks>It is set as protected as to allow serialization. Use constructor instead.</remarks>
        protected void Load(string filename)
        {
            m_Name = filename;
            Load(FileSystem.GetBytes(filename));
        }

        /// <summary>
        /// Loads the texture from a stream.
        /// </summary>
        /// <param name="stream"></param>
        protected void Load(Stream stream)
        {
            byte[] buffer = new byte[stream.Length];
            stream.Read(buffer, 0, (int)stream.Length);
            Load(buffer);
        }

        /// <summary>
        /// Loads the texture from an Image.
        /// </summary>
        /// <param name="image">The image to load from.</param>
        protected void Load(Image image)
        {
            byte[] buffer;
            using (MemoryStream stream = new MemoryStream())
            {
                image.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                buffer = stream.GetBuffer();
            }
            Load(buffer);
        }

        /// <summary>
        /// Loads a byte buffer into the texture state.
        /// </summary>
        /// <param name="buffer">The byte buffer to load.</param>
        protected void Load(byte[] buffer)
        {
            // Generate an DevIL image
            int ilImage;
            Il.ilGenImages(1, out ilImage);

            // Bind the image so that we work with it
            Il.ilBindImage(ilImage);

            // Load the buffer
            if (!Il.ilLoadL(Il.IL_TYPE_UNKNOWN, buffer, buffer.Length))
                throw new Exception("Failed to load image.");

            // Convert every colour component into unsigned byte. If your image contains alpha channel you can replace IL_RGB with IL_RGBA
            if (!Il.ilConvertImage(Il.IL_RGBA, Il.IL_UNSIGNED_BYTE))
                throw new Exception("Failed to convert image.");

            // Get details
            m_BytesPerPixel = Il.ilGetInteger(Il.IL_IMAGE_BPP);
            m_Width = Il.ilGetInteger(Il.IL_IMAGE_WIDTH);
            m_Height = Il.ilGetInteger(Il.IL_IMAGE_HEIGHT);
            m_Format = Il.ilGetInteger(Il.IL_IMAGE_FORMAT);
            m_Depth = Il.ilGetInteger(Il.IL_IMAGE_DEPTH);

            m_TextureWidth = NextPowerOfTwo(m_Width);
            m_TextureHeight = NextPowerOfTwo(m_Height);
            if ((m_TextureWidth != m_Width) || (m_TextureHeight != m_Height))
                Ilu.iluEnlargeCanvas(m_TextureWidth, m_TextureHeight, m_Depth);

            Ilu.iluFlipImage();

            // Generate GL name
            Gl.glGenTextures(1, out m_TextureID);

            // Bind GL texture
            Gl.glBindTexture(Gl.GL_TEXTURE_2D, m_TextureID);

            // Use linear interpolation for magnification filter
            Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_NEAREST);

            // Use linear interpolation for minifying filter
            Gl.glTexParameterf(Gl.GL_TEXTURE_2D, Gl.GL_TEXTURE_MAG_FILTER, Gl.GL_NEAREST);

            // Texture specification
            Gl.glTexImage2D(Gl.GL_TEXTURE_2D, 0, m_BytesPerPixel, m_TextureWidth,
                m_TextureHeight, 0, m_Format, Gl.GL_UNSIGNED_BYTE, Il.ilGetData());

            // Release from IL memory
            Il.ilDeleteImages(1, ref ilImage);
        }

        private int NextPowerOfTwo(int n)
        {
            double power = 0;
            while (n > Math.Pow(2.0, power))
                power++;
            return (int)Math.Pow(2.0, power);
        }

        private int m_BytesPerPixel = 0;
        /// <summary>
        /// Gets the bytes per pixel associated with this texture.
        /// </summary>
        public int BytesPerPixel
        {
            get
            {
                return m_BytesPerPixel;
            }
        }

        private int m_TextureWidth = 0;
        /// <summary>
        /// Gets the actual width of the OpenGL texture in pixels.
        /// </summary>
        public int TextureWidth
        {
            get
            {
                return m_TextureWidth;
            }
        }

        private int m_TextureHeight = 0;
        /// <summary>
        /// Gets the actual height of the OpenGL texture in pixels.
        /// </summary>
        public int TextureHeight
        {
            get
            {
                return m_TextureHeight;
            }
        }

        private int m_Width = 0;
        /// <summary>
        /// Gets the width of the texture in pixels.
        /// </summary>
        public virtual int Width
        {
            get
            {
                return m_Width;
            }
        }

        private int m_Height = 0;
        /// <summary>
        /// Gets the height of the texture in pixels.
        /// </summary>
        public virtual int Height
        {
            get
            {
                return m_Height;
            }
        }

        private int m_Format = 0;
        /// <summary>
        /// Gets the format of the texture.
        /// </summary>
        public int Format
        {
            get
            {
                return m_Format;
            }
        }

        /// <summary>
        /// The name of which the texture is associated with.
        /// </summary>
        protected string m_Name;
        /// <summary>
        /// Gets the name of which this texture was loaded.
        /// </summary>
        public string Name
        {
            get
            {
                return m_Name;
            }
        }

        private int m_Depth = 0;
        /// <summary>
        /// Gets the depth of the texture.
        /// </summary>
        public int Depth
        {
            get
            {
                return m_Depth;
            }
        }

		private static int m_BoundTexture = -999;
        /// <summary>
        /// Binds the texture to the OpenGL context.
        /// </summary>
        /// <returns>The bound texture index.</returns>
        internal void Bind()
        {
			if(m_BoundTexture != m_TextureID)
			{
				Gl.glBindTexture(Gl.GL_TEXTURE_2D, m_TextureID);
				m_BoundTexture = m_TextureID;
			}
        }

        #region Serialization
        /// <summary>
        /// Save a serialized state of this object to a file.
        /// </summary>
        /// <param name="filename">The destination filename.</param>
        public virtual void Save(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(stream, this);
            }
        }

        /// <summary>
        /// Loads a serialized texture state from a file.
        /// </summary>
        /// <param name="filename">The destination filename.</param>
        /// <returns>The loaded texture object.</returns>
        public static Texture FromSerialized(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            Texture text;
            using (Stream stream = FileSystem.GetStream(filename))
            {
                text = (Texture)formatter.Deserialize(stream);
            }
            return text;
        }

        protected Texture(SerializationInfo info, StreamingContext context)
        {
            Load(FileSystem.GetBytes(info.GetString("name")));
        }

        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("name", m_Name);
        }
        #endregion Serialization
    }

    #region TextureCollection
    /// <summary>
    /// A collection of Textures.
    /// </summary>
    [Serializable]
    public class TextureCollection : CollectionBase, ICollection
    {
        public TextureCollection()
            : base()
        {
        }

        public TextureCollection(TextureCollection textures)
        {
            this.Add(textures);
        }

        public TextureCollection(string filename)
        {
            this.List.Add(new Texture(filename));
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public TextureCollection(Texture texture)
        {
            Add(texture);
        }

        public Texture this[int index]
        {
            get
            {
                return ((Texture)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }

        public int Add(Texture texture)
        {
            return (List.Add(texture));
        }

        public int Add(TextureCollection textureCollection)
        {
            for (int i = 0; i < textureCollection.Count; i++)
                this.List.Add(textureCollection[i]);
            return this.Count;
        }

        public int Add(string fileName)
        {
            return (this.Add(new Texture(fileName)));
        }

        public void Insert(int index, Texture texture)
        {
            List.Insert(index, texture);
        }

        public void Remove(Texture texture)
        {
            List.Remove(texture);
        }

        public int IndexOf(Texture texture)
        {
            return (List.IndexOf(texture));
        }

        public bool Contains(Texture texture)
        {
            return (List.Contains(texture));
        }

        public virtual void CopyTo(Texture[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }
    }
    #endregion TextureCollection
}
