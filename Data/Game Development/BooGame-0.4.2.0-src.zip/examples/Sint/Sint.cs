/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;

namespace Sint
{
    /// <summary>
    /// BooGame demonstration of using a Tile Studio map (ScrollDemo).
    /// </summary>
    public class Sint : GameState
    {
        public static void Main()
        {
            // Location to load Sint game data
            FileSystem.AddSearchPath("SintData.zip");

            // Setup the game state
            Core.Game = new Sint();

            // Setup the system
            Display.ClearColor = Color.Black;
            Keyboard.KeyRepeat = false;
            Display.WindowCaption = "BooGame - Sint";

            // Report the FPS
            Timer.FpsUpdate += new FpsUpdateEventHandler(Timer_FpsUpdate);

            // Begin running the system
            Core.Run();
        }

        // When there's a new FPS value
        static void Timer_FpsUpdate(object sender, FpsUpdateEventArgs args)
        {
            // Report the new FPS value
            Display.WindowCaption = "BooGame - Sint - " + args.Fps.ToString("#.0") + " FPS";
        }

        // Load the Tile Studio map scripts
        Map map = Map.FromFile("L1Level.map");
        Sprite player = new Sprite(); // The player sprite

        public Sint()
        {
            // Add the map
            Entities.Add(map);

            // Load the player sprite from the character map
            Map sint = Map.FromFile("MainCharSint.map");
            player.Animations.Add(sint.Animations);
            player.HotSpot = new PointF(player.Width / 2F, 0f);
            player.Center = new PointF(375, 150);
            Entities.Add(player);
        }

        public override void KeyDown(KeyboardEventArgs args)
        {
            // Arrow keys move the player
            switch (args.Key)
            {
                case Keys.RightArrow:
                    player.Velocity.X = 120f;
                    player.CurrentAnimation = 1;
                    player.ScaleX = 1f;
                    break;
                case Keys.LeftArrow:
                    player.Velocity.X = -120f;
                    player.CurrentAnimation = 1;
                    player.ScaleX = -1f;
                    break;
            }
        }

        public override void KeyUp(KeyboardEventArgs args)
        {
            // Letting go of the arrow keys stops the player from moving
            switch (args.Key)
            {
                case Keys.RightArrow:
                    player.Velocity.X = 0f;
                    player.CurrentAnimation = 0;
                    break;
                case Keys.LeftArrow:
                    player.Velocity.X = 0f;
                    player.CurrentAnimation = 0;
                    break;
                case Keys.Escape:
                    Core.QuitApplication();
                    break;
            }
        }

        public override void Update()
        {
            // Move the map object entities
            base.Update();

            // Apply gravity
            player.Velocity.Y += 90f * Timer.DeltaSeconds;

            // Player lands on platform
            if (player.Velocity.Y > 0f)
            {
                Tile tileBelow = map.GetTile(player.Center.X, player.Bottom, true);
                if (tileBelow != null)
                {
                    if (tileBelow.TopBoundry)
                    {
                        player.Velocity.Y = 0f;
                        player.Bottom = map.GetTileLocation(player.Center.X, player.Bottom, true).Top;

                        // Check if player wants to jump
                        if (Keyboard.IsKeyDown(Keys.UpArrow))
                        {
                            player.Velocity.Y = -120f;
                            player.CurrentAnimation = 3;
                        }
                    }
                }
            }

            // Falling animations
            if (player.Velocity.X == 0)
            {
                if (player.Velocity.Y > 20) // jump up
                    player.CurrentAnimation = 4;
                else if (player.Velocity.Y < -7) // fall
                    player.CurrentAnimation = 3;
                else // standing
                    player.CurrentAnimation = 0;
            }

            // Center camera on player
            Camera.Center = player.Center;

            // Make sure the camera doesn't go off the side of the screen
            if (Camera.Y < 0)
                Camera.Y = 0;
            if (Camera.X < 0)
                Camera.X = 0;
            if (Camera.Bottom > map.Height)
                Camera.Bottom = map.Height;
            if (Camera.Right > map.Width)
                Camera.Right = map.Width;
        }
    }
}
