Attribute VB_Name = "mOpengl"
' modOpenGL: OpenGL start/stop functions and related routines.

Option Explicit

Public iFlatSmooth As Integer
Public quadSphere As GLUquadric

Public bCull, bDepth, bOutLine As GLboolean
Public xRot, yRot As GLfloat
Public bAppRunning As GLboolean

Public Type PIXELFORMATDESCRIPTOR
    nSize As Integer
    nVersion As Integer
    dwFlags As Long
    iPixelType As Byte
    cColorBits As Byte
    cRedBits As Byte
    cRedShift As Byte
    cGreenBits As Byte
    cGreenShift As Byte
    cBlueBits As Byte
    cBlueShift As Byte
    cAlphaBits As Byte
    cAlphaShift As Byte
    cAccumBits As Byte
    cAccumRedBits As Byte
    cAccumGreenBits As Byte
    cAccumBlueBits As Byte
    cAccumAlpgaBits As Byte
    cDepthBits As Byte
    cStencilBits As Byte
    cAuxBuffers As Byte
    iLayerType As Byte
    bReserved As Byte
    dwLayerMask As Long
    dwVisibleMask As Long
    dwDamageMask As Long
End Type
Public Const PFD_TYPE_RGBA = 0
Public Const PFD_TYPE_COLORINDEX = 1
Public Const PFD_MAIN_PLANE = 0
Public Const PFD_DOUBLEBUFFER = 1
Public Const PFD_DRAW_TO_WINDOW = &H4
Public Const PFD_SUPPORT_OPENGL = &H20
Public Const PFD_NEED_PALETTE = &H80
Public Declare Function ChoosePixelFormat Lib "gdi32" (ByVal hDC As Long, pfd As PIXELFORMATDESCRIPTOR) As Long
Public Declare Function CreatePalette Lib "gdi32" (pPal As LOGPALETTE) As Long
Public Declare Sub DeleteObject Lib "gdi32" (hObject As Long)
Public Declare Sub DescribePixelFormat Lib "gdi32" (ByVal hDC As Long, ByVal PixelFormat As Long, ByVal nBytes As Long, pfd As PIXELFORMATDESCRIPTOR)
Public Declare Function GetDC Lib "gdi32" (ByVal hWnd As Long) As Long
Public Declare Function GetPixelFormat Lib "gdi32" (ByVal hDC As Long) As Long
Public Declare Sub GetSystemPaletteEntries Lib "gdi32" (ByVal hDC As Long, ByVal start As Long, ByVal entries As Long, ByVal ptrEntries As Long)
Public Declare Sub RealizePalette Lib "gdi32" (ByVal hPalette As Long)
Public Declare Sub SelectPalette Lib "gdi32" (ByVal hDC As Long, ByVal hPalette As Long, ByVal bln As Long)
Public Declare Function SetPixelFormat Lib "gdi32" (ByVal hDC As Long, ByVal i As Long, pfd As PIXELFORMATDESCRIPTOR) As Boolean
Public Declare Sub SwapBuffers Lib "gdi32" (ByVal hDC As Long)
Public Declare Function wglCreateContext Lib "OpenGL32" (ByVal hDC As Long) As Long
Public Declare Sub wglDeleteContext Lib "OpenGL32" (ByVal hContext As Long)
Public Declare Sub wglMakeCurrent Lib "OpenGL32" (ByVal l1 As Long, ByVal l2 As Long)
Public hGLRC As Long

Public sRenderer As String, sVendor As String, sExtensions As String, sVersion As String

Public Sub FatalError(ByVal sMessage As String)

'Subroutine to stop the program on fatal error

    MsgBox "Fatal Error: " & sMessage, vbCritical + vbApplicationModal + vbOKOnly + vbDefaultButton1, "Fatal Error In " & App.Title
    Unload frmDisplay
    Set frmDisplay = Nothing
    End
    
End Sub

Private Sub SetupPixelFormat(ByVal lhDC As Long)

' Subroutine to set pixel format

    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim PixelFormat As Integer
    
    ' Initialize pixel format
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 16
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    
    ' Choose a pixel format that best matches that described in pfd
    PixelFormat = ChoosePixelFormat(lhDC, pfd)
    If PixelFormat = 0 Then FatalError "Could not retrieve pixel format!"
    
    ' Set the pixel format for the device context
    SetPixelFormat lhDC, PixelFormat, pfd
    
End Sub

Public Sub StartOpenGL(ByVal lTargetHDC As Long)

' Subroutine to intialize opengl window
   
    ' Select the pixel format
    SetupPixelFormat lTargetHDC
    
    ' Create the rendering context and make it current
    hGLRC = wglCreateContext(lTargetHDC)
    wglMakeCurrent lTargetHDC, hGLRC

End Sub

Public Sub StopOpenGL()

' Subroutine called when opengl window is closed
    
    ' Deselect the current rendering context and delete it
    If hGLRC <> 0 Then
        wglMakeCurrent 0, 0
        wglDeleteContext hGLRC
    End If
    
End Sub

Public Sub glRGB(R%, G%, B%)
    glColor3f R / 255, G / 255, B / 255
End Sub

Public Sub ReDraw()

' Subroutine to redraw opengl graphics
    
    glClearColor 0#, 0#, 0#, 1#
    glColor3f 0#, 1#, 0#
    glFrontFace ffCCW
    Call RenderScene
    
End Sub


