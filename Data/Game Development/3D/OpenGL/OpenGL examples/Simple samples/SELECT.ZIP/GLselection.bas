Attribute VB_Name = "Module1"
Option Explicit


Sub Selection(X As Single, Y As Single)
Dim hits As Long
Dim selectbuf(0 To 1023) As GLuint ' bufer pro ulozeni vysledku
Dim near As Long, dist As Double, itens(20) As Long ' max 20 objektu
Dim w As Long, h As Long
Dim viewport(0 To 3) As Long ' pole pro viewport (rozmery obarzovky napr 0,0,300,300)
Dim i As Integer
Dim hGLRC As Double
hGLRC = wglCreateContext(frmMain.hDC)

    '
    wglMakeCurrent frmMain.hDC, hGLRC ' ????? co to je ?? ale bez toho to nechodi
' kontrola randerovani
    glSelectBuffer 1024, selectbuf(0) 'delka buferu a jeho umisteni
    glRenderMode GL_SELECT
    glInitNames
    glPushName -1 '??? v jinych ukazkach je 0, asi prvotni name
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glGetIntegerv GL_VIEWPORT, viewport(0) 'nacteni viewportu do pole
    gluPickMatrix X, viewport(3) - Y, 0.01, 0.01, viewport(0) 'bod + velikost zaberu =0.01 x 0.01
        
    w = Me.ScaleWidth
    h = Me.ScaleHeight
    glOrtho -100, 100, -100, 100, -100, 100
    gluLookAt 10, 10, 30, -10, -10, -10, 0, 0, 1
    
        Draw (GL_SELECT)
        hits = glRenderMode(GL_RENDER)   'HERE HERE HERE
        Text1.Text = hits
        If hits = 0 Then Exit Sub
        If hits > 0 Then
            Beep
        '    ReDim itens(0 To hits - 1)
            near = 0
            dist = -1E+61 ' hodne male cislo
            For i = 1 To hits
                If (selectbuf((i - 1) * 4 + 1) > dist) Then 'pokud nejblizsi cast objektu je blize nez dist
                    dist = selectbuf((i - 1) * 4 + 1) ' dist = nejblizsi cast objektu
                    near = selectbuf((i - 1) * 4 + 3) ' near = nazev cislo objektu
                End If
            Text2.Text = selectbuf((1 - 1) * 4 + 2)
             Text3.Text = selectbuf((2 - 1) * 4 + 2)
             'Text4.Text = selectbuf((3 - 1) * 4 + 1)
            Next i
            Me.PSet (X, Y), RGB(255, 0, 0)
            Print near
        End If
End Sub
