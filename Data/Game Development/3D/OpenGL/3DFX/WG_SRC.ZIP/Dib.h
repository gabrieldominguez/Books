
//DIB Section support for WinGlide
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _DIB_
#define _DIB_

#include <windows.h>

extern BOOL CreateDIB(HWND, DWORD, DWORD);
extern VOID FreeDIB(VOID);
extern LPVOID GetDIBBuffer(VOID);
extern LONG GetDIBWidth(VOID);
extern LONG GetDIBHeight(VOID);
extern LONG GetDIBPitch(VOID);
extern VOID DrawDIB(VOID);
extern VOID DrawStretchedDIB(VOID);

#endif //_DIB_
