#if TEST
using System;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
using ICSharpCode.SharpZipLib.BZip2;
using NUnit.Framework;

namespace ICSharpCode.SharpZipLib.Zip
{
	/// <summary>
	/// This class contains test cases for the Adler32 and Crc32 checksums
	/// </summary>
	[TestFixture]
	public class BZip2Suite
	{
		[Test]
		public void TestBZip2()
		{
			MemoryStream ms = new MemoryStream();
			BZip2OutputStream outStream = new BZip2OutputStream(ms);
			
			byte[] buf = new byte[10000];
			System.Random rnd = new Random();
			rnd.NextBytes(buf);
			
			outStream.Write(buf, 0, buf.Length);
			outStream.Close();
			ms = new MemoryStream(ms.GetBuffer());
			ms.Seek(0, SeekOrigin.Begin);
			
			BZip2InputStream inStream = new BZip2InputStream(ms);
			byte[] buf2 = new byte[buf.Length];
			int    pos  = 0;
			while (true) {
				int numRead = inStream.Read(buf2, pos, 4096);
				if (numRead <= 0) {
					break;
				}
				pos += numRead;
			}
			
			for (int i = 0; i < buf.Length; ++i) {
				Assertion.AssertEquals(buf2[i], buf[i]);
			}
		}
	}
}
#endif
