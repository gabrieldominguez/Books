VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "CXXX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'----------------------------------------------------------------------------
'FUNCTION: main class which responds to the ocx
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
' * By Brian Paul,  written July 31, 1997  for Mark.
' This is ported from a sample in the GLUT distribution.
'HISTORY: -
'NOTES:
'----------------------------------------------------------------------------
Dim m_MatBlue As glxMaterial
Dim m_MatPink As glxMaterial
Dim m_MatBlack As glxMaterial
Dim m_bTexture As Boolean
Dim m_bMoving As Boolean
Dim m_Grids As Boolean
Dim m_MouseX&, m_MouseY&
Dim m_StartX&, m_StartY&

''*********************** Pony-specific code *********************************/

Dim BodyDepth!
Dim LegDepth!
Dim FrontLegPos!(0 To 2)
Dim BodyVerts(0 To 17) As POINT2F
Dim FrontLegVerts(0 To 10) As POINT2F
Dim BackLegPos!(0 To 2)
Dim BackLegVerts(0 To 9) As POINT2F
Dim ManeDepth!
Dim ManeVerts(0 To 6) As POINT2F

Dim EyePos!(0 To 2)
Dim EyeSize!
' Display lists
Dim Body&, FrontLeg&, BackLeg&, Mane&
Dim Speed!, LegAngleStep!, LegMaxAngle!
Dim LegAngle!, LegDeltaAngle!
Dim WalkAngle!, DeltaWalkAngle!
Dim WalkRadius!
Dim Xrot!, Yrot!
Dim AnimFlag As Boolean
Dim tobj&
Dim GroundList&


Private Sub Class_Initialize()
    AnimFlag = GL_TRUE
    BodyDepth = 0.216
    LegDepth = 0.144
    ManeDepth = 0.288
    EyeSize = 0.025
    Speed = 10
    LegAngleStep = 0.75
    LegMaxAngle = 15
    LegDeltaAngle = 0.5
    WalkAngle = -90
    DeltaWalkAngle = 0.225
    WalkRadius = 4
    Yrot = 30
    FillArrayf FrontLegPos, -0.36, -0.324, 0.108
    FillArrayf BackLegPos, 0.684, -0.324, 0.108
    FillArrayf EyePos, -0.702, 0.648, 0.1116
    BodyVerts(0).p(0) = -0.993334
    BodyVerts(0).p(1) = 0.344444
    BodyVerts(1).p(0) = -0.72
    BodyVerts(1).p(1) = 0.462964
    BodyVerts(2).p(0) = -0.58
    BodyVerts(2).p(1) = -0.411113
    BodyVerts(3).p(0) = -0.406667
    BodyVerts(3).p(1) = -0.692593
    BodyVerts(4).p(0) = 0.733334
    BodyVerts(4).p(1) = -0.633334
    BodyVerts(5).p(0) = 0.846666
    BodyVerts(5).p(1) = -0.225926
    BodyVerts(6).p(0) = 0.873335
    BodyVerts(6).p(1) = -0.55926
    BodyVerts(7).p(0) = 0.879998
    BodyVerts(7).p(1) = -0.988888
    BodyVerts(8).p(0) = 0.933332
    BodyVerts(8).p(1) = -0.974074
    BodyVerts(9).p(0) = 0.953334
    BodyVerts(9).p(1) = -0.537037
    BodyVerts(10).p(0) = 0.906667
    BodyVerts(10).p(1) = -0.0777776
    BodyVerts(11).p(0) = 0.806666
    BodyVerts(11).p(1) = 0.0333334
    BodyVerts(12).p(0) = -0.26
    BodyVerts(12).p(1) = 0.0111111
    BodyVerts(13).p(0) = -0.406667
    BodyVerts(13).p(1) = 0.27037
    BodyVerts(14).p(0) = -0.54
    BodyVerts(14).p(1) = 0.781481
    BodyVerts(15).p(0) = -0.673333
    BodyVerts(15).p(1) = 1.00371
    BodyVerts(16).p(0) = -0.653332
    BodyVerts(16).p(1) = 0.803704
    BodyVerts(17).p(0) = -1.05333
    BodyVerts(17).p(1) = 0.44815
    FrontLegVerts(0).p(0) = -0.23
    FrontLegVerts(0).p(1) = -0.113481
    FrontLegVerts(1).p(0) = -0.123333
    FrontLegVerts(1).p(1) = -0.528296
    FrontLegVerts(2).p(0) = -0.0926752
    FrontLegVerts(2).p(1) = -0.728103
    FrontLegVerts(3).p(0) = -0.0766667
    FrontLegVerts(3).p(1) = -1.232
    FrontLegVerts(4).p(0) = 0.0233333
    FrontLegVerts(4).p(1) = -1.232
    FrontLegVerts(5).p(0) = 0.0433332
    FrontLegVerts(5).p(1) = -0.743111
    FrontLegVerts(6).p(0) = 0.0366667
    FrontLegVerts(6).p(1) = -0.424593
    FrontLegVerts(7).p(0) = 0.0699998
    FrontLegVerts(7).p(1) = -0.157926
    FrontLegVerts(8).p(0) = 0.116667
    FrontLegVerts(8).p(1) = 0.049482
    FrontLegVerts(9).p(0) = -0.0166667
    FrontLegVerts(9).p(1) = 0.197629
    FrontLegVerts(10).p(0) = -0.196667
    FrontLegVerts(10).p(1) = 0.13837
    BackLegVerts(0).p(0) = -0.24
    BackLegVerts(0).p(1) = -0.195556
    BackLegVerts(1).p(0) = -0.0933332
    BackLegVerts(1).p(1) = -0.41037
    BackLegVerts(2).p(0) = -0.04
    BackLegVerts(2).p(1) = -0.684445
    BackLegVerts(3).p(0) = -0.113333
    BackLegVerts(3).p(1) = -1.26222
    BackLegVerts(4).p(0) = 0
    BackLegVerts(4).p(1) = -1.26222
    BackLegVerts(5).p(0) = 0.1
    BackLegVerts(5).p(1) = -0.677037
    BackLegVerts(6).p(0) = 0.213333
    BackLegVerts(6).p(1) = -0.121482
    BackLegVerts(7).p(0) = 0.153333
    BackLegVerts(7).p(1) = 0.108148
    BackLegVerts(8).p(0) = -0.0533333
    BackLegVerts(8).p(1) = 0.211853
    BackLegVerts(9).p(0) = -0.26
    BackLegVerts(9).p(1) = 0.063702
    ManeVerts(0).p(0) = -0.512667
    ManeVerts(0).p(1) = 0.578519
    ManeVerts(1).p(0) = -0.419333
    ManeVerts(1).p(1) = 0.267407
    ManeVerts(2).p(0) = -0.299333
    ManeVerts(2).p(1) = -0.00666719
    ManeVerts(3).p(0) = -0.239333
    ManeVerts(3).p(1) = -0.0140724
    ManeVerts(4).p(0) = -0.226
    ManeVerts(4).p(1) = 0.0896296
    ManeVerts(5).p(0) = -0.319333
    ManeVerts(5).p(1) = 0.422963
    ManeVerts(6).p(0) = -0.532667
    ManeVerts(6).p(1) = 0.741481
End Sub

Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    glClearColor 0.3, 0.3, 0.3, 0
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1
        .SetPosition 1, 10, 10
        .Enabled = True
    End With
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.1
        .FieldOfView = 45
        .SetEyePos 0, 1, -10
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_MatBlue = gCtl.NewMaterial
    With m_MatBlue
        .face = faceFront
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 0.1, 0.1, 1
        .SetSpecular 0.6, 0.8, 0.8
        .SpecExp = 120
    End With
    Set m_MatBlack = gCtl.Materials.GetMaterialIndex(BLACK_PLASTIC)
    Set m_MatPink = gCtl.NewMaterial
    With m_MatPink
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 0.5, 0.5
        .SetSpecular 0.6, 0.8, 0.8
        .SpecExp = 120
    End With
    
    With gCtl
        .MouseRotate = True
        .Trackball.Animate = False
        .Grid = glxGridX
        .Axis = glxXYZ
        .Pick = True
    End With
    'm_Grids = True
    glClearColor 0.5, 0.8, 0.99, 1
    glEnable GL_NORMALIZE
    glShadeModel GL_FLAT
    'LoadRGBMipmaps "logo.bw", 1
    tobj = gluNewTess  ' create and initialize a GLU polygon tesselation object
    gluTessCallback tobj, GLU_BEGIN, AddressOf glBeginCB
    gluTessCallback tobj, GLU_VERTEX, AddressOf glVertex2fvCB
    gluTessCallback tobj, GLU_END, AddressOf glEndCB
    '
    MakeGround
    MakePony
    gCtl.Animate = AnimFlag
End Sub

Sub MakeGround()
Dim x!, z!, i&, j&
Dim rows&, columns&
Dim sizeA!, sizeB!, size!
Dim mat!(0 To 7)
    rows = 20: columns = 20
    sizeA = 1.25: sizeB = 0.2
    mat(1) = 0.6
    mat(3) = 1
    mat(4) = 0.1
    mat(5) = 0.8
    mat(6) = 0.1
    mat(7) = 1
    GroundList = glGenLists(1)
    glNewList GroundList, GL_COMPILE
        glNormal3f 0, 1, 0
        x = -(columns * (sizeA + sizeB)) / 4
        For i = 0 To rows
            size = IIf(i And 1, sizeA, sizeB)
            z = -(rows * (sizeA + sizeB)) / 4
            glBegin GL_QUAD_STRIP
            For j = 0 To columns
                ' glMaterialfv GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat((i+j)%2) */
                glColor4fv mat((i + j) Mod 2)
                glVertex3f x + size, 0, z
                glVertex3f x, 0, z
                If (j And 1) Then
                  z = z + sizeA
                Else
                  z = z + sizeB
                End If
            Next
            glEnd
            x = x + size
        Next
    glEndList
End Sub

' Build the four display lists which make up the pony.
Sub MakePony()
    Body = glGenLists(1)
    glNewList Body, GL_COMPILE
    m_MatBlue.SetMaterial
    ExtrudePart 18, BodyVerts, BodyDepth

    ' eyes
    m_MatBlack.SetMaterial
    glNormal3f 0, 0, 1
    glBegin GL_POLYGON
        glVertex3f EyePos(0) - EyeSize, EyePos(1) - EyeSize, EyePos(2)
        glVertex3f EyePos(0) + EyeSize, EyePos(1) - EyeSize, EyePos(2)
        glVertex3f EyePos(0) + EyeSize, EyePos(1) + EyeSize, EyePos(2)
        glVertex3f EyePos(0) - EyeSize, EyePos(1) + EyeSize, EyePos(2)
    glEnd
    glNormal3f 0, 0, -1
    glBegin GL_POLYGON
        glVertex3f EyePos(0) - EyeSize, EyePos(1) + EyeSize, -EyePos(2)
        glVertex3f EyePos(0) + EyeSize, EyePos(1) + EyeSize, -EyePos(2)
        glVertex3f EyePos(0) + EyeSize, EyePos(1) - EyeSize, -EyePos(2)
        glVertex3f EyePos(0) - EyeSize, EyePos(1) - EyeSize, -EyePos(2)
    glEnd
    glEndList

    Mane = glGenLists(1)
    glNewList Mane, GL_COMPILE
        m_MatPink.SetMaterial
        ExtrudePart 7, ManeVerts, ManeDepth
    glEndList
    
    FrontLeg = glGenLists(1)
    glNewList FrontLeg, GL_COMPILE
        m_MatBlue.SetMaterial
        ExtrudePart 11, FrontLegVerts, LegDepth
    glEndList
    
    BackLeg = glGenLists(1)
    glNewList BackLeg, GL_COMPILE
        m_MatBlue.SetMaterial
        ExtrudePart 10, BackLegVerts, LegDepth
    glEndList
End Sub


Sub Idle()
    ' update animation vars
    LegAngle = LegAngle + LegDeltaAngle * Speed
    If LegAngle > LegMaxAngle Then
      LegDeltaAngle = -LegAngleStep
    ElseIf (LegAngle < -LegMaxAngle) Then
      LegDeltaAngle = LegAngleStep
    End If
    WalkAngle = WalkAngle + DeltaWalkAngle * Speed
End Sub

Public Sub Draw()
Dim xPos!, zPos!
    With gCtl
        .Trackball.Update
        If m_Grids Then .DrawGrids
    End With
    ' viewing
    glPushMatrix
        glRotatef Xrot, 1, 0, 0
        glRotatef Yrot, 0, 1, 0
        ' ground
        glDisable GL_LIGHTING
        glPushMatrix
            glTranslatef 0, -1.6, 0
            glCallList GroundList
        glPopMatrix
        ' logo
        glPushMatrix
            glScalef 2.5, 2.5, 2.5
            DrawLogo
        glPopMatrix
        ' pony
        xPos = WalkRadius * Cos(WalkAngle * PI / 180)
        zPos = WalkRadius * Sin(WalkAngle * PI / 180)
        glEnable GL_LIGHTING
        glPushMatrix
            glTranslatef xPos, 0, zPos
            glRotatef -WalkAngle + 90, 0, 1, 0
            DrawPony LegAngle
        glPopMatrix
    glPopMatrix
    If AnimFlag Then Idle
    CheckError
End Sub

' Draw the pony.  legAngle should be in (-15,15) or so.
' The pony display lists will be constructed the first time this is called.
Sub DrawPony(LegAngle!)
  ' BODY */
  glCallList Body

  ' MANE */
  glCallList Mane
  ' FRONT +Z LEG */
  glPushMatrix
  glTranslatef FrontLegPos(0), FrontLegPos(1), FrontLegPos(2)
  glRotatef LegAngle, 0, 0, 1
  glCallList FrontLeg
  glPopMatrix
  ' FRONT -Z LEG */
  glPushMatrix
  glTranslatef FrontLegPos(0), FrontLegPos(1), -FrontLegPos(2)
  glRotatef -LegAngle, 0, 0, 1
  glCallList FrontLeg
  glPopMatrix
  ' BACK +Z LEG */
  glPushMatrix
  glTranslatef BackLegPos(0), BackLegPos(1), BackLegPos(2)
  glRotatef -LegAngle, 0, 0, 1
  glCallList BackLeg
  glPopMatrix
  ' BACK -Z LEG */
  glPushMatrix
  glTranslatef BackLegPos(0), BackLegPos(1), -BackLegPos(2)
  glRotatef LegAngle, 0, 0, 1
  glCallList BackLeg
  glPopMatrix
End Sub

Sub DrawLogo()
    glEnable GL_TEXTURE_2D
    glShadeModel GL_SMOOTH
    glBegin GL_POLYGON
        glColor3f 1, 0, 0
        glTexCoord2f 0, 0
        glVertex2f -1, -0.5
        glColor3f 0, 1, 0
        glTexCoord2f 1, 0
        glVertex2f 1, -0.5
        glColor3f 0, 0, 1
        glTexCoord2f 1, 1
        glVertex2f 1, 0.5
        glColor3f 1, 1, 0
        glTexCoord2f 0, 1
        glVertex2f -1, 0.5
    glEnd
    glDisable GL_TEXTURE_2D
    glShadeModel GL_FLAT
End Sub

Public Function Reshape(width&, height&) As Boolean
    Reshape = True
End Function

Public Sub KeyDown(KeyCode%, Shift%)
Const step = 2
    Select Case (KeyCode)
    Case vbKeyLeft: Yrot = Yrot - step
    Case vbKeyRight: Yrot = Yrot + step
    Case vbKeyUp: Xrot = Xrot + step
    Case vbKeyDown: Xrot = Xrot - step
    Case 27:   Unload frmMain
    Case Else: Exit Sub
    End Select
    gCtl.Render
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$
    s = Chr$(KeyAscii)
    Select Case (s)
    Case " "
        AnimFlag = Not AnimFlag
        gCtl.Animate = AnimFlag
    End Select
    gCtl.Render
End Sub

Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 1 Then
        m_bMoving = True
        m_StartX = x
        m_StartY = y
    Else
    End If
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    If Button = 0 Then
        Exit Sub
    ElseIf Button = 1 Then
        If m_bMoving Then
        End If
        gCtl.Render
    ElseIf Button = 2 Then
        gCtl.Render
    End If
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
      m_bMoving = False
End Sub

Public Sub Pick(items() As Long)
Dim Name&, ptr&, i&, j&, cnt&, n&
Dim Picked&, z#, z1#, z2#
    'bug: ocx returns right clicks
    If Not m_bMoving Then Exit Sub
    z = FLOAT_MAX ' a big number, limit of the data type
    Debug.Print "/////////////////////////////////////"
    cnt = gCtl.Hits
    Debug.Print "Count:" & cnt
    If cnt Then
        For i = 1 To cnt
            'Debug.Print "Name " & i & ":"
            '1.number of names on stack
                n = items(ptr)
                Debug.Print " number of names = " & n
                ptr = ptr + 1
            '2.z1
                z1 = ULong(items(ptr))
                Debug.Print " z1 = " & z1
                ptr = ptr + 1
            '3.z2
                z2 = ULong(items(ptr))
                Debug.Print " z2 = " & z2
                ptr = ptr + 1
            '4.names
            For j = 1 To n
                Debug.Print "    name " & (j) & " = " & items(ptr)
                If items(ptr) <> -1 Then
                    'get the lowest z-value, nearest node
                    If z1 < z Then
                        z = z1
                        Picked = items(ptr)
                    End If
                End If
                ptr = ptr + 1
            Next
        Next
    Else
        Exit Sub
    End If
    Debug.Print "Selected: " & Picked
    If Picked > 0 Then
        'gCtl.Render
    End If
End Sub

' Generate an extruded, capped part from a 2-D polyline.
Private Sub ExtrudePart(n&, v() As POINT2F, depth!)
Dim vertex() As POINT3D
Dim i&, x!, y!, dx!, dy!
Dim z0!, z1!
    z0 = 0.5 * depth
    z1 = -0.5 * depth
    ReDim vertex(0 To n - 1)
    
    ' +Z face
    glPushMatrix
        glTranslatef 0, 0, z0
        glNormal3f 0, 0, 1
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To n - 1
                vertex(i).p(0) = v(i).p(0)
                vertex(i).p(1) = v(i).p(1)
                vertex(i).p(2) = 0
                gluTessVertex tobj, vertex(i).p(0), v(i).p(0)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glPopMatrix

    ' -Z face
    glFrontFace GL_CW
    glPushMatrix
        glTranslatef 0, 0, z1
        glNormal3f 0, 0, -1
        gluTessBeginPolygon tobj, 0&
            gluTessBeginContour tobj
            For i = 0 To n - 1
                vertex(i).p(0) = v(i).p(0)
                vertex(i).p(1) = v(i).p(1)
                vertex(i).p(2) = z1
                gluTessVertex tobj, vertex(i).p(0), v(i).p(0)
            Next
            gluTessEndContour tobj
        gluTessEndPolygon tobj
    glPopMatrix
    glFrontFace GL_CCW
    ' edge polygons
    glBegin GL_TRIANGLE_STRIP
    For i = 0 To n
        x = v(i Mod n).p(0)
        y = v(i Mod n).p(1)
        dx = v((i + 1) Mod n).p(0) - x
        dy = v((i + 1) Mod n).p(1) - y
        glVertex3f x, y, z0
        glVertex3f x, y, z1
        glNormal3f dy, -dx, 0
    Next
  glEnd

End Sub




