VERSION 5.00
Begin VB.Form dlgFont 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Font"
   ClientHeight    =   1965
   ClientLeft      =   8295
   ClientTop       =   2580
   ClientWidth     =   4395
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1965
   ScaleWidth      =   4395
   ShowInTaskbar   =   0   'False
   Begin VB.TextBox txtScale 
      Height          =   315
      Index           =   0
      Left            =   1020
      TabIndex        =   7
      Top             =   1080
      Width           =   555
   End
   Begin VB.TextBox txtScale 
      Height          =   315
      Index           =   1
      Left            =   1620
      TabIndex        =   6
      Top             =   1080
      Width           =   555
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   3390
      TabIndex        =   5
      Top             =   120
      Width           =   975
   End
   Begin VB.ComboBox cmbFont 
      Height          =   315
      Left            =   1020
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   300
      Width           =   1755
   End
   Begin VB.CommandButton btnColor 
      Height          =   315
      Left            =   2430
      TabIndex        =   0
      Top             =   690
      Width           =   300
   End
   Begin VB.Label lblPos 
      Caption         =   "Scale:"
      Height          =   195
      Index           =   3
      Left            =   450
      TabIndex        =   8
      Top             =   1140
      Width           =   465
   End
   Begin VB.Label lblFont 
      Caption         =   "Font:"
      Height          =   255
      Left            =   480
      TabIndex        =   4
      Top             =   360
      Width           =   585
   End
   Begin VB.Label Label1 
      Caption         =   "Color:"
      Height          =   255
      Left            =   480
      TabIndex        =   3
      Top             =   750
      Width           =   405
   End
   Begin VB.Label lblFontColor 
      BorderStyle     =   1  'Fixed Single
      Height          =   315
      Left            =   1020
      TabIndex        =   2
      Top             =   690
      Width           =   1305
   End
End
Attribute VB_Name = "dlgFont"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim CD As CommonDialog
Dim Loading As Boolean
Dim a As CArea

Private Sub Command1_Click()
    dlgFontX = Left
    dlgFontY = Top
    Unload Me
End Sub

Private Sub btnColor_Click()
On Error Resume Next
    CD.flags = cdlCCRGBInit
    CD.Color = lblFontColor.BackColor
    CD.ShowColor
    If Error Then Exit Sub
    Debug.Print CD.Color
    a.FontColor = CD.Color
    lblFontColor.BackColor = CD.Color
    gCtl.Render
End Sub

Private Sub cmbFont_Click()
    If Not Loading Then
        a.Font = cmbFont.Text
        gCtl.Render
    End If
End Sub

Private Sub txtScale_Change(Index As Integer)
    If Not Loading Then
        Select Case Index
        Case 0: a.sx = Val(txtScale(0).Text)
        Case 1: a.sy = Val(txtScale(1).Text)
        End Select
        gCtl.Render
    End If
End Sub


Private Sub Form_Load()
Dim s$, n&
    Set CD = frmMain.CD
    s = Dir(App.Path & "\fonts\" & "*.ftx")
    Do While Len(s)
        n = InStr(s, ".")
        s = Left$(s, n - 1)
        cmbFont.AddItem s
        s = Dir
    Loop
End Sub

Public Property Let Area(ByVal Selection As CArea)
Dim s$, i&
    Loading = True
    Set a = Selection
    With cmbFont
        s = a.Font
        For i = 1 To .ListCount
            If .List(i - 1) = s Then
                .ListIndex = i - 1
                Exit For
            End If
        Next
        If i > .ListCount Then .ListIndex = -1
    End With
    lblFontColor.BackColor = a.FontColor
    txtScale(0) = a.sx
    txtScale(1) = a.sy
    Loading = False
End Property

