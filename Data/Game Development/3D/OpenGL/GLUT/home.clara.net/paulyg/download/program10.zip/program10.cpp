/*
      Program 10.
      
      Vertex arrays and (hardware) multitexturing.
      The first program to utilise extensions on my 
      new graphics card (woohoo!)
*/

#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>

#include "program10.h"
#include "tgaload.h"

/*      Some macros for naming the textures */
#define         MAX_TEXTURES    2

#define         WOOD_IMAGE      0
#define         LIGHTMAP        1

PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB = NULL;
PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB     = NULL;

float    angle;

/* Vertex Array object description:
   These arrays contain the vertex data, indices for the vertices, and texture
   coordinates for each vertex.  */
GLfloat vertices[] =  { -1.0,  1.0,  0.0,
                         1.0,  1.0,  0.0,
                         1.0, -1.0,  0.0,
                        -1.0, -1.0,  0.0 };

GLfloat tex_coords[] = { 0.0, 1.0,
                         1.0, 1.0,
                         1.0, 0.0,
                         0.0, 0.0 };

GLuint  indices[] = { 0, 1, 2, 3 };

/*  Array to hold our texture IDs   */
GLuint  tex_id[MAX_TEXTURES];


void get_extensions ( void )
{
   printf( "Vendor     : %s\n",   glGetString ( GL_VENDOR     ));   
   printf( "OGL Driver : %s\n\n", glGetString ( GL_VERSION    ));   
   printf( "Extensions: %s\n\n",    glGetString ( GL_EXTENSIONS ));        
   
   if ( glutExtensionSupported ( "GL_ARB_multitexture" ))
   {
	   glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )	
	     wglGetProcAddress  ( "glActiveTextureARB" );
		
		glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )
		  wglGetProcAddress        ( "glClientActiveTextureARB" );		  		 				     
   } else {
      printf ("GL_ARB_multitexture not found\nThis program _requires_ multitexturing.");
      exit ( 0 );
   }
}


void init( void )
{    
   get_extensions ( );

   glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
   glGenTextures ( 2, tex_id );

   tex_id[WOOD_IMAGE] = tgaLoadAndBind ( "board.tga", TGA_DEFAULT );   
   tex_id[LIGHTMAP]   = tgaLoadAndBind ( "lightmap.tga", TGA_FREE | TGA_LUMINANCE );      

   glEnable ( GL_DEPTH_TEST );
   glEnableClientState ( GL_VERTEX_ARRAY );
   
   // Enable texcoordinate array client state for each texture unit
   glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
   glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
   glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
   glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
   glActiveTextureARB ( GL_TEXTURE0_ARB );   
   glEnable           ( GL_TEXTURE_2D   );     

   glActiveTextureARB ( GL_TEXTURE1_ARB );   
   glEnable           ( GL_TEXTURE_2D   );     
   
   glClearColor ( 0.0, 0.0, 0.0, 0.0 );
}


void set_and_draw ( void )
{
   glVertexPointer   ( 3, GL_FLOAT, 0, &vertices );

   glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
   glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
   glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
   glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

   glActiveTextureARB ( GL_TEXTURE0_ARB ); 
   glBindTexture      ( GL_TEXTURE_2D, tex_id[WOOD_IMAGE] ); 
   glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

   glActiveTextureARB ( GL_TEXTURE1_ARB ); 
   glBindTexture      ( GL_TEXTURE_2D, tex_id[LIGHTMAP] ); 
   glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

   glDrawElements ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
}


void display ( void )
{
   glClear    ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   glLoadIdentity ( );
   glTranslatef   ( 0.0, 0.0, -3.0 );
   glRotatef      ( angle, 1.0, 1.0, 0.0 );

   set_and_draw ( );
   
   glutSwapBuffers ( );   
}

void reshape ( int w, int h )
{
   glViewport   ( 0, 0, ( GLint ) w, ( GLint ) h );
   glMatrixMode ( GL_PROJECTION );
   glLoadIdentity ( );
   if ( h==0 )
      gluPerspective ( 45, ( GLdouble ) w, 1.0, 20.0 );
   else
      gluPerspective ( 45, ( GLdouble ) w / ( GLdouble ) h ,1.0, 10.0 );
   glMatrixMode   ( GL_MODELVIEW );
   glLoadIdentity ( );
}

void idle_func ( void )
{
   angle = angle + 0.1;
   if ( angle == 360 )
      angle = 0;
   glutPostRedisplay ( );
}

/*  Main Loop
 *  Open window with initial window size, title bar,
 *  RGB display mode, and handle input events.
 */
int main ( int argc, char **argv )
{
   glutInit ( &argc, argv );
   glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );
   glutInitWindowSize  ( 250, 250 );
   glutCreateWindow ( argv[0] );
   glutReshapeFunc ( reshape   );
   glutDisplayFunc ( display   );
   glutIdleFunc    ( idle_func );
   init ( );
   glutMainLoop    ( );
   return 0;
}
