VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CArcBall"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Event OnAxisSetChanged(Axis As AxisSets)
Event OnAxisChanged(Axis As Long) 'AxisConstants)
'----------------------------------------------------------------
Const LG_NSEGS = 4
Const NSEGS = 8 '(1<<LG_NSEGS)
Const M_PI = 3.14159265358979
'**** Ball.c ****
' Ken Shoemake, 1993
'----------------------------------------------------------------
'**** BallAux.h - Vector and quaternion routines for Arcball. ****
Private Type Quat
    x As Single
    y As Single
    Z As Single
    W As Single
End Type
'Public Enum QuatPart
'    x = 0
'    y = 1
'    z = 2
'    w = 3
'    QuatLen = 4
'End Enum
Private Type HVect
    x As Single
    y As Single
    Z As Single
    W As Single
End Type
Private Type HMatrix
    v(0 To 15) As Single
End Type
'Public Enum AxisConstants
'    XAxis = 0
'    YAxis = 1
'    ZAxis = 2
'    AllAxes = 3
'End Enum
Public Enum AxisSets
    NoAxes = 0
    CameraAxes = 1
    BodyAxes = 2
    OtherAxes = 3
    NSets = 4
End Enum
'typedef float *ConstraintSet;
Private Type BallData
    Center As HVect
    Radius As Double
    qNow As Quat
    qDown As Quat
    qDrag As Quat
    vNow As HVect
    vDown As HVect
    vFrom As HVect
    vTo As HVect
    vrFrom As HVect
    vrTo As HVect
    mNow As HMatrix
    mDown As HMatrix
    ShowResult As Boolean
    Dragging As Boolean
    'sets(0 To 3) As Single 'NSets);ConstraintSet
    setSizes(0 To 3) As Long
    AxisSet As AxisSets
    AxisIndex As Long
    'Axis As AxisConstants
End Type
'----------------------------------------------------------------
Dim qOne As Quat
Dim otherAxis!(0 To 3)
Dim mId As HMatrix
Dim Ball As BallData
'enum QuatPart {X, Y, Z, W};

'----------------------------------------------------------------
' Establish reasonable initial values for controller.
Private Sub Class_Initialize()
Dim i&
    qOne.W = 1 ' = {0, 0, 0, 1};
    '
    FillArrayf mId.v, 1, 0, 0, 0, _
                      0, 1, 0, 0, _
                      0, 0, 1, 0, _
                      0, 0, 0, 1
    FillArrayf otherAxis, -0.48, 0.8, 0.36, 1
    '
    'defaults
    Ball.Radius = 1
    Ball.Center.W = 1 ' qOne : 0,0,0,1
    Ball.vDown.W = 1 'qOne
    Ball.vNow.W = 1 'qOne
    Ball.qDown.W = 1 'qOne
    Ball.qNow.W = 1 ' qOne
    For i = 0 To 15
        Ball.mNow.v(i) = mId.v(i)
        Ball.mDown.v(i) = mId.v(i)
    Next
    'ball.showResult = True ' False
    'Ball.dragging = False
    Ball.AxisSet = NoAxes
    Ball.AxisIndex = 3
    '1
    'ball.sets(CameraAxes) = mId.v(x)
    Ball.setSizes(CameraAxes) = 3
    '2
    'ball.sets(BodyAxes) = ball.mDown.v(x)
    Ball.setSizes(BodyAxes) = 3
    '3
    'ball.sets(OtherAxes) = otherAxis(x)
    Ball.setSizes(OtherAxes) = 1
    '
    End Sub

Private Sub Class_Terminate()
'
End Sub


'----------------------------------------------------------------
'Sets the size of the controller
Public Property Get Radius#()
    Radius = Ball.Radius
End Property

'----------------------------------------------------------------
'Returns the size of the controller
Public Property Let Radius(ByVal NewValue#)
    Ball.Radius = Radius
End Property

'----------------------------------------------------------------
'Sets the center of the controller.
Public Sub SetCenter(x!, y!, Z!, Optional W! = 1)
    Ball.Center.x = x
    Ball.Center.y = y
    Ball.Center.Z = Z
    Ball.Center.W = W
End Sub

'----------------------------------------------------------------
'Returns the center of the controller.
Public Sub GetCenter(x!, y!, Z!)
    x = Ball.Center.x
    y = Ball.Center.y
    Z = Ball.Center.Z
End Sub

'----------------------------------------------------------------
'Choose an active axis, or none.
Public Property Let Axis(NewAxis&) ' As AxisConstants)
    Select Case NewAxis
    Case NAME_XAXIS, NAME_XBOX
        Ball.AxisSet = BodyAxes
        Ball.AxisIndex = 0
    Case NAME_YAXIS, NAME_YBOX
        Ball.AxisSet = BodyAxes
        Ball.AxisIndex = 1
    Case NAME_ZAXIS, NAME_ZBOX
        Ball.AxisSet = BodyAxes
        Ball.AxisIndex = 2
    Case NAME_CENTERBOX
        Ball.AxisSet = NoAxes
        Ball.AxisIndex = 3
    End Select
    RaiseEvent OnAxisChanged(Ball.AxisIndex)
End Property

Public Property Get Axis() As Long 'AxisConstants
    Axis = Ball.AxisIndex
End Property

'----------------------------------------------------------------
'Choose a constraint set, or none.
Public Property Let AxisSet(NewAxisSet As AxisSets)
    If Not Ball.Dragging Then
        Ball.AxisSet = NewAxisSet
        RaiseEvent OnAxisSetChanged(Ball.AxisSet)
    End If
End Property

Public Property Get AxisSet() As AxisSets
    AxisSet = Ball.AxisSet
End Property

'----------------------------------------------------------------
' Begin or stop drawing arc for all drags combined.
Public Property Let ShowResult(NewValue As Boolean)
    Ball.ShowResult = NewValue
End Property

'----------------------------------------------------------------
Public Property Get ShowResult() As Boolean
    ShowResult = Ball.ShowResult
End Property

'----------------------------------------------------------------
' Using vDown, vNow, dragging, and axisSet, compute rotation etc.
Public Sub Update()
Dim i&, setSize&, setIdx& ' As HVect
    setSize& = Ball.setSizes(Ball.AxisSet)
    '
    setIdx = Ball.AxisSet 'ball.sets(ball.axisSet)
    '
    Ball.vFrom = m_MouseOnSphere(Ball.vDown)
    Ball.vTo = m_MouseOnSphere(Ball.vNow)
    '
    If (Ball.Dragging) Then
        'If (Ball.AxisSet <> NoAxes) Then
            Debug.Print "Axis:" & Ball.AxisIndex
            Ball.vFrom = m_ConstrainToAxis(Ball.vFrom, m_GetHVectorSet(setIdx, Ball.AxisIndex))
            Ball.vTo = m_ConstrainToAxis(Ball.vTo, m_GetHVectorSet(setIdx, Ball.AxisIndex))
        'End If
        Ball.qDrag = Qt_FromBallPoints(Ball.vFrom, Ball.vTo)
        Ball.qNow = Qt_Mul(Ball.qDrag, Ball.qDown)
    Else
        If (Ball.AxisSet <> NoAxes) Then
            Ball.AxisIndex = m_NearestConstraintAxis(Ball.vTo, setIdx, setSize)
        End If
    End If
    Qt_ToBallPoints Ball.qDown, Ball.vrFrom, Ball.vrTo
    Qt_ToMatrix Qt_Conj(Ball.qNow), Ball.mNow ' Gives transpose for GL.
End Sub

'----------------------------------------------------------------
'    ball.sets(CameraAxes) = mId.v(x)
'    ball.sets(BodyAxes) = ball.mDown.v(x)
'    ball.sets(OtherAxes) = otherAxis(x)
Private Function m_GetHVectorSet(setIdx&, axisIdx&) As HVect
Dim hv As HVect
    Select Case setIdx
    Case NoAxes ' = 0
    Case CameraAxes '= 1
        hv.x = mId.v(axisIdx * 4)
        hv.y = mId.v(axisIdx * 4 + 1)
        hv.Z = mId.v(axisIdx * 4 + 2)
        hv.W = mId.v(axisIdx * 4 + 3)
    Case BodyAxes '= 2
        hv.x = Ball.mDown.v(axisIdx * 4)
        hv.y = Ball.mDown.v(axisIdx * 4 + 1)
        hv.Z = Ball.mDown.v(axisIdx * 4 + 2)
        hv.W = Ball.mDown.v(axisIdx * 4 + 3)
    Case OtherAxes '= 3
        hv.x = otherAxis(0)
        hv.y = otherAxis(1)
        hv.Z = otherAxis(2)
        hv.W = otherAxis(3)
    End Select
    m_GetHVectorSet = hv
End Function

'----------------------------------------------------------------
' Force sphere point to be perpendicular to axis.
Private Function m_ConstrainToAxis(loose As HVect, Axis As HVect) As HVect
Dim onPlane As HVect
Dim norm!
    onPlane = V3_Sub(loose, V3_Scale(Axis, V3_Dot(Axis, loose)))
    norm = V3_Norm(onPlane)
    If (norm > 0) Then
        If (onPlane.Z < 0) Then onPlane = V3_Negate(onPlane)
        m_ConstrainToAxis = V3_Scale(onPlane, 1 / Sqr(norm))
        Exit Function
    End If
    ' else drop through
    If (Axis.Z = 1) Then
        onPlane = V3_(1, 0, 0)
    Else
        onPlane = V3_Unit(V3_(-Axis.y, Axis.x, 0))
    End If
    m_ConstrainToAxis = onPlane
End Function

'----------------------------------------------------------------
' Find the index of nearest arc of axis set.
Private Function m_NearestConstraintAxis(loose As HVect, setIdx&, nAxes&) ' axes As HVect, nAxes&)
Dim onPlane As HVect
Dim max!, dot!, i&, nearest&
    max = -1
    nearest = 0
        For i = 0 To nAxes - 1
            onPlane = m_ConstrainToAxis(loose, m_GetHVectorSet(setIdx, i))
            dot = V3_Dot(onPlane, loose)
            If (dot > max) Then
                max = dot
                nearest = i
            End If
        Next
    m_NearestConstraintAxis = nearest
End Function


'----------------------------------------------------------------
' Return rotation matrix defined by controller use.
Public Sub GetValue(v16!())
Dim i&
    For i = 0 To 15
    v16(i) = Ball.mNow.v(i)
    Next
End Sub

'----------------------------------------------------------------
' Begin drag sequence.
Public Sub MouseDown(x!, y!)
    Ball.vNow.x = x
    Ball.vNow.y = y
    Ball.vDown = Ball.vNow
    Update
    Ball.Dragging = True
End Sub

'----------------------------------------------------------------
' Incorporate new mouse position.
Public Sub MouseMove(x!, y!)
    Ball.vNow.x = x
    Ball.vNow.y = y
    Update
End Sub

'----------------------------------------------------------------
' Stop drag sequence.
Public Sub MouseUp()
Dim i&
    Ball.Dragging = False
    Ball.qDown = Ball.qNow
    For i = 0 To 15
        Ball.mDown.v(i) = Ball.mNow.v(i)
    Next
End Sub


'----------------------------------------------------------------
' Draw the controller with all its arcs.
Public Sub Draw()
Dim r!
    r = Ball.Radius
    glPushMatrix
        glPushAttrib amAllAttribBits
        glPolygonMode faceFrontAndBack, pgmFILL
        glEnable GL_LIGHTING
        glEnable GL_CULL_FACE
        glPushName NAME_CENTERBOX
            If Ball.AxisSet = NoAxes Then
                glColor3f 1, 0.6, 0.6
            Else
                glColor3f 0.6, 0.6, 0.6
            End If
            gCtl.Shapes.Sphere 0.1
        glPopName
        '
        glPushName NAME_ZAXIS
            If Ball.AxisIndex = 2 Then
                glColor3f 1, 0.6, 0.6
            Else
                glColor3f 0.6, 0.6, 0.6
            End If
            m_Doughnut 0.02, 0.9, 8, 32
        glPopName
        '
        glPushMatrix
        glPushName NAME_YAXIS
            If Ball.AxisIndex = 1 Then
                glColor3f 1, 0.6, 0.6
            Else
                glColor3f 0.6, 0.6, 0.6
            End If
            glRotatef 90, 1, 0, 0
            m_Doughnut 0.02, 0.9, 8, 32
        glPopName
        glPopMatrix
        '
        glPushMatrix
        glPushName NAME_XAXIS
            If Ball.AxisIndex = 0 Then
                glColor3f 1, 0.6, 0.6
            Else
                glColor3f 0.6, 0.6, 0.6
            End If
            glRotatef 90, 0, 1, 0
            m_Doughnut 0.02, 0.9, 8, 32
        glPopName
        glPopMatrix
        glPopAttrib
        glLoadMatrixf mId.v(0)
        'glOrtho -1, 1, -1, 1, 0.1, 100000
        glColor3b 255, 255, 255
        glScalef r, r, r
        'circ 0, 0, 1
        'glPushAttrib amPolygonBit
        If Ball.ShowResult Then m_DrawResultArc
        'm_DrawConstraints
        'm_DrawDragArc
    glPopMatrix
End Sub

'----------------------------------------------------------------
' Draw an arc defined by its ends.
'called by m_DrawDragArc,m_DrawHalfArc,m_DrawResultArc
Private Sub m_DrawAnyArc(vFrom As HVect, vTo As HVect)
Dim i&, pts(0 To NSEGS) As HVect, dot! '
    pts(0) = vFrom
    pts(1) = vTo
    pts(NSEGS) = vTo
    For i = 0 To LG_NSEGS - 1
        pts(1) = V3_Bisect(pts(0), pts(1))
    Next
    dot = 2 * V3_Dot(pts(0), pts(1))
    For i = 2 To NSEGS - 1
        pts(i) = V3_Sub(V3_Scale(pts(i - 1), dot), pts(i - 2))
    Next
    '
    glBegin GL_LINES
        For i = 0 To NSEGS - 1
            glVertex3fv pts(i).x
        Next
    glEnd
End Sub

'----------------------------------------------------------------
' Draw the arc of a semi-circle defined by its axis.
'called by m_DrawConstraints
Private Sub m_DrawHalfArc(n As HVect)
Dim p As HVect, m As HVect
    p.Z = 0
    If (n.Z <> 1) Then
        p.x = n.y
        p.y = -n.x
        p = V3_Unit(p)
    Else
        p.x = 0
        p.y = 1
    End If
    m = V3_Cross(p, n)
    m_DrawAnyArc p, m
    m_DrawAnyArc m, V3_Negate(p)
End Sub

'----------------------------------------------------------------
' Draw all constraint arcs.
'called by Draw
Private Sub m_DrawConstraints()
Dim setIdx& '    ConstraintSet set;
Dim Axis As HVect, j&, axisI&, setSize&
    If (Ball.AxisSet = NoAxes) Then Exit Sub
    setSize = Ball.setSizes(Ball.AxisSet)
    setIdx = Ball.AxisSet
    For axisI = 0 To setSize - 1
        If (Ball.AxisIndex <> axisI) Then
            If (Ball.Dragging) Then GoTo cont
            'FARCOLOR
            glColor3b 195, 127, 31
        Else
            'NEARCOLOR
            glColor3b 255, 255, 63
        End If
        Axis = m_GetHVectorSet(setIdx, axisI)
        'If (Axis.Z = 1) Then
            'circ 0, 0, 1
            'gCtl.Shapes.Sphere 1
        'Else
            m_DrawHalfArc Axis
        'End If
cont:
    Next
End Sub

'----------------------------------------------------------------
'----------------------------------------------------------------
' Draw "rubber band" arc during dragging. */
Private Sub m_DrawDragArc()
    'DRAGCOLOR
    glColor3f 127, 255, 255
    If (Ball.Dragging) Then
        m_DrawAnyArc Ball.vFrom, Ball.vTo
    End If
End Sub

'----------------------------------------------------------------
' Draw arc for result of all drags. */
Private Sub m_DrawResultArc()
    'RESCOLOR
    glColor3f 195, 31, 31
    m_DrawAnyArc Ball.vrFrom, Ball.vrTo
End Sub

'----------------------------------------------------------------
'**** Body.c *****/



'----------------------------------------------------------------
'*** BallMath.c - Essential routines for ArcBall.  ***
'----------------------------------------------------------------

'----------------------------------------------------------------
' Convert window coordinates to sphere coordinates.
Private Function m_MouseOnSphere(mouse As HVect) As HVect
Dim ballMouse As HVect, mag#, scale_#
    ballMouse.x = (mouse.x - Ball.Center.x) / Ball.Radius
    ballMouse.y = (mouse.y - Ball.Center.y) / Ball.Radius
    mag = ballMouse.x * ballMouse.x + ballMouse.y * ballMouse.y
    If (mag > 1) Then
        scale_ = 1 / Sqr(mag)
        ballMouse.x = ballMouse.x * scale_
        ballMouse.y = ballMouse.y * scale_
        ballMouse.Z = 0
    Else
        ballMouse.Z = Sqr(1 - mag)
    End If
    ballMouse.W = 0
    m_MouseOnSphere = ballMouse
End Function

'----------------------------------------------------------------
' Construct a unit quaternion from two points on unit sphere
Private Function Qt_FromBallPoints(from As HVect, to_ As HVect) As Quat
Dim qu As Quat
    qu.x = from.y * to_.Z - from.Z * to_.y
    qu.y = from.Z * to_.x - from.x * to_.Z
    qu.Z = from.x * to_.y - from.y * to_.x
    qu.W = from.x * to_.x + from.y * to_.y + from.Z * to_.Z
    Qt_FromBallPoints = qu
End Function

'----------------------------------------------------------------
' Convert a unit quaternion to two points on unit sphere
Private Sub Qt_ToBallPoints(q As Quat, arcFrom As HVect, arcTo As HVect)
Dim s As Double
    s = Sqr(q.x * q.x + q.y * q.y)
    If (s = 0) Then
        arcFrom = V3_(0, 1, 0)
    Else
        arcFrom = V3_(-q.y / s, q.x / s, 0)
    End If
    arcTo.x = q.W * arcFrom.x - q.Z * arcFrom.y
    arcTo.y = q.W * arcFrom.y + q.Z * arcFrom.x
    arcTo.Z = q.x * arcFrom.y - q.y * arcFrom.x
    If (q.W < 0) Then
        arcFrom = V3_(-arcFrom.x, -arcFrom.y, 0)
    End If
End Sub


'----------------------------------------------------------------
'**** BallAux.c ****

'----------------------------------------------------------------
' Return quaternion product qL * qR.  Note: order is important!
'* To combine rotations, use the product Mul(qSecond, qFirst),
'* which gives the effect of rotating by qFirst then qSecond.
Private Function Qt_Mul(qL As Quat, qR As Quat) As Quat
Dim qq As Quat
    qq.W = qL.W * qR.W - qL.x * qR.x - qL.y * qR.y - qL.Z * qR.Z
    qq.x = qL.W * qR.x + qL.x * qR.W + qL.y * qR.Z - qL.Z * qR.y
    qq.y = qL.W * qR.y + qL.y * qR.W + qL.Z * qR.x - qL.x * qR.Z
    qq.Z = qL.W * qR.Z + qL.Z * qR.W + qL.x * qR.y - qL.y * qR.x
    Qt_Mul = qq
End Function


'----------------------------------------------------------------
' Construct rotation matrix from (possibly non-unit) quaternion.
' * Assumes matrix is used to multiply column vector on the left:
' * vnew = mat vold.  Works correctly for right-handed coordinate system
' * and right-handed rotations.
Private Function Qt_ToMatrix(q As Quat, out As HMatrix) As HMatrix
Dim Nq#, s#, xs#, ys#, zs#, wx#, wy#, wz#
Dim xx#, xy#, xz#, yy#, yz#, zz#
    Nq = q.x * q.x + q.y * q.y + q.Z * q.Z + q.W * q.W
    If Nq > 0 Then
        s = 2 / Nq
    Else: s = 0
    End If
    xs = q.x * s
    ys = q.y * s
    zs = q.Z * s
    wx = q.W * xs
    wy = q.W * ys
    wz = q.W * zs
    xx = q.x * xs
    xy = q.x * ys
    xz = q.x * zs
    yy = q.y * ys
    yz = q.y * zs
    zz = q.Z * zs
    out.v(0) = 1 - (yy + zz)
    out.v(4) = xy + wz
    out.v(8) = xz - wy
    out.v(1) = xy - wz
    out.v(5) = 1 - (xx + zz)
    out.v(9) = yz + wx
    out.v(2) = xz + wy
    out.v(6) = yz - wx
    out.v(10) = 1 - (xx + yy)
    out.v(3) = 0
    out.v(7) = 0
    out.v(11) = 0
    out.v(12) = 0
    out.v(13) = 0
    out.v(14) = 0
    out.v(15) = 1
    Qt_ToMatrix = out
End Function

'----------------------------------------------------------------
' Return conjugate of quaternion.
Private Function Qt_Conj(q As Quat) As Quat
Dim qq As Quat
    qq.x = -q.x
    qq.y = -q.y
    qq.Z = -q.Z
    qq.W = q.W
    Qt_Conj = qq
End Function

'----------------------------------------------------------------
' Return vector formed from components
Private Function V3_(x!, y!, Z!) As HVect
Dim v As HVect
    v.x = x
    v.y = y
    v.Z = Z
    v.W = 0
    V3_ = v
End Function

'----------------------------------------------------------------
' Return norm of v, defined as sum of squares of components
Private Function V3_Norm!(v As HVect)
    V3_Norm = v.x * v.x + v.y * v.y + v.Z * v.Z
End Function

'----------------------------------------------------------------
' Return unit magnitude vector in direction of v
Private Function V3_Unit(v As HVect) As HVect
Dim u As HVect '    static HVect u = {0, 0, 0, 0};
Dim vlen!
    vlen = Sqr(V3_Norm(v))
    If (vlen <> 0) Then
        u.x = v.x / vlen
        u.y = v.y / vlen
        u.Z = v.Z / vlen
    End If
    V3_Unit = u
End Function

'----------------------------------------------------------------
' Return version of v scaled by s
Private Function V3_Scale(v As HVect, s!) As HVect
Dim u As HVect
    u.x = s * v.x
    u.y = s * v.y
    u.Z = s * v.Z
    u.W = v.W
    V3_Scale = u
End Function

'----------------------------------------------------------------
' Return negative of v
Private Function V3_Negate(v As HVect) As HVect
Dim u As HVect '    static HVect u = {0, 0, 0, 0};
    u.x = -v.x
    u.y = -v.y
    u.Z = -v.Z
    V3_Negate = u
End Function

'----------------------------------------------------------------
' Return sum of v1 and v2
Private Function V3_Add(v1 As HVect, v2 As HVect) As HVect
Dim v As HVect 'v = {0, 0, 0, 0};
    v.x = v1.x + v2.x
    v.y = v1.y + v2.y
    v.Z = v1.Z + v2.Z
    V3_Add = v
End Function

'----------------------------------------------------------------
' Return difference of v1 minus v2
Private Function V3_Sub(v1 As HVect, v2 As HVect) As HVect
Dim v As HVect ' v = {0, 0, 0, 0};
    v.x = v1.x - v2.x
    v.y = v1.y - v2.y
    v.Z = v1.Z - v2.Z
    V3_Sub = v
End Function

'----------------------------------------------------------------
' Halve arc between unit vectors v0 and v1.
Private Function V3_Bisect(v0 As HVect, v1 As HVect) As HVect
Dim v As HVect    ' v = {0, 0, 0, 0}
Dim Nv!
    v = V3_Add(v0, v1)
    Nv = V3_Norm(v)
    If (Nv < 0.00001) Then
        v = V3_(0, 0, 1)
    Else
        v = V3_Scale(v, 1 / Sqr(Nv))
    End If
    V3_Bisect = v

End Function

'----------------------------------------------------------------
' Return dot product of v1 and v2
Private Function V3_Dot!(v1 As HVect, v2 As HVect)
    V3_Dot = (v1.x * v2.x + v1.y * v2.y + v1.Z * v2.Z)
End Function

'----------------------------------------------------------------
' Return cross product, v1 x v2
Private Function V3_Cross(v1 As HVect, v2 As HVect) As HVect
Dim v As HVect  'v = {0, 0, 0, 0};
    v.x = v1.y * v2.Z - v1.Z * v2.y
    v.y = v1.Z * v2.x - v1.x * v2.Z
    v.Z = v1.x * v2.y - v1.y * v2.x
    V3_Cross = v
End Function

'----------------------------------------------------------------
Private Sub m_Doughnut(ByVal InnerRad#, ByVal OuterRad#, ByVal nsides&, ByVal rings&)
Dim i&, j&
Dim theta!, phi!, theta1!
Dim cosTheta!, sinTheta!
Dim cosTheta1!, sinTheta1!
Dim ringDelta!, sideDelta!
Dim cosPhi!, sinPhi!, dist!
  
    ringDelta = 2 * M_PI / rings
    sideDelta = 2 * M_PI / nsides
    
    theta = 0
    cosTheta = 1
    sinTheta = 0
    For i = rings - 1 To 0 Step -1
        theta1 = theta + ringDelta
        cosTheta1 = Cos(theta1)
        sinTheta1 = Sin(theta1)
        glBegin GL_QUAD_STRIP
        phi = 0
        For j = nsides To 0 Step -1
            
            phi = phi + sideDelta
            cosPhi = Cos(phi)
            sinPhi = Sin(phi)
            dist = OuterRad + InnerRad * cosPhi
            
            glNormal3f cosTheta1 * cosPhi, -sinTheta1 * cosPhi, sinPhi
            glVertex3f cosTheta1 * dist, -sinTheta1 * dist, InnerRad * sinPhi
            glNormal3f cosTheta * cosPhi, -sinTheta * cosPhi, sinPhi
            glVertex3f cosTheta * dist, -sinTheta * dist, InnerRad * sinPhi
        Next
        glEnd
    theta = theta1
    cosTheta = cosTheta1
    sinTheta = sinTheta1
    Next
End Sub




