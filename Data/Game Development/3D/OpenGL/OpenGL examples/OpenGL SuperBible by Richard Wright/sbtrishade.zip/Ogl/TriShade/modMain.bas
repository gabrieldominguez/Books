Attribute VB_Name = "mMain"
Public Sub main()
   
' Main subroutine to draw triangle with flat/smooth shading
   
'****************************************************************
' Author - Sameer Deshmukh, Zentech Inc.
' Contact - sameer@zentech-usa.com
'****************************************************************
   
    ' Intialize variables and set the menus accordingly
    bCull = False
    bDepth = False
    bOutLine = False
    iFlatSmooth = 1
    frmDisplay.mnuFlat_Shading.Checked = True
    frmDisplay.mnuSmooth_Shading.Checked = False
  
    ' Show the current window
    Load frmDisplay
    StartOpenGL frmDisplay.hDC
    frmDisplay.Show
    
    ' Event Processing Loop
    bAppRunning = True
    While bAppRunning = True
        ReDraw  ' Draw Triangle with 3 vertexes with 3 different colors
        DoEvents
    Wend
    
    StopOpenGL
    
    Unload frmDisplay
    Set frmDisplay = Nothing
    
End Sub

