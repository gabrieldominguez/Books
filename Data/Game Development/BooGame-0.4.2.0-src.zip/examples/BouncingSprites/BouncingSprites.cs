/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;

using BooGame;

namespace BouncingSprites
{
	/// <summary>
	/// A simple bouncing sprites example.
	/// </summary>
	public class BouncingSprites : GameState
    {
        [STAThread]
        public static void Main()
        {
            // Allow BooGame to load files from BouncingSpritesData.zip
            FileSystem.AddSearchPath("BouncingSpritesData.zip");

            // Change window caption
            Display.WindowCaption = "BooGame - Bouncing Sprites";

            // Setup the system and run it
            Keyboard.KeyRepeat = false;
            Core.Game = new BouncingSprites();
            Core.Run();
        }

        // The local variables
        private BooGame.Font font = new BooGame.Font(FontFamily.GenericSansSerif, 25f, FontStyle.Italic);
		private AnimationCollection m_Animations = new AnimationCollection();
		private Audio shot = new Audio("shot.ogg");
        private Audio jaguar = new Audio("jaguar.wav");
        private Audio music = new Audio("music.mod");
		private Random rand = new Random();
		
		public BouncingSprites()
        {
            // Add more functionality to draw to report the sprite count
            Core.Draw += new DrawEventHandler(Core_Draw);

            // Dynamically load all sprites in the "sprites" directory
			string[] files = FileSystem.GetFiles("sprites");
			foreach(string file in files)
				m_Animations.Add(file, 96, 96);
			foreach(Animation anim in m_Animations)
				anim.Frames.RemoveAt(anim.Frames.Count - 7, 6);

            // Setup the background music
            music.Volume = 0.3f;
            music.LoopCount = -1;
            music.Play();

            // Add a single sprite
			AddSprite();
		}

        private void Core_Draw(object sender, DrawEventArgs args)
        {
            font.Print("Sprites: " + Entities.Count, Color.Red, 0f, Display.Height, ContentAlignment.BottomLeft);
        }

		public override void KeyDown(KeyboardEventArgs args)
		{
			switch(args.Key)
			{
				case Keys.UpArrow:
					AddSprite();
					break;
				case Keys.DownArrow:
					if(Entities.Count > 0)
					{
						Entities.RemoveAt(Entities.Count - 1);
						shot.Play();
					}
					break;
				case Keys.Escape:
					Core.QuitApplication();
					break;
			}
		}

		public override void MouseButtonDown(MouseEventArgs args)
		{
			switch(args.Button)
			{
				case MouseButtons.Left:
					Sprite sprite = AddSprite();
					sprite.X = args.MouseX;
					sprite.Y = args.MouseY;
					break;
				case MouseButtons.Right:
					Entities.Remove(Entities.GetEntityAtLocation(args.Location));
					shot.Play();
					break;
			}
		}

        public override void MouseWheel(MouseEventArgs args)
        {
            switch (args.WheelDirection)
            {
                case MouseWheelDirection.Down:
                    if (Entities.Count > 0)
                    {
                        Entities.RemoveAt(Entities.Count - 1);
                        shot.Play();
                    }
                    break;
                case MouseWheelDirection.Up:
                    AddSprite();
                    break;
            }
        }

		public Sprite AddSprite()
		{
            // Choose which animation to use
			int i = rand.Next(m_Animations.Count);

            // Create the sprite
			Sprite newSprite = new Sprite(m_Animations[i]);
			newSprite.HotSpot = new System.Drawing.PointF(newSprite.Width / 2f, newSprite.Height / 2f);
			newSprite.Velocity = Vector.FromDirection((float)rand.NextDouble() * 2f * (float)Math.PI, (float)rand.NextDouble() * 100f + 1f);
            newSprite.Location = new System.Drawing.PointF(Display.ScreenSize.Width / 2f, Display.ScreenSize.Height / 2f);
			newSprite.RotationSpeed = (float)rand.NextDouble() * 20f - 2f;
			newSprite.Scale = (float)rand.NextDouble() * 0.4f + 0.6f;
            newSprite.FrameProgression = (float)(rand.NextDouble() * newSprite.Animations[0].Frames.Count);

            // Play the sound and add the entity
			jaguar.Play();
			base.Entities.Add(newSprite);

			return newSprite;
		}

		public override void Update()
		{
            // Report the FPS
            Display.WindowCaption = "BooGame - Bouncing Sprites - " + Timer.Fps.ToString("#.0") + " FPS";

            // Bounce the sprites
			foreach(Entity sprite in Entities)
			{
				if(sprite.Left < 0f)
				{
					sprite.Left = 0f;
					sprite.Velocity.X *= -1f;
				}
				if(sprite.Top < 0f)
				{
					sprite.Top = 0f;
					sprite.Velocity.Y *= -1f;
				}
                if (sprite.Right > Display.Width)
				{
                    sprite.Right = Display.Width;
					sprite.Velocity.X *= -1f;
				}
                if (sprite.Bottom > Display.Height)
				{
                    sprite.Bottom = Display.Height;
					sprite.Velocity.Y *= -1f;
				}
			}

			base.Update();
		}
	}
}
