/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;

namespace BooGame
{
	/// <summary>
	/// Describes a set of frames to make up an animation.
	/// </summary>
	[Serializable]
	public class Animation
	{
		public Animation()
		{
		}
		public Animation(string filename)
		{
			m_Frames.Add(filename);
		}
		public Animation(TileSet tiles)
		{
			m_Frames.Add(tiles);
		}
		public Animation(TileCollection tiles)
		{
			m_Frames.Add(tiles);
		}
		public Animation(Tile tile)
		{
			m_Frames.Add(tile);
		}
		public Animation(TileSet tiles, float animationSpeed)
		{
			m_Speed = animationSpeed;
			m_Frames.Add(tiles);
		}
		public Animation(TileCollection tiles, float animationSpeed)
		{
			m_Speed = animationSpeed;
			m_Frames.Add(tiles);
		}
		public Animation(Tile tile, float animationSpeed)
		{
			m_Speed = animationSpeed;
			m_Frames.Add(tile);
		}

		public Tile this[int index]
		{
			get
			{
				return m_Frames[index];
			}
			set
			{
				m_Frames[index] = value;
			}
		}
		
		public Tile this[float index]
		{
			get
			{
				return m_Frames[(int)index];
			}
			set
			{
				m_Frames[(int)index] = value;
			}
        }

		public TileCollection m_Frames = new TileCollection();
        /// <summary>
        /// Gets the frames associated with the animation.
        /// </summary>
		public TileCollection Frames
		{
			get
			{
				return m_Frames;
			}
		}

		private string m_Name = String.Empty;
        /// <summary>
        /// The name of the animation.
        /// </summary>
		public string Name
		{
			get
			{
				return m_Name;
			}
			set
			{
				m_Name = value;
			}
		}

		private float m_Speed = 30f;
        /// <summary>
        /// The speed of the animations at animation frames per second.
        /// </summary>
		public float Speed
		{
			get
			{
				return m_Speed;
			}
			set
			{
				m_Speed = value;
			}
		}
    }
    #region AnimationCollection
    /// <summary>
    /// A collection of Animations.
    /// </summary>
    [Serializable]
    public class AnimationCollection : CollectionBase, ICollection
    {

        public AnimationCollection()
            : base()
        {
        }

        public AnimationCollection(string filename)
        {
            this.Add(filename);
        }

        public AnimationCollection(string filename, int tileWidth, int tileHeight)
        {
            this.Add(filename, tileWidth, tileHeight);
        }

        public AnimationCollection(AnimationCollection anims)
        {
            this.Add(anims);
        }

        public AnimationCollection(TileCollection tiles)
        {
            this.Add(tiles);
        }

        public AnimationCollection(TileSet tiles)
        {
            this.Add(tiles);
        }

        public AnimationCollection(Tile tile)
        {
            this.Add(tile);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public Animation this[int index]
        {
            get
            {
                return ((Animation)List[index]);
            }
            set
            {
                List[index] = value;
            }
        }

        public Animation this[string name]
        {
            get
            {
                foreach (Animation animation in this)
                    if (animation.Name == name)
                        return animation;
                throw new NullReferenceException("Animation '" + name + "' not found in collection.");
            }
            set
            {
                for (int i = 0; i < this.Count; i++)
                {
                    if (this[i].Name == name)
                    {
                        this[i] = value;
                        return;
                    }
                }
                value.Name = name;
                this.Add(value);
            }
        }

        public int Add(TileSet tileset)
        {
            return List.Add(new Animation(tileset));
        }
        public int Add(TileCollection tiles)
        {
            return List.Add(new Animation(tiles));
        }

        public int Add(Animation anim)
        {
            return (List.Add(anim));
        }

        public int Add(Tile tile)
        {
            return (List.Add(new Animation(tile)));
        }

        public int Add(string  filename)
        {
            return (List.Add(new Animation(filename)));
        }
        public int Add(string filename, int tileWidth, int tileHeight)
        {
            return this.Add(new TileSet(filename, tileWidth, tileHeight));
        }

        public int Add(AnimationCollection animCollection)
        {
            for (int i = 0; i < animCollection.Count; i++)
                this.Add(animCollection[i]);
            return this.Count;
        }

        public void Insert(int index, Animation anim)
        {
            List.Insert(index, anim);
        }

        public void Remove(Animation anim)
        {
            List.Remove(anim);
        }

        public int IndexOf(Animation anim)
        {
            return (List.IndexOf(anim));
        }

        public bool Contains(Animation anim)
        {
            return (List.Contains(anim));
        }

        public virtual void CopyTo(Animation[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public static AnimationCollection FromFile(string filename)
        {
            return Map.FromFile(filename).Animations;
        }
    }
    #endregion AnimationCollection
}
