VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Puzzle"
   ClientHeight    =   5190
   ClientLeft      =   300
   ClientTop       =   2235
   ClientWidth     =   5625
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5190
   ScaleWidth      =   5625
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3660
      Left            =   405
      TabIndex        =   0
      Top             =   405
      Width           =   3165
      _ExtentX        =   5583
      _ExtentY        =   6456
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileSolve 
         Caption         =   "Solve"
      End
      Begin VB.Menu mnuFileReset 
         Caption         =   "Reset"
      End
      Begin VB.Menu mnuFileSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "Exit"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub


Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
If WindowState = 1 Then
    CX.Visibility 0
Else
    CX.Visibility True
End If
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub


Private Sub glxCtl1_Resize(Width As Long, Height As Long, default As Boolean)
default = CX.Reshape(Width, Height)
End Sub


Private Sub mnuFileReset_Click()
CX.Reset
End Sub

Private Sub mnuFileSolve_Click()
CX.toggleSolve
End Sub
