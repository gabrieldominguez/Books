Attribute VB_Name = "basWhale"
'/**
' * (c) Copyright 1993, 1994, Silicon Graphics, Inc.
' * ALL RIGHTS RESERVED
' * Permission to use, copy, modify, and distribute this software for
' * any purpose and without fee is hereby granted, provided that the above
' * copyright notice appear in all copies and that both the copyright notice
' * and this permission notice appear in supporting documentation, and that
' * the name of Silicon Graphics, Inc. not be used in advertising
' * or publicity pertaining to distribution of the software without specific,
' * written prior permission.
' *
' * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
' * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
' * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
' * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
' * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
' * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
' * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
' * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
' * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
' * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
' * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
' * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
' *
' * US Government Users Restricted Rights
' * Use, duplication, or disclosure by the Government is subject to
' * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
' * (c)(1)(ii) of the Rights in Technical Data and Computer Software
' * clause at DFARS 252.227-7013 and/or in similar or successor
' * clauses in the FAR or the DOD or NASA FAR Supplement.
' * Unpublished-- rights reserved under the copyright laws of the
' * United States.  Contractor/manufacturer is Silicon Graphics,
' * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
' *
' * OpenGL(TM) is a trademark of Silicon Graphics, Inc.
' */
'#include <GL/glut.h>
'#include <math.h>
'#include "atlantis.h"
'/* *INDENT-OFF* */

Option Explicit

Private N001(2) As Single
Private N002(2) As Single
Private N003(2) As Single
Private N004(2) As Single
Private N005(2) As Single
Private N006(2) As Single
Private N008(2) As Single
Private N009(2) As Single
Private N010(2) As Single
Private N011(2) As Single
Private N012(2) As Single
Private N013(2) As Single
Private N014(2) As Single
Private N015(2) As Single
Private N016(2) As Single
Private N017(2) As Single
Private N018(2) As Single
Private N019(2) As Single
Private N020(2) As Single
Private N021(2) As Single
Private N022(2) As Single
Private N023(2) As Single
Private N024(2) As Single
Private N025(2) As Single
Private N026(2) As Single
Private N027(2) As Single
Private N028(2) As Single
Private N029(2) As Single
Private N030(2) As Single
Private N031(2) As Single
Private N032(2) As Single
Private N033(2) As Single
Private N034(2) As Single
Private N035(2) As Single
Private N036(2) As Single
Private N037(2) As Single
Private N038(2) As Single
Private N039(2) As Single
Private N040(2) As Single
Private N041(2) As Single
Private N042(2) As Single
Private N043(2) As Single
Private N044(2) As Single
Private N045(2) As Single
Private N046(2) As Single
Private N047(2) As Single
Private N048(2) As Single
Private N049(2) As Single
Private N050(2) As Single
Private N051(2) As Single
Private N052(2) As Single
Private N053(2) As Single
Private N054(2) As Single
Private N055(2) As Single
Private N056(2) As Single
Private N057(2) As Single
Private N058(2) As Single
Private N059(2) As Single
Private N060(2) As Single
Private N062(2) As Single
Private N063(2) As Single
Private N065(2) As Single
Private N066(2) As Single
Private N067(2) As Single
Private N068(2) As Single
Private N069(2) As Single
Private N070(2) As Single
Private N071(2) As Single
Private N072(2) As Single
Private N073(2) As Single
Private N074(2) As Single
Private N075(2) As Single
Private N076(2) As Single
Private N077(2) As Single
Private N078(2) As Single
Private N079(2) As Single
Private N080(2) As Single
Private N081(2) As Single
Private N082(2) As Single
Private N083(2) As Single
Private N084(2) As Single
Private N085(2) As Single
Private N086(2) As Single
Private N087(2) As Single
Private N088(2) As Single
Private N089(2) As Single
Private N090(2) As Single
Private N091(2) As Single
Private N092(2) As Single
Private N093(2) As Single
Private N094(2) As Single
Private N095(2) As Single
Private N096(2) As Single
Private N097(2) As Single
Private N098(2) As Single
Private N099(2) As Single
Private N100(2) As Single
Private iP001(2) As Single
Private P001(2) As Single
Private P002(2) As Single
Private P003(2) As Single
Private P004(2) As Single
Private P005(2) As Single
Private P006(2) As Single
Private P008(2) As Single
Private iP009(2) As Single
Private iP010(2) As Single
Private iP011(2) As Single
Private P009(2) As Single
Private P010(2) As Single
Private P011(2) As Single
Private iP012(2) As Single
Private iP013(2) As Single
Private iP014(2) As Single
Private iP015(2) As Single
Private iP016(2) As Single
Private iP017(2) As Single
Private iP018(2) As Single
Private iP019(2) As Single
Private iP020(2) As Single
Private iP021(2) As Single
Private iP022(2) As Single
Private iP023(2) As Single
Private iP024(2) As Single
Private iP025(2) As Single
Private iP026(2) As Single
Private iP027(2) As Single
Private iP028(2) As Single
Private iP029(2) As Single
Private iP030(2) As Single
Private iP031(2) As Single
Private iP032(2) As Single
Private iP033(2) As Single
Private iP034(2) As Single
Private iP035(2) As Single
Private iP036(2) As Single
Private iP037(2) As Single
Private iP038(2) As Single
Private iP039(2) As Single
Private iP040(2) As Single
Private iP041(2) As Single
Private iP042(2) As Single
Private iP043(2) As Single
Private iP044(2) As Single
Private iP045(2) As Single
Private iP046(2) As Single
Private iP047(2) As Single
Private iP048(2) As Single
Private iP049(2) As Single
Private iP050(2) As Single
Private iP051(2) As Single
Private P012(2) As Single
Private P013(2) As Single
Private P014(2) As Single
Private P015(2) As Single
Private P016(2) As Single
Private P017(2) As Single
Private P018(2) As Single
Private P019(2) As Single
Private P020(2) As Single
Private P021(2) As Single
Private P022(2) As Single
Private P023(2) As Single
Private P024(2) As Single
Private P025(2) As Single
Private P026(2) As Single
Private P027(2) As Single
Private P028(2) As Single
Private P029(2) As Single
Private P030(2) As Single
Private P031(2) As Single
Private P032(2) As Single
Private P033(2) As Single
Private P034(2) As Single
Private P035(2) As Single
Private P036(2) As Single
Private P037(2) As Single
Private P038(2) As Single
Private P039(2) As Single
Private P040(2) As Single
Private P041(2) As Single
Private P042(2) As Single
Private P043(2) As Single
Private P044(2) As Single
Private P045(2) As Single
Private P046(2) As Single
Private P047(2) As Single
Private P048(2) As Single
Private P049(2) As Single
Private P050(2) As Single
Private P051(2) As Single
Private P052(2) As Single
Private P053(2) As Single
Private P054(2) As Single
Private P055(2) As Single
Private P056(2) As Single
Private P057(2) As Single
Private P058(2) As Single
Private P059(2) As Single
Private P060(2) As Single
Private P062(2) As Single
Private P063(2) As Single
Private P065(2) As Single
Private P066(2) As Single
Private P067(2) As Single
Private iP068(2) As Single
Private iP069(2) As Single
Private iP070(2) As Single
Private iP071(2) As Single
Private iP072(2) As Single
Private iP073(2) As Single
Private iP074(2) As Single
Private iP075(2) As Single
Private iP076(2) As Single
Private P068(2) As Single
Private P069(2) As Single
Private P070(2) As Single
Private P071(2) As Single
Private P072(2) As Single
Private P073(2) As Single
Private P074(2) As Single
Private P075(2) As Single
Private P076(2) As Single
Private P077(2) As Single
Private P078(2) As Single
Private P079(2) As Single
Private P080(2) As Single
Private P081(2) As Single
Private P082(2) As Single
Private P083(2) As Single
Private P084(2) As Single
Private P085(2) As Single
Private P086(2) As Single
Private P087(2) As Single
Private P088(2) As Single
Private P089(2) As Single
Private P090(2) As Single
Private iP091(2) As Single
Private iP092(2) As Single
Private iP093(2) As Single
Private iP094(2) As Single
Private iP095(2) As Single
Private P091(2) As Single
Private P092(2) As Single
Private P093(2) As Single
Private P094(2) As Single
Private P095(2) As Single
Private iP096(2) As Single
Private iP097(2) As Single
Private iP098(2) As Single
Private iP099(2) As Single
Private P096(2) As Single
Private P097(2) As Single
Private P098(2) As Single
Private P099(2) As Single
Private P100(2) As Single
Private P104(2) As Single
Private P105(2) As Single
Private P106(2) As Single
Private P107(2) As Single
Private P108(2) As Single
Private P109(2) As Single
Private P110(2) As Single
Private P111(2) As Single
Private P112(2) As Single
Private P113(2) As Single
Private P114(2) As Single
Private P115(2) As Single
Private P116(2) As Single
Private P117(2) As Single
Private P118(2) As Single
Private P119(2) As Single
Private P120(2) As Single
Private P121(2) As Single
Sub Whale_Init()
    FillArray N001(), Array(0.019249, 0.01134, -0.99975)
    FillArray N002, Array(-0.132579, 0.954547, 0.266952)
    FillArray N003, Array(-0.196061, 0.980392, -0.019778)
    FillArray N004, Array(0.695461, 0.604704, 0.388158)
    FillArray N005, Array(0.8706, 0.425754, 0.246557)
    FillArray N006, Array(-0.881191, 0.392012, 0.264251)
    FillArray N008, Array(-0.341437, 0.887477, 0.309523)
    FillArray N009, Array(0.124035, -0.992278, 0#)
    FillArray N010, Array(0.242536, 0#, -0.970143)
    FillArray N011, Array(0.588172, 0#, 0.808736)
    FillArray N012, Array(0.929824, -0.340623, -0.139298)
    FillArray N013, Array(0.954183, 0.267108, -0.134865)
    FillArray N014, Array(0.495127, 0.855436, -0.151914)
    FillArray N015, Array(-0.390199, 0.906569, -0.160867)
    FillArray N016, Array(-0.923605, 0.354581, -0.145692)
    FillArray N017, Array(-0.955796, -0.260667, -0.136036)
    FillArray N018, Array(-0.501283, -0.853462, -0.14254)
    FillArray N019, Array(0.4053, -0.901974, -0.148913)
    FillArray N020, Array(0.909913, -0.392746, -0.133451)
    FillArray N021, Array(0.936494, 0.331147, -0.115414)
    FillArray N022, Array(0.600131, 0.793724, -0.099222)
    FillArray N023, Array(-0.231556, 0.968361, -0.093053)
    FillArray N024, Array(-0.844369, 0.52533, -0.105211)
    FillArray N025, Array(-0.982725, -0.136329, -0.125164)
    FillArray N026, Array(-0.560844, -0.822654, -0.093241)
    FillArray N027, Array(0.263884, -0.959981, -0.093817)
    FillArray N028, Array(0.842057, -0.525192, -0.122938)
    FillArray N029, Array(0.92162, 0.367565, -0.124546)
    FillArray N030, Array(0.613927, 0.784109, -0.090918)
    FillArray N031, Array(-0.448754, 0.888261, -0.098037)
    FillArray N032, Array(-0.891865, 0.434376, -0.126077)
    FillArray N033, Array(-0.881447, -0.448017, -0.149437)
    FillArray N034, Array(-0.345647, -0.922057, -0.174183)
    FillArray N035, Array(0.307998, -0.941371, -0.137688)
    FillArray N036, Array(0.806316, -0.574647, -0.140124)
    FillArray N037, Array(0.961346, 0.233646, -0.145681)
    FillArray N038, Array(0.488451, 0.865586, -0.110351)
    FillArray N039, Array(-0.37429, 0.921953, -0.099553)
    FillArray N040, Array(-0.928504, 0.344533, -0.138485)
    FillArray N041, Array(-0.918419, -0.371792, -0.135189)
    FillArray N042, Array(-0.520666, -0.833704, -0.183968)
    FillArray N043, Array(0.339204, -0.920273, -0.195036)
    FillArray N044, Array(0.921475, -0.387382, -0.028636)
    FillArray N045, Array(0.842465, 0.533335, -0.076204)
    FillArray N046, Array(0.38011, 0.924939, 0.002073)
    FillArray N047, Array(-0.276128, 0.961073, -0.009579)
    FillArray N048, Array(-0.879684, 0.473001, -0.04925)
    FillArray N049, Array(-0.947184, -0.317614, -0.044321)
    FillArray N050, Array(-0.642059, -0.764933, -0.051363)
    FillArray N051, Array(0.466794, -0.880921, -0.07799)
    FillArray N052, Array(0.898509, -0.432277, 0.076279)
    FillArray N053, Array(0.938985, 0.328141, 0.103109)
    FillArray N054, Array(0.44242, 0.895745, 0.043647)
    FillArray N055, Array(-0.255163, 0.966723, 0.018407)
    FillArray N056, Array(-0.833769, 0.54065, 0.111924)
    FillArray N057, Array(-0.953653, -0.289939, 0.080507)
    FillArray N058, Array(-0.672357, -0.730524, 0.119461)
    FillArray N059, Array(0.522249, -0.846652, 0.102157)
    FillArray N060, Array(0.885868, -0.427631, 0.179914)
    FillArray N062, Array(0.648942, 0.743116, 0.163255)
    FillArray N063, Array(-0.578967, 0.80773, 0.111219)
    FillArray N065, Array(-0.909864, -0.352202, 0.219321)
    FillArray N066, Array(-0.502541, -0.81809, 0.27961)
    FillArray N067, Array(0.322919, -0.915358, 0.240504)
    FillArray N068, Array(0.242536, 0#, -0.970143)
    FillArray N069, Array(0#, 1#, 0#)
    FillArray N070, Array(0#, 1#, 0#)
    FillArray N071, Array(0#, 1#, 0#)
    FillArray N072, Array(0#, 1#, 0#)
    FillArray N073, Array(0#, 1#, 0#)
    FillArray N074, Array(0#, 1#, 0#)
    FillArray N075, Array(0.03122, 0.999025, -0.03122)
    FillArray N076, Array(0#, 1#, 0#)
    FillArray N077, Array(0.446821, 0.893642, 0.041889)
    FillArray N078, Array(0.863035, -0.10098, 0.494949)
    FillArray N079, Array(0.585597, -0.808215, 0.062174)
    FillArray N080, Array(0#, 1#, 0#)
    FillArray N081, Array(1#, 0#, 0#)
    FillArray N082, Array(0#, 1#, 0#)
    FillArray N083, Array(-1#, 0#, 0#)
    FillArray N084, Array(-0.478893, 0.837129, -0.264343)
    FillArray N085, Array(0#, 1#, 0#)
    FillArray N086, Array(0.763909, 0.539455, -0.354163)
    FillArray N087, Array(0.446821, 0.893642, 0.041889)
    FillArray N088, Array(0.385134, -0.908288, 0.163352)
    FillArray N089, Array(-0.605952, 0.779253, -0.159961)
    FillArray N090, Array(0#, 1#, 0#)
    FillArray N091, Array(0#, 1#, 0#)
    FillArray N092, Array(0#, 1#, 0#)
    FillArray N093, Array(0#, 1#, 0#)
    FillArray N094, Array(1#, 0#, 0#)
    FillArray N095, Array(-1#, 0#, 0#)
    FillArray N096, Array(0.644444, -0.621516, 0.445433)
    FillArray N097, Array(-0.760896, -0.474416, 0.442681)
    FillArray N098, Array(0.636888, -0.464314, 0.615456)
    FillArray N099, Array(-0.710295, 0.647038, 0.277168)
    FillArray N100, Array(0.009604, 0.993655, 0.112063)
    FillArray iP001, Array(18.74, 13.19, 3.76)
    FillArray P001, Array(18.74, 13.19, 3.76)
    FillArray P002, Array(0#, 390.42, 10292.57)
    FillArray P003, Array(55.8, 622.31, 8254.35)
    FillArray P004, Array(20.8, 247.66, 10652.13)
    FillArray P005, Array(487.51, 198.05, 9350.78)
    FillArray P006, Array(-457.61, 199.04, 9353.01)
    FillArray P008, Array(-34.67, 247.64, 10663.71)
    FillArray iP009, Array(97.46, 67.63, 593.82)
    FillArray iP010, Array(-84.33, 67.63, 588.18)
    FillArray iP011, Array(118.69, 8.98, -66.91)
    FillArray P009, Array(97.46, 67.63, 593.82)
    FillArray P010, Array(-84.33, 67.63, 588.18)
    FillArray P011, Array(118.69, 8.98, -66.91)
    FillArray iP012, Array(156.48, -31.95, 924.54)
    FillArray iP013, Array(162#, 110.22, 924.54)
    FillArray iP014, Array(88.16, 221.65, 924.54)
    FillArray iP015, Array(-65.21, 231.16, 924.54)
    FillArray iP016, Array(-156.48, 121.97, 924.54)
    FillArray iP017, Array(-162#, -23.93, 924.54)
    FillArray iP018, Array(-88.16, -139.1, 924.54)
    FillArray iP019, Array(65.21, -148.61, 924.54)
    FillArray iP020, Array(246.87, -98.73, 1783.04)
    FillArray iP021, Array(253.17, 127.76, 1783.04)
    FillArray iP022, Array(132.34, 270.77, 1783.04)
    FillArray iP023, Array(-97.88, 285.04, 1783.04)
    FillArray iP024, Array(-222.97, 139.8, 1783.04)
    FillArray iP025, Array(-225.29, -86.68, 1783.04)
    FillArray iP026, Array(-108.44, -224.15, 1783.04)
    FillArray iP027, Array(97.88, -221.56, 1783.04)
    FillArray iP028, Array(410.55, -200.66, 3213.87)
    FillArray iP029, Array(432.19, 148.42, 3213.87)
    FillArray iP030, Array(200.66, 410.55, 3213.87)
    FillArray iP031, Array(-148.42, 432.19, 3213.87)
    FillArray iP032, Array(-407.48, 171.88, 3213.87)
    FillArray iP033, Array(-432.19, -148.42, 3213.87)
    FillArray iP034, Array(-148.88, -309.74, 3213.87)
    FillArray iP035, Array(156.38, -320.17, 3213.87)
    FillArray iP036, Array(523.39, -303.81, 4424.57)
    FillArray iP037, Array(574.66, 276.84, 4424.57)
    FillArray iP038, Array(243.05, 492.5, 4424.57)
    FillArray iP039, Array(-191.23, 520.13, 4424.57)
    FillArray iP040, Array(-523.39, 304.01, 4424.57)
    FillArray iP041, Array(-574.66, -231.83, 4424.57)
    FillArray iP042, Array(-266.95, -578.17, 4424.57)
    FillArray iP043, Array(211.14, -579.67, 4424.57)
    FillArray iP044, Array(680.57, -370.27, 5943.46)
    FillArray iP045, Array(834.01, 363.09, 5943.46)
    FillArray iP046, Array(371.29, 614.13, 5943.46)
    FillArray iP047, Array(-291.43, 621.86, 5943.46)
    FillArray iP048, Array(-784.13, 362.6, 5943.46)
    FillArray iP049, Array(-743.29, -325.82, 5943.46)
    FillArray iP050, Array(-383.24, -804.77, 5943.46)
    FillArray iP051, Array(283.47, -846.09, 5943.46)
    FillArray P012, Array(156.48, -31.95, 924.54)
    FillArray P013, Array(162#, 110.22, 924.54)
    FillArray P014, Array(88.16, 221.65, 924.54)
    FillArray P015, Array(-65.21, 231.16, 924.54)
    FillArray P016, Array(-156.48, 121.97, 924.54)
    FillArray P017, Array(-162#, -23.93, 924.54)
    FillArray P018, Array(-88.16, -139.1, 924.54)
    FillArray P019, Array(65.21, -148.61, 924.54)
    FillArray P020, Array(246.87, -98.73, 1783.04)
    FillArray P021, Array(253.17, 127.76, 1783.04)
    FillArray P022, Array(132.34, 270.77, 1783.04)
    FillArray P023, Array(-97.88, 285.04, 1783.04)
    FillArray P024, Array(-222.97, 139.8, 1783.04)
    FillArray P025, Array(-225.29, -86.68, 1783.04)
    FillArray P026, Array(-108.44, -224.15, 1783.04)
    FillArray P027, Array(97.88, -221.56, 1783.04)
    FillArray P028, Array(410.55, -200.66, 3213.87)
    FillArray P029, Array(432.19, 148.42, 3213.87)
    FillArray P030, Array(200.66, 410.55, 3213.87)
    FillArray P031, Array(-148.42, 432.19, 3213.87)
    FillArray P032, Array(-407.48, 171.88, 3213.87)
    FillArray P033, Array(-432.19, -148.42, 3213.87)
    FillArray P034, Array(-148.88, -309.74, 3213.87)
    FillArray P035, Array(156.38, -320.17, 3213.87)
    FillArray P036, Array(523.39, -303.81, 4424.57)
    FillArray P037, Array(574.66, 276.84, 4424.57)
    FillArray P038, Array(243.05, 492.5, 4424.57)
    FillArray P039, Array(-191.23, 520.13, 4424.57)
    FillArray P040, Array(-523.39, 304.01, 4424.57)
    FillArray P041, Array(-574.66, -231.83, 4424.57)
    FillArray P042, Array(-266.95, -578.17, 4424.57)
    FillArray P043, Array(211.14, -579.67, 4424.57)
    FillArray P044, Array(680.57, -370.27, 5943.46)
    FillArray P045, Array(834.01, 363.09, 5943.46)
    FillArray P046, Array(371.29, 614.13, 5943.46)
    FillArray P047, Array(-291.43, 621.86, 5943.46)
    FillArray P048, Array(-784.13, 362.6, 5943.46)
    FillArray P049, Array(-743.29, -325.82, 5943.46)
    FillArray P050, Array(-383.24, -804.77, 5943.46)
    FillArray P051, Array(283.47, -846.09, 5943.46)
    FillArray P052, Array(599.09, -332.24, 7902.59)
    FillArray P053, Array(735.48, 306.26, 7911.92)
    FillArray P054, Array(321.55, 558.53, 7902.59)
    FillArray P055, Array(-260.54, 559.84, 7902.59)
    FillArray P056, Array(-698.66, 320.83, 7902.59)
    FillArray P057, Array(-643.29, -299.16, 7902.59)
    FillArray P058, Array(-341.47, -719.3, 7902.59)
    FillArray P059, Array(252.57, -756.12, 7902.59)
    FillArray P060, Array(458.39, -265.31, 9355.44)
    FillArray P062, Array(224.04, 438.98, 9364.77)
    FillArray P063, Array(-165.71, 441.27, 9355.44)
    FillArray P065, Array(-473.99, -219.71, 9355.44)
    FillArray P066, Array(-211.97, -479.87, 9355.44)
    FillArray P067, Array(192.86, -504.03, 9355.44)
    FillArray iP068, Array(-112.44, 9.25, -64.42)
    FillArray iP069, Array(1155.63, 0#, -182.46)
    FillArray iP070, Array(-1143.13, 0#, -181.54)
    FillArray iP071, Array(1424.23, 0#, -322.09)
    FillArray iP072, Array(-1368.01, 0#, -310.38)
    FillArray iP073, Array(1255.57, 2.31, 114.05)
    FillArray iP074, Array(-1149.38, 0#, 117.12)
    FillArray iP075, Array(718.36, 0#, 433.36)
    FillArray iP076, Array(-655.9, 0#, 433.36)
    FillArray P068, Array(-112.44, 9.25, -64.42)
    FillArray P069, Array(1155.63, 0#, -182.46)
    FillArray P070, Array(-1143.13, 0#, -181.54)
    FillArray P071, Array(1424.23, 0#, -322.09)
    FillArray P072, Array(-1368.01, 0#, -310.38)
    FillArray P073, Array(1255.57, 2.31, 114.05)
    FillArray P074, Array(-1149.38, 0#, 117.12)
    FillArray P075, Array(718.36, 0#, 433.36)
    FillArray P076, Array(-655.9, 0#, 433.36)
    FillArray P077, Array(1058#, -2.66, 7923.51)
    FillArray P078, Array(-1016.51, -15.47, 7902.87)
    FillArray P079, Array(-1363.99, -484.5, 7593.38)
    FillArray P080, Array(1478.09, -861.47, 7098.12)
    FillArray P081, Array(1338.06, -284.68, 7024.15)
    FillArray P082, Array(-1545.51, -860.64, 7106.6)
    FillArray P083, Array(1063.19, -70.46, 7466.6)
    FillArray P084, Array(-1369.18, -288.11, 7015.34)
    FillArray P085, Array(1348.44, -482.5, 7591.41)
    FillArray P086, Array(-1015.45, -96.8, 7474.86)
    FillArray P087, Array(731.04, 148.38, 7682.58)
    FillArray P088, Array(-697.03, 151.82, 7668.81)
    FillArray P089, Array(-686.82, 157.09, 7922.29)
    FillArray P090, Array(724.73, 147.75, 7931.39)
    FillArray iP091, Array(0#, 327.1, 2346.55)
    FillArray iP092, Array(0#, 552.28, 2311.31)
    FillArray iP093, Array(0#, 721.16, 2166.41)
    FillArray iP094, Array(0#, 693.42, 2388.8)
    FillArray iP095, Array(0#, 389.44, 2859.97)
    FillArray P091, Array(0#, 327.1, 2346.55)
    FillArray P092, Array(0#, 552.28, 2311.31)
    FillArray P093, Array(0#, 721.16, 2166.41)
    FillArray P094, Array(0#, 693.42, 2388.8)
    FillArray P095, Array(0#, 389.44, 2859.97)
    FillArray iP096, Array(222.02, -183.67, 10266.89)
    FillArray iP097, Array(-128.9, -182.7, 10266.89)
    FillArray iP098, Array(41.04, 88.31, 10659.36)
    FillArray iP099, Array(-48.73, 88.3, 10659.36)
    FillArray P096, Array(222.02, -183.67, 10266.89)
    FillArray P097, Array(-128.9, -182.7, 10266.89)
    FillArray P098, Array(41.04, 88.31, 10659.36)
    FillArray P099, Array(-48.73, 88.3, 10659.36)
    FillArray P100, Array(0#, 603.42, 9340.68)
    FillArray P104, Array(-9.86, 567.62, 7858.65)
    FillArray P105, Array(31.96, 565.27, 7908.46)
    FillArray P106, Array(22.75, 568.13, 7782.83)
    FillArray P107, Array(58.93, 568.42, 7775.94)
    FillArray P108, Array(55.91, 565.59, 7905.86)
    FillArray P109, Array(99.21, 566#, 7858.65)
    FillArray P110, Array(-498.83, 148.14, 9135.1)
    FillArray P111, Array(-495.46, 133.24, 9158.48)
    FillArray P112, Array(-490.82, 146.23, 9182.76)
    FillArray P113, Array(-489.55, 174.11, 9183.66)
    FillArray P114, Array(-492.92, 189#, 9160.28)
    FillArray P115, Array(-497.56, 176.02, 9136#)
    FillArray P116, Array(526.54, 169.68, 9137.7)
    FillArray P117, Array(523.49, 184.85, 9161.42)
    FillArray P118, Array(518.56, 171.78, 9186.06)
    FillArray P119, Array(516.68, 143.53, 9186.98)
    FillArray P120, Array(519.73, 128.36, 9163.26)
    FillArray P121, Array(524.66, 141.43, 9138.62)
'/* *INDENT-ON* */
End Sub
Sub Whale001()
    glBegin GL_POLYGON
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N074(0)
    glVertex3fv P074(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N072(0)
    glVertex3fv P072(0)
    glNormal3fv N074(0)
    glVertex3fv P074(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N072(0)
    glVertex3fv P072(0)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N074(0)
    glVertex3fv P074(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N074(0)
    glVertex3fv P074(0)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N070(0)
    glVertex3fv P070(0)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N076(0)
    glVertex3fv P076(0)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N068(0)
    glVertex3fv P068(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N010(0)
    glVertex3fv P010(0)
    glEnd
End Sub

Sub Whale002()

    glBegin (GL_POLYGON)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glNormal3fv N073(0)
    glVertex3fv P073(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N071(0)
    glVertex3fv P071(0)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N073(0)
    glVertex3fv P073(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N009(0)
    glVertex3fv P009(0)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N011(0)
    glVertex3fv P011(0)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N073(0)
    glVertex3fv P073(0)
    glNormal3fv N075(0)
    glVertex3fv P075(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N069(0)
    glVertex3fv P069(0)
    glNormal3fv N071(0)
    glVertex3fv P071(0)
    glNormal3fv N073(0)
    glVertex3fv P073(0)
    glEnd
End Sub

Sub Whale003()

    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N001(0)
    glVertex3fv P001(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glEnd
End Sub

Sub Whale004()

    glBegin (GL_POLYGON)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N015(0)
    glVertex3fv P015(0)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N016(0)
    glVertex3fv P016(0)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N017(0)
    glVertex3fv P017(0)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N014(0)
    glVertex3fv P014(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N013(0)
    glVertex3fv P013(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N018(0)
    glVertex3fv P018(0)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N019(0)
    glVertex3fv P019(0)
    glNormal3fv N012(0)
    glVertex3fv P012(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glEnd
End Sub

Sub Whale005()

    glBegin (GL_POLYGON)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N022(0)
    glVertex3fv P022(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N023(0)
    glVertex3fv P023(0)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N024(0)
    glVertex3fv P024(0)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N021(0)
    glVertex3fv P021(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N020(0)
    glVertex3fv P020(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N025(0)
    glVertex3fv P025(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N026(0)
    glVertex3fv P026(0)
    glNormal3fv N027(0)
    glVertex3fv P027(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glEnd
End Sub

Sub Whale006()

    glBegin (GL_POLYGON)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N093(0)
    glVertex3fv P093(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N093(0)
    glVertex3fv P093(0)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N091(0)
    glVertex3fv P091(0)
    glNormal3fv N092(0)
    glVertex3fv P092(0)
    glNormal3fv N094(0)
    glVertex3fv P094(0)
    glNormal3fv N095(0)
    glVertex3fv P095(0)
    glEnd
End Sub

Sub Whale007()

    glBegin (GL_POLYGON)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N030(0)
    glVertex3fv P030(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N029(0)
    glVertex3fv P029(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N028(0)
    glVertex3fv P028(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N035(0)
    glVertex3fv P035(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N034(0)
    glVertex3fv P034(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N031(0)
    glVertex3fv P031(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N032(0)
    glVertex3fv P032(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N033(0)
    glVertex3fv P033(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glEnd
End Sub

Sub Whale008()

    glBegin (GL_POLYGON)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N043(0)
    glVertex3fv P043(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N042(0)
    glVertex3fv P042(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N036(0)
    glVertex3fv P036(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N041(0)
    glVertex3fv P041(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N040(0)
    glVertex3fv P040(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N037(0)
    glVertex3fv P037(0)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N038(0)
    glVertex3fv P038(0)
    glNormal3fv N039(0)
    glVertex3fv P039(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glEnd
End Sub

Sub Whale009()

    glBegin (GL_POLYGON)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N051(0)
    glVertex3fv P051(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N044(0)
    glVertex3fv P044(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N050(0)
    glVertex3fv P050(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N049(0)
    glVertex3fv P049(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N048(0)
    glVertex3fv P048(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N045(0)
    glVertex3fv P045(0)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N046(0)
    glVertex3fv P046(0)
    glNormal3fv N047(0)
    glVertex3fv P047(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
End Sub

Sub Whale010()

    glBegin (GL_POLYGON)
    glNormal3fv N080(0)
    glVertex3fv P080(0)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N090(0)
    glVertex3fv P090(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N080(0)
    glVertex3fv P080(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N081(0)
    glVertex3fv P081(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N085(0)
    glVertex3fv P085(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N083(0)
    glVertex3fv P083(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N087(0)
    glVertex3fv P087(0)
    glNormal3fv N077(0)
    glVertex3fv P077(0)
    glNormal3fv N090(0)
    glVertex3fv P090(0)
    glEnd
End Sub

Sub Whale011()

    glBegin (GL_POLYGON)
    glNormal3fv N082(0)
    glVertex3fv P082(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N088(0)
    glVertex3fv P088(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N089(0)
    glVertex3fv P089(0)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N086(0)
    glVertex3fv P086(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N078(0)
    glVertex3fv P078(0)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N084(0)
    glVertex3fv P084(0)
    glNormal3fv N082(0)
    glVertex3fv P082(0)
    glNormal3fv N079(0)
    glVertex3fv P079(0)
    glEnd
End Sub

Sub Whale012()

    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N059(0)
    glVertex3fv P059(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N058(0)
    glVertex3fv P058(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N057(0)
    glVertex3fv P057(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N056(0)
    glVertex3fv P056(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N053(0)
    glVertex3fv P053(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N052(0)
    glVertex3fv P052(0)
    glEnd
End Sub

Sub Whale013()

    glBegin (GL_POLYGON)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N096(0)
    glVertex3fv P096(0)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glNormal3fv N096(0)
    glVertex3fv P096(0)
    glNormal3fv N098(0)
    glVertex3fv P098(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N066(0)
    glVertex3fv P066(0)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N067(0)
    glVertex3fv P067(0)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N096(0)
    glVertex3fv P096(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N060(0)
    glVertex3fv P060(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N096(0)
    glVertex3fv P096(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N096(0)
    glVertex3fv P096(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glNormal3fv N098(0)
    glVertex3fv P098(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N065(0)
    glVertex3fv P065(0)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N097(0)
    glVertex3fv P097(0)
    glNormal3fv N099(0)
    glVertex3fv P099(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P005(0)
    glVertex3fv P006(0)
    glVertex3fv P099(0)
    glVertex3fv P098(0)
    glEnd
End Sub

Sub Whale014()

    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N004(0)
    glVertex3fv P004(0)
    glNormal3fv N005(0)
    glVertex3fv P005(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P006(0)
    glVertex3fv P005(0)
    glVertex3fv P004(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N006(0)
    glVertex3fv P006(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N008(0)
    glVertex3fv P008(0)
    glNormal3fv N004(0)
    glVertex3fv P004(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N004(0)
    glVertex3fv P004(0)
    glEnd
End Sub

Sub Whale015()

    glBegin (GL_POLYGON)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N055(0)
    glVertex3fv P055(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N003(0)
    glVertex3fv P003(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N054(0)
    glVertex3fv P054(0)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N063(0)
    glVertex3fv P063(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glEnd
    glBegin (GL_POLYGON)
    glNormal3fv N100(0)
    glVertex3fv P100(0)
    glNormal3fv N002(0)
    glVertex3fv P002(0)
    glNormal3fv N062(0)
    glVertex3fv P062(0)
    glEnd
End Sub

Sub Whale016()

    glBegin (GL_POLYGON)
    glVertex3fv P104(0)
    glVertex3fv P105(0)
    glVertex3fv P106(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P107(0)
    glVertex3fv P108(0)
    glVertex3fv P109(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P110(0)
    glVertex3fv P111(0)
    glVertex3fv P112(0)
    glVertex3fv P113(0)
    glVertex3fv P114(0)
    glVertex3fv P115(0)
    glEnd
    glBegin (GL_POLYGON)
    glVertex3fv P116(0)
    glVertex3fv P117(0)
    glVertex3fv P118(0)
    glVertex3fv P119(0)
    glVertex3fv P120(0)
    glVertex3fv P121(0)
    glEnd
End Sub

Sub DrawWhale(Fish As fishRec)
    Dim seg0 As Double, seg1 As Double, seg2 As Double, seg3 As Double, seg4 As Double, seg5 As Double, seg6 As Double, seg7 As Double
    Dim pitch As Double, thrash As Double, chomp As Double

    Fish.htail = CInt(Fish.htail - CInt(5# * Fish.v)) Mod 360

    thrash = 70# * Fish.v

    seg0 = 1.5 * thrash * Sin((Fish.htail) * RRAD)
    seg1 = 2.5 * thrash * Sin((Fish.htail + 10#) * RRAD)
    seg2 = 3.7 * thrash * Sin((Fish.htail + 15#) * RRAD)
    seg3 = 4.8 * thrash * Sin((Fish.htail + 23#) * RRAD)
    seg4 = 6# * thrash * Sin((Fish.htail + 28#) * RRAD)
    seg5 = 6.5 * thrash * Sin((Fish.htail + 35#) * RRAD)
    seg6 = 6.5 * thrash * Sin((Fish.htail + 40#) * RRAD)
    seg7 = 6.5 * thrash * Sin((Fish.htail + 55#) * RRAD)

    pitch = Fish.v * Sin((Fish.htail - 160#) * RRAD)

    chomp = 0#
    If (Fish.v > 2#) Then
        chomp = -(Fish.v - 2#) * 200#
    End If
    P012(1) = iP012(1) + seg5
    P013(1) = iP013(1) + seg5
    P014(1) = iP014(1) + seg5
    P015(1) = iP015(1) + seg5
    P016(1) = iP016(1) + seg5
    P017(1) = iP017(1) + seg5
    P018(1) = iP018(1) + seg5
    P019(1) = iP019(1) + seg5

    P020(1) = iP020(1) + seg4
    P021(1) = iP021(1) + seg4
    P022(1) = iP022(1) + seg4
    P023(1) = iP023(1) + seg4
    P024(1) = iP024(1) + seg4
    P025(1) = iP025(1) + seg4
    P026(1) = iP026(1) + seg4
    P027(1) = iP027(1) + seg4

    P028(1) = iP028(1) + seg2
    P029(1) = iP029(1) + seg2
    P030(1) = iP030(1) + seg2
    P031(1) = iP031(1) + seg2
    P032(1) = iP032(1) + seg2
    P033(1) = iP033(1) + seg2
    P034(1) = iP034(1) + seg2
    P035(1) = iP035(1) + seg2

    P036(1) = iP036(1) + seg1
    P037(1) = iP037(1) + seg1
    P038(1) = iP038(1) + seg1
    P039(1) = iP039(1) + seg1
    P040(1) = iP040(1) + seg1
    P041(1) = iP041(1) + seg1
    P042(1) = iP042(1) + seg1
    P043(1) = iP043(1) + seg1

    P044(1) = iP044(1) + seg0
    P045(1) = iP045(1) + seg0
    P046(1) = iP046(1) + seg0
    P047(1) = iP047(1) + seg0
    P048(1) = iP048(1) + seg0
    P049(1) = iP049(1) + seg0
    P050(1) = iP050(1) + seg0
    P051(1) = iP051(1) + seg0

    P009(1) = iP009(1) + seg6
    P010(1) = iP010(1) + seg6
    P075(1) = iP075(1) + seg6
    P076(1) = iP076(1) + seg6

    P001(1) = iP001(1) + seg7
    P011(1) = iP011(1) + seg7
    P068(1) = iP068(1) + seg7
    P069(1) = iP069(1) + seg7
    P070(1) = iP070(1) + seg7
    P071(1) = iP071(1) + seg7
    P072(1) = iP072(1) + seg7
    P073(1) = iP073(1) + seg7
    P074(1) = iP074(1) + seg7

    P091(1) = iP091(1) + seg3 * 1.1
    P092(1) = iP092(1) + seg3
    P093(1) = iP093(1) + seg3
    P094(1) = iP094(1) + seg3
    P095(1) = iP095(1) + seg3 * 0.9

    P099(1) = iP099(1) + chomp
    P098(1) = iP098(1) + chomp
    P097(1) = iP097(1) + chomp
    P096(1) = iP096(1) + chomp

    glPushMatrix

    glRotatef pitch, 1#, 0#, 0#

    glTranslatef 0#, 0#, 8000#

    glRotatef 180#, 0#, 1#, 0#

    glScalef 3#, 3#, 3#

    glEnable (GL_CULL_FACE)

    Whale001
    Whale002
    Whale003
    Whale004
    Whale005
    Whale006
    Whale007
    Whale008
    Whale009
    Whale010
    Whale011
    Whale012
    Whale013
    Whale014
    Whale015
    Whale016

    glDisable (GL_CULL_FACE)

    glPopMatrix
End Sub
