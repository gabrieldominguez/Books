VERSION 5.00
Begin VB.Form frmDisplay 
   Caption         =   "Triangle Culling Example"
   ClientHeight    =   6000
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   ScaleHeight     =   400
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   400
   StartUpPosition =   3  'Windows Default
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFile_Exit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEffects 
      Caption         =   "&Effects"
      Begin VB.Menu mnuEffects_Depth 
         Caption         =   "&Depth Test"
      End
      Begin VB.Menu mnuEffects_Cull 
         Caption         =   "&Cull Back"
      End
      Begin VB.Menu mnuEffects_Outline 
         Caption         =   "&OutLine Back"
      End
   End
End
Attribute VB_Name = "frmDisplay"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Paint()
        ReDraw
End Sub

Private Sub Form_Resize()
    Dim WinAW As GLfloat, WinAH As GLfloat
    Dim WinW As GLfloat, WinH As GLfloat
    
    glViewport 0#, 0#, frmDisplay.ScaleWidth, frmDisplay.ScaleHeight
    
    WinAW = frmDisplay.ScaleWidth
    WinAH = frmDisplay.ScaleHeight
    
    If WinAW <= WinAH Then
      WinH = 400# * WinAH / WinAW
      WinW = 400#
    Else
      WinW = 400# * WinAW / WinAH
      WinH = 400#
    End If
    
    glMatrixMode mmProjection
    glLoadIdentity
    glOrtho -WinW / 2#, WinW / 2#, -WinH / 2#, WinH / 2#, 150#, -150#
    glMatrixMode mmModelView
    glLoadIdentity
   
    Call RenderScene
        
End Sub

Private Sub Form_Unload(Cancel As Integer)
    bAppRunning = False
End Sub

Private Sub mnuFile_Exit_Click()
    bAppRunning = False
End Sub

Private Sub mnuEffects_Cull_Click()
    frmCulling.Show
    Call RenderScene
End Sub

Private Sub mnuEffects_Depth_Click()
    If bDepth = False Then
      bDepth = True
      mnuEffects_Depth.Checked = True
    Else
      bDepth = False
      mnuEffects_Depth.Checked = False
    End If
    Call RenderScene
End Sub

Private Sub mnuEffects_Outline_Click()
    If bOutLine = False Then
      bOutLine = True
      mnuEffects_Outline.Checked = True
    Else
      bOutLine = False
      mnuEffects_Outline.Checked = False
    End If
    glClear clrColorBufferBit + clrDepthBufferBit
    Call RenderScene
End Sub


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
  Select Case KeyCode
    Case vbKeyUp
      xRot = xRot - 5#
    Case vbKeyDown
      xRot = xRot + 5#
    Case vbKeyLeft
      yRot = yRot - 5#
    Case vbKeyRight
      yRot = yRot + 5#
  End Select
  If xRot > 356# Then xRot = 0#
  If xRot < -1# Then xRot = 355#
  If yRot > 356# Then yRot = 0#
  If yRot < -1# Then yRot = 355#
  Call ReDraw
End Sub

