VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "gleSpiral"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Dim gc As gleGC
Dim m_StartRadius#
Dim m_drdTheta#
Dim m_StartZ#
Dim m_dzdTheta#
Dim m_StartTheta#
Dim m_SweepTheta#
Dim m_dXformdTheta() As gleAffine
Dim m_StartXForm() As gleAffine

Private Sub Class_Initialize()
    ReDim gc.up(0 To 2)
    gc.up(1) = 1
    gc.JoinStyle = gleANGLE
    gc.CapStyle = gleCAPS
    gc.NormStyle = gleFACET
    gc.ContourStyle = gleOPEN
End Sub

Private Sub Class_Terminate()
'
End Sub

'-------------------------------------------------------------------------== */
'public sub gleSpiral (ncp&,               ' number of contour points */
'             gleDouble contour()(2),    ' 2D contour */
'             gleDouble cont_normal()(2), ' 2D contour normals */
'             gleDouble up(3),           ' up vector for contour */
'             gleDouble startRadius,
'             gleDouble drdTheta,        ' change in radius per revolution */
'             gleDouble startZ,
'             gleDouble dzdTheta,        ' change in Z per revolution */
'             gleDouble startXform(2)(3),
'             gleDouble dXformdTheta(2)(3), ' tangent change xform per revolution */
'             gleDouble startTheta,        ' start angle, in degrees */
'             gleDouble sweepTheta)        ' sweep angle, in degrees */
'-------------------------------------------------------------------------== */
Public Sub Draw()
    GenSpiral gc, _
                m_StartRadius, m_drdTheta, m_StartZ, m_dzdTheta, _
                m_StartXForm, _
                m_dXformdTheta, _
                m_StartTheta, m_SweepTheta
End Sub

'-------------------------------------------------------------------------
'PUBLIC PROPERTIES
'-------------------------------------------------------------------------

'-------------------------------------------------------------------------
'ncp
'-------------------------------------------------------------------------
Public Property Get NumContourPoints() As Long
    NumContourPoints = gc.ncp
End Property

Public Property Let NumContourPoints(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncp = 0
    Erase gc.contour
Else
    gc.ncp = NewValue
    ReDim Preserve gc.contour(0 To gc.ncp - 1)
End If
End Property

'-------------------------------------------------------------------------
'contour
'-------------------------------------------------------------------------
Public Sub GetContourPt(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.contour(Index).v(0)
    y = gc.contour(Index).v(1)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetContourPt(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.contour(Index).v(0) = x
    gc.contour(Index).v(1) = y
Exit Sub
eh: gEH 1
End Sub

Public Property Get CPtX(ByVal Index&) As Double
On Error GoTo eh
    CPtX = gc.contour(Index).v(0)
Exit Property

eh: gEH 1
End Property

Public Property Let CPtX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.contour(Index).v(0) = NewX
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CPtY(ByVal Index&) As Double
On Error GoTo eh
    CPtY = gc.contour(Index).v(1)
Exit Property

eh: gEH 1
End Property

Public Property Let CPtY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.contour(Index).v(1) = NewY
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
'ncnormals
'-------------------------------------------------------------------------
Public Property Get NumContourNormals() As Long
NumContourNormals = gc.ncnormals
End Property

Public Property Let NumContourNormals(ByVal NewValue As Long)
If NewValue < 1 Then
    gc.ncnormals = 0
    Erase gc.cont_normal
Else
    gc.ncnormals = NewValue
    ReDim Preserve gc.cont_normal(0 To gc.ncnormals - 1)
End If
End Property

'-------------------------------------------------------------------------
'cont_normal
'-------------------------------------------------------------------------
Public Sub GetContourNormal(ByVal Index&, x#, y#)
On Error GoTo eh
    x = gc.cont_normal(Index).v(0)
    y = gc.cont_normal(Index).v(1)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetContourNormal(ByVal Index&, ByVal x#, ByVal y#)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = x
    gc.cont_normal(Index).v(1) = y
Exit Sub
eh: gEH 1
End Sub

Public Property Get CNX(ByVal Index&) As Double
On Error GoTo eh
    CNX = gc.cont_normal(Index).v(0)
Exit Property

eh: gEH 1
End Property

Public Property Let CNX(ByVal Index&, ByVal NewX As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(0) = NewX
Exit Property

eh: gEH 1
End Property

'-------------------------------------------------------------------------
Public Property Get CNY(ByVal Index&) As Double
On Error GoTo eh
    CNY = gc.cont_normal(Index).v(1)
Exit Property

eh: gEH 1
End Property

Public Property Let CNY(ByVal Index&, ByVal NewY As Double)
On Error GoTo eh
    gc.cont_normal(Index).v(1) = NewY
Exit Property

eh: gEH 1
End Property


'-------------------------------------------------------------------------
'up
'-------------------------------------------------------------------------
Public Sub GetUp(x#, y#, z#)
On Error GoTo eh
    x = gc.up(0)
    y = gc.up(1)
    z = gc.up(2)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetUp(ByVal x#, ByVal y#, ByVal z#)
On Error GoTo eh
    gc.up(0) = x
    gc.up(1) = y
    gc.up(2) = z
Exit Sub
eh: gEH 1
End Sub

'-------------------------------------------------------------------------
'StartRadius
'-------------------------------------------------------------------------
Public Property Get startRadius() As Double
startRadius = m_StartRadius
End Property

Public Property Let startRadius(ByVal NewValue As Double)
m_StartRadius = NewValue
End Property

'-------------------------------------------------------------------------
'drdTheta
'-------------------------------------------------------------------------
Public Property Get drdTheta() As Double
drdTheta = m_drdTheta
End Property

Public Property Let drdTheta(ByVal NewValue As Double)
m_drdTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartZ
'-------------------------------------------------------------------------
Public Property Get startZ() As Double
startZ = m_StartZ
End Property

Public Property Let startZ(ByVal NewValue As Double)
m_StartZ = NewValue
End Property


'-------------------------------------------------------------------------
'dzdTheta
'-------------------------------------------------------------------------
Public Property Get dzdTheta() As Double
dzdTheta = m_dzdTheta
End Property

Public Property Let dzdTheta(ByVal NewValue As Double)
m_dzdTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartTheta
'-------------------------------------------------------------------------
Public Property Get startTheta() As Double
startTheta = m_StartTheta
End Property

Public Property Let startTheta(ByVal NewValue As Double)
m_StartTheta = NewValue
End Property

'-------------------------------------------------------------------------
'SweepTheta
'-------------------------------------------------------------------------
Public Property Get sweepTheta() As Double
sweepTheta = m_SweepTheta
End Property

Public Property Let sweepTheta(ByVal NewValue As Double)
m_SweepTheta = NewValue
End Property

'-------------------------------------------------------------------------
'StartXForm
'-------------------------------------------------------------------------
Public Sub GetStartXForm(x1#, y1#, z1#, _
             x2#, y2#, z2#)
On Error GoTo eh
    With gc
        x1 = m_StartXForm(0).v0(0)
        y1 = m_StartXForm(0).v0(1)
        z1 = m_StartXForm(0).v0(2)
        x2 = m_StartXForm(0).v1(0)
        y2 = m_StartXForm(0).v1(1)
        z2 = m_StartXForm(0).v1(2)
    End With
Exit Sub
eh: gEH 1
End Sub

Public Sub SetStartXForm(ByVal x1#, ByVal y1#, ByVal z1#, _
            ByVal x2#, ByVal y2#, ByVal z2#)
On Error GoTo eh
    ReDim m_StartXForm(0 To 0)
    With gc
        m_StartXForm(0).v0(0) = x1
        m_StartXForm(0).v0(1) = y1
        m_StartXForm(0).v0(2) = z1
        m_StartXForm(0).v1(0) = x2
        m_StartXForm(0).v1(1) = y2
        m_StartXForm(0).v1(2) = z2
    End With
Exit Sub
eh: gEH 1
End Sub

'-------------------------------------------------------------------------
'dXformdTheta
'-------------------------------------------------------------------------
Public Sub GetdXFormdTheta(x1#, y1#, z1#, _
             x2#, y2#, z2#)
On Error GoTo eh
        x1 = m_dXformdTheta(0).v0(0)
        y1 = m_dXformdTheta(0).v0(1)
        z1 = m_dXformdTheta(0).v0(2)
        x2 = m_dXformdTheta(0).v1(0)
        y2 = m_dXformdTheta(0).v1(1)
        z2 = m_dXformdTheta(0).v1(2)
Exit Sub
eh: gEH 1
End Sub

Public Sub SetdXformdTheta(ByVal x1#, ByVal y1#, ByVal z1#, _
            ByVal x2#, ByVal y2#, ByVal z2#)
    ReDim m_dXformdTheta(0 To 0)
        m_dXformdTheta(0).v0(0) = x1
        m_dXformdTheta(0).v0(1) = y1
        m_dXformdTheta(0).v0(2) = z1
        m_dXformdTheta(0).v1(0) = x2
        m_dXformdTheta(0).v1(1) = y2
        m_dXformdTheta(0).v1(2) = z2
End Sub


' ======================================================= */
Public Property Get TextureEnabled() As Boolean
TextureEnabled = gc.TextureEnabled
End Property

Public Property Let TextureEnabled(ByVal NewValue As Boolean)
If NewValue Then
    gc.TextureEnabled = True
Else
    gc.TextureEnabled = False
End If
End Property

' ======================================================= */
Public Property Get TextureMode() As gleTextureModes
TextureMode = gc.TextureMode
End Property

Public Property Let TextureMode(ByVal mode As gleTextureModes)
gc.TextureMode = mode
SetTextureMode gc
End Property

' ======================================================= */
Public Property Get JoinStyle() As gleJoinStyles
JoinStyle = gc.JoinStyle
End Property

Public Property Let JoinStyle(ByVal NewValue As gleJoinStyles)
gc.JoinStyle = NewValue
End Property

' ======================================================= */
Public Property Get NormStyle() As gleNormStyles
NormStyle = gc.NormStyle
End Property

Public Property Let NormStyle(ByVal NewValue As gleNormStyles)
gc.NormStyle = NewValue
End Property

' ======================================================= */
Public Property Get ContourStyle() As gleContourStyles
ContourStyle = gc.ContourStyle
End Property

Public Property Let ContourStyle(ByVal NewValue As gleContourStyles)
gc.ContourStyle = NewValue
End Property

' ======================================================= */
Public Property Get CapStyle() As gleCapStyles
CapStyle = gc.CapStyle
End Property

Public Property Let CapStyle(ByVal NewValue As gleCapStyles)
gc.CapStyle = NewValue
End Property



