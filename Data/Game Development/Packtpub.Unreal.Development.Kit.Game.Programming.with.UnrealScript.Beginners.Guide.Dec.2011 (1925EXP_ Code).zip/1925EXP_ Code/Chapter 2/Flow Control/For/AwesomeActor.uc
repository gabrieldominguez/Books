class AwesomeActor extends Actor
    placeable;

var int m;

function PostBeginPlay()
{
    for(m = 0; m < 3; m++)
    {
        `log("Stop hitting yourself." @ m);
    }
}

defaultproperties
{
    Begin Object Class=SpriteComponent Name=Sprite
        Sprite=Texture2D'EditorResources.S_NavP'
        HiddenGame=True
    End Object
    Components.Add(Sprite)
}
