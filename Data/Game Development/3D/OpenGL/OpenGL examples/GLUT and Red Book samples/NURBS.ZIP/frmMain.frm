VERSION 5.00
Object = "*\A..\..\glxCtl\glxCtl.vbp"
Begin VB.Form Form1 
   Caption         =   "Nurbs"
   ClientHeight    =   5415
   ClientLeft      =   1815
   ClientTop       =   2115
   ClientWidth     =   5610
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5415
   ScaleWidth      =   5610
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4875
      Left            =   135
      TabIndex        =   0
      Top             =   180
      Width           =   5190
      _ExtentX        =   9155
      _ExtentY        =   8599
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_KeyPress(KeyAscii As Integer)
    '
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CN = New CNurb
glxCtl1.Init
glxCtl1.Animate = True
End Sub

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub glxctl1_Draw()
CN.Draw
End Sub

Private Sub glxctl1_InitGL()
CN.InitGL
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, shift As Integer)
'not getting arrows?, use 1,2,3,4
    Select Case KeyCode
    Case vbKeyDown, 49:
        rotX = rotX - 5
    Case vbKeyUp, 50:
        rotX = rotX + 5
    Case vbKeyLeft, 51:
         rotY = rotY - 5
    Case vbKeyRight, 52:
        rotY = rotY + 5
    Case 27:   Unload Form1
    Case Else: Exit Sub
    End Select
    KeyCode = 0
End Sub

Private Sub glxctl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CN.Reshape(width, height)
End Sub
