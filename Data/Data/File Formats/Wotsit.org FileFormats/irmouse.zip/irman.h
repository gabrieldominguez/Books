#ifndef IRMAN_H
#define IRMAN_H

//#include <sys/time.h>
#include <termios.h>
//#include <unistd.h>
#include <stdio.h>
//#include <sys/stat.h>
//#include <fcntl.h>
//#include <string.h>
#define DEBUGPRINT(x...) fprintf(stderr,##x)

#ifndef DEBUGPRINT
#define DEBUGPRINT(x...) 
#endif

const int IR_BUTTONDOWN	= 0xa0;
const int IR_BUTTONUP	= 0xaa;

const int BAUD		= B1200;  // Speed to talk to IR mouse
const int MB_NONE	= 0x00;  // mouse buttons
const int MB_LEFT	= 0x01;
const int MB_MIDDLE	= 0x02;
const int MB_RIGHT	= 0x04;
const int MINNEED	= 0x03;  // codes received BEFORE triggering event
const int REPEATCOUNT	= 20;    // codes repeat before triggering repeat events

const long FALSE	= 0;
const long TRUE		= -1;

struct limit {
  long min;
  long max;
};

struct point {
  long x;
  long y;
};

class IRMouse {
  public:
  // IR Mouse probe method
  virtual int checkmouse();
  // IR Mouse Setup/teardown methods
  IRMouse(char *devname="/dev/irmouse");
  ~IRMouse();
  //
  // Misc IR Mouse methods
  //
  void mute(int muted) { fmuted=(mute!=0); }; // sets mute
  int ismuted() { return fmuted; };
  //
  long volume() { return fvolume; };
  int setvolume(long newvolume);
  int setmaxvolume(long maxvolume);
  int setminvolume(long minvolume);
  //
  int fileno() { return fdev; };
  //
  // IR Mouse events
  //
  virtual void Event(int ev);	// Internal code handler
  virtual void evHelp(){DEBUGPRINT("Help\n");};
  virtual void evStart(){DEBUGPRINT("Start\n");};
  virtual void evPhone(){DEBUGPRINT("Phone\n");};
  virtual void evTV(){DEBUGPRINT("TV\n");};
  virtual void evGde(){DEBUGPRINT("Gde\n");};
  virtual void evCD(){DEBUGPRINT("CD\n");};
  virtual void evMsg(){DEBUGPRINT("Msg\n");};
  virtual void evSelect(){DEBUGPRINT("Select\n");};
  virtual void evChannelUp();
  virtual void evChannelDown();
  virtual void evChannel(int channel) {DEBUGPRINT("Channel=%d\n",channel);};
  virtual void evMute(int muted){DEBUGPRINT((muted)?"Mute: on\n":"Mute: off\n");};
  virtual void evVolumeUp(); 
  virtual void evVolumeDown();
  virtual void evVolume(int volume) {DEBUGPRINT("Volume=%d\n",volume);};
  virtual void evSkipPrev(){DEBUGPRINT("SkipPrev\n");};
  virtual void evPlay(){DEBUGPRINT("Play\n");};
  virtual void evSkipNext(){DEBUGPRINT("SkipNext\n");};
  virtual void evMenu(){DEBUGPRINT("Menu\n");};
  virtual void evStop(){DEBUGPRINT("Stop\n");};
  virtual void evPause(){DEBUGPRINT("Pause\n");};
  virtual void evKeypad(char ch=0){DEBUGPRINT("%c",ch);};
  virtual void evTerminate(){DEBUGPRINT("Terminate\n");};
  virtual void evClick(int buttons){DEBUGPRINT("Click %s,%s,%s\n",(buttons&MB_LEFT)?"Down":"-Up-",(buttons&MB_MIDDLE)?"Down":"-Up-",(buttons&MB_RIGHT)?"Down":"-Up-");};
  virtual void evMove(int x,int y){DEBUGPRINT("Move %d,%d\n",position.x,position.y);};
  private:
  int fdev;			// File handle to IRMouse device
  // the following is used in the checkmouse method
  unsigned char frepeatcode;
  unsigned long frepeatcount;
  int finstate;
  int fcodecount[256];
  // Misc values
  long fchannel;		// Current channel
  struct limit fchannel_limit;	// Limits on channel
  long fvolume;			// Current volume
  struct limit fvolume_limit;	// Limits on volume
  struct point position;	// Current Mouse position
  struct limit fx_limit;	// Limits on position.x range
  struct limit fy_limit;	// limits on position.y range
  int fmuted;			// if device is muted
};

#endif
