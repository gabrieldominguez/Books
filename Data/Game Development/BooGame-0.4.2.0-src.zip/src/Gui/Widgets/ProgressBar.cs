/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Drawing;
using BooGame;
using BooGame.Gui;

namespace BooGame.Gui.Widgets
{
    public class ProgressBar : Container
    {
        public ProgressBar()
        {
            this.Focusable = false;
            this.Tint = Color.Navy;
            this.BorderColor = Color.Black;
        }

        protected override void DrawBackground()
        {
            Paint.FilledRectangle(this.AbsoluteRectangle, this.BackgroundColor);
            if (!m_VerticalBar)
                Paint.FilledRectangle(this.AbsoluteX, this.AbsoluteY, this.Width / m_Max * m_Value, this.Height, this.Tint);
            else
                Paint.FilledRectangle(this.AbsoluteX, this.AbsoluteY + this.Height - m_Value / m_Max * this.Height, this.Width, this.Height / m_Max * m_Value, this.Tint);
            Paint.Rectangle(this.AbsoluteRectangle, this.BorderColor);
        }

        private bool m_VerticalBar = false;
        public bool VerticalBar
        {
            get { return m_VerticalBar; }
            set{ m_VerticalBar = value; }
        }

        private float m_Max = 100f;
        public float Max
        {
            get { return m_Max; }
            set
            {
                if (m_Max > 0f)
                {
                    m_Max = value;
                    Value = m_Value;
                }
            }
        }
        private float m_Value = 0f;
        public float Value
        {
            get { return m_Value; }
            set
            {
                if (value > m_Max)
                    m_Value = m_Max;
                else if (value < 0f)
                    m_Value = 0f;
                else
                    m_Value = value; 
            }
        }
    }
}
