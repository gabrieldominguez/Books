#include <stdio.h>
#include "device.h"
#include "globals.h"

void
text_init(device* this)
{
}

void
text_clear(device* this)
{
}

void
text_exit(device* this)
{
}

int
text_getch(device* this)
{
  return getchar();
}

void
text_line(device* this, int x1, int y1, int x2, int y2)
{
  printf("line %4.4x %4.4x %4.4x %4.4x\n",x1,y1,x2,y2);
}

void
text_spline(device* this,
	    int x1, int y1, int x2, int y2, 
	    int x3, int y3, int x4, int y4)
{
  printf("spline %4.4x %4.4x %4.4x %4.4x %4.4x %4.4x %4.4x %4.4x\n",
	 x1,y1,x2,y2,x3,y3,x4,y4);
}

device dev_text=
{
  text_init,
  text_clear,
  text_exit,
  text_getch,
  text_line,
  text_spline
};

