Attribute VB_Name = "glxDebug"
Option Explicit

'-------------------------------------------------------------------------
'FUNCTION: debug routines
'AUTHOR: edx - edx@hk.super.net, Jan 99
'HISTORY:
'-------------------------------------------------------------------------

'---------------------------------------------------------------------------------
'these 2 are in case I decide to raise errors from the ocx
'---------------------------------------------------------------------------------
Private Function GetErrorTextFromResource$(ErrorNum As Long)
Dim strMsg As String
On Error GoTo GetErrorTextFromResourceError
      GetErrorTextFromResource = LoadResString(ErrorNum)
      Exit Function
GetErrorTextFromResourceError:
      If Err.Number <> 0 Then
            GetErrorTextFromResource = "An unknown error has occurred!"
      End If
End Function

'---------------------------------------------------------------------------------
Public Sub RaiseError(ErrorNumber As Long, Source As String)
Dim strErrorText As String
'there are a number of methods for retrieving the error
'message.  The following method uses a resource file to
'retrieve strings indexed by the error number you are
'raising.
strErrorText = GetErrorTextFromResource(ErrorNumber)
'raise an error back to the client
If RaiseErrors Then
Err.Raise vbObjectError + ErrorNumber, Source, strErrorText
Else
Debug.Print vbObjectError + ErrorNumber, Source, strErrorText
Debug.Assert 0
End If
End Sub

'---------------------------------------------------------------------------------
'returns the current GL matrix
'in column major order
'---------------------------------------------------------------------------------
Public Function DumpGLMatrix$()
Dim m!(0 To 15)
Dim i&, s$, f$
    glGetFloatv GL_MODELVIEW_MATRIX, m(0)
    f = "0.000"
    For i = 0 To 3
        s = s & Format(m(i), f) & "  " _
            & Format(m(i + 4), f) & "  " _
            & Format(m(i + 8), f) & "  " _
            & Format(m(i + 12), f) & vbCrLf
    Next
    Debug.Print s
    DumpGLMatrix = s
End Function

'---------------------------------------------------------------------------------
Public Function GetImplementationInfo$()
Dim s$, f!, fv!(0 To 3)
s = "Maximum stack depths" & vbCrLf
glGetFloatv glgMaxAttribStackDepth, f
s = s & "Attribute: " & f & vbCrLf
glGetFloatv glgMaxClientAttribStackDepth, f
s = s & "Client Attribute: " & f & vbCrLf
glGetFloatv glgMaxModelViewStackDepth, f
s = s & "ModelView: " & f & vbCrLf
glGetFloatv glgMaxNameStackDepth, f
s = s & "Name: " & f & vbCrLf
glGetFloatv glgMaxProjectionStackDepth, f
s = s & "Projection: " & f & vbCrLf
glGetFloatv glgMaxTextureStackDepth, f
s = s & "Texture: " & f & vbCrLf
'
s = s & vbCrLf & "Other maxima: " & vbCrLf
glGetFloatv glgMaxClipPlanes, f
s = s & "ClipPlanes: " & f & vbCrLf
glGetFloatv glgMaxEvalOrder, f
s = s & "EvalOrder: " & f & vbCrLf
glGetFloatv glgMaxLights, f
s = s & "Lights: " & f & vbCrLf
glGetFloatv glgMaxListNesting, f
s = s & "ListNesting: " & f & vbCrLf
glGetFloatv glgMaxPixelMapTable, f
s = s & "PixelMapTable: " & f & vbCrLf
glGetFloatv glgMaxTextureSize, f
s = s & "TextureSize: " & f & vbCrLf
glGetFloatv glgMaxViewportDims, fv(0)
s = s & "ViewportDims: " & fv(0) & "x" & fv(1) & vbCrLf



GetImplementationInfo$ = s
End Function

'---------------------------------------------------------------------------------
Public Function GetGLInfo$()
Dim s$, p&, s2$, s3$, pos1&, pos2&, s4$
p = glGetString(szVendor)
s = "Vendor: " & GetGLString(p) & vbCrLf
p = glGetString(szVersion)
s = s & "Version: " & GetGLString(p) & vbCrLf
p = glGetString(szRenderer)
s = s & "Renderer: " & GetGLString(p) & vbCrLf
p = glGetString(szExtensions)
s2 = GetGLString(p)
pos1 = 1
Do
    pos2 = InStr(pos1, s2, " ")
    If pos2 > pos1 Then
        s3 = Mid$(s2, pos1, pos2 - pos1)
        s4 = s4 & vbCrLf & s3
        pos1 = pos2 + 1
    Else
        s3 = Mid$(s2, pos1)
        s4 = s4 & vbCrLf & s3
        Exit Do
    End If
Loop While pos1 < Len(s2)
s = s & "Extensions: " & s4 & vbCrLf
GetGLInfo = s
End Function

'---------------------------------------------------------------------------------
Public Function GetGLString$(ByVal ptr&)
Dim s$, char As Byte
On Error Resume Next
Do
    CopyToByteFromPtr char, ptr, 1
    If char = 0 Then Exit Do
    '
    s = s & Chr$(char)
    ptr = ptr + 1
Loop
GetGLString$ = s
End Function

'------------------------------------------------------------------------------------
'don't clear it, just return one
Public Sub CheckError()
Dim s$
    s = UC.GetErr
    If Len(s) Then
        Debug.Print s
        Debug.Assert 0
    End If
End Sub

'------------------------------------------------------------------------------------
'Lighting State Variables
Public Function DumpLighting$()
Dim r&, iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$
    s = "Lighting:============================"
'GL_LIGHTING
    'Description: True if lighting is enabled
    s = s & vbCrLf & Out("GL_LIGHTING", glIsEnabled(GL_LIGHTING))
'GL_COLOR_MATERIAL
    'Description: True if color tracking is enabled
    s = s & vbCrLf & Out("GL_COLOR_MATERIAL", glIsEnabled(GL_COLOR_MATERIAL))
'GL_COLOR_MATERIAL_PARAMETER
    'Description: The params parameter returns one value: a symbolic
    'constant indicating which material parameters are tracking the current color.
    'Initial value: GL_AMBIENT_AND_DIFFUSE
    glGetIntegerv GL_COLOR_MATERIAL_PARAMETER, iv(0)
    s = s & vbCrLf & Out("GL_COLOR_MATERIAL_PARAMETER", dbGetString(iv(0)))
'GL_COLOR_MATERIAL_FACE
    'Description: Face(s) affected by color tracking
    'Initial value: GL_FRONT_AND_BACK
     glGetIntegerv GL_COLOR_MATERIAL_FACE, iv(0)
    s = s & vbCrLf & Out("GL_COLOR_MATERIAL_FACE", dbGetString(iv(0)))
'GL_AMBIENT
    'Description: Ambient material color
    'Initial value: (0.2, 0.2, 0.2, 1.0)
    glGetMaterialfv GL_FRONT, GL_AMBIENT, v(0)
    s = s & vbCrLf & Out4fv("GL_AMBIENT", v)
'GL_DIFFUSE
    'Description: Diffuse material color
    'Initial value: (0.8, 0.8, 0.8, 1.0)
    glGetMaterialfv GL_FRONT, GL_DIFFUSE, v(0)
    s = s & vbCrLf & Out4fv("GL_DIFFUSE", v)
'GL_SPECULAR
    'Description: Specular material color
    'Initial value: (0.0, 0.0, 0.0, 1.0)
    glGetMaterialfv GL_FRONT, GL_SPECULAR, v(0)
    s = s & vbCrLf & Out4fv("GL_SPECULAR", v)
'GL_EMISSION
    'Description: Emissive material color
    'Initial value: (0.0, 0.0, 0.0, 1.0)
    glGetMaterialfv GL_FRONT, GL_EMISSION, v(0)
    s = s & vbCrLf & Out4fv("GL_EMISSION", v)
'GL_SHININESS
    'Description: Specular exponent of material
    'Initial value: 0.0
    glGetMaterialfv GL_FRONT, GL_SHININESS, v(0)
    s = s & vbCrLf & Out4fv("GL_SHININESS", v)
'GL_COLOR_INDEXES
    'Description: C (a) , C (d) , and C (s) for color-index lighting
    'Initial value: 0, 1, 1
    glGetMaterialfv GL_FRONT, mpmColorIndexes, v(0)
    s = s & vbCrLf & Out3fv("GL_COLOR_INDEXES", v)
'GL_LIGHT_MODEL_Ambient
    'Description: Ambient scene color
    'Initial value: (0.2, 0.2, 0.2, 0.1)
    glGetFloatv GL_LIGHT_MODEL_Ambient, v(0)
    s = s & vbCrLf & Out4fv("GL_LIGHT_MODEL_Ambient", v)
'GL_LIGHT_MODEL_LOCAL_VIEWER
    'Description: Viewer is local
    'Initial value: GL_FALSE
    glGetBooleanv GL_LIGHT_MODEL_LOCAL_VIEWER, bv(0)
    s = s & vbCrLf & Out("GL_LIGHT_MODEL_LOCAL_VIEWER", iv(0))
'GL_LIGHT_MODEL_TWO_SIDE
    'Description: Use two-sided lighting
    'Initial value: GL_FALSE
    glGetBooleanv GL_LIGHT_MODEL_TWO_SIDE, bv(0)
    s = s & vbCrLf & Out("GL_LIGHT_MODEL_TWO_SIDE", iv(0))
    DumpLighting = s
End Function

'------------------------------------------------------------------------------------
'Light State Variables
Public Function DumpLights$()
Dim r&, iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$
'---------------------------------------------------
    s = "Lights:=============================="
'dump each light
    For i = 0 To 7
        s = s & vbCrLf & "Light" & i & ":***************"
    'GL_AMBIENT
        'Description: Ambient intensity of light i
        'Initial value: (0.0, 0.0, 0.0, 1.0)
        glGetLightfv ltLight0 + i, GL_AMBIENT, v(0)
        s = s & vbCrLf & Out4fv("GL_AMBIENT", v)
    'GL_DIFFUSE
        'Description: Diffuse intensity of light i
        'Get command: glGetLightfv
        glGetLightfv ltLight0 + i, GL_DIFFUSE, v(0)
        s = s & vbCrLf & Out4fv("GL_DIFFUSE", v)
    'GL_SPECULAR
    'Description: Specular intensity of light i
        glGetLightfv ltLight0 + i, GL_SPECULAR, v(0)
        s = s & vbCrLf & Out4fv("GL_SPECULAR", v)
    'GL_POSITION
        'Description: Position of light i
        'Initial value: (0.0, 0.0, 1.0, 0.0)
        glGetLightfv ltLight0 + i, GL_POSITION, v(0)
        s = s & vbCrLf & Out4fv("GL_POSITION", v)
    'GL_CONSTANT_ATTENUATION
        'Description: Constant attenuation factor
        'Initial value: 1.0
        glGetLightfv ltLight0 + i, GL_CONSTANT_ATTENUATION, v(0)
        s = s & vbCrLf & Out4fv("GL_CONSTANT_ATTENUATION", v)
    'GL_LINEAR_ATTENUATION
        'Description: Linear attenuation factor
        'Initial value: 0.0
        glGetLightfv ltLight0 + i, GL_LINEAR_ATTENUATION, v(0)
        s = s & vbCrLf & Out4fv("GL_LINEAR_ATTENUATION", v)
    'GL_QUADRATIC_ATTENUATION
        'Description: Quadratic attenuation factor
        'Initial value: 0.0
        glGetLightfv ltLight0 + i, GL_QUADRATIC_ATTENUATION, v(0)
        s = s & vbCrLf & Out4fv("GL_QUADRATIC_ATTENUATION", v)
    'GL_SPOT_DIRECTION
        'Description: Spotlight direction of light i
        'Initial value: (0.0, 0.0, �1.0)
        glGetLightfv ltLight0 + i, GL_SPOT_DIRECTION, v(0)
        s = s & vbCrLf & Out3fv("GL_SPOT_DIRECTION", v)
    'GL_SPOT_EXPONENT
        'Description: Spotlight exponent of light i
        'Initial value: 0.0
        glGetLightfv ltLight0 + i, GL_SPOT_EXPONENT, v(0)
        s = s & vbCrLf & Out("GL_SPOT_EXPONENT", v(0))
    'GL_SPOT_CUTOFF
        'Description: Spotlight angle of light i
        'Initial value: 180.0
        glGetLightfv ltLight0 + i, GL_SPOT_CUTOFF, v(0)
        s = s & vbCrLf & Out("GL_SPOT_CUTOFF", v(0))
    'GL_LIGHTi
        'Description: True if light i enabled
        'Initial value: GL_FALSE
         s = s & vbCrLf & Out("ENABLED", glIsEnabled(GL_LIGHT0 + 1))
    Next
    DumpLights = s
End Function

'------------------------------------------------------------------------------------
'Current State Variables
Public Function DumpCurrent$()
Dim r&, iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$
    s = "Current values:========================="
'GL_CURRENT_COLOR
    'Initial value: 1,1,1,1
    glGetFloatv GL_CURRENT_COLOR, v(0)
    s = s & vbCrLf & Out4fv("GL_CURRENT_COLOR", v)
'GL_CURRENT_INDEX
    'Description: Current color index
    'Initial value: 1
    glGetIntegerv GL_CURRENT_INDEX, iv(0)
    s = s & vbCrLf & Out("GL_CURRENT_INDEX", v(0))
'GL_CURRENT_TEXTURE_COORDS
    'Description: Current texture coordinates
    'Initial value: 0,0,0,1
    glGetFloatv GL_CURRENT_TEXTURE_COORDS, v(0)
    s = s & vbCrLf & Out2fv("GL_CURRENT_TEXTURE_COORDS", v)
'GL_CURRENT_NORMAL
    'Description: Current Normal
    'Initial value: 0,0,1
    glGetFloatv GL_CURRENT_NORMAL, v(0)
    s = s & vbCrLf & Out3fv("GL_CURRENT_NORMAL", v)
'GL_CURRENT_RASTER_POSITION
    'Description: Current raster position
    'Initial value: 0,0,0,1
    glGetFloatv GL_CURRENT_RASTER_POSITION, v(0)
    s = s & vbCrLf & Out4fv("GL_CURRENT_RASTER_POSITION", v)
'GL_CURRENT_RASTER_DISTANCE
    'Description: Current raster distance
    'Initial value: 0
    glGetFloatv GL_CURRENT_RASTER_DISTANCE, v(0)
    s = s & vbCrLf & Out("GL_CURRENT_RASTER_DISTANCE", v(0))
'GL_CURRENT_RASTER_COLOR
    'Description: Color associated with raster position
    'Initial value: 1,1,1,1
    glGetFloatv GL_CURRENT_RASTER_COLOR, v(0)
    s = s & vbCrLf & Out4fv("GL_CURRENT_RASTER_COLOR", v)
'GL_CURRENT_RASTER_INDEX
    'Description: Color index associated with raster position
    'Initial value: 1
    glGetIntegerv GL_CURRENT_RASTER_INDEX, iv(0)
    s = s & vbCrLf & Out("GL_CURRENT_RASTER_INDEX", iv(0))
'GL_CURRENT_RASTER_TEXTURE_COORDS
    'Description: Texture coordinates associated with raster position
    'Initial value: 0,0,0,1
    glGetFloatv GL_CURRENT_RASTER_TEXTURE_COORDS, v(0)
    s = s & vbCrLf & Out4fv("GL_CURRENT_RASTER_TEXTURE_COORDS", v)
'GL_CURRENT_RASTER_POSITION_VALID
    'Description: Raster position valid bit
    'Initial value: GL_TRUE
    glGetBooleanv GL_CURRENT_RASTER_POSITION_VALID, bv(0)
    s = s & vbCrLf & Out("GL_CURRENT_RASTER_POSITION_VALID", bv(0))
'GL_EDGE_FLAG
    'Description: Edge flag
    'Initial value: GL_TRUE
    glGetBooleanv GL_EDGE_FLAG, bv(0)
    s = s & vbCrLf & Out("GL_EDGE_FLAG", bv(0))
    DumpCurrent = s
End Function

'------------------------------------------------------------------------------------
'Raster State Variables
Public Function DumpRaster$()
Dim r&, iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$
    s = "Raster:========================="
''GL_POINT_SIZE
    'Description: Point Size
    'Initial value: 1.0
    glGetFloatv GL_POINT_SIZE, v(0)
    s = s & vbCrLf & Out("GL_POINT_SIZE", v(0))
'GL_POINT_SMOOTH
    'Description: Point aliasing on
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_POINT_SMOOTH", glIsEnabled(GL_POINT_SMOOTH))
'GL_LINE_WIDTH
    'Description: Line width
    'Initial value: 1.0
    glGetFloatv GL_LINE_WIDTH, v(0)
    s = s & vbCrLf & Out("GL_LINE_WIDTH", v(0))
'GL_LINE_SMOOTH
    'Description: Line antialiasing on
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_LINE_SMOOTH", glIsEnabled(GL_LINE_SMOOTH))
'GL_LINE_STIPPLE_PATTERN
    'Description: Line stipple
    'Initial value: 1's
    glGetIntegerv GL_LINE_STIPPLE_PATTERN, iv(0)
    s = s & vbCrLf & OutHex("GL_LINE_STIPPLE_PATTERN", iv(0))
'GL_LINE_STIPPLE_REPEAT
    'Description: Line stipple repeat
    'Initial value: 1
    glGetIntegerv GL_LINE_STIPPLE_REPEAT, iv(0)
    s = s & vbCrLf & Out("GL_LINE_STIPPLE_REPEAT", iv(0))
'GL_LINE_STIPPLE
    'Description: Line stipple enable
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_LINE_STIPPLE", glIsEnabled(GL_LINE_STIPPLE))
'GL_CULL_FACE
    'Description: Polygon culling enabled
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_CULL_FACE", glIsEnabled(GL_CULL_FACE))
'GL_CULL_FACE_MODE
    'Description: Cull front-/back-facing polygons
    'Initial value: GL_BACK
    glGetIntegerv GL_CULL_FACE_MODE, iv(0)
    s = s & vbCrLf & Out("GL_CULL_FACE_MODE", dbGetString(iv(0)))
'GL_FRONT_FACE
    'Description: Polygon front-face CW/CCW indicator
    'Initial value: GL_CCW
    glGetIntegerv GL_FRONT_FACE, iv(0)
    s = s & vbCrLf & Out("GL_FRONT_FACE", dbGetString(iv(0)))
'GL_POLYGON_SMOOTH
    'Description: Polygon antialiasing on
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_POLYGON_SMOOTH", glIsEnabled(GL_POLYGON_SMOOTH))
'GL_POLYGON_MODE
    'Description: Polygon rasterization mode (front and back)
    'Initial value: GL_FILL
    glGetIntegerv GL_POLYGON_MODE, iv(0)
    s = s & vbCrLf & Out("GL_POLYGON_MODE", dbGetString(iv(0)))
'GL_POLYGON_STIPPLE
    'Description: Polygon stipple enable
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_POLYGON_STIPPLE", glIsEnabled(GL_POLYGON_STIPPLE))
'GL_POLYGON_STIPPLE pattern
    'Description: Polygon stipple pattern
    'Initial value: 1's
    'Get command: glGetPolygonStipple
    DumpRaster = s
End Function

'------------------------------------------------------------------------------------
'Texture Variables
Public Function DumpTexture$()
Dim r&(0), iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$, z&
'GL_TEXTURE_x
    s = "Texture:========================="
    'Description: True if x-D texturing enabled (x is 1-D or 2-D)
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_TEXTURE_1D", glIsEnabled(GL_TEXTURE_1D))
    s = s & vbCrLf & Out("GL_TEXTURE_2D", glIsEnabled(GL_TEXTURE_2D))
'GL_TEXTURE_WIDTH
    'Description: x-D texture image i's width
    'Initial value: 0
    glGetTexLevelParameterfv GL_TEXTURE_1D, 0, GL_TEXTURE_WIDTH, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WIDTH (1D,0)", v(0))
    glGetTexLevelParameterfv GL_TEXTURE_2D, 0, GL_TEXTURE_WIDTH, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WIDTH (2D,0)", v(0))
'GL_TEXTURE_HEIGHT
    'Description: x-D texture image i's height
    'Initial value: 0
    glGetTexLevelParameterfv GL_TEXTURE_1D, 0, GL_TEXTURE_HEIGHT, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_HEIGHT (1D,0)", v(0))
    glGetTexLevelParameterfv GL_TEXTURE_2D, 0, GL_TEXTURE_HEIGHT, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_HEIGHT (2D,0)", v(0))
'GL_TEXTURE_BORDER
    'Description: x-D texture image i's border
    'Initial value: 0
    glGetTexLevelParameterfv GL_TEXTURE_1D, 0, GL_TEXTURE_BORDER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_BORDER (1D,0)", v(0))
    glGetTexLevelParameterfv GL_TEXTURE_2D, 0, GL_TEXTURE_BORDER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_BORDER (2D,0)", v(0))
'GL_TEXTURE_COMPONENTS
    'Description: Texture image components
    'Initial value: 1
    glGetTexLevelParameterfv GL_TEXTURE_1D, 0, GL_TEXTURE_INTERNAL_FORMAT, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_COMPONENTS (1D,0)", v(0))
    glGetTexLevelParameterfv GL_TEXTURE_2D, 0, GL_TEXTURE_INTERNAL_FORMAT, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_COMPONENTS (2D,0)", v(0))
'GL_TEXTURE_BORDER_COLOR
    'Description: Texture border color
    'Initial value: 0,0,0,0
    glGetTexParameterfv GL_TEXTURE_1D, GL_TEXTURE_BORDER_COLOR, v(0)
    s = s & vbCrLf & Out4fv("GL_TEXTURE_BORDER_COLOR 1D", v)
    glGetTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, v(0)
    s = s & vbCrLf & Out4fv("GL_TEXTURE_BORDER_COLOR 2D", v)
'GL_TEXTURE_MIN_FILTER
    'Description: Texture minification function
    'Initial value: GL_NEAREST_MIPMAP_LINEAR
    glGetTexParameterfv GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_MIN_FILTER 1D", dbGetString(CLng(v(0))))
    glGetTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_MIN_FILTER 2D", dbGetString(CLng(v(0))))
'GL_TEXTURE_MAG_FILTER
    'Description: Texture magnification function
    'Initial value: GL_LINEAR
    glGetTexParameterfv GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_MAG_FILTER 1D", dbGetString(CLng(v(0))))
    glGetTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_MAG_FILTER 2D", dbGetString(CLng(v(0))))
'GL_TEXTURE_WRAP_x
    'Description: Texture wrap mode (x is S or T)
    'Initial value: GL_REPEAT
    'Get command: glGetTexParameter
    glGetTexParameterfv GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WRAP_S 1D", dbGetString(CLng(v(0))))
    glGetTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WRAP_S 2D", dbGetString(CLng(v(0))))
    glGetTexParameterfv GL_TEXTURE_1D, GL_TEXTURE_WRAP_T, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WRAP_T 1D", dbGetString(CLng(v(0))))
    glGetTexParameterfv GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_WRAP_T 2D", dbGetString(CLng(v(0))))
'GL_TEXTURE_ENV_MODE
'CheckError
    'Description: Texture application function
    'Initial value: GL_MODULATE
    glGetTexEnviv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, z 'r(0) 'v(0)
'CheckError
    s = s & vbCrLf & Out("GL_TEXTURE_ENV_MODE 1D", dbGetString(z)) 'CLng(v(0))))
    glGetTexEnviv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, z 'r(0) 'v(0)
'CheckError
    s = s & vbCrLf & Out("GL_TEXTURE_ENV_MODE 2D", dbGetString(z)) 'CLng(v(0))))
'GL_TEXTURE_ENV_COLOR
    'Description: Texture environment color
    'Initial value: 0,0,0,0
    glGetTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, v(0)
    s = s & vbCrLf & Out4fv("GL_TEXTURE_ENV_COLOR 1D", v)
    glGetTexEnvfv GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, v(0)
    s = s & vbCrLf & Out4fv("GL_TEXTURE_ENV_COLOR 2D", v)
'CheckError
'GL_TEXTURE_GEN_x
    'Description: Texgen is enabled (x is S, T, R, or Q)
    'Initial value: GL_FALSE
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_S", glIsEnabled(GL_TEXTURE_GEN_S))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_T", glIsEnabled(GL_TEXTURE_GEN_T))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_R", glIsEnabled(GL_TEXTURE_GEN_R))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_Q", glIsEnabled(GL_TEXTURE_GEN_Q))
'GL_EYE_LINEAR
    'Description: Texgen plane equation coefficients
    'Initial value: �
    glGetTexGenfv GL_S, GL_EYE_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_EYE_PLANE S", v)
    glGetTexGenfv GL_T, GL_EYE_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_EYE_PLANE T", v)
    glGetTexGenfv GL_R, GL_EYE_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_EYE_PLANE R", v)
    glGetTexGenfv GL_Q, GL_EYE_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_EYE_PLANE Q", v)
'GL_OBJECT_LINEAR
    'Description: Texgen object linear coefficients
    'Initial value: �
    glGetTexGenfv GL_S, GL_OBJECT_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_OBJECT_PLANE S", v)
    glGetTexGenfv GL_T, GL_OBJECT_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_OBJECT_PLANE T", v)
    glGetTexGenfv GL_R, GL_OBJECT_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_OBJECT_PLANE R", v)
    glGetTexGenfv GL_Q, GL_OBJECT_PLANE, v(0)
    s = s & vbCrLf & Out4fv("GL_OBJECT_PLANE Q", v)
'GL_TEXTURE_GEN_MODE
    'Description: Function used for texgen
    'Initial value: GL_EYE_LINEAR
    glGetTexGenfv GL_S, GL_TEXTURE_GEN_MODE, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_MODE S", dbGetString(CLng(v(0))))
    glGetTexGenfv GL_T, GL_TEXTURE_GEN_MODE, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_MODE T", dbGetString(CLng(v(0))))
    glGetTexGenfv GL_R, GL_TEXTURE_GEN_MODE, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_MODE R", dbGetString(CLng(v(0))))
    glGetTexGenfv GL_Q, GL_TEXTURE_GEN_MODE, v(0)
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_MODE Q", dbGetString(CLng(v(0))))
    DumpTexture = s
End Function

 
'------------------------------------------------------------------------------------
'Enabled State Variables
Public Function DumpEnabled$()
Dim r&, iv&(0 To 3), v!(0 To 3), bv(0 To 3) As GLboolean
Dim i&, s$
    s = "Enabled:==============================="
    s = s & vbCrLf & Out("GL_ALPHA_TEST", glIsEnabled(GL_ALPHA_TEST))
    s = s & vbCrLf & Out("GL_ALPHA_TEST ", glIsEnabled(GL_ALPHA_TEST))
    s = s & vbCrLf & Out("GL_AUTO_NORMAL", glIsEnabled(GL_AUTO_NORMAL))
    s = s & vbCrLf & Out("GL_BLEND", glIsEnabled(GL_BLEND))
    's=s & Out( "GL_CLIP_PLANEi", glIsEnabled()
    s = s & vbCrLf & Out("GL_COLOR_MATERIAL", glIsEnabled(GL_COLOR_MATERIAL))
    s = s & vbCrLf & Out("GL_CULL_FACE", glIsEnabled(GL_CULL_FACE))
    s = s & vbCrLf & Out("GL_DEPTH_TEST", glIsEnabled(GL_DEPTH_TEST))
    s = s & vbCrLf & Out("GL_DITHER", glIsEnabled(GL_DITHER))
    s = s & vbCrLf & Out("GL_FOG", glIsEnabled(GL_FOG))
    's=s & Out( "GL_LIGHTi", glIsEnabled()
    s = s & vbCrLf & Out("GL_LIGHTING", glIsEnabled(GL_LIGHTING))
    s = s & vbCrLf & Out("GL_LINE_SMOOTH", glIsEnabled(GL_LINE_SMOOTH))
    s = s & vbCrLf & Out("GL_LINE_STIPPLE", glIsEnabled(GL_LINE_STIPPLE))
    s = s & vbCrLf & Out("GL_LOGIC_OP", glIsEnabled(GL_LOGIC_OP))
    s = s & vbCrLf & Out("GL_MAP1_COLOR_4", glIsEnabled(GL_MAP1_COLOR_4))
    s = s & vbCrLf & Out("GL_MAP1_INDEX", glIsEnabled(GL_MAP1_INDEX))
    s = s & vbCrLf & Out("GL_MAP1_NORMAL", glIsEnabled(GL_MAP1_NORMAL))
    s = s & vbCrLf & Out("GL_MAP1_TEXTURE_COORD_1", glIsEnabled(GL_MAP1_TEXTURE_COORD_1))
    s = s & vbCrLf & Out("GL_MAP1_TEXTURE_COORD_2", glIsEnabled(GL_MAP1_TEXTURE_COORD_2))
    s = s & vbCrLf & Out("GL_MAP1_TEXTURE_COORD_3", glIsEnabled(GL_MAP1_TEXTURE_COORD_3))
    s = s & vbCrLf & Out("GL_MAP1_TEXTURE_COORD_4", glIsEnabled(GL_MAP1_TEXTURE_COORD_4))
    s = s & vbCrLf & Out("GL_MAP1_VERTEX_3", glIsEnabled(GL_MAP1_VERTEX_3))
    s = s & vbCrLf & Out("GL_MAP1_VERTEX_4", glIsEnabled(GL_MAP1_VERTEX_4))
    s = s & vbCrLf & Out("GL_MAP2_COLOR_4", glIsEnabled(GL_MAP2_COLOR_4))
    s = s & vbCrLf & Out("GL_MAP2_INDEX", glIsEnabled(GL_MAP2_INDEX))
    s = s & vbCrLf & Out("GL_MAP2_NORMAL", glIsEnabled(GL_MAP2_NORMAL))
    s = s & vbCrLf & Out("GL_MAP2_TEXTURE_COORD_1", glIsEnabled(GL_MAP2_TEXTURE_COORD_1))
    s = s & vbCrLf & Out("GL_MAP2_TEXTURE_COORD_2", glIsEnabled(GL_MAP2_TEXTURE_COORD_2))
    s = s & vbCrLf & Out("GL_MAP2_TEXTURE_COORD_3", glIsEnabled(GL_MAP2_TEXTURE_COORD_3))
    s = s & vbCrLf & Out("GL_MAP2_TEXTURE_COORD_4", glIsEnabled(GL_MAP2_TEXTURE_COORD_4))
    s = s & vbCrLf & Out("GL_MAP2_VERTEX_3", glIsEnabled(GL_MAP2_VERTEX_3))
    s = s & vbCrLf & Out("GL_MAP2_VERTEX_4", glIsEnabled(GL_MAP2_VERTEX_4))
    s = s & vbCrLf & Out("GL_NORMALIZE", glIsEnabled(GL_NORMALIZE))
    s = s & vbCrLf & Out("GL_POINT_SMOOTH", glIsEnabled(GL_POINT_SMOOTH))
    s = s & vbCrLf & Out("GL_POLYGON_SMOOTH", glIsEnabled(GL_POLYGON_SMOOTH))
    s = s & vbCrLf & Out("GL_POLYGON_STIPPLE", glIsEnabled(GL_POLYGON_STIPPLE))
    s = s & vbCrLf & Out("GL_SCISSOR_TEST", glIsEnabled(GL_SCISSOR_TEST))
    s = s & vbCrLf & Out("GL_STENCIL_TEST", glIsEnabled(GL_STENCIL_TEST))
    s = s & vbCrLf & Out("GL_TEXTURE_1D", glIsEnabled(GL_TEXTURE_1D))
    s = s & vbCrLf & Out("GL_TEXTURE_2D", glIsEnabled(GL_TEXTURE_2D))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_Q", glIsEnabled(GL_TEXTURE_GEN_Q))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_R", glIsEnabled(GL_TEXTURE_GEN_R))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_S", glIsEnabled(GL_TEXTURE_GEN_S))
    s = s & vbCrLf & Out("GL_TEXTURE_GEN_T", glIsEnabled(GL_TEXTURE_GEN_T))
    DumpEnabled = s
End Function

'------------------------------------------------------------------------------------
Private Function Out$(Name$, ParamArray values())
Dim s$, v
    s = Name & ": "
    For Each v In values
        s = s & Format(v)
    Next
    Out = s
End Function

'------------------------------------------------------------------------------------
Private Function OutHex$(Name$, ParamArray values())
Dim s$, v
    s = Name & ": "
    For Each v In values
        s = s & "&H" & Hex(v)
    Next
    OutHex = s
End Function

Private Function Out4fv$(Name$, v!())
Dim s$, i&
    s = Name & ": "
    For i = 0 To 3
        s = s & str(v(i)) & ","
    Next
    Out4fv = s
End Function

Private Function Out3fv$(Name$, v!())
Dim s$, i&
    s = Name & ": "
    For i = 0 To 2
        s = s & str(v(i)) & ","
    Next
    Out3fv = s
End Function

Private Function Out2fv$(Name$, v!())
Dim s$, i&
    s = Name & ": "
    For i = 0 To 1
        s = s & str(v(i)) & ","
    Next
    Out2fv = s
End Function

'------------------------------------------------------------------------------------
Private Function dbGetString$(ID&)
Dim s$
Select Case ID
'Case GL_VERSION_1_1: s = "" '1
Case GL_ZERO: s = "GL_ZERO" '  0
Case GL_ONE: s = "GL_ONE" '   1
' Boolean */
'Case GL_TRUE: s = "" '  1
'Case GL_FALSE: s = "" ' 0
'Case GL_NONE: s = "" '  0
' ClientAttribMask */
'Case GL_CLIENT_PIXEL_STORE_BIT: s = "" '  &H00000001
'Case GL_CLIENT_VERTEX_ARRAY_BIT: s = "" ' &H00000002
'Case GL_CLIENT_ALL_ATTRIB_BITS: s = "" '  &Hffffffff
'0100-------------------------------------------------------
' AccumOp */
Case GL_ACCUM: s = "GL_ACCUM" ' &H0100
Case GL_LOAD: s = "GL_LOAD" '  &H0101
Case GL_RETURN: s = "GL_RETURN" '&H0102
Case GL_MULT: s = "GL_MULT" '  &H0103
Case GL_ADD: s = "GL_ADD" '   &H0104
'0200-------------------------------------------------------
' AlphaFunction */
Case GL_NEVER: s = "GL_NEVER" ' &H0200
Case GL_LESS: s = "GL_LESS" '  &H0201
Case GL_EQUAL: s = "GL_EQUAL" ' &H0202
Case GL_LEQUAL: s = "GL_LEQUAL" '&H0203
Case GL_GREATER: s = "GL_GREATER" '       &H0204
Case GL_NOTEQUAL: s = "GL_NOTEQUAL" '      &H0205
Case GL_GEQUAL: s = "GL_GEQUAL" '&H0206
Case GL_ALWAYS: s = "GL_ALWAYS" '&H0207
'0300-------------------------------------------------------
' BlendingFactorDest */
Case GL_SRC_COLOR: s = "GL_SRC_COLOR" '                     &H0300
Case GL_ONE_MINUS_SRC_COLOR: s = "GL_ONE_MINUS_SRC_COLOR" '     &H0301
Case GL_SRC_ALPHA: s = "GL_SRC_ALPHA"        '              &H0302
Case GL_ONE_MINUS_SRC_ALPHA: s = "GL_ONE_MINUS_SRC_ALPHA" '     &H0303
Case GL_DST_ALPHA: s = "GL_DST_ALPHA" '           &H0304
Case GL_ONE_MINUS_DST_ALPHA: s = "GL_ONE_MINUS_DST_ALPHA" '     &H0305
Case GL_DST_COLOR: s = "GL_DST_COLOR" '           &H0306
Case GL_ONE_MINUS_DST_COLOR: s = "GL_ONE_MINUS_DST_COLOR" '     &H0307
Case GL_SRC_ALPHA_SATURATE: s = "GL_SRC_ALPHA_SATURATE" '   &H0308
'0400-------------------------------------------------------
' DrawBufferMode */
Case GL_FRONT_LEFT: s = "GL_FRONT_LEFT" '    &H0400
Case GL_FRONT_RIGHT: s = "GL_FRONT_RIGHT" '   &H0401
Case GL_BACK_LEFT: s = "GL_BACK_LEFT"        '        &H0402
Case GL_BACK_RIGHT: s = "GL_BACK_RIGHT" '    &H0403
Case GL_FRONT: s = "GL_FRONT" ' &H0404
Case GL_BACK: s = "GL_BACK"        '   &H0405
Case GL_LEFT: s = "GL_LEFT" '  &H0406
Case GL_RIGHT: s = "GL_RIGHT" ' &H0407
Case GL_FRONT_AND_BACK: s = "GL_FRONT_AND_BACK" '&H0408
Case GL_AUX0: s = "GL_AUX0" '  &H0409
Case GL_AUX1: s = "GL_AUX1" '  &H040A
Case GL_AUX2: s = "GL_AUX2" '  &H040B
Case GL_AUX3: s = "GL_AUX3" '  &H040C
'0500-------------------------------------------------------
' ErrorCode */
Case GL_NO_ERROR: s = "GL_NO_ERROR" '      0
Case GL_INVALID_ENUM: s = "GL_INVALID_ENUM" '  &H0500
Case GL_INVALID_VALUE: s = "GL_INVALID_VALUE"        '    &H0501
Case GL_INVALID_OPERATION: s = "GL_INVALID_OPERATION"        '&H0502
Case GL_STACK_OVERFLOW: s = "GL_STACK_OVERFLOW"        '   &H0503
Case GL_STACK_UNDERFLOW: s = "GL_STACK_UNDERFLOW"        '  &H0504
Case GL_OUT_OF_MEMORY: s = "GL_OUT_OF_MEMORY" ' &H0505
'0600-------------------------------------------------------
' FeedBackMode */
Case GL_2D: s = "GL_2D" '    &H0600
Case GL_3D: s = "GL_3D" '    &H0601
Case GL_3D_COLOR: s = "GL_3D_COLOR" '      &H0602
Case GL_3D_COLOR_TEXTURE: s = "GL_3D_COLOR_TEXTURE" '        &H0603
Case GL_4D_COLOR_TEXTURE: s = "GL_4D_COLOR_TEXTURE" '        &H0604
'0700-------------------------------------------------------
' FeedBackToken */
Case GL_PASS_THROUGH_TOKEN: s = "GL_PASS_THROUGH_TOKEN" '      &H0700
Case GL_POINT_TOKEN: s = "GL_POINT_TOKEN"        '      &H0701
Case GL_LINE_TOKEN: s = "GL_LINE_TOKEN"        '       &H0702
Case GL_POLYGON_TOKEN: s = "GL_POLYGON_TOKEN" ' &H0703
Case GL_BITMAP_TOKEN: s = "GL_BITMAP_TOKEN" '  &H0704
Case GL_DRAW_PIXEL_TOKEN: s = "GL_DRAW_PIXEL_TOKEN" '        &H0705
Case GL_COPY_PIXEL_TOKEN: s = "GL_COPY_PIXEL_TOKEN" '        &H0706
Case GL_LINE_RESET_TOKEN: s = "GL_LINE_RESET_TOKEN" '        &H0707
'0800-------------------------------------------------------
' FogMode */
Case GL_EXP: s = "GL_EXP" '   &H0800
Case GL_EXP2: s = "GL_EXP2" '  &H0801
' FrontFaceDirection */
Case GL_CW: s = "GL_CW" '    &H0900
Case GL_CCW: s = "GL_CCW" '   &H0901
'0A00-------------------------------------------------------
' GetMapTarget */
Case GL_COEFF: s = "GL_COEFF" ' &H0A00
Case GL_ORDER: s = "GL_ORDER" ' &H0A01
Case GL_DOMAIN: s = "GL_DOMAIN" '&H0A02
'0B00-------------------------------------------------------
' GetTarget */
Case GL_CURRENT_COLOR: s = "GL_CURRENT_COLOR" ' &H0B00
Case GL_CURRENT_INDEX: s = "GL_CURRENT_INDEX" ' &H0B01
Case GL_CURRENT_NORMAL: s = "GL_CURRENT_NORMAL" '&H0B02
Case GL_CURRENT_TEXTURE_COORDS: s = "GL_CURRENT_TEXTURE_COORDS" '  &H0B03
Case GL_CURRENT_RASTER_COLOR: s = "GL_CURRENT_RASTER_COLOR" '    &H0B04
Case GL_CURRENT_RASTER_INDEX: s = "GL_CURRENT_RASTER_INDEX" '    &H0B05
Case GL_CURRENT_RASTER_TEXTURE_COORDS: s = "GL_CURRENT_RASTER_TEXTURE_COORDS"  ' &H0B06
Case GL_CURRENT_RASTER_POSITION: s = "GL_CURRENT_RASTER_POSITION" ' &H0B07
Case GL_CURRENT_RASTER_POSITION_VALID: s = "GL_CURRENT_RASTER_POSITION_VALID" '  &H0B08
Case GL_CURRENT_RASTER_DISTANCE: s = "GL_CURRENT_RASTER_DISTANCE" ' &H0B09
Case GL_POINT_SMOOTH: s = "GL_POINT_SMOOTH" '  &H0B10
Case GL_POINT_SIZE: s = "GL_POINT_SIZE" '    &H0B11
Case GL_POINT_SIZE_RANGE: s = "GL_POINT_SIZE_RANGE" '        &H0B12
Case GL_POINT_SIZE_GRANULARITY: s = "GL_POINT_SIZE_GRANULARITY" '  &H0B13
Case GL_LINE_SMOOTH: s = "GL_LINE_SMOOTH" '   &H0B20
Case GL_LINE_WIDTH: s = "GL_LINE_WIDTH" '    &H0B21
Case GL_LINE_WIDTH_RANGE: s = "GL_LINE_WIDTH_RANGE" '        &H0B22
Case GL_LINE_WIDTH_GRANULARITY: s = "GL_LINE_WIDTH_GRANULARITY" '  &H0B23
Case GL_LINE_STIPPLE: s = "GL_LINE_STIPPLE" '  &H0B24
Case GL_LINE_STIPPLE_PATTERN: s = "GL_LINE_STIPPLE_PATTERN" '    &H0B25
Case GL_LINE_STIPPLE_REPEAT: s = "GL_LINE_STIPPLE_REPEAT" '     &H0B26
Case GL_LIST_MODE: s = "GL_LIST_MODE" '     &H0B30
Case GL_MAX_LIST_NESTING: s = "GL_MAX_LIST_NESTING" '        &H0B31
Case GL_LIST_BASE: s = "GL_LIST_BASE" '     &H0B32
Case GL_LIST_INDEX: s = "GL_LIST_INDEX" '    &H0B33
Case GL_POLYGON_MODE: s = "GL_POLYGON_MODE" '  &H0B40
Case GL_POLYGON_SMOOTH: s = "GL_POLYGON_SMOOTH" '&H0B41
Case GL_POLYGON_STIPPLE: s = "GL_POLYGON_STIPPLE" '         &H0B42
Case GL_EDGE_FLAG: s = "GL_EDGE_FLAG" '     &H0B43
Case GL_CULL_FACE: s = "GL_CULL_FACE" '     &H0B44
Case GL_CULL_FACE_MODE: s = "GL_CULL_FACE_MODE" '&H0B45
Case GL_FRONT_FACE: s = "GL_FRONT_FACE" '    &H0B46
Case GL_LIGHTING: s = "GL_LIGHTING" '      &H0B50
Case GL_LIGHT_MODEL_LOCAL_VIEWER: s = "GL_LIGHT_MODEL_LOCAL_VIEWER" '&H0B51
Case GL_LIGHT_MODEL_TWO_SIDE: s = "GL_LIGHT_MODEL_TWO_SIDE" '    &H0B52
Case GL_LIGHT_MODEL_Ambient: s = "GL_LIGHT_MODEL_Ambient" '     &H0B53
Case GL_SHADE_MODEL: s = "GL_SHADE_MODEL" '   &H0B54
Case GL_COLOR_MATERIAL_FACE: s = "GL_COLOR_MATERIAL_FACE"  ' &H0B55
Case GL_COLOR_MATERIAL_PARAMETER: s = "GL_COLOR_MATERIAL_PARAMETER" '&H0B56
Case GL_COLOR_MATERIAL: s = "GL_COLOR_MATERIAL" '       &H0B57
Case GL_FOG: s = "GL_FOG"  '    &H0B60
Case GL_FOG_INDEX: s = "GL_FOG_INDEX" '    &H0B61
Case GL_FOG_DENSITY: s = "GL_FOG_DENSITY"  ' &H0B62
Case GL_FOG_START: s = "GL_FOG_START" '    &H0B63
Case GL_FOG_END: s = "GL_FOG_END" ' &H0B64
Case GL_FOG_MODE: s = "GL_FOG_MODE" '      &H0B65
Case GL_FOG_COLOR: s = "GL_FOG_COLOR" '    &H0B66
Case GL_DEPTH_RANGE: s = "GL_DEPTH_RANGE" '  &H0B70
Case GL_DEPTH_TEST: s = "GL_DEPTH_TEST" '   &H0B71
Case GL_DEPTH_WRITEMASK: s = "GL_DEPTH_WRITEMASK" '      &H0B72
Case GL_DEPTH_CLEAR_VALUE: s = "GL_DEPTH_CLEAR_VALUE" '    &H0B73
Case GL_DEPTH_FUNC: s = "GL_DEPTH_FUNC" '   &H0B74
Case GL_ACCUM_CLEAR_VALUE: s = "GL_ACCUM_CLEAR_VALUE" '    &H0B80
Case GL_STENCIL_TEST: s = "GL_STENCIL_TEST" ' &H0B90
Case GL_STENCIL_CLEAR_VALUE: s = "GL_STENCIL_CLEAR_VALUE" '  &H0B91
Case GL_STENCIL_FUNC: s = "GL_STENCIL_FUNC" ' &H0B92
Case GL_STENCIL_VALUE_MASK: s = "GL_STENCIL_VALUE_MASK" '   &H0B93
Case GL_STENCIL_FAIL: s = "GL_STENCIL_FAIL" ' &H0B94
Case GL_STENCIL_PASS_DEPTH_FAIL: s = "GL_STENCIL_PASS_DEPTH_FAIL" ' &H0B95
Case GL_STENCIL_PASS_DEPTH_PASS: s = "GL_STENCIL_PASS_DEPTH_PASS" ' &H0B96
Case GL_STENCIL_REF: s = "GL_STENCIL_REF" '  &H0B97
Case GL_STENCIL_WRITEMASK: s = "GL_STENCIL_WRITEMASK" '    &H0B98
Case GL_MATRIX_MODE: s = "GL_MATRIX_MODE" '  &H0BA0
Case GL_NORMALIZE: s = "GL_NORMALIZE" '    &H0BA1
Case GL_VIEWPORT: s = "GL_VIEWPORT" '&H0BA2
Case GL_MODELVIEW_STACK_DEPTH: s = "GL_MODELVIEW_STACK_DEPTH" '&H0BA3
Case GL_PROJECTION_STACK_DEPTH: s = "GL_PROJECTION_STACK_DEPTH" '  &H0BA4
Case GL_TEXTURE_STACK_DEPTH: s = "GL_TEXTURE_STACK_DEPTH" '  &H0BA5
Case GL_MODELVIEW_MATRIX: s = "GL_MODELVIEW_MATRIX" '     &H0BA6
Case GL_PROJECTION_MATRIX: s = "GL_PROJECTION_MATRIX" '    &H0BA7
Case GL_TEXTURE_MATRIX: s = "GL_TEXTURE_MATRIX" '       &H0BA8
Case GL_ATTRIB_STACK_DEPTH: s = "GL_ATTRIB_STACK_DEPTH" '   &H0BB0
Case GL_CLIENT_ATTRIB_STACK_DEPTH: s = "GL_CLIENT_ATTRIB_STACK_DEPTH"   '    &H0BB1
Case GL_ALPHA_TEST: s = "GL_ALPHA_TEST" '   &H0BC0
Case GL_ALPHA_TEST_FUNC: s = "GL_ALPHA_TEST_FUNC" '      &H0BC1
Case GL_ALPHA_TEST_REF: s = "GL_ALPHA_TEST_REF" '       &H0BC2
Case GL_DITHER: s = "GL_DITHER" '  &H0BD0
Case GL_BLEND_DST: s = "GL_BLEND_DST" '    &H0BE0
Case GL_BLEND_SRC: s = "GL_BLEND_SRC" '    &H0BE1
Case GL_BLEND: s = "GL_BLEND" '   &H0BE2
Case GL_LOGIC_OP_MODE: s = "GL_LOGIC_OP_MODE" '&H0BF0
Case GL_INDEX_LOGIC_OP: s = "GL_INDEX_LOGIC_OP" '       &H0BF1
Case GL_COLOR_LOGIC_OP: s = "GL_COLOR_LOGIC_OP" '       &H0BF2
'0C00-------------------------------------------------------
Case GL_AUX_BUFFERS: s = "GL_AUX_BUFFERS" '  &H0C00
Case GL_DRAW_BUFFER: s = "GL_DRAW_BUFFER" '  &H0C01
Case GL_READ_BUFFER: s = "GL_READ_BUFFER" '  &H0C02
Case GL_SCISSOR_BOX: s = "GL_SCISSOR_BOX" '  &H0C10
Case GL_SCISSOR_TEST: s = "GL_SCISSOR_TEST" ' &H0C11
Case GL_INDEX_CLEAR_VALUE: s = "GL_INDEX_CLEAR_VALUE" '    &H0C20
Case GL_INDEX_WRITEMASK: s = "GL_INDEX_WRITEMASK" '      &H0C21
Case GL_COLOR_CLEAR_VALUE: s = "GL_COLOR_CLEAR_VALUE" '    &H0C22
Case GL_COLOR_WRITEMASK: s = "GL_COLOR_WRITEMASK" '      &H0C23
Case GL_INDEX_MODE: s = "GL_INDEX_MODE" '   &H0C30
Case GL_RGBA_MODE: s = "GL_RGBA_MODE" '    &H0C31
Case GL_DOUBLEBUFFER: s = "GL_DOUBLEBUFFER" ' &H0C32
Case GL_STEREO: s = "GL_STEREO" '  &H0C33
Case GL_RENDER_MODE: s = "GL_RENDER_MODE" '  &H0C40
Case GL_PERSPECTIVE_CORRECTION_HINT: s = "GL_PERSPECTIVE_CORRECTION_HINT" '    &H0C50
Case GL_POINT_SMOOTH_HINT: s = "GL_POINT_SMOOTH_HINT" '    &H0C51
Case GL_LINE_SMOOTH_HINT: s = "GL_LINE_SMOOTH_HINT" '     &H0C52
Case GL_POLYGON_SMOOTH_HINT: s = "GL_POLYGON_SMOOTH_HINT" '  &H0C53
Case GL_FOG_HINT: s = "GL_FOG_HINT" '&H0C54
Case GL_TEXTURE_GEN_S: s = "GL_TEXTURE_GEN_S" '&H0C60
Case GL_TEXTURE_GEN_T: s = "GL_TEXTURE_GEN_T" '&H0C61
Case GL_TEXTURE_GEN_R: s = "GL_TEXTURE_GEN_R" '&H0C62
Case GL_TEXTURE_GEN_Q: s = "GL_TEXTURE_GEN_Q" '&H0C63
'sgi only
Case &HC70: s = "GL_PIXEL_MAP_I_TO_I"  '     &H0C70
Case &HC71: s = "GL_PIXEL_MAP_S_TO_S"  '     &H0C71
Case &HC72: s = "GL_PIXEL_MAP_I_TO_R"  '     &H0C72
Case &HC73: s = "GL_PIXEL_MAP_I_TO_G"  '     &H0C73
Case &HC74: s = "GL_PIXEL_MAP_I_TO_B"  '     &H0C74
Case &HC75: s = "GL_PIXEL_MAP_I_TO_A"  '     &H0C75
Case &HC76: s = "GL_PIXEL_MAP_R_TO_R"  '     &H0C76
Case &HC77: s = "GL_PIXEL_MAP_G_TO_G"  '     &H0C77
Case &HC78: s = "GL_PIXEL_MAP_B_TO_B"  '     &H0C78
Case &HC79: s = "GL_PIXEL_MAP_A_TO_A"  '     &H0C79
Case GL_PIXEL_MAP_I_TO_I_SIZE: s = "GL_PIXEL_MAP_I_TO_I_SIZE" '&H0CB0
Case GL_PIXEL_MAP_S_TO_S_SIZE: s = "GL_PIXEL_MAP_S_TO_S_SIZE" '&H0CB1
Case GL_PIXEL_MAP_I_TO_R_SIZE: s = "GL_PIXEL_MAP_I_TO_R_SIZE" '&H0CB2
Case GL_PIXEL_MAP_I_TO_G_SIZE: s = "GL_PIXEL_MAP_I_TO_G_SIZE" '&H0CB3
Case GL_PIXEL_MAP_I_TO_B_SIZE: s = "GL_PIXEL_MAP_I_TO_B_SIZE" '&H0CB4
Case GL_PIXEL_MAP_I_TO_A_SIZE: s = "GL_PIXEL_MAP_I_TO_A_SIZE" '&H0CB5
Case GL_PIXEL_MAP_R_TO_R_SIZE: s = "GL_PIXEL_MAP_R_TO_R_SIZE" '&H0CB6
Case GL_PIXEL_MAP_G_TO_G_SIZE: s = "GL_PIXEL_MAP_G_TO_G_SIZE" '&H0CB7
Case GL_PIXEL_MAP_B_TO_B_SIZE: s = "GL_PIXEL_MAP_B_TO_B_SIZE" '&H0CB8
Case GL_PIXEL_MAP_A_TO_A_SIZE: s = "GL_PIXEL_MAP_A_TO_A_SIZE" '&H0CB9
Case GL_UNPACK_SWAP_BYTES: s = "GL_UNPACK_SWAP_BYTES" '    &H0CF0
Case GL_UNPACK_LSB_FIRST: s = "GL_UNPACK_LSB_FIRST" '     &H0CF1
Case GL_UNPACK_ROW_LENGTH: s = "GL_UNPACK_ROW_LENGTH" '    &H0CF2
Case GL_UNPACK_SKIP_ROWS: s = "GL_UNPACK_SKIP_ROWS" '     &H0CF3
Case GL_UNPACK_SKIP_PIXELS: s = "GL_UNPACK_SKIP_PIXELS" '   &H0CF4
Case GL_UNPACK_ALIGNMENT: s = "GL_UNPACK_ALIGNMENT" '     &H0CF5
'0D00-------------------------------------------------------
Case GL_PACK_SWAP_BYTES: s = "GL_PACK_SWAP_BYTES" '      &H0D00
Case GL_PACK_LSB_FIRST: s = "GL_PACK_LSB_FIRST" '       &H0D01
Case GL_PACK_ROW_LENGTH: s = "GL_PACK_ROW_LENGTH" '      &H0D02
Case GL_PACK_SKIP_ROWS: s = "GL_PACK_SKIP_ROWS" '       &H0D03
Case GL_PACK_SKIP_PIXELS: s = "GL_PACK_SKIP_PIXELS" '     &H0D04
Case GL_PACK_ALIGNMENT: s = "GL_PACK_ALIGNMENT" '       &H0D05
Case GL_MAP_COLOR: s = "GL_MAP_COLOR" '    &H0D10
Case GL_MAP_STENCIL: s = "GL_MAP_STENCIL" '  &H0D11
Case GL_INDEX_SHIFT: s = "GL_INDEX_SHIFT" '  &H0D12
Case GL_INDEX_OFFSET: s = "GL_INDEX_OFFSET" ' &H0D13
Case GL_RED_SCALE: s = "GL_RED_SCALE" '    &H0D14
Case GL_RED_BIAS: s = "GL_RED_BIAS" '&H0D15
Case GL_ZOOM_X: s = "GL_ZOOM_X" '  &H0D16
Case GL_ZOOM_Y: s = "GL_ZOOM_Y" '  &H0D17
Case GL_GREEN_SCALE: s = "GL_GREEN_SCALE" '  &H0D18
Case GL_GREEN_BIAS: s = "GL_GREEN_BIAS" '   &H0D19
Case GL_BLUE_SCALE: s = "GL_BLUE_SCALE" '   &H0D1A
Case GL_BLUE_BIAS: s = "GL_BLUE_BIAS" '    &H0D1B
Case GL_ALPHA_SCALE: s = "GL_ALPHA_SCALE" '  &H0D1C
Case GL_ALPHA_BIAS: s = "GL_ALPHA_BIAS" '   &H0D1D
Case GL_DEPTH_SCALE: s = "GL_DEPTH_SCALE" '  &H0D1E
Case GL_DEPTH_BIAS: s = "GL_DEPTH_BIAS" '   &H0D1F
Case GL_MAX_EVAL_ORDER: s = "GL_MAX_EVAL_ORDER" '       &H0D30
Case GL_MAX_LIGHTS: s = "GL_MAX_LIGHTS" '   &H0D31
Case GL_MAX_CLIP_PLANES: s = "GL_MAX_CLIP_PLANES" '      &H0D32
Case GL_MAX_TEXTURE_SIZE: s = "GL_MAX_TEXTURE_SIZE" '     &H0D33
Case GL_MAX_PIXEL_MAP_TABLE: s = "GL_MAX_PIXEL_MAP_TABLE" '  &H0D34
Case GL_MAX_ATTRIB_STACK_DEPTH: s = "GL_MAX_ATTRIB_STACK_DEPTH" '         &H0D35
Case GL_MAX_MODELVIEW_STACK_DEPTH: s = "GL_MAX_MODELVIEW_STACK_DEPTH" '      &H0D36
Case GL_MAX_NAME_STACK_DEPTH: s = "GL_MAX_NAME_STACK_DEPTH" ' &H0D37
Case GL_MAX_PROJECTION_STACK_DEPTH: s = "GL_MAX_PROJECTION_STACK_DEPTH"  '    &H0D38
Case GL_MAX_TEXTURE_STACK_DEPTH: s = "GL_MAX_TEXTURE_STACK_DEPTH" ' &H0D39
Case GL_MAX_VIEWPORT_DIMS: s = "GL_MAX_VIEWPORT_DIMS" '    &H0D3A
Case GL_MAX_CLIENT_ATTRIB_STACK_DEPTH: s = "GL_MAX_CLIENT_ATTRIB_STACK_DEPTH" '  &H0D3B
Case GL_SUBPIXEL_BITS: s = "GL_SUBPIXEL_BITS" '&H0D50
Case GL_INDEX_BITS: s = "GL_INDEX_BITS" '   &H0D51
Case GL_RED_BITS: s = "GL_RED_BITS" '&H0D52
Case GL_GREEN_BITS: s = "GL_GREEN_BITS" '   &H0D53
Case GL_BLUE_BITS: s = "GL_BLUE_BITS" '    &H0D54
Case GL_ALPHA_BITS: s = "GL_ALPHA_BITS" '   &H0D55
Case GL_DEPTH_BITS: s = "GL_DEPTH_BITS" '   &H0D56
Case GL_STENCIL_BITS: s = "GL_STENCIL_BITS" ' &H0D57
Case GL_ACCUM_RED_BITS: s = "GL_ACCUM_RED_BITS" '       &H0D58
Case GL_ACCUM_GREEN_BITS: s = "GL_ACCUM_GREEN_BITS" '     &H0D59
Case GL_ACCUM_BLUE_BITS: s = "GL_ACCUM_BLUE_BITS" '      &H0D5A
Case GL_ACCUM_ALPHA_BITS: s = "GL_ACCUM_ALPHA_BITS" '     &H0D5B
Case GL_NAME_STACK_DEPTH: s = "GL_NAME_STACK_DEPTH" '     &H0D70
Case GL_AUTO_NORMAL: s = "GL_AUTO_NORMAL" '  &H0D80
Case GL_MAP1_COLOR_4: s = "GL_MAP1_COLOR_4" ' &H0D90
Case GL_MAP1_INDEX: s = "GL_MAP1_INDEX" '   &H0D91
Case GL_MAP1_NORMAL: s = "GL_MAP1_NORMAL" '  &H0D92
Case GL_MAP1_TEXTURE_COORD_1: s = "GL_MAP1_TEXTURE_COORD_1" ' &H0D93
Case GL_MAP1_TEXTURE_COORD_2: s = "GL_MAP1_TEXTURE_COORD_2" ' &H0D94
Case GL_MAP1_TEXTURE_COORD_3: s = "GL_MAP1_TEXTURE_COORD_3" ' &H0D95
Case GL_MAP1_TEXTURE_COORD_4: s = "GL_MAP1_TEXTURE_COORD_4" ' &H0D96
Case GL_MAP1_VERTEX_3: s = "GL_MAP1_VERTEX_3" '&H0D97
Case GL_MAP1_VERTEX_4: s = "GL_MAP1_VERTEX_4" '&H0D98
Case GL_MAP2_COLOR_4: s = "GL_MAP2_COLOR_4" ' &H0DB0
Case GL_MAP2_INDEX: s = "GL_MAP2_INDEX" '   &H0DB1
Case GL_MAP2_NORMAL: s = "GL_MAP2_NORMAL" '  &H0DB2
Case GL_MAP2_TEXTURE_COORD_1: s = "GL_MAP2_TEXTURE_COORD_1" ' &H0DB3
Case GL_MAP2_TEXTURE_COORD_2: s = "GL_MAP2_TEXTURE_COORD_2" ' &H0DB4
Case GL_MAP2_TEXTURE_COORD_3: s = "GL_MAP2_TEXTURE_COORD_3" ' &H0DB5
Case GL_MAP2_TEXTURE_COORD_4: s = "GL_MAP2_TEXTURE_COORD_4" ' &H0DB6
Case GL_MAP2_VERTEX_3: s = "GL_MAP2_VERTEX_3" '&H0DB7
Case GL_MAP2_VERTEX_4: s = "GL_MAP2_VERTEX_4" '&H0DB8
Case GL_MAP1_GRID_DOMAIN: s = "GL_MAP1_GRID_DOMAIN" '     &H0DD0
Case GL_MAP1_GRID_SEGMENTS: s = "GL_MAP1_GRID_SEGMENTS" '   &H0DD1
Case GL_MAP2_GRID_DOMAIN: s = "GL_MAP2_GRID_DOMAIN" '     &H0DD2
Case GL_MAP2_GRID_SEGMENTS: s = "GL_MAP2_GRID_SEGMENTS" '   &H0DD3
Case GL_TEXTURE_1D: s = "GL_TEXTURE_1D" '   &H0DE0
Case GL_TEXTURE_2D: s = "GL_TEXTURE_2D" '   &H0DE1
Case GL_FEEDBACK_BUFFER_POINTER: s = "GL_FEEDBACK_BUFFER_POINTER" ' &H0DF0
Case GL_FEEDBACK_BUFFER_SIZE: s = "GL_FEEDBACK_BUFFER_SIZE" ' &H0DF1
Case GL_FEEDBACK_BUFFER_TYPE: s = "GL_FEEDBACK_BUFFER_TYPE" ' &H0DF2
Case GL_SELECTION_BUFFER_POINTER: s = "GL_SELECTION_BUFFER_POINTER" '&H0DF3
Case GL_SELECTION_BUFFER_SIZE: s = "GL_SELECTION_BUFFER_SIZE" '&H0DF4
'1000-------------------------------------------------------
Case GL_TEXTURE_WIDTH: s = "GL_TEXTURE_WIDTH" '&H1000
Case GL_TEXTURE_HEIGHT: s = "GL_TEXTURE_HEIGHT" '       &H1001
Case GL_TEXTURE_INTERNAL_FORMAT: s = "GL_TEXTURE_INTERNAL_FORMAT" ' &H1003
Case GL_TEXTURE_BORDER_COLOR: s = "GL_TEXTURE_BORDER_COLOR" ' &H1004
Case GL_TEXTURE_BORDER: s = "GL_TEXTURE_BORDER" '       &H1005
' HintMode */
Case GL_DONT_CARE: s = "" '    &H1100
Case GL_FASTEST: s = "" ' &H1101
Case GL_NICEST: s = "" '  &H1102
'1200-------------------------------------------------------
' LightParameter */
Case GL_AMBIENT: s = "GL_AMBIENT" ' &H1200
Case GL_DIFFUSE: s = "GL_DIFFUSE" ' &H1201
Case GL_SPECULAR: s = "GL_SPECULAR" '&H1202
Case GL_POSITION: s = "GL_POSITION" '&H1203
Case GL_SPOT_DIRECTION: s = "GL_SPOT_DIRECTION" '       &H1204
Case GL_SPOT_EXPONENT: s = "GL_SPOT_EXPONENT" '&H1205
Case GL_SPOT_CUTOFF: s = "GL_SPOT_CUTOFF" '  &H1206
Case GL_CONSTANT_ATTENUATION: s = "GL_CONSTANT_ATTENUATION" ' &H1207
Case GL_LINEAR_ATTENUATION: s = "GL_LINEAR_ATTENUATION" '   &H1208
Case GL_QUADRATIC_ATTENUATION: s = "GL_QUADRATIC_ATTENUATION" '&H1209
'1400-------------------------------------------------------
' DataType */
Case GL_BYTE: s = "GL_BYTE" '  &H1400
Case GL_UNSIGNED_BYTE: s = "GL_UNSIGNED_BYTE" ' &H1401
Case GL_SHORT: s = "GL_SHORT" ' &H1402
Case GL_UNSIGNED_SHORT: s = "GL_UNSIGNED_SHORT" '&H1403
Case GL_INT: s = "GL_INT" '   &H1404
Case GL_UNSIGNED_INT: s = "GL_UNSIGNED_INT" '  &H1405
Case GL_FLOAT: s = "GL_FLOAT" ' &H1406
Case GL_2_BYTES: s = "GL_2_BYTES" '       &H1407
Case GL_3_BYTES: s = "GL_3_BYTES" '       &H1408
Case GL_4_BYTES: s = "GL_4_BYTES" '       &H1409
Case GL_DOUBLE: s = "GL_DOUBLE" '&H140A
'1300-------------------------------------------------------
' ListMode */
Case GL_COMPILE: s = "GL_COMPILE" ' &H1300
Case GL_COMPILE_AND_EXECUTE: s = "GL_COMPILE_AND_EXECUTE" '  &H1301
'1500-------------------------------------------------------
' LogicOp */
Case GL_CLEAR: s = "GL_CLEAR" '   &H1500
Case GL_AND: s = "GL_AND" '     &H1501
Case GL_AND_REVERSE: s = "GL_AND_REVERSE" '  &H1502
Case GL_COPY: s = "GL_COPY" '    &H1503
Case GL_AND_INVERTED: s = "GL_AND_INVERTED" ' &H1504
Case GL_NOOP: s = "GL_NOOP" '    &H1505
Case GL_XOR: s = "GL_XOR" '     &H1506
Case GL_OR: s = "GL_OR" '      &H1507
Case GL_NOR: s = "GL_NOR" '     &H1508
Case GL_EQUIV: s = "GL_EQUIV" '   &H1509
Case GL_INVERT: s = "GL_INVERT" '  &H150A
Case GL_OR_REVERSE: s = "GL_OR_REVERSE" '   &H150B
Case GL_COPY_INVERTED: s = "GL_COPY_INVERTED" '&H150C
Case GL_OR_INVERTED: s = "GL_OR_INVERTED" '  &H150D
Case GL_NAND: s = "GL_NAND" '    &H150E
Case GL_SET: s = "GL_SET" '     &H150F
'1600-------------------------------------------------------
' MaterialParameter */
Case GL_EMISSION: s = "GL_EMISSION" '&H1600
Case GL_SHININESS: s = "GL_SHININESS" '    &H1601
Case GL_AMBIENT_AND_DIFFUSE: s = "GL_AMBIENT_AND_DIFFUSE" '  &H1602
Case GL_COLOR_INDEXES: s = "GL_COLOR_INDEXES" '&H1603
'1700-------------------------------------------------------
' MatrixMode */
Case GL_MODELVIEW: s = "GL_MODELVIEW" '    &H1700
Case GL_PROJECTION: s = "GL_PROJECTION" '   &H1701
Case GL_TEXTURE: s = "GL_TEXTURE" ' &H1702
' PixelCopyType */
Case GL_COLOR: s = "GL_COLOR" '   &H1800
Case GL_DEPTH: s = "GL_DEPTH" '   &H1801
Case GL_STENCIL: s = "GL_STENCIL" ' &H1802
'1900-------------------------------------------------------
' PixelFormat */
Case GL_COLOR_INDEX: s = "GL_COLOR_INDEX" '  &H1900
Case GL_STENCIL_INDEX: s = "GL_STENCIL_INDEX" '&H1901
Case GL_DEPTH_COMPONENT: s = "GL_DEPTH_COMPONENT" '      &H1902
Case GL_RED: s = "GL_RED" '     &H1903
Case GL_GREEN: s = "GL_GREEN" '   &H1904
Case GL_BLUE: s = "GL_BLUE" '    &H1905
Case GL_ALPHA: s = "GL_ALPHA" '   &H1906
Case GL_RGB: s = "GL_RGB" '     &H1907
Case GL_RGBA: s = "GL_RGBA" '    &H1908
Case GL_LUMINANCE: s = "GL_LUMINANCE" '    &H1909
Case GL_LUMINANCE_ALPHA: s = "GL_LUMINANCE_ALPHA" '      &H190A
'1A00-------------------------------------------------------
' PixelType */
Case &H1A00: s = "GL_BITMAP" '  &H1A00'sgi
' PolygonMode */
Case GL_POINT: s = "GL_POINT" '   &H1B00
Case GL_LINE: s = "GL_LINE" '    &H1B01
Case GL_FILL: s = "GL_FILL" '    &H1B02
' RenderingMode */
Case GL_RENDER: s = "GL_RENDER" '  &H1C00
Case GL_FEEDBACK: s = "GL_FEEDBACK" '&H1C01
Case GL_SELECT: s = "GL_SELECT" '  &H1C02
' ShadingModel */
Case GL_FLAT: s = "GL_FLAT" '    &H1D00
Case GL_SMOOTH: s = "GL_SMOOTH" '  &H1D01
'1E00-------------------------------------------------------
' StencilOp */
Case GL_KEEP: s = "GL_KEEP" '    &H1E00
Case GL_REPLACE: s = "GL_REPLACE" ' &H1E01
Case GL_INCR: s = "GL_INCR" '    &H1E02
Case GL_DECR: s = "GL_DECR" '    &H1E03
' StringName */
Case GL_VENDOR: s = "GL_VENDOR" '  &H1F00
Case GL_RENDERER: s = "GL_RENDERER" '&H1F01
Case GL_VERSION: s = "GL_VERSION" ' &H1F02
Case GL_EXTENSIONS: s = "GL_EXTENSIONS" '   &H1F03
'2000-------------------------------------------------------
' TextureCoordName */
Case GL_S: s = "GL_S" '       &H2000
Case GL_T: s = "GL_T" '       &H2001
Case GL_R: s = "GL_R" '       &H2002
Case GL_Q: s = "GL_Q" '       &H2003
' TextureEnvMode */
Case GL_MODULATE: s = "GL_MODULATE" '&H2100
Case GL_DECAL: s = "GL_DECAL" '   &H2101
' TextureEnvParameter */
Case GL_TEXTURE_ENV_MODE: s = "GL_TEXTURE_ENV_MODE" '     &H2200
Case GL_TEXTURE_ENV_COLOR: s = "GL_TEXTURE_ENV_COLOR" '    &H2201
' TextureEnvTarget */
Case GL_TEXTURE_ENV: s = "GL_TEXTURE_ENV" '  &H2300
' TextureGenMode */
Case GL_EYE_LINEAR: s = "GL_EYE_LINEAR" '   &H2400
Case GL_OBJECT_LINEAR: s = "GL_OBJECT_LINEAR" '&H2401
Case GL_SPHERE_MAP: s = "GL_SPHERE_MAP" '   &H2402
'2500-------------------------------------------------------
' TextureGenParameter */
Case GL_TEXTURE_GEN_MODE: s = "GL_TEXTURE_GEN_MODE" '     &H2500
Case GL_OBJECT_PLANE: s = "GL_OBJECT_PLANE" ' &H2501
Case GL_EYE_PLANE: s = "GL_EYE_PLANE" '    &H2502
' TextureMagFilter */
Case GL_NEAREST: s = "GL_NEAREST" ' &H2600
Case GL_LINEAR: s = "GL_LINEAR" '  &H2601
' TextureMinFilter */
Case GL_NEAREST_MIPMAP_NEAREST: s = "GL_NEAREST_MIPMAP_NEAREST" '  &H2700
Case GL_LINEAR_MIPMAP_NEAREST: s = "GL_LINEAR_MIPMAP_NEAREST" '&H2701
Case GL_NEAREST_MIPMAP_LINEAR: s = "GL_NEAREST_MIPMAP_LINEAR" '&H2702
Case GL_LINEAR_MIPMAP_LINEAR: s = "GL_LINEAR_MIPMAP_LINEAR" ' &H2703
' TextureParameterName */
Case GL_TEXTURE_MAG_FILTER: s = "GL_TEXTURE_MAG_FILTER" '   &H2800
Case GL_TEXTURE_MIN_FILTER: s = "GL_TEXTURE_MIN_FILTER" '   &H2801
Case GL_TEXTURE_WRAP_S: s = "GL_TEXTURE_WRAP_S" '       &H2802
Case GL_TEXTURE_WRAP_T: s = "GL_TEXTURE_WRAP_T" '       &H2803
' TextureWrapMode */
Case GL_CLAMP: s = "GL_CLAMP" '   &H2900
Case GL_REPEAT: s = "GL_REPEAT" '  &H2901
'2A00-------------------------------------------------------
Case GL_POLYGON_OFFSET_UNITS: s = "" ' &H2A00
Case GL_POLYGON_OFFSET_POINT: s = "" ' &H2A01
Case GL_POLYGON_OFFSET_LINE: s = "" '  &H2A02
Case GL_V2F: s = "GL_V2F" '     &H2A20
Case GL_V3F: s = "GL_V3F" '     &H2A21
Case GL_C4UB_V2F: s = "GL_C4UB_V2F" '&H2A22
Case GL_C4UB_V3F: s = "GL_C4UB_V3F" '&H2A23
Case GL_C3F_V3F: s = "GL_C3F_V3F" ' &H2A24
Case GL_N3F_V3F: s = "GL_N3F_V3F" ' &H2A25
Case GL_C4F_N3F_V3F: s = "GL_C4F_N3F_V3F" '  &H2A26
Case GL_T2F_V3F: s = "GL_T2F_V3F" ' &H2A27
Case GL_T4F_V4F: s = "GL_T4F_V4F" ' &H2A28
Case GL_T2F_C4UB_V3F: s = "GL_T2F_C4UB_V3F" ' &H2A29
Case GL_T2F_C3F_V3F: s = "GL_T2F_C3F_V3F" '  &H2A2A
Case GL_T2F_N3F_V3F: s = "GL_T2F_N3F_V3F" '  &H2A2B
Case GL_T2F_C4F_N3F_V3F: s = "GL_T2F_C4F_N3F_V3F" '      &H2A2C
Case GL_T4F_C4F_N3F_V4F: s = "GL_T4F_C4F_N3F_V4F" '      &H2A2D
'3000-------------------------------------------------------
' ClipPlaneName */
Case GL_CLIP_PLANE0: s = "GL_CLIP_PLANE0" '   &H3000
Case GL_CLIP_PLANE1: s = "GL_CLIP_PLANE1" '   &H3001
Case GL_CLIP_PLANE2: s = "GL_CLIP_PLANE2" '   &H3002
Case GL_CLIP_PLANE3: s = "GL_CLIP_PLANE3" '   &H3003
Case GL_CLIP_PLANE4: s = "GL_CLIP_PLANE4" '   &H3004
Case GL_CLIP_PLANE5: s = "GL_CLIP_PLANE5" '   &H3005
'4000-------------------------------------------------------
' LightName */
Case GL_LIGHT0: s = "GL_LIGHT0" '  &H4000
Case GL_LIGHT1: s = "GL_LIGHT1" '  &H4001
Case GL_LIGHT2: s = "GL_LIGHT2" '  &H4002
Case GL_LIGHT3: s = "GL_LIGHT3" '  &H4003
Case GL_LIGHT4: s = "GL_LIGHT4" '  &H4004
Case GL_LIGHT5: s = "GL_LIGHT5" '  &H4005
Case GL_LIGHT6: s = "GL_LIGHT6" '  &H4006
Case GL_LIGHT7: s = "GL_LIGHT7" '  &H4007
'8000-------------------------------------------------------
' polygon_offset */
Case GL_POLYGON_OFFSET_FACTOR: s = "GL_POLYGON_OFFSET_FACTOR" '&H8038
Case GL_POLYGON_OFFSET_FILL: s = "" '  &H8037
' texture */
Case GL_ALPHA4: s = "GL_ALPHA4" '  &H803B
Case GL_ALPHA8: s = "GL_ALPHA8" '  &H803C
Case GL_ALPHA12: s = "GL_ALPHA12" ' &H803D
Case GL_ALPHA16: s = "GL_ALPHA16" ' &H803E
Case GL_LUMINANCE4: s = "GL_LUMINANCE4" '   &H803F
Case GL_LUMINANCE8: s = "GL_LUMINANCE8" '   &H8040
Case GL_LUMINANCE12: s = "GL_LUMINANCE12" '  &H8041
Case GL_LUMINANCE16: s = "GL_LUMINANCE16" '  &H8042
Case GL_LUMINANCE4_ALPHA4: s = "GL_LUMINANCE4_ALPHA4" '    &H8043
Case GL_LUMINANCE6_ALPHA2: s = "GL_LUMINANCE6_ALPHA2" '    &H8044
Case GL_LUMINANCE8_ALPHA8: s = "GL_LUMINANCE8_ALPHA8" '    &H8045
Case GL_LUMINANCE12_ALPHA4: s = "GL_LUMINANCE12_ALPHA4" '   &H8046
Case GL_LUMINANCE12_ALPHA12: s = "GL_LUMINANCE12_ALPHA12" '  &H8047
Case GL_LUMINANCE16_ALPHA16: s = "GL_LUMINANCE16_ALPHA16" '  &H8048
Case GL_INTENSITY: s = "GL_INTENSITY" '    &H8049
Case GL_INTENSITY4: s = "GL_INTENSITY4" '   &H804A
Case GL_INTENSITY8: s = "GL_INTENSITY8" '   &H804B
Case GL_INTENSITY12: s = "GL_INTENSITY12" '  &H804C
Case GL_INTENSITY16: s = "GL_INTENSITY16" '  &H804D
Case GL_R3_G3_B2: s = "GL_R3_G3_B2" '&H2A10
Case GL_RGB4: s = "GL_RGB4" '    &H804F
Case GL_RGB5: s = "GL_RGB5" '    &H8050
Case GL_RGB8: s = "GL_RGB8" '    &H8051
Case GL_RGB10: s = "GL_RGB10" '   &H8052
Case GL_RGB12: s = "GL_RGB12" '   &H8053
Case GL_RGB16: s = "GL_RGB16" '   &H8054
Case GL_RGBA2: s = "GL_RGBA2" '   &H8055
Case GL_RGBA4: s = "GL_RGBA4" '   &H8056
Case GL_RGB5_A1: s = "GL_RGB5_A1" ' &H8057
Case GL_RGBA8: s = "GL_RGBA8" '   &H8058
Case GL_RGB10_A2: s = "GL_RGB10_A2" '&H8059
Case GL_RGBA12: s = "GL_RGBA12" '  &H805A
Case GL_RGBA16: s = "GL_RGBA16" '  &H805B
Case GL_TEXTURE_RED_SIZE: s = "GL_TEXTURE_RED_SIZE" '     &H805C
Case GL_TEXTURE_GREEN_SIZE: s = "GL_TEXTURE_GREEN_SIZE" '   &H805D
Case GL_TEXTURE_BLUE_SIZE: s = "GL_TEXTURE_BLUE_SIZE" '    &H805E
Case GL_TEXTURE_ALPHA_SIZE: s = "GL_TEXTURE_ALPHA_SIZE" '   &H805F
Case GL_TEXTURE_LUMINANCE_SIZE: s = "GL_TEXTURE_LUMINANCE_SIZE" '  &H8060
Case GL_TEXTURE_INTENSITY_SIZE: s = "GL_TEXTURE_INTENSITY_SIZE" '  &H8061
Case GL_PROXY_TEXTURE_1D: s = "GL_PROXY_TEXTURE_1D" '     &H8063
Case GL_PROXY_TEXTURE_2D: s = "GL_PROXY_TEXTURE_2D" '     &H8064
' texture_object */
Case GL_TEXTURE_PRIORITY: s = "GL_TEXTURE_PRIORITY" '     &H8066
Case GL_TEXTURE_RESIDENT: s = "GL_TEXTURE_RESIDENT" '     &H8067
Case GL_TEXTURE_BINDING_1D: s = "GL_TEXTURE_BINDING_1D" '   &H8068
Case GL_TEXTURE_BINDING_2D: s = "GL_TEXTURE_BINDING_2D" '   &H8069
' vertex_array */
Case GL_VERTEX_ARRAY: s = "GL_VERTEX_ARRAY" ' &H8074
Case GL_NORMAL_ARRAY: s = "GL_NORMAL_ARRAY" ' &H8075
Case GL_COLOR_ARRAY: s = "GL_COLOR_ARRAY" '  &H8076
Case GL_INDEX_ARRAY: s = "GL_INDEX_ARRAY" '  &H8077
Case GL_TEXTURE_COORD_ARRAY: s = "GL_TEXTURE_COORD_ARRAY" '  &H8078
Case GL_EDGE_FLAG_ARRAY: s = "GL_EDGE_FLAG_ARRAY" '      &H8079
Case GL_VERTEX_ARRAY_SIZE: s = "GL_VERTEX_ARRAY_SIZE" '    &H807A
Case GL_VERTEX_ARRAY_TYPE: s = "GL_VERTEX_ARRAY_TYPE" '    &H807B
Case GL_VERTEX_ARRAY_STRIDE: s = "GL_VERTEX_ARRAY_STRIDE" '  &H807C
Case GL_NORMAL_ARRAY_TYPE: s = "GL_NORMAL_ARRAY_TYPE" '    &H807E
Case GL_NORMAL_ARRAY_STRIDE: s = "GL_NORMAL_ARRAY_STRIDE" '  &H807F
Case GL_COLOR_ARRAY_SIZE: s = "GL_COLOR_ARRAY_SIZE" '     &H8081
Case GL_COLOR_ARRAY_TYPE: s = "GL_COLOR_ARRAY_TYPE" '     &H8082
Case GL_COLOR_ARRAY_STRIDE: s = "GL_COLOR_ARRAY_STRIDE" '   &H8083
Case GL_INDEX_ARRAY_TYPE: s = "GL_INDEX_ARRAY_TYPE" '     &H8085
Case GL_INDEX_ARRAY_STRIDE: s = "GL_INDEX_ARRAY_STRIDE" '   &H8086
Case GL_TEXTURE_COORD_ARRAY_SIZE: s = "GL_TEXTURE_COORD_ARRAY_SIZE" '&H8088
Case GL_TEXTURE_COORD_ARRAY_TYPE: s = "GL_TEXTURE_COORD_ARRAY_TYPE" '&H8089
Case GL_TEXTURE_COORD_ARRAY_STRIDE: s = "GL_TEXTURE_COORD_ARRAY_STRIDE" '     &H808A
Case GL_EDGE_FLAG_ARRAY_STRIDE: s = "GL_EDGE_FLAG_ARRAY_STRIDE" '  &H808C
Case GL_VERTEX_ARRAY_POINTER: s = "GL_VERTEX_ARRAY_POINTER" ' &H808E
Case GL_NORMAL_ARRAY_POINTER: s = "GL_NORMAL_ARRAY_POINTER" ' &H808F
Case GL_COLOR_ARRAY_POINTER: s = "GL_COLOR_ARRAY_POINTER" '  &H8090
Case GL_INDEX_ARRAY_POINTER: s = "GL_INDEX_ARRAY_POINTER" '  &H8091
Case GL_TEXTURE_COORD_ARRAY_POINTER: s = "GL_TEXTURE_COORD_ARRAY_POINTER" '    &H8092
Case GL_EDGE_FLAG_ARRAY_POINTER: s = "GL_EDGE_FLAG_ARRAY_POINTER" ' &H8093
'8000-------------------------------------------------------
' Extensions */
'Case GL_EXT_vertex_array: s = "" '     1
'Case GL_WIN_swap_hint: s = "" '1
'Case GL_EXT_bgra: s = "" '1
'Case GL_EXT_paletted_texture: s = "" ' 1
' EXT_vertex_array */
Case GL_VERTEX_ARRAY_EXT: s = "" '     &H8074
Case GL_NORMAL_ARRAY_EXT: s = "" '     &H8075
Case GL_COLOR_ARRAY_EXT: s = "" '      &H8076
Case GL_INDEX_ARRAY_EXT: s = "" '      &H8077
Case GL_TEXTURE_COORD_ARRAY_EXT: s = "" ' &H8078
Case GL_EDGE_FLAG_ARRAY_EXT: s = "" '  &H8079
Case GL_VERTEX_ARRAY_SIZE_EXT: s = "" '&H807A
Case GL_VERTEX_ARRAY_TYPE_EXT: s = "" '&H807B
Case GL_VERTEX_ARRAY_STRIDE_EXT: s = "" ' &H807C
Case GL_VERTEX_ARRAY_COUNT_EXT: s = "" '  &H807D
Case GL_NORMAL_ARRAY_TYPE_EXT: s = "" '&H807E
Case GL_NORMAL_ARRAY_STRIDE_EXT: s = "" ' &H807F
Case GL_NORMAL_ARRAY_COUNT_EXT: s = "" '  &H8080
Case GL_COLOR_ARRAY_SIZE_EXT: s = "" ' &H8081
Case GL_COLOR_ARRAY_TYPE_EXT: s = "" ' &H8082
Case GL_COLOR_ARRAY_STRIDE_EXT: s = "" '  &H8083
Case GL_COLOR_ARRAY_COUNT_EXT: s = "" '&H8084
Case GL_INDEX_ARRAY_TYPE_EXT: s = "" ' &H8085
Case GL_INDEX_ARRAY_STRIDE_EXT: s = "" '  &H8086
Case GL_INDEX_ARRAY_COUNT_EXT: s = "" '&H8087
Case GL_TEXTURE_COORD_ARRAY_SIZE_EXT: s = ""  '  &H8088
Case GL_TEXTURE_COORD_ARRAY_TYPE_EXT: s = ""  '  &H8089
Case GL_TEXTURE_COORD_ARRAY_STRIDE_EXT: s = "" ' &H808A
Case GL_TEXTURE_COORD_ARRAY_COUNT_EXT: s = "" '  &H808B
Case GL_EDGE_FLAG_ARRAY_STRIDE_EXT: s = "" '     &H808C
Case GL_EDGE_FLAG_ARRAY_COUNT_EXT: s = "" '      &H808D
Case GL_VERTEX_ARRAY_POINTER_EXT: s = "" '&H808E
Case GL_NORMAL_ARRAY_POINTER_EXT: s = "" '&H808F
Case GL_COLOR_ARRAY_POINTER_EXT: s = "" ' &H8090
Case GL_INDEX_ARRAY_POINTER_EXT: s = "" ' &H8091
Case GL_TEXTURE_COORD_ARRAY_POINTER_EXT: s = "" ' &H8092
Case GL_EDGE_FLAG_ARRAY_POINTER_EXT: s = ""  '   &H8093

' EXT_bgra */
'Case GL_BGR_EXT: s = "" ' &H80E0
'Case GL_BGRA_EXT: s = "" '&H80E1

' EXT_paletted_texture */

' These must match the GL_COLOR_TABLE_*_SGI enumerants */
Case GL_COLOR_TABLE_FORMAT_EXT: s = "" '  &H80D8
Case GL_COLOR_TABLE_WIDTH_EXT: s = "" '&H80D9
Case GL_COLOR_TABLE_RED_SIZE_EXT: s = "" '&H80DA
Case GL_COLOR_TABLE_GREEN_SIZE_EXT: s = ""  '    &H80DB
Case GL_COLOR_TABLE_BLUE_SIZE_EXT: s = "" '      &H80DC
Case GL_COLOR_TABLE_ALPHA_SIZE_EXT: s = ""   '   &H80DD
Case GL_COLOR_TABLE_LUMINANCE_SIZE_EXT: s = "" ' &H80DE
Case GL_COLOR_TABLE_INTENSITY_SIZE_EXT: s = "" ' &H80DF

Case GL_COLOR_INDEX1_EXT: s = "" '     &H80E2
Case GL_COLOR_INDEX2_EXT: s = "" '     &H80E3
Case GL_COLOR_INDEX4_EXT: s = "" '     &H80E4
Case GL_COLOR_INDEX8_EXT: s = "" '     &H80E5
Case GL_COLOR_INDEX12_EXT: s = "" '    &H80E6
Case GL_COLOR_INDEX16_EXT: s = "" '    &H80E7

' For compatibility with OpenGL v1.0 */
Case GL_LOGIC_OP: s = "" ' GL_INDEX_LOGIC_OP
'Case GL_TEXTURE_COMPONENTS: s = "" ' GL_TEXTURE_INTERNAL_FORMAT
Case Else: Debug.Assert 0
End Select
dbGetString$ = s
End Function


Private Function dbGetDataType$(ID&)
Select Case ID
Case GL_BYTE: dbGetDataType = "GL_BYTE" '&H1400
Case GL_UNSIGNED_BYTE: dbGetDataType = "GL_UNSIGNED_BYTE" '&H1401
Case GL_SHORT: dbGetDataType = "GL_SHORT" '&H1402
Case GL_UNSIGNED_SHORT: dbGetDataType = "GL_UNSIGNED_SHORT" '&H1403
Case GL_INT: dbGetDataType = "GL_INT" '&H1404
Case GL_UNSIGNED_INT: dbGetDataType = "GL_UNSIGNED_INT" '&H1405
Case GL_FLOAT: dbGetDataType = "GL_FLOAT" '&H1406
Case GL_2_BYTES: dbGetDataType = "GL_2_BYTES" '&H1407
Case GL_3_BYTES: dbGetDataType = "GL_3_BYTES" '&H1408
Case GL_4_BYTES: dbGetDataType = "GL_4_BYTES" '&H1409
Case GL_DOUBLE: dbGetDataType = "GL_DOUBLE" '&H140A
Case &H1A00: dbGetDataType = "GL_BITMAP" '&H1A00
End Select
End Function

' AttribMask,ClearBufferMask
Private Function dbGetAttrib$(ID&)
Select Case ID
Case GL_ACCUM_BUFFER_BIT: dbGetAttrib = "GL_ACCUM_BUFFER_BIT" '&H00000200
Case GL_COLOR_BUFFER_BIT: dbGetAttrib = "GL_COLOR_BUFFER_BIT" '&H00004000
Case GL_CURRENT_BIT: dbGetAttrib = "GL_CURRENT_BIT" '&H00000001
Case GL_DEPTH_BUFFER_BIT: dbGetAttrib = "GL_DEPTH_BUFFER_BIT" '&H00000100
Case GL_ENABLE_BIT: dbGetAttrib = "GL_ENABLE_BIT" '&H00002000
Case GL_EVAL_BIT: dbGetAttrib = "GL_EVAL_BIT" '&H00010000
Case GL_FOG_BIT: dbGetAttrib = "GL_FOG_BIT" '&H00000080
Case GL_HINT_BIT: dbGetAttrib = "GL_HINT_BIT" '&H00008000
Case GL_LIGHTING_BIT: dbGetAttrib = "GL_LIGHTING_BIT" '&H00000040
Case GL_LINE_BIT: dbGetAttrib = "GL_LINE_BIT" '&H00000004
Case GL_LIST_BIT: dbGetAttrib = "GL_LIST_BIT" '&H00020000
Case GL_PIXEL_MODE_BIT: dbGetAttrib = "GL_PIXEL_MODE_BIT" '&H00000020
Case GL_POINT_BIT: dbGetAttrib = "GL_POINT_BIT" '&H00000002
Case GL_POLYGON_BIT: dbGetAttrib = "GL_POLYGON_BIT" '&H00000008
Case GL_POLYGON_STIPPLE_BIT: dbGetAttrib = "GL_POLYGON_STIPPLE_BIT" '&H00000010
Case GL_SCISSOR_BIT: dbGetAttrib = "GL_SCISSOR_BIT" '&H00080000
Case GL_STENCIL_BUFFER_BIT: dbGetAttrib = "GL_STENCIL_BUFFER_BIT" '&H00000400
Case GL_TEXTURE_BIT: dbGetAttrib = "GL_TEXTURE_BIT" '&H00040000
Case GL_TRANSFORM_BIT: dbGetAttrib = "GL_TRANSFORM_BIT" '&H00001000
Case GL_VIEWPORT_BIT: dbGetAttrib = "GL_VIEWPORT_BIT" '&H00000800
Case GL_ALL_ATTRIB_BITS: dbGetAttrib = "GL_ALL_ATTRIB_BITS" '&H000fffff
End Select
End Function

' ClientAttribMask */
Private Function dbGetCAttrib$(ID&)
Select Case ID
Case GL_CLIENT_PIXEL_STORE_BIT: dbGetCAttrib$ = "GL_CLIENT_PIXEL_STORE_BIT" '&H00000001
Case GL_CLIENT_VERTEX_ARRAY_BIT: dbGetCAttrib$ = "GL_CLIENT_VERTEX_ARRAY_BIT" '&H00000002
Case GL_CLIENT_ALL_ATTRIB_BITS: dbGetCAttrib$ = "GL_CLIENT_ALL_ATTRIB_BITS" '&Hffffffff
End Select
End Function

' BeginMode */
Private Function dbGetBegin$(ID&)
Select Case ID
Case GL_POINTS: dbGetBegin = "GL_POINTS" '&H0000
Case GL_LINES: dbGetBegin = "GL_LINES" '&H0001
Case GL_LINE_LOOP: dbGetBegin = "GL_LINE_LOOP" '&H0002
Case GL_LINE_STRIP: dbGetBegin = "GL_LINE_STRIP" '&H0003
Case GL_TRIANGLES: dbGetBegin = "GL_TRIANGLES" '&H0004
Case GL_TRIANGLE_STRIP: dbGetBegin = "GL_TRIANGLE_STRIP" '&H0005
Case GL_TRIANGLE_FAN: dbGetBegin = "GL_TRIANGLE_FAN" '&H0006
Case GL_QUADS: dbGetBegin = "GL_QUADS" '&H0007
Case GL_QUAD_STRIP: dbGetBegin = "GL_QUAD_STRIP" '&H0008
Case GL_POLYGON: dbGetBegin = "GL_POLYGON" '&H0009
End Select
End Function

