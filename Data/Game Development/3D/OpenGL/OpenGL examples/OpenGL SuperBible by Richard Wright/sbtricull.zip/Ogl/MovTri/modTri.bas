Attribute VB_Name = "mTriangle"
Public Sub RenderScene()

' Routine to draw triangle with culling effect
    
    Dim X, Y, Angle As GLfloat
    Dim Gl_Pi As GLfloat
    Dim iPivot As Integer
    
    ' Initialize Variables
    iPivot = 1
    Gl_Pi = 3.142
    
    glClear clrColorBufferBit + clrDepthBufferBit

    ' Effects - Culling
    If bCull Then
      glEnable glcCullFace
    Else
      glDisable glcCullFace
    End If
    
    ' Effects - Depth Test
    If bDepth Then
      glEnable glcDepthTest
    Else
      glDisable glcDepthTest
    End If

    ' Effects - Outline back
    If bOutLine Then
      glPolygonMode faceFrontAndBack, pgmLine
    Else
      glPolygonMode faceFrontAndBack, pgmFILL
    End If
    
    ' Save matrix state and do the rotation
    glPushMatrix
    glRotatef xRot, 1#, 0#, 0#
    glRotatef yRot, 0#, 1#, 0#
    
    ' Draw triangle fan for the cone part of the model
    glFrontFace ffCW
    glBegin bmTriangleFan
      glVertex3f 0#, 0#, 150#
      For Angle = 0# To 2# * Gl_Pi Step Gl_Pi / 8#
        X = 100# * Sin(Angle)
        Y = 100# * Cos(Angle)
        If iPivot Mod 2 = 0 Then
          glColor3f 0#, 1#, 0#
        Else
          glColor3f 1#, 0#, 0#
        End If
        iPivot = iPivot + 1
        glVertex2f X, Y
      Next Angle
    glEnd
    
    ' Draw new triangle fan to cover the bottom of the cone
    If bWrongCulling = True Then
      glFrontFace ffCW
    Else
      glFrontFace ffCCW
    End If
    ' Above line is commented to show culling effect
    ' Refer to superbible for more details
    glBegin bmTriangleFan
      glVertex2f 0#, 0#
      For Angle = 0# To 2# * Gl_Pi Step Gl_Pi / 8#
        X = 100# * Sin(Angle)
        Y = 100# * Cos(Angle)
        If iPivot Mod 2 = 0 Then
          glColor3f 0#, 1#, 0#
        Else
          glColor3f 1#, 0#, 0#
        End If
        iPivot = iPivot + 1
        glVertex2f X, Y
      Next Angle
    glEnd
    
    ' Restore Transformations
    glPopMatrix
    
    SwapBuffers frmDisplay.hDC
    
    ' Flush drawing commands
    glFlush
    
End Sub
