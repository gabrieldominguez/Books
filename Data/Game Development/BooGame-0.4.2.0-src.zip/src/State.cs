using System;
using System.Collections;

namespace BooGame
{
    /// <summary>
    /// The state to describe a certain state in a state machine.
    /// </summary>
    public abstract class State
    {
        /// <summary>
        /// When implemented by a class, updates the state.
        /// </summary>
        public virtual void Update()
        {
            if (OnUpdate != null)
                OnUpdate(this, new UpdateEventArgs());
        }

        /// <summary>
        /// When implemented by a class, is executed when the state is entered.
        /// </summary>
        public virtual void Enter(EnterEventArgs args)
        {
            if (OnEnter != null)
                OnEnter(this, args);
        }

        /// <summary>
        /// When implemented by a class, the exit method is executed when the state is left.
        /// </summary>
        public virtual void Exit(ExitEventArgs args)
        {
            if (OnExit != null)
                OnExit(this, args);
        }

        #region Events
        public event UpdateEventHandler OnUpdate;
        public event ExitEventHandler OnExit;
        public event EnterEventHandler OnEnter;
        #endregion Events
    }

    #region Events
    /// <summary>
    /// Describes an exit event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void ExitEventHandler(object sender, ExitEventArgs args);

    /// <summary>
    /// Passed to the exit event when Exit calls are made.
    /// </summary>
    public class ExitEventArgs : EventArgs
    {
        private State m_NextState;
        public State NextState
        {
            get { return m_NextState; }
        }
        public ExitEventArgs(State nextState)
        {
            m_NextState = nextState;
        }
    }

    /// <summary>
    /// Describes an enter event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void EnterEventHandler(object sender, EnterEventArgs args);

    /// <summary>
    /// Passed to the enter event when Enter calls are made.
    /// </summary>
    public class EnterEventArgs : EventArgs
    {
        private State m_PreviousState;
        public State PreviousState
        {
            get { return m_PreviousState; }
        }
        public EnterEventArgs(State previousState)
        {
            m_PreviousState = previousState;
        }
    }
    #endregion Events

    #region StateDictionary
    /// <summary>
    /// A dictionary describing a number of states.
    /// </summary>
    [Serializable]
    public class StateDictionary : DictionaryBase
    {
        public StateDictionary() : base()
        {
        }
        /// <summary>
        /// Creates a StateDictionary with the "Default" state set to the given state.
        /// </summary>
        /// <param name="state">The state to be set with a key of "Default".</param>
        public StateDictionary(State state)
        {
            this.Add("Default", state);
        }
        public StateDictionary(string key, State entity)
        {
            this.Add(key, entity);
        }

        public State this[string key]
        {
            get
            {
                return (State)Dictionary[key];
            }
            set
            {
                if (Dictionary.Contains(key))
                    Dictionary[key] = value;
                else
                    Dictionary.Add(key, value);
            }
        }

        public ICollection Keys
        {
            get{ return Dictionary.Keys; }
        }

        public ICollection Values
        {
            get{ return Dictionary.Values; }
        }

        public void Add(string key, State entity)
        {
            Dictionary.Add(key, entity);
        }

        public bool Contains(string key)
        {
            return Dictionary.Contains(key);
        }

        public void Remove(string key)
        {
            Dictionary.Remove(key);
        }
    }
    #endregion StateDictionary


    #region StateCollection
    /// <summary>
    ///  A collection of states.
    /// </summary>
    [Serializable]
    public class StateCollection : CollectionBase, ICollection
    {
        public StateCollection() : base()
        {
        }

        public StateCollection(StateCollection states)
        {
            this.Add(states);
        }

        void ICollection.CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }

        public StateCollection(State state)
        {
            this.Add(state);
        }

        public State this[int index]
        {
            get{ return ((State)List[index]); }
            set{ List[index] = value; }
        }

        public int Add(State state)
        {
            return (List.Add(state));
        }

        public int Add(StateCollection stateCollection)
        {
            for (int i = 0; i < stateCollection.Count; i++)
                this.List.Add(stateCollection[i]);
            return this.Count;
        }

        public void Insert(int index, State state)
        {
            List.Insert(index, state);
        }

        public void Remove(State state)
        {
            if (state != null)
                List.Remove(state);
        }

        public int IndexOf(State state)
        {
            return (List.IndexOf(state));
        }

        public bool Contains(State state)
        {
            return (List.Contains(state));
        }

        public virtual void CopyTo(State[] array, int index)
        {
            ((ICollection)this).CopyTo(array, index);
        }

        public virtual void CopyTo(Array array, int index)
        {
            this.List.CopyTo(array, index);
        }
    }
    #endregion EntityCollection
}
