Attribute VB_Name = "mConstants"
Option Explicit

Public gCtl As glxCtl
Public CX As CXXX
'
Public Const PI = 3.141592654
Type POINT4F
    p(0 To 3) As Single
End Type

Type POINT3F
    p(0 To 2) As Single
End Type

Type POINT2F
    p(0 To 1) As Single
End Type

Public Sub ErrorHandler(which&)
    Debug.Print "Quad Error: " & gluErrorString(which)
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayb(a() As Byte, ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayf(a!(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub FillArrayi(a&(), ParamArray n())
Dim v, i&
    For Each v In n
        a(i) = v
        i = i + 1
    Next
End Sub

'----------------------------------------------------------------------------
Public Sub Fill1DArray(a() As POINT3F, ParamArray n())
Dim i&, j&
    For i = 0 To 17
        a(i).p(0) = n(j)
        a(i).p(1) = n(j + 1)
        a(i).p(2) = n(j + 2)
        j = j + 3
    Next
End Sub

'----------------------------------------------------------------------------
'to fill a 2d array of v
Public Sub Fill2DArray(a() As POINT2F, ParamArray n())
Dim i&, j&, cnt&
    For i = 0 To 6
    For j = 0 To 8
        a(i, j).p(0) = n(cnt)
        a(i, j).p(1) = n(cnt + 1)
        cnt = cnt + 2
    Next
    Next
End Sub

Public Sub Main()
Set gCtl = frmMain.glxCtl1
Set CX = New CXXX
gCtl.init
frmMain.Show
gCtl.Animate = True
End Sub

'------------------------------------------------------------
'Arccos(X) = Atn(-X / Sqr(-X * X + 1)) + 2 * Atn(1)
Public Function ArcCos!(X!)
Dim tmp!
If ArcCos > 1 Then
    Debug.Assert 0
End If
If X >= 1 Then
    ArcCos = 0 '2 * Atn(1)
ElseIf X <= 0 Then
    '???
    ArcCos = 2 * Atn(1)
Else
tmp = -X * X
tmp = Sqr(tmp + 1)
ArcCos = Atn(-X / tmp) + 2 * Atn(1)
End If
End Function

'----------------------------------------------------------------
' Return version of v scaled by s
Public Sub Qt_Scale2(qDest!(), q!(), s!)
    qDest(0) = s * q(0)
    qDest(1) = s * q(1)
    qDest(2) = s * q(2)
End Sub

Public Function RadToDeg(a)
Const ONE_OVER_PI = (1 / PI)
RadToDeg = (a * 180) * ONE_OVER_PI
End Function

Public Function RAD(X)
    RAD = X * PI / 180
End Function

Public Sub Qt_ToAxis(q!(), Angle!, X!, Y!, Z!)
Dim lng!, q1!(0 To 3), s!
    lng = Sqr(q(0) * q(0) + q(1) * q(1) + q(2) * q(2))
    If lng > 0.00001 Then
        'vnormal q
        '    vscale v, 1 / vlength(v)
        Qt_Scale2 q1, q, 1 / lng
        X = q1(0)
        Y = q1(1)
        Z = q1(2)
        Angle = RadToDeg(2 * ArcCos(q(3)))
    Else
        X = 0
        Y = 0
        Z = 1
        Angle = 0
    End If
End Sub


