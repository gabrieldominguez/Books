/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;

namespace BooGame
{
    /// <summary>
    /// Module to control the in-game terminal.
    /// </summary>
    /// <remarks>
    /// You must enable the Terminal by calling Terminal.Enabled = true; . Once you do that, you can access it by pressing the ActivationKey.
    /// </remarks>
    public class Terminal
    {
        static Terminal()
        {
			Font.Initialize();
            Core.Draw += new DrawEventHandler(Draw);
            Core.Update += new UpdateEventHandler(Update);
			m_Font = Font.Default;
        }

        /// <summary>
        /// Private Constructor - Denies instantiation.
        /// </summary>
        private Terminal()
        {
        }

        internal static void OnKeyDown(KeyboardEventArgs e)
        {
            switch (e.Key)
            {
                case Keys.Return:
                    if(m_Input == string.Empty)
                        return;
                    WriteLine(m_EntryString + m_Input);

                    // Execute the script
                    object output;
                    try
                    {
                        output = Script.DoCode(m_Input);
                    }
                    catch
                    {
                        output = null;
                    }

                    // Output the result to the terminal
                    if (output != null)
                    {
                        string final = output.ToString().Trim();
                        if (final.Length > 0)
                            WriteLine(final);
                    }
                    
                    // Call the event
                    if (Execute != null)
                        Execute(null, new TerminalEventArgs(m_Input, output));

                    // Update values
                    m_PreviousInput = m_Input;
                    m_Input = string.Empty;
                    break;
                case Keys.UpArrow:
                    m_Input = m_PreviousInput;
                    break;
                case Keys.DownArrow:
                    m_Input = string.Empty;
                    break;
                case Keys.Backspace:
                    if (m_Input.Length > 0)
                        m_Input = m_Input.Substring(0, m_Input.Length - 1);
                    break;
                default:
                    if(!e.IsSpecialKey)
                        m_Input += e.Char.ToString();
                    break;
            }
        }

        private static void Draw(object sender, DrawEventArgs args)
        {
            if (m_Visible)
            {
                float height = m_Font.TextHeight(m_VisibleLines);
                Paint.FilledRectangle(Camera.Left, Camera.Top, Camera.Width, height, m_BackgroundColor);
                string final = string.Empty;

                // calculate which lines are to be drawn
                int offset;
                int i = m_Lines.Count - (m_VisibleLines - 1);

                if (i < 0)
                    offset = Math.Abs(i);
                else
                    offset = 0;

                // add these lines to the final string
                while (i < m_Lines.Count)
                {
                    if (i >= 0)
                        final += m_Lines[i] + "\n";
                    i++;
                }

                m_Font.Print(final, m_FontColor, Camera.Left, Camera.Top + m_Font.TextHeight(offset), ContentAlignment.TopLeft);
                m_Font.Print(m_EntryString + m_Input + (m_CaretShown ? "|" : string.Empty), m_FontColor, Camera.Left, Camera.Top + height - m_Font.Height);
            }
        }

        private static void Update(object sender, UpdateEventArgs args)
        {
            if (m_Visible)
            {
                if (m_CaretTimer.CheckTime())
                    m_CaretShown = !m_CaretShown;
            }
        }

        /// <summary>
        /// Writes a string to the terminal.
        /// </summary>
        /// <param name="line">The line to write.</param>
        public static void WriteLine(string line)
        {
            if (line.Length <= 0)
                return;

            while (m_Font.TextWidth(line) > Camera.Width)
            {
                // if line is bigger than camera width, split in sublines
                string subLine = string.Empty;
                int i = 0;

                // increase subline size until it exceeds camera width
                while (m_Font.TextWidth(subLine) < Camera.Width)
                {
                    subLine += line[i];
                    i++;
                }

                // remove last character, because that exceeds camera width
                subLine = subLine.Substring(0, subLine.Length - 1);
                line = line.Remove(0, subLine.Length - 1);

                // add the subline
                m_Lines.Add(subLine);
            }

            m_Lines.Add(line); 
        }

        /// <summary>
        /// Writes a line to the Terminal.
        /// </summary>
        /// <param name="line">The object to write to the Terminal.</param>
        public static void WriteLine(object line)
        {
            if(line != null)
                WriteLine(line.ToString());
        }

        /// <summary>
        /// Gets and sets whether or not the user can take advantage of the terminal.
        /// </summary>
        public static bool Enabled
        {
            get { return m_Enabled; }
            set { m_Enabled = value; }
        }

        /// <summary>
        /// Gets and sets whether the terminal is visible.
        /// </summary>
        public static bool Visible
        {
            get { return m_Visible; }
            set { m_Visible = value; }
        }

        /// <summary>
        /// Gets and sets where the Terminal log should be saved on exit (defaults to "").
        /// </summary>
        /// <remarks>When set to "" or null, the log will not be saved.</remarks>
        public static string LogFile
        {
            get { return m_LogFile; }
            set { m_LogFile = value; }
        }

        /// <summary>
        /// Gets and sets the number of visible lines.
        /// </summary>
        public static int VisibleLines
        {
            get { return m_VisibleLines; }
            set { m_VisibleLines = value; }
        }

        /// <summary>
        /// Gets and sets the font used with the terminal.
        /// </summary>
        public static Font Font
        {
            get { return m_Font; }
            set { m_Font = value; }
        }

        /// <summary>
        /// Gets and sets the key used to activate and deactivate the terminal.
        /// </summary>
        public static Keys ActivationKey
        {
            get { return m_ActivationKey; }
            set { m_ActivationKey = value; }
        }

        /// <summary>
        /// Gets and sets the string the is shown before the input text in the console input screen.
        /// </summary>
        public static string EntryString
        {
            get { return m_EntryString; }
            set { m_EntryString = value; }
        }

        /// <summary>
        /// Gets and sets the color of the Terminal background.
        /// </summary>
        public static ColorF BackgroundColor
        {
            get { return m_BackgroundColor; }
            set { m_BackgroundColor = value; }
        }

        /// <summary>
        /// Gets and set the color of the font on the Terminal.
        /// </summary>
        public static ColorF FontColor
        {
            get { return m_FontColor; }
            set { m_FontColor = value; }
        }

        private static string m_PreviousInput = string.Empty;
        private static Keys m_ActivationKey = Keys.GraveAccent;
        private static ColorF m_BackgroundColor = Color.FromArgb(150, 0, 0, 0);
        private static ColorF m_FontColor = Color.White;
        private static bool m_CaretShown = false;
        private static Timer m_CaretTimer = new Timer(666);
        private static bool m_Enabled = false;
        private static bool m_Visible = false;
        private static Font m_Font;
        private static ArrayList m_Lines = new ArrayList();
        private static string m_Input = string.Empty;
        private static string m_EntryString = ">>> ";
        private static int m_VisibleLines = 10;
        private static string m_LogFile = string.Empty;

        /// <summary>
        /// Called when the user executes a script through the Terminal.
        /// </summary>
        public static event TerminalEventHandler Execute;
    }

    /// <summary>
    /// Describes a Terminal event.
    /// </summary>
    /// <param name="sender">The object that called the event.</param>
    /// <param name="args">The arguments passed to the event.</param>
    public delegate void TerminalEventHandler(object sender, TerminalEventArgs args);

    /// <summary>
    /// Passed to the Terminal event when terminal calls are made.
    /// </summary>
    public class TerminalEventArgs : EventArgs
    {
        public TerminalEventArgs()
        {
        }

        public TerminalEventArgs(string input)
        {
            m_Input = input;
        }

        public TerminalEventArgs(string input, object output)
        {
            m_Input = input;
            m_Output = output;
        }

        private string m_Input = string.Empty;
        /// <summary>
        /// Gets the input that was passed to the Terminal.
        /// </summary>
        public string Input
        {
            get { return m_Input; }
        }

        private object m_Output;
        /// <summary>
        /// Gets the output when the inputed script is run through the interpreter.
        /// </summary>
        public object Output
        {
            get { return m_Output; }
        }
    }

}
