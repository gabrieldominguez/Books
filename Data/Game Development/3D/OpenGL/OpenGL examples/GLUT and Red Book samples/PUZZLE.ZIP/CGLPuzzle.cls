VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CGLPuzzle"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: demonstrates picking
'AUTHOR: from the GLUT 3.3 distribution
'   - ported by edx - edx@hk.super.net, April 98
'HISTORY:
'/*************************************************************************
'  r   Reset puzzle
'  s   Solve puzzle (may take a few seconds to compute)
'  Left mouse moves pieces
'  Right mouse spins the puzzle
Dim m_Mat As glxMaterial

Dim colors(0 To NUMPIECES + 1) As COLOR255 '(3) =
'
'states
Dim m_bSolving As Boolean
Dim m_bSpinning As Boolean
Dim m_bPieceSelected As Boolean
'
'drawing
Dim xsize(0 To NUMPIECES) As Byte
Dim ysize(0 To NUMPIECES) As Byte
Dim zsize!(0 To NUMPIECES) '???
Dim boxcoords(0 To 23) As POINT3F
Dim containercoords(0 To 23) As POINT3F
Dim boxnormals(0 To 25) As POINT3F
Dim containernormals(0 To 23) As POINT3F
Dim boxfaces&(0 To NBOXFACES - 1, 0 To 3)
Dim containerfaces&(0 To NCONTFACES - 1, 0 To 3)
'
'picking/moving
Dim m_MouseX&, m_MouseY& 'current mouse coords
Dim m_SelectedPiece& 'name of selected piece, or 0
Dim m_MovingPiece& 'name of moving piece, or 0
Dim m_MoveX!, m_MoveY! 'current coords of piece being moved
Dim m_SelectedCellX&, m_SelectedCellY&
Dim m_SelStartX!, m_SelStartY!
'
Dim viewport&(0 To 3)
Dim curquat!(0 To 3)
Dim lastquat!(0 To 3)
Dim m_Width&, m_Height&


Private Sub Class_Initialize()
m_Width = 400
m_Height = 300
FillArrayb convert, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 4
FillColorArray colors, 0, 0, 0, 255, 255, 127, 255, 255, 127, _
    255, 255, 127, 255, 255, 127, 255, 127, 255, _
    255, 127, 255, 255, 127, 255, 255, 127, 255, _
    255, 127, 127, 255, 255, 255
FillArrayi xadds, -1, 0, 1, 0
'
FillArrayi yadds, 0, -1, 0, 1
FillArrayb xsize, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2
FillArrayb ysize, 0, 1, 1, 1, 1, 2, 2, 2, 2, 1, 2
FillArrayf zsize, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.6
'24
FillArrayP3F 24, boxcoords, 0.2, 0.2, 0.9, 0.8, 0.2, 0.9, 0.8, 0.8, 0.9, _
    0.2, 0.8, 0.9, 0.2, 0.1, 0.8, 0.8, 0.1, 0.8, _
    0.9, 0.2, 0.8, 0.9, 0.8, 0.8, 0.8, 0.9, 0.8, _
    0.2, 0.9, 0.8, 0.1, 0.8, 0.8, 0.1, 0.2, 0.8, _
    0.2, 0.1, 0.2, 0.8, 0.1, 0.2, 0.9, 0.2, 0.2, _
    0.9, 0.8, 0.2, 0.8, 0.9, 0.2, 0.2, 0.9, 0.2, _
    0.1, 0.8, 0.2, 0.1, 0.2, 0.2, 0.2, 0.2, 0.1, _
    0.8, 0.2, 0.1, 0.8, 0.8, 0.1, 0.2, 0.8, 0.1
'26
FillArrayP3F 26, boxnormals, 0, 0, 1, 0, 1, 0, 1, 0, 0, _
    0, 0, -1, 0, -1, 0, -1, 0, 0, _
    0.7071, 0.7071, 0, 0.7071, -0.7071, 0, -0.7071, 0.7071, 0, _
    -0.7071, -0.7071, 0, 0.7071, 0, 0.7071, 0.7071, 0, -0.7071, _
    -0.7071, 0, 0.7071, -0.7071, 0, -0.7071, 0, 0.7071, 0.7071, _
    0, 0.7071, -0.7071, 0, -0.7071, 0.7071, 0, -0.7071, -0.7071, _
    0.5774, 0.5774, 0.5774, 0.5774, 0.5774, -0.5774, 0.5774, -0.5774, 0.5774, _
    0.5774, -0.5774, -0.5774, -0.5774, 0.5774, 0.5774, -0.5774, 0.5774, -0.5774, _
    -0.5774, -0.5774, 0.5774, -0.5774, -0.5774, -0.5774
FillFaceArray 26, boxfaces, _
    0, 1, 2, 3, 9, 8, 16, 17, 6, 14, 15, 7, _
    20, 23, 22, 21, 12, 13, 5, 4, 19, 11, 10, 18, _
    7, 15, 16, 8, 13, 14, 6, 5, 18, 10, 9, 17, _
    19, 12, 4, 11, 1, 6, 7, 2, 14, 21, 22, 15, _
    11, 0, 3, 10, 20, 19, 18, 23, 3, 2, 8, 9, _
    17, 16, 22, 23, 4, 5, 1, 0, 20, 21, 13, 12, _
    2, 7, 8, -1, 16, 15, 22, -1, 5, 6, 1, -1, _
    13, 21, 14, -1, 10, 3, 9, -1, 18, 17, 23, -1, _
    11, 4, 0, -1, 20, 12, 19, -1
'24
FillArrayP3F 24, containercoords, -0.1, -0.1, 1, -0.1, -0.1, -0.1, 4.1, -0.1, -0.1, _
  4.1, -0.1, 1, 1, -0.1, 0.6, 3, -0.1, 0.6, _
  1, -0.1, 0, 3, -0.1, 0, 1, 0, 0, _
  3, 0, 0, 3, 0, 0.6, 1, 0, 0.6, _
  0, 0, 1, 4, 0, 1, 4, 0, 0, _
  0, 0, 0, 0, 5, 0, 0, 5, 1, _
  4, 5, 1, 4, 5, 0, -0.1, 5.1, -0.1, _
  4.1, 5.1, -0.1, 4.1, 5.1, 1, -0.1, 5.1, 1
'24
FillArrayP3F 24, containernormals, 0, -1, 0, 0, -1, 0, 0, -1, 0, _
    0, -1, 0, 0, -1, 0, 0, 1, 0, _
    0, 1, 0, 0, 1, 0, 1, 0, 0, _
    1, 0, 0, 1, 0, 0, -1, 0, 0, _
    -1, 0, 0, -1, 0, 0, 0, 1, 0, _
    0, 0, -1, 0, 0, -1, 0, 0, 1, _
    0, 0, 1, 0, 0, 1, 0, 0, 1, _
    0, 0, 1, 0, 0, 1, 0, 0, 1
FillFaceArray 24, containerfaces, _
    1, 6, 4, 0, 0, 4, 5, 3, 1, 2, 7, 6, _
    7, 2, 3, 5, 16, 19, 18, 17, 23, 22, 21, 20, _
    12, 11, 8, 15, 10, 13, 14, 9, 15, 16, 17, 12, _
    2, 21, 22, 3, 6, 8, 11, 4, 1, 0, 23, 20, _
    14, 13, 18, 19, 9, 7, 5, 10, 12, 13, 10, 11, _
    1, 20, 21, 2, 4, 11, 10, 5, 15, 8, 19, 16, _
    19, 8, 9, 14, 8, 6, 7, 9, 0, 3, 13, 12, _
    13, 3, 22, 18, 18, 22, 23, 17, 17, 23, 0, 12
'typedef char Config[HEIGHT][WIDTH];
'static Config startConfig =
'{pieces rotated 180*
'  {8, 10, 10, 7},
'  {8, 10, 10, 7},
'  {6, 9, 9, 5},
'  {6, 4, 3, 5},
'  {2, 0, 0, 1}
'};
FillConfig StartConfig, _
    8, 10, 10, 7, 8, 10, 10, 7, 6, 9, 9, 5, _
    6, 4, 3, 5, 2, 0, 0, 1
FillConfig thePuzzle, _
    8, 10, 10, 7, 8, 10, 10, 7, 6, 9, 9, 5, _
    6, 4, 3, 5, 2, 0, 0, 1

End Sub

'*************************************************************************
'
'*************************************************************************
Public Sub Init()
'do pre-GL stuff here - set pf
End Sub

Public Sub InitGL()
    gCtl.UseCamera = False
    gCtl.ClearMode = clrNone
    glGetIntegerv GL_VIEWPORT, viewport(0)
    With gCtl.Lights.Item(liLight0)
        .SetAmbient 0.1, 0.1, 0.1
        .SetDiffuse 1, 1, 1, 0
        .SetSpecular 0, 0, 0, 0
        .SetPosition 0.8660254, 0.5, 1
        .Enabled = True
    End With
    With gCtl.Lights
        .LocalViewer = False
        .SetAmbient 0, 0, 0
        .TwoSide = 0
    End With
    glClearColor 0.5, 0.5, 0.5, 0
    glEnable GL_CULL_FACE
    glCullFace GL_BACK
    glEnable GL_DEPTH_TEST
    glClearDepth 1
    With gCtl.Camera
        .FarPlane = 100
        .NearPlane = 0.01
        .FieldOfView = 45
        .SetEyePos 0, 0, 10
        .SetTargetPos 0, 0, 0
    End With
    '
    Set m_Mat = gCtl.NewMaterial
    With m_Mat
        .face = faceFront
        .SetAmbient 0, 0, 0, 1
        .SetDiffuse 1, 0, 0, 0
        .SetSpecular 0, 0, 0, 0
        .SpecExp = 40
    End With

    glColorMaterial GL_FRONT_AND_BACK, GL_DIFFUSE
    glEnable GL_COLOR_MATERIAL
    glShadeModel GL_FLAT
    
    Trackball curquat, 0, 0, 0, 0

End Sub

Public Function Reshape(Width&, Height&) As Boolean
    'return 0 so ocx won't do anything
    m_Width = Width
    m_Height = Height
    glViewport 0, 0, m_Width, m_Height
    glGetIntegerv GL_VIEWPORT, viewport(0)
End Function

Public Sub KeyDown(KeyCode%, Shift%)
    Select Case (KeyCode)
    Case vbKeyLeft:
    Case vbKeyRight:
    Case vbKeyUp:
    Case vbKeyDown:
    Case 27:   Unload frmMain
    Case Else:
    End Select
End Sub

Public Sub KeyPress(KeyAscii As Integer)
Dim s$, piece&
    s = Chr$(KeyAscii)
    Select Case (s)
    Case "D", "d" 'delete a piece
        If m_bSolving Then
            freeSolutions
            m_bSolving = 0
            SetMenu "Solving"
            frmMain.Caption = "glpuzzle"
            m_MovingPiece = 0
        End If
        piece = SelectPiece(m_MouseX, m_MouseY)
        If piece Then
            NukePiece piece
        End If
    Case "R", "r"
        Reset
    Case "S", "s"
        toggleSolve
    End Select
End Sub

Public Sub NukePiece(ByVal piece&)
Dim i&, j&
    For i = 0 To BOXHEIGHT - 1
        For j = 0 To BOXWIDTH - 1
            If (thePuzzle.m(i, j) = piece) Then
                thePuzzle.m(i, j) = 0
            End If
        Next
    Next
End Sub

Public Sub Reset()
    If m_bSolving Then
        freeSolutions
        m_bSolving = 0
        SetMenu "Solve"
        frmMain.Caption = "glpuzzle"
        m_MovingPiece = 0
    End If
    thePuzzle = StartConfig
End Sub

Public Sub Visibility(ByVal v As Boolean)
    gCtl.Animate = v
End Sub

'*************************************************************************
'drawing code
'*************************************************************************

Public Sub Draw()
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    gluPerspective 45, 1, 0.1, 100
    '
    If m_bSpinning Then
        add_quats lastquat, curquat, curquat
    End If
    '
    If m_bSolving Then
        If ContinueSolving = 0 Then
            m_bSolving = 0
            SetMenu "Solve"
            frmMain.Caption = "glpuzzle"
        End If
    End If
    drawAll
End Sub

' Draw the container
Public Sub drawContainer()
Dim i&, k&, n&
Dim v!
    ' Y is reversed here because the model has it reversed

    'Arbitrary bright wood-like color
    glColor3ub 209, 103, 23
    glBegin GL_QUADS
    For i = 0 To NCONTFACES - 1
        'v = containernormals(i)
        'glNormal3f (v(0), -v(1), v(2));
        glNormal3f containernormals(i).p(0), _
                    -containernormals(i).p(1), _
                    containernormals(i).p(2)
        For k = 3 To 0 Step -1
            'v = containercoords(containerfaces(i)(k));
            n = containerfaces(i, k)
            'glVertex3f(v(0) + OFFSETX, -(v(1) + OFFSETY), v(2) + OFFSETZ);
            glVertex3f containercoords(n).p(0) + OFFSETX, _
                        -(containercoords(n).p(1) + OFFSETY), _
                        containercoords(n).p(2) + OFFSETZ
        Next
    Next
    glEnd
End Sub

Public Sub drawAll()
Dim i&, j&, piece&
Dim done(0 To NUMPIECES) As Byte ' + 1);
Dim m!(0 To 15) '  float m(4)(4);

    build_rotmatrix m, curquat
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glTranslatef 0, 0, -10
    glMultMatrixf m(0)
    glRotatef 180, 0, 0, 1

    glClear GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
    '
    glLoadName 0
    drawContainer
    For i = 0 To BOXHEIGHT - 1
    For j = 0 To BOXWIDTH - 1
        piece = thePuzzle.m(i, j)
        If piece = 0 Then
            GoTo skip
        End If
        If (done(piece)) Then
            GoTo skip
        End If
        done(piece) = 1
        glLoadName (piece)
        If piece = m_MovingPiece Then
            drawBox piece, m_MoveX, m_MoveY
        Else
            drawBox piece, CSng(j), CSng(i)
        End If
skip:
    Next
    Next
End Sub

' Draw a box.  Bevel as desired.
Public Sub drawBox(ByVal piece&, ByVal xoff!, ByVal yoff!)
Dim xlen&, ylen&
Dim i&, k&
Dim x!, y!, z!
Dim zlen!
Dim v! '*
Dim n&
    xlen = xsize(piece)
    ylen = ysize(piece)
    zlen = zsize(piece)
    
    glColor3ubv colors(piece).c(0)
    glBegin GL_QUADS
    For i = 0 To 17
        glNormal3fv boxnormals(i).p(0)
        For k = 0 To 3
            If (boxfaces(i, k) = -1) Then
              GoTo skip
            End If
            n = boxfaces(i, k)
            'v = boxcoords(n).p
            x = boxcoords(n).p(0) + OFFSETX
            If (boxcoords(n).p(0) > 0.5) Then
                x = x + xlen - 1
            End If
            y = boxcoords(n).p(1) + OFFSETY
            If (boxcoords(n).p(1) > 0.5) Then
                y = y + ylen - 1
            End If
            z = boxcoords(n).p(2) + OFFSETZ
            If (boxcoords(n).p(2) > 0.5) Then
                z = z + zlen - 1
            End If
            glVertex3f xoff + x, yoff + y, z
skip:
        Next
    Next
    glEnd
    glBegin GL_TRIANGLES
    For i = 18 To NBOXFACES - 1
        glNormal3fv boxnormals(i).p(0)
        For k = 0 To 2
            If (boxfaces(i, k) = -1) Then
                GoTo skip2
            End If
            'v = boxcoords()
            n = boxfaces(i, k)
            x = boxcoords(n).p(0) + OFFSETX
            If (boxcoords(n).p(0) > 0.5) Then
                x = x + xlen - 1
            End If
            y = boxcoords(n).p(1) + OFFSETY
            If (boxcoords(n).p(1) > 0.5) Then
                y = y + ylen - 1
            End If
            z = boxcoords(n).p(2) + OFFSETZ
            If (boxcoords(n).p(2) > 0.5) Then
                z = z + zlen - 1
            End If
            glVertex3f xoff + x, yoff + y, z
skip2:
        Next
    Next
    glEnd
End Sub

'*************************************************************************
'picking code
'*************************************************************************
Public Sub MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim selx!, sely!
    m_MouseX = x
    m_MouseY = y
    Select Case Button
    Case 1 'GLUT_LEFT_BUTTON:
        If m_bSolving Then
            freeSolutions
            m_bSolving = 0
            SetMenu "Solve"
            frmMain.Caption = "glpuzzle"
            m_MovingPiece = 0
        End If
        m_SelectedPiece = SelectPiece(m_MouseX, m_MouseY)
        If m_SelectedPiece Then
            If ComputeCoords(m_SelectedPiece, m_MouseX, m_MouseY, selx, sely) Then
                GrabPiece m_SelectedPiece, selx, sely
            End If
        End If
    Case Else 'GLUT_MIDDLE_BUTTON:
        If m_MouseX = x Or m_MouseY = y Then
            m_bSpinning = False
        End If
    End Select
End Sub

Public Sub MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim selx!, sely!
    If Button > 1 Then
        If m_MouseX <> x Or m_MouseY <> y Then
            Trackball lastquat, _
                (2 * m_MouseX - m_Width) / m_Width, _
                (m_Height - 2 * m_MouseY) / m_Height, _
                (2 * x - m_Width) / m_Width, _
                (m_Height - 2 * y) / m_Height
            m_bSpinning = True
        Else
            m_bSpinning = 0
        End If
    ElseIf Button = 1 Then
        If m_SelectedPiece Then
            ComputeCoords m_SelectedPiece, x, y, selx, sely
            MoveSelection selx, sely
        End If
    End If
    m_MouseX = x
    m_MouseY = y
End Sub

Public Sub MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    m_MouseX = x
    m_MouseY = y
    Select Case Button
    Case 1 'GLUT_LEFT_BUTTON:
        If m_bPieceSelected Then
            m_MovingPiece = 0
            m_bPieceSelected = False
            m_SelectedPiece = 0
            m_MoveX = 0
            m_MoveY = 0
            m_SelectedCellX = 0
            m_SelectedCellY = 0
            m_SelStartX = 0
            m_SelStartY = 0
            'Debug.Print "------------------"
            'Debug.Print "MouseUp: m_bPieceSelected=" & m_bPieceSelected
        End If
    Case Else
    End Select
End Sub

'*************************************************************************
' This is a screwball function.  What it does is the following:
' Given screen x and y coordinates, compute the corresponding object space
' x and y coordinates given that the object space z is 0.9 + OFFSETZ.
' Since the tops of (most) pieces are at z = 0.9 + OFFSETZ, we use that
' number.
'called from MouseDown,MouseMove
' returns the coords in selx,sely
'*************************************************************************
Public Function ComputeCoords(ByVal piece&, ByVal x&, ByVal y&, selx!, sely!) As Boolean
Dim modelMatrix!(0 To 15)
Dim projMatrix!(0 To 15)
Dim finalMatrix!(0 To 15)
Dim fIn!(0 To 3)
Dim a!, b!, c!, d!
Dim top!, bot!
Dim z!
Dim Width!
Dim Height!

    If piece = 0 Then Exit Function
    Height = zsize(piece) - 0.1 + OFFSETZ
    
    glGetFloatv GL_PROJECTION_MATRIX, projMatrix(0)
    glGetFloatv GL_MODELVIEW_MATRIX, modelMatrix(0)
    multMatrices modelMatrix, projMatrix, finalMatrix
    If invertMatrix(finalMatrix, finalMatrix) = 0 Then
        Exit Function
    End If
    
    fIn(0) = (2 * (x - viewport(0)) / viewport(2)) - 1
    fIn(1) = (2 * ((m_Height - y) - viewport(1)) / viewport(3)) - 1
    
    a = fIn(0) * finalMatrix(0 * 4 + 2) + _
      fIn(1) * finalMatrix(1 * 4 + 2) + _
      finalMatrix(3 * 4 + 2)
    b = finalMatrix(2 * 4 + 2)
    c = fIn(0) * finalMatrix(0 * 4 + 3) + _
      fIn(1) * finalMatrix(1 * 4 + 3) + _
      finalMatrix(3 * 4 + 3)
    d = finalMatrix(2 * 4 + 3)
    
    ' Ok, now we need to solve for z:
    '(a + b z) / (c + d z) = height.
    ' ("height" is the height in object space we
    'want to solve z for)** ** ==>
    ' a + b z = height c +  height d z
    '   bz - height d z = height c - a
    '   z = (height c - a) / (b - height d)
    top = Height * c - a
    bot = b - Height * d
    If bot = 0 Then
        Exit Function
    End If
    z = top / bot

    ' Ok, no problem.  Now we solve for x and y.
    ' We know that
    '   w = c + d z, so we compute it.
    Width = c + d * z
    ' Now for x and y:
    selx = (fIn(0) * finalMatrix(0 * 4 + 0) + _
        fIn(1) * finalMatrix(1 * 4 + 0) + _
        z * finalMatrix(2 * 4 + 0) + _
        finalMatrix(3 * 4 + 0)) / Width - OFFSETX
    sely = (fIn(0) * finalMatrix(0 * 4 + 1) + _
        fIn(1) * finalMatrix(1 * 4 + 1) + _
        z * finalMatrix(2 * 4 + 1) + _
        finalMatrix(3 * 4 + 1)) / Width - OFFSETY
    ComputeCoords = True
End Function


Public Sub GrabPiece(ByVal piece&, ByVal x!, ByVal y!)
Dim hit&
'    Debug.Print "------------------"
'    Debug.Print "GrabPiece"
'    Debug.Print "m_bPieceSelected=" & m_bPieceSelected
'    Debug.Print "x=" & x
'    Debug.Print "y=" & y
    'round the x,y coords to a cell
    m_SelectedCellX = Int(x)
    m_SelectedCellY = Int(y)
    If (m_SelectedCellX < 0) Or _
        (m_SelectedCellY < 0) Or _
        (m_SelectedCellX >= BOXWIDTH) Or _
        (m_SelectedCellY >= BOXHEIGHT) Then
        'Debug.Print "Outside of box"
        Exit Sub
    End If
    '
    hit = thePuzzle.m(m_SelectedCellY, m_SelectedCellX)
    If (hit <> piece) Then
'        Debug.Print "Picked piece" & piece
'        Debug.Print "Hit:" & thePuzzle.m(m_SelectedCellY, m_SelectedCellX)
'        Debug.Print "Hit <> piece"
        Exit Sub
    End If
    If hit Then
        m_MovingPiece = hit
        Debug.Print "Selected : movingpiece=" & m_MovingPiece
        '
        'Do While (selectx > 0 And thePuzzle(m_SelectedCellY, selectx - 1) = m_MovingPiece)
        Do While m_SelectedCellX > 0
            If thePuzzle.m(m_SelectedCellY, m_SelectedCellX - 1) = m_MovingPiece Then
                m_SelectedCellX = m_SelectedCellX - 1
            Else: Exit Do
            End If
        Loop
        Do While m_SelectedCellY > 0
            If thePuzzle.m(m_SelectedCellY - 1, m_SelectedCellX) = m_MovingPiece Then
                m_SelectedCellY = m_SelectedCellY - 1
            Else: Exit Do
            End If
        Loop
        '
        m_MoveX = m_SelectedCellX
        m_MoveY = m_SelectedCellY
        m_bPieceSelected = True
        'intial mouse coords
        m_SelStartX = x
        m_SelStartY = y
        'Debug.Print "Selected : m_bPieceSelected=" & m_bPieceSelected
    Else
        m_bPieceSelected = False
        'Debug.Print "Deselected : m_bPieceSelected=" & m_bPieceSelected
    End If
    'ChangeState
End Sub

Public Sub MoveSelection(ByVal x!, ByVal y!)
Dim deltaX!, deltaY!, direction As pzlDirections
Dim newpieces As TConfiguration
    
    If m_bPieceSelected = False Then Exit Sub
'    Debug.Print "Selected piece=" & m_SelectedPiece&
'    Debug.Print "Moving piece=" & m_MovingPiece
    deltaX = x - m_SelStartX
    deltaY = y - m_SelStartY
'    Debug.Print "dx:" & deltaX
'    Debug.Print "dy:" & deltaY
    '
    'figure out which way the player is trying
    'to move the piece
    If Abs(deltaX) > Abs(deltaY) Then
        deltaY = 0
        If deltaX > 0 Then
            If deltaX > 1 Then deltaX = 1
            direction = pzlRIGHT '2
            'Debug.Print "Move right"
        Else
            If deltaX < -1 Then deltaX = -1
            direction = pzlLEFT '0
            'Debug.Print "Move left"
        End If
    Else
        deltaX = 0
        'note: I reversed these
        If deltaY > 0 Then
            If deltaY > 1 Then deltaY = 1
            direction = pzlDOWN ' 1
            'Debug.Print "move down"
        Else
            If deltaY < -1 Then deltaY = -1
            direction = pzlUP ' 3
            'Debug.Print "Move up"
        End If
    End If
    
    'see if it is possible. If so, the new board config will be returned in newpieces
    If canmove(thePuzzle, m_SelectedCellX, m_SelectedCellY, direction, newpieces) Then
        'Debug.Print "OK to move"
        m_MoveX = deltaX + m_SelectedCellX
        m_MoveY = deltaY + m_SelectedCellY
        'if we're in a new cell, change the configuration and
        'adjust the move variables
        If deltaX > 0.5 Then
            thePuzzle = newpieces
            m_SelectedCellX = m_SelectedCellX + 1
            m_SelStartX = m_SelStartX + 1
        ElseIf deltaX < -0.5 Then
            thePuzzle = newpieces
            m_SelectedCellX = m_SelectedCellX - 1
            m_SelStartX = m_SelStartX - 1
        ElseIf deltaY > 0.5 Then
            thePuzzle = newpieces
            m_SelectedCellY = m_SelectedCellY + 1
            m_SelStartY = m_SelStartY + 1
        ElseIf deltaY < -0.5 Then
            thePuzzle = newpieces
            m_SelectedCellY = m_SelectedCellY - 1
            m_SelStartY = m_SelStartY - 1
        End If
    Else
        If deltaY > 0 And thePuzzle.m(m_SelectedCellY, m_SelectedCellX) = 10 And _
          m_SelectedCellX = 1 And m_SelectedCellY = 3 Then
            ' Allow visual movement of solution piece outside of the box
            m_MoveX = m_SelectedCellX
            'reversed
            m_MoveY = y - m_SelStartY + m_SelectedCellY
        Else
            'Debug.Print "Can't move"
            m_MoveX = m_SelectedCellX
            m_MoveY = m_SelectedCellY
        End If
    End If
End Sub



Public Function ContinueSolving() As Boolean
Dim nextpuz& ' As TPuzzle
Dim i&, j&
Dim movedPiece&, movedir As pzlDirections
Dim tox&, toy&, fromx&, fromy&
    
If StartPuzzle = 0 Then Exit Function
    If Puzzles(StartPuzzle).Solnptr = 0 Then
        freeSolutions
        Exit Function
    End If
    
With Puzzles(StartPuzzle)
    nextpuz = .Solnptr
    movedPiece = 0
    movedir = 0
    For i = 0 To BOXHEIGHT - 1
        For j = 0 To BOXWIDTH - 1
        'find the piece which is different
        If (.Pieces.m(i, j) <> Puzzles(nextpuz).Pieces.m(i, j)) Then
            'if this is a piece
            If (.Pieces.m(i, j)) Then
                'this is the piece that moved
                movedPiece = .Pieces.m(i, j)
                fromx = j
                fromy = i
                '
                If (i < BOXHEIGHT - 1) Then
                    If Puzzles(nextpuz).Pieces.m(i + 1, j) = movedPiece Then
                        movedir = pzlDOWN  '3
                    Else
                        movedir = pzlRIGHT '2
                    End If
                Else
                    movedir = pzlRIGHT '2
                End If
                GoTo found_piece
            'if this is a space
            Else
                'a piece was moved here
                movedPiece = Puzzles(nextpuz).Pieces.m(i, j)
                If i < BOXHEIGHT - 1 Then
                    If .Pieces.m(i + 1, j) = movedPiece Then
                        fromx = j
                        'x
                        fromy = i + 1
                        movedir = pzlUP '1
                    Else
                        fromx = j + 1
                        fromy = i
                        movedir = pzlLEFT '0
                    End If
                Else
                    fromx = j + 1
                    fromy = i
                    movedir = pzlLEFT '0
                End If
                GoTo found_piece
            End If
        End If
        Next
    Next
    'error
    frmMain.Caption = "What!  No change?"
    freeSolutions
    Exit Function
End With

found_piece:
    'set next move cycle
    If m_MovingPiece = 0 Then
        m_MovingPiece = movedPiece
        m_MoveX = fromx
        m_MoveY = fromy
    End If
    m_MoveX = m_MoveX + xadds(movedir) * MOVE_SPEED
    m_MoveY = m_MoveY + yadds(movedir) * MOVE_SPEED
    
    tox = fromx + xadds(movedir)
    '
    toy = fromy + yadds(movedir)
    
    If (m_MoveX > (tox - MOVE_SPEED / 2)) And _
        (m_MoveX < (tox + MOVE_SPEED / 2)) And _
        (m_MoveY > (toy - MOVE_SPEED / 2)) And _
        (m_MoveY < (toy + MOVE_SPEED / 2)) Then
        StartPuzzle = nextpuz
        m_MovingPiece = 0
    End If
    thePuzzle = Puzzles(StartPuzzle).Pieces
    ContinueSolving = True
End Function

'performs the picking, returns name of selected piece or 0
Public Function SelectPiece&(ByVal x&, ByVal y&)
Dim hits&
Dim selectBuf(0 To 1023) As GLuint
Dim closest&, dist#, items&()

    'Debug.Print "x=" & x
    'Debug.Print "y=" & y
    glSelectBuffer 1024, selectBuf(0)
    glRenderMode GL_SELECT
    glInitNames
    
    ' Because LoadName() won't work with no names on the stack
    glPushName -1
    
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    gluPickMatrix x, m_Height - y, 4, 4, viewport(0)
    gluPerspective 45, 1, 0.1, 100
    
    drawAll
    
    hits = glRenderMode(GL_RENDER)
    If (hits <= 0) Then
        Debug.Print "No hit"
        Exit Function
    End If
    ReDim items(0 To hits - 1)
    'ProcessHits hits, selectBuf, items
    closest = 0
    '    dist = 4294967295#
    dist = 4294967295#
    Do While (hits)
        If (selectBuf((hits - 1) * 4 + 1) < dist) Then
            dist = selectBuf((hits - 1) * 4 + 1)
            closest = selectBuf((hits - 1) * 4 + 3)
        End If
        hits = hits - 1
    Loop
    SelectPiece = closest
End Function

Public Sub ProcessHits(hits&, buffer() As GLuint, items&())
Dim i&, j&
Dim names&, ptr&
    Debug.Print "------------------"
    Debug.Print "SelectPiece"
    Debug.Print "hits = " & hits
    For i = 0 To hits - 1 '  for each hit
        names = buffer(ptr)
        'Debug.Print " number of names for hit = " & names
        ptr = ptr + 1
        'Debug.Print "  z1 is " & CDbl(buffer(ptr))
        ptr = ptr + 1
        'Debug.Print " z2 is " & buffer(ptr)
        ptr = ptr + 1
        'Debug.Print ("   the name is ")

        For j = 0 To names - 1
            Debug.Print "name " & (j + 1) & " = " & buffer(ptr)
            ptr = ptr + 1
        Next
        items(i) = buffer(ptr - 1)
    Next
End Sub

Public Sub toggleSolve()
    If m_bSolving Then
        freeSolutions
        m_bSolving = 0
        SetMenu "Solve"
        frmMain.Caption = "glpuzzle"
        m_MovingPiece = 0
    Else
        SetMenu "Stop solving"
        frmMain.Caption = "Solving..."
        If SolvePuzzle() Then
            m_bSolving = True
        End If
    End If
End Sub



'*************************************************************************
'misc utility routines
'*************************************************************************

Public Sub SetMenu(s$)
frmMain.mnuFileSolve.Caption = s
End Sub

'a(0 to 15),b(0 to 15)r(0 to 15)
Public Sub multMatrices(a!(), b!(), r!())
Dim i&, j&
    For i = 0 To 3
    For j = 0 To 3
        r(i * 4 + j) = _
          a(i * 4 + 0) * b(0 * 4 + j) + _
          a(i * 4 + 1) * b(1 * 4 + j) + _
          a(i * 4 + 2) * b(2 * 4 + j) + _
          a(i * 4 + 3) * b(3 * 4 + j)
    Next
    Next
End Sub

'm(0 to 15)
Public Sub makeIdentity(m!())
    m(0 + 4 * 0) = 1
    m(0 + 4 * 1) = 0
    m(0 + 4 * 2) = 0
    m(0 + 4 * 3) = 0
    m(1 + 4 * 0) = 0
    m(1 + 4 * 1) = 1
    m(1 + 4 * 2) = 0
    m(1 + 4 * 3) = 0
    m(2 + 4 * 0) = 0
    m(2 + 4 * 1) = 0
    m(2 + 4 * 2) = 1
    m(2 + 4 * 3) = 0
    m(3 + 4 * 0) = 0
    m(3 + 4 * 1) = 0
    m(3 + 4 * 2) = 0
    m(3 + 4 * 3) = 1
End Sub

'inverse = invert(src)
'm(0 to 15)
Public Function invertMatrix(src!(), inverse!())
Dim i&, j&, k&, swap&, t#
Dim temp!(0 To 3, 0 To 3)
    For i = 0 To 3:  For j = 0 To 3
        temp(i, j) = src(i * 4 + j)
    Next: Next
    makeIdentity inverse
    For i = 0 To 3
        ' Look for largest element in column
        swap = i
        For j = i + 1 To 3
            If (Abs(temp(j, i)) > Abs(temp(i, i))) Then
                swap = j
            End If
        Next
        If (swap <> i) Then
            ' Swap rows.
            For k = 0 To 3
                t = temp(i, k)
                temp(i, k) = temp(swap, k)
                temp(swap, k) = t
                t = inverse(i * 4 + k)
                inverse(i * 4 + k) = inverse(swap * 4 + k)
                inverse(swap * 4 + k) = t
            Next
        End If
        If (temp(i, i) = 0) Then
             ' No non-zero pivot.  The matrix is singular, which
             'shouldn 't ** happen.  This means the user gave us a
             'bad matrix.
            Debug.Assert 0
            Exit Function
        End If
        t = temp(i, i)
        For k = 0 To 3
            temp(i, k) = temp(i, k) / t
            inverse(i * 4 + k) = inverse(i * 4 + k) / t
        Next
        For j = 0 To 3
            If (j <> i) Then
                t = temp(j, i)
                For k = 0 To 3
                    temp(j, k) = temp(j, k) - temp(i, k) * t
                    inverse(j * 4 + k) = inverse(j * 4 + k) - inverse(i * 4 + k) * t
                Next
            End If
        Next
    Next
    invertMatrix = 1
End Function



