Attribute VB_Name = "mDino"
Option Explicit
'/* Copyright (c) Mark J. Kilgard, 1994, 1997.  */
'
'/* This program is freely distributable without licensing fees
'   and is provided without guarantee or warrantee expressed or
'   implied. This program is -not- in the public domain. */

Public Enum displayLists
    Reserved = 0
    BODY_SIDE = 1
    BODY_EDGE = 2
    BODY_WHOLE = 3
    ARM_SIDE = 4
    ARM_EDGE = 5
    ARM_WHOLE = 6
    LEG_SIDE = 7
    LEG_EDGE = 8
    LEG_WHOLE = 9
    EYE_SIDE = 10
    EYE_EDGE = 11
    EYE_WHOLE = 12
    DINOSAUR = 13
End Enum
'/* *INDENT-OFF* */
Dim body(0 To 21) As POINT2F
Dim arm(0 To 15) As POINT2F
Dim leg(0 To 13) As POINT2F
Dim eye(0 To 5) As POINT2F
Dim skinColor!(0 To 3)
Dim eyeColor!(0 To 3)
'/* *INDENT-ON* */
Dim tObj& ' As GLUtriangulatorObj ' *tobj = NULL;

Public Sub Init()
FillArray2Df body, 0, 3, 1, 1, 5, 1, 8, 4, 10, 4, 11, 5, _
  11, 11.5, 13, 12, 13, 13, 10, 13.5, 13, 14, 13, 15, 11, 16, _
  8, 16, 7, 15, 7, 13, 8, 12, 7, 11, 6, 6, 4, 3, 3, 2, _
  1, 2
FillArray2Df arm, 8, 10, 9, 9, 10, 9, 13, 8, 14, 9, 16, 9, _
  15, 9.5, 16, 10, 15, 10, 15.5, 11, 14.5, 10, 14, 11, 14, 10, _
  13, 9, 11, 11, 9, 11
FillArray2Df leg, 8, 6, 8, 4, 9, 3, 9, 2, 8, 1, 8, 0.5, 9, 0, _
  12, 0, 10, 1, 10, 2, 12, 4, 11, 6, 10, 7, 9, 7
FillArray2Df eye, 8.75, 15, 9, 14.7, 9.6, 14.7, 10.1, 15, 9.6, 15.25, 9, 15.25
FillArrayf skinColor, 0.1, 1, 0.1, 1
FillArrayf eyeColor, 1, 0.2, 0.2, 1
End Sub

Public Sub glxBegin(ByVal X&)
glBegin X
End Sub

Public Sub glxVertex2fv(ByRef a!)
glVertex2fv a
End Sub

Public Sub glxEnd()
glEnd
End Sub

Public Sub extrudeSolidFromPolygon(data() As POINT2F, dataSize&, thickness#, side&, edge&, whole&)
Dim vertex#(0 To 2), dx#, dy#, lng#
Dim i&, count&
    count = dataSize '/ 8 ' (2 * sizeof(GLfloat));
    If tObj = 0 Then
        tObj = gluNewTess()  ' create and initialize a GLU
                             'polygon * * tesselation object */
        gluTessCallback tObj, GLU_BEGIN, AddressOf glxBegin
        gluTessCallback tObj, GLU_VERTEX, AddressOf glxVertex2fv  ' semi-tricky */
        gluTessCallback tObj, GLU_END, AddressOf glxEnd
    End If
    glNewList side, GL_COMPILE
    glShadeModel GL_SMOOTH  ' smooth minimizes seeing
                            '   tessellation */
    gluTessBeginPolygon tObj, 0
    For i = 0 To count - 1
        vertex(0) = data(i).p(0)
        vertex(1) = data(i).p(1)
        vertex(2) = 0
        gluTessVertex tObj, vertex(0), data(i).p(0)
    Next
    gluTessEndPolygon tObj
    glEndList
    glNewList edge, GL_COMPILE
    glShadeModel smFlat  ' flat shade keeps angular hands
                         '    from being "smoothed" */

    glBegin GL_QUAD_STRIP
    For i = 0 To count
        ' mod function handles closing the edge */
        glVertex3f data(i Mod count).p(0), data(i Mod count).p(1), 0
        glVertex3f data(i Mod count).p(0), data(i Mod count).p(1), thickness
        ' Calculate a unit normal by dividing by Euclidean
        ' distance. We * could be lazy and use
        ' glEnable(GL_NORMALIZE) so we could pass in * arbitrary
        ' normals for a very slight performance hit. */
        dx = data((i + 1) Mod count).p(1) - data(i Mod count).p(1)
        dy = data(i Mod count).p(0) - data((i + 1) Mod count).p(0)
        lng = Sqr(dx * dx + dy * dy)
        glNormal3f dx / lng, dy / lng, 0
    Next
    glEnd
    glEndList
    glNewList whole, GL_COMPILE
    glFrontFace GL_CW
    glCallList edge
    glNormal3f 0, 0, -1     ' constant normal for side */
    glCallList side
    glPushMatrix
    glTranslatef 0, 0, thickness
    glFrontFace GL_CCW
    glNormal3f 0, 0, 1     ' opposite normal for other side */
    glCallList side
    glPopMatrix
    glEndList
End Sub

Public Function MakeDinosaur&()
Dim bodyWidth#
    Init
    bodyWidth = 3
    extrudeSolidFromPolygon body, 22, bodyWidth, _
        BODY_SIDE, BODY_EDGE, BODY_WHOLE
    extrudeSolidFromPolygon arm, 16, bodyWidth / 4, _
        ARM_SIDE, ARM_EDGE, ARM_WHOLE
    extrudeSolidFromPolygon leg, 14, bodyWidth / 2, _
        LEG_SIDE, LEG_EDGE, LEG_WHOLE
    extrudeSolidFromPolygon eye, 6, bodyWidth + 0.2, _
        EYE_SIDE, EYE_EDGE, EYE_WHOLE
    glNewList DINOSAUR, GL_COMPILE
    glPushMatrix
    glTranslatef -8, -8, -bodyWidth / 2
    glMaterialfv GL_FRONT, GL_DIFFUSE, skinColor(0)
    glCallList BODY_WHOLE
    glPushMatrix
    glTranslatef 0, 0, bodyWidth
    glCallList ARM_WHOLE
    glCallList LEG_WHOLE
    glTranslatef 0, 0, -bodyWidth - bodyWidth / 4
    glCallList ARM_WHOLE
    glTranslatef 0, 0, -bodyWidth / 4
    glCallList LEG_WHOLE
    glTranslatef 0, 0, bodyWidth / 2 - 0.1
    glMaterialfv GL_FRONT, GL_DIFFUSE, eyeColor(0)
    glCallList EYE_WHOLE
    glPopMatrix
    glPopMatrix
    glEndList
    MakeDinosaur& = DINOSAUR
End Function



