/*
 * $RCSfile$
 * Copyright (C) 2006 Rob Loach (http://www.robloach.net)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

using System;
using System.Collections;

namespace BooGame.Gui
{
    public class GuiManager : WidgetCollection
    {
        private Widget m_FocusedWidget;
        public Widget FocusedWidget
        {
            get{ return m_FocusedWidget; }
            set
            {
                m_FocusedWidget = value.Focusable ? value : null;
            }
        }

        public virtual void OnMouseMotion(MouseEventArgs e)
        {
            foreach (Widget widget in this)
                if(widget.IntersectsWith(e.Location))
                    widget.OnMouseMotion(e);
        }
        public virtual void OnMouseButtonDown(MouseEventArgs e)
        {
            foreach (Widget widget in this)
            {
                if (widget.IntersectsWith(e.Location))
                {
                    if (widget.Enabled && widget.Visible)
                    {
                        widget.OnMouseButtonDown(e);
                        FocusedWidget = widget;
                    }
                }
            }
        }
        public virtual void OnMouseWheel(MouseEventArgs e)
        {
            foreach (Widget widget in this)
                if (widget.IntersectsWith(e.Location))
                    widget.OnMouseWheel(e);
        }
        public virtual void OnMouseButtonUp(MouseEventArgs e)
        {
            foreach (Widget widget in this)
                if (widget.IntersectsWith(e.Location))
                    if (widget.Enabled && widget.Visible)
                        widget.OnMouseButtonUp(e);
        }

        public virtual void OnKeyUp(KeyboardEventArgs e)
        {
            if(m_FocusedWidget != null)
                if(m_FocusedWidget.Enabled)
                    m_FocusedWidget.OnKeyUp(e);
        }
        public virtual void OnKeyDown(KeyboardEventArgs e)
        {
            if (m_FocusedWidget != null)
                if(m_FocusedWidget.Enabled)
                    m_FocusedWidget.OnKeyDown(e);
        }

        public virtual void OnJoystickButtonDown(JoystickEventArgs e)
        {
            if (m_FocusedWidget != null)
                if(m_FocusedWidget.Enabled)
                    m_FocusedWidget.OnJoystickButtonDown(e);
        }
        public virtual void OnJoystickButtonUp(JoystickEventArgs e)
        {
            if (m_FocusedWidget != null)
                if (m_FocusedWidget.Enabled)
                    m_FocusedWidget.OnJoystickButtonUp(e);
        }
        public virtual void OnJoystickAxisMovement(JoystickEventArgs e)
        {
            if (m_FocusedWidget != null)
                if (m_FocusedWidget.Enabled)
                    m_FocusedWidget.OnJoystickAxisMovement(e);
        }
    }
}
