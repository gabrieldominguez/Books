class AwesomeBoss extends AwesomeEnemy
    placeable;

defaultproperties
{
    MovementSpeed=128.0

    Begin Object Name=EnemyMesh
        Scale3D=(X=1.0,Y=1.0,Z=2.0)
    End Object

    Begin Object Name=CollisionCylinder
        CollisionRadius=128.0
        CollisionHeight=256.0
    End Object
}
