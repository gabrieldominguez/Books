VERSION 5.00
Begin VB.Form feuille_pyramide 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "feuille pyramide"
   ClientHeight    =   4800
   ClientLeft      =   120
   ClientTop       =   696
   ClientWidth     =   5304
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   400
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   442
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox animate1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      ForeColor       =   &H80000008&
      Height          =   4092
      Left            =   480
      ScaleHeight     =   339
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   359
      TabIndex        =   0
      Top             =   240
      Width           =   4332
   End
   Begin VB.Menu menu 
      Caption         =   "menu"
      Begin VB.Menu Quitter 
         Caption         =   "Quitter"
      End
   End
   Begin VB.Menu couleur 
      Caption         =   "couleur"
      Begin VB.Menu small 
         Caption         =   "150"
      End
      Begin VB.Menu medium 
         Caption         =   "200"
      End
      Begin VB.Menu large 
         Caption         =   "250"
      End
   End
   Begin VB.Menu Shading 
      Caption         =   "Shading"
      Begin VB.Menu simple 
         Caption         =   "simple"
      End
      Begin VB.Menu Gouraud 
         Caption         =   "gouraud"
      End
   End
End
Attribute VB_Name = "feuille_pyramide"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'see "Notes" for some explanations

'use the arrow keys to turn the pyramide right or left
'use the up and down key to move the camera over the pyramide


'you need this TLB files : vbogl.tlb (538 ko)
'in order  to make this sample work.
'you can find it here  :
'http://is6.pacific.net.hk/~edx/

'then use  menu "project"
'and choose "references..."
'and select : VB OpenGL API 1.2 (ANSI)

'you can Email me at :
' voineo@netexecutive.com

Dim s As Integer 'to quit the loop

Dim p As Integer 'toggle between normal pyramide and gouraud pyramide

'camera position
Dim xcam As Double
Dim ycam As Double
Dim zcam As Double

Dim pyramideGouraud As New pyramideGouraud
Dim pyramide As New pyramide


'Open Gl declare
Dim m_fieldOfView As Double
Dim m_NearPlane As Double
Dim m_FarPlane As Double
Dim m_AspectRatio As Double
Dim m_hGLRC&, m_hdc&, m_hwnd&

Public Sub Display()

Static Busy As Boolean

If Busy Then Exit Sub
    
Busy = True

glClear clrColorBufferBit Or clrDepthBufferBit

glPushMatrix
    
gluLookAt xcam, ycam, zcam, 0, 0, 0, 0, 1, 0
 
 If p = 1 Then
 pyramide.affichage xcam, ycam, zcam
 End If
 
 If p = 2 Then
pyramideGouraud.affichage xcam, ycam, zcam
End If

glPopMatrix

    glFinish
    SwapBuffers animate1.hDC 'display to the screen

Busy = False

End Sub


Public Sub SetViewPort()

glMatrixMode mmProjection 'first

glLoadIdentity
gluPerspective m_fieldOfView, _
                   m_AspectRatio, _
                   m_NearPlane, _
                   m_FarPlane
                   
glMatrixMode mmModelView 'then

glLoadIdentity

End Sub

Public Sub OnSize()

'called by "Form Resize"

Dim h As Integer
Dim w As Integer
h = feuille_pyramide.animate1.ScaleHeight
w = feuille_pyramide.animate1.ScaleWidth

If h = 0 Then h = 1
m_AspectRatio = w / h
glViewport 0, 0, w, h

SetViewPort 'call SetViewPort

End Sub




Private Sub Form_Activate()

'center the form on the screen
Me.Move (Screen.Width - Me.Width) / 2, (Screen.Height - Me.Height) / 2

p = 2 'gouraud pyramide by default

'menu :
Gouraud.Checked = True
simple.Checked = False

small.Checked = True
medium.Checked = False
large.Checked = False

'call the loop
boucle

End Sub

Private Sub Form_Initialize()

'camera at start up
xcam = 0
ycam = 10
zcam = 15 'move camera with "up" and "down" key


Dim pfd As PIXELFORMATDESCRIPTOR
Dim r&, pos!(0 To 3)

'standards parameters
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 16
    pfd.iLayerType = PFD_MAIN_PLANE
    
    r = ChoosePixelFormat(animate1.hDC, pfd)
    If r = 0 Then
        MsgBox "ChoosePixelFormat failed"
        Exit Sub
    End If
    r = SetPixelFormat(animate1.hDC, r, pfd)
    
    'palette?
    m_hGLRC = wglCreateContext(animate1.hDC)
    wglMakeCurrent animate1.hDC, m_hGLRC
    

    glClearColor 0.5, 0.5, 0.5, 0 'gris
    
    
    'depht
    glClearDepth 1
    glEnable GL_DEPTH_TEST
    
    'color
    glEnable glcColorMaterial
    glColorMaterial faceFront, GL_AMBIENT_AND_DIFFUSE
    
    
   'position of the light source
pos(0) = 0: pos(1) = 10: pos(2) = 30 ': pos(3) = 1
glLightfv ltLight0, lpmPosition, pos(0)
'glLightfv ltLight0, lpmAmbient, lpos(0)

    'light is enabled or not in the menu
    
    m_AspectRatio = 1
    m_FarPlane = 200
    m_NearPlane = 0.5
    m_fieldOfView = 45
    
End Sub


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)

'move camera over the pyramide
If KeyCode = vbKeyUp Then
zcam = zcam - 0.5
If zcam <= 1 Then zcam = 1
End If

If KeyCode = vbKeyDown Then
zcam = zcam + 0.5
If zcam >= 20 Then zcam = 20
End If


If p = 2 Then
'turn pyramide by 12 degrees
If KeyCode = vbKeyLeft Then
pyramideGouraud.rotation_droite
End If

If KeyCode = vbKeyRight Then
pyramideGouraud.rotation_gauche
End If
End If


If p = 1 Then
'turn pyramide by 12 degrees
If KeyCode = vbKeyLeft Then
pyramide.rotation_droite
End If

If KeyCode = vbKeyRight Then
pyramide.rotation_gauche
End If
End If

End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)

'to quit the loop
s = 1

End Sub

Private Sub Form_Resize()

OnSize

End Sub



Public Sub boucle()

Dim nn As Integer
nn = 9
'
While nn < 10

DoEvents

Display 'call display

If s = 1 Then 'quit the loop
Unload Me
End
End If

Wend

End Sub

Private Sub Gouraud_Click()

'disable the light
glDisable GL_LIGHTING
glDisable glcLight0 'couleur blanche par d�faut

Gouraud.Checked = True
simple.Checked = False

p = 2 'use in Display

small.Enabled = True
medium.Enabled = True
large.Enabled = True

End Sub

Private Sub large_Click()

'number of colors for the shade of blue
pyramideGouraud.couleurs 250

small.Checked = False
medium.Checked = False
large.Checked = True

End Sub

Private Sub medium_Click()

'number of colors for the shade of blue
pyramideGouraud.couleurs 200

small.Checked = False
medium.Checked = True
large.Checked = False


End Sub

Private Sub Quitter_Click()

'sert � sortir de la boucle
s = 1

End Sub



Public Sub Notes()

'this sample show how to do Gouraud Shading
'with Open GL and visual basic

'Gouraud Shading is to colour a polygon with a shade off colors
'with respect of the light

'this is visual basic code (not C translate)

'it show some mathematics useful in 3D:
'how to calculate angle between the side of a polygon and the camera
'(this is use to determine if a face is visible from front or back,
'or if a polygon is visible or not)

'it show how to calculate the color for each vertex
'with respect of the position of the vertex from the light source

'as it' s impossible to calculate a normal vector for a point
'we first calculate a normal vector for each face of the object
'then sum and average vectors of the faces that meet on that point

'the second pyramide call "pyramide" is here to show the basic
'open GL lightning mode (so a comparison is possible)

End Sub

Private Sub simple_Click()

 'light
glEnable GL_LIGHTING
glEnable glcLight0 'couleur blanche par d�faut
    

Gouraud.Checked = False
simple.Checked = True

p = 1 'use in Display

small.Enabled = False
medium.Enabled = False
large.Enabled = False

End Sub

Private Sub small_Click()

'number of colors for the shade of blue
pyramideGouraud.couleurs 150

small.Checked = True
medium.Checked = False
large.Checked = False


End Sub


