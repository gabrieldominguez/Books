Attribute VB_Name = "basSwim"
' Ported to Visual Basic by Patrice Scribe, 1997
' scribe@chez.com
' http://www.chez.com
'/**
' * (c) Copyright 1993, 1994, Silicon Graphics, Inc.
' * ALL RIGHTS RESERVED
' * Permission to use, copy, modify, and distribute this software for
' * any purpose and without fee is hereby granted, provided that the above
' * copyright notice appear in all copies and that both the copyright notice
' * and this permission notice appear in supporting documentation, and that
' * the name of Silicon Graphics, Inc. not be used in advertising
' * or publicity pertaining to distribution of the software without specific,
' * written prior permission.
' *
' * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
' * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
' * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
' * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
' * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
' * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
' * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
' * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
' * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
' * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
' * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
' * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
' *
' * US Government Users Restricted Rights
' * Use, duplication, or disclosure by the Government is subject to
' * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
' * (c)(1)(ii) of the Rights in Technical Data and Computer Software
' * clause at DFARS 252.227-7013 and/or in similar or successor
' * clauses in the FAR or the DOD or NASA FAR Supplement.
' * Unpublished-- rights reserved under the copyright laws of the
' * United States.  Contractor/manufacturer is Silicon Graphics,
' * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
' *
' * OpenGL(TM) is a trademark of Silicon Graphics, Inc.
' */

Option Explicit

Sub initFishs()
    Dim i As Long
    For i = 0 To NUM_SHARKS - 1
        sharks(i).x = 70000 + rand() Mod 6000
        sharks(i).y = rand() Mod 600
        sharks(i).Z = rand() Mod 600
        sharks(i).psi = rand() Mod 360 - 180
        sharks(i).v = 1
    Next

    Dolph.x = 30000
    Dolph.y = 0
    Dolph.Z = 6000
    Dolph.psi = 90
    Dolph.theta = 0
    Dolph.v = 3

    MomWhale.x = 70000
    MomWhale.y = 0
    MomWhale.Z = 0
    MomWhale.psi = 90
    MomWhale.theta = 0
    MomWhale.v = 3

    BabyWhale.x = 60000
    BabyWhale.y = -2000
    BabyWhale.Z = -2000
    BabyWhale.psi = 90
    BabyWhale.theta = 0
    BabyWhale.v = 3
End Sub

Sub Init()
    Dim Ambient(0 To 3) As Single
    FillArray Ambient, Array(0.1, 0.1, 0.1, 1)
    Dim diffuse(0 To 3) As Single
    FillArray diffuse, Array(1, 1, 1, 1)
    Dim Position(0 To 3) As Single
    FillArray Position, Array(0, 1, 0, 0)
    Dim mat_shininess(0) As Single
    FillArray mat_shininess, Array(90)
    Dim mat_specular(0 To 3) As Single
    FillArray mat_specular, Array(0.8, 0.8, 0.8, 1)
    Dim mat_diffuse(0 To 3) As Single
    FillArray mat_diffuse, Array(0.46, 0.66, 0.795, 1)
    Dim mat_ambient(0 To 3) As Single
    FillArray mat_ambient, Array(0, 0.1, 0.2, 1)
    Dim lmodel_ambient(0 To 3) As Single
    FillArray lmodel_ambient, Array(0.4, 0.4, 0.4, 1)
    Dim lmodel_localviewer(0) As Single
    FillArray lmodel_localviewer, Array(0)

    glFrontFace (GL_CW)

    glDepthFunc (GL_LEQUAL)
    glEnable (GL_DEPTH_TEST)

    glLightfv GL_LIGHT0, GL_AMBIENT, Ambient(0)
    glLightfv GL_LIGHT0, GL_DIFFUSE, diffuse(0)
    glLightfv GL_LIGHT0, GL_POSITION, Position(0)
    glLightModelfv GL_LIGHT_MODEL_Ambient, lmodel_ambient(0)
    glLightModelfv GL_LIGHT_MODEL_LOCAL_VIEWER, lmodel_localviewer(0)
    glEnable (GL_LIGHTING)
    glEnable (GL_LIGHT0)

    glMaterialfv GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess(0)
    glMaterialfv GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular(0)
    glMaterialfv GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse(0)
    glMaterialfv GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient(0)

    initFishs

    glClearColor 0, 0.5, 0.9, 0
End Sub


Function rand() As Long
    rand = Rnd * 100000
End Function

Sub FishTransform(Fish As fishRec)
    glTranslatef Fish.y, Fish.Z, -Fish.x
    glRotatef -Fish.psi, 0, 1, 0
    glRotatef Fish.theta, 1, 0, 0
    glRotatef -Fish.phi, 0, 0, 1
End Sub

Sub WhalePilot(Fish As fishRec)
    Fish.phi = -20
    Fish.theta = 0
    Fish.psi = Fish.psi - 0.5

    Fish.x = Fish.x + WHALESPEED * Fish.v * Cos(Fish.psi / RAD) * Cos(Fish.theta / RAD)
    Fish.y = Fish.y + WHALESPEED * Fish.v * Sin(Fish.psi / RAD) * Cos(Fish.theta / RAD)
    Fish.Z = Fish.Z + WHALESPEED * Fish.v * Sin(Fish.theta / RAD)
End Sub

Sub SharkPilot(Fish As fishRec)
    Static sign As Long
    Dim x As Single, y As Single, Z As Single, tpsi As Single, ttheta As Single, thetal As Single
    If sign = 0 Then sign = 1
    Fish.xt = 60000
    Fish.yt = 0
    Fish.zt = 0

    x = Fish.xt - Fish.x
    y = Fish.yt - Fish.y
    Z = Fish.zt - Fish.Z

    thetal = Fish.theta

    ttheta = RAD * Atn(Z / (Sqr(x * x + y * y)))

    If (ttheta > Fish.theta + 0.25) Then
        Fish.theta = Fish.theta + 0.5
    ElseIf (ttheta < Fish.theta - 0.25) Then
        Fish.theta = Fish.theta - 0.5
    End If
    If (Fish.theta > 90) Then
        Fish.theta = 90
    End If
    If (Fish.theta < -90) Then
        Fish.theta = -90
    End If
    Fish.dtheta = Fish.theta - thetal

    tpsi = RAD * Atn(y / x) 'atan2(y, x)

    Fish.attack = 0

    If (Abs(tpsi - Fish.psi) < 10) Then
        Fish.attack = 1
    ElseIf (Abs(tpsi - Fish.psi) < 45) Then
        If (Fish.psi > tpsi) Then
            Fish.psi = Fish.psi - 0.5
            If (Fish.psi < -180) Then
                Fish.psi = Fish.psi + 360
            End If
        ElseIf (Fish.psi < tpsi) Then
            Fish.psi = Fish.psi + 0.5
            If (Fish.psi > 180) Then
                Fish.psi = Fish.psi - 360
            End If
        End If
    Else
        If (rand() Mod 100 > 98) Then
            sign = 1 - sign
        End If
        Fish.psi = Fish.psi + sign
        If (Fish.psi > 180) Then
            Fish.psi = Fish.psi - 360
        End If
        If (Fish.psi < -180) Then
            Fish.psi = Fish.psi + 360
        End If
    End If

    If (Fish.attack) Then
        If (Fish.v < 1.1) Then
            Fish.spurt = 1
        End If
        If (Fish.spurt) Then
            Fish.v = Fish.v + 0.2
        End If
        If (Fish.v > 5) Then
            Fish.spurt = 0
        End If
        If ((Fish.v > 1) And (Not Fish.spurt)) Then
            Fish.v = Fish.v - 0.2
        End If
    Else
        If (Not (rand() Mod 400) And (Not Fish.spurt)) Then
            Fish.spurt = 1
        End If
        If (Fish.spurt) Then
            Fish.v = Fish.v + 0.05
        End If
        If (Fish.v > 3) Then
            Fish.spurt = 0
        End If
        If ((Fish.v > 1) And (Not Fish.spurt)) Then
            Fish.v = Fish.v - 0.05
        End If
    End If

    Fish.x = Fish.x + SHARKSPEED * Fish.v * Cos(Fish.psi / RAD) * Cos(Fish.theta / RAD)
    Fish.y = Fish.y + SHARKSPEED * Fish.v * Sin(Fish.psi / RAD) * Cos(Fish.theta / RAD)
    Fish.Z = Fish.Z + SHARKSPEED * Fish.v * Sin(Fish.theta / RAD)
End Sub

Sub SharkMiss(ByVal i As Long)
    Dim j As Long
    Dim avoid As Single, thetal As Single
    Dim x As Single, y As Single, Z As Single, R As Single

    For j = 0 To NUM_SHARKS - 1
        If (j <> i) Then
            x = sharks(j).x - sharks(i).x
            y = sharks(j).y - sharks(i).y
            Z = sharks(j).Z - sharks(i).Z

            R = Sqr(x * x + y * y + Z * Z)

            avoid = 1
            thetal = sharks(i).theta

            If (R < SHARKSIZE) Then
                If (Z > 0) Then
                    sharks(i).theta = sharks(i).theta - avoid
                Else
                    sharks(i).theta = sharks(i).theta + avoid
                End If
            End If
            sharks(i).dtheta = sharks(i).dtheta + (sharks(i).theta - thetal)
        End If
    Next
End Sub
