using System;

namespace ParticleSystems
{
    namespace Verlet
    {
        /// <summary>
        /// Exception class used by ParticleSystems.Verlet
        /// </summary>
        public class Exception : System.Exception
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="message">The message string</param>
            public Exception(string message)
                :	base(message)
            {
            }
        }
    }
}
