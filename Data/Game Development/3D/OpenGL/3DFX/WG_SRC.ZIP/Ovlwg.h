
//Chris' WinGlide enhancements
//Copr. 1998, Chris Dohnal (cwdohnal@ucdavis.edu)

#ifndef _OVLWG_
#define _OVLWG_

#include <windows.h>

extern BOOL OvlWGInitialize(HWND, DWORD, DWORD);
extern VOID OvlWGShutdown(VOID);
extern VOID OvlWGCopy3DfxFrameBuffer(VOID);

#endif //_OVLWG_
