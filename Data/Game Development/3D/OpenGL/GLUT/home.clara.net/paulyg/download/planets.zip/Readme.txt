Current Version: 29/10/99
Fixes from last version:-

*  Now using my bmp image functions instead of the raw file loader.
*  Fixed the 'jumpiness' of the camera movement.  (I actually thought
   I'd fixed that, but hadn't changed it in the uploaded version.)
*  All planets are now rendered using a single function.
*  Used the system clock to make the simulation update the positions 
   of the camera, planets and anything else consistantly.  Before, the 
   movement if the positions of entities in the scene occurs every
   frame redraw -- that was bad.

Still to do..

1.
Use our new found 'time' to control input from the mouse in a 
better way.  Instead of using screen delta coordinates directly to 
influence the camera angle - a group of 'camera_direction' deltas 
should be used.  These could have damping on them so that the angle 
change occurs much more smoothly.

2.
Have a textured or un-textured nebula in the background.  Use somekind 
of object loader to import a collection of polygons that could look 
like a nebula.

3.
Motion blur on the stars is nice in games like I-War and Freespace.  
Easy to do too...