class AwesomeGun extends UTWeap_RocketLauncher_Content;

var int MyInt;

defaultproperties
{
    FireInterval(0)=0.1
    ShotCost(0)=0
}
