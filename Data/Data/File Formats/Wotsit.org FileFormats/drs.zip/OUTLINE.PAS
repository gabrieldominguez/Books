program wpfonts(input,output);
{ tested with WP.DRS from DrawPerfect 1.0 }
uses graph,crt,dos;
const multx=1;
      multy=1;
      divx=20;
      divy=30;
      num=6;

type buffer=array[0..65534] of byte;
     index_type=array[0..67] of record
                                   offset:longint;
                                   lengte:word;
                                   xxxxxx:word
                                end;
     nindex_type=array[0..67] of word;
     names_type=array[0..1540] of byte;
     inhoud=record
               typ:word; { 4=bitmap, 8=outline}
               aantal_chars:word;
               table_offset:word;
               data_offset :word;
               data_lengte :word;
            end;
     table=array[0..32766] of word;
     data=array[0..65534] of byte;

     index_ptr=^index_type;
     table_ptr=^table;
     data_ptr=^data;
     pr=(_6,_7,_a,_b,_77);
     typ77=record x,y:integer end;
     typ6=record
                lengte:byte;
                data:array[1..255] of record x,y:shortint end
                end;
     typ7=record
                lengte:byte;
                data:array[1..255] of record x,y:integer end
                end;
     typa=record x1,y1,x2,y2,x3,y3:shortint end;
     typb=record x1,y1,x2,y2,x3,y3:integer end;
     line=record
                case code:pr of
                     $6 :(_6 :typ6);
                     $7 :(_7 :typ7);
                     $a :(_a :typa);
                     $b :(_b :typb);
                     $77:(_77:typ77)
                end;

var heap:pointer;
    t:text;

procedure init_fonts(var f:file;
                     var index:index_ptr;
                     var font_table:table_ptr;
                     var font_data:data_ptr;
                     var nindex:nindex_type;
                     var names:names_type);
begin
assign(f,'c:\dr10\wp.drs');
{$i-}
reset(f,1);
{$i+}
if ioresult<>0
   then begin
        writeln('C:\DR10\WP.DRS not found.');
        halt(1)
        end;
seek(f,$12d0);
getmem(index,$218);
blockread(f,index^,$218);
font_table:=nil;
font_data:=nil;
seek(f,$14e8);
blockread(f,nindex,sizeof(nindex_type));
seek(f,$156e);
blockread(f,names,sizeof(names_type));
mark(heap);
end;

procedure load_font( var f:file;
                         font_nr:byte;
                     var font:inhoud;
                     var font_table:table_ptr;
                     var font_data:data_ptr;
                     var index:index_ptr);

var font_offset:longint;
begin
    release(heap);
    font_offset:=$123a+index^[font_nr].offset;
    seek(f,font_offset);
    blockread(f,font,sizeof(font));
    seek(f,font_offset+font.table_offset);
    getmem(font_table,font.aantal_chars*2+2);
    blockread(f,font_table^,font.aantal_chars*2+2);
    seek(f,font_offset+font.data_offset);
    getmem(font_data,font.data_lengte);
    blockread(f,font_data^,font.data_lengte);
end;


procedure printoutline( font:inhoud;
                        font_table:table_ptr;
                        font_data:data_ptr;
                        ch:byte);
var lengte:word;
    m,n,p:word;
    dx,dy:integer;
    hulp:^line;
    breedte:^word;

begin
n:=font_table^[ch];
lengte:=0;
repeat
      lengte:=lengte+font_data^[n];
      n:=n+1;
until font_data^[n-1]<255;
breedte:=addr(font_data^[n]);
m:=n+2;
dx:=0;dy:=0;
while m<n+lengte do
      begin
      case font_data^[m] of
       $78,$77: begin
                hulp:=addr(font_data^[m]);
                dx:=hulp^._77.x;
                dy:=hulp^._77.y;
                writeln(t,'moveto ',dx:5,dy:5);
                m:=m+5;
                end;
           $7:  begin
                hulp:=addr(font_data^[m]);
                for p:=1 to font_data^[m+1] do
                begin
                   dx:=dx+hulp^._7.data[p].x;
                   dy:=dy+hulp^._7.data[p].y;
                   writeln(t,'lineto ',dx:5,dy:5);
                end;
                m:=m+2+font_data^[m+1]*4
                end;
           $6:  begin
                hulp:=addr(font_data^[m]);
                for p:=1 to font_data^[m+1] do
                    begin
                    dx:=dx+hulp^._6.data[p].x;
                    dy:=dy+hulp^._6.data[p].y;
                    writeln(t,'lineto ',dx:5,dy:5);
                    end;
                m:=m+2+font_data^[m+1]*2
                end;
           $a:  begin
                hulp:=addr(font_data^[m]);
                with hulp^._a do
                     begin
                     write(t,'bezier ');
                     dx:=dx+x1;dy:=dy+y1;write(t,dx:5,dy:5);
                     dx:=dx+x2;dy:=dy+y2;write(t,dx:5,dy:5);
                     dx:=dx+x3;dy:=dy+y3;write(t,dx:5,dy:5);
                     end;
                writeln(t);
                m:=m+7;
                end;
           $b:  begin
                hulp:=addr(font_data^[m]);
                with hulp^._b do
                     begin
                     write(t,'bezier ');
                     dx:=dx+x1;dy:=dy+y1;write(t,dx:5,dy:5);
                     dx:=dx+x2;dy:=dy+y2;write(t,dx:5,dy:5);
                     dx:=dx+x3;dy:=dy+y3;write(t,dx:5,dy:5);
                     end;
                writeln(t);
                m:=m+13;
                end;
           else begin
                writeln('error:',font_data^[m]);
                end;
           end{case}
      end;{while}
end;

procedure help;
begin
  writeln('OUTLINE fontnr charnr file');
  writeln('  output outline of char to file');
  halt;
end;

var f:file;
    font:inhoud;
    font_table:table_ptr;
    font_data:data_ptr;
    index:index_ptr;
    nindex:nindex_type;
    names:names_type;
    font_nr:byte;
    char_nr:byte;
    c:char;
    name:^string;
    code:integer;
begin
  if (paramcount<>3) then help;
  val(paramstr(1),font_nr,code); if (code<>0) then help;
  val(paramstr(2),char_nr,code); if (code<>0) then help;
  assign(t,paramstr(3));
  {$i-}
  rewrite(t);
  {$i+}
  if (IOresult<>0) then help;

  init_fonts(f,index,font_table,font_data,nindex,names);
  name:=addr(names[nindex[font_nr]]);
  load_font(f,font_nr,font,font_table,font_data,index);
  if (font.typ=8) then
     begin
         writeln(t,' font : ',name^,' font nr: ',font_nr,' char nr: ',char_nr);
         printoutline(font,font_table,font_data,char_nr);
     end else
  if (font.typ=4) then
     begin
         writeln(' font : ',name^,' font nr: ',font_nr);
         writeln('font is bitmap...')
     end else
  writeln('unknown fonttype');
  close(f);
  close(t);
end.
