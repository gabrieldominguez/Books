VERSION 5.00
Object = "*\A..\..\glxCtl\glxCtl.vbp"
Begin VB.Form frmMain 
   Caption         =   "Logo"
   ClientHeight    =   5250
   ClientLeft      =   240
   ClientTop       =   2325
   ClientWidth     =   5880
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5250
   ScaleWidth      =   5880
   Begin glCtl.glxCtl glxCtl1 
      Height          =   4740
      Left            =   90
      TabIndex        =   0
      Top             =   180
      Width           =   5325
      _ExtentX        =   9393
      _ExtentY        =   8361
   End
   Begin VB.Menu mnufile 
      Caption         =   "File"
      Begin VB.Menu mnuf1 
         Caption         =   "z/Z - Ztranslation"
      End
      Begin VB.Menu mnuf2 
         Caption         =   "1/2/3 - Polygon Fillmode"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, shift As Integer)
    CX.KeyDown KeyCode, shift
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CX = New CLogo
glxCtl1.Init
glxCtl1.Animate = True
End Sub

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, shift As Integer)
CX.KeyDown KeyCode, shift
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


