VERSION 5.00
Object = "{34A5E085-7527-11D2-9718-000000000000}#1.0#0"; "glxCtl.ocx"
Begin VB.Form frmMain 
   Caption         =   "Index"
   ClientHeight    =   4380
   ClientLeft      =   3525
   ClientTop       =   5955
   ClientWidth     =   4905
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   4380
   ScaleWidth      =   4905
   Begin glCtl.glxCtl glxCtl1 
      Height          =   3705
      Left            =   225
      TabIndex        =   0
      Top             =   270
      Width           =   4200
      _ExtentX        =   7408
      _ExtentY        =   6535
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case (KeyCode)
    Case 27:   Unload frmMain
    Case Else:
        CX.KeyDown KeyCode, Shift
    End Select
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    CX.KeyPress KeyAscii
End Sub

Private Sub Form_Load()
Set gCtl = glxCtl1
Set CX = New CIndex
glxCtl1.Init
glxCtl1.Animate = True
End Sub

Private Sub Form_Resize()
glxCtl1.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub glxCtl1_Draw()
CX.Draw
End Sub

Private Sub glxCtl1_Init()
CX.Init
End Sub

Private Sub glxCtl1_InitGL()
CX.InitGL
End Sub

Private Sub glxCtl1_KeyDown(KeyCode As Integer, Shift As Integer)
    CX.KeyDown KeyCode, Shift
End Sub

'Private Sub glxCtl1_MakePalette(hPal As Long)
'hPal = CX.MakePalette
'End Sub

Private Sub glxCtl1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseDown Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseMove Button, Shift, x, y
End Sub

Private Sub glxCtl1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
CX.MouseUp Button, Shift, x, y
End Sub

Private Sub glxCtl1_Resize(width As Long, height As Long, Default As Boolean)
Default = CX.Reshape(width, height)
End Sub


