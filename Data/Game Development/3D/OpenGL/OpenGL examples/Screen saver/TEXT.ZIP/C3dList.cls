VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "C3dList"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'*************************************************************************\
'FUNCTION:
'Simple class to hold a string and it's key.
'The key identifies a category so that the user can select a
'category and have the ss cycle through those strings .
'AUTHOR: ported by edx - edx@hk.super.net, Feb 98
'HISTORY: - modified to use updated glxCtl, April 98
'*************************************************************************\

Public pszStr As String
Public sKey$

