VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
  Persistable = 0  'NotPersistable
  DataBindingBehavior = 0  'vbNone
  DataSourceBehavior  = 0  'vbNone
  MTSTransactionMode  = 0  'NotAnMTSObject
END
Attribute VB_Name = "glxLights"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'-------------------------------------------------------------------------
'FUNCTION: wraps some of the global lighting parameters
'   - creates wrappers for the 8 lights
'
'AUTHOR: edx - edx@hk.super.net, April 98
'HISTORY:
'-------------------------------------------------------------------------
Public Enum LightIndexConstants
    liLight0 = 1
    liLight1 = 2
    liLight2 = 3
    liLight3 = 4
    liLight4 = 5
    liLight5 = 6
    liLight6 = 7
    liLight7 = 8
End Enum
Private m_Col As Collection

Public Property Get count() As Long
    count = m_Col.count
End Property

Public Property Get Item(Index As LightIndexConstants) As glxLight
Attribute Item.VB_UserMemId = 0
On Error GoTo errorhandler
    Set Item = m_Col(Index)
Exit Property
errorhandler:
    'Err.Raise errIndexOutOfBounds, "CGLLights", "Index out of bounds"
End Property

Public Property Get NewEnum() As IUnknown
    Set NewEnum = m_Col.[_NewEnum]
End Property

Private Sub Class_Initialize()
Dim l As glxLight
Dim i&

Set m_Col = New Collection
    For i = ltLight0 To (ltLight0 + 7)
        Set l = New glxLight
        l.Index = i
        m_Col.Add l
    Next
End Sub

Private Sub Class_Terminate()
    
    Set m_Col = Nothing
End Sub


Public Property Get LocalViewer() As Boolean
Dim r As Byte
glGetBooleanv GL_LIGHT_MODEL_LOCAL_VIEWER, r
LocalViewer = r
End Property

Public Property Let LocalViewer(ByVal bNewValue As Boolean)
Dim r As Boolean
If bNewValue Then r = 1
glLightModeli GL_LIGHT_MODEL_LOCAL_VIEWER, r
End Property

Public Property Get TwoSide() As Boolean
Dim r As Byte
glGetBooleanv GL_LIGHT_MODEL_TWO_SIDE, r
TwoSide = r
End Property

Public Property Let TwoSide(ByVal bNewValue As Boolean)
Dim r As Boolean
If bNewValue Then r = 1
glLightModeli GL_LIGHT_MODEL_TWO_SIDE, r
End Property

Public Sub SetAmbient(ByVal Red!, ByVal Green!, ByVal Blue!, Optional ByVal alpha! = 1)
Dim clr!(0 To 3)
    clr(0) = Red
    clr(1) = Green
    clr(2) = Blue
    clr(3) = alpha
    glLightModelfv GL_LIGHT_MODEL_Ambient, clr(0)
    UC.GetErr
End Sub

Public Sub GetAmbient(r!, g!, b!, a!)
Dim clr!(0 To 3)
    glGetFloatv glgLightModelAmbient, clr(0)
    r = clr(0)
    g = clr(1)
    b = clr(2)
    a = clr(3)
End Sub



