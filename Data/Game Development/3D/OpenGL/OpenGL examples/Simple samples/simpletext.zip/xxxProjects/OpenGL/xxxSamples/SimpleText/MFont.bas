Attribute VB_Name = "MFont"
Option Explicit
'/******************************Module*Header******************************
'FUNCTION: create and draw 3d text
'AUTHOR: edx - edx@hk.super.net, Feb 98
'   - the code in this module is derived from code in
'       -OpenGL SuperBible
'       -MSJ sample by Ron Fosner
'HISTORY: -
'/*************************************************************************

Public ARIAL36& ' = 12000
Public TIMES36& ' = 13000
Const MAX_STRING = 1024
'Declare Function CreateFontIndirect& Lib "gdi32" Alias "CreateFontIndirectA" (lpLogFont As LOGFONT)
'Declare Function CreateFont& Lib "gdi32" Alias "CreateFontA" (ByVal H As Long, ByVal W As Long, ByVal E As Long, ByVal O As Long, ByVal W As Long, ByVal i As Long, ByVal u As Long, ByVal s As Long, ByVal C As Long, ByVal OP As Long, ByVal CP As Long, ByVal Q As Long, ByVal PAF As Long, ByVal F As String)

Public Function StringToByteArray&(A() As Byte, s$)
Dim i&
If Len(s) Then
For i = 1 To Len(s)
    A(i - 1) = Asc(Mid$(s, i, 1))
Next
A(i) = 0
End If
End Function

'return the 255 values for the color components
Public Function GetBValue(X As Long) As Integer
    GetBValue = (X \ &H10000) And &HFF
End Function

Public Function GetGValue(X As Long) As Integer
    GetGValue = (X \ &H100) And &HFF
End Function

Public Function GetRValue(X As Long) As Integer
    GetRValue = X And &HFF
End Function

'set current color from RGB255 values
Public Sub glRGB(R%, G%, B%)
    glColor3f R / 255, G / 255, B / 255
End Sub

'set current color from RGB255 values
Public Sub glColor32(Color&)
Dim R%, G%, B%
    R = GetRValue(Color)
    G = GetGValue(Color)
    B = GetBValue(Color)
    glColor3f R / 255, G / 255, B / 255
End Sub

Public Sub Create3dFont(hDC&, ID&, Typeface$, _
    height&, weight&, italic&, Color&)
Dim hFont&, R& ', base&
Dim agmf(256) As GLYPHMETRICSFLOAT 'agmf[256] ' Throw away
Dim face(LF_FACESIZE) As Byte
Dim lf As LOGFONT
    lf.lfHeight = height '-10
    lf.lfWidth = 0
    lf.lfEscapement = 0
    lf.lfOrientation = 0
    lf.lfWeight = weight 'FW_BOLD
    lf.lfItalic = italic 'FALSE
    lf.lfUnderline = False
    lf.lfStrikeOut = False
    lf.lfCharSet = ANSI_CHARSET
    lf.lfOutPrecision = OUT_DEFAULT_PRECIS
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS
    lf.lfQuality = DEFAULT_QUALITY
    lf.lfPitchAndFamily = DEFAULT_PITCH
    'lf.lfFaceName = Typeface
    StringToByteArray lf.lfFaceName, Typeface
    '
    glColor32 Color
    hFont = CreateFontIndirect(lf)
    SelectObject hDC, hFont
    'create display lists for glyphs 0 through 255 with 0.1 extrusion
    ' and default deviation. The display list numbering starts at 1000
    ' (it could be any number).
    ID = glGenLists(96)
    If ID = 0 Then
        MsgBox "Unable to create font"
    Else
        R = wglUseFontOutlines(hDC, 32, 96, ID, 0#, 0.3, _
                    WGL_FONT_POLYGONS, agmf(0))
        If R = 0 Then
            MsgBox "Unable to create font"
            glDeleteLists ID, 96
        End If
    End If
    DeleteObject hFont
End Sub

Public Sub DrawText(Font&, s$, X!, Y!, Z!, Optional Color)
Dim R As glErrorConstants, i&
Dim A() As Byte
    glPushAttrib amListBit
    glPushMatrix
    'set font size
    'glScalef m_FontSize*10.0f, m_FontSize*10.0f, m_FontSize*10.0f);
    'set font
    glListBase Font - 32 'ARIAL36 'TIMES36
    glTranslatef X, Y, Z
    'set forecolor
    If Not IsMissing(Color) Then
        glColor32 CLng(Color)
    End If
    ReDim A(0 To Len(s) + 1)
    StringToByteArray A, s
    glCallLists Len(s), GL_BYTE, A(0) 'ByVal s
    'GL_UNSIGNED_BYTE
    'GL_UNSIGNED_SHORT
'    For i = font To font + 96
'        glCallList i
'    Next
    glPopMatrix
    R = glGetError()
    If R <> glerrNoError Then
        MsgBox R
    End If
    glPopAttrib
End Sub

